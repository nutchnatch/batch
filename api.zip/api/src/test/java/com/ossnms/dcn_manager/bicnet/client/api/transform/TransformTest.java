package com.ossnms.dcn_manager.bicnet.client.api.transform;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import org.junit.Test;

import java.util.Collection;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;

public class TransformTest {

    @Test public void getNeIds() throws Exception {
        IAS domain = new ASItem();
        domain.setNeList(new INEId[]{new NEIdItem(1), new NEIdItem(2)});

        final Collection<Integer> neIds = Transform.getNeIds(domain);

        assertThat(neIds, containsInAnyOrder(1,2));
    }

    @Test public void getNeIds_empty() throws Exception {
        IAS domain = new ASItem();
        domain.setNeList(new INEId[0]);

        final Collection<Integer> neIds = Transform.getNeIds(domain);

        assertThat(neIds.isEmpty(), is(true) );
    }
}