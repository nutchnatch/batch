package com.ossnms.dcn_manager.bicnet.client.api.command;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class CommandExceptionTest {

    @Test public void testErrorMessage() throws Exception {
        final CommandException commandException = new CommandException("error {}", 1);
        assertThat(commandException.getMessage(), is("error 1"));
    }

    @Test public void testError() throws Exception {
        final CommandException commandException = new CommandException(new Exception("error message"));
        assertThat(commandException.getMessage(), containsString("error message"));
    }
}