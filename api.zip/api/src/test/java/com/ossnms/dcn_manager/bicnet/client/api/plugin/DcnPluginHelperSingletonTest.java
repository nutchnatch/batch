package com.ossnms.dcn_manager.bicnet.client.api.plugin;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class DcnPluginHelperSingletonTest {

    private BiCNetPluginSite site;
    private IPluginSecurityProvider securityProvider;

    @Before
    public void setup() {
        site = mock(BiCNetPluginSite.class);
        securityProvider = mock(IPluginSecurityProvider.class);

        DcnPluginHelperSingleton.getInstance().setCfPluginSite(site);
    }

    @Test
    public void testPluginId() {
        final DcnPluginHelperSingleton plugin = DcnPluginHelperSingleton.getInstance();

        assertNull(plugin.getPluginId());

        plugin.setPluginId("id");

        assertThat(plugin.getPluginId(), CoreMatchers.is("id"));
    }

    @Test
    public void testSecurityProvider() throws BiCNetPluginException {
        when(site.getSecurityProvider()).thenReturn(securityProvider);

        assertNotNull(DcnPluginHelperSingleton.getInstance().getSecurityProvider());

        verify(site, Mockito.times(1)).getSecurityProvider();
    }

    @Test(expected = SecurityException.class)
    public void testSecurityProvider_error() throws BiCNetPluginException {
        doThrow(BiCNetPluginException.class).when(site).getSecurityProvider();

        DcnPluginHelperSingleton.getInstance().getSecurityProvider();
    }
}
