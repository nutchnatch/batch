package com.ossnms.dcn_manager.bicnet.client.api.view;

import com.ossnms.dcn_manager.bicnet.client.api.exception.DcnClientException;
import com.ossnms.tools.jfx.table.JfxTable;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class MessageBoxTest {

    @Test
    public void testContructor() {
        assertNotNull(new MessageBox());
        assertNotNull(new MessageBox(new JfxTable()));
    }
    
    @Test
    public void testMessage() {
        assertThat(new MessageBox().getMessageFromRootCause(new DcnClientException("Message test!")), 
                          CoreMatchers.is("Message test!"));
    }
    
    @Test
    public void testMessage_throws_chain() {
        assertThat(new MessageBox().getMessageFromRootCause(new DcnClientException(new Exception("Message test!"))), 
                          CoreMatchers.is("Message test!"));
    }
    
    @Test
    public void testMessage_wrong_format() {
        assertThat(new MessageBox().getMessageFromRootCause(new DcnClientException("Messa:ge test!")), 
                          CoreMatchers.is("ge test!"));
    }
}
