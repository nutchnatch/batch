package com.ossnms.dcn_manager.bicnet.client.api.plugin.security;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkableId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class SecureActionValidationTest {

    private ISecureClientSession secureSession;
    private SecureActionValidation validator;

    @Before
    public void setup() throws BiCNetPluginException {

        DcnPluginHelper helper = mock(DcnPluginHelper.class);
        IPluginSecurityProvider provider = mock(IPluginSecurityProvider.class);
        secureSession = mock(ISecureClientSession.class);
        ISessionContext context = mock(ISessionContext.class);


        when(helper.getSecurityProvider()).thenReturn(provider);
        when(helper.getSessionContext()).thenReturn(context);
        when(helper.getClientSession()).thenReturn(Optional.of(secureSession));

        validator = new SecureActionValidation(helper);
    }

    @Test
    public void testCheckPermission_valid() throws Exception {
        when(secureSession.checkOperationPermission(SecureAction.MOVE_NE_SAN.getIdentifier())).thenReturn(true);

        assertTrue(validator.checkPermission(SecureAction.MOVE_NE_SAN));
    }

    @Test
    public void testCheckPermission_invalid() throws Exception {
        when(secureSession.checkOperationPermission(SecureAction.MOVE_NE_SAN.getIdentifier())).thenReturn(false);

        assertFalse(validator.checkPermission(SecureAction.MOVE_NE_SAN));
    }

    @Test
    public void testCheckPermissionWithDomainObjects_valid() throws Exception {
        IManagedObjectId[] domainObject = domainObject();
        when(secureSession.checkOperationPermission(SecureAction.MOVE_NE_SAN.getIdentifier(), domainObject)).thenReturn(domainObject);

        assertTrue(validator.checkPermission(SecureAction.MOVE_NE_SAN, domainObject));
    }

    @Test
    public void testCheckPermissionWithDomainObjects_invalid() throws Exception {
        IManagedObjectId[] domainObject = domainObject();
        when(secureSession.checkOperationPermission(SecureAction.MOVE_NE_SAN.getIdentifier(), domainObject))
                .thenReturn(ImmutableList.of(new EMIdItem(1), new EMIdItem(2)).toArray(new IManagedObjectId[2]));

        assertFalse(validator.checkPermission(SecureAction.MOVE_NE_SAN, domainObject));
    }

    @Test
    public void testCheckPermissionWithNonDomainObjects_valid() throws Exception {
        IManagedObjectId[] nonDomainObject = nonDomainObject();
        when(secureSession.checkOperationPermission(SecureAction.MOVE_NE_SAN.getIdentifier())).thenReturn(true);

        assertTrue(validator.checkPermission(SecureAction.MOVE_NE_SAN, nonDomainObject));
    }

    @Test
    public void testCheckPermissionWithNonDomainObjects_invalid() throws Exception {
        IManagedObjectId[] nonDomainObject = nonDomainObject();
        when(secureSession.checkOperationPermission(SecureAction.MOVE_NE_SAN.getIdentifier())).thenReturn(false);

        assertFalse(validator.checkPermission(SecureAction.MOVE_NE_SAN, nonDomainObject));
    }

    @Test public void shouldUseCachedVisibilityValue() throws Exception {
        INEId ne = new NEIdItem(1);

        //first call should fetch from USM
        reset(secureSession);
        validator.checkVisibility(ne);

        verify(secureSession, times(1)).filterVisibleObjects(any(IManagedObjectMarkableId[].class));


        //second call should use cache
        reset(secureSession);
        validator.checkVisibility(ne);

        verify(secureSession, never()).filterVisibleObjects(any(IManagedObjectMarkableId[].class));
    }

    private IManagedObjectId[] domainObject() {
        IManagedObjectId managedObjectId = new NEIdItem(1);
        return new IManagedObjectId[]{managedObjectId};
    }

    private IManagedObjectId[] nonDomainObject() {
        IManagedObjectId managedObjectId = new MediatorIdItem(1);
        return new IManagedObjectId[]{managedObjectId};
    }
}
