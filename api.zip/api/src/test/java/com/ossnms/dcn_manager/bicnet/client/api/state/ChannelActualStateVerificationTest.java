package com.ossnms.dcn_manager.bicnet.client.api.state;

import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ChannelActualStateVerificationTest {

    private IEM object;

    @Before
    public void setup() {
        object = Mockito.mock(IEM.class);
    }
    
    @Test
    public void testUtilityClass()  {
        try {
            final Constructor<ChannelActualStateVerification> constructor = ChannelActualStateVerification.class.getDeclaredConstructor();
            assertTrue(Modifier.isPrivate(constructor.getModifiers()));
            constructor.setAccessible(true);
            constructor.newInstance();
        } catch (final Exception e) {
             Assert.fail(e.getMessage());
        } 
    }

    @Test
    public void testIsActive() {
        when(object.getCommunicationState()).thenReturn(CommunicationState.CONNECTED);
        assertTrue(ChannelActualStateVerification.isActive(object));
        verify(object).getCommunicationState();
    }

    @Test
    public void testIsInactive() {
        when(object.getCommunicationState()).thenReturn(CommunicationState.DISCONNECTED);
        assertTrue(ChannelActualStateVerification.isInactive(object));
        verify(object).getCommunicationState();
    }
    
    @Test
    public void testIsInactive_connecting() {
        when(object.getCommunicationState()).thenReturn(CommunicationState.CONNECTING);
        assertTrue(ChannelActualStateVerification.isConnecting(object));
        verify(object).getCommunicationState();
    }
    
    @Test
    public void testIsActive_false() {
        when(object.getCommunicationState()).thenReturn(CommunicationState.DISCONNECTED);
        assertFalse(ChannelActualStateVerification.isActive(object));
        verify(object).getCommunicationState();
    }

    @Test
    public void testIsInactive_false() {
        when(object.getCommunicationState()).thenReturn(CommunicationState.CONNECTED);
        assertFalse(ChannelActualStateVerification.isInactive(object));
        verify(object).getCommunicationState();
    }
}
