package com.ossnms.dcn_manager.bicnet.client.api;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class ObjectUtilsTest {
    
    @Test
    public void testAnyMatch_true() {
        final String test = "void";
        
        final boolean match = ObjectUtils.anyMatch(test, Integer.class, Double.class, String.class);

        assertTrue(match);
    }

    @Test
    public void testAnyMatch_collection_true() {
        final boolean match = ObjectUtils.anyMatch(ImmutableList.of(new NEItem(),
                new EMItem()), INE.class, IEM.class, IMediator.class);

        assertTrue(match);
    }

    @Test
    public void testAnyMatch_collection_false() {
        final boolean match = ObjectUtils.anyMatch(ImmutableList.of(new NEItem(),
                new EMItem()), IMediator.class);

        assertFalse(match);
    }
    
    @Test
    public void testAnyMatch_false() {
        final String test = "void";
        
        final boolean match = ObjectUtils.anyMatch(test, Integer.class, Double.class);

        assertFalse(match);
    }
    
    @Test
    public void testAnyMatchValidation() {        
        assertTrue(ObjectUtils.anyMatch(new NEItem(), INE.class));
        assertTrue(ObjectUtils.anyMatch(new NEItem(), IEM.class, INE.class));
        assertTrue(ObjectUtils.anyMatch(new EMItem(), IEM.class, INE.class));
    }
    
    @Test
    public void testAnyMatchValidationFailed() {        
        assertFalse(ObjectUtils.anyMatch(new MediatorItem(), INE.class));
        assertFalse(ObjectUtils.anyMatch(new MediatorItem(), IEM.class, INE.class));
    }
    
    @Test
    public void testFilterBy() {
        final INE ne = new NEItem();
        final IMediator mediator = new MediatorItem();
        
        final IManagedObject[] objects = {ne, mediator};
        
        assertThat(Iterables.size(ObjectUtils.filterBy(objects, INE.class)), is(1));
        assertThat(Iterables.getFirst(ObjectUtils.filterBy(objects, INE.class), null), is(ne));
        
        assertThat(Iterables.size(ObjectUtils.filterBy(objects, IMediator.class)), is(1));
        assertThat(Iterables.getFirst(ObjectUtils.filterBy(objects, IMediator.class), null), is(mediator));
    }
    
    @Test
    public void testFilterBy_empty() {
        final INE ne = new NEItem();
        final IMediator mediator = new MediatorItem();
        
        final IManagedObject[] objects = {ne, mediator};
        
        assertThat(Iterables.isEmpty(ObjectUtils.filterBy(objects, IEM.class)), is(true));
        assertNull(Iterables.getFirst(ObjectUtils.filterBy(objects, IEM.class), null));
    }

    @Test
    public void testJoin_only_one() throws Exception {
        INE ne = new NEItem();
        ne.setIdName("name");

        String names = ObjectUtils.join("and", ImmutableList.of(ne));

        assertThat("name", is(names));
    }

    @Test
    public void testJoin_many() throws Exception {
        INE ne1 = new NEItem();
        ne1.setIdName("name1");

        INE ne2 = new NEItem();
        ne2.setIdName("name2");

        INE ne3 = new NEItem();
        ne3.setIdName("name3");

        String names = ObjectUtils.join(" and ", ImmutableList.of(ne1, ne2, ne3));

        assertThat("name1 and name2 and name3", is(names));
    }

    @Test
    public void testToString_NES() {

        INEId id1 = new NEIdItem(1);
        INEId id2 = new NEIdItem(2);
        INEId id3 = new NEIdItem(3);

        String value = ObjectUtils.toString(ImmutableList.<IManagedObjectId>of(id1,id2,id3));

        assertThat("IDs[NE=1, NE=2, NE=3]", is(value));
    }

    @Test
    public void testToString_null() {
        String value = ObjectUtils.toString(null);
        assertThat("", is(value));
    }

    @Test
    public void testToString_empty() {
        String value = ObjectUtils.toString(ImmutableList.<IManagedObjectId>of());
        assertThat("IDs[]", is(value));
    }
}