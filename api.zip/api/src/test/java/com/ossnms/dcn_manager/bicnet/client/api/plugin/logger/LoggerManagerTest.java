package com.ossnms.dcn_manager.bicnet.client.api.plugin.logger;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.DefaultPluginClientLogEntry;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class LoggerManagerTest {
    
    private BiCNetPluginSite plugin;
    
    @Before
    public void setup() {
        plugin = mock(BiCNetPluginSite.class);
    }
    
    @Test
    public void testLogInfo() throws BiCNetPluginException {
        final LoggerManager loggerManager = new LoggerManager(plugin);
        
        loggerManager.info("test", "name");
        
        verify(plugin, atLeastOnce()).addClientLogEntry(Mockito.any(DefaultPluginClientLogEntry.class));
    }
    
    @Test
    public void testLogWarn() throws BiCNetPluginException {
        final LoggerManager loggerManager = new LoggerManager(plugin);
        
        loggerManager.warn("test", "name");
        
        verify(plugin, atLeastOnce()).addClientLogEntry(Mockito.any(DefaultPluginClientLogEntry.class));
    }
    
    @Test
    public void testLogError() throws BiCNetPluginException {
        final LoggerManager loggerManager = new LoggerManager(plugin);
        
        loggerManager.error("test", "name");
        
        verify(plugin, atLeastOnce()).addClientLogEntry(Mockito.any(DefaultPluginClientLogEntry.class));
    }
    
    @Test
    public void testOnError() throws BiCNetPluginException {
        final LoggerManager loggerManager = new LoggerManager(plugin);

        loggerManager.info("test", "name");
        
        doThrow(new BiCNetPluginException()).when(plugin).addClientLogEntry(Mockito.any(DefaultPluginClientLogEntry.class));
    }
}
