package com.ossnms.dcn_manager.bicnet.client.api.state;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeActivationState;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NeActualStateVerificationTest {
    private INE ne;

    @Before
    public void setup() {
        ne = mock(INE.class);
    }

    @Test
    public void testUtilityClass()  {
        try {
            final Constructor<NeActualStateVerification> constructor = NeActualStateVerification.class.getDeclaredConstructor();
            assertTrue(Modifier.isPrivate(constructor.getModifiers()));
            constructor.setAccessible(true);
            constructor.newInstance();
        } catch (final Exception e) {
             Assert.fail(e.getMessage());
        } 
    }

    @Test
    public void testIsActive() {
        when(ne.getActualActivationState()).thenReturn(NeActivationState.ACTIVE);
        assertTrue(NeActualStateVerification.isActive(ne));
    }

    @Test
    public void testIsInactive() {
        when(ne.getActualActivationState()).thenReturn(NeActivationState.INACTIVE);
        assertTrue(NeActualStateVerification.isInactive(ne));
    }

    @Test
    public void testIsActivating() {
        when(ne.getActualActivationState()).thenReturn(NeActivationState.ACTIVATING);
        assertTrue(NeActualStateVerification.isActivating(ne));
    }

    @Test
    public void testIsDeactivating() {
        when(ne.getActualActivationState()).thenReturn(NeActivationState.DEACTIVATING);
        assertTrue(NeActualStateVerification.isDeactivating(ne));
    }

    @Test
    public void testIsStartingUp() {
        when(ne.getActualActivationState()).thenReturn(NeActivationState.STARTING_UP);
        assertTrue(NeActualStateVerification.isStartingUp(ne));
    }

    @Test
    public void testIsShuttingDown() {
        when(ne.getActualActivationState()).thenReturn(NeActivationState.SHUTTING_DOWN);
        assertTrue(NeActualStateVerification.isShuttingDown(ne));
    }

    @Test
    public void testIsFailed() {
        when(ne.getActualActivationState()).thenReturn(NeActivationState.FAILED);
        assertTrue(NeActualStateVerification.isFailed(ne));
    }
}
