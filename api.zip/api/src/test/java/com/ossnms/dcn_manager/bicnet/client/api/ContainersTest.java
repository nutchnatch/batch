package com.ossnms.dcn_manager.bicnet.client.api;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import static org.junit.Assert.assertThat;

public class ContainersTest {

    @Test
    public void testGetRootContainerId() {
        assertThat(0, CoreMatchers.is(Containers.ROOT_CONTAINER_ID));
    }
}
