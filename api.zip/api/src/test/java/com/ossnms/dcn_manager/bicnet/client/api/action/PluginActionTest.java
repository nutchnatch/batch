package com.ossnms.dcn_manager.bicnet.client.api.action;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import org.junit.Before;
import org.junit.Test;

import javax.swing.Icon;
import javax.swing.KeyStroke;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

public class PluginActionTest {

    private enum NAMES {menuName, description};
    
    private KeyStroke key;
    private Icon icon;    
    private PluginAction action;

    @Before
    public void setup() {
        key = mock(KeyStroke.class);
        icon = mock(Icon.class); 
        action = new TestActionImpl("id", NAMES.menuName, NAMES.description);
    }

    @Test
    public void testConstructor() {
        action = new TestActionImpl("id", NAMES.menuName, NAMES.description, key, icon);
        
        assertNotNull(action);
    }
    
    @Test
    public void testConstructorMenuRootPath() {
        action = new TestActionImpl("id", NAMES.menuName, NAMES.description, "menuRootPath");
        
        assertNotNull(action);
    }

    private static final class TestActionImpl extends PluginAction {

        public TestActionImpl(final String id, final Enum<?> menuName, final Enum<?> description) {
            super(id, menuName, description);
        }
        
        public TestActionImpl(final String id, final Enum<?> menuName, final Enum<?> description, final KeyStroke keyStroke, final Icon icon) {
            super(id, menuName, description, keyStroke, icon);
        }

        public TestActionImpl(final String id, final Enum<?> menuName, final Enum<?> description, final String menuRootPath) {
            super(id, menuName, description, menuRootPath);
        }

        @Override
        public boolean isPluginActionAllowed(final IManagedObject[] arSelectedObjects) {
            return false;
        }

        @Override
        public void eventPluginActionPerformed(final IManagedObject[] arSelectedObjects) throws BiCNetPluginException {
        }
    }
}
