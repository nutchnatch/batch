package com.ossnms.dcn_manager.bicnet.client.api.chain;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.assertThat;

public class ChainTest {

    private static final String FLOW_1 = "1";
    private static final String FLOW_2 = "2";
        
    @Test
    public void testFlow1() throws ChainProcessException {
        final AtomicInteger integer = new AtomicInteger();
        final Chain<String> chain = new Flow1Impl(integer).setNext(new Flow2Impl(integer));
        
        chain.handleRequest(FLOW_1);
        assertThat(integer.get(), CoreMatchers.is(1));
        
    }
    
    @Test
    public void testFlow2() throws ChainProcessException {
        final AtomicInteger integer = new AtomicInteger();
        final Chain<String> chain = new Flow1Impl(integer).setNext(new Flow2Impl(integer));
        
        chain.handleRequest(FLOW_2);
        assertThat(integer.get(), CoreMatchers.is(2));
        
    }
    
    @Test(expected=ChainProcessException.class)
    public void testFlowError() throws ChainProcessException {
        final AtomicInteger integer = new AtomicInteger();
        final Chain<String> chain = new Flow1Impl(null);
        
        chain.handleRequest(FLOW_1);
        assertThat(integer.get(), CoreMatchers.is(2));
    }
    
    private static final class Flow1Impl extends ChainTemplate<String> {
        private final AtomicInteger execution;
        
        public Flow1Impl(AtomicInteger execution) {
            this.execution = execution;
        }
        
        @Override
        protected ChainStatus process(String element) throws ChainProcessException {
            try {
                if (element.equals(FLOW_1)) {
                    execution.incrementAndGet();
                    return ChainStatus.STOP;
                }
                
                return ChainStatus.CONTINUE;
            } catch (final Exception e) {
                throw new ChainProcessException(e);
            }
        }
        
    }
    
    private static final class Flow2Impl extends ChainTemplate<String> {
        private final AtomicInteger execution;
        
        public Flow2Impl(AtomicInteger execution) {
            this.execution = execution;
        }
        
        @Override
        protected ChainStatus process(String element) {
            if (element.equals(FLOW_2)) {
                execution.incrementAndGet();
                execution.incrementAndGet();
                return ChainStatus.STOP;
            }
            
            return ChainStatus.CONTINUE;
        }
        
    }
}
