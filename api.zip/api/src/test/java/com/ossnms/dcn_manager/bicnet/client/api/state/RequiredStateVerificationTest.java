package com.ossnms.dcn_manager.bicnet.client.api.state;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IDcnObjectPkg;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

public class RequiredStateVerificationTest {

    private IDcnObjectPkg object;
    
    @Test
    public void testUtilityClass()  {
        try {
            final Constructor<RequiredStateVerification> constructor = RequiredStateVerification.class.getDeclaredConstructor();
            assertTrue(Modifier.isPrivate(constructor.getModifiers()));
            constructor.setAccessible(true);
            constructor.newInstance();
        } catch (final Exception e) {
             Assert.fail(e.getMessage());
        } 
    }
    
    @Before
    public void setup() {
        object = Mockito.mock(IDcnObjectPkg.class);
    }
    
    @Test
    public void testIsActive() {
        when(object.getActivation()).thenReturn(EnableSwitch.ENABLED);
        assertTrue(RequiredStateVerification.isEnable(object));
    }

    @Test
    public void testIsInactive() {
        when(object.getActivation()).thenReturn(EnableSwitch.DISABLED);
        assertTrue(RequiredStateVerification.isDisable(object));
    }
    
    @Test
    public void testIsActive_false() {
        when(object.getActivation()).thenReturn(EnableSwitch.DISABLED);
        assertFalse(RequiredStateVerification.isEnable(object));
    }

    @Test
    public void testIsInactive_false() {
        when(object.getActivation()).thenReturn(EnableSwitch.ENABLED);
        assertFalse(RequiredStateVerification.isDisable(object));
    }
}
