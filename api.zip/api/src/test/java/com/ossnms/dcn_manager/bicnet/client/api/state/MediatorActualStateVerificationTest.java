package com.ossnms.dcn_manager.bicnet.client.api.state;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorActivationState;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

public class MediatorActualStateVerificationTest {

    private IMediator object;

    @Before
    public void setup() {
        object = Mockito.mock(IMediator.class);
    }
    
    @Test
    public void testUtilityClass()  {
        try {
            final Constructor<MediatorActualStateVerification> constructor = MediatorActualStateVerification.class.getDeclaredConstructor();
            assertTrue(Modifier.isPrivate(constructor.getModifiers()));
            constructor.setAccessible(true);
            constructor.newInstance();
        } catch (final Exception e) {
             Assert.fail(e.getMessage());
        } 
    }

    @Test
    public void testIsActive() {
        when(object.getActualActivationState()).thenReturn(MediatorActivationState.ACTIVE);
        assertTrue(MediatorActualStateVerification.isActive(object));
    }

    @Test
    public void testIsInactive() {
        when(object.getActualActivationState()).thenReturn(MediatorActivationState.INACTIVE);
        assertTrue(MediatorActualStateVerification.isInactive(object));
    }

    @Test
    public void testIsFailed() {
        when(object.getActualActivationState()).thenReturn(MediatorActivationState.FAILED);
        assertTrue(MediatorActualStateVerification.isFailed(object));
    }

    @Test
    public void testIsActive_false() {
        when(object.getActualActivationState()).thenReturn(MediatorActivationState.FAILED);
        assertFalse(MediatorActualStateVerification.isActive(object));
    }

    @Test
    public void testIsInactive_false() {
        when(object.getActualActivationState()).thenReturn(MediatorActivationState.ACTIVE);
        assertFalse(MediatorActualStateVerification.isInactive(object));
    }
}
