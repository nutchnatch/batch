package com.ossnms.dcn_manager.bicnet.client.api.plugin;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class JobTest {

    @Mock private ISessionContext sessionContext;
    @Mock private BicnetServerFacade bicnetServerFacade;

    private StringBuilder execution;
    private Job<Integer> job;

    @Before public void setUp() throws Exception {
        execution = new StringBuilder();

        job = new Job<Integer>("name", sessionContext, bicnetServerFacade, Arrays.asList(1,2)) {
            @Override protected void execute() throws BiCNetPluginException {
                execution.append("executed");
            }
        };
    }

    @Test public void execute() throws Exception {
        job.execute();
        assertThat(execution.toString(), is("executed"));
    }

    @Test public void run() throws Exception {
        job.execute();
        assertThat(execution.toString(), is("executed"));
    }

    @Test public void getBicnetServerFacade() throws Exception {
        assertThat(job.getBicnetServerFacade(), is(bicnetServerFacade));
    }

    @Test public void getSessionContext() throws Exception {
        assertThat(job.getSessionContext(), is(sessionContext));
    }

    @Test public void getElements() throws Exception {
        assertThat(job.getElements(), containsInAnyOrder(1,2));
    }

    @Test public void getJobName() throws Exception {
        assertThat(job.getJobName(), is("name"));
    }

    @Test public void affectedObjects() throws Exception {
        assertThat(job.affectedObjects(), is("IDs[1, 2]"));
    }
}