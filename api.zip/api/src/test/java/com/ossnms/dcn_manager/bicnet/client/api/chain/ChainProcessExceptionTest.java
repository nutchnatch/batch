package com.ossnms.dcn_manager.bicnet.client.api.chain;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;

public class ChainProcessExceptionTest {

    @Test public void testMessageThrowable() throws Exception {
        final ChainProcessException text = new ChainProcessException(new Exception("text"));
        assertThat(text.getMessage(), containsString("text"));
    }

    @Test public void testMessage() throws Exception {
        final ChainProcessException text = new ChainProcessException("text");
        assertThat(text.getMessage(), containsString("text"));
    }

    @Test public void testMessageWithParams() throws Exception {
        final ChainProcessException text = new ChainProcessException("text {}", "param1");
        assertThat(text.getMessage(), containsString("text param1"));
    }
}