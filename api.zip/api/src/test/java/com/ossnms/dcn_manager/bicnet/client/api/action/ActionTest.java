package com.ossnms.dcn_manager.bicnet.client.api.action;

import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.JfxText;
import org.junit.Before;
import org.junit.Test;

import javax.swing.Icon;
import javax.swing.KeyStroke;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;

public class ActionTest {
    private KeyStroke key;
    private Icon icon;    
    private Action action;
    
    @Before
    public void setup() {
        key = mock(KeyStroke.class);
        icon = mock(Icon.class); 
        action = new TestActionImpl(new JfxText("name"), new JfxText("description"));
    }
    
    @Test
    public void testAddKeyStroke() {
        action.addKeyStroke(key);
        assertThat(key, is(action.getValue(Action.ACCELERATOR_KEY)));
    }
    
    @Test
    public void testAddButtonToolTip() {
        final JfxText text = new JfxText("tool");
        action.addButtonToolTip(text);
        assertThat(text.toString(), is(action.getValue(Action.SHORT_DESCRIPTION)));
    }
    
    @Test
    public void testAddIcon() {
        action.addIcon(icon);
        assertThat(icon, is(action.getValue(Action.SMALL_ICON)));
    }
    
    private static final class TestActionImpl extends Action {
        private static final long serialVersionUID = 1L;

        public TestActionImpl(JfxText name, JfxText description) {
            super(name, description);
        }

        @Override
        public void actionPerformed(JfxAction action) {
        }

        @Override
        public boolean fulfilled(JfxAction action) {
            return false;
        }
        
    }
}
