package com.ossnms.dcn_manager.bicnet.client.api.state;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ActualActivationStateVerificationTest {
    @Test public void isActive() throws Exception {
        final boolean state = ActualActivationStateVerification.isActive(Optional.of(GuiActualActivationState.ACTIVE));
        assertThat(state, is(true));
    }

    @Test public void isSynchronizing() throws Exception {
        final boolean state = ActualActivationStateVerification.isSynchronizing(Optional.of(GuiActualActivationState.SYNCHRONIZING));
        assertThat(state, is(true));
    }

    @Test public void isOutOfSync() throws Exception {
        final boolean state = ActualActivationStateVerification.isOutOfSync(Optional.of(GuiActualActivationState.OUT_OF_SYNCH));
        assertThat(state, is(true));
    }

    @Test public void isInactive() throws Exception {
        final boolean state = ActualActivationStateVerification.isInactive(Optional.of(GuiActualActivationState.INACTIVE));
        assertThat(state, is(true));
    }

    @Test public void isActivating() throws Exception {
        final boolean state = ActualActivationStateVerification.isActivating(Optional.of(GuiActualActivationState.ACTIVATING));
        assertThat(state, is(true));
    }

    @Test public void isDeactivating() throws Exception {
        final boolean state = ActualActivationStateVerification.isDeactivating(Optional.of(GuiActualActivationState.DEACTIVATING));
        assertThat(state, is(true));
    }

    @Test public void isFailed() throws Exception {
        final boolean state = ActualActivationStateVerification.isFailed(Optional.of(GuiActualActivationState.FAILED));
        assertThat(state, is(true));
    }

    @Test public void isUnmanaged() throws Exception {
        final boolean state = ActualActivationStateVerification.isUnmanaged(Optional.of(GuiActualActivationState.NONE));
        assertThat(state, is(true));
    }

    @Test public void isShutingDown() throws Exception {
        final boolean state = ActualActivationStateVerification.isShutingDown(Optional.of(GuiActualActivationState.SHUTTINGDOWN));
        assertThat(state, is(true));
    }

    @Test public void isStartingUp() throws Exception {
        final boolean state = ActualActivationStateVerification.isStartingUp(Optional.of(GuiActualActivationState.STARTINGUP));
        assertThat(state, is(true));
    }

}