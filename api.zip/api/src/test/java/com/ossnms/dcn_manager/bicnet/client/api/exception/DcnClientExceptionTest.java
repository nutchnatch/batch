package com.ossnms.dcn_manager.bicnet.client.api.exception;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class DcnClientExceptionTest {

    @Test public void testConstructor() throws Exception {
        assertThat(new DcnClientException(), notNullValue());
    }

    @Test public void testMessage() throws Exception {
        final DcnClientException exception = new DcnClientException("text", new Exception());
        assertThat(exception.getMessage(), containsString("text"));
    }

    @Test public void testMessageSuppression() throws Exception {
        final DcnClientException exception = new DcnClientException("text", new Exception(), true, true);
        assertThat(exception.getMessage(), containsString("text"));
    }

    @Test public void testMessageFormatted() throws Exception {
        final DcnClientException exception = new DcnClientException("text {}", new Exception(), "param1");
        assertThat(exception.getMessage(), containsString("text param1"));
    }
}