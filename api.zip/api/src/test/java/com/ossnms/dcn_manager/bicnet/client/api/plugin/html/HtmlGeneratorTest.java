package com.ossnms.dcn_manager.bicnet.client.api.plugin.html;

import com.ossnms.dcn_manager.bicnet.client.api.html.HtmlGenerator;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import static org.junit.Assert.assertThat;

public class HtmlGeneratorTest {

    @Test
    public void testEmptyBody() {
        final String html = HtmlGenerator.start().toHtml();
        
        assertThat(html, CoreMatchers.is("<html></html>"));
    }
    
    @Test
    public void testBoldText() {
        final String html = HtmlGenerator.start().boldText("text").toHtml();
        
        assertThat(html, CoreMatchers.is("<html><b>text</b></html>"));
    }
    
    @Test
    public void testText() {
        final String html = HtmlGenerator.start().simpleHtmlText("text").toHtml();
        
        assertThat(html, CoreMatchers.is("<html>text</html>"));
    }
    
    @Test
    public void testLineBreak() {
        final String html = HtmlGenerator.start().lineBreak().toHtml();
        
        assertThat(html, CoreMatchers.is("<html><br /></html>"));
    }
    
    @Test
    public void testLineBreak_with_repetitions() {
        final String html = HtmlGenerator.start().lineBreak(3).toHtml();
        
        assertThat(html, CoreMatchers.is("<html><br /><br /><br /></html>"));
    }
    
    @Test
    public void testSpaces_with_repetitions() {
        final String html = HtmlGenerator.start().spaces(3).toHtml();
        
        assertThat(html, CoreMatchers.is("<html> &nbsp;  &nbsp;  &nbsp; </html>"));
    }
    
    @Test
    public void testSpace() {
        final String html = HtmlGenerator.start().space().toHtml();
        
        assertThat(html, CoreMatchers.is("<html> &nbsp; </html>"));
    }
    
    @Test
    public void testNewLineBold() {
        final String html = HtmlGenerator.start().newLineBold("text").toHtml();
        
        assertThat(html, CoreMatchers.is("<html><br /><b>text</b></html>"));
    }

    @Test
    public void testSimpleTest() {
        final String html = HtmlGenerator.start().simpleHtmlText(1L).toHtml();

        assertThat(html, CoreMatchers.is("<html>1</html>"));
    }
    
    @Test
    public void testToString() {
        final String toHtml = HtmlGenerator.start().toHtml();
        final String toString = HtmlGenerator.start().toString();
        
        assertThat(toHtml, CoreMatchers.is(toString));
    }
}
