package com.ossnms.dcn_manager.bicnet.client.api.view;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentTypes;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.AP_LAYER;
import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.ASON_MANAGER;
import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.CROSS_NE_MANAGER;
import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.GCT_MANAGER;
import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.assertThat;

public class UsedByTest {

    @Test public void usedBy() throws Exception {
        BiCNetComponentTypes types = new BiCNetComponentTypes();
        types.addAll(asList(ASON_MANAGER, CROSS_NE_MANAGER, GCT_MANAGER));

        INE ne = new NEItem();
        ne.setUsedBy(types);

        BiCNetComponentTypes types2 = new BiCNetComponentTypes();
        types2.addAll(asList(ASON_MANAGER, AP_LAYER, GCT_MANAGER));

        INE ne2 = new NEItem();
        ne2.setUsedBy(types2);

        final Optional<String> labels = UsedBy.of(asList(ne, ne2));

        assertThat(labels.isPresent(), is(true));
        labels.ifPresent( label -> {
            assertThat(label, containsString(ASON_MANAGER.guiLabel()));
            assertThat(label, containsString(CROSS_NE_MANAGER.guiLabel()));
            assertThat(label, containsString(GCT_MANAGER.guiLabel()));
            assertThat(label, containsString(AP_LAYER.guiLabel()));
        });
    }

    @Test public void usedBy_empty() throws Exception {
        BiCNetComponentTypes types = new BiCNetComponentTypes();
        types.addAll(Collections.emptyList());

        INE ne = new NEItem();
        ne.setUsedBy(types);

        final Optional<String> labels = UsedBy.of(singletonList(ne));

        assertThat(labels.isPresent(), is(false));
    }

    @Test public void usedBy_null() throws Exception {
        BiCNetComponentTypes types = new BiCNetComponentTypes();
        types.addAll(Collections.emptyList());

        INE ne = new NEItem();
        ne.setUsedBy(types);

        final Optional<String> labels = UsedBy.of(singletonList(ne));

        assertThat(labels.isPresent(), is(false));
    }
}