package com.ossnms.dcn_manager.bicnet.client.api.properties;

/**
 * Contains constants with the names of "well known" Generic properties.
 */
public final class WellKnownMediatorPropertyNames {

    public static final String ID_NAME = "BCB-Attribute/Mediator/idName";
    public static final String NODE_MANAGER_SELECTED = "NODE_MANAGER_SELECTED";

    private WellKnownMediatorPropertyNames() {
    }
}
