package com.ossnms.dcn_manager.bicnet.client.api.chain;

/**
 * Chain status to help decision to CONTINUE or STOP the chain process. 
 */
public enum ChainStatus {
    STOP, CONTINUE
}
