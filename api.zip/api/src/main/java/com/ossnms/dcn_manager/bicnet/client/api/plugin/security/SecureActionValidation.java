package com.ossnms.dcn_manager.bicnet.client.api.plugin.security;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEMarkableIdItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkableId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkableId;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static java.util.Collections.emptyMap;
import static java.util.Objects.requireNonNull;
import static java.util.stream.Collectors.toMap;
import static org.apache.commons.lang3.ArrayUtils.getLength;
import static org.apache.commons.lang3.ArrayUtils.isEmpty;
import static org.apache.commons.lang3.ArrayUtils.isSameLength;

/**
 * Checks if the current Client session has permissions to use the selected #SecuredAction.
 */
public class SecureActionValidation {
    private static final Predicate<IManagedObjectId> IN_SECURITY_DOMAIN = INEId.class::isInstance;

    private final DcnPluginHelper helper;
    private final Map<INEId, Boolean> visibilityCache;

    private static volatile SecureActionValidation instance = null;

    public static synchronized SecureActionValidation getInstance(@Nonnull final DcnPluginHelper helper) {
        if (instance != null) {
            return instance;
        }
        instance = new SecureActionValidation(helper);
        return instance;
    }

    protected SecureActionValidation(@Nonnull final DcnPluginHelper helper) {
        this.helper = helper;
        visibilityCache = new ConcurrentHashMap<>();
    }

    /**
     * Checks if the current user has permission to use the SecureAction.
     *
     * @param action
     * @return True if the current session has permissions for the SecureAction
     */
    public boolean checkPermission(@Nonnull final SecureAction action) {
        final Optional<ISecureClientSession> clientSession = helper.getClientSession();
        return clientSession.isPresent() && clientSession.get().checkOperationPermission(action.getIdentifier());
    }

    /**
     * Checks if Operator has permission to use #SecureAction for all #objectsToCheck
     *
     * @param action
     * @param objectsToCheck
     * @return True if operator has permission to uses the SecureAction for all objectsToCheck
     */
    public boolean checkPermission(@Nonnull final SecureAction action, @Nonnull final IManagedObjectId... objectsToCheck) {
        requireNonNull(objectsToCheck, "Ids cannot be null");

        IManagedObjectId[] inDomain = filter(objectsToCheck, IN_SECURITY_DOMAIN);
        boolean forDomainObjects = inDomain.length == 0 || checkDomainPermission(action, inDomain);

        IManagedObjectId[] nonDomain = filter(objectsToCheck, IN_SECURITY_DOMAIN.negate());
        boolean forNonDomainObjects = nonDomain.length == 0 || checkPermission(action);

        return forDomainObjects && forNonDomainObjects;
    }

    /**
     * Checks if Operator has permission to see NEs
     *
     * @param neIds Use a single item to check the visibility of a particular NE.
     * @return True if all NEs in array are visible.
     */
    private boolean checkVisibilityOnUSM(@Nonnull final INEId... neIds) {
        requireNonNull(neIds, "Id cannot be null");

        if (isEmpty(neIds)) {
            return true;
        }

        final IManagedObjectMarkableId[] criteria = Stream.of(neIds).map(neId -> {
            final INEMarkableId item = new NEMarkableIdItem(neId);
            item.markId(true);
            return item;
        }).toArray(IManagedObjectMarkableId[]::new);

        final Optional<ISecureClientSession> clientSession = helper.getClientSession();

        if (clientSession.isPresent()) {
            IManagedObjectId[] visibleObjects = clientSession.get().filterVisibleObjects(criteria);
            return getLength(visibleObjects) == neIds.length;
        }

        return false;
    }
    
    /**
     * Checks if Operator has permission to see NE
     *
     * @return True if is visible.
     */
    public boolean checkVisibility(INEId neId) {
        return visibilityCache.computeIfAbsent(neId, this::checkVisibilityOnUSM);
    }

    /**
     * Checks if Operator has permission to see NEs
     *
     * @return False if at least one NE is invisible
     */
    public boolean checkVisibility(Collection<? extends INEId> nes) {
        return nes.isEmpty() || nes.stream().allMatch(this::checkVisibility);
    }

    public void reloadVisibilityCache() {
        visibilityCache.clear();
        helper.getClientSession()
                .map(this::fetchVisibleNEs)
                .ifPresent(visibilityCache::putAll);
    }

    private Map<INEId, Boolean> fetchVisibleNEs(ISecureClientSession session) {
        IManagedObjectId[] visibleObjects = session.filterVisibleObjects(new NEMarkableIdItem(new NEIdItem()));
        if (visibleObjects == null) {
            return emptyMap();
        }
        return Stream.of(visibleObjects)
                .filter(INEId.class::isInstance).map(INEId.class::cast)
                .collect(toMap(id -> id, id -> true));
    }

    private IManagedObjectId[] filter(IManagedObjectId[] objects, Predicate<IManagedObjectId> predicate) {
        return Stream.of(objects).filter(predicate).toArray(IManagedObjectId[]::new);
    }

    /**
     * Checks whether all objects has permissions in security domain
     */
    private boolean checkDomainPermission(@Nonnull SecureAction action, @Nonnull IManagedObjectId[] objectsToCheck) {
        final Optional<ISecureClientSession> clientSession = helper.getClientSession();

        if (clientSession.isPresent()) {
            final IManagedObjectId[] permittedObjects = clientSession.get()
                    .checkOperationPermission(action.getIdentifier(), objectsToCheck);

            return isSameLength(permittedObjects, objectsToCheck);
        }

        return false;
    }

}
