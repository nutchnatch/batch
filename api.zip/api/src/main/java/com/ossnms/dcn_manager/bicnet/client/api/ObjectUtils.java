package com.ossnms.dcn_manager.bicnet.client.api;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.FluentIterable;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INamedObjectPkg;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Stream;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Utility class to handle objects.
 */
public final class ObjectUtils {

    private ObjectUtils() {
    }

    /**
     * Verifies if the input type class is equals for the any class types in types argument.
     * 
     * @param input class type to be verified.
     * @param types classes that types must match
     * @return true if the input match with any class in types array.
     */
    public static <E> boolean anyMatch(@Nonnull final E input, @Nonnull final Class<?>... types) {
        checkNotNull(input);
        checkNotNull(types);

        return Stream.of(types)
                .anyMatch(c -> c.isInstance(input));
    }

    public static <E> boolean anyMatch(@Nonnull final Collection<E> input, @Nonnull final Class<?>... types) {
        checkNotNull(input);
        checkNotNull(types);

        return input.stream()
                .anyMatch(object -> anyMatch(object,types));
    }

    /**
     * Filter a collection of manage objects for a specific ManageObject sub-type. 
     * 
     * @param elements Elements filtered
     * @param klazz Class type to be filtered
     * @return
     */
    public static <E extends IManagedObject> Iterable<E> filterBy(@Nonnull final IManagedObject[] elements, @Nonnull final Class<E> klazz) {
        checkNotNull(elements);
        checkNotNull(klazz);        
        return FluentIterable.from(Arrays.asList(elements)).filter(klazz);
    }

    public static <E extends INamedObjectPkg> String join(@Nonnull final String token, @Nonnull final Iterable<E> elements) {
        return Joiner.on(token).skipNulls()
                .join(FluentIterable.from(elements).transform(new Function<E, String>() {
                    @Override public String apply(@Nonnull E input) {
                        return input.getIdName();
                    }
                }));
    }

    public static <E extends IManagedObjectId> String toString(final Iterable<E> elements) {
        if (elements == null) {
            return StringUtils.EMPTY;
        }

        String values = Joiner.on(", ").skipNulls()
                .join(FluentIterable.from(elements).transform(new Function<E, String>() {
                    @Override public String apply(@Nonnull E input) {
                        return input.key();
                    }
                }));

        return new StringBuilder().append("IDs[").append(values).append("]").toString();
    }
}
