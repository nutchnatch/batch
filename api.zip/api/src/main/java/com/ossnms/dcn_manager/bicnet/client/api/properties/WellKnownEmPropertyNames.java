package com.ossnms.dcn_manager.bicnet.client.api.properties;


/**
 * Contains constants with the names of "well known" Channel Type properties, i.e.,
 * properties that are required to be present in Channel Type XML files.
 */
public final class WellKnownEmPropertyNames {

    public static final String ID_NAME = "BCB-Attribute/EM/idName";

    private WellKnownEmPropertyNames() {
    }
}
