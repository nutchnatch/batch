package com.ossnms.dcn_manager.bicnet.client.api.html;

import javax.annotation.Nonnegative;

import static org.apache.commons.lang3.StringUtils.defaultString;
import static org.apache.commons.lang3.StringUtils.repeat;

public final class HtmlGenerator {

    private static final int ONLY_ONCE = 1;
    private final StringBuilder html = new StringBuilder();
    
    private HtmlGenerator() {
        html.append("<html>");
    }
    
    /**
     * Starts the Generator.
     * @return
     */
    public static HtmlGenerator start() {
        return new HtmlGenerator();
    }
    
    /**
     * Add a bold text.
     * @param text
     * @return
     */
    public HtmlGenerator boldText(String text) {
        html.append("<b>").append(defaultString(text)).append("</b>");
        return this;
    }
    
    /**
     * Add a new line with a bold text. 
     * @param text
     * @return
     */
    public HtmlGenerator newLineBold(String text) {
        html.append("<br />");
        boldText(defaultString(text));
        return this;
    }
    
    /**
     * Add a simple text.
     * @param text
     * @return
     */
    public HtmlGenerator simpleHtmlText(String text) {
        html.append(defaultString(text));
        return this;
    }

    /**
     * Add a simple text.
     * @param intValue
     * @return
     */
    public HtmlGenerator simpleHtmlText(long intValue) {
        html.append(defaultString(String.valueOf(intValue)));
        return this;
    }
    
    /**
     * Add a line break.
     * @return
     */
    public HtmlGenerator lineBreak() {
        lineBreak(ONLY_ONCE);
        return this;
    }
    
    /**
     * Repeat a number of line break that was passed thought the argument.
     * 
     * @param repeat
     * @return
     */
    public HtmlGenerator lineBreak(@Nonnegative int repeat) {
        html.append(repeat("<br />", repeat));
        return this;
    }
    
    /**
     * Add a space
     * @return
     */
    public HtmlGenerator space() {
        spaces(ONLY_ONCE);
        return this;
    }
    
    /**
     * Repeat a number of spaces that was passed thought the argument.
     * 
     * @param repeat
     * @return
     */
    public HtmlGenerator spaces(@Nonnegative int repeat) {
        html.append(repeat(" &nbsp; ", repeat));
        return this;
    }
    
    /**
     * @return The string that contains the generated HTML code.
     */
    public String toHtml() {
        html.append("</html>");
        return html.toString();
    }
    
    @Override
    public String toString() {
        return toHtml();
    }
}
