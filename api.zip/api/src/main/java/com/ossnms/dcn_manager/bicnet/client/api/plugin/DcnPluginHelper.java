package com.ossnms.dcn_manager.bicnet.client.api.plugin;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;

import java.util.Optional;

/**
 * Helper to access the BicNet Plug-in public environment.
 */
public interface DcnPluginHelper {

    /**
     * @return The DCN Plug-in Name.
     */
    String getPluginId();

    /**
     * Set plug-in site
     *
     * @param site
     */
    void setCfPluginSite(BiCNetPluginSite site);

    /**
     * @return The current session context.
     */
    ISessionContext getSessionContext();

    /**
     * Sets the DCN Plug-in name.
     *
     * @param pluginId
     */
    void setPluginId(String pluginId);

    /**
     * @return The Plug-in Object that access the BiCNet Plug-in Environment.
     */
    BiCNetPluginSite getCfPluginSite();

    /**
     * Called when the BiCNet Plug-in Client GUI is open.
     *
     * @param logonContext
     */
    void initialize(ISessionContext logonContext);

    /**
     * Called when the BiCNet Plug-in Client GUI is destroyed.
     */
    void uninitialize();

    /**
     * @return The BiCNet Security Plug-in interface.
     */
    IPluginSecurityProvider getSecurityProvider() throws SecurityException;

    /**
     * @return The current client session
     * @throws SecurityException
     */
    Optional<ISecureClientSession> getClientSession() throws SecurityException;

    /**
     * Queue a job to be executed by BiCNet framework job executor.
     *
     * @param job
     * @param <ELEMENT>
     * @see com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper#queueJob(String, String, com.ossnms.bicnet.bcb.plugin.BiCNetPluginRunnable)
     */
    <ELEMENT> void queueJob(Job<ELEMENT> job) throws BiCNetPluginException;
}