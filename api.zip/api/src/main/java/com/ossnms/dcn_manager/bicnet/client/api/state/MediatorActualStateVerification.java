package com.ossnms.dcn_manager.bicnet.client.api.state;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorActivationState;

import javax.annotation.Nonnull;

public final class MediatorActualStateVerification {

    private MediatorActualStateVerification() {
    }
        
    public static boolean isActive(IMediator mediator) {
        return MediatorActivationState.ACTIVE == mediator.getActualActivationState();
    }

    public static boolean isInactive(@Nonnull final IMediator mediator) {
        return MediatorActivationState.INACTIVE == mediator.getActualActivationState();
    }

    public static boolean isFailed(@Nonnull final IMediator mediator) {
        return MediatorActivationState.FAILED == mediator.getActualActivationState();
    }
}
