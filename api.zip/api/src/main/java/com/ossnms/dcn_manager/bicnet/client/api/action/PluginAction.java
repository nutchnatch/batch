package com.ossnms.dcn_manager.bicnet.client.api.action;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionListener;
import com.ossnms.bicnet.bcb.plugin.DefaultPluginAction;

import javax.annotation.Nonnull;
import javax.swing.Icon;
import javax.swing.KeyStroke;

/**
 * Abstraction for BiCNet Plug-in action to be called in the BicNet plug-in context.
 * 
 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPlugin#getObjectTypeActions(com.ossnms.bicnet.bcb.model.ManagedObjectType, com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionType)
 */
public abstract class PluginAction extends DefaultPluginAction implements BiCNetPluginActionListener {

    public PluginAction(@Nonnull final String id, @Nonnull final Enum<?> menuName, @Nonnull final Enum<?> description) {
        this.setMenuID(id);

        this.setMenuName(menuName.toString());
        this.setToolName(menuName.toString());

        this.setShortDescription(description.toString());
        this.setLongDescription(description.toString());

        this.setActionListener(this);
    }
    
    public PluginAction(@Nonnull final String id, @Nonnull final Enum<?> menuName, @Nonnull final Enum<?> description, @Nonnull final KeyStroke keyStroke, final Icon icon) {
        this(id, menuName, description);
        this.setMenuAccelerator(keyStroke);
        this.setToolIcon(icon);
    }
    
    public PluginAction(@Nonnull final String id, @Nonnull final Enum<?> menuName, @Nonnull final Enum<?> description, @Nonnull final String menuRootPath) {
        this(id, menuName, description);
        this.setMenuPath(new String[] { menuRootPath, menuName.toString() });
    }
}
