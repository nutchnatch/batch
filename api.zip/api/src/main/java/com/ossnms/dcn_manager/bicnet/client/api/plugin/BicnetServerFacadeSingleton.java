package com.ossnms.dcn_manager.bicnet.client.api.plugin;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.util.UnexpectedException;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ChannelService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ConfigurationService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ContainerService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.DomainService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportCoreService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportCtService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportExportService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportLegacyService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.MediatorService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.NeService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.SystemContainerService;
import com.ossnms.dcn_manager.bicnet.connector.common.servicelocator.ServiceLocator;

/**
 * Uses the Service Locator to access the BiCNet Server Facades.
 */
public final class BicnetServerFacadeSingleton implements BicnetServerFacade {

    private static final BicnetServerFacade INSTANCE = new BicnetServerFacadeSingleton();

    private BicnetServerFacadeSingleton() {
    }

    public static BicnetServerFacade getInstance() {
        return INSTANCE;
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade#getDcnPublicServices()
     */
    @Override
    public IEMObjectMgrFacade getDcnPublicServices() throws BcbException {
        try {
            return ServiceLocator.getInstance().getPublicService(BiCNetComponentType.DCN_MANAGER);
        } catch (final UnexpectedException e) {
            throw new BcbException(e);
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade#getNeService()
     */
    @Override
    public NeService getNeService() throws BcbException {
        try {
            return ServiceLocator.getInstance().getNeService();
        } catch (final UnexpectedException e) {
            throw new BcbException(e);
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade#getChannelService()
     */
    @Override
    public ChannelService getChannelService() throws BcbException {
        try {
            return ServiceLocator.getInstance().getChannelService();
        } catch (final UnexpectedException e) {
            throw new BcbException(e);
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade#getMediatorService()
     */
    @Override
    public MediatorService getMediatorService() throws BcbException {
        try {
            return ServiceLocator.getInstance().getMediatorService();
        } catch (final UnexpectedException e) {
            throw new BcbException(e);
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade#getDomainService()
     */
    @Override
    public DomainService getDomainService() throws BcbException {
        try {
            return ServiceLocator.getInstance().getDomainService();
        } catch (final UnexpectedException e) {
            throw new BcbException(e);
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade#getConfigurationService()
     */
    @Override
    public ConfigurationService getConfigurationService() throws BcbException {
        try {
            return ServiceLocator.getInstance().getConfigurationService();
        } catch (final UnexpectedException e) {
            throw new BcbException(e);
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade#getContainerService()
     */
    @Override
    public ContainerService getContainerService() throws BcbException {
        try {
            return ServiceLocator.getInstance().getContainerService();
        } catch (final UnexpectedException e) {
            throw new BcbException(e);
        }
    }

    /**
     * @return The System Container services
     * @throws BcbException
     */
    @Override public SystemContainerService getSystemContainerService() throws BcbException {
        try {
            return ServiceLocator.getInstance().getSystemContainerService();
        } catch (final UnexpectedException e) {
            throw new BcbException(e);
        }
    }

    @Override public ImportExportService getImportExportService() {
        return ServiceLocator.getInstance().getImportExportService();
    }

    @Override public ImportLegacyService getImportLegacyService() {
        return ServiceLocator.getInstance().getImportLegacyService();
    }
    @Override public ImportCtService getImportCtService() {
        return ServiceLocator.getInstance().getImportCtService();
    }
    @Override public ImportCoreService getImportCoreService() {
        return ServiceLocator.getInstance().getImportCoreService();
    }
}
