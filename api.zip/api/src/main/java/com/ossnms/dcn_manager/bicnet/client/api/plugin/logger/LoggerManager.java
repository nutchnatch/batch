package com.ossnms.dcn_manager.bicnet.client.api.plugin.logger;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientLogSeverity;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.DefaultPluginClientLogEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

/**
 * Manager for the client log (BiCNet Plug-in).
 */
public class LoggerManager {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggerManager.class);

    private final BiCNetPluginSite plugin;

    public LoggerManager(@Nonnull final BiCNetPluginSite plugin) {
        super();
        this.plugin = plugin;
    }

    /**
     * Message for severity INFO.
     * 
     * @param description
     * @param objectName 
     */
    public void info(@Nonnull final String description, @Nonnull final String objectName) {
        buildLogEntry(BiCNetPluginClientLogSeverity.INFORMATION, description, objectName);
    }
    
    /**
     * Message for severity ERROR.
     * 
     * @param description
     * @param objectName 
     */
    public void error(@Nonnull final String description, @Nonnull final String objectName) {
        buildLogEntry(BiCNetPluginClientLogSeverity.ERROR, description, objectName);
    }
    
    /**
     * Message for severity WARN.
     * 
     * @param description
     * @param objectName 
     */
    public void warn(@Nonnull final String description, @Nonnull final String objectName) {
        buildLogEntry(BiCNetPluginClientLogSeverity.WARNING, description, objectName);
    }

    /*
     * Adds an entry to the client log. The client log contains entries only 
     * interesting for this single client. It is not stored persistently on the 
     * server.
     */
    private void buildLogEntry(@Nonnull final BiCNetPluginClientLogSeverity severity,  @Nonnull final String description, @Nonnull final String objectName) {
        try {
            plugin.addClientLogEntry(new DefaultPluginClientLogEntry(severity, description, objectName));
        } catch (final BiCNetPluginException e) {
            LOGGER.error("Error on buildLogEntry.", e);
        }
    }
}
