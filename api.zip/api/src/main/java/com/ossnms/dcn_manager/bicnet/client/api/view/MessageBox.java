package com.ossnms.dcn_manager.bicnet.client.api.view;

import com.ossnms.tools.jfx.JfxOptionPane;

import javax.annotation.Nonnull;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.awt.Component;
import java.io.Serializable;

import static org.apache.commons.lang3.StringUtils.defaultString;

/**
 * Shows a GUI Box with the selected message type.
 */
public class MessageBox implements Serializable{

    private static final long serialVersionUID = 8598471636638814180L;

    public enum OPTION {YES, NO}

    private Component component;

    public MessageBox() {
    }

    public MessageBox(@Nonnull final Component component) {
        this.component = component;
    }

    public MessageBox setComponent(Component component) {
        this.component = component;
        return this;
    }

    public OPTION warnConfirmationBox(@Nonnull final Enum<?> title, @Nonnull final String confirmationMessage) {
        int option = JfxOptionPane.showMessageBox(component, title.toString(), confirmationMessage,
                JfxOptionPane.YES_NO_OPTION, 
                JOptionPane.WARNING_MESSAGE,
                null, null, UIManager.getString("OptionPane.noButtonText"));

        return option == JfxOptionPane.YES_OPTION ? OPTION.YES : OPTION.NO;
    }

    public void warnMessage(@Nonnull final Enum<?> message) {
        message(message.toString(), JfxOptionPane.WARNING_MESSAGE);
    }
    
    public void errorMessage(@Nonnull final Enum<?> message) {
        message(message.toString(), JfxOptionPane.ERROR_MESSAGE);
    }
    
    public void errorMessage(@Nonnull final String message) {
        message(message, JfxOptionPane.ERROR_MESSAGE);
    }
    
    public void errorMessage(@Nonnull final Throwable throwable) {
        message(getMessageFromRootCause(throwable), JfxOptionPane.ERROR_MESSAGE);
    }
    
    private void message(@Nonnull final String message, final int type) {
        JfxOptionPane.showMessageBox(component, message, JfxOptionPane.OPTION_TYPE_OK, type);
    }
    
    protected String getMessageFromRootCause(@Nonnull final Throwable throwable) {
        final String message = defaultString(getRootCause(throwable).getMessage());
        return message.contains(":") ? message.substring(message.indexOf(':') + 1, message.length()) : message;
    }
    
    private Throwable getRootCause(final Throwable throwable) {
        if (throwable.getCause() != null) {
            return getRootCause(throwable.getCause());
        }

        return throwable;
    }
}
