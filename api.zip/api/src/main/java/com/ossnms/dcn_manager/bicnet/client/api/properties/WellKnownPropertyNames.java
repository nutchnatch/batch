package com.ossnms.dcn_manager.bicnet.client.api.properties;

/**
 * Contains constants with the names of "well known" NE properties.
 */
public final class WellKnownPropertyNames {

    public static final String ACTIVE = "ACTIVE";

    private WellKnownPropertyNames() {
    }
}
