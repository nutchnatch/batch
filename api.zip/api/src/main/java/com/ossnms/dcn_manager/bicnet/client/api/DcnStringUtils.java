package com.ossnms.dcn_manager.bicnet.client.api;

import com.ossnms.tools.jfx.JfxTextLineOfNames;

import java.util.Collection;

/**
 * Utility class to handle objects.
 */
public final class DcnStringUtils {

    private static final int MAX_LENGTH = 80;

    private DcnStringUtils() {
    }
    
    /**
     * Format a list of String to be show on GUI.
     * 
     * Example for collection{name1,name2,name3}:
     * 
     * <code> name1, name2 and name3 </code>
     * 
     * @param names
     * @return
     */
    public static String formatListOfNames(final Collection<String> names) {
        
        final JfxTextLineOfNames formatter = new JfxTextLineOfNames(MAX_LENGTH, names.size());
        int count = 0;
        
        for (final String name : names) {
            formatter.addName(name, count++);            
        }
        
        return formatter.getTextLine();
    }
}
