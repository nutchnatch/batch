package com.ossnms.dcn_manager.bicnet.client.api.transform;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.apache.commons.lang3.ArrayUtils.isNotEmpty;

public final class Transform {

    private Transform() {
    }

    public static Collection<Integer> getNeIds(@Nonnull final IAS domain) {
        if(isNotEmpty(domain.getNeList())) {
            return Stream.of(domain.getNeList()).map(INEId::getId).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }
}
