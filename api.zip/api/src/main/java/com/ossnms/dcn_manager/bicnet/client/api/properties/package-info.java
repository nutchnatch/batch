/**
 * Contains the well known PropertyPage values id. 
 */
package com.ossnms.dcn_manager.bicnet.client.api.properties;