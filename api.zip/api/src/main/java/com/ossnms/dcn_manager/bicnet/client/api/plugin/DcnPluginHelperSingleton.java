package com.ossnms.dcn_manager.bicnet.client.api.plugin;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Helper to access the BicNet Plug-in public environment.
 */
public final class DcnPluginHelperSingleton extends FrameworkPluginHelper implements DcnPluginHelper {
    private static final DcnPluginHelperSingleton INSTANCE = new DcnPluginHelperSingleton();

    private String pluginId;

    private DcnPluginHelperSingleton() {
        super(null);
    }

    /**
     * @return The singleton instance.
     */
    @Nonnull
    public static DcnPluginHelperSingleton getInstance() {
        return INSTANCE;
    }

    @Override
    public String getPluginId() {
        return pluginId;
    }

    @Override
    public void setPluginId(@Nonnull final String pluginId) {
        this.pluginId = pluginId;
    }

    @Override
    public IPluginSecurityProvider getSecurityProvider() throws SecurityException {
        try {
            return getCfPluginSite() == null ? null : getCfPluginSite().getSecurityProvider();
        } catch (final BiCNetPluginException e) {
            throw new SecurityException(e);
        }
    }

    @Override
    public ISessionContext getSessionContext() {
        return getLogonContext();
    }

    @Override
    public Optional<ISecureClientSession> getClientSession() throws SecurityException {
        try {
            IPluginSecurityProvider provider = getSecurityProvider();
            ISecureClientSession session = provider == null ? null : provider.getClientSession(getSessionContext());
            return Optional.ofNullable(session);
        } catch (final BiCNetPluginException e) {
            throw new SecurityException(e);
        }
    }

    @Override
    public <ELEMENT> void queueJob(Job<ELEMENT> job) throws BiCNetPluginException {
        getCfPluginSite().queueJob(job.getJobName(), job.affectedObjects(), job);
    }
}