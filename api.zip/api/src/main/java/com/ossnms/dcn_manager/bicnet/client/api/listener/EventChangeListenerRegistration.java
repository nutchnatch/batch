package com.ossnms.dcn_manager.bicnet.client.api.listener;


/**
 * Abstraction for change listeners registration. 
 */
public interface EventChangeListenerRegistration<ELEMENT> {

    /**
     * Add a change listener for INE objects.
     * 
     * @param listener
     */
    void addChangeListener(EventChangeListener<ELEMENT> listener);

    /**
     * Remove a change listener.
     * 
     * @param listener
     */
    void removeChangeListener(EventChangeListener<ELEMENT> listener);
}
