package com.ossnms.dcn_manager.bicnet.client.api.action;

import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.JfxActionCondition;
import com.ossnms.tools.jfx.JfxActionPerformed;
import com.ossnms.tools.jfx.JfxText;

import javax.annotation.Nonnull;
import javax.swing.Icon;
import javax.swing.KeyStroke;

/**
 * Abstraction of #JfxAction to help the creation of the internal actions. 
 */
public abstract class Action extends JfxAction implements JfxActionPerformed, JfxActionCondition {

    private static final long serialVersionUID = 5506941707320370158L;

    public Action(@Nonnull final JfxText name, @Nonnull final JfxText description) {
        super(null, name, name, null, description, null, null, null, null);

        this.setIfConditionHandler(this);
        this.setIfPerformedHandler(this);
    }

    /**
     * Adds Key stroke
     * 
     * @param keyStroke
     * @return
     */
    public Action addKeyStroke(@Nonnull final KeyStroke keyStroke) {
        putValue(ACCELERATOR_KEY, keyStroke);
        return this;
    }
    
    /**
     * Adds the button for tool tips
     * 
     * @param toolTip
     * @return
     */
    public Action addButtonToolTip(@Nonnull final JfxText toolTip) {
        putValue(SHORT_DESCRIPTION, toolTip.toString());
        return this;
    }
    

    /**
     * Adds a icon
     * 
     * @param icon
     * @return
     */
    public Action addIcon(@Nonnull final Icon icon) {
        setMenuIcon(icon);
        putValue(SMALL_ICON, icon);
        return this;
    }
}
