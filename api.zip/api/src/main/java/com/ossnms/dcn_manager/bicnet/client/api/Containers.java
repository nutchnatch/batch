package com.ossnms.dcn_manager.bicnet.client.api;

/**
 * Helps for Containers. 
 */
public final class Containers {
    /* By convention the default ROOT_CONTAINER_ID is 0 */
    public static final int ROOT_CONTAINER_ID = 0;

    /* By convention a System Container ID = 0, is undefined */
    public static final int UNDEFINED = 0;

    public static final String TYPE_NE_CONTAINER = "NE Container";
    public static final String TYPE_SYSTEM_CONTAINER = "System Container";

    private Containers() {
    }    
}
