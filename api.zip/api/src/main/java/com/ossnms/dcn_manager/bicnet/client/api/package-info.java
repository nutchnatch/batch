/**
 * Contains the API definition for the DCN Client.
 */
package com.ossnms.dcn_manager.bicnet.client.api;