package com.ossnms.dcn_manager.bicnet.client.api.properties;

public final class WellKnownContainerPropertyNames {
    
    public static final String ID_NAME = "BCB-Attribute/Container/idName";
    public static final String DESCRIPTION = "Description";
    public static final String USER_TEXT = "Subtitle";

    private WellKnownContainerPropertyNames() {
    }
}