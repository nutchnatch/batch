package com.ossnms.dcn_manager.bicnet.client.api.chain;

import javax.annotation.Nonnull;

/**
 *  Chain of responsibility interface.
 */
public interface Chain<E> {
    
    /**
     * Process the business logic and call the next executor if that exists.
     * 
     * @param element Object to work for
     * @throws ChainProcessException
     */
    void handleRequest(@Nonnull final E element) throws ChainProcessException;

    /**
     * Sets the next executor of the chain.
     * 
     * @param next
     * @return
     */
    Chain<E> setNext(@Nonnull Chain<E> next);
}
