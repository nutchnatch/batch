package com.ossnms.dcn_manager.bicnet.client.api.view;

import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentTypes;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static com.ossnms.dcn_manager.bicnet.client.api.DcnStringUtils.formatListOfNames;

/**
 * Builds a string with a used components guiLabels.
 */
public final class UsedBy {

    private UsedBy() {
    }

    /**
     * Return a formatted used by components gui labels.
     * @param neList NEs to get the formatted used by components
     * @return A formatted strings like: ComponentLabel1, ComponentLabel2 and ComponentLabel3.
     */
    @Nonnull
    public static Optional<String> of(@Nonnull final Collection<INE> neList) {
        final Set<String> guiLabels = neList.stream()
                .map(INE::getUsedBy)
                .filter(Objects::nonNull)
                .flatMap(BiCNetComponentTypes::stream)
                .map(BiCNetComponentType::guiLabel).collect(Collectors.toSet());

        return guiLabels.isEmpty() ?  Optional.empty() : Optional.of(formatListOfNames(guiLabels));
    }
}
