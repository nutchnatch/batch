package com.ossnms.dcn_manager.bicnet.client.api.listener;

/**
 * Generic Event listener for DCN Domain objects.
 * 
 * @param <E> DCN Domain Object 
 */
public interface EventChangeListener<E> {

    /**
     * Invoked when element was removed. 
     * @param element Removed element.
     */
    void elementRemoved(E element);
    
    /**
     * Invoked when a new element was received.
     * @param element Added element.
     */
    void elementAdded(E element);
    
    /**
     * Invoked when a element was updated.
     * @param element Updated element.
     */
    void elementUpdated(E element);

    /**
     * Invoked when all element was removed.
     */
    void removeAll();
}