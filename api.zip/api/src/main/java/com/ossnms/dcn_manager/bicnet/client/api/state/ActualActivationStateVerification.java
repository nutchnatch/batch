package com.ossnms.dcn_manager.bicnet.client.api.state;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;

import java.util.Optional;

public final class ActualActivationStateVerification {

    private ActualActivationStateVerification() {
    }

    public static boolean isActive(final Optional<GuiActualActivationState> input) {
        return verify(input, GuiActualActivationState.ACTIVE);
    }

    public static boolean isSynchronizing(final Optional<GuiActualActivationState> input) {
        return verify(input, GuiActualActivationState.SYNCHRONIZING);
    }

    public static boolean isOutOfSync(final Optional<GuiActualActivationState> input) {
        return verify(input, GuiActualActivationState.OUT_OF_SYNCH);
    }

    public static boolean isInactive(final Optional<GuiActualActivationState> input) {
        return verify(input, GuiActualActivationState.INACTIVE);
    }

    public static boolean isActivating(final Optional<GuiActualActivationState> input) {
        return verify(input, GuiActualActivationState.ACTIVATING);
    }

    public static boolean isDeactivating(final Optional<GuiActualActivationState> input) {
        return verify(input, GuiActualActivationState.DEACTIVATING);
    }

    public static boolean isFailed(final Optional<GuiActualActivationState> input) {
        return verify(input, GuiActualActivationState.FAILED);
    }

    public static boolean isUnmanaged(final Optional<GuiActualActivationState> input) {
        return verify(input, GuiActualActivationState.NONE);
    }

    public static boolean isStartingUp(final Optional<GuiActualActivationState> input) {
        return verify(input, GuiActualActivationState.STARTINGUP);
    }

    public static boolean isShutingDown(final Optional<GuiActualActivationState> input) {
        return verify(input, GuiActualActivationState.SHUTTINGDOWN);
    }

    public static boolean verify(Optional<GuiActualActivationState> input, GuiActualActivationState state) {
        return input.isPresent() ? input.get() == state : false;
    }
}
