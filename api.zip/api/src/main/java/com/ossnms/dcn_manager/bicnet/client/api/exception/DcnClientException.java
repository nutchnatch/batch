package com.ossnms.dcn_manager.bicnet.client.api.exception;

import org.slf4j.helpers.MessageFormatter;

public class DcnClientException extends Exception {

    private static final long serialVersionUID = -1249478941120743112L;

    /** @see Exception#Exception() */
    public DcnClientException() {

    }

    /** @see Exception#Exception(String) */
    public DcnClientException(final String message) {
        super(message);
    }

    /** @see Exception#Exception(Throwable) */
    public DcnClientException(final Throwable cause) {
        super(cause);
    }

    /** @see Exception#Exception(String,Throwable) */
    public DcnClientException(final String message, final Throwable cause) {
        super(message, cause);
    }

    /** @see Exception#Exception(String,Throwable,boolean,boolean) */
    public DcnClientException(final String message, final Throwable cause, final boolean enableSuppression, final boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * Constructs a new exception with a detail message built from the given format string and parameters.
     * 
     * @param format A format string.
     * @param formatParameters Parameters referenced by format specifiers in the format string.
     *
     * @see DcnClientException#DcnClientException(String)
     * @see MessageFormatter#arrayFormat(String, Object[])
     */
    public DcnClientException(final String format, final Object... formatParameters) {
        this(buildMessage(format, formatParameters));
    }

    /**
     * Constructs a new exception with a cause and a detail message built from the given format string and parameters.
     * 
     * @param format A format string.
     * @param cause The cause.
     * @param formatParameters Parameters referenced by format specifiers in the format string.
     *
     * @see DcnClientException#DcnClientException(String,Throwable)
     * @see MessageFormatter#arrayFormat(String, Object[])
     */
    public DcnClientException(final String format, final Throwable cause, final Object... formatParameters) {
        this(buildMessage(format, formatParameters), cause);
    }

    private static String buildMessage(final String format, final Object... formatParameters) {
        return MessageFormatter.arrayFormat(format, formatParameters).getMessage();
    }
}
