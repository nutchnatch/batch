package com.ossnms.dcn_manager.bicnet.client.api.state;

import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;

import javax.annotation.Nonnull;

public final class ChannelActualStateVerification {

    private ChannelActualStateVerification() {
    }

    public static boolean isActive(@Nonnull final IEM em) {
        return CommunicationState.CONNECTED == em.getCommunicationState();
    }

    public static boolean isInactive(@Nonnull final IEM em) {
        return CommunicationState.DISCONNECTED == em.getCommunicationState();
    }

    public static boolean isConnecting(@Nonnull final IEM em) {
        return CommunicationState.CONNECTING == em.getCommunicationState();
    }
}
