package com.ossnms.dcn_manager.bicnet.client.api.command;

/**
 * Base class for client commands.
 *
 * @param <ELEMENT>
 */
public interface Command<ELEMENT> {

    void call(ELEMENT parentId) throws CommandException;
}
