package com.ossnms.dcn_manager.bicnet.client.api.plugin;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ChannelService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ConfigurationService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ContainerService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.DomainService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportCoreService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportCtService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportExportService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportLegacyService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.MediatorService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.NeService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.SystemContainerService;

/**
 * Uses the Service Locator to access the BiCNet Server Facades.
 */
public interface BicnetServerFacade {

    /**
     * @return The EM/NE Public facade
     * @throws BcbException
     */
    IEMObjectMgrFacade getDcnPublicServices() throws BcbException;

    /**
     * @return The NE services
     * @throws BcbException
     */
    NeService getNeService() throws BcbException;

    /**
     * @return The Channel services
     * @throws BcbException
     */
    ChannelService getChannelService() throws BcbException;

    /**
     * @return The MEDIATOR services
     * @throws BcbException
     */
    MediatorService getMediatorService() throws BcbException;

    /**
     * @return The DOMAIN services
     * @throws BcbException
     */
    DomainService getDomainService() throws BcbException;

    /**
     * @return The Configuration services
     * @throws BcbException
     */
    ConfigurationService getConfigurationService() throws BcbException;

    /**
     * @return The Container services
     * @throws BcbException
     */
    ContainerService getContainerService() throws BcbException;

    /**
     * @return The System Container services
     * @throws BcbException
     */
    SystemContainerService getSystemContainerService() throws BcbException;

    /**
     * @return The Import/Export Services
     */
    ImportExportService getImportExportService();

    /**
     * @return The Import Legacy Service
     */
    ImportLegacyService getImportLegacyService();
    
    /**
     * @return The Import CT Service
     */
    ImportCtService getImportCtService();

    /**
     * @return The Import Core Service
     */
    ImportCoreService getImportCoreService();
    
}