package com.ossnms.dcn_manager.bicnet.client.api.properties;


/**
 * Contains constants with the names of "well known" NE properties.
 */
public final class WellKnownNePropertyNames {

    public static final String ID_NAME = "BCB-Attribute/NE/idName";
    public static final String NE_TYPE_LABEL = "NE_TYPE_LABEL";
    public static final String CONTAINER_ID = "NEContainerId";
    public static final String NE_SYSTEM_ASSIGNMENT_NAME = "NE_SYSTEM_ASSIGNMENT_NAME";
    public static final String NE_LOCATION = "NE_LOCATION";

    private WellKnownNePropertyNames() {
    }
}
