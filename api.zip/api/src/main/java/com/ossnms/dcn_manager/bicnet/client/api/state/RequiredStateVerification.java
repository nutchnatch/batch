package com.ossnms.dcn_manager.bicnet.client.api.state;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IDcnObjectPkg;

import javax.annotation.Nonnull;

/**
 * Verifies the Required Connection State of the DCN Management objects.
 */
public final class RequiredStateVerification {
    
    private RequiredStateVerification() {
    }
        
    public static boolean isEnable(@Nonnull final IDcnObjectPkg dcnObject) {
        return EnableSwitch.ENABLED.equals(dcnObject.getActivation());
    }    
    
    public static boolean isDisable(@Nonnull final IDcnObjectPkg dcnObject) {
        return EnableSwitch.DISABLED.equals(dcnObject.getActivation());
    } 
}
