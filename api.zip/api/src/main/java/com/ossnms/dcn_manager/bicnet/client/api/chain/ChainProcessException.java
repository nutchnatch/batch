package com.ossnms.dcn_manager.bicnet.client.api.chain;

import com.ossnms.dcn_manager.bicnet.client.api.exception.DcnClientException;

public class ChainProcessException extends DcnClientException {

    private static final long serialVersionUID = 4680913942034356572L;

    /** @see DcnClientException#Exception(Throwable) */
    public ChainProcessException(final Throwable cause) {
        super(cause);
    }
    
    /** @see DcnClientException#Exception(String) */
    public ChainProcessException(final String message) {
        super(message);
    }
    
    /** @see DcnClientException#Exception(String, Object[]) */
    public ChainProcessException(final String format, final Object... formatParameters) {
        super(format, formatParameters);
    }
}
