/**
 *  Contains the chain of responsibility pattern template.
 */
package com.ossnms.dcn_manager.bicnet.client.api.chain;