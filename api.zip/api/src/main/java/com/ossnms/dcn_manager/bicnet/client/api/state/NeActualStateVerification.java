package com.ossnms.dcn_manager.bicnet.client.api.state;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeActivationState;

/**
 * Verifies the Actual state of the Network Element based on  {@link NeActivationState}.
 */
public final class NeActualStateVerification {

    private NeActualStateVerification() {
    }

    public static boolean isActive(final INE ne) {
        return ne.getActualActivationState() == NeActivationState.ACTIVE;
    }

    public static boolean isFailed(final INE ne) {
        return ne.getActualActivationState() == NeActivationState.FAILED;
    }

    public static boolean isInactive(final INE ne) {
        return ne.getActualActivationState() == NeActivationState.INACTIVE;
    }

    public static boolean isActivating(final INE ne) {
        return ne.getActualActivationState() == NeActivationState.ACTIVATING;
    }

    public static boolean isDeactivating(final INE ne) {
        return ne.getActualActivationState() == NeActivationState.DEACTIVATING;
    }

    public static boolean isStartingUp(final INE ne) {
        return ne.getActualActivationState() == NeActivationState.STARTING_UP;
    }

    public static boolean isShuttingDown(final INE ne) {
        return ne.getActualActivationState() == NeActivationState.SHUTTING_DOWN;
    }
}
