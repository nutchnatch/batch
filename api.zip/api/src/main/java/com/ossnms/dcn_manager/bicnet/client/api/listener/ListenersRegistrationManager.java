package com.ossnms.dcn_manager.bicnet.client.api.listener;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;

/**
 * Abstraction for change listeners registration.
 */
public interface ListenersRegistrationManager {

    /**
     * Add a change listener for NetworkElement objects.
     */
    void addNeListener(EventChangeListener<FullNeData> listener);

    /**
     * Add a change listener for IEM objects.
     */
    void addChannelListener(EventChangeListener<FullChannelData> listener);

    /**
     * Add a change listener for IMediator objects.
     */
    void addMediatorListener(EventChangeListener<FullMediatorData> listener);

    /**
     * Add a change listener for IGenericContainer objects.
     */
    void addContainerListener(EventChangeListener<IGenericContainer> listener);

    /**
     * Add a change listener for ISystemContainer objects.
     */
    void addSystemContainerListener(EventChangeListener<ISystemContainer> listener);

    /**
     * Add a change listener for IAS objects.
     */
    void addDomainListener(EventChangeListener<IAS> listener);

    /**
     * Add a change listener for ISystemGenericContainerAssignment objects.
     */
    void addSystemContainerAssignmentListener(EventChangeListener<ISystemGenericContainerAssignment> listener);

    /**
     * Add  a change listener for INeGenericContainerAssignment objects.
     */
    void addNEContainerAssignmentListener(EventChangeListener<INeGenericContainerAssignment> listener);

    /**
     * Remove a change listener for NetworkElement objects.
     */
    void removeNeListener(EventChangeListener<FullNeData> listener);

    /**
     * Remove a change listener for IEM objects.
     */
    void removeChannelListener(EventChangeListener<FullChannelData> listener);

    /**
     * Remove a change listener for IMediator objects.
     */
    void removeMediatorListener(EventChangeListener<FullMediatorData> listener);

    /**
     * Remove a change listener for IGenericContainer objects.
     */
    void removeContainerListener(EventChangeListener<IGenericContainer> listener);

    /**
     * Remove a change listener for ISystemContainer objects.
     */
    void removeSystemContainerListener(EventChangeListener<ISystemContainer> listener);

    /**
     * Remove a change listener for ISystemGenericContainerAssignment objects.
     */
    void removeSystemContainerAssignmentListener(EventChangeListener<ISystemGenericContainerAssignment> listener);

    /**
     * Remove a change listener for INeGenericContainerAssignment objects.
     */
    void removeNEContainerAssignmentListener(EventChangeListener<INeGenericContainerAssignment> listener);

    /**
     * Remove a change listener for IAS objects.
     */
    void removeDomainListener(EventChangeListener<IAS> listener);
}
