package com.ossnms.dcn_manager.bicnet.client.api.command;

import com.ossnms.dcn_manager.bicnet.client.api.exception.DcnClientException;

public class CommandException extends DcnClientException {
    private static final long serialVersionUID = -1249478941120743112L;

    /** @see DcnClientException#Exception(Throwable) */
    public CommandException(final Throwable cause) {
        super(cause);
    }
    
    /** @see DcnClientException#Exception(String, Object[]) */
    public CommandException(final String format, final Object... formatParameters) {
        super(format, formatParameters);
    }
}
