package com.ossnms.dcn_manager.bicnet.client.api.chain;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Template to Handle the chain flow.
 *
 * @param <E> Object to be processed
 */
public abstract class ChainTemplate<E> implements Chain<E> {
    
    /* Next item to be processed */
    private Optional<Chain<E>> next = Optional.empty();

    /**
     * Implements the business logic.
     * 
     * @param element Object to be processed
     * @return return {@link ChainStatus#CONTINUE} to continue the chain flow or {@link ChainStatus#STOP} to stop the chain flow.
     * @throws ChainProcessException
     */
    protected abstract ChainStatus process(@Nonnull final E element) throws ChainProcessException;
    
    /**
     * @see Chain#handleRequest(Object)
     * @throws ChainProcessException 
     */
    @Override
    public final void handleRequest(@Nonnull final E element) throws ChainProcessException {
        if (ChainStatus.STOP != process(element) && next.isPresent()) {
            next.get().handleRequest(element);
        }
    }
    
    /**
     * @see Chain#setNext(Chain)
     */
    @Override
    public final Chain<E> setNext(@Nonnull Chain<E> next) {
        this.next = Optional.of(next);
        return this;
    }
}
