package com.ossnms.dcn_manager.bicnet.client.api.plugin;

import com.google.common.base.Joiner;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.framework.client.jfx.FrameworkRunnableBaseImpl;

import java.util.Collection;
import java.util.HashSet;

/**
 * Abstraction fors JOBs.
 * <p>
 * Must be used on JOBs that will be queued in Framework JOBs execution.
 *
 * @param <E> Element type to be processed
 * @see com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper#queueJob(String, String, com.ossnms.bicnet.bcb.plugin.BiCNetPluginRunnable)
 */
public abstract class Job<E> extends FrameworkRunnableBaseImpl {

    private final Collection<E> elements;
    private final ISessionContext sessionContext;
    private final BicnetServerFacade bicnetServerFacade;
    private final String jobName;

    public Job(final String jobName,
               final ISessionContext sessionContext,
               final BicnetServerFacade bicnetServerFacade,
               final Collection<? extends E> elements) {
        this.sessionContext = sessionContext;
        this.bicnetServerFacade = bicnetServerFacade;
        this.elements = new HashSet<>(elements);
        this.jobName = jobName;
    }

    /**
     * The logic to be executed by the Job.
     *
     * @throws BiCNetPluginException
     */
    protected abstract void execute() throws BiCNetPluginException;

    /**
     * {@inheritDoc}
     */
    @Override public final void run() throws BiCNetPluginException {
        this.execute();
    }

    /**
     * @return The BiCNet Server services facade
     */
    protected final BicnetServerFacade getBicnetServerFacade() {
        return bicnetServerFacade;
    }

    /**
     * @return The current session context
     */
    protected final ISessionContext getSessionContext() {
        return sessionContext;
    }

    /**
     * @return The elements to be processed
     */
    protected final Collection<E> getElements() {
        return elements;
    }

    /**
     * @return The Job Name for identification and to be show on BiCNet GUI.
     */
    public String getJobName() {
        return jobName;
    }

    /**
     * @return The affected objects in a string format.
     */
    public String affectedObjects() {
        String values = Joiner.on(", ").join(getElements());
        return "IDs[" + values + "]";
    }
}
