@javax.xml.bind.annotation.XmlSchema(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct")
package com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct;
