@javax.xml.bind.annotation.XmlSchema(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager")
package com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager;
