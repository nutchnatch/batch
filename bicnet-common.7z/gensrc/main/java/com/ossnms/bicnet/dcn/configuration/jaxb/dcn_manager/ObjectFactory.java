
package com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SystemContainers_QNAME = new QName("http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", "SystemContainers");
    private final static QName _Mediators_QNAME = new QName("http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", "Mediators");
    private final static QName _NE_QNAME = new QName("http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", "NE");
    private final static QName _SystemContainer_QNAME = new QName("http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", "SystemContainer");
    private final static QName _EM_QNAME = new QName("http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", "EM");
    private final static QName _GenericContainers_QNAME = new QName("http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", "GenericContainers");
    private final static QName _Mediator_QNAME = new QName("http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", "Mediator");
    private final static QName _EMs_QNAME = new QName("http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", "EMs");
    private final static QName _NEs_QNAME = new QName("http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", "NEs");
    private final static QName _GenericContainer_QNAME = new QName("http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", "GenericContainer");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SystemContainers }
     * 
     */
    public SystemContainers createSystemContainers() {
        return new SystemContainers();
    }

    /**
     * Create an instance of {@link Mediators }
     * 
     */
    public Mediators createMediators() {
        return new Mediators();
    }

    /**
     * Create an instance of {@link NetworkElement }
     * 
     */
    public NetworkElement createNetworkElement() {
        return new NetworkElement();
    }

    /**
     * Create an instance of {@link SystemContainer }
     * 
     */
    public SystemContainer createSystemContainer() {
        return new SystemContainer();
    }

    /**
     * Create an instance of {@link Channel }
     * 
     */
    public Channel createChannel() {
        return new Channel();
    }

    /**
     * Create an instance of {@link BiCNetData }
     * 
     */
    public BiCNetData createBiCNetData() {
        return new BiCNetData();
    }

    /**
     * Create an instance of {@link Channels }
     * 
     */
    public Channels createChannels() {
        return new Channels();
    }

    /**
     * Create an instance of {@link NetworkElements }
     * 
     */
    public NetworkElements createNetworkElements() {
        return new NetworkElements();
    }

    /**
     * Create an instance of {@link GenericContainers }
     * 
     */
    public GenericContainers createGenericContainers() {
        return new GenericContainers();
    }

    /**
     * Create an instance of {@link Mediator }
     * 
     */
    public Mediator createMediator() {
        return new Mediator();
    }

    /**
     * Create an instance of {@link GenericContainer }
     * 
     */
    public GenericContainer createGenericContainer() {
        return new GenericContainer();
    }

    /**
     * Create an instance of {@link DcnAttributes }
     * 
     */
    public DcnAttributes createDcnAttributes() {
        return new DcnAttributes();
    }

    /**
     * Create an instance of {@link Properties }
     * 
     */
    public Properties createProperties() {
        return new Properties();
    }

    /**
     * Create an instance of {@link ContainerAssignment }
     * 
     */
    public ContainerAssignment createContainerAssignment() {
        return new ContainerAssignment();
    }

    /**
     * Create an instance of {@link Container }
     * 
     */
    public Container createContainer() {
        return new Container();
    }

    /**
     * Create an instance of {@link MediatorPhysicalInstance }
     * 
     */
    public MediatorPhysicalInstance createMediatorPhysicalInstance() {
        return new MediatorPhysicalInstance();
    }

    /**
     * Create an instance of {@link Domain }
     * 
     */
    public Domain createDomain() {
        return new Domain();
    }

    /**
     * Create an instance of {@link Property }
     * 
     */
    public Property createProperty() {
        return new Property();
    }

    /**
     * Create an instance of {@link NeTypeTaxonomy }
     * 
     */
    public NeTypeTaxonomy createNeTypeTaxonomy() {
        return new NeTypeTaxonomy();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SystemContainers }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", name = "SystemContainers")
    public JAXBElement<SystemContainers> createSystemContainers(SystemContainers value) {
        return new JAXBElement<SystemContainers>(_SystemContainers_QNAME, SystemContainers.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mediators }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", name = "Mediators")
    public JAXBElement<Mediators> createMediators(Mediators value) {
        return new JAXBElement<Mediators>(_Mediators_QNAME, Mediators.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NetworkElement }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", name = "NE")
    public JAXBElement<NetworkElement> createNE(NetworkElement value) {
        return new JAXBElement<NetworkElement>(_NE_QNAME, NetworkElement.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SystemContainer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", name = "SystemContainer")
    public JAXBElement<SystemContainer> createSystemContainer(SystemContainer value) {
        return new JAXBElement<SystemContainer>(_SystemContainer_QNAME, SystemContainer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Channel }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", name = "EM")
    public JAXBElement<Channel> createEM(Channel value) {
        return new JAXBElement<Channel>(_EM_QNAME, Channel.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GenericContainers }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", name = "GenericContainers")
    public JAXBElement<GenericContainers> createGenericContainers(GenericContainers value) {
        return new JAXBElement<GenericContainers>(_GenericContainers_QNAME, GenericContainers.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mediator }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", name = "Mediator")
    public JAXBElement<Mediator> createMediator(Mediator value) {
        return new JAXBElement<Mediator>(_Mediator_QNAME, Mediator.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Channels }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", name = "EMs")
    public JAXBElement<Channels> createEMs(Channels value) {
        return new JAXBElement<Channels>(_EMs_QNAME, Channels.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NetworkElements }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", name = "NEs")
    public JAXBElement<NetworkElements> createNEs(NetworkElements value) {
        return new JAXBElement<NetworkElements>(_NEs_QNAME, NetworkElements.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GenericContainer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager", name = "GenericContainer")
    public JAXBElement<GenericContainer> createGenericContainer(GenericContainer value) {
        return new JAXBElement<GenericContainer>(_GenericContainer_QNAME, GenericContainer.class, null, value);
    }

}
