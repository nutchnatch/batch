
package com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Mediators" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}Mediators"/>
 *         &lt;element name="EMs" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}Channels"/>
 *         &lt;element name="NEs" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}NetworkElements"/>
 *         &lt;element name="SystemContainers" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}SystemContainers"/>
 *         &lt;element name="GenericContainers" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}GenericContainers"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Version" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "mediators",
    "eMs",
    "nEs",
    "systemContainers",
    "genericContainers"
})
@XmlRootElement(name = "BiCNetData")
public class BiCNetData
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlElement(name = "Mediators", required = true)
    protected Mediators mediators;
    @XmlElement(name = "EMs", required = true)
    protected Channels eMs;
    @XmlElement(name = "NEs", required = true)
    protected NetworkElements nEs;
    @XmlElement(name = "SystemContainers", required = true)
    protected SystemContainers systemContainers;
    @XmlElement(name = "GenericContainers", required = true)
    protected GenericContainers genericContainers;
    @XmlAttribute(name = "Version")
    protected String version;

    /**
     * Gets the value of the mediators property.
     * 
     * @return
     *     possible object is
     *     {@link Mediators }
     *     
     */
    public Mediators getMediators() {
        return mediators;
    }

    /**
     * Sets the value of the mediators property.
     * 
     * @param value
     *     allowed object is
     *     {@link Mediators }
     *     
     */
    public void setMediators(Mediators value) {
        this.mediators = value;
    }

    /**
     * Gets the value of the eMs property.
     * 
     * @return
     *     possible object is
     *     {@link Channels }
     *     
     */
    public Channels getEMs() {
        return eMs;
    }

    /**
     * Sets the value of the eMs property.
     * 
     * @param value
     *     allowed object is
     *     {@link Channels }
     *     
     */
    public void setEMs(Channels value) {
        this.eMs = value;
    }

    /**
     * Gets the value of the nEs property.
     * 
     * @return
     *     possible object is
     *     {@link NetworkElements }
     *     
     */
    public NetworkElements getNEs() {
        return nEs;
    }

    /**
     * Sets the value of the nEs property.
     * 
     * @param value
     *     allowed object is
     *     {@link NetworkElements }
     *     
     */
    public void setNEs(NetworkElements value) {
        this.nEs = value;
    }

    /**
     * Gets the value of the systemContainers property.
     * 
     * @return
     *     possible object is
     *     {@link SystemContainers }
     *     
     */
    public SystemContainers getSystemContainers() {
        return systemContainers;
    }

    /**
     * Sets the value of the systemContainers property.
     * 
     * @param value
     *     allowed object is
     *     {@link SystemContainers }
     *     
     */
    public void setSystemContainers(SystemContainers value) {
        this.systemContainers = value;
    }

    /**
     * Gets the value of the genericContainers property.
     * 
     * @return
     *     possible object is
     *     {@link GenericContainers }
     *     
     */
    public GenericContainers getGenericContainers() {
        return genericContainers;
    }

    /**
     * Sets the value of the genericContainers property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericContainers }
     *     
     */
    public void setGenericContainers(GenericContainers value) {
        this.genericContainers = value;
    }

    /**
     * Gets the value of the version property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersion(String value) {
        this.version = value;
    }

}
