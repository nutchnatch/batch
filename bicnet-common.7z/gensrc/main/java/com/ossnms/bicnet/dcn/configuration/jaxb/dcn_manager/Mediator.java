
package com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Mediator complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Mediator">
 *   &lt;complexContent>
 *     &lt;extension base="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}Properties">
 *       &lt;sequence>
 *         &lt;element name="ReconnectInterval" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ConcurrentActivationsLimited" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ConcurrentActivationsLimit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhysicalInstance" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}MediatorPhysicalInstance" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="IDName" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Host" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Mediator", propOrder = {
    "reconnectInterval",
    "concurrentActivationsLimited",
    "concurrentActivationsLimit",
    "description",
    "physicalInstance"
})
public class Mediator
    extends Properties
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlElement(name = "ReconnectInterval")
    protected String reconnectInterval;
    @XmlElement(name = "ConcurrentActivationsLimited")
    protected Boolean concurrentActivationsLimited;
    @XmlElement(name = "ConcurrentActivationsLimit")
    protected String concurrentActivationsLimit;
    @XmlElement(name = "Description")
    protected String description;
    @XmlElement(name = "PhysicalInstance")
    protected List<MediatorPhysicalInstance> physicalInstance;
    @XmlAttribute(name = "IDName")
    protected String idName;
    @XmlAttribute(name = "Type")
    protected String type;
    @XmlAttribute(name = "Host")
    protected String host;

    /**
     * Gets the value of the reconnectInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReconnectInterval() {
        return reconnectInterval;
    }

    /**
     * Sets the value of the reconnectInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReconnectInterval(String value) {
        this.reconnectInterval = value;
    }

    /**
     * Gets the value of the concurrentActivationsLimited property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isConcurrentActivationsLimited() {
        return concurrentActivationsLimited;
    }

    /**
     * Sets the value of the concurrentActivationsLimited property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setConcurrentActivationsLimited(Boolean value) {
        this.concurrentActivationsLimited = value;
    }

    /**
     * Gets the value of the concurrentActivationsLimit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConcurrentActivationsLimit() {
        return concurrentActivationsLimit;
    }

    /**
     * Sets the value of the concurrentActivationsLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConcurrentActivationsLimit(String value) {
        this.concurrentActivationsLimit = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the physicalInstance property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the physicalInstance property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPhysicalInstance().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MediatorPhysicalInstance }
     * 
     * 
     */
    public List<MediatorPhysicalInstance> getPhysicalInstance() {
        if (physicalInstance == null) {
            physicalInstance = new ArrayList<MediatorPhysicalInstance>();
        }
        return this.physicalInstance;
    }

    /**
     * Gets the value of the idName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDName() {
        return idName;
    }

    /**
     * Sets the value of the idName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDName(String value) {
        this.idName = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the host property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHost() {
        return host;
    }

    /**
     * Sets the value of the host property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHost(String value) {
        this.host = value;
    }

}
