
package com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NetworkElement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NetworkElement">
 *   &lt;complexContent>
 *     &lt;extension base="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}Properties">
 *       &lt;sequence>
 *         &lt;element name="NeTypeTaxonomy" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}NeTypeTaxonomy" minOccurs="0"/>
 *         &lt;element name="ParentAS" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}Domain" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="AssignedContainer" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}ContainerAssignment" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="DcnAttributes" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}DcnAttributes" minOccurs="0"/>
 *         &lt;element name="NeSoftwareVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MountMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="IDName" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="ParentEM" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="SystemContainer" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetworkElement", propOrder = {
    "neTypeTaxonomy",
    "parentAS",
    "assignedContainer",
    "dcnAttributes",
    "neSoftwareVersion",
    "mountMode"
})
public class NetworkElement
    extends Properties
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlElement(name = "NeTypeTaxonomy")
    protected NeTypeTaxonomy neTypeTaxonomy;
    @XmlElement(name = "ParentAS")
    protected List<Domain> parentAS;
    @XmlElement(name = "AssignedContainer")
    protected List<ContainerAssignment> assignedContainer;
    @XmlElement(name = "DcnAttributes")
    protected DcnAttributes dcnAttributes;
    @XmlElement(name = "NeSoftwareVersion")
    protected String neSoftwareVersion;
    @XmlElement(name = "MountMode")
    protected String mountMode;
    @XmlAttribute(name = "IDName")
    protected String idName;
    @XmlAttribute(name = "Type")
    protected String type;
    @XmlAttribute(name = "ParentEM")
    protected String parentEM;
    @XmlAttribute(name = "SystemContainer")
    protected String systemContainer;

    /**
     * Gets the value of the neTypeTaxonomy property.
     * 
     * @return
     *     possible object is
     *     {@link NeTypeTaxonomy }
     *     
     */
    public NeTypeTaxonomy getNeTypeTaxonomy() {
        return neTypeTaxonomy;
    }

    /**
     * Sets the value of the neTypeTaxonomy property.
     * 
     * @param value
     *     allowed object is
     *     {@link NeTypeTaxonomy }
     *     
     */
    public void setNeTypeTaxonomy(NeTypeTaxonomy value) {
        this.neTypeTaxonomy = value;
    }

    /**
     * Gets the value of the parentAS property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parentAS property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParentAS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Domain }
     * 
     * 
     */
    public List<Domain> getParentAS() {
        if (parentAS == null) {
            parentAS = new ArrayList<Domain>();
        }
        return this.parentAS;
    }

    /**
     * Gets the value of the assignedContainer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assignedContainer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssignedContainer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContainerAssignment }
     * 
     * 
     */
    public List<ContainerAssignment> getAssignedContainer() {
        if (assignedContainer == null) {
            assignedContainer = new ArrayList<ContainerAssignment>();
        }
        return this.assignedContainer;
    }

    /**
     * Gets the value of the dcnAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link DcnAttributes }
     *     
     */
    public DcnAttributes getDcnAttributes() {
        return dcnAttributes;
    }

    /**
     * Sets the value of the dcnAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link DcnAttributes }
     *     
     */
    public void setDcnAttributes(DcnAttributes value) {
        this.dcnAttributes = value;
    }

    /**
     * Gets the value of the neSoftwareVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeSoftwareVersion() {
        return neSoftwareVersion;
    }

    /**
     * Sets the value of the neSoftwareVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeSoftwareVersion(String value) {
        this.neSoftwareVersion = value;
    }

    /**
     * Gets the value of the mountMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMountMode() {
        return mountMode;
    }

    /**
     * Sets the value of the mountMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMountMode(String value) {
        this.mountMode = value;
    }

    /**
     * Gets the value of the idName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDName() {
        return idName;
    }

    /**
     * Sets the value of the idName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDName(String value) {
        this.idName = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the parentEM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentEM() {
        return parentEM;
    }

    /**
     * Sets the value of the parentEM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentEM(String value) {
        this.parentEM = value;
    }

    /**
     * Gets the value of the systemContainer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemContainer() {
        return systemContainer;
    }

    /**
     * Sets the value of the systemContainer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemContainer(String value) {
        this.systemContainer = value;
    }

}
