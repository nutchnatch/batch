
package com.ossnms.bicnet.dcn.configuration.jaxb.legacy;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AS complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AS">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="NEList" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="IDName" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="IDName" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="ParentAS" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="ASIdFromRID" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="DiscoveryPermitted" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AS", propOrder = {
    "neList"
})
public class AS
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlElement(name = "NEList")
    protected List<AS.NEList> neList;
    @XmlAttribute(name = "IDName")
    protected String idName;
    @XmlAttribute(name = "ParentAS")
    protected String parentAS;
    @XmlAttribute(name = "ASIdFromRID")
    protected String asIdFromRID;
    @XmlAttribute(name = "DiscoveryPermitted")
    protected Boolean discoveryPermitted;

    /**
     * Gets the value of the neList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the neList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNEList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AS.NEList }
     * 
     * 
     */
    public List<AS.NEList> getNEList() {
        if (neList == null) {
            neList = new ArrayList<AS.NEList>();
        }
        return this.neList;
    }

    /**
     * Gets the value of the idName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDName() {
        return idName;
    }

    /**
     * Sets the value of the idName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDName(String value) {
        this.idName = value;
    }

    /**
     * Gets the value of the parentAS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentAS() {
        return parentAS;
    }

    /**
     * Sets the value of the parentAS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentAS(String value) {
        this.parentAS = value;
    }

    /**
     * Gets the value of the asIdFromRID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getASIdFromRID() {
        return asIdFromRID;
    }

    /**
     * Sets the value of the asIdFromRID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setASIdFromRID(String value) {
        this.asIdFromRID = value;
    }

    /**
     * Gets the value of the discoveryPermitted property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDiscoveryPermitted() {
        return discoveryPermitted;
    }

    /**
     * Sets the value of the discoveryPermitted property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDiscoveryPermitted(Boolean value) {
        this.discoveryPermitted = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="IDName" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class NEList
        implements Serializable
    {

        private final static long serialVersionUID = -1L;
        @XmlAttribute(name = "IDName")
        protected String idName;

        /**
         * Gets the value of the idName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getIDName() {
            return idName;
        }

        /**
         * Sets the value of the idName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setIDName(String value) {
            this.idName = value;
        }

    }

}
