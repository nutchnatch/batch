
package com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NeTypeTaxonomy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NeTypeTaxonomy">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="NeFamilyLabel" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="NeTypeLabel" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="NeSubTypeLabel" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NeTypeTaxonomy")
public class NeTypeTaxonomy
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlAttribute(name = "NeFamilyLabel")
    protected String neFamilyLabel;
    @XmlAttribute(name = "NeTypeLabel")
    protected String neTypeLabel;
    @XmlAttribute(name = "NeSubTypeLabel")
    protected String neSubTypeLabel;

    /**
     * Gets the value of the neFamilyLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeFamilyLabel() {
        if (neFamilyLabel == null) {
            return "";
        } else {
            return neFamilyLabel;
        }
    }

    /**
     * Sets the value of the neFamilyLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeFamilyLabel(String value) {
        this.neFamilyLabel = value;
    }

    /**
     * Gets the value of the neTypeLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeTypeLabel() {
        if (neTypeLabel == null) {
            return "";
        } else {
            return neTypeLabel;
        }
    }

    /**
     * Sets the value of the neTypeLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeTypeLabel(String value) {
        this.neTypeLabel = value;
    }

    /**
     * Gets the value of the neSubTypeLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeSubTypeLabel() {
        if (neSubTypeLabel == null) {
            return "";
        } else {
            return neSubTypeLabel;
        }
    }

    /**
     * Sets the value of the neSubTypeLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeSubTypeLabel(String value) {
        this.neSubTypeLabel = value;
    }

}
