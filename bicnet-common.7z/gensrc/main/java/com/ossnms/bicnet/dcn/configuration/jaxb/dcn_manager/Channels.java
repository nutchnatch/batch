
package com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Channels complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Channels">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EM" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}Channel" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Channels", propOrder = {
    "em"
})
public class Channels
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlElement(name = "EM", required = true)
    protected List<Channel> em;

    /**
     * Gets the value of the em property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the em property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEM().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Channel }
     * 
     * 
     */
    public List<Channel> getEM() {
        if (em == null) {
            em = new ArrayList<Channel>();
        }
        return this.em;
    }

}
