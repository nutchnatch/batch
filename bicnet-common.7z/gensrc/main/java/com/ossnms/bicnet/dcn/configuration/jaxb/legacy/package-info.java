@javax.xml.bind.annotation.XmlSchema(namespace = "http://ossnms.com/bicnet/dcn/configuration/jaxb/legacy")
package com.ossnms.bicnet.dcn.configuration.jaxb.legacy;
