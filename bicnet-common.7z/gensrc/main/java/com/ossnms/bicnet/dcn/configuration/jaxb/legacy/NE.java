
package com.ossnms.bicnet.dcn.configuration.jaxb.legacy;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NE complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NE">
 *   &lt;complexContent>
 *     &lt;extension base="{http://ossnms.com/bicnet/dcn/configuration/jaxb/legacy}Properties">
 *       &lt;sequence>
 *         &lt;element name="NeTypeTaxonomy">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="NeFamilyLabel" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="NeTypeLabel" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="NeSubTypeLabel" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ParentAS" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="Name" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="IDName" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="ParentEM" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NE", propOrder = {
    "neTypeTaxonomy",
    "parentAS"
})
public class NE
    extends Properties
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlElement(name = "NeTypeTaxonomy", required = true)
    protected NE.NeTypeTaxonomy neTypeTaxonomy;
    @XmlElement(name = "ParentAS", required = true)
    protected List<NE.ParentAS> parentAS;
    @XmlAttribute(name = "IDName")
    protected String idName;
    @XmlAttribute(name = "Type")
    protected String type;
    @XmlAttribute(name = "ParentEM")
    protected String parentEM;

    /**
     * Gets the value of the neTypeTaxonomy property.
     * 
     * @return
     *     possible object is
     *     {@link NE.NeTypeTaxonomy }
     *     
     */
    public NE.NeTypeTaxonomy getNeTypeTaxonomy() {
        return neTypeTaxonomy;
    }

    /**
     * Sets the value of the neTypeTaxonomy property.
     * 
     * @param value
     *     allowed object is
     *     {@link NE.NeTypeTaxonomy }
     *     
     */
    public void setNeTypeTaxonomy(NE.NeTypeTaxonomy value) {
        this.neTypeTaxonomy = value;
    }

    /**
     * Gets the value of the parentAS property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parentAS property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParentAS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NE.ParentAS }
     * 
     * 
     */
    public List<NE.ParentAS> getParentAS() {
        if (parentAS == null) {
            parentAS = new ArrayList<NE.ParentAS>();
        }
        return this.parentAS;
    }

    /**
     * Gets the value of the idName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDName() {
        return idName;
    }

    /**
     * Sets the value of the idName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDName(String value) {
        this.idName = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the parentEM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentEM() {
        return parentEM;
    }

    /**
     * Sets the value of the parentEM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentEM(String value) {
        this.parentEM = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="NeFamilyLabel" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="NeTypeLabel" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="NeSubTypeLabel" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class NeTypeTaxonomy
        implements Serializable
    {

        private final static long serialVersionUID = -1L;
        @XmlAttribute(name = "NeFamilyLabel")
        protected String neFamilyLabel;
        @XmlAttribute(name = "NeTypeLabel")
        protected String neTypeLabel;
        @XmlAttribute(name = "NeSubTypeLabel")
        protected String neSubTypeLabel;

        /**
         * Gets the value of the neFamilyLabel property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNeFamilyLabel() {
            return neFamilyLabel;
        }

        /**
         * Sets the value of the neFamilyLabel property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNeFamilyLabel(String value) {
            this.neFamilyLabel = value;
        }

        /**
         * Gets the value of the neTypeLabel property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNeTypeLabel() {
            return neTypeLabel;
        }

        /**
         * Sets the value of the neTypeLabel property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNeTypeLabel(String value) {
            this.neTypeLabel = value;
        }

        /**
         * Gets the value of the neSubTypeLabel property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNeSubTypeLabel() {
            return neSubTypeLabel;
        }

        /**
         * Sets the value of the neSubTypeLabel property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNeSubTypeLabel(String value) {
            this.neSubTypeLabel = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="Name" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class ParentAS
        implements Serializable
    {

        private final static long serialVersionUID = -1L;
        @XmlAttribute(name = "Name")
        protected String name;

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

    }

}
