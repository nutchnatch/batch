
package com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TNMSData }
     * 
     */
    public TNMSData createTNMSData() {
        return new TNMSData();
    }

    /**
     * Create an instance of {@link NE }
     * 
     */
    public NE createNE() {
        return new NE();
    }

    /**
     * Create an instance of {@link Channel }
     * 
     */
    public Channel createChannel() {
        return new Channel();
    }

    /**
     * Create an instance of {@link PropContainer }
     * 
     */
    public PropContainer createPropContainer() {
        return new PropContainer();
    }

    /**
     * Create an instance of {@link TNMSData.NetServers }
     * 
     */
    public TNMSData.NetServers createTNMSDataNetServers() {
        return new TNMSData.NetServers();
    }

    /**
     * Create an instance of {@link TNMSData.DcnChannels }
     * 
     */
    public TNMSData.DcnChannels createTNMSDataDcnChannels() {
        return new TNMSData.DcnChannels();
    }

    /**
     * Create an instance of {@link TNMSData.NEs }
     * 
     */
    public TNMSData.NEs createTNMSDataNEs() {
        return new TNMSData.NEs();
    }

    /**
     * Create an instance of {@link EID }
     * 
     */
    public EID createEID() {
        return new EID();
    }

    /**
     * Create an instance of {@link NetServer }
     * 
     */
    public NetServer createNetServer() {
        return new NetServer();
    }

    /**
     * Create an instance of {@link Mediator }
     * 
     */
    public Mediator createMediator() {
        return new Mediator();
    }

    /**
     * Create an instance of {@link Property }
     * 
     */
    public Property createProperty() {
        return new Property();
    }

    /**
     * Create an instance of {@link NE.NEType }
     * 
     */
    public NE.NEType createNENEType() {
        return new NE.NEType();
    }

    /**
     * Create an instance of {@link Channel.DcnChannelType }
     * 
     */
    public Channel.DcnChannelType createChannelDcnChannelType() {
        return new Channel.DcnChannelType();
    }

    /**
     * Create an instance of {@link PropContainer.PropStore }
     * 
     */
    public PropContainer.PropStore createPropContainerPropStore() {
        return new PropContainer.PropStore();
    }

}
