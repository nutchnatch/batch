package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IVisitable;
import com.ossnms.bicnet.bcb.model.platform.Notification;

import javax.annotation.Nonnull;
import java.util.Date;
import java.util.Objects;

/**
 * BCB notification class used to forward Mediator Information updates to listeners.
 */
public final class FullMediatorDataCreateNotification extends Notification implements IVisitable {

    private static final long serialVersionUID = -6441909422073635259L;

    /**
     * Implementation of our specific visitor pattern.
     */
    public interface IVisitor extends com.ossnms.bicnet.bcb.model.IVisitor
    {
        /**
         * Allows specific processing of FullMediatorDataCreateNotification instances.
         * @param arg {@link FullMediatorDataCreateNotification} object to be processed.
         * @return Whether the Notification has been processed.
         */
        boolean onFullMediatorDataCreation(FullMediatorDataCreateNotification arg) throws BcbException;
    }

    /**
     * Performs specific processing of FullMediatorDataCreateNotification instances
     * by delegating to the given visitor interface.
     */
    @Override
    public boolean dispatch(com.ossnms.bicnet.bcb.model.IVisitor visitor) throws BcbException
    {
        return visitor instanceof IVisitor
                ? ((IVisitor)visitor).onFullMediatorDataCreation(this)
                : super.dispatch(visitor);
    }

    private final FullMediatorData fullMediatorData;

    public FullMediatorDataCreateNotification(@Nonnull FullMediatorData fullMediatorData) {
        super(new Date());
        this.fullMediatorData = fullMediatorData;
    }

    @Override
    public String toString() {
        return "<" + com.ossnms.bicnet.bcb.model.platform.Notification.toString(this)
                + "fullMediatorData=" + fullMediatorData.toString() + ">";
    }

    /**
     * Obtains the BCB identifier of the Channel associated with the information in transit.
     * @return An instance of a Channel identifier.
     */
    @Override
    public IManagedObjectId affectedMO() {
        return new MediatorIdItem(fullMediatorData.getInfo().getMediatorId());
    }

    /**
     * @return The Channel information instance contained in this notification.
     */
    public FullMediatorData getFullMediatorData() {
        return fullMediatorData;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.model.platform.Notification#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final FullMediatorDataCreateNotification rhs = (FullMediatorDataCreateNotification) obj;
        return Objects.equals(getTimestamp(), rhs.getTimestamp()) &&
                fullMediatorData.equals(rhs.fullMediatorData);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.model.platform.Notification#hashCode()
     */
    @Override
    public int hashCode() {
        return Objects.hash(getTimestamp(), fullMediatorData);
    }
}
