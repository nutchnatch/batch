package com.ossnms.dcn_manager.bicnet.connector.common.servicelocator;

import javax.annotation.Nonnull;

import com.ossnms.bicnet.util.ApplicationProperties;

/**
 * Returns the configuration files to {@link ServiceLocator} class initialize the context.
 * 
 * This files will be available in deployment environment.
 */
public final class ConfigurationFiles {
    public static final String SERVICE_PROPERTIES = "/dcn-manager-services.properties";
    public static final String CALLSTYLE_PROPERTIES = "/dcn-manager-callstyle.properties";

    private ConfigurationFiles() {
    }

    @Nonnull
    public static ApplicationProperties getServicesProperties() {
        return ApplicationProperties.getInstance(SERVICE_PROPERTIES, 
                 ConfigurationFiles.class.getResourceAsStream(SERVICE_PROPERTIES));
    }

    @Nonnull
    public static ApplicationProperties getCallStyleProperties() {
        return ApplicationProperties.getInstance(CALLSTYLE_PROPERTIES,
                ConfigurationFiles.class.getResourceAsStream(CALLSTYLE_PROPERTIES));
    }
}
