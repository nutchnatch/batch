package com.ossnms.dcn_manager.bicnet.connector.common.interfaces;

import java.util.Collection;
import java.util.Map;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IMediatorFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;

public interface MediatorService extends IMediatorFacade {

    /**
     * Stores a new Mediator.
     *
     * @param mediator   Must contain minimal Mediator information, such as its type.
     * @param properties Mediator properties as set in the GUI.
     * @return A Mediator instance with the information that was actually stored.
     */
    IMediator store(ISessionContext context, IMediator mediator, Map<String, String> properties) throws BcbException;

    /**
     * Updates the changed properties
     */
    void updateProperties(ISessionContext context, IMediatorId mediatorId, Map<String, String> changedProperties) throws BcbException;

    /**
     * Gets the Mediator properties.
     */
    Map<String, String> getProperties(ISessionContext context, IMediatorId mediatorId) throws BcbException;

    /**
     * Gets all installed Mediators.
     */
    String[] getRegisteredMediatorTypes(ISessionContext sessionContext) throws BcbException;

    /**
     * Deletes a collection of Mediators.
     */
    void deleteMediators(ISessionContext sessionContext, Collection<IMediatorId> mediatorIds) throws BcbException;

    /**
     * Retrieves all mediator's full information objects
     */
    Collection<FullMediatorData> getFullMediatorList(final ISessionContext sessionContext) throws BcbException;

    /**
     * Retrieves mediator's full information objects
     */
    FullMediatorData getFullMediator(final ISessionContext sessionContext, Integer mediatorId) throws BcbException;

    /**
     * Activates the hot standby mediation connections of a given collection of Mediators.
     *
     * @param sessionContext
     * @param mediatorIds
     * @throws BcbException
     */
    void activateMediatorsOnStandbyMediation(ISessionContext sessionContext, Collection<IMediatorId> mediatorIds) throws BcbException;

    /**
     * Deactivates the hot standby mediation connections of a given collection of Mediators.
     *
     * @param sessionContext
     * @param mediatorIds
     * @throws BcbException
     */
    void deactivateMediatorsOnStandbyMediation(ISessionContext sessionContext, Collection<IMediatorId> mediatorIds) throws BcbException;
}
