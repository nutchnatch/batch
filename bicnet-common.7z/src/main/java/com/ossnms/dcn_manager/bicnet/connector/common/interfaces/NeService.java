package com.ossnms.dcn_manager.bicnet.connector.common.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;

import java.util.Collection;
import java.util.Map;

/**
 * Defines private operations against Network Elements.
 */
public interface NeService extends IFacade {

    /**
     * Create a NE under a Container
     */
    INE createNE(ISessionContext sessionContext, String neProxyType, IEMId parentEmId, INEId parentNe, IGenericContainerId genericContainerId,
            String neIdName, Property[] neProperties) throws BcbException;

    /**
     * Duplicate NE data base on template object.
     */
    void duplicate(ISessionContext sessionContext, INE template, Property[] neProperties) throws BcbException;

    /**
     * Create a NE under a System
     */
    INE createNE(ISessionContext sessionContext, String neProxyType, IEMId parentEmId, INEId parentNe, ISystemContainerId systemContainerId,
            String neIdName, Property[] neProperties) throws BcbException;

    /**
     * Used by the GUI client at startup to retrieve all NE information, including
     * all GUI-specific data that is not included in public responses.
     *
     * @return All known NEs with full information.
     */
    Collection<FullNeData> getFullNeList(ISessionContext sessionContext) throws BcbException;

    /**
     * @return NEs with full information.
     */
    FullNeData getFullNe(ISessionContext sessionContext, Integer neId) throws BcbException;

    /**
     * Gets the NE properties.
     */
    Map<String, String> getProperties(ISessionContext context, INEId neId) throws BcbException;

    /**
     * Sets NE Properties.
     */
    void updateProperties(ISessionContext sessionContext, INEId neId, Map<String, String> properties) throws BcbException;

    /**
     * Returns the list of NE types supported by the given EM type.
     *
     * @return array of NE types as strings
     */
    String[] getSupportedNeTypes(ISessionContext sessionContext, String emType) throws BcbException;

    /**
     * Delete a collection of NEs.
     */
    void deleteNEs(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException;

    /**
     * Copies known network names into the NE name of each NE.
     * Unknown NE identifiers and NEs without network names or with network names that are equal to the NE
     * names will be silently ignored.
     * Should an operation fail due to a database error on a given NE, it will be skipped and execution
     * will continue with the next NE on the collection.
     * Successful changes and failures are reported to the Command Log.
     *
     * @param neIds Collection of NE identifiers to process.
     * @throws BcbException If the operation fails due to a database error.
     */
    void copyNetworkNamesToNeNames(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException;

    /**
     * Moves Network Elements from their current channels to a different channel.
     * Moves requested to the same channel are ignored.
     * Channels must be of the same type and NEs must not be "required active".
     *
     * @param neIds           Collection of NE identifiers to process.
     * @param targetChannelId Target Channel identifier.
     * @throws BcbException If the NE or channels could not be found, the NE state is invalid, channels are
     *                      not of the same type or a database error occurs.
     */
    void moveNesToAnotherChannel(ISessionContext sessionContext, Collection<INEId> neIds, IEMId targetChannelId) throws BcbException;

    void setToActiveStateMode(ISessionContext sessionContext, INEId neId) throws BcbException;

    void setToMaintenanceMode(ISessionContext sessionContext, INEId neId) throws BcbException;

    void setToOperationalMode(ISessionContext sessionContext, INEId neId) throws BcbException;

    void writeAccessRelease(ISessionContext sessionContext, INEId neId) throws BcbException;

    void writeAccessRequest(ISessionContext sessionContext, INEId neId) throws BcbException;

    void writeAccessEnforce(ISessionContext sessionContext, INEId neId) throws BcbException;

    /**
     * @return The entire collection of known SCS synchronization states.
     */
    Iterable<ScsSynchronizationState> getScsSynchronizationStates();

    /**
     * Changes, or removes, the association of NEs to DCN Containers.
     *  @param sessionContext BiCNet session context.
     * @param associations   Pairs of NE identifiers and their new DCN Container identifiers.
     *                       The DCN Container identifier associated with a NE identifier may be zero or {@code null},
     *                       in which case any existing association will be removed. Ensure that the implementation of
     *                       Map used allows {@code null} values in this case.
     */
    void changeSystemContainerId(ISessionContext sessionContext, Map<INEId, ISystemContainerId> associations) throws BcbException;
    
    /**
     * Activates a collection of NEs in hot standby mode
     * 
     * @param sessionContext
     * @param neIds
     * @throws BcbException
     */
    void activateNesOnStandbyMediation(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException;

    /**
     * Deactivates a collection of NEs in hot standby mode
     * 
     * @param sessionContext
     * @param neIds
     * @throws BcbException
     */
    void deactivateNesOnStandbyMediation(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException;

    /**
     * Performs a data resynchronization operations on a collection of NEs in hot standby mode
     * 
     * @param sessionContext
     * @param neIds
     * @throws BcbException
     */
    void resynchronizeNesOnStandbyMediation(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException;

    /**
     * Associates nes with specified containers
     */
    void moveToContainers(ISessionContext sessionContext, Collection<INEId> neIds, Collection<IGenericContainerId> containers, IGenericContainerId primaryContainer) throws BcbException;

    /**
     * Associates nes with specified system
     */
    void moveToSystem(ISessionContext sessionContext, Collection<INEId> neIds, ISystemContainerId systemId) throws BcbException;

    /**
     * Associates nes with default container
     */
    void moveToDefaultContainer(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException;
}

