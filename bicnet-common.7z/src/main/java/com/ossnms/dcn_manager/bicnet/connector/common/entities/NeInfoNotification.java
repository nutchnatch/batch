package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IVisitable;
import com.ossnms.bicnet.bcb.model.platform.Notification;

import javax.annotation.Nonnull;
import java.util.Date;
import java.util.Objects;

/**
 * BCB notification class used to forward NE Information updates to listeners.
 */
public final class NeInfoNotification extends Notification implements IVisitable {

    private static final long serialVersionUID = -7554298797148920671L;

    /**
     * Implementation of our specific visitor pattern.
     */
    public interface IVisitor extends com.ossnms.bicnet.bcb.model.IVisitor
    {
        /**
         * Allows specific processing of NeInfoNotification instances.
         * @param arg {@link NeInfoNotification} object to be processed.
         * @return Whether the Notification has been processed.
         */
        boolean onNeInfoNotification(NeInfoNotification arg) throws BcbException;
    }

    /**
     * Performs specific processing of NeInfoNotification instances
     * by delegating to the given visitor interface.
     */
    @Override
    public boolean dispatch(com.ossnms.bicnet.bcb.model.IVisitor visitor) throws BcbException
    {
        return visitor instanceof IVisitor
                ? ((IVisitor)visitor).onNeInfoNotification(this)
                : super.dispatch(visitor);
    }

    private final NeInfo neInfo;

    public NeInfoNotification(@Nonnull NeInfo neInfo) {
        super(new Date());
        this.neInfo = neInfo;
    }

    @Override
    public String toString() {
        return "<" + com.ossnms.bicnet.bcb.model.platform.Notification.toString(this)
                + "neInfo=" + neInfo.toString() + ">";
    }

    /**
     * Obtains the BCB identifier of the NE associated with the information in transit.
     * @return An instance of an NE identifier.
     */
    @Override
    public IManagedObjectId affectedMO() {
        return new NEIdItem(neInfo.getNeId());
    }

    /**
     * @return The NE information instance contained in this notification.
     */
    public NeInfo getNeInfo() {
        return neInfo;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.model.platform.Notification#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final NeInfoNotification rhs = (NeInfoNotification) obj;
        return Objects.equals(getTimestamp(), rhs.getTimestamp()) &&
               neInfo.equals(rhs.neInfo);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.model.platform.Notification#hashCode()
     */
    @Override
    public int hashCode() {
        return Objects.hash(getTimestamp(), neInfo);
    }
}
