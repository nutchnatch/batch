package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.google.common.base.Objects;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.Optional;

/**
 * Contains GUI information about a DCN entity.
 */
public abstract class GuiInfo<T extends GuiInfo<T>> implements Serializable {

    private static final long serialVersionUID = -7371921266572393502L;

    private GuiActualActivationState guiActiveActualActivationState;
    private GuiActualActivationState guiStandbyActualActivationState;
    private String standbyDisplayState;
    private String userText;

    @Override public int hashCode() {
        return Objects.hashCode(guiActiveActualActivationState, guiStandbyActualActivationState, userText, standbyDisplayState);
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().isInstance(obj)) {
            return false;
        }
        final GuiInfo<?> rhs = (GuiInfo<?>) obj;
        return Objects.equal(guiActiveActualActivationState, rhs.guiActiveActualActivationState) &&
                Objects.equal(guiStandbyActualActivationState, rhs.guiStandbyActualActivationState) &&
                Objects.equal(standbyDisplayState, rhs.standbyDisplayState) &&
                Objects.equal(userText, rhs.userText);
    }

    protected abstract T self();

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("guiActiveActualActivationState", guiActiveActualActivationState)
                .append("guiStandbyActualActivationState", guiStandbyActualActivationState)
                .append("standbyDisplayState", standbyDisplayState)
                .append("userText", userText)
                .toString();
    }

    /**
     * Expresses the state of communication against the active connection towards this entity.
     *
     * @return The communication state, if set.
     */
    public Optional<GuiActualActivationState> getGuiActiveActualActivationState() {
        return Optional.ofNullable(guiActiveActualActivationState);
    }

    /**
     * @param guiActualActivationState The new Actual Activation State state of the active connection.
     */
    public T setGuiActualActivationState(@Nullable GuiActualActivationState guiActualActivationState) {
        this.guiActiveActualActivationState = guiActualActivationState;
        return self();
    }

    /**
     * Expresses the state of communication against the standby connection towards this entity.
     *
     * @return The communication state, if set.
     */
    public Optional<GuiActualActivationState> getGuiStandbyActualActivationState() {
        return Optional.ofNullable(guiStandbyActualActivationState);
    }

    /**
     * @param guiStandbyActualActivationState The new Actual Activation State state of the standby connection.
     */
    public T setGuiStandbyActualActivationState(@Nullable GuiActualActivationState guiStandbyActualActivationState) {
        this.guiStandbyActualActivationState = guiStandbyActualActivationState;
        return self();
    }

    /**
     * @param standbyDisplayState The new standby Display State.
     */
    public T setStandbyDisplayState(@Nullable String standbyDisplayState) {
        this.standbyDisplayState = standbyDisplayState;
        return self();
    }

    /**
     * @return The standby Display State, if set.
     */
    public Optional<String> getStandbyDisplayState() {
        return Optional.ofNullable(standbyDisplayState);
    }

    public Optional<String> getUserText() {
        return Optional.ofNullable(userText);
    }

    public T setUserText(String userText) {
        this.userText = userText;
        return self();
    }
}
