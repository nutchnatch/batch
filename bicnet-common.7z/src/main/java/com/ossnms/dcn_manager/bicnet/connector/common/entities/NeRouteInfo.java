package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

public final class NeRouteInfo implements Serializable {
    private static final long serialVersionUID = 5366088605858037620L;

    private final String domain;
    private final int cost;
    private final String gneNeighbourhoodId;

    public NeRouteInfo(String domain, int cost, String gneNeighbourhoodId) {
        this.domain = domain;
        this.cost = cost;
        this.gneNeighbourhoodId = gneNeighbourhoodId;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        NeRouteInfo that = (NeRouteInfo) o;
        return domain.equals(that.domain) && gneNeighbourhoodId.equals(that.gneNeighbourhoodId);
    }

    @Override public int hashCode() {
        int result = domain.hashCode();
        result = 31 * result + gneNeighbourhoodId.hashCode();
        return result;
    }

    @Override public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public String getDomain() {
        return domain;
    }

    public int getCost() {
        return cost;
    }

    public String getGneNeighbourhoodId() {
        return gneNeighbourhoodId;
    }
}
