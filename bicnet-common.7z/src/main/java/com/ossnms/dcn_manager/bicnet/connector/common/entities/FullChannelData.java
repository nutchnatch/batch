package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import java.io.Serializable;

/**
 * Aggregator of all Channel information. Used to reduce the number of requests
 * issued by the GUI client.
 */
public final class FullChannelData implements Serializable {

    private static final long serialVersionUID = 4910608254567457106L;

    private final IEM channel;
    private final ChannelInfo info;

    /**
     * Creates a new object.
     * @param em Public BCB EM data.
     * @param info Private Channel information.
     */
    public FullChannelData(@Nonnull IEM em, @Nonnull ChannelInfo info) {
        this.channel = em;
        this.info = info;
    }

    /**
     * @return Public BCB Channel data.
     */
    public IEM getChannel() {
        return channel;
    }

    /**
     * @return the Channel Name.
     */
    public String getIdName() {
        return channel.getIdName();
    }

    /**
     * @return Private Channel information.
     */
    public ChannelInfo getInfo() {
        return info;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }

        FullChannelData that = (FullChannelData) o;

        return channel.equals(that.channel);

    }

    @Override
    public int hashCode() {
        return channel.hashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("channel", channel)
                .append("info", info)
                .toString();
    }
}
