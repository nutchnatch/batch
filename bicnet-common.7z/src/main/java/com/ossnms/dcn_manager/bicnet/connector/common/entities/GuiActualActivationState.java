package com.ossnms.dcn_manager.bicnet.connector.common.entities;

/**
 * Actual Activation state for the GUI actions against the Entity.
 * It has the respective priority value.
 */
public enum GuiActualActivationState {
    ACTIVE			(10),
    INACTIVE		(2),
    ACTIVATING		(7),
    DEACTIVATING	(5),
    FAILED			(3),
    STARTINGUP		(6),
    SHUTTINGDOWN	(4),
    NONE			(1000),
    DEACTIVATED		(1),
    SYNCHRONIZING	(8),
    OUT_OF_SYNCH	(9);
	
	private final int priority;
	
	GuiActualActivationState(int priority) {
		this.priority = priority;
	}
	
	public int getPriority() {
		return priority;
	}
	
	public boolean hasLowerPriorityThan( GuiActualActivationState state ) {
		return this.priority < state.priority;
	}
}
