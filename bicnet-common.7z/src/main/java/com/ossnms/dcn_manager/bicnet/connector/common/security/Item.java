package com.ossnms.dcn_manager.bicnet.connector.common.security;

/**
 * Base class for {@link Menu} and {@link Action}.
 * Facilitates transformation of their fluent API into a string
 * that can be exposed to Bicnet.
 */
abstract class Item {

    private final Item parent;
    private final String name;

    Item(Item parent, String name) {
        this.parent = parent;
        this.name = name;
    }

    Item(String name) {
        this.parent = null;
        this.name = name;
    }

    @Override
    public String toString() {
        return parent != null ? parent.toString() + "->" + name : name;
    }
}