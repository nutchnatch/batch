package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.google.common.base.Objects;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;
import java.io.Serializable;

import static com.ossnms.dcn_manager.bicnet.connector.common.entities.NeStatusInfo.Status.IDLE;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.NeStatusInfo.Status.IN_OPERATION;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.NeStatusInfo.Status.UNDER_MAINTENANCE;

/**
 * GUI assistant holding NE info data supporting ne data gui info.
 */
@Immutable
public final class NeStatusInfo implements Serializable {

    private static final long serialVersionUID = -7991503621491318697L;

    private final int neId;
    private final Status info;

    public enum Status {
        UNDER_MAINTENANCE("Under Maintenance",100),
        IDLE("Idle", 200),
        IN_OPERATION("In Operation", 300);

        private final String name;
        private final int priority;

        Status(String name, int priority) {
            this.name = name;
            this.priority = priority;
        }

        public String getName() {
            return name;
        }

        public int getPriority() {
            return priority;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    /**
     * Creates a new instance.
     *
     * @param neId NE identifier.
     * @param operationalState state on the NE
     * @param eventForwarding state on the NE
     */
    public NeStatusInfo(int neId, @Nonnull OperationalState operationalState, @Nonnull EnableSwitch eventForwarding) {
        this.neId = neId;
        this.info = produceInfo(operationalState, eventForwarding);
    }

    /**
     * Creates a new instance.
     *
     * @param ne the NE
     */
    public NeStatusInfo(FullNeData ne) {
        this(ne.getNe().getId(), ne.getNe().getOperationalState(), ne.getNe().getEventForwarding());
    }

    /**
     * @return Human-readable information about the current NE status info
     */
    public Status getInfo() {
        return info;
    }

    private Status produceInfo(@Nonnull OperationalState operationalState, @Nonnull EnableSwitch eventForwarding) {
        
        if(EnableSwitch.DISABLED.equals(eventForwarding)) {
            return UNDER_MAINTENANCE;
        }
        
        if(OperationalState.DISABLED.equals(operationalState)) {
            return IDLE;
        }
        
        return IN_OPERATION;
    }

    /**
     * @return NE identifier.
     */
    public int getNeId() {
        return neId;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return Objects.hashCode(neId, info);
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || getClass() != obj.getClass()) {
            return false;
        }
        final NeStatusInfo rhs = (NeStatusInfo) obj;
        return neId == rhs.neId && Objects.equal(info, rhs.info);
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("neId", neId)
                .append("info", info)
                .toString();
    }
}
