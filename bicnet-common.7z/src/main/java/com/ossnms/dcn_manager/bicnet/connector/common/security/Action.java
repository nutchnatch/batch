package com.ossnms.dcn_manager.bicnet.connector.common.security;

/**
 * Represents a secure action.
 * May be used standalone or as a child of a Menu.
 */
final class Action extends Item {

    Action(Menu parent, String name) {
        super(parent, name);
    }

    Action(String name) {
        super(name);
    }

    static Action action(String name) {
        return new Action(name);
    }
}