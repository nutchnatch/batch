package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.google.common.base.Objects;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.Optional;

/**
 * Contains GUI Mediator Information.
 */
public final class MediatorInfo extends GuiInfo<MediatorInfo> implements Serializable {

    private static final long serialVersionUID = -3952935487369527932L;

    private final int mediatorId;
    private Boolean standbyMediatorConfigured;

    /**
     * @param mediatorId Identifier of the Mediator that owns this information.
     */
    public MediatorInfo(int mediatorId) {
    	this.mediatorId = mediatorId;
    }

    /**
     * @param mediatorId Identifier of the Mediator that owns this information.
     * @param  standbyMediatorConfigured true when secondary host is defined
     */
    public MediatorInfo(int mediatorId, Boolean standbyMediatorConfigured) {
        this.mediatorId = mediatorId;
        this.standbyMediatorConfigured = standbyMediatorConfigured;
    }


    @Override
    protected MediatorInfo self() {
        return this;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(mediatorId, standbyMediatorConfigured, super.hashCode());
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || getClass() != obj.getClass()) {
            return false;
        }
        final MediatorInfo rhs = (MediatorInfo) obj;
        return mediatorId == rhs.mediatorId &&
                (standbyMediatorConfigured != null && standbyMediatorConfigured.equals(rhs.standbyMediatorConfigured)) &&                
                super.equals(obj);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("mediatorId", mediatorId)
                .append("standbyMediatorConfigured", standbyMediatorConfigured)
                .appendSuper(super.toString())
                .toString();
    }

    /**
     * @return The Mediator identifier.
     */
    public int getMediatorId() {
        return mediatorId;
    }

    /**
     * @param standbyMediatorConfigured New configuration state for the standby mediator.
     */
    public MediatorInfo setStandbyMediatorConfigured(Boolean standbyMediatorConfigured) {
        this.standbyMediatorConfigured = standbyMediatorConfigured;
        return self();
    }

    /**
     * @return Whether the standby mediator is configured.
     */
    public Optional<Boolean> isStandbyMediatorConfigured() {
    	return Optional.ofNullable(standbyMediatorConfigured);
    }

}
