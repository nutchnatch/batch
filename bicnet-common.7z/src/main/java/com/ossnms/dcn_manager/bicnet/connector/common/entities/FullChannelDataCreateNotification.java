package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IVisitable;
import com.ossnms.bicnet.bcb.model.platform.Notification;

import javax.annotation.Nonnull;
import java.util.Date;
import java.util.Objects;

/**
 * BCB notification class used to forward Channel Information updates to listeners.
 */
public final class FullChannelDataCreateNotification extends Notification implements IVisitable {

    private static final long serialVersionUID = -6441909422073635259L;

    /**
     * Implementation of our specific visitor pattern.
     */
    public interface IVisitor extends com.ossnms.bicnet.bcb.model.IVisitor
    {
        /**
         * Allows specific processing of FullChannelDataCreateNotification instances.
         * @param arg {@link FullChannelDataCreateNotification} object to be processed.
         * @return Whether the Notification has been processed.
         */
        boolean onFullChannelDataCreation(FullChannelDataCreateNotification arg) throws BcbException;
    }

    /**
     * Performs specific processing of FullChannelDataCreateNotification instances
     * by delegating to the given visitor interface.
     */
    @Override
    public boolean dispatch(com.ossnms.bicnet.bcb.model.IVisitor visitor) throws BcbException
    {
        return visitor instanceof IVisitor
                ? ((IVisitor)visitor).onFullChannelDataCreation(this)
                : super.dispatch(visitor);
    }

    private final FullChannelData fullChannelData;

    public FullChannelDataCreateNotification(@Nonnull FullChannelData fullChannelData) {
        super(new Date());
        this.fullChannelData = fullChannelData;
    }

    @Override
    public String toString() {
        return "<" + com.ossnms.bicnet.bcb.model.platform.Notification.toString(this)
                + "fullChannelData=" + fullChannelData.toString() + ">";
    }

    /**
     * Obtains the BCB identifier of the Channel associated with the information in transit.
     * @return An instance of a Channel identifier.
     */
    @Override
    public IManagedObjectId affectedMO() {
        return new EMIdItem(fullChannelData.getInfo().getChannelId());
    }

    /**
     * @return The Channel information instance contained in this notification.
     */
    public FullChannelData getFullChannelData() {
        return fullChannelData;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.model.platform.Notification#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final FullChannelDataCreateNotification rhs = (FullChannelDataCreateNotification) obj;
        return Objects.equals(getTimestamp(), rhs.getTimestamp()) &&
                fullChannelData.equals(rhs.fullChannelData);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.model.platform.Notification#hashCode()
     */
    @Override
    public int hashCode() {
        return Objects.hash(getTimestamp(), fullChannelData);
    }
}
