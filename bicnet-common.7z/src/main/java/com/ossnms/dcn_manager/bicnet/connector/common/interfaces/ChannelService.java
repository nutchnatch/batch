package com.ossnms.dcn_manager.bicnet.connector.common.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;

import java.util.Collection;
import java.util.Map;

public interface ChannelService extends IFacade {

    /**
     * Used by the GUI client at startup to retrieve all Channel information, including
     * all GUI-specific data that is not included in public responses.
     *
     * @return All known Channels with full information.
     */
    Collection<FullChannelData> getFullChannelList(ISessionContext sessionContext) throws BcbException;

    /**
     * Used by the GUI client to retrieve Channel information, including
     * all GUI-specific data that is not included in public responses.
     */
    FullChannelData getFullChannel(ISessionContext sessionContext, Integer channelId) throws BcbException;

    /**
     * Gets the Channel properties.
     */
    Map<String, String> getProperties(ISessionContext context, IEMId channelId) throws BcbException;

    /**
     * Sets Channel Properties.
     */
    void updateProperties(ISessionContext sessionContext, IEMId emId, Map<String, String> properties) throws BcbException;

    /**
     * Creates a new Channel.
     */
    IEM createEM(ISessionContext sessionContext, String emType, String emIdName, IMediatorId mediatorId, Property[] emProperties) throws BcbException;

    /**
     * Gets all available Channel types under a specific type of Mediator.
     *
     * @param sessionContext BiCNet session context.
     * @param mediatorType   Name of the Mediator type the request refers to.
     * @return An array of strings with Channel type names. May be empty but never null.
     */
    String[] getRegisteredEmTypes(ISessionContext sessionContext, String mediatorType) throws BcbException;

    /**
     * Gets all available Channel types under all Mediator types.
     *
     * @param sessionContext BiCNet session context.
     * @return An array of strings with Channel type names. May be empty but never null.
     */
    String[] getRegisteredEmTypes(ISessionContext sessionContext) throws BcbException;

    /**
     * Deletes a collection of Channels
     */
    void deleteChannels(ISessionContext sessionContext, Collection<IEMId> mediatorType) throws BcbException;
    
    /**
     * Activates a collection of channels on hot standby mode
     * 
     * @param sessionContext
     * @param channelIds
     * @throws BcbException
     */
    void activateChannelsOnStandbyMediation(ISessionContext sessionContext, Collection<IEMId> channelIds) throws BcbException;

    /**
     * Deactivates a collection of channels on hot standby mode
     * 
     * @param sessionContext
     * @param channelIds
     * @throws BcbException
     */
    void deactivateChannelsOnStandbyMediation(ISessionContext sessionContext, Collection<IEMId> channelIds) throws BcbException;

    void moveChannelsToAnotherMediators(ISessionContext sessionContext, Collection<IEMId> emIds, IMediatorId targetMediatorId)
            throws BcbException;
    
}
