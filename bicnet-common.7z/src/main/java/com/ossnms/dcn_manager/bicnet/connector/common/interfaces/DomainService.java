package com.ossnms.dcn_manager.bicnet.connector.common.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IASId;

/**
 * Contract for "private" facade beans that handle AS/EON/Domains.
 */
public interface DomainService extends IFacade {

    /**
     * Finds and returns the AS with the given {@code domainId}.
     * @param sessionContext the session context is passed as 1st parameter in every facade method.
     * @param domainId the identifier of the requested Domain instance.
     */
    IAS getSingleAS(ISessionContext sessionContext, IASId domainId) throws BcbException;

    /**
     * Gets all installed Domains.
     *
     * @param sessionContext the session context is passed as 1st parameter in every facade method.
     * @return An array of all known Domains.
     */
    IAS[] getASList(ISessionContext sessionContext) throws BcbException;

    /**
     * Changes whether newly discovered NEs within a domain are activated automatically,
     * when the global discovery policy is set to Domain.
     *
     * @param sessionContext the session context is passed as 1st parameter in every facade method.
     * @param domainIds identifier of affected Domain instances.
     * @param allow whether newly discovered NEs within the domains are activated automatically.
     */
    void setAutomaticNeActivationPolicy(ISessionContext sessionContext, IASId[] domainIds, boolean allow) throws BcbException;
}
