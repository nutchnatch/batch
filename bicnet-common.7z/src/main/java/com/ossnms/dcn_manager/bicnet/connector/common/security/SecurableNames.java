package com.ossnms.dcn_manager.bicnet.connector.common.security;

/**
 * A collection of names that can be reused as menu names.
 */
enum SecurableNames {

    DCN("DCN"),
    NETWORK("Network"),
    IMPORT_FROM_CORE("Import From Core"),
    ADMINISTRATION("Administration"),
    EXPORT_CONFIGURATION("Export Configuration"),
    IMPORT_CONFIGURATION("Import Configuration"),
    FILE("File"),
    MAINTENANCE_MODE("Maintenance Mode"),
    ACCESS_CONTROL("Access Control"),
    OBJECT_CONTEXT_MENU("Object Context Menu");

    private final String name;

    private SecurableNames(String name) {
        this.name = name;
    }

    public String getValue() {
        return name;
    }

}
