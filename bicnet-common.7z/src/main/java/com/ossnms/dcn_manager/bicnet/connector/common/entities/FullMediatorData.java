package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import java.io.Serializable;
import java.util.Objects;

/**
 * Aggregator of all Mediator information. Used to reduce the number of requests
 * issued by the GUI client.
 */
public final class FullMediatorData implements Serializable {

    private static final long serialVersionUID = -9220027189153862636L;

    private final IMediator mediator;
    private final MediatorInfo info;

    /**
     * Creates a new object.
     * @param mediator Public BCB Mediator data.
     * @param info Private Mediator information.
     */
    public FullMediatorData(@Nonnull IMediator mediator, @Nonnull MediatorInfo info) {
        this.mediator = mediator;
        this.info = info;
    }

    /**
     * @return Public BCB Mediator data.
     */
    public IMediator getMediator() {
        return mediator;
    }

    /**
     * @return Private Mediator information.
     */
    public MediatorInfo getInfo() {
        return info;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }

        FullMediatorData that = (FullMediatorData) o;

        return Objects.equals(mediator,that.mediator);
    }

    /**
     * @return the Mediator Name.
     */
    public String getIdName() {
        return getMediator().getIdName();
    }

    @Override
    public int hashCode() {
        return mediator != null ? mediator.hashCode() : 0;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("mediator", mediator)
                .append("info", info)
                .toString();
    }
}
