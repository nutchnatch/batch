package com.ossnms.dcn_manager.bicnet.connector.common.interfaces;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.ISystemContainerFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;

import javax.annotation.Nonnull;
import java.util.Collection;

/**
 * Private access point for System Container management.
 */
public interface SystemContainerService extends ISystemContainerFacade {

    /**
     * Delete zero or more System containers in one swoop.
     *
     * @param sessionContext     BiCNet session context.
     * @param systemContainerIds All {@link ISystemContainerId} instances representing
     *                           System Containers to delete.
     * @throws BcbException
     */
    void deleteSystemContainers(@Nonnull final ISessionContext sessionContext,
            @Nonnull final Collection<ISystemContainerId> systemContainerIds) throws BcbException;

    /**
     * Create a new System Container inside a NE Container.
     *
     * @param sessionContext BiCNet session context.
     * @param systemContainer System container to be created.
     * @param genericContainerId The parent Generic container.
     * @return
     * @throws BcbException
     */
    ISystemContainer createSystemContainer(@Nonnull final ISessionContext sessionContext,
            @Nonnull final ISystemContainer systemContainer, @Nonnull final IGenericContainerId genericContainerId)
            throws BcbException;

    /**
     * Associate systems with specified containers
     */
    void moveToContainers(ISessionContext sessionContext, Collection<ISystemContainerId> systems, IGenericContainerId primaryContainer, Collection<IGenericContainerId> containers) throws BcbException;
}
