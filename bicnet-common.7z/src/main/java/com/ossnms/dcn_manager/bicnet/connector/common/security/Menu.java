package com.ossnms.dcn_manager.bicnet.connector.common.security;

/**
 * <p>Represents a "menu", i.e., a sequence element in a securable action.
 * For example, A and B are "menus" in the action identifier <code>A-&gt;B-&gt;C</code>.</p>
 */
final class Menu extends Item {

    Menu(SecurableNames name) {
        super(name.getValue());
    }

    Menu(Menu parent, SecurableNames name) {
        super(parent, name.getValue());
    }

    Menu subMenu(SecurableNames name) {
        return new Menu(this, name);
    }

    Action action(String name) {
        return new Action(this, name);
    }

    static Menu menu(SecurableNames name) {
        return new Menu(name);
    }
}