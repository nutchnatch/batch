package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IVisitable;
import com.ossnms.bicnet.bcb.model.platform.Notification;

import javax.annotation.Nonnull;
import java.util.Date;
import java.util.Objects;

/**
 * BCB notification class used to forward SCS synchronization states to listeners.
 */
public final class ScsSynchronizationStateNotification extends Notification implements IVisitable {

    private static final long serialVersionUID = -2785332501568068158L;

    /**
     * Implementation of our specific visitor pattern.
     */
    public interface IVisitor extends com.ossnms.bicnet.bcb.model.IVisitor
    {
        /**
         * Allows specific processing of ScsSynchronizationStateNotification instances.
         * @param arg {@link ScsSynchronizationStateNotification} object to be processed.
         * @return Whether the Notification has been processed.
         */
        boolean onScsSynchronizationStateNotification(ScsSynchronizationStateNotification arg) throws BcbException;
    }

    /**
     * Performs specific processing of ScsSynchronizationStateNotification instances
     * by delegating to the given visitor interface.
     */
    @Override
    public boolean dispatch(com.ossnms.bicnet.bcb.model.IVisitor visitor) throws BcbException
    {
        return visitor instanceof IVisitor
                ? ((IVisitor)visitor).onScsSynchronizationStateNotification(this)
                : super.dispatch(visitor);
    }

    private final ScsSynchronizationState synchronizationState;

    public ScsSynchronizationStateNotification(@Nonnull ScsSynchronizationState synchronizationState) {
        super(new Date());
        this.synchronizationState = synchronizationState;
    }

    @Override
    public String toString() {
        return "<" + com.ossnms.bicnet.bcb.model.platform.Notification.toString(this)
                + "synchronizationState=" + synchronizationState.toString() + ">";
    }

    /**
     * Obtains the BCB identifier of the NE associated with the synchronization state.
     * @return An instance of an NE identifier.
     */
    @Override
    public IManagedObjectId affectedMO() {
        return new NEIdItem(synchronizationState.getNeId());
    }

    /**
     * @return SCS synchronization state.
     */
    public ScsSynchronizationState getSynchronizationState() {
        return synchronizationState;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.model.platform.Notification#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final ScsSynchronizationStateNotification rhs = (ScsSynchronizationStateNotification) obj;
        return Objects.equals(getTimestamp(), rhs.getTimestamp()) &&
               synchronizationState.equals(rhs.synchronizationState);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.model.platform.Notification#hashCode()
     */
    @Override
    public int hashCode() {
        return Objects.hash(getTimestamp(), synchronizationState);
    }
}
