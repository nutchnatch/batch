package com.ossnms.dcn_manager.bicnet.connector.common.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.Channel;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.GenericContainer;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.Mediator;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.NetworkElement;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.SystemContainer;

import java.util.Collection;

public interface ImportExportService extends IFacade {

    /**
     * Produces a collection of mediators prepared for export
     *
     * @param mediators requested collection of mediators to export
     */
    Collection<Mediator> exportMediators(ISessionContext sessionContext, Collection<IMediator> mediators);

    /**
     * Produces a collection of channels prepared for export
     *
     * @param ems requested collection of channels to export
     */
    Collection<Channel> exportChannels(ISessionContext sessionContext, Collection<IEM> ems);

    /**
     * Produces a collection of nes prepared for export
     *
     * @param nes requested collection of nes to export
     */
    Collection<NetworkElement> exportNes(ISessionContext sessionContext, Collection<INE> nes);

    /**
     * Produces a collection of all containers prepared for export
     */
    Collection<GenericContainer> exportContainers(ISessionContext sessionContext);

    /**
     * Produces a collection of all systems prepared for export
     */
    Collection<SystemContainer> exportSystems(ISessionContext sessionContext);

    /**
     * Imports provided mediators
     *
     * @return collection of messages for user (warning, errors)
     */
    Collection<String> importMediators(ISessionContext sessionContext, Collection<Mediator> mediators);

    /**
     * Imports provided channels
     *
     * @return collection of messages for user (warning, errors)
     */
    Collection<String> importChannels(ISessionContext sessionContext, Collection<Channel> channels);

    /**
     * Imports provided nes
     *
     * @param importSftp flat whether to import SFTP/FTP settings in NE properties
     * @return collection of messages for user (warning, errors)
     */
    Collection<String> importNes(ISessionContext sessionContext, Collection<NetworkElement> networkElements, boolean importSftp);

    /**
     * Imports provided containers
     *
     * @return collection of messages for user (warning, errors)
     */
    Collection<String> importContainers(ISessionContext sessionContext, Collection<GenericContainer> containers);

    /**
     * Imports provided systems
     *
     * @return collection of messages for user (warning, errors)
     */
    Collection<String> importSystems(ISessionContext sessionContext, Collection<SystemContainer> systems);
}
