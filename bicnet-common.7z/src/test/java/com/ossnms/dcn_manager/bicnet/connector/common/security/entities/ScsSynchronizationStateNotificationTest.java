package com.ossnms.dcn_manager.bicnet.connector.common.security.entities;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationStateNotification;
import org.junit.Test;

import java.util.Date;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ScsSynchronizationStateNotificationTest {

    @Test
    public void equals() throws Exception {
        final Date timestamp = new Date(3);
        final Date timestamp2 = new Date(2);
        final ScsSynchronizationState state1 = new ScsSynchronizationState(1, ScsSyncState.SYNCHRONIZED);
        final ScsSynchronizationState state2 = new ScsSynchronizationState(2, ScsSyncState.SYNCHRONIZED, "blah");

        ScsSynchronizationStateNotification notification;
        ScsSynchronizationStateNotification notification2;

        notification = new ScsSynchronizationStateNotification(state1);
        assertThat(notification, not(is(equalTo(null))));
        assertThat(notification, not(is(equalTo((Object) "something else"))));

        notification = new ScsSynchronizationStateNotification(state1);
        notification.setTimestamp(timestamp);
        notification2 = new ScsSynchronizationStateNotification(state2);
        notification2.setTimestamp(timestamp);
        assertThat(notification, not(is(equalTo(notification2))));
        assertThat(notification.hashCode(), not(is(notification2.hashCode())));

        notification = new ScsSynchronizationStateNotification(state1);
        notification.setTimestamp(timestamp);
        notification2 = new ScsSynchronizationStateNotification(state2);
        notification2.setTimestamp(timestamp2);
        assertThat(notification, not(is(equalTo(notification2))));
        assertThat(notification.hashCode(), not(is(notification2.hashCode())));

        notification = new ScsSynchronizationStateNotification(state1);
        notification.setTimestamp(timestamp);
        notification2 = new ScsSynchronizationStateNotification(state1);
        notification2.setTimestamp(timestamp);
        assertThat(notification, is(equalTo(notification)));
        assertThat(notification, is(equalTo(notification2)));
        assertThat(notification.hashCode(), is(notification2.hashCode()));
    }

    @Test
    public void managedObjectIdentifier() throws Exception {
        final ScsSynchronizationState state = new ScsSynchronizationState(1, ScsSyncState.SYNCHRONIZED);

        final ScsSynchronizationStateNotification notification = new ScsSynchronizationStateNotification(state);

        assertThat(notification.affectedMO(), is((IManagedObjectId) new NEIdItem(state.getNeId())));
    }

    @Test
    public void notificationData() throws Exception {
        final ScsSynchronizationState state = new ScsSynchronizationState(1, ScsSyncState.SYNCHRONIZED);

        final ScsSynchronizationStateNotification notification = new ScsSynchronizationStateNotification(state);

        assertThat(notification.getSynchronizationState(), is(state));
    }

    @Test
    public void specificVisitor() throws Exception {
        final ScsSynchronizationState state = new ScsSynchronizationState(1, ScsSyncState.SYNCHRONIZED);
        final ScsSynchronizationStateNotification notification = new ScsSynchronizationStateNotification(state);

        final ScsSynchronizationStateNotification.IVisitor visitor = mock(ScsSynchronizationStateNotification.IVisitor.class);
        when(visitor.onScsSynchronizationStateNotification(isA(ScsSynchronizationStateNotification.class))).thenReturn(true);

        final boolean visitResult = notification.dispatch(visitor);

        verify(visitor).onScsSynchronizationStateNotification(notification);
        assertThat(visitResult, is(true));
    }

    @Test
    public void notificationVisitor() throws Exception {
        final ScsSynchronizationState state = new ScsSynchronizationState(1, ScsSyncState.SYNCHRONIZED);
        final ScsSynchronizationStateNotification notification = new ScsSynchronizationStateNotification(state);

        final Notification.IVisitor visitor = mock(Notification.IVisitor.class);
        when(visitor.onNotification(isA(Notification.class))).thenReturn(true);

        final boolean visitResult = notification.dispatch(visitor);

        verify(visitor).onNotification(notification);
        assertThat(visitResult, is(true));
    }

}
