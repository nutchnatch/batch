#!/bin/bash

DIRNAME=`dirname $0`
TSP="sugar"
TSP_NAME="Sugar"

. $DIRNAME/$TSP.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/$TSP-prssrv-env.sh

. $DIRNAME/dependencies/standalone.sh

removeModule sugar-arender-hmi "Sugar ARender HMI"

removeApache

removeJDK

if ! $CYGWIN; then
	CLEANUP="$(package-cleanup --leaves -q)"
	[ -n "$CLEANUP" ] && yum -y -q remove $CLEANUP
fi

ECHO "Sugar ARender HMI Server successfully removed."
exit 0