#!/bin/bash

TSP=sugar
SSH_USER=${SSH_USER:-"$TSP"}
SSH_PATH=${SSH_PATH:-"/home/$SSH_USER/software-tsp"}
ENV=${ENV:-"$1"}
DIRNAME=`dirname $0`

. $DIRNAME/$TSP.conf.$ENV

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/checkflows.sh

buildFlows() {
	URL_INFO=$(parseURL $SESAME_SERVICES_URL)
	SESAME=$(echo $URL_INFO | cut -f2 -d' ')
	SESAME_PORT=$(getPort $URL_INFO)
	IDX=1
	for SRV in $(echo -n $SUGAR_SERVICES_NODES)
	do
		echo "$SRV,$ORACLE_NODE,$ORACLE_PORT,service${IDX}->oracle1"
		if test $ORACLE_DATAGUARD = true; then
			echo "$SRV,$ORACLE_DATAGUARD_STANDBY_NODE,$ORACLE_PORT,service${IDX}->oracle2"
		fi
		echo "$SRV,$SESAME,$SESAME_PORT,service${IDX}->sesame"
		IDX2=1
		for SRV2 in $(echo -n $SUGAR_SERVICES_NODES)
		do
			if [ "$SRV" != "$SRV2" ]; then
				echo "$SRV,$SRV2,$SUGAR_SERVICES_EHCACHE_PORT,svc_ehcache${IDX}->svc_ehcache${IDX2}"
			fi
			IDX2=$(expr $IDX2 + 1)
		done
		IDX=$(expr $IDX + 1)
	done

	URL_INFO=$(parseURL $SUGAR_SERVICES_URL)
	SVC=$(echo $URL_INFO | cut -f2 -d' ')
	SVC_PORT=$(getPort $URL_INFO)
	IDX=1
	for SRV in $(echo -n $SUGAR_ARENDER_NODES)
	do
		echo "$SRV,$SVC,$SVC_PORT,arender${IDX}->services"
		IDX=$(expr $IDX + 1)
	done

	IDX=1
	for SRV in $(echo -n $SUGAR_USAGE_NODES)
	do
		echo "$SRV,$SVC,$SVC_PORT,usage${IDX}->services"
		echo "$SRV,$SESAME,$SESAME_PORT,usage${IDX}->sesame"
		IDX2=1
		for ARENDER in $(echo -n $SUGAR_ARENDER_NODES)
		do
			echo "$SRV,$ARENDER,$SUGAR_ARENDER_PORT,usage${IDX}->arender${IDX2}"
			IDX2=$(expr $IDX2 + 1)
		done
		IDX=$(expr $IDX + 1)
	done

	IDX=1
	for ARENDER in $(echo -n $SUGAR_ARENDER_NODES)
	do
		echo "$ARENDER,$SVC,$SVC_PORT,arender${IDX}->services"
		echo "$ARENDER,$ORACLE_NODE,$ORACLE_PORT,arender${IDX}->oracle1"
		if test $ORACLE_DATAGUARD = true; then
			echo "$ARENDER,$ORACLE_DATAGUARD_STANDBY_NODE,$ORACLE_PORT,arender${IDX}->oracle2"
		fi
		IDX=$(expr $IDX + 1)
	done

	if test $ORACLE_DATAGUARD = true; then
		echo "$ORACLE_NODE,$ORACLE_DATAGUARD_STANDBY_NODE,$ORACLE_PORT,oracle1->oracle2"
		echo "$ORACLE_DATAGUARD_STANDBY_NODE,$ORACLE_NODE,$ORACLE_PORT,oracle2->oracle1"
	fi
}

checkFlows

exit 0