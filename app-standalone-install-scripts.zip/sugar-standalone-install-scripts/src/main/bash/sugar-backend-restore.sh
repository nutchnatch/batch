#!/bin/bash

DIRNAME=`dirname $0`
TSP="sugar"
TSP_NAME="Sugar"

. $DIRNAME/$TSP.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/$TSP-appsrv-env.sh

. $DIRNAME/dependencies/standalone.sh

BACKUP_DIR="$TSP_BACKUP_DIR/clm"
echo ""
echo "Available backups for CLM"
IDX=1
for VERSION in $(ls $BACKUP_DIR)
do
	echo "$IDX) $VERSION"
	IDX=$(expr $IDX + 1)
done
printf "Enter the backup number to restore it, or press enter to quit: "
read CHOICE

if [ -n "$CHOICE" -a "$CHOICE" -gt "0" -a "$CHOICE" -lt "$IDX" ] 2>/dev/null; then
	IDX=1
	for VERSION in $(ls $BACKUP_DIR)
	do
		if [ "$IDX" -eq "$CHOICE" ]; then
			break;
		fi
		IDX=$(expr $IDX + 1)
	done
	echo ""
	ECHO "Restoration of CLM to version $VERSION"
	rm -rf ${TSP_HOME}/clm 1>> $LOG_FILE 2>&1
	checkReturnCode $? "Error while deleting old CLM directory ${TSP_HOME}/clm"
	tar xzvf ${BACKUP_DIR}/${VERSION}/clm.tar.gz -C ${TSP_HOME} 1>> $LOG_FILE 2>&1
	checkReturnCode $? "Error while restoring CLM"
	chown sugar-appsrv:sugar ${TSP_HOME}/clm
	checkReturnCode $? "Error while restoring CLM"
	rm -rf ${BACKUP_DIR}/${VERSION} 1>> $LOG_FILE 2>&1
	checkReturnCode $? "Error while deleting CLM backup"
	ECHO "Done"
fi

BACKUP_DIR="$TSP_BACKUP_DIR/sugar-logstash"
echo ""
echo "Available backups for LogStash"
IDX=1
for VERSION in $(ls $BACKUP_DIR)
do
	echo "$IDX) $VERSION"
	IDX=$(expr $IDX + 1)
done
printf "Enter the backup number to restore it, or press enter to quit: "
read CHOICE

if [ -n "$CHOICE" -a "$CHOICE" -gt "0" -a "$CHOICE" -lt "$IDX" ] 2>/dev/null; then
	IDX=1
	for VERSION in $(ls $BACKUP_DIR)
	do
		if [ "$IDX" -eq "$CHOICE" ]; then
			break;
		fi
		IDX=$(expr $IDX + 1)
	done
	echo ""
	ECHO "Restoration of LogStash to version $VERSION"
	rm -rf ${TSP_HOME}/sugar-logstash 1>> $LOG_FILE 2>&1
	checkReturnCode $? "Error while deleting old LogStash directory ${TSP_HOME}/sugar-logstash"
	tar xzvf ${BACKUP_DIR}/${VERSION}/sugar-logstash.tar.gz -C ${TSP_HOME} 1>> $LOG_FILE 2>&1
	checkReturnCode $? "Error while restoring LogStash"
	chown sugar-appsrv:sugar ${TSP_HOME}/sugar-logstash
	checkReturnCode $? "Error while restoring LogStash"
	rm -rf ${BACKUP_DIR}/${VERSION} 1>> $LOG_FILE 2>&1
	checkReturnCode $? "Error while deleting LogStash backup"
	ECHO "Done"
fi

restoreModule $TSP-backend "$TSP_NAME Backend"

ECHO "$TSP_NAME Backend Server successfully restored."
exit 0