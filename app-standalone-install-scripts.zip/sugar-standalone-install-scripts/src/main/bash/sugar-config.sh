#!/bin/bash

TSP=sugar
SSH_USER=${SSH_USER:-"$TSP"}
SSH_PATH=${SSH_PATH:-"/home/$SSH_USER/software-tsp"}
SERVERS=${1:-"$TSP-servers.csv"}
ENV="${SERVERS##*.}"
DIRNAME=`dirname $0`

. $DIRNAME/$TSP.conf.$ENV

. $DIRNAME/dependencies/config.sh

. $DIRNAME/dependencies/$TSP-prssrv-env.sh

. $DIRNAME/dependencies/$TSP-appsrv-env.sh

for LINE in $(cat $SERVERS | sort)
do
	TYPE=$(echo -n $LINE | cut -d',' -f1)
	SERVER=$(echo -n $LINE | cut -d',' -f2)
	CONFIG_FILE=${SERVER}.conf

	ssh -q -l $SSH_USER -t $SERVER "$(cat <<SSH
#(declare -f getSystemInfo | tail -n +3 | head -n -1)
$(getSystemInfo)
case "$TYPE" in
	DBSrv)
		$(getOracleInfo)
	;;
	PresSrv)
		$(getModuleInfo sugar-usage)
		$(getModuleConf sugar-usage)
	;;
	AppSrv)
		$(getModuleInfo sugar-services)
		$(getModuleConf sugar-services)
	;;
	ArenderSrv)
		$(getModuleInfo arender)
		printTitle "Module arender configuration"
		echo "find ${TSP_HOME}/arender/conf/ -type f -exec echo \; -exec echo \"# {}\" \; -exec cat {} \;"
		echo "echo"
	;;
esac
SSH
)" > $CONFIG_FILE
done
