#!/bin/bash

TSP=sugar
SSH_USER=${SSH_USER:-"$TSP"}
SSH_PATH=${SSH_PATH:-"/home/${SSH_USER}/software-tsp"}
SERVERS=${1:-"$TSP-servers.csv"}

for LINE in $(cat $SERVERS | sort)
do
	TYPE=$(echo -n $LINE | cut -d',' -f1)
	SERVER=$(echo -n $LINE | cut -d',' -f2)
	case "$TYPE" in
		DBSrv)
			INCLUDE="--include=/{,'TC-$(echo "$TSP" | tr '[:lower:]' '[:upper:]')-DBSrv/'{,'**'}}"
		;;
		DBObs)
			INCLUDE="--include=/{,'TC-$(echo "$TSP" | tr '[:lower:]' '[:upper:]')-DBObs/'{,'**'}}"
		;;
		PresSrv)
			INCLUDE="--include=/ --include=/sugar/ --include=/sugar/frontend/ --include=/sugar/frontend/**"
		;;
		AppSrv)
			INCLUDE="--include=/ --include=/sugar/ --include=/sugar/backend/ --include=/sugar/backend/** --include=/sugar/clm/ --include=/sugar/clm/**"
		;;
		ArenderSrv)
			INCLUDE="--include=/ --include=/sugar/ --include=/sugar/arender/ --include=/sugar/arender/**"
		;;
	esac
	echo "Synchronizing $SERVER"
	LOCAL_DIR=$(readlink -f $(dirname $0)/..)
	rsync -4 -av --delete -e "ssh -q" --chmod=Duo+x,Dg+s,ug+w,+r --include=/{,'bin/'{,'**'}} $INCLUDE --exclude="*" ${LOCAL_DIR}/ ${SSH_USER}@$SERVER:${SSH_PATH}
	ENV="${SERVERS##*.}"
	ssh -q -l ${SSH_USER} -t $SERVER "$(cat <<SSH
		REAL_PATH=\$(readlink -f ${SSH_PATH})
		if [ ! -f \${REAL_PATH}/bin/$TSP-servers.csv ]; then
			ln -s \${REAL_PATH}/bin/$TSP-servers.csv.${ENV} \${REAL_PATH}/bin/$TSP-servers.csv
		fi
		if [ ! -f \${REAL_PATH}/bin/$TSP.conf ]; then
			ln -s \${REAL_PATH}/bin/$TSP.conf.${ENV} \${REAL_PATH}/bin/$TSP.conf
		fi
		chgrp -R $TSP $SSH_PATH/*
SSH
)"
	echo "Done"
done

exit 0