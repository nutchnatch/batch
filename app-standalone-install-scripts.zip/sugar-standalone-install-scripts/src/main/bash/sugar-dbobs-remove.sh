#!/bin/bash

DIRNAME=`dirname $0`
TSP="sugar"
TSP_NAME="Sugar"

. $DIRNAME/$TSP.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/$TSP-dbsrv-env.sh

service oradgobs stop 1>> $LOG_FILE 2>&1
chkconfig --del oradgobs
[ -f /etc/init.d/oradgobs ] && rm -f /etc/init.d/oradgobs 1>> $LOG_FILE 2>&1

userdel -r $ORACLE_USER 1>> $LOG_FILE 2>&1
groupdel $ORACLE_GROUP 1>> $LOG_FILE 2>&1

mv /etc/sysctl.conf.orabackup /etc/sysctl.conf 1>> $LOG_FILE 2>&1
rm -rf $ORACLE_BASE $ORACLE_INVENTORY 1>> $LOG_FILE 2>&1
rm -f /etc/ora* 1>> $LOG_FILE 2>&1
rm -f /etc/security/limits.d/oracle-limits.conf 1>> $LOG_FILE 2>&1
