#!/bin/bash

DIRNAME=`dirname $0`
TSP="sugar"
TSP_NAME="Sugar"

. $DIRNAME/$TSP.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/$TSP-prssrv-env.sh

. $DIRNAME/dependencies/tomcat.sh

postInstallModule() {
	if [ -f $TO_DIR/shared_classes/arender.xml ]; then
		for NODE in $SUGAR_ARENDER_NODES
		do
			ARENDER_HOST_LIST="$ARENDER_HOST_LIST<value>rmi://${NODE}:${SUGAR_ARENDER_PORT}/JavaRMIDocumentService</value>"
		done
		sed -i -e s#\${ARENDER_HOST_LIST}#$ARENDER_HOST_LIST# $TO_DIR/shared_classes/arender.xml
	fi
}

initTSP

installApache

installJDK

installModule sugar-arender-hmi "Sugar ARender HMI"

startApache

ECHO "Sugar ARender HMI Server successfully installed."
exit 0