#!/bin/bash

DIRNAME=`dirname $0`
TSP="sugar"
TSP_NAME="Sugar"

. $DIRNAME/$TSP.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/$TSP-prssrv-env.sh

. $DIRNAME/dependencies/standalone.sh

restoreModule $TSP-frontend "$TSP_NAME Frontend"

ECHO "$TSP_NAME Frontend Server successfully restored."
exit 0