#!/bin/bash

DIRNAME=`dirname $0`
TSP="sugar"
TSP_NAME="Sugar"

. $DIRNAME/$TSP.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/$TSP-dbsrv-env.sh

su - oracle -c /apps/oracle/12102/rdb/enterprise/deinstall/deinstall

userdel -r $ORACLE_USER
groupdel $ORACLE_GROUP

mv /etc/sysctl.conf.orabackup /etc/sysctl.conf
rm -rf $ORACLE_BASE/*
rm -f /etc/ora*
rm -f /etc/security/limits.d/oracle-limits.conf
rm -rf /tmp/deinstall*
