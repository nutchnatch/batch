#!/bin/bash

DIRNAME=`dirname $0`
TSP="sugar"
TSP_NAME="Sugar"

. $DIRNAME/$TSP.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/$TSP-dbsrv-env.sh

. $DIRNAME/dependencies/oracle.sh

installObserver

ECHO "$TSP_NAME Database Observer successfully installed."
exit 0
