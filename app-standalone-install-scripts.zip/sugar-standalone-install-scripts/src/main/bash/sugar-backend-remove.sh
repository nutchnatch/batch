#!/bin/bash

DIRNAME=`dirname $0`
TSP="sugar"
TSP_NAME="Sugar"

. $DIRNAME/$TSP.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/$TSP-appsrv-env.sh

. $DIRNAME/dependencies/standalone.sh

rm -rf $TSP_HOME/clm

removeModule $TSP-backend "$TSP_NAME Backend"

removeApache

removeJDK

if ! $CYGWIN; then
	CLEANUP="$(package-cleanup --leaves -q)"
	[ -n "$CLEANUP" ] && yum -y -q remove $CLEANUP
fi

ECHO "$TSP_NAME Backend Server successfully removed."
exit 0