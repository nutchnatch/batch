#!/bin/sh

. ./sugar.conf

. dependencies/tsp-env.sh

. dependencies/sugar-arender-env.sh

REMOVE_JDK=${REMOVE_JDK:-"false"}

service ARenderService stop 1>> $LOG_FILE 2>&1

$TSP_HOME/arender/bin/UnintallService-ARenderServer.sh 1>> $LOG_FILE 2>&1

userdel $ARENDER_USER 1>> $LOG_FILE 2>&1
rm -rf $ARENDER_HOME 1>> $LOG_FILE 2>&1

if test "$REMOVE_JDK" = true; then
    removeJDK
fi

yum -y -q remove libreoffice* 1>> $LOG_FILE 2>&1
rm -rf /opt/libreoffice* 1>> $LOG_FILE 2>&1
yum -y -q remove ImageMagick* 1>> $LOG_FILE 2>&1
CLEANUP="$(package-cleanup --leaves -q)"
[ -n "$CLEANUP" ] && yum -y -q remove $CLEANUP 1>> $LOG_FILE 2>&1
