#!/bin/bash

DIRNAME=`dirname $0`
TSP="sugar"
TSP_NAME="Sugar"

. $DIRNAME/$TSP.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/$TSP-appsrv-env.sh

. $DIRNAME/dependencies/springboot.sh

initTSP

installApache

installJDK

# CLM Installation
INSTALL_TYPE=""
UPGRADE_CLM=false
if [ ! -d $TSP_HOME/clm ]; then
	INSTALL_TYPE="Installation of CLM"
else
	CLM_VERSION=`ls $CLM_DIR/*.zip | sed 's/.*-\([0-9\.]*\)\.zip/\1/'`
	VERSION=`ls $TSP_HOME/clm/bin/*.jar | sed 's/.*-\([0-9\.]*\)-.*\.jar/\1/'`

	versionCompare $CLM_VERSION $VERSION
	if [[ "$?" == "1" ]]; then
		INSTALL_TYPE="Upgrade of CLM"
		UPGRADE_CLM=true

		# Backup previous version
		BACKUP_DIR="$TSP_BACKUP_DIR/clm/$VERSION/"
		mkdir -p $BACKUP_DIR 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while creating directory $BACKUP_DIR"

		tar czf $BACKUP_DIR/clm.tar.gz $TSP_HOME/clm -P --transform="s|$TSP_HOME/||" 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while creating backup of CLM"

		rm -rf $TSP_HOME/clm 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while removing old version"
	fi
fi
if [ "$INSTALL_TYPE" != "" ]; then
	ECHO_WAIT "$INSTALL_TYPE"
	unzip -qq -d $TSP_HOME/ $CLM_DIR/*.zip &&
		mv $TSP_HOME/sugar-backend-clm* $TSP_HOME/clm &&
		mkdir $TSP_HOME/clm/logs 1>> $LOG_FILE 2>&1
	checkReturnCode $? "Error while installing CLM to $TSP_HOME/clm"
	if $CYGWIN; then
		icacls "$(cygpath -w ${TSP_HOME}/clm)" /grant $TSP_USER:\(OI\)\(CI\)F /T 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while changing ownership to $TSP_HOME/clm"
	else
		chown -R $TSP_USER:$TSP_GROUP $TSP_HOME/clm 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while changing ownership to $TSP_HOME/clm"
		chmod -R o-rwx $TSP_HOME/clm && chmod 770 $TSP_HOME/clm/bin/*.sh 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while changing rights to $TSP_HOME/clm"
	fi
	if $CYGWIN; then
		CLM_PATH=$(cygpath -m $TSP_HOME/clm)
	else
		CLM_PATH=$TSP_HOME/clm
	fi
	sed -e "s|spring\.datasource\.url=.*$|spring.datasource.url=$SUGAR_ORACLE_URL|" \
		-e "s|spring\.datasource\.username=.*$|spring.datasource.username=$SUGAR_ORACLE_USR_CLM|" \
		-e "s|spring\.datasource\.username\.annotation=.*$|spring.datasource.username.annotation=$SUGAR_ORACLE_USR_DOC|" \
		-e "s|spring\.datasource\.password=.*$|spring.datasource.password=$SUGAR_ORACLE_PWD_CLM|" \
		-e "s|spring\.datasource\.username\.app=.*$|spring.datasource.username.app=$SUGAR_ORACLE_USR_APP|" \
		-e "s|spring\.datasource\.password\.app=.*$|spring.datasource.password.app=$SUGAR_ORACLE_PWD_APP|" \
		-e "s|spring\.datasource\.username\.acl=.*$|spring.datasource.username.acl=$SUGAR_ORACLE_USR_ACL|" \
		-e "s|spring\.datasource\.password\.acl=.*$|spring.datasource.password.acl=$SUGAR_ORACLE_PWD_ACL|" \
		-e "s|spring\.datasource\.acl\.ts\.data=.*$|spring.datasource.acl.ts.data=$SUGAR_DAT_TBS_ACL|" \
		-e "s|spring\.datasource\.acl\.ts\.index=.*$|spring.datasource.acl.ts.index=$SUGAR_IDX_TBS_ACL|" \
		-e "s|spring\.datasource\.acl\.ts\.tmp=.*$|spring.datasource.acl.ts.tmp=$SUGAR_TMP_TBS_ACL|" \
		-e "s|spring\.datasource\.username\.meta=.*$|spring.datasource.username.meta=$SUGAR_ORACLE_USR_META|" \
		-e "s|spring\.datasource\.password\.meta=.*$|spring.datasource.password.meta=$SUGAR_ORACLE_PWD_META|" \
		-e "s|spring\.datasource\.meta\.ts\.data=.*$|spring.datasource.meta.ts.data=$SUGAR_DAT_TBS_META|" \
		-e "s|spring\.datasource\.meta\.ts\.index=.*$|spring.datasource.meta.ts.index=$SUGAR_IDX_TBS_META|" \
		-e "s|spring\.datasource\.meta\.ts\.tmp=.*$|spring.datasource.meta.ts.tmp=$SUGAR_TMP_TBS_META|" \
		-e "s|spring\.datasource\.username\.rep=.*$|spring.datasource.username.rep=$SUGAR_ORACLE_USR_REP|" \
		-e "s|spring\.datasource\.password\.rep=.*$|spring.datasource.password.rep=$SUGAR_ORACLE_PWD_REP|" \
		-e "s|spring\.datasource\.rep\.ts\.data=.*$|spring.datasource.rep.ts.data=$SUGAR_DAT_TBS_REP|" \
		-e "s|spring\.datasource\.rep\.ts\.index=.*$|spring.datasource.rep.ts.index=$SUGAR_IDX_TBS_REP|" \
		-e "s|spring\.datasource\.rep\.ts\.tmp=.*$|spring.datasource.rep.ts.tmp=$SUGAR_TMP_TBS_REP|" \
		-e "s|spring\.datasource\.username\.doc=.*$|spring.datasource.username.doc=$SUGAR_ORACLE_USR_DOC|" \
		-e "s|spring\.datasource\.password\.doc=.*$|spring.datasource.password.doc=$SUGAR_ORACLE_PWD_DOC|" \
		-e "s|spring\.datasource\.doc\.ts\.data=.*$|spring.datasource.doc.ts.data=$SUGAR_DAT_TBS_DOC|" \
		-e "s|spring\.datasource\.doc\.ts\.index=.*$|spring.datasource.doc.ts.index=$SUGAR_IDX_TBS_DOC|" \
		-e "s|spring\.datasource\.doc\.ts\.tmp=.*$|spring.datasource.doc.ts.tmp=$SUGAR_TMP_TBS_DOC|" \
		-e "s|spring\.datasource\.src\.username=.*$|spring.datasource.src.username=$SUGAR_ORACLE_USER|" \
		-e "s|spring\.datasource\.src\.password=.*$|spring.datasource.src.password=$SUGAR_ORACLE_PWD|" \
		-e "s|spring\.datasource\.username\.trace=.*$|spring.datasource.username.trace=$SUGAR_ORACLE_USR_TRACE|" \
		-e "s|spring\.datasource\.password\.trace=.*$|spring.datasource.password.trace=$SUGAR_ORACLE_PWD_TRACE|" \
		-e "s|spring\.datasource\.trace\.ts\.data=.*$|spring.datasource.trace.ts.data=$SUGAR_DAT_TBS_TRACE|" \
		-e "s|spring\.datasource\.trace\.ts\.index=.*$|spring.datasource.trace.ts.index=$SUGAR_IDX_TBS_TRACE|" \
		-e "s|spring\.datasource\.trace\.ts\.tmp=.*$|spring.datasource.trace.ts.tmp=$SUGAR_TMP_TBS_TRACE|" \
		-e "s|inputPath=resources$|inputPath=$CLM_PATH/resources|" \
		-e "s|exportPath=output$|exportPath=$CLM_PATH/output|" \
		-e "s|sugar.logstash.health.url=$|sugar.logstash.health.url=$SUGAR_LOGSTASH_HEALTH_URL|" \
		-i $TSP_HOME/clm/properties/config.properties
	checkReturnCode $? "Error while applying configuration"
	ECHO_DONE

	if test "$UPGRADE_CLM" = true; then
		if [ -f $CLM_DIR/PostInstallation/clm-post-update.cmd ]; then
			ECHO_WAIT "Upgrading database"
			sh $TSP_HOME/clm/bin/clm.sh --input-path $TSP_HOME/clm/resources `cat $CLM_DIR/PostInstallation/clm-post-update.cmd` 1>> $LOG_FILE 2>&1
			chown -R $TSP_username:$TSP_GROUP $TSP_HOME/clm/logs/sugar-clm.log 1>> $LOG_FILE 2>&1
			ECHO_DONE
		fi
	else
		if [ -f $CLM_DIR/PostInstallation/clm-post-install.cmd ]; then
			ECHO_WAIT "Initilisation of database"
			sh $TSP_HOME/clm/bin/clm.sh --input-path $TSP_HOME/clm/resources `cat $CLM_DIR/PostInstallation/clm-post-install.cmd` 1>> $LOG_FILE 2>&1
			if $CYGWIN; then
				icacls "$(cygpath -w ${TSP_HOME}/clm/logs)" /grant $TSP_username:\(OI\)\(CI\)F /T 1>> $LOG_FILE 2>&1
				checkReturnCode $? "Error while changing ownership to $TSP_HOME/clm"
			else
				chown -R $TSP_username:$TSP_GROUP $TSP_HOME/clm/logs 1>> $LOG_FILE 2>&1
				checkReturnCode $? "Error while changing ownership to $TSP_HOME/clm"
			fi
			ECHO_DONE
		fi
	fi
fi

# Logstash installation
INSTALL_TYPE=""
NEW_VERSION=$(ls $LOGSTASH_DIR/sugar-logstash-*.zip | sed 's/.*-\([0-9\.]*\)\.zip/\1/')
if [ ! -d $TSP_HOME/sugar-logstash ]; then
	INSTALL_TYPE="Installation of LogStash"
else
	VERSION=`cat $TSP_HOME/sugar-logstash/.sugar-logstash.version`

	versionCompare $NEW_VERSION $VERSION
	if [[ "$?" == "1" ]]; then
		INSTALL_TYPE="Upgrade of LogStash"
		stopModule sugar-logstash

		# Backup previous version
		BACKUP_DIR="$TSP_BACKUP_DIR/sugar-logstash/$VERSION/"
		mkdir -p $BACKUP_DIR 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while creating directory $BACKUP_DIR"

		tar czf $BACKUP_DIR/sugar-logstash.tar.gz $TSP_HOME/sugar-logstash -P --transform="s|$TSP_HOME/||" 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while creating backup of LogStash"

		rm -rf $TSP_HOME/sugar-logstash 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while removing old version"
	fi
fi
if [ "$INSTALL_TYPE" != "" ]; then
	ECHO_WAIT "$INSTALL_TYPE"
	unzip -qq -d $TSP_HOME/ $LOGSTASH_DIR/sugar-logstash-*.zip 1>> $LOG_FILE 2>&1
	checkReturnCode $? "Error while installing LogStash to $TSP_HOME/sugar-logstash"
	echo $NEW_VERSION > $TSP_HOME/sugar-logstash/.sugar-logstash.version
	if $CYGWIN; then
		icacls "$(cygpath -w ${TSP_HOME}/sugar-logstash)" /grant $TSP_USER:\(OI\)\(CI\)F /T 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while changing ownership to $TSP_HOME/sugar-logstash"
	else
		chown -R $TSP_USER:$TSP_GROUP $TSP_HOME/sugar-logstash 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while changing ownership to $TSP_HOME/sugar-logstash"
		chmod -R o-rwx $TSP_HOME/sugar-logstash && chmod 770 $TSP_HOME/sugar-logstash/bin/*.sh 1>> $LOG_FILE 2>&1
		checkReturnCode $? "Error while changing rights to $TSP_HOME/sugar-logstash"
	fi
	sed -e "s|\${TSP_LOG_DIR}|${TSP_LOG_DIR}|" \
		-e "s|\${TSP_MODULE}|sugar-backend|" \
		-e "s|\${SUGAR_ORACLE_TRACE_FULL_URL}|${SUGAR_ORACLE_TRACE_FULL_URL}|" \
		-e "s|\${SUGAR_LOGSTASH_HEALTH_PORT}|${SUGAR_LOGSTASH_HEALTH_PORT}|" \
		-i $TSP_HOME/sugar-logstash/sugar-logntrace.conf
	checkReturnCode $? "Error while applying configuration"

	cat > /usr/lib/systemd/system/sugar-logstash.service <<EOF
[Unit]
Description=Sugar Logstash Server
After=syslog.target network.target

[Service]
User=$APPSRV_USER
ExecStart=$TSP_HOME/sugar-logstash/bin/logstash -f $TSP_HOME/sugar-logstash/sugar-logntrace.conf
SuccessExitStatus=143
WorkingDirectory=$TSP_HOME/sugar-logstash

[Install]
WantedBy=multi-user.target
EOF
	checkReturnCode $? "Error while installing LogStash as a service."

	systemctl enable sugar-logstash 1>> $LOG_FILE 2>&1
	checkReturnCode $? "Error while installing LogStash as a service."

	ECHO_DONE
	startModule sugar-logstash
fi

installModule $TSP-backend "$TSP_NAME Backend"

startApache

ECHO "$TSP_NAME Backend Server successfully installed."
exit 0