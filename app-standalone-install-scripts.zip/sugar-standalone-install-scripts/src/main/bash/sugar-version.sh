#!/bin/bash

TSP="sugar"
SSH_USER="sugar"
SERVERS=${1:-"$TSP-servers.csv"}
ENV="${SERVERS##*.}"
CONF_FILE="$TSP.conf.$ENV"
DIRNAME=`dirname $0`

. $DIRNAME/$CONF_FILE

. $DIRNAME/dependencies/version.sh

function getArenderVersion() {
	VERSION=`ssh -l $SSH_USER -t $1 "$(cat <<SSH
lsb_release -sd | tr -d '"'
echo "|"
uname -mrs
echo "|"
ls $TSP_HOME/arender/lib | grep "arondor-arender-rendition" | sort -r | tail -n 1 | sed 's/[a-z\-]*\([0-9\.\-]*\)\.jar/ARender \1/'
SSH
)" 2>> /dev/null`
	echo -n $VERSION | sed 's/\r//g'
}

printHeader

for LINE in $(cat $SERVERS | sort)
do
	TYPE=$(echo -n $LINE | cut -d',' -f1)
	SERVER=$(echo -n $LINE | cut -d',' -f2)
	case "$TYPE" in
		DBSrv)
			OUTPUT="${OUTPUT}$(printInfo "$SERVER" "$(getDBVersion "$SERVER")")"
		;;
		PresSrv)
			OUTPUT="${OUTPUT}$(printInfo "$SERVER" "$(getModuleVersion "$SERVER" sugar-usage "Sugar Usage")")"
		;;
		AppSrv)
			OUTPUT="${OUTPUT}$(printInfo "$SERVER" "$(getModuleVersion "$SERVER" sugar-services "Sugar Services")")"
		;;
		ArenderSrv)
			OUTPUT="${OUTPUT}$(printInfo "$SERVER" "$(getArenderVersion "$SERVER")")"
		;;
	esac
done

printFooter
exit 0