#!/bin/sh

DIRNAME=`dirname $0`

. $DIRNAME/sugar.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/sugar-arender-env.sh

NODE=$(getNode SUGAR_ARENDER)
if [ -z "$NODE" ]; then
    ECHO "This server is not declared as ARender node."
    exit 1
fi
NODE_NUMBER=$(getNodeNumber SUGAR_ARENDER)

initTSP

createUser $ARENDER_USER "$ARENDER_HOME"

chmod 750 $ARENDER_HOME 1>> $LOG_FILE 2>&1
checkReturnCode $? "Error while changing group rights to $ARENDER_HOME"

RPM=`rpm -qa | grep -i libreoffice`
if [ -z "$RPM" ]; then
    ECHO_WAIT "Installation of LibreOffice"
    yum -y -q install $LIBREOFFICE_DIR/*.rpm 1>> $LOG_FILE 2>&1
    checkReturnCode $? "Error while installing LibreOffice"
    
    find /opt/ -name libreoffice* -type d -exec ln -s {} /opt/libreoffice \;
    checkReturnCode $? "Error while creating symbolic link to LibreOffice"
    
    # Chinese, Japanese & Korean Fonts
    yum -y install cjkuni-* wqy-zenhei-* ipa-*-fonts vlgothic-* un-core* 1>> $LOG_FILE 2>&1
    ECHO_DONE
fi

RPM=`rpm -qa | grep -i ImageMagick`
if [ -z "$RPM" ]; then
    ECHO_WAIT "Installation of ImageMagick"
    yum -y -q --nogpgcheck localinstall $IMAGEMAGICK_DIR/*.rpm 1>> $LOG_FILE 2>&1
    checkReturnCode $? "Error while installing ImageMagick"
    ECHO_DONE
fi

installJDK

if [ ! -f $ARENDER_HOME/conf/sugar-connector.xml ]; then
    # verify if /tmp is mounted with noexec
    if [ -n "$(mount | grep '/tmp' | grep 'noexec')" ]; then
        # Remount /tmp with exec
        mount -o remount,exec /tmp
        # Remount /tmp with noexec on exit
        trap "mount -o remount,noexec /tmp" EXIT
    fi

    ECHO_WAIT "Installation of ARender"
    # -options-template file.conf to get template example
    TMP_CONF=/tmp/arender.conf
    cat > $TMP_CONF <<EOF
INSTALL_PATH=$ARENDER_HOME
arender.configurations.port=$SUGAR_ARENDER_PORT
arender.configurations.port.rest=1990
arender.configurations.hostname=$(hostname)
arender.configurations.service.check=false
EOF
    checkReturnCode $? "Error while installing ARender"
    java -jar $ARENDER_DIR/binaries/$ARENDER_INSTALLER -options $TMP_CONF 1>> $LOG_FILE 2>&1
    checkReturnCode $? "Error while installing ARender"
    rm -f $TMP_CONF

    pushd $TSP_HOME/arender/bin 1>> $LOG_FILE 2>&1 && ./InstallService-ARenderServer.sh 1>> $LOG_FILE 2>&1 && popd 1>> $LOG_FILE 2>&1
    checkReturnCode $? "Error while installing ARender as a service"
    chkconfig --add ARenderService 1>> $LOG_FILE 2>&1
    checkReturnCode $? "Error while installing ARender as a service"
    chkconfig --level 2345 ARenderService on 1>> $LOG_FILE 2>&1
    checkReturnCode $? "Error while installing ARender as a service"

    cp $ARENDER_DIR/configuration/* $ARENDER_HOME/conf 1>> $LOG_FILE 2>&1
    checkReturnCode $? "Error while copying configuration files into $ARENDER_HOME/conf"

    cp $ARENDER_DIR/binaries/sugar-arender-connector* $ARENDER_HOME/lib 1>> $LOG_FILE 2>&1
    checkReturnCode $? "Error while copying JAR files to $ARENDER_HOME/lib"

    sed -i -e "s#\${SUGAR_BACKEND_URL}#$SUGAR_BACKEND_URL#" \
        $ARENDER_HOME/conf/arender-rendition.properties
    checkReturnCode $? "Error while configuring arender-rendition.properties"

    sed -i -e "s#\${TSP_LOG_DIR}#$TSP_LOG_DIR#" $ARENDER_HOME/conf/log4j.properties
    checkReturnCode $? "Error while configuring log4j.properties"

    chown -R $ARENDER_USER:$TSP_GROUP $ARENDER_HOME 1>> $LOG_FILE 2>&1
    checkReturnCode $? "Error while changing ownership to $ARENDER_HOME"

    # Issue when /tmp is noexec
    sed -i -e "s#-Djna\.nosys=true#-Djna.nosys=true -Djava.io.tmpdir=/var/tmp#" /etc/init.d/ARenderService
    checkReturnCode $? "Error while patching /etc/init.d/ARenderService"
    sed -i -e "s#-Djna\.nosys=true#-Djna.nosys=true\nwrapper.ntservice.additional.2=-Djava.io.tmpdir=/var/tmp#" $ARENDER_HOME/conf/wrapper.conf
    checkReturnCode $? "Error while patching $ARENDER_HOME/conf/wrapper.conf"

    # JAVA OPTS
    # Get last number of args
    ARG_NUM=$(egrep '^wrapper\.java\.additional\.[1-9]' $ARENDER_HOME/conf/wrapper.conf | sort -r | head -n 1 | sed -e 's/wrapper\.java\.additional\.\([0-9]*\)=.*/\1/')
    # Loop back on options
    IDX=$ARG_NUM
    for opt in $SUGAR_ARENDER_JAVA_OPTS;
    do
        IDX=$(expr $IDX + 1)
        opt=$(eval "echo -n \"${opt}\"")
        JAVA_OPTS="$JAVA_OPTS\nwrapper.java.additional.$IDX=$opt"
    done
    # Modify wrapper.conf
    if [ -n "$JAVA_OPTS" ]; then
        sed -i -e "s|\(wrapper.java.additional.$ARG_NUM=.*\)|\1$JAVA_OPTS|" $ARENDER_HOME/conf/wrapper.conf
        checkReturnCode $? "Error while setting JAVA_OPTS in $ARENDER_HOME/conf/wrapper.conf"
    fi
    ECHO_DONE
fi

ECHO_WAIT "Starting ARender"
service ARenderService restart 1>> $LOG_FILE 2>&1
ECHO_DONE

ECHO "Sugar Rendition Server successfully installed."
exit 0