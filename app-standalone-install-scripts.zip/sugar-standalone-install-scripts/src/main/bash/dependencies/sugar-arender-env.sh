#!/bin/sh

INSTALLATION_DIR="$DIRNAME/../sugar/arender"
JDK_VERSION="1.8.0"
JDK_PKG="java-$JDK_VERSION-openjdk-devel"
IMAGEMAGICK_DIR="$INSTALLATION_DIR/software/ImageMagick_*"
LIBREOFFICE_DIR="$INSTALLATION_DIR/software/LibreOffice_*_Linux_x86-64_rpm/RPMS"
ARENDER_DIR="$INSTALLATION_DIR"
ARENDER_INSTALLER="arondor-arender-rendition-service-3.0.7-rendition.jar"

ARENDER_HOME="$TSP_HOME/arender"
ARENDER_USER="arender"
