#!/bin/sh

INSTALLATION_DIR="$DIRNAME/../TC-SUGAR-DBSrv"
ORACLE_DIR="$INSTALLATION_DIR/Software/Oracle/Oracle-12cR1-12.1.0.2"
ORACLE_INSTALLER="$ORACLE_DIR/Binaries/runInstaller"
DB_INSTALL_RSP="$ORACLE_DIR/ConfigurationFiles/response/db_install.rsp"
DBCA_RSP="$ORACLE_DIR/ConfigurationFiles/response/dbca.rsp"
NETCA_RSP="$ORACLE_DIR/ConfigurationFiles/response/netca.rsp"
DBCA_TEMPLATE_NAME=`readlink -f $ORACLE_DIR/ConfigurationFiles/templates/General_Purpose.dbc`
ORACLE_INITD="$ORACLE_DIR/ConfigurationFiles/init.d/oracle"
ORACLE_INIT_SCRIPT="$INSTALLATION_DIR/Application/Configuration/init.sql"

ORACLE_OBS_DIR="$DIRNAME/../TC-SUGAR-DBObs/Software/Oracle/Oracle-12cR1-12.1.0.2"
ORACLE_OBS_INSTALLER="$ORACLE_OBS_DIR/Binaries/runInstaller"
ORACLE_OBS_INSTALL_RSP="$ORACLE_OBS_DIR/ConfigurationFiles/response/client.rsp"
ORACLE_OBS_INITD="$ORACLE_OBS_DIR/ConfigurationFiles/init.d/oradgobs"
