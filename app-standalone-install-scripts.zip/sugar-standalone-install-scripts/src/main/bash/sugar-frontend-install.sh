#!/bin/bash

DIRNAME=`dirname $0`
TSP="sugar"
TSP_NAME="Sugar"

. $DIRNAME/$TSP.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/$TSP-prssrv-env.sh

. $DIRNAME/dependencies/springboot.sh

initTSP

installApache

installJDK

installModule $TSP-frontend "$TSP_NAME Frontend"

startApache

ECHO "$TSP_NAME Frontend Server successfully installed."
exit 0