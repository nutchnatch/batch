#!/bin/bash

DIRNAME=`dirname $0`
TSP="sugar"
TSP_NAME="Sugar"

. $DIRNAME/$TSP.conf

. $DIRNAME/dependencies/tsp-env.sh

. $DIRNAME/dependencies/$TSP-prssrv-env.sh

. $DIRNAME/dependencies/tomcat.sh

restoreModule sugar-arender-hmi "Sugar ARender HMI"

ECHO "Sugar ARender HMI Server successfully restored."
exit 0