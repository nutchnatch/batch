
var arenderJSAPI ;


function getARenderJS()
{
	return arenderJSAPI;
}

function arenderjs_init(arenderjs_)
{
	arenderjs_.documentBuilder.registerNotifyAlterDocumentContentEvent(function(obj){sugar_onNotifyAlterDocumentContentEvent(arenderjs_,obj);});
	arenderJSAPI=arenderjs_;

	sugar_onARenderDocumentChange();
}

function sugar_onNotifyAlterDocumentContentEvent(arenderjs_,event)
{
    if(typeof(Event) === 'function') {
        window.dispatchEvent(new Event('split-event'));
    }else{
        var event = document.createEvent('event');
        event.initEvent("split-event", true, true);
        window.dispatchEvent(event);
    }
}
