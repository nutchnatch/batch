package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import com.ossnms.bicnet.common.javafx.piechart.JfxPieChartData;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDataChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.google.common.collect.Lists.newArrayList;
import static com.jayway.awaitility.Awaitility.await;
import static java.util.concurrent.TimeUnit.SECONDS;
import static javax.swing.SwingUtilities.invokeLater;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class StateSummaryDocumentTest extends TestHelper {

    @Mock private ListenersRegistrationManager changeListenersManager;
    @Mock private RepositoryManager repositoryManager;
    @Mock private IFrameworkDataChangeListener dataListener;

    private StateSummaryDocument document;

    private Map<ChartState, JfxPieChartData> selectedJfxPieChartData;
    private Map<ChartState, Collection<Integer>> dataValues;

    @Before public void setUp() throws Exception {
        document = new StateSummaryDocument(changeListenersManager, repositoryManager);

        fetchDataValues();
        fetchJfxPieChartData();

        initToolkit();
    }

    @Test public void setResult_run_EDT() throws Exception {
        Object data = new Object();
        final FrameworkDataChangeListenerImpl listener = new FrameworkDataChangeListenerImpl();

        document.setDataChangeListener(listener);

        invokeLater(() -> document.setResult(null, data));

        await().timeout(5, SECONDS).until(listener::wasExecuted);

        assertThat(listener.wasExecuted(), is(true));
    }

    @Test public void setResult_not_EDT() throws Exception {
        Object data = new Object();

        document.setResult(null, data);

        verify(dataListener, never()).updateData(data);
    }

    @Test public void addChangeListeners() throws Exception {
        ConcurrentHashMap<Chart, Map<ChartState, JfxPieChartData>> map = new ConcurrentHashMap<>();

        map.put(Chart.CHANNELS, selectedJfxPieChartData);
        map.put(Chart.MEDIATORS, selectedJfxPieChartData);
        map.put(Chart.NETWORK_ELEMENTS, selectedJfxPieChartData);

        document.addChangeListeners(map);

        verify(changeListenersManager, atLeastOnce()).addChannelListener(Matchers.any());
        verify(changeListenersManager, atLeastOnce()).addMediatorListener(Matchers.any());
        verify(changeListenersManager, atLeastOnce()).addNeListener(Matchers.any());
    }

    @Test public void removeChangeListeners() throws Exception {
        ConcurrentHashMap<Chart, Map<ChartState, JfxPieChartData>> map = new ConcurrentHashMap<>();

        map.put(Chart.NETWORK_ELEMENTS, selectedJfxPieChartData);
        map.put(Chart.CHANNELS, selectedJfxPieChartData);
        map.put(Chart.MEDIATORS, selectedJfxPieChartData);

        document.addChangeListeners(map);

        document.removeChangeListeners();

        verify(changeListenersManager, atLeastOnce()).removeChannelListener(Matchers.any());
        verify(changeListenersManager, atLeastOnce()).addMediatorListener(Matchers.any());
        verify(changeListenersManager, atLeastOnce()).addNeListener(Matchers.any());
    }

    @Test public void removeChangeListeners_no_listeners() throws Exception {
        document.removeChangeListeners();

        verify(changeListenersManager, never()).removeChannelListener(Matchers.any());
        verify(changeListenersManager, never()).addMediatorListener(Matchers.any());
        verify(changeListenersManager, never()).addNeListener(Matchers.any());
    }

    @Test public void getObject() throws Exception {
        final Object object = document.getObject(new Object());
        assertThat(object, nullValue());
    }

    @Test public void getRepositoryManager() throws Exception {
        final RepositoryManager repo = document.getRepositoryManager();
        assertThat(repo, is(repositoryManager));
    }

    private static class FrameworkDataChangeListenerImpl implements IFrameworkDataChangeListener {
        private boolean executed;

        private FrameworkDataChangeListenerImpl() {
            executed = false;
        }

        @Override public void updateData(Object p_key) {
            executed = true;
        }

        public boolean wasExecuted() {
            return executed;
        }
    }

    private void fetchDataValues() {
        dataValues = new ConcurrentHashMap<>();

        dataValues.put(ChartState.ACTIVE, newArrayList());
        dataValues.put(ChartState.INACTIVE, newArrayList());
        dataValues.put(ChartState.ACTIVATING, newArrayList());
        dataValues.put(ChartState.FAILED, newArrayList());
        dataValues.put(ChartState.UNMANAGED, newArrayList());
    }

    private void fetchJfxPieChartData() {
        selectedJfxPieChartData = new ConcurrentHashMap<>();

        selectedJfxPieChartData.put(ChartState.ACTIVE, ChartState.ACTIVE.initialize());
        selectedJfxPieChartData.put(ChartState.INACTIVE, ChartState.INACTIVE.initialize());
        selectedJfxPieChartData.put(ChartState.FAILED, ChartState.FAILED.initialize());
        selectedJfxPieChartData.put(ChartState.ACTIVATING, ChartState.ACTIVATING.initialize());
        selectedJfxPieChartData.put(ChartState.UNMANAGED, ChartState.UNMANAGED.initialize());
    }
}