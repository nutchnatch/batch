package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model;

import com.ossnms.bicnet.common.javafx.piechart.JfxPieChartData;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.TestHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.google.common.collect.Lists.newArrayList;
import static com.jayway.awaitility.Awaitility.await;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;

public class ChartStateModelUpdaterTest extends TestHelper {

    private static final int NEW_ITEM_ID = 6;
    private static final long TIMEOUT = 5L;
    private ChartStateModelUpdater modelUpdater;

    private Map<ChartState, JfxPieChartData> selectedJfxPieChartData;
    private Map<ChartState, Collection<Integer>> dataValues;

    @Before public void setUp() throws Exception {
        initToolkit();
        fetchDataValues();
        fetchJfxPieChartData();

        modelUpdater = new ChartStateModelUpdater(selectedJfxPieChartData);
        modelUpdater.insertAllData(dataValues);
    }

    @After public void tearDown() throws Exception {
        selectedJfxPieChartData.entrySet().clear();
        dataValues.entrySet().clear();
    }

    @Test public void insertData_in_a_empty_list() throws Exception {

        modelUpdater.insertData(NEW_ITEM_ID,
                new ChannelInfo(NEW_ITEM_ID).setGuiActualActivationState(GuiActualActivationState.FAILED));

        await().timeout(TIMEOUT, SECONDS).until(() -> selectedJfxPieChartData.get(ChartState.FAILED).getValue() == 1);

        assertThat(dataValues.get(ChartState.FAILED), hasItem(NEW_ITEM_ID));
        assertThat(dataValues.get(ChartState.FAILED).size(), is(1));
    }

    @Test public void insertData() throws Exception {

        modelUpdater.insertData(NEW_ITEM_ID,
                new ChannelInfo(NEW_ITEM_ID).setGuiActualActivationState(GuiActualActivationState.ACTIVE));

        await().timeout(TIMEOUT, SECONDS).until(() -> selectedJfxPieChartData.get(ChartState.ACTIVE).getValue() == 4);

        assertThat(dataValues.get(ChartState.ACTIVE), hasItem(NEW_ITEM_ID));
        assertThat(dataValues.get(ChartState.ACTIVE).size(), is(4));
    }

    @Test public void updateData_active_to_inactive() throws Exception {

        modelUpdater.updateData(2,
                new ChannelInfo(2).setGuiActualActivationState(GuiActualActivationState.INACTIVE));

        await().timeout(TIMEOUT, SECONDS).until(() -> selectedJfxPieChartData.get(ChartState.ACTIVE).getValue() == 2);
        await().timeout(TIMEOUT, SECONDS).until(() -> selectedJfxPieChartData.get(ChartState.INACTIVE).getValue() == 3);

        assertThat(dataValues.get(ChartState.ACTIVE), containsInAnyOrder(1,3));
        assertThat(dataValues.get(ChartState.ACTIVE).size(), is(2));

        assertThat(dataValues.get(ChartState.INACTIVE), containsInAnyOrder(2,4,5));
        assertThat(dataValues.get(ChartState.INACTIVE).size(), is(3));
    }

    @Test public void removeData() throws Exception {

        modelUpdater.removeData(5);

        await().timeout(TIMEOUT, SECONDS).until(() -> selectedJfxPieChartData.get(ChartState.INACTIVE).getValue() == 1);

        assertThat(dataValues.get(ChartState.INACTIVE), not(hasItem(5)));
        assertThat(dataValues.get(ChartState.INACTIVE).size(), is(1));
    }

    @Test public void removeData_not_exists_value() throws Exception {

        modelUpdater.removeData(100);

        await().timeout(TIMEOUT, SECONDS).until(() -> selectedJfxPieChartData.get(ChartState.INACTIVE).getValue() == 2);

        assertThat(dataValues.get(ChartState.INACTIVE), containsInAnyOrder(4,5));
        assertThat(dataValues.get(ChartState.ACTIVE), containsInAnyOrder(1,2,3));
        assertThat(dataValues.get(ChartState.INACTIVE).size(), is(2));
    }

    private void fetchDataValues() {
        dataValues = new ConcurrentHashMap<>();

        dataValues.put(ChartState.ACTIVE, newArrayList(1, 2, 3));
        dataValues.put(ChartState.INACTIVE, newArrayList(4, 5));
        dataValues.put(ChartState.ACTIVATING, newArrayList());
        dataValues.put(ChartState.FAILED, newArrayList());
    }

    private void fetchJfxPieChartData() {
        selectedJfxPieChartData = new ConcurrentHashMap<>();

        selectedJfxPieChartData.put(ChartState.ACTIVE, ChartState.ACTIVE.initialize(3));
        selectedJfxPieChartData.put(ChartState.INACTIVE, ChartState.INACTIVE.initialize(2));
        selectedJfxPieChartData.put(ChartState.FAILED, ChartState.FAILED.initialize());
        selectedJfxPieChartData.put(ChartState.ACTIVATING, ChartState.ACTIVATING.initialize());
    }
}
