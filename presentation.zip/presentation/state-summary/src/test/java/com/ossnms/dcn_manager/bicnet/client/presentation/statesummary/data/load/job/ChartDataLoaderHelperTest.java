package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job;

import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.TestHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ChartDataLoaderHelperTest extends TestHelper {

    private final static int TOTAL_ACTIVE_STATE = 1_000;
    private final static int TOTAL_INACTIVE_STATE = 1_560;
    private final static int TOTAL_ACTIVATING_STATE = 2_000;
    private final static int TOTAL_FAILED_STATE = 530;
    private final static int TOTAL_UNMANAGED_STATE = 250;

    private final static int TOTAL_DATA = TOTAL_ACTIVE_STATE + TOTAL_INACTIVE_STATE + TOTAL_ACTIVATING_STATE + TOTAL_FAILED_STATE + TOTAL_UNMANAGED_STATE;

    private Collection<FullChannelData> channels;
    private ChartDataLoaderHelper channelDataLoaderHelper;

    @Before public void setUp() throws Exception {
        channelDataLoaderHelper = new ChartDataLoaderHelper();
        channels = fetch();

        assertThat(channels.size(), is(TOTAL_DATA));
    }

    @After public void tearDown() throws Exception {
        channels.clear();
    }

    @Test public void testInitialize() throws Exception {
        final Collection<ImmutablePair<Integer, GuiInfo<?>>> elements = channels.stream()
                .map(channel -> ImmutablePair.<Integer, GuiInfo<?>>of(channel.getInfo().getChannelId(),
                        channel.getInfo()))
                .collect(Collectors.toList());

        final Map<ChartState, Collection<Integer>> chartStates = channelDataLoaderHelper.initialize(elements);

        assertThat(chartStates.get(ChartState.ACTIVE).size(), is(TOTAL_ACTIVE_STATE));
        assertThat(chartStates.get(ChartState.ACTIVATING).size(), is(TOTAL_ACTIVATING_STATE));
        assertThat(chartStates.get(ChartState.INACTIVE).size(), is(TOTAL_INACTIVE_STATE));
        assertThat(chartStates.get(ChartState.FAILED).size(), is(TOTAL_FAILED_STATE));
        assertThat(chartStates.get(ChartState.UNMANAGED).size(), is(TOTAL_UNMANAGED_STATE));
    }

    private Collection<FullChannelData> fetch() {
        final ArrayList<FullChannelData> channels = new ArrayList<>();
        int id = 1;

        for (int count = 0; count < TOTAL_ACTIVE_STATE; count++) {
            channels.add(buildChannel(id++, GuiActualActivationState.ACTIVE));
        }

        for (int count = 0; count < TOTAL_INACTIVE_STATE; count++) {
            channels.add(buildChannel(id++, GuiActualActivationState.INACTIVE));
        }

        for (int count = 0; count < TOTAL_FAILED_STATE; count++) {
            channels.add(buildChannel(id++, GuiActualActivationState.FAILED));
        }

        for (int count = 0; count < TOTAL_ACTIVATING_STATE; count++) {
            channels.add(buildChannel(id++, GuiActualActivationState.ACTIVATING));
        }

        for (int count = 0; count < TOTAL_UNMANAGED_STATE; count++) {
            channels.add(buildChannel(id++, GuiActualActivationState.NONE));
        }

        Collections.shuffle(channels);

        return channels;
    }
}
