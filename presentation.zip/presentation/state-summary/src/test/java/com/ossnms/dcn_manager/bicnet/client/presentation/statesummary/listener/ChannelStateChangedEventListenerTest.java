package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.listener;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.TestHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job.ChannelChartDataLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.StateModelUpdater;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static com.jayway.awaitility.Awaitility.await;
import static java.lang.Thread.sleep;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class ChannelStateChangedEventListenerTest extends TestHelper {
    private static final int CHANNEL_ID = 1;
    private static final int TIMEOUT = 10;

    @Mock private StateModelUpdater<Integer, GuiInfo<?>> modelUpdater;
    @Mock private ChannelChartDataLoader dataLoader;

    private ChannelStateChangedEventListener eventListener;
    private FullChannelData fullChannelData;

    @Before public void setUp() throws Exception {
        initToolkit();

        eventListener = new ChannelStateChangedEventListener(modelUpdater, dataLoader);

        fullChannelData = new FullChannelData(new EMItem(), new ChannelInfo(CHANNEL_ID)
                .setGuiActualActivationState(GuiActualActivationState.ACTIVE));

        sleep(TIMEOUT);
    }

    @Test public void elementRemoved() throws Exception {
        eventListener.elementRemoved(fullChannelData);

        await().timeout(TIMEOUT, SECONDS).until(this::modelUpdaterWasVerified);

        verify(modelUpdater, atLeastOnce()).removeData(fullChannelData.getInfo().getChannelId());
    }

    @Test public void elementAdded() throws Exception {
        eventListener.elementAdded(fullChannelData);

        await().timeout(TIMEOUT, SECONDS).until(this::modelUpdaterWasVerified);

        verify(modelUpdater, atLeastOnce()).insertData(fullChannelData.getInfo().getChannelId(), fullChannelData.getInfo());
    }

    @Test public void elementUpdated() throws Exception {
        eventListener.elementUpdated(fullChannelData);

        await().timeout(TIMEOUT, SECONDS).until(this::modelUpdaterWasVerified);

        verify(modelUpdater, atLeastOnce()).updateData(fullChannelData.getInfo().getChannelId(), fullChannelData.getInfo());
    }

    @Test public void removeAll() throws Exception {
        eventListener.removeAll();

        verify(modelUpdater, never()).insertData(fullChannelData.getInfo().getChannelId(), fullChannelData.getInfo());
        verify(modelUpdater, never()).updateData(fullChannelData.getInfo().getChannelId(), fullChannelData.getInfo());
        verify(modelUpdater, never()).removeData(fullChannelData.getInfo().getChannelId());
    }

    private boolean modelUpdaterWasVerified() {
        try {
            verify(modelUpdater, atLeastOnce());
        }catch (Error | Exception e) {
            return false;
        }
        return true;
    }
}