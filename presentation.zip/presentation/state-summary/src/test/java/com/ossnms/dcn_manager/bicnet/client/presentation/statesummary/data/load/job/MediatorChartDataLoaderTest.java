package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job;

import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.TestHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.MediatorRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collection;
import java.util.Map;

import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MediatorChartDataLoaderTest extends TestHelper {

    private MediatorChartDataLoader dataLoader;

    @Before public void setup() throws SecurityException, RepositoryException {
        final MediatorRepository mediatorRepository = mock(MediatorRepository.class);
        when(mediatorRepository.getAll()).thenReturn(getMediators());
        dataLoader = new MediatorChartDataLoader(mediatorRepository);
    }

    @Test public void testLoad() throws RepositoryException {
        final Map<ChartState, Collection<Integer>> data = dataLoader.load();

        assertThat(data.get(ChartState.ACTIVE).size(), CoreMatchers.is(1));
        assertThat(data.get(ChartState.ACTIVATING).size(), CoreMatchers.is(0));
        assertThat(data.get(ChartState.INACTIVE).size(), CoreMatchers.is(1));
        assertThat(data.get(ChartState.FAILED).size(), CoreMatchers.is(0));
    }

    private Collection<FullMediatorData> getMediators() {
        FullMediatorData fullMediator1 = buildMediator(ID_1, GuiActualActivationState.ACTIVE);
        FullMediatorData fullMediator2 = buildMediator(ID_2, GuiActualActivationState.INACTIVE);
        return Arrays.asList(fullMediator1, fullMediator2);
    }
}

