package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class StateSummaryCommandTest {

    @Mock private StateSummaryView view;

    private StateSummaryCommand command;

    @Before public void setUp() throws Exception {
        command = new StateSummaryCommand();
    }

    @Test public void testClone() throws Exception {
        final IFrameworkCommand clone = command.clone(null);
        assertThat(command, not(is(clone)));
    }

    @Test public void testBringViewToFront() throws Exception {
        command.bringViewToFront(view);
        verify(view, atLeastOnce()).bringToFront();
    }

    @Test public void testBringViewToFront_view_null() throws Exception {
        command.bringViewToFront(null);
        verify(view, never()).bringToFront();
    }
}