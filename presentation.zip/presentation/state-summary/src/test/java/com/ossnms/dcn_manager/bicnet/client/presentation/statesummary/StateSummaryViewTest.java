package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.tools.jfx.components.JfxDropDownToolBarButton;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JPanel;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class StateSummaryViewTest extends TestHelper {

    @Mock private StateSummaryDocument document;

    private StateSummaryView view;

    @Before public void setUp() throws Exception {
        view = new StateSummaryView("title", document);
    }

    @Test public void getButtonActions() throws Exception {
        final List<?> buttonActions = view.getButtonActions();

        assertThat(buttonActions.size(), is(1));
        assertThat(buttonActions.stream().anyMatch(JfxDropDownToolBarButton.class::isInstance), is(true));
    }

    @Test public void eventClosing() throws Exception {
        view.eventClosing();
        verify(document, atLeastOnce()).removeChangeListeners();
    }

    @Test public void getMainComponent() throws Exception {
        final JComponent mainComponent = view.getMainComponent();
        assertThat(JPanel.class.isInstance(mainComponent), is(true));
    }

    @Test public void getIcon() throws Exception {
        final Icon icon = view.getIcon();
        assertThat(icon, is(ResourcesIconFactory.ICON_WINDOW_STATE_SUMMARY_16));
    }

    @Test public void getFrameworkDocument() throws Exception {
        final StateSummaryDocument document = view.getFrameworkDocument();
        assertThat(StateSummaryDocument.class.isInstance(document), is(true));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void updateData_not_in_edt() throws Exception {
        ConcurrentMap<Chart, ConcurrentMap<ChartState, Collection<Integer>>> data = new ConcurrentHashMap<>();
        view.updateData(data);
    }
}
