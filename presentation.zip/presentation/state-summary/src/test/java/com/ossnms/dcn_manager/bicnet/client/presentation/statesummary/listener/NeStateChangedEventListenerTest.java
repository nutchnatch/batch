package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.listener;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.TestHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job.NeChartDataLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.StateModelUpdater;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static com.jayway.awaitility.Awaitility.await;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class NeStateChangedEventListenerTest extends TestHelper {

    @Mock private StateModelUpdater<Integer, GuiInfo<?>> modelUpdater;
    @Mock private NeChartDataLoader dataLoader;

    private NeStateChangedEventListener eventListener;
    private FullNeData fullNeData;

    @Before public void setUp() throws Exception {
        initToolkit();

        eventListener = new NeStateChangedEventListener(modelUpdater, dataLoader);

        fullNeData = new FullNeData(new NEItem(),
                new NeInfo(ID_1).setGuiActualActivationState(GuiActualActivationState.ACTIVE), null);
    }

    @Test public void elementRemoved() throws Exception {
        eventListener.elementRemoved(fullNeData);

        await().timeout(TIMEOUT, SECONDS).until(this::modelUpdaterWasVerified);

        verify(modelUpdater, atLeastOnce()).removeData(fullNeData.getInfo().getNeId());
    }

    @Test public void elementAdded() throws Exception {
        eventListener.elementAdded(fullNeData);

        await().timeout(TIMEOUT, SECONDS).until(this::modelUpdaterWasVerified);

        verify(modelUpdater, atLeastOnce()).insertData(fullNeData.getInfo().getNeId(), fullNeData.getInfo());
    }

    @Test public void elementUpdated() throws Exception {
        eventListener.elementUpdated(fullNeData);

        await().timeout(TIMEOUT, SECONDS).until(this::modelUpdaterWasVerified);

        verify(modelUpdater, atLeastOnce()).updateData(fullNeData.getInfo().getNeId(), fullNeData.getInfo());
    }

    @Test public void removeAll() throws Exception {
        eventListener.removeAll();

        verify(modelUpdater, never()).insertData(fullNeData.getInfo().getNeId(), fullNeData.getInfo());
        verify(modelUpdater, never()).updateData(fullNeData.getInfo().getNeId(), fullNeData.getInfo());
        verify(modelUpdater, never()).removeData(fullNeData.getInfo().getNeId());
    }

    private boolean modelUpdaterWasVerified() {
        try {
            verify(modelUpdater, atLeastOnce());
        } catch (Error | Exception e) {
            return false;
        }
        return true;
    }
}