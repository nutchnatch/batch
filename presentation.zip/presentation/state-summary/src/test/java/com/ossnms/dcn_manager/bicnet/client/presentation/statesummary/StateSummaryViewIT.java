package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ChannelCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.MediatorCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static com.jayway.awaitility.Awaitility.await;
import static java.lang.Thread.sleep;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Test concurrency on State Summary model data update.
 */
public class StateSummaryViewIT extends TestHelper {

    private StateSummaryView view;
    private StateSummaryDocument document;

    @Before public void setUp() throws Exception {
        initToolkit();

        NeCacheManager.getInstance().cache().fetch(new ArrayList<>());
        MediatorCacheManager.getInstance().cache().fetch(new ArrayList<>());
        ChannelCacheManager.getInstance().cache().fetch(new ArrayList<>());

        document = new StateSummaryDocument(new CacheListenersRegistrationManager(),
                new RepositoryManager());
        view = new StateSummaryView("title", document);

        waitGuiEnvToBeDone();
    }

    @After public void tearDown() throws Exception {
        view.getAllChartData().get(Chart.NETWORK_ELEMENTS).clear();
        view.getAllChartData().clear();
        view.eventClosing();
        view = null;

        NeCacheManager.getInstance().cache().clear();

        waitGuiEnvToBeDone();
    }

    @Test public void testAddItems() throws Exception {
        new Thread(() -> {
            for (int id = 1; id <= 1000; id++) {
                try {
                    NeCacheManager.getInstance().cache().put(id, buildNe(id, GuiActualActivationState.ACTIVE));
                } catch (Exception e) {
                    Throwables.propagate(e);
                }
            }
        }).start();

        new Thread(() -> {
            for (int id = 1001; id <= 2000; id++) {
                try {
                    NeCacheManager.getInstance().cache().put(id, buildNe(id, GuiActualActivationState.INACTIVE));
                } catch (Exception e) {
                    Throwables.propagate(e);
                }
            }
        }).start();

        await().timeout(TIMEOUT, SECONDS).until(() -> NeCacheManager.getInstance().cache().all().size() == 2000);

        document.addChangeListeners(view.getAllChartData());

        await().timeout(TIMEOUT, SECONDS).until(() -> view.getAllChartData().get(Chart.NETWORK_ELEMENTS) != null
                && view.getAllChartData().get(Chart.NETWORK_ELEMENTS).get(ChartState.ACTIVE).getValue() == 1000.0);

        await().timeout(TIMEOUT, SECONDS).until(() -> view.getAllChartData().get(Chart.NETWORK_ELEMENTS) != null
                && view.getAllChartData().get(Chart.NETWORK_ELEMENTS).get(ChartState.INACTIVE).getValue() == 1000.0);

        assertThat(view.getAllChartData().get(Chart.NETWORK_ELEMENTS).get(ChartState.ACTIVE).getValue(), is(1000.0));
        assertThat(view.getAllChartData().get(Chart.NETWORK_ELEMENTS).get(ChartState.INACTIVE).getValue(), is(1000.0));
    }

    @Test public void testUpdateItems() throws Exception {

        for (int id = 1; id <= 2000; id++) {
            try {
                NeCacheManager.getInstance().cache().put(id, buildNe(id, GuiActualActivationState.ACTIVE));
            } catch (Exception e) {
                Throwables.propagate(e);
            }
        }

        document.addChangeListeners(view.getAllChartData());

        new Thread(() -> {
            for (int id = 1; id <= 1000; id++) {
                try {
                    NeCacheManager.getInstance().cache().update(id, buildNe(id, GuiActualActivationState.INACTIVE));
                } catch (Exception e) {
                    Throwables.propagate(e);
                }
            }
        }).start();

        await().timeout(TIMEOUT, SECONDS).until(() -> NeCacheManager.getInstance().cache().all().size() == 2000);

        await().timeout(TIMEOUT, SECONDS).until(() -> view.getAllChartData().get(Chart.NETWORK_ELEMENTS) != null
                && view.getAllChartData().get(Chart.NETWORK_ELEMENTS).get(ChartState.ACTIVE).getValue() == 1000.0);

        await().timeout(TIMEOUT, SECONDS).until(() -> view.getAllChartData().get(Chart.NETWORK_ELEMENTS) != null
                && view.getAllChartData().get(Chart.NETWORK_ELEMENTS).get(ChartState.INACTIVE).getValue() == 1000.0);

        assertThat(view.getAllChartData().get(Chart.NETWORK_ELEMENTS).get(ChartState.ACTIVE).getValue(), is(1000.0));
        assertThat(view.getAllChartData().get(Chart.NETWORK_ELEMENTS).get(ChartState.INACTIVE).getValue(), is(1000.0));
    }

    @Test public void testAddItems_stress() throws Exception {
        new Thread(() -> {
            for (int id = 1; id <= 500; id++) {
                try {
                    NeCacheManager.getInstance().cache().put(id, buildNe(id, GuiActualActivationState.INACTIVE));
                } catch (Exception e) {
                    Throwables.propagate(e);
                }
            }
        }).start();

        document.addChangeListeners(view.getAllChartData());

        new Thread(() -> {
            for (int id = 501; id <= 1_000; id++) {
                try {
                    NeCacheManager.getInstance().cache().put(id, buildNe(id, GuiActualActivationState.INACTIVE));
                } catch (Exception e) {
                    Throwables.propagate(e);
                }
            }
        }).start();

        await().timeout(TIMEOUT, SECONDS).until(() -> NeCacheManager.getInstance().cache().all().size() == 1_000);
        await().timeout(TIMEOUT, SECONDS).until(() -> view.getAllChartData().get(Chart.NETWORK_ELEMENTS).get(ChartState.INACTIVE).getValue() >= 1_000);
    }

    private void waitGuiEnvToBeDone() throws InterruptedException {
        sleep(500L);
    }
}
