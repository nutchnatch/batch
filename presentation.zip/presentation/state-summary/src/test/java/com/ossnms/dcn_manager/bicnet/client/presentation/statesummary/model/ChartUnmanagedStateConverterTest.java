package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.TestHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.ChartUnmanagedStateConverter.tryChangeToUnmanagedState;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.DEACTIVATING;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.INACTIVE;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.NONE;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ChartUnmanagedStateConverterTest extends TestHelper {

    @Test public void tryChangeToUnmanagedState_channel() throws Exception {
        final FullChannelData element = buildChannel(ID_1, INACTIVE);
        element.getChannel().setActivation(EnableSwitch.DISABLED);

        final FullChannelData changed = tryChangeToUnmanagedState(element);

        assertThat(element.getInfo().getGuiActiveActualActivationState(), is(Optional.of(INACTIVE)));
        assertThat(changed.getInfo().getGuiActiveActualActivationState(), is(Optional.of(NONE)));
    }

    @Test public void tryChangeToUnmanagedState_channel_no_change_deactivating() throws Exception {
        final FullChannelData element = buildChannel(ID_1, DEACTIVATING);
        element.getChannel().setActivation(EnableSwitch.DISABLED);

        final FullChannelData notChanged = tryChangeToUnmanagedState(element);

        assertThat(element.getInfo().getGuiActiveActualActivationState(), is(Optional.of(DEACTIVATING)));
        assertThat(notChanged.getInfo().getGuiActiveActualActivationState(), is(Optional.of(DEACTIVATING)));
    }

    @Test public void tryChangeToUnmanagedState_channel_no_change_enable() throws Exception {
        final FullChannelData element = buildChannel(ID_1, INACTIVE);
        element.getChannel().setActivation(EnableSwitch.ENABLED);

        final FullChannelData notChanged = tryChangeToUnmanagedState(element);

        assertThat(element.getInfo().getGuiActiveActualActivationState(), is(Optional.of(INACTIVE)));
        assertThat(notChanged.getInfo().getGuiActiveActualActivationState(), is(Optional.of(INACTIVE)));
    }

    @Test public void tryChangeToUnmanagedState_mediator() throws Exception {
        final FullMediatorData element = buildMediator(ID_1, INACTIVE);
        element.getMediator().setActivation(EnableSwitch.DISABLED);

        final FullMediatorData changed = tryChangeToUnmanagedState(element);

        assertThat(element.getInfo().getGuiActiveActualActivationState(), is(Optional.of(INACTIVE)));
        assertThat(changed.getInfo().getGuiActiveActualActivationState(), is(Optional.of(NONE)));
    }

    @Test public void tryChangeToUnmanagedState_mediator_no_change_deactivating() throws Exception {
        final FullMediatorData element = buildMediator(ID_1, DEACTIVATING);
        element.getMediator().setActivation(EnableSwitch.DISABLED);

        final FullMediatorData notChanged = tryChangeToUnmanagedState(element);

        assertThat(element.getInfo().getGuiActiveActualActivationState(), is(Optional.of(DEACTIVATING)));
        assertThat(notChanged.getInfo().getGuiActiveActualActivationState(), is(Optional.of(DEACTIVATING)));
    }

    @Test public void tryChangeToUnmanagedState_mediator_no_change_enable() throws Exception {
        final FullMediatorData element = buildMediator(ID_1, INACTIVE);
        element.getMediator().setActivation(EnableSwitch.ENABLED);

        final FullMediatorData notChanged = tryChangeToUnmanagedState(element);

        assertThat(element.getInfo().getGuiActiveActualActivationState(), is(Optional.of(INACTIVE)));
        assertThat(notChanged.getInfo().getGuiActiveActualActivationState(), is(Optional.of(INACTIVE)));
    }

    @Test public void tryChangeToUnmanagedState_ne() throws Exception {
        final FullNeData element = buildNe(ID_1, INACTIVE);
        element.getNe().setActivation(EnableSwitch.DISABLED);

        final FullNeData changed = tryChangeToUnmanagedState(element);

        assertThat(element.getInfo().getGuiActiveActualActivationState(), is(Optional.of(INACTIVE)));
        assertThat(changed.getInfo().getGuiActiveActualActivationState(), is(Optional.of(NONE)));
    }

    @Test public void tryChangeToUnmanagedState_ne_no_change_deactivating() throws Exception {
        final FullNeData element = buildNe(ID_1, DEACTIVATING);
        element.getNe().setActivation(EnableSwitch.DISABLED);

        final FullNeData notChanged = tryChangeToUnmanagedState(element);

        assertThat(element.getInfo().getGuiActiveActualActivationState(), is(Optional.of(DEACTIVATING)));
        assertThat(notChanged.getInfo().getGuiActiveActualActivationState(), is(Optional.of(DEACTIVATING)));
    }

    @Test public void tryChangeToUnmanagedState_ne_no_change_enable() throws Exception {
        final FullNeData element = buildNe(ID_1, INACTIVE);
        element.getNe().setActivation(EnableSwitch.ENABLED);

        final FullNeData notChanged = tryChangeToUnmanagedState(element);

        assertThat(element.getInfo().getGuiActiveActualActivationState(), is(Optional.of(INACTIVE)));
        assertThat(notChanged.getInfo().getGuiActiveActualActivationState(), is(Optional.of(INACTIVE)));
    }
}
