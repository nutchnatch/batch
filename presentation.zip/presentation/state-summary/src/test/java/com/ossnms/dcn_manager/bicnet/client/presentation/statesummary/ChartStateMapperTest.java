package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateActivating;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateActive;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateFailed;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateInactive;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateUnmanaged;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.ACTIVATING;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.ACTIVE;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.DEACTIVATING;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.FAILED;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.INACTIVE;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.NONE;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.OUT_OF_SYNCH;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.SHUTTINGDOWN;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.STARTINGUP;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.SYNCHRONIZING;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ChartStateMapperTest {

    @Test public void testIsChartStateActive() throws Exception {
        assertThat(isChartStateActive(Optional.of(ACTIVE)), is(true));
        assertThat(isChartStateActive(Optional.of(OUT_OF_SYNCH)), is(true));
        assertThat(isChartStateActive(Optional.of(SYNCHRONIZING)), is(true));
    }

    @Test public void testIsChartStateInactive() throws Exception {
        assertThat(isChartStateInactive(Optional.of(INACTIVE)), is(true));
        assertThat(isChartStateInactive(Optional.of(DEACTIVATING)), is(true));
        assertThat(isChartStateInactive(Optional.of(SHUTTINGDOWN)), is(true));
    }

    @Test public void testIsChartStateUnmanaged() throws Exception {
        assertThat(isChartStateUnmanaged(Optional.of(NONE)), is(true));
    }

    @Test public void testIsChartStateFailed() throws Exception {
        assertThat(isChartStateFailed(Optional.of(FAILED)), is(true));
    }

    @Test public void testIsChartStateActivating() throws Exception {
        assertThat(isChartStateActivating(Optional.of(ACTIVATING)), is(true));
        assertThat(isChartStateActivating(Optional.of(STARTINGUP)), is(true));
    }
}