package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.listener;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.TestHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job.MediatorChartDataLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.StateModelUpdater;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static com.jayway.awaitility.Awaitility.await;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class MediatorStateChangedEventListenerTest extends TestHelper {

    @Mock private StateModelUpdater<Integer, GuiInfo<?>> modelUpdater;
    @Mock private MediatorChartDataLoader dataLoader;

    private MediatorStateChangedEventListener eventListener;
    private FullMediatorData fullMediator;

    @Before public void setUp() throws Exception {
        initToolkit();

        eventListener = new MediatorStateChangedEventListener(modelUpdater, dataLoader);

        fullMediator = new FullMediatorData(new MediatorItem(),
                new MediatorInfo(ID_1).setGuiActualActivationState(GuiActualActivationState.ACTIVE));
    }

    @Test public void elementRemoved() throws Exception {
        eventListener.elementRemoved(fullMediator);

        await().timeout(TIMEOUT, SECONDS).until(this::modelUpdaterWasVerified);

        verify(modelUpdater, atLeastOnce()).removeData(fullMediator.getInfo().getMediatorId());
    }

    @Test public void elementAdded() throws Exception {
        eventListener.elementAdded(fullMediator);

        await().timeout(TIMEOUT, SECONDS).until(this::modelUpdaterWasVerified);

        verify(modelUpdater, atLeastOnce()).insertData(fullMediator.getInfo().getMediatorId(), fullMediator.getInfo());
    }

    @Test public void elementUpdated() throws Exception {
        eventListener.elementUpdated(fullMediator);

        await().timeout(TIMEOUT, SECONDS).until(this::modelUpdaterWasVerified);

        verify(modelUpdater, atLeastOnce()).updateData(fullMediator.getInfo().getMediatorId(), fullMediator.getInfo());
    }

    @Test public void removeAll() throws Exception {
        eventListener.removeAll();

        verify(modelUpdater, never()).insertData(fullMediator.getInfo().getMediatorId(), fullMediator.getInfo());
        verify(modelUpdater, never()).updateData(fullMediator.getInfo().getMediatorId(), fullMediator.getInfo());
        verify(modelUpdater, never()).removeData(fullMediator.getInfo().getMediatorId());
    }

    private boolean modelUpdaterWasVerified() {
        try {
            verify(modelUpdater, atLeastOnce());
        } catch (Error | Exception e) {
            return false;
        }
        return true;
    }
}