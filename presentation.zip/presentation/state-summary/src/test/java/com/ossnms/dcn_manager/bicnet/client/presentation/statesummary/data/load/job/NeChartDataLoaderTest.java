package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job;

import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.TestHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collection;
import java.util.Map;

import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NeChartDataLoaderTest extends TestHelper {

    private NeChartDataLoader dataLoader;

    @Before public void setup() throws SecurityException, RepositoryException {
        final NeRepository neRepository = mock(NeRepository.class);
        when(neRepository.getAll()).thenReturn(getNEs());
        dataLoader = new NeChartDataLoader(neRepository);
    }

    @Test public void testLoad() throws RepositoryException {
        final Map<ChartState, Collection<Integer>> data = dataLoader.load();

        assertThat(data.get(ChartState.ACTIVE).size(), CoreMatchers.is(1));
        assertThat(data.get(ChartState.ACTIVATING).size(), CoreMatchers.is(0));
        assertThat(data.get(ChartState.INACTIVE).size(), CoreMatchers.is(0));
        assertThat(data.get(ChartState.FAILED).size(), CoreMatchers.is(1));
    }

    private Collection<FullNeData> getNEs() {
        final FullNeData fullNeData1 = buildNe(ID_1, GuiActualActivationState.ACTIVE);
        final FullNeData fullNeData2 = buildNe(ID_2, GuiActualActivationState.FAILED);
        return Arrays.asList(fullNeData1, fullNeData2);
    }
}
