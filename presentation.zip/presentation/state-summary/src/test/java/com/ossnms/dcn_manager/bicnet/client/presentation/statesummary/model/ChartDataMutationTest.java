package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model;

import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ChartDataMutationTest {

    private ChartDataMutation chartDataMutation;

    @Before public void setUp() throws Exception {
        chartDataMutation = new ChartDataMutation();
    }

    @Test public void testNewState_active() throws Exception {
        final Optional<ChartState> newState = chartDataMutation
                .newState(Optional.of(GuiActualActivationState.ACTIVE));

        assertThat(newState.isPresent(), is(true));
        newState.ifPresent(state -> assertThat(state, is(ChartState.ACTIVE)));
    }

    @Test public void testNewState_activating() throws Exception {
        final Optional<ChartState> newState = chartDataMutation
                .newState(Optional.of(GuiActualActivationState.ACTIVATING));

        assertThat(newState.isPresent(), is(true));
        newState.ifPresent(state -> assertThat(state, is(ChartState.ACTIVATING)));
    }

    @Test public void testNewState_failed() throws Exception {
        final Optional<ChartState> newState = chartDataMutation
                .newState(Optional.of(GuiActualActivationState.FAILED));

        assertThat(newState.isPresent(), is(true));
        newState.ifPresent(state -> assertThat(state, is(ChartState.FAILED)));
    }

    @Test public void testNewState_inactive() throws Exception {
        final Optional<ChartState> newState = chartDataMutation
                .newState(Optional.of(GuiActualActivationState.INACTIVE));

        assertThat(newState.isPresent(), is(true));
        newState.ifPresent(state -> assertThat(state, is(ChartState.INACTIVE)));
    }

    @Test public void testNewState_unmanaged() throws Exception {
        final Optional<ChartState> newState = chartDataMutation
                .newState(Optional.of(GuiActualActivationState.NONE));

        assertThat(newState.isPresent(), is(true));
        newState.ifPresent(state -> assertThat(state, is(ChartState.UNMANAGED)));
    }

    @Test public void testGetCurrentState() throws Exception {
        Map<ChartState, Collection<Integer>> chartData = new HashMap<>();

        chartData.put(ChartState.ACTIVE, Arrays.asList(2,3,4));
        chartData.put(ChartState.INACTIVE, Arrays.asList(8,1,5));

        final Optional<ChartState> currentState = chartDataMutation.currentState(chartData, 1);
        assertThat(currentState.isPresent(), is(true));
        currentState.ifPresent(state -> assertThat(state, is(ChartState.INACTIVE)));
    }

    @Test public void testGetCurrentState_not_found() throws Exception {
        Map<ChartState, Collection<Integer>> chartData = new HashMap<>();

        chartData.put(ChartState.ACTIVE, Arrays.asList(2,3,4));
        chartData.put(ChartState.INACTIVE, Arrays.asList(8,1,5));

        final Optional<ChartState> currentState = chartDataMutation.currentState(chartData, 10);
        assertThat(currentState.isPresent(), is(false));
    }
}