package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import javafx.embed.swing.JFXPanel;

import java.util.concurrent.CountDownLatch;

import static java.lang.Thread.sleep;
import static java.util.concurrent.TimeUnit.SECONDS;
import static javax.swing.SwingUtilities.invokeLater;

public abstract class TestHelper {
    protected static final int TIMEOUT = 15;
    protected static final int ID_2 = 2;
    protected static final int ID_1 = 1;

    protected void initToolkit() throws InterruptedException {
        final CountDownLatch latch = new CountDownLatch(1);
        invokeLater(() -> {
            new JFXPanel();
            latch.countDown();
        });

        if (!latch.await(TIMEOUT, SECONDS)) {
            throw new ExceptionInInitializerError();
        }

        sleep(20);
    }

    protected FullMediatorData buildMediator(int id, GuiActualActivationState state) {
        final MediatorItem mediatorItem = new MediatorItem();
        mediatorItem.setActivation(EnableSwitch.ENABLED);
        return new FullMediatorData(mediatorItem, new MediatorInfo(id).setGuiActualActivationState(state));
    }

    protected FullNeData buildNe(int id, GuiActualActivationState state) {
        final NEItem neItem = new NEItem();
        neItem.setActivation(EnableSwitch.ENABLED);
        return new FullNeData(neItem, new NeInfo(id).setGuiActualActivationState(state), null);
    }

    protected FullChannelData buildChannel(final int id, final GuiActualActivationState state) {
        final EMItem emItem = new EMItem();
        emItem.setActivation(EnableSwitch.ENABLED);
        return new FullChannelData(emItem, new ChannelInfo(id).setGuiActualActivationState(state));
    }
}
