package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model;

import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState.ACTIVATING;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState.ACTIVE;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState.FAILED;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState.INACTIVE;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState.UNMANAGED;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateActivating;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateActive;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateFailed;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateInactive;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateUnmanaged;

/**
 * Helper to apply the data mutation on Chart data.
 */
class ChartDataMutation {

    /**
     * Transforms a Gui actual state in a Chart state.
     *
     * @param newState the new {@link GuiActualActivationState} to be transformed.
     * @return The {@link ChartState} which references a {@link GuiActualActivationState}.
     */
    @SuppressWarnings("OptionalUsedAsFieldOrParameterType") Optional<ChartState> newState(
            @Nonnull final Optional<GuiActualActivationState> newState) {
        if (isChartStateActive(newState)) {
            return Optional.of(ACTIVE);

        } else if (isChartStateInactive(newState)) {
            return Optional.of(INACTIVE);

        } else if (isChartStateActivating(newState)) {
            return Optional.of(ACTIVATING);

        } else if (isChartStateFailed(newState)) {
            return Optional.of(FAILED);

        } else if (isChartStateUnmanaged(newState)) {
            return Optional.of(UNMANAGED);
        }

        return Optional.empty();
    }

    /**
     * Gets the current Chart State fo a element.
     *
     * @param chartData The chart data that contains the states with a collection of element ids.
     * @param id        The element id
     * @return The current state of the element id.
     */
    Optional<ChartState> currentState(@Nonnull final Map<ChartState, Collection<Integer>> chartData, final int id) {
        return chartData.entrySet().stream()
                .filter(entry -> entry.getValue().stream().anyMatch(data -> data == id))
                .map(Map.Entry::getKey).findAny();
    }
}
