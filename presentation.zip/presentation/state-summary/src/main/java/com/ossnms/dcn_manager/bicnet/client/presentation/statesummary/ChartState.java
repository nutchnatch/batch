package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import com.ossnms.bicnet.common.javafx.piechart.JfxPieChartData;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.StateSummaryLabels;
import javafx.scene.paint.Color;

import static javafx.scene.paint.Color.rgb;

/**
 * The supported Chart states.
 */
public enum ChartState {
    ACTIVATING    (StateSummaryLabels.ACTIVATING,    rgb(0, 155, 163)),
    ACTIVE        (StateSummaryLabels.ACTIVE,        rgb(155, 200, 65)),
    INACTIVE      (StateSummaryLabels.INACTIVE,      rgb(200, 212, 217)),
    FAILED        (StateSummaryLabels.FAILED,        rgb(190, 20, 70)),
    UNMANAGED     (StateSummaryLabels.UNMANAGED,     rgb(112, 123, 129));

    public static final int INIT_VALUE = 0;
    private final StateSummaryLabels label;
    private final Color color;

    ChartState(StateSummaryLabels label, Color color) {
        this.label = label;
        this.color = color;
    }

    /**
     * @return The default Pie chart data.
     */
    public JfxPieChartData initialize() {
        return initialize(INIT_VALUE);
    }

    public JfxPieChartData initialize(int value) {
        return new JfxPieChartData(label.toString(), value, color);
    }
}
