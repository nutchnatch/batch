package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model;

import com.ossnms.bicnet.common.javafx.piechart.JfxPieChartData;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import static com.google.common.collect.Sets.newHashSet;
import static com.ossnms.bicnet.common.javafx.JavaFxUtil.runOnFxThread;
import static java.util.Optional.ofNullable;

/**
 * Updates the Chart states.
 */
public class ChartStateModelUpdater implements StateModelUpdater<Integer, GuiInfo<?>> {

    private final Map<ChartState, JfxPieChartData> pieChartModel;
    private final Map<ChartState, Collection<Integer>> dataValues;

    private final ChartDataMutation chartDataMutation;

    public ChartStateModelUpdater(@Nonnull final Map<ChartState, JfxPieChartData> pieChartModel) {
        this.pieChartModel = pieChartModel;

        dataValues = new ConcurrentHashMap<>();
        dataValues.put(ChartState.ACTIVE, newHashSet());
        dataValues.put(ChartState.INACTIVE, newHashSet());
        dataValues.put(ChartState.ACTIVATING, newHashSet());
        dataValues.put(ChartState.FAILED, newHashSet());
        dataValues.put(ChartState.UNMANAGED, newHashSet());

        chartDataMutation = new ChartDataMutation();
    }

    /**
     * @see StateModelUpdater#insertData(Object, Object)
     */
    @Override public void insertAllData(Map<ChartState, Collection<Integer>> data) {
        runOnFxThread(() -> {
            dataValues.clear();
            dataValues.putAll(data);
            dataValues.keySet().forEach(this::updatePieChart);
        });
    }

    /**
     * @see StateModelUpdater#insertData(Object, Object)
     */
    @Override public void insertData(@Nonnull final Integer id, @Nonnull final GuiInfo<?> info) {
        runOnFxThread(() -> chartDataMutation.newState(info.getGuiActiveActualActivationState())
                .ifPresent(newState -> addElementId(id, newState))
        );
    }

    /**
     * @see StateModelUpdater#updateData(Object, Object)
     */
    @Override public void updateData(@Nonnull final Integer id, @Nonnull final GuiInfo<?> info) {
        runOnFxThread(() -> {
            final Optional<ChartState> newState = chartDataMutation.newState(info.getGuiActiveActualActivationState());
            final Optional<ChartState> currentState = chartDataMutation.currentState(dataValues, id);

            if (newState.isPresent() && currentState.isPresent() && !Objects.equals(newState, currentState)) {
                removeElementId(id, currentState.get());
                addElementId(id, newState.get());
            }
        });
    }

    /**
     * @see StateModelUpdater#removeData(Object)
     */
    @Override public void removeData(@Nonnull final Integer id) {
        runOnFxThread(() -> chartDataMutation.currentState(dataValues, id)
                .ifPresent(currentState -> removeElementId(id, currentState)));
    }

    private void updatePieChart(@Nonnull final ChartState chartState) {
        ofNullable(pieChartModel.get(chartState))
                .ifPresent(jfxPieChartData -> jfxPieChartData.setValue(dataValues.get(chartState).size()));
    }

    private void removeElementId(@Nonnull final Integer id, @Nonnull final ChartState currentState) {
        dataValues.get(currentState).remove(id);
        updatePieChart(currentState);
    }

    private void addElementId(@Nonnull final Integer id, @Nonnull final ChartState newState) {
        dataValues.get(newState).add(id);
        updatePieChart(newState);
    }
}
