package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job;

import com.ossnms.dcn_manager.bicnet.client.api.exception.DcnClientException;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;

/**
 * Fetch the data from the client repository.
 *
 * @see Repository
 *
 * @param <K> The key of the element
 * @param <V> The element value
 */
public abstract class ChartDataLoader<K, V> {

    private final Repository<K, V> repository;

    public ChartDataLoader(@Nonnull final Repository<K, V> repository) {
        this.repository = repository;
    }

    /**
     * @see com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.Chart
     *
     * @return The Chart data for a specific Chart type.     *
     * @throws DcnClientException
     */
    public abstract Map<ChartState, Collection<Integer>> load() throws DcnClientException;

    /**
     * @return The repository of the current Value type
     */
    protected final Repository<K, V> getRepository() {
        return repository;
    }
}
