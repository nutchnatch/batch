package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job;

import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.ChartUnmanagedStateConverter;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Loads the Chart Data from a collections of {@link FullChannelData}.
 */
public class ChannelChartDataLoader extends ChartDataLoader<Integer, FullChannelData>{

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelChartDataLoader.class);

    public ChannelChartDataLoader(final Repository<Integer, FullChannelData> repository) {
        super(repository);
    }

    /**
     * @see ChartDataLoader#load()
     */
    @Override
    public Map<ChartState, Collection<Integer>> load() throws RepositoryException {
        LOGGER.debug("ChannelChartDataLoader :: Loading Channel State Summary data...");

        final Collection<ImmutablePair<Integer, GuiInfo<?>>> channels = getRepository().getAll().stream()
                .map(ChartUnmanagedStateConverter::tryChangeToUnmanagedState)
                .map(channel -> ImmutablePair.<Integer, GuiInfo<?>>of(channel.getInfo().getChannelId(),
                        channel.getInfo()))
                .collect(Collectors.toList());

        return new ChartDataLoaderHelper().initialize(channels);
    }
}
