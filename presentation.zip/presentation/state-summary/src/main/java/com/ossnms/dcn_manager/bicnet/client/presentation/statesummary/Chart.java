package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import com.ossnms.dcn_manager.bicnet.client.service.i18n.StateSummaryLabels;

/**
 * Supported chart types.
 */
public enum Chart {

    NETWORK_ELEMENTS  (StateSummaryLabels.NETWORKELEMENTS_TITLE),
    CHANNELS          (StateSummaryLabels.CHANNELS_TITLE),
    MEDIATORS         (StateSummaryLabels.MEDIATORS_TITLE);

    private final StateSummaryLabels label;

    Chart(StateSummaryLabels label) {
        this.label = label;
    }

    public String getLabel() {
        return label.toString();
    }
}