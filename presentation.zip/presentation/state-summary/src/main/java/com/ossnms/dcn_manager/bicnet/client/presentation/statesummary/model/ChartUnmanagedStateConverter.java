package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;
import org.apache.commons.lang3.SerializationUtils;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isInactive;
import static com.ossnms.dcn_manager.bicnet.client.api.state.RequiredStateVerification.isDisable;
import static com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState.NONE;
import static java.util.Optional.of;

/**
 * Convert to UNMANAGED state if necessary.
 */
public final class ChartUnmanagedStateConverter {

    private ChartUnmanagedStateConverter(){}

    public static FullNeData tryChangeToUnmanagedState(@Nonnull final FullNeData fullNeData) {
        return of(fullNeData)
                .filter(ne -> isDisable(ne.getNe()))
                .filter(ne -> isInactive(ne.getInfo().getGuiActiveActualActivationState()))
                .map(ne -> {
                    final FullNeData clone = SerializationUtils.clone(ne);
                    changeToUnmanaged(clone.getInfo());
                    return clone;
                }).orElse(fullNeData);
    }

    public static FullMediatorData tryChangeToUnmanagedState(@Nonnull final FullMediatorData fullMediatorData) {
        return of(fullMediatorData)
                .filter(mediator -> isDisable(mediator.getMediator()))
                .filter(mediator -> isInactive(mediator.getInfo().getGuiActiveActualActivationState()))
                .map(mediator -> {
                    final FullMediatorData clone = SerializationUtils.clone(mediator);
                    changeToUnmanaged(clone.getInfo());
                    return clone;
                }).orElse(fullMediatorData);
    }

    public static FullChannelData tryChangeToUnmanagedState(@Nonnull final FullChannelData fullChannelData) {
        return of(fullChannelData)
                .filter(channel -> isDisable(channel.getChannel()))
                .filter(channel -> isInactive(channel.getInfo().getGuiActiveActualActivationState()))
                .map(channel -> {
                    final FullChannelData clone = SerializationUtils.clone(channel);
                    changeToUnmanaged(clone.getInfo());
                    return clone;
                }).orElse(fullChannelData);
    }

    private static void changeToUnmanaged(@Nonnull final GuiInfo<?> guiInfo) {
            guiInfo.setGuiActualActivationState(NONE);
    }
}
