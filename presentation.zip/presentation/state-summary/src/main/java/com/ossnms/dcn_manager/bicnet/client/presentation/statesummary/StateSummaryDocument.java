package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import com.ossnms.bicnet.common.javafx.piechart.JfxPieChartData;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job.ChannelChartDataLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job.MediatorChartDataLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job.NeChartDataLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.listener.ChannelStateChangedEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.listener.MediatorStateChangedEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.listener.NeStateChangedEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.ChartStateModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;

import javax.annotation.Nonnull;
import java.util.Map;

import static com.ossnms.bicnet.common.javafx.JavaFxUtil.runOnFxThread;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.Chart.CHANNELS;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.Chart.MEDIATORS;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.Chart.NETWORK_ELEMENTS;
import static java.util.Optional.ofNullable;

/**
 * @see FrameworkDocument
 */
public class StateSummaryDocument extends FrameworkDocument {

    private NeStateChangedEventListener neStateChangedListener;
    private ChannelStateChangedEventListener channelStateChangedListener;
    private MediatorStateChangedEventListener mediatorStateChangedListener;

    private final ListenersRegistrationManager changeListenersManager;
    private final RepositoryManager repositoryManager;

    /**
     * The framework will instantiate by reflection.
     */
    public StateSummaryDocument(){
        this(new CacheListenersRegistrationManager(), new RepositoryManager());
    }

    public StateSummaryDocument(final ListenersRegistrationManager changeListenersManager,
            final RepositoryManager repositoryManager) {
        super(DcnPluginHelperSingleton.getInstance());

        this.changeListenersManager = changeListenersManager;
        this.repositoryManager = repositoryManager;
    }

    /**
     * @see FrameworkDocument#setResult(IFrameworkJob, Object)
     */
    @Override public final void setResult(final IFrameworkJob job, final Object result) {
        updateData(result);
    }

    /**
     * Subscribe the change listener.
     */
    void addChangeListeners(@Nonnull final Map<Chart, Map<ChartState, JfxPieChartData>> allChartData) {
        addNeListener(allChartData);
        addChannelListener(allChartData);
        addMediatorListener(allChartData);
    }

    private void addMediatorListener(@Nonnull Map<Chart, Map<ChartState, JfxPieChartData>> allChartData) {
        mediatorStateChangedListener = new MediatorStateChangedEventListener(
                new ChartStateModelUpdater(allChartData.get(MEDIATORS)),
                new MediatorChartDataLoader(repositoryManager.getMediatorRepository()));

        changeListenersManager.addMediatorListener(mediatorStateChangedListener);
        runOnFxThread(() -> mediatorStateChangedListener.addAll());
    }

    private void addChannelListener(@Nonnull Map<Chart, Map<ChartState, JfxPieChartData>> allChartData) {
        channelStateChangedListener = new ChannelStateChangedEventListener(
                new ChartStateModelUpdater(allChartData.get(CHANNELS)),
                new ChannelChartDataLoader(repositoryManager.getChannelRepository()));

        changeListenersManager.addChannelListener(channelStateChangedListener);
        runOnFxThread(() -> channelStateChangedListener.addAll());
    }

    private void addNeListener(@Nonnull Map<Chart, Map<ChartState, JfxPieChartData>> allChartData) {
        neStateChangedListener = new NeStateChangedEventListener(
                new ChartStateModelUpdater(allChartData.get(NETWORK_ELEMENTS)),
                new NeChartDataLoader(repositoryManager.getNeRepository()));

        changeListenersManager.addNeListener(neStateChangedListener);
        runOnFxThread(() -> neStateChangedListener.addAll());
    }

    /**
     * Unsubscribe the change listener.
     */
    void removeChangeListeners() {
        ofNullable(neStateChangedListener).ifPresent(changeListenersManager::removeNeListener);
        ofNullable(channelStateChangedListener).ifPresent(changeListenersManager::removeChannelListener);
        ofNullable(mediatorStateChangedListener).ifPresent(changeListenersManager::removeMediatorListener);
    }

    /**
     * @see FrameworkDocument#getObject(Object)
     */
    @Override public Object getObject(final Object key) {
        return null;
    }

    /**
     * @return The NE repository
     */
    public RepositoryManager getRepositoryManager() {
        return repositoryManager;
    }
}