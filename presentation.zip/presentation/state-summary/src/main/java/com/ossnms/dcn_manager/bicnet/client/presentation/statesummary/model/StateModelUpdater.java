package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model;

import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;

/**
 * Updates the Chart states.
 *
 * @param <ID> The id of the element.
 * @param <INFO> The info that contain the state.
 */
public interface StateModelUpdater<ID, INFO> {

    void insertAllData(Map<ChartState, Collection<Integer>> data);

    /**
     * Add new entry in Chart Data and update the Chart model.
     *
     * @param id The id of the element.
     * @param info The info that contain the new state.
     */
    void insertData(@Nonnull final ID id, @Nonnull final INFO info);

    /**
     * Update a entry in Chart Data and the Chart model.
     *
     * <p>A update process remove the current state in the chart data and add a new entry in Chart Data.<p/>
     *
     * @param id The id of the element.
     * @param info The info that contain the a state to be updated.
     */
    void updateData(@Nonnull final ID id, @Nonnull final INFO info);

    /**
     * Remove a current entry in Chart Data and update the Chart model.
     *
     * @param id The id of the element.
     */
    void removeData(@Nonnull final ID id);
}
