package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;

import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isActivating;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isActive;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isDeactivating;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isFailed;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isInactive;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isOutOfSync;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isShutingDown;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isStartingUp;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isSynchronizing;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isUnmanaged;

/**
 * Minify the states to a Summary view states.
 */
@SuppressWarnings("OptionalUsedAsFieldOrParameterType")
public final class ChartStateMapper {
    private ChartStateMapper() {
    }

    /**
     * Combine Actual states to became the Chart state ACTIVE.
     *
     * @param state The Element Actual State.
     * @return true if is ACTIVE.
     */
    public static boolean isChartStateActive(Optional<GuiActualActivationState> state) {
        return isActive(state) || isOutOfSync(state) || isSynchronizing(state);
    }

    /**
     * Combine Actual states to became the Chart state INACTIVE.
     *
     * @param state The Element Actual State.
     * @return true if is INACTIVE.
     */
    public static boolean isChartStateInactive(Optional<GuiActualActivationState> state) {
        return isInactive(state) || isDeactivating(state) || isShutingDown(state);
    }

    /**
     * Combine Actual states to became the Chart state UNMANAGED.
     *
     * The element is UNMANAGED when the Require state is inactive.
     *
     * @param state The Element Actual State.
     * @return true if is UNMANAGED.
     */
    public static boolean isChartStateUnmanaged(Optional<GuiActualActivationState> state) {
        return isUnmanaged(state);
    }

    /**
     * Combine Actual states to became the Chart state FAILED.
     *
     * @param state The Element Actual State.
     * @return true if is FAILED.
     */
    public static boolean isChartStateFailed(Optional<GuiActualActivationState> state) {
        return isFailed(state);
    }

    /**
     * Combine Actual states to became the Chart state ACTIVATING.
     *
     * @param state The Element Actual State.
     * @return true if is ACTIVATING.
     */
    public static boolean isChartStateActivating(Optional<GuiActualActivationState> state) {
        return isActivating(state) || isStartingUp(state);
    }
}
