/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import com.ossnms.bicnet.common.javafx.piechart.JfxPieChart;
import com.ossnms.bicnet.common.javafx.piechart.JfxPieChartData;
import com.ossnms.bicnet.framework.client.helpers.FrameworkView;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.service.help.DefaultHelpIds;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.StateSummaryLabels;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.components.EToolBarButtonStyle;
import com.ossnms.tools.jfx.components.JfxDropDownToolBarButton;
import com.ossnms.tools.jfx.components.JfxPopupMenu;
import com.ossnms.tools.jfx.components.JfxRadioButtonMenuItem;

import javax.annotation.Nonnull;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Maps.newConcurrentMap;

/**
 * The Summary view Pie Chart.
 *
 * @see FrameworkView
 */
public class StateSummaryView extends FrameworkView {

    private static final long serialVersionUID = -3930356712836748196L;
    private static final String ID = StateSummaryView.class.getName();
    private static final boolean RESIZABLE = true;
    private static final int MAIN_COMPONENT_PREFERRED_WIDTH = 420;
    private static final int MAIN_COMPONENT_PREFERRED_HEIGHT = 420;
    private static final String ACTION_GUI_NAME = "93365D0E110e2F81";

    private final JPanel mainComponent;
    private final JfxDropDownToolBarButton pieChartMenu;
    private final JfxRadioButtonMenuItem mediatorPieChartMenu;
    private final JfxRadioButtonMenuItem channelPieChartMenu;
    private final JfxRadioButtonMenuItem nePieChartMenu;
    private final JfxPieChart chart;
    private final Map<Chart, Map<ChartState, JfxPieChartData>> allChartData;

    /**
     * The framework will instantiate by reflection.
     */
    public StateSummaryView(@Nonnull final String title, @Nonnull final StateSummaryDocument doc) {
        super(ID, title, doc, RESIZABLE, DefaultHelpIds.STATE_SUMMARY_VIEW.getValue());

        checkNotNull(title);
        checkNotNull(doc);

        mainComponent = new JPanel();
        mainComponent.setLayout(new BoxLayout(mainComponent, BoxLayout.LINE_AXIS));
        mainComponent.setPreferredSize(new Dimension(MAIN_COMPONENT_PREFERRED_WIDTH, MAIN_COMPONENT_PREFERRED_HEIGHT));

        nePieChartMenu = new JfxRadioButtonMenuItem(new ActionSelect().ne());
        channelPieChartMenu = new JfxRadioButtonMenuItem(new ActionSelect().channel());
        mediatorPieChartMenu = new JfxRadioButtonMenuItem(new ActionSelect().mediator());

        pieChartMenu = new JfxDropDownToolBarButton(StateSummaryLabels.SELECT_PIECHART.guiName(),
                ResourcesIconFactory.ICON_TOOL_PIECHART_16, EToolBarButtonStyle.SMALL, buildSelectPieChartMenu(), true);

        allChartData = new ConcurrentHashMap<>();

        createNeDataSet();
        createMediatorDataSet();
        createChannelDataSet();

        chart = new JfxPieChart();

        chart.roundValuesToInt(true);
        mainComponent.add(createPieChartPanel());

        configPieChart(Chart.NETWORK_ELEMENTS);

        initControls();
    }

    /**
     * @see FrameworkView#getButtonActions()
     */
    @Override protected List<? extends Object> getButtonActions() {
        final List<Object> buttons = new ArrayList<>();
        buttons.add(pieChartMenu);
        return buttons;
    }

    /**
     * @see FrameworkView#eventClosing()
     */
    @Override public void eventClosing() {
        getFrameworkDocument().removeChangeListeners();
        super.eventClosing();
    }

    /**
     * @see FrameworkView#getMainComponent()
     */
    @Override protected JComponent getMainComponent() {
        return mainComponent;
    }

    /**
     * @see FrameworkView#getIcon()
     */
    @Override public Icon getIcon() {
        return ResourcesIconFactory.ICON_WINDOW_STATE_SUMMARY_16;
    }

    /**
     * @see FrameworkView#getFrameworkDocument()
     */
    @Nonnull
    @Override public StateSummaryDocument getFrameworkDocument() {
        return (StateSummaryDocument) super.getFrameworkDocument();
    }

    /**
     * @see FrameworkView#updateData(Object)
     */
    @Override public final void updateData(final Object result) {
        if (!SwingUtilities.isEventDispatchThread()) {
            throw new UnsupportedOperationException("Should be called in the EDT");
        }
    }

    final Map<Chart, Map<ChartState, JfxPieChartData>> getAllChartData() {
        return allChartData;
    }

    private JfxPopupMenu buildSelectPieChartMenu() {
        final ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(nePieChartMenu);
        buttonGroup.add(channelPieChartMenu);
        buttonGroup.add(mediatorPieChartMenu);

        final JfxPopupMenu choosePieChartMenu = new JfxPopupMenu();
        choosePieChartMenu.add(nePieChartMenu);
        choosePieChartMenu.add(channelPieChartMenu);
        choosePieChartMenu.add(mediatorPieChartMenu);
        nePieChartMenu.setSelected(true);

        return choosePieChartMenu;
    }

    private JPanel createPieChartPanel() {
        final JPanel panel = new JPanel(new BorderLayout());
        panel.add(chart, BorderLayout.CENTER);
        return panel;
    }

    /*
     * Create initial list for NEs
     */
    private void createNeDataSet() {
        allChartData.put(Chart.NETWORK_ELEMENTS, initializeChartData());
    }

    /*
     * Create initial list for Channels
     */
    private void createChannelDataSet() {
        allChartData.put(Chart.CHANNELS, initializeChartData());
    }

    /*
     * Create initial list for Mediators
     */
    private void createMediatorDataSet() {
        allChartData.put(Chart.MEDIATORS, initializeChartData());
    }

    private EnumMap<ChartState, JfxPieChartData> initializeChartData() {
        EnumMap<ChartState, JfxPieChartData> data = new EnumMap<>(ChartState.class);

        data.put(ChartState.ACTIVE, ChartState.ACTIVE.initialize());
        data.put(ChartState.ACTIVATING, ChartState.ACTIVATING.initialize());
        data.put(ChartState.INACTIVE, ChartState.INACTIVE.initialize());
        data.put(ChartState.FAILED, ChartState.FAILED.initialize());
        data.put(ChartState.UNMANAGED, ChartState.UNMANAGED.initialize());

        return data;
    }

    /*
     * Select and configure chart by type selected
     */
    private void configPieChart(final Chart selectedChart) {
        chart.setTitle(selectedChart.getLabel());
        chart.setData(allChartData.getOrDefault(selectedChart, newConcurrentMap()).values());
    }

    private class ActionSelect {
        JfxAction mediator() {
            return new JfxAction(StateSummaryLabels.MEDIATOR_PIECHART.guiName(),
                    StateSummaryLabels.MEDIATOR_PIECHART.guiName(), ACTION_GUI_NAME,
                    a -> configPieChart(Chart.MEDIATORS), null, null);
        }

        JfxAction channel() {
            return new JfxAction(StateSummaryLabels.CHANNEL_PIECHART.guiName(),
                    StateSummaryLabels.CHANNEL_PIECHART.guiName(), ACTION_GUI_NAME, a -> configPieChart(Chart.CHANNELS),
                    null, null);
        }

        JfxAction ne() {
            return new JfxAction(StateSummaryLabels.NE_PIECHART.guiName(), StateSummaryLabels.NE_PIECHART.guiName(),
                    ACTION_GUI_NAME, a -> configPieChart(Chart.NETWORK_ELEMENTS), null, null);
        }
    }
}