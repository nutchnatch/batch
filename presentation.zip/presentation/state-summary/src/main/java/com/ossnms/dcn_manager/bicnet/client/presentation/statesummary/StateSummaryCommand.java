package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginView;
import com.ossnms.bicnet.framework.client.command.FrameworkCommand;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandHandler;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginViewFactory;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.DcnPluginLabels;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.StateSummaryLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static java.util.Optional.ofNullable;
import static org.apache.commons.lang3.StringUtils.EMPTY;

/**
 * @see FrameworkCommand
 */
public class StateSummaryCommand extends FrameworkCommand {
    private static final long serialVersionUID = 2560905399295947640L;
    private static final Logger LOGGER = LoggerFactory.getLogger(StateSummaryCommand.class);
    private static final FrameworkCommandID CMD_ID = new FrameworkCommandID(StateSummaryCommand.class.getName());

    private static final String GUI_NAME = "StateSummary";
    private static final String FILTER = EMPTY;
    private static final String ACCELERATOR = EMPTY;

    public StateSummaryCommand() {
        setCommandID(CMD_ID);
        setCmdDetails(
                DcnPluginLabels.MENU_NAME.toString(),
                CMD_ID.toString(),
                FILTER,
                ACCELERATOR,
                StateSummaryLabels.MENU_SHORT_DESCRIPTION.toString(),
                StateSummaryLabels.MENU_LONG_DESCRIPTION.toString(),
                ResourcesIconFactory.ICON_WINDOW_STATE_SUMMARY_16,
                DcnPluginLabels.DCN_MENU_NAME.toString(),
                StateSummaryLabels.MENU_NAME.toString());

        setPluginHelper(DcnPluginHelperSingleton.getInstance());
        setActionListener(new FrameworkCommandHandler(CMD_ID));
        setActionType(BiCNetPluginActionType.MANAGEMENT);
        setComponentName(GUI_NAME);
        setSecurityId(SecureAction.OPEN_STATE_STATISTIC_SAN.getIdentifier());
    }

    /**
     * @see FrameworkCommand#clone()
     */
    @Override public IFrameworkCommand clone(final IManagedObject[] selectedObjects) {
        return new StateSummaryCommand();
    }

    /**
     * @see FrameworkCommand#execute(IManagedObject[])
     */
    @Override public boolean execute(final IManagedObject[] selectedObjects) {
        try {
            final StateSummaryView view = FrameworkPluginViewFactory
                    .createView(StateSummaryDocument.class, StateSummaryView.class, StateSummaryLabels.TITLE.toString(),
                            selectedObjects, DcnPluginHelperSingleton.getInstance(), this,
                            BiCNetPluginFrameType.INTERNAL);
            setView(view);
            view.getFrameworkDocument().addChangeListeners(view.getAllChartData());
        } catch (final Exception e) {
            LOGGER.error("Error creating DCN State Summary view", e);
            return false;
        }

        return true;
    }

    /**
     * @see FrameworkCommand#bringViewToFront(BiCNetPluginView)
     */
    @Override public void bringViewToFront(final BiCNetPluginView view) {
        ofNullable(view).map(StateSummaryView.class::cast).ifPresent(StateSummaryView::bringToFront);
    }
}