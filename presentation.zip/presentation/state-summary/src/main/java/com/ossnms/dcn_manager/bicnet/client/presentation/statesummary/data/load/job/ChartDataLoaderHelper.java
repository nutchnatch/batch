package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job;

import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;
import org.apache.commons.lang3.tuple.ImmutablePair;
import rx.Observable;
import rx.functions.Action1;
import rx.observables.ConnectableObservable;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateActivating;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateActive;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateFailed;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateInactive;
import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.ChartStateMapper.isChartStateUnmanaged;

/**
 * Helper to load each known {@link ChartState}.
 */
class ChartDataLoaderHelper {
    private final ActionActiveState actionActiveState;
    private final ActionActivatingState actionActivatingState;
    private final ActionFailedState actionFailedState;
    private final ActionInactiveState actionInactiveState;
    private final ActionUnmanagedState actionUnmanagedState;

    ChartDataLoaderHelper() {
        actionActiveState = new ActionActiveState();
        actionActivatingState = new ActionActivatingState();
        actionFailedState = new ActionFailedState();
        actionInactiveState = new ActionInactiveState();
        actionUnmanagedState = new ActionUnmanagedState();
    }

    /**
     * Initialize the the chart data.
     *
     * @param elements Collection of a pair of id and info(that contains a
     * {@link com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState})
     * @return A loaded map that contains the {@link ChartState} and the list o ids that belongs.
     */
    Map<ChartState, Collection<Integer>> initialize(Collection<ImmutablePair<Integer, GuiInfo<?>>> elements) {
        Map<ChartState, Collection<Integer>> allData = new ConcurrentHashMap<>();

        final Observable<ImmutablePair<Integer, GuiInfo<?>>> observe = Observable.from(elements).doOnCompleted(() -> {
            allData.put(ChartState.ACTIVE, actionActiveState.getStates());
            allData.put(ChartState.ACTIVATING, actionActivatingState.getStates());
            allData.put(ChartState.INACTIVE, actionInactiveState.getStates());
            allData.put(ChartState.FAILED, actionFailedState.getStates());
            allData.put(ChartState.UNMANAGED, actionUnmanagedState.getStates());
        });

        final ConnectableObservable<ImmutablePair<Integer, GuiInfo<?>>> publish = observe.publish();

        publish.subscribe(actionActiveState);
        publish.subscribe(actionActivatingState);
        publish.subscribe(actionInactiveState);
        publish.subscribe(actionFailedState);
        publish.subscribe(actionUnmanagedState);
        publish.connect();

        return allData;
    }

    private abstract static class ActionState implements Action1<ImmutablePair<Integer, GuiInfo<?>>> {
        private final Collection<Integer> states = new HashSet<>();

        final Collection<Integer> getStates() {
            return states;
        }
    }

    private static class ActionActiveState extends ActionState {
        @Override public void call(ImmutablePair<Integer, GuiInfo<?>> info) {
            if (isChartStateActive(info.getRight().getGuiActiveActualActivationState())) {
                getStates().add(info.getLeft());
            }
        }
    }

    private static class ActionActivatingState extends ActionState {
        @Override public void call(ImmutablePair<Integer, GuiInfo<?>> info) {
            if (isChartStateActivating(info.getRight().getGuiActiveActualActivationState())) {
                getStates().add(info.getLeft());
            }
        }
    }

    private static class ActionInactiveState extends ActionState {
        @Override public void call(ImmutablePair<Integer, GuiInfo<?>> info) {
            if (isChartStateInactive(info.getRight().getGuiActiveActualActivationState())) {
                getStates().add(info.getLeft());
            }
        }
    }

    private static class ActionUnmanagedState extends ActionState {
        @Override public void call(ImmutablePair<Integer, GuiInfo<?>> info) {
            if (isChartStateUnmanaged(info.getRight().getGuiActiveActualActivationState())) {
                getStates().add(info.getLeft());
            }
        }
    }

    private static class ActionFailedState extends ActionState {
        @Override public void call(ImmutablePair<Integer, GuiInfo<?>> info) {
            if (isChartStateFailed(info.getRight().getGuiActiveActualActivationState())) {
                getStates().add(info.getLeft());
            }
        }
    }
}
