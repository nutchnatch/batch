package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.listener;

import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job.NeChartDataLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.StateModelUpdater;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.ChartUnmanagedStateConverter.tryChangeToUnmanagedState;

public class NeStateChangedEventListener extends ChartStateEventListener<Integer, FullNeData> {

    public NeStateChangedEventListener(@Nonnull final StateModelUpdater<Integer, GuiInfo<?>> modelUpdater,
            @Nonnull final NeChartDataLoader dataLoader) {
        super(modelUpdater, dataLoader);
    }

    @Override public void elementRemoved(@Nonnull final FullNeData element) {
        getModelUpdater().removeData(element.getInfo().getNeId());
    }

    @Override public void elementAdded(@Nonnull final FullNeData element) {
        getModelUpdater().insertData(element.getInfo().getNeId(), tryChangeToUnmanagedState(element).getInfo());
    }

    @Override public void elementUpdated(@Nonnull final FullNeData element) {
        getModelUpdater().updateData(element.getInfo().getNeId(), tryChangeToUnmanagedState(element).getInfo());
    }
}
