package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.listener;

import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job.ChannelChartDataLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.StateModelUpdater;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.ChartUnmanagedStateConverter.tryChangeToUnmanagedState;

public class ChannelStateChangedEventListener extends ChartStateEventListener<Integer, FullChannelData> {

    public ChannelStateChangedEventListener(@Nonnull final StateModelUpdater<Integer, GuiInfo<?>> modelUpdater,
            @Nonnull final ChannelChartDataLoader dataLoader) {
        super(modelUpdater, dataLoader);
    }

    @Override public void elementRemoved(@Nonnull final FullChannelData element) {
        getModelUpdater().removeData(element.getInfo().getChannelId());
    }

    @Override public void elementAdded(@Nonnull final FullChannelData element) {
        getModelUpdater().insertData(element.getInfo().getChannelId(), tryChangeToUnmanagedState(element).getInfo());
    }

    @Override public void elementUpdated(@Nonnull final FullChannelData element) {
        getModelUpdater().updateData(element.getInfo().getChannelId(), tryChangeToUnmanagedState(element).getInfo());
    }
}
