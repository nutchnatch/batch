package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.listener;

import com.ossnms.dcn_manager.bicnet.client.api.exception.DcnClientException;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job.ChartDataLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.StateModelUpdater;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

/**
 * Abstraction fo Events Listeners.
 */
public abstract class ChartStateEventListener<K, V> implements EventChangeListener<V> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChartStateEventListener.class);

    private final StateModelUpdater<Integer, GuiInfo<?>> modelUpdater;
    private final ChartDataLoader<K,V> dataLoader;

    public ChartStateEventListener(@Nonnull final StateModelUpdater<Integer, GuiInfo<?>> modelUpdater,
            @Nonnull final ChartDataLoader<K,V> dataLoader) {
        this.modelUpdater = modelUpdater;
        this.dataLoader = dataLoader;
    }

    @Override public void removeAll() {
    }

    protected StateModelUpdater<Integer, GuiInfo<?>> getModelUpdater() {
        return modelUpdater;
    }

    public void addAll() {
        try {
            modelUpdater.insertAllData(dataLoader.load());
        } catch (DcnClientException e) {
            LOGGER.error("Error to fetch objects for summary view", e);
        }
    }
}
