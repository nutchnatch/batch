package com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.listener;

import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.data.load.job.MediatorChartDataLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.ChartUnmanagedStateConverter;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.model.StateModelUpdater;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiInfo;

import javax.annotation.Nonnull;

public class MediatorStateChangedEventListener extends ChartStateEventListener<Integer, FullMediatorData>{

    public MediatorStateChangedEventListener(@Nonnull final StateModelUpdater<Integer, GuiInfo<?>> modelUpdater,
            @Nonnull final MediatorChartDataLoader dataLoader) {
        super(modelUpdater, dataLoader);
    }

    @Override public void elementRemoved(@Nonnull final FullMediatorData element) {
        getModelUpdater().removeData(element.getInfo().getMediatorId());
    }

    @Override public void elementAdded(@Nonnull final FullMediatorData element) {
        getModelUpdater().insertData(element.getInfo().getMediatorId(), ChartUnmanagedStateConverter
                .tryChangeToUnmanagedState(element).getInfo());
    }

    @Override public void elementUpdated(@Nonnull final FullMediatorData element) {
        getModelUpdater().updateData(element.getInfo().getMediatorId(), ChartUnmanagedStateConverter
                .tryChangeToUnmanagedState(element).getInfo());
    }
}
