package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

public class NodeCommandExecutorTest {

    private IManagedObject[] nodes;
    private IEM nodeChannel;
    private INE nodeNe;
    private IMediator nodeMediator;
    private SecureActionValidation secureActionValidation;

    @Before
    public void setup() {
        secureActionValidation = mock(SecureActionValidation.class);
        nodeChannel = new EMItem();
        nodeChannel.setId(1);
        nodeNe = new NEItem();
        nodeNe.setId(1);
        nodeMediator = new MediatorItem();
        nodeMediator.setId(1);

        nodes = new IManagedObject[]{nodeChannel, nodeNe, nodeMediator};
    }

    @Test
    public void testExecuteAllCommands() throws CommandException {
        final CommandTest commandEm = new CommandTest();
        final CommandTest commandMediator = new CommandTest();
        final CommandTest commandNe = new CommandTest();
        
        NodeCommandExecutor.from(nodes)
                           .addCommand(commandEm, IEM.class)
                           .addCommand(commandNe, INE.class)
                           .addCommand(commandMediator, IMediator.class)
                           .execute();
        
        assertTrue(commandEm.executed());
        assertTrue(commandMediator.executed());
        assertTrue(commandNe.executed());
    }
    
    @Test
    public void testExecuteOnlyOneType() throws CommandException {
        final CommandTest commandEm = new CommandTest();
        
        NodeCommandExecutor.from(nodes)
                           .addCommand(commandEm, IEM.class)
                           .execute();

        assertTrue(commandEm.executed());
    }
    
    @Test
    public void testOnlyFirstCommands() throws CommandException {
        final CommandTest commandEm = new CommandTest();
        final CommandTest commandMediator = new CommandTest();
        final CommandTest commandNe = new CommandTest();
        
        NodeCommandExecutor.from(nodes)
                           .addCommand(commandEm, IEM.class)
                           .addCommand(commandNe, INE.class)
                           .addCommand(commandMediator, IMediator.class)
                           .stopAfterFirstCommandExecution()
                           .execute();

        assertTrue(commandEm.executed());
        assertFalse(commandMediator.executed());
        assertFalse(commandNe.executed());
    }
    
    private static class CommandTest implements Command<IManagedObject> {

        private boolean executed = false; 
        
        @Override
        public void call(IManagedObject id) {
            executed = true;
        }

        public boolean executed() {
            return executed;
        }
    }
}
