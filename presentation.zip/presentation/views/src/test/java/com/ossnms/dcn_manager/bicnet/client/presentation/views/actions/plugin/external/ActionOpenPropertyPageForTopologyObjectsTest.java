package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.api.Containers;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ContainerType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeType;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionOpenPropertyPageForTopologyObjectsTest extends TestsHelper {

    private ActionOpenPropertyPageForTopologyObjects action;

    @Mock private PropertyPagesRepository propertyPagesRepository;
    @Mock private NeType neType;
    @Mock private ContainerType containerType;

    @Before public void setUp() throws Exception {
        action = new ActionOpenPropertyPageForTopologyObjects(commonServices, repositoryManager,
                propertyPagesRepository);

        when(staticConfiguration.findContainerType(anyString())).thenReturn(Optional.of(containerType));
        when(propertyPagesRepository.getPropertyPage(containerType)).thenReturn(new Page());
    }

    @Test public void eventPluginActionPerformed_for_nes() throws Exception {
        when(staticConfiguration.findNeType(anyString())).thenReturn(Optional.of(neType));
        when(propertyPagesRepository.getPropertyPage(neType)).thenReturn(new Page());
        when(neRepository.get(ID_1)).thenReturn(Optional.of(buildFullNeData(ID_1, ID_1, "")));
        when(neRepository.get(ID_2)).thenReturn(Optional.of(buildFullNeData(ID_2, ID_1, "")));

        action.eventPluginActionPerformed(
                new IManagedObject[] { buildTopologicalSymbol(ID_1), buildTopologicalSymbol(ID_2) });

        verify(neRepository, times(2)).get(ID_1);
        verify(neRepository, times(2)).get(ID_2);
        verify(propertyPagesRepository, atLeastOnce()).getPropertyPage(neType);

        verify(containerRepository, never()).get(ID_1);
        verify(containerRepository, never()).get(ID_2);
        verify(systemContainerRepository, never()).get(ID_1);
        verify(systemContainerRepository, never()).get(ID_2);
    }

    @Test public void eventPluginActionPerformed_for_containers() throws Exception {
        when(containerRepository.get(ID_1)).thenReturn(Optional.of(buildContainer(ID_1)));
        when(containerRepository.get(ID_2)).thenReturn(Optional.of(buildContainer(ID_2)));

        action.eventPluginActionPerformed(
                new IManagedObject[] { buildTopologicalContainer(ID_1), buildTopologicalContainer(ID_2) });

        verify(containerRepository, times(1)).get(ID_1);
        verify(containerRepository, times(1)).get(ID_2);
        verify(propertyPagesRepository, atLeastOnce()).getPropertyPage(containerType);

        verify(neRepository, never()).get(ID_1);
        verify(neRepository, never()).get(ID_2);
        verify(systemContainerRepository, never()).get(ID_1);
        verify(systemContainerRepository, never()).get(ID_2);
    }

    @Test public void eventPluginActionPerformed_for_system() throws Exception {
        when(systemContainerRepository.get(ID_1)).thenReturn(Optional.of(buildSystemContainer(ID_1)));
        when(systemContainerRepository.get(ID_2)).thenReturn(Optional.of(buildSystemContainer(ID_2)));

        action.eventPluginActionPerformed(
                new IManagedObject[] { buildTopologicalContainerSystem(ID_1), buildTopologicalContainerSystem(ID_2) });

        verify(systemContainerRepository, times(1)).get(ID_1);
        verify(systemContainerRepository, times(1)).get(ID_2);
        verify(propertyPagesRepository, atLeastOnce()).getPropertyPage(containerType);

        verify(containerRepository, never()).get(ID_1);
        verify(containerRepository, never()).get(ID_2);
        verify(neRepository, never()).get(ID_1);
        verify(neRepository, never()).get(ID_2);
    }

    @Test public void isPluginActionAllowed_for_nes() throws Exception {
        final FullNeData fullNeData1 = buildFullNeData(ID_1, ID_1, "");
        final FullNeData fullNeData2 = buildFullNeData(ID_2, ID_1, "");

        when(secureActionValidation.checkPermission(SecureAction.OP_PROPERTIES_NE_SAN, fullNeData1.getNe(),
                fullNeData2.getNe())).thenReturn(true);

        when(neRepository.get(ID_1)).thenReturn(Optional.of(buildFullNeData(ID_1, ID_1, "")));
        when(neRepository.get(ID_2)).thenReturn(Optional.of(buildFullNeData(ID_2, ID_1, "")));

        final boolean allowed = action.isPluginActionAllowed(
                new IManagedObject[] { buildTopologicalSymbol(ID_1), buildTopologicalSymbol(ID_2) });

        assertThat(allowed, is(true));

        verify(neRepository, times(1)).get(ID_1);
        verify(neRepository, times(1)).get(ID_2);
    }

    @Test public void isPluginActionAllowed_for_containers() throws Exception {
        final IGenericContainer container1 = buildContainer(ID_1);
        final IGenericContainer container2 = buildContainer(ID_2);

        when(secureActionValidation.checkPermission(SecureAction.OP_PROPERTIES_CONTAINER_SAN, container1,
                container2)).thenReturn(true);

        when(containerRepository.get(ID_1)).thenReturn(Optional.of(container1));
        when(containerRepository.get(ID_2)).thenReturn(Optional.of(container2));

        final boolean allowed = action.isPluginActionAllowed(
                new IManagedObject[] { buildTopologicalContainer(ID_1), buildTopologicalContainer(ID_2) });

        assertThat(allowed, is(true));

        verify(containerRepository, times(1)).get(ID_1);
        verify(containerRepository, times(1)).get(ID_2);
    }

    @Test public void isPluginActionAllowed_for_system() throws Exception {
        final ISystemContainer container1 = buildSystemContainer(ID_1);
        final ISystemContainer container2 = buildSystemContainer(ID_2);

        when(secureActionValidation.checkPermission(SecureAction.OP_PROPERTIES_CONTAINER_SAN, container1,
                container2)).thenReturn(true);

        when(systemContainerRepository.get(ID_1)).thenReturn(Optional.of(container1));
        when(systemContainerRepository.get(ID_2)).thenReturn(Optional.of(container2));

        final boolean allowed = action.isPluginActionAllowed(
                new IManagedObject[] { buildTopologicalContainerSystem(ID_1), buildTopologicalContainerSystem(ID_2) });

        assertThat(allowed, is(true));

        verify(systemContainerRepository, times(1)).get(ID_1);
        verify(systemContainerRepository, times(1)).get(ID_2);
    }

    @Test public void isPluginActionAllowed_false_different_types() throws Exception {
        final ISystemContainer container1 = buildSystemContainer(ID_1);
        final IGenericContainer container2 = buildContainer(ID_2);

        when(secureActionValidation.checkPermission(SecureAction.OP_PROPERTIES_CONTAINER_SAN, container1)).thenReturn(true);
        when(secureActionValidation.checkPermission(SecureAction.OP_PROPERTIES_CONTAINER_SAN, container2)).thenReturn(true);

        when(systemContainerRepository.get(ID_1)).thenReturn(Optional.of(container1));
        when(containerRepository.get(ID_2)).thenReturn(Optional.of(container2));

        final boolean allowed = action.isPluginActionAllowed(
                new IManagedObject[] { buildTopologicalContainerSystem(ID_1), buildTopologicalContainer(ID_2) });

        assertThat(allowed, is(false));

        verify(systemContainerRepository, times(1)).get(ID_1);
        verify(containerRepository, times(1)).get(ID_2);
    }
    
    @Test public void isPluginActionAllowed_for_root_container() throws Exception {
        final IGenericContainer container1 = buildContainer(Containers.ROOT_CONTAINER_ID);

        when(secureActionValidation.checkPermission(SecureAction.OP_PROPERTIES_CONTAINER_SAN, container1)).thenReturn(true);
        when(containerRepository.get(Containers.ROOT_CONTAINER_ID)).thenReturn(Optional.of(container1));

        final boolean allowed = action.isPluginActionAllowed(
                new IManagedObject[] { buildTopologicalContainer(Containers.ROOT_CONTAINER_ID)});

        assertThat(allowed, is(false));

        verify(containerRepository, times(1)).get(Containers.ROOT_CONTAINER_ID);
    }
}