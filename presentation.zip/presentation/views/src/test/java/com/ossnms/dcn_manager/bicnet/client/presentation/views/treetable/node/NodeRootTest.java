package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import org.apache.commons.lang3.ArrayUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import javax.swing.ImageIcon;
import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NodeRootTest {
 private IconManager iconManager;
    
    private final ImmutableNodeRoot mutableRoot;        
    private NodeRoot nodeRoot;
    
    public NodeRootTest() {
        mutableRoot = new ImmutableNodeRoot(1, "name");
    }

    @Before
    public void setup() {
        final Optional<ImageIcon> imaOptional = Optional.empty();

        iconManager = mock(IconManager.class);        
        when(iconManager.findNetworkIcon(Matchers.any(IEM.class), Matchers.anyInt())).thenReturn(imaOptional);
        
        nodeRoot = new NodeRoot(1, "name");
    }

    @Test
    public void testGetAllowsChildren() {
        assertTrue(nodeRoot.getAllowsChildren());
    }
    
    @Test
    public void testToString() {
        assertThat(nodeRoot.toString(), is(nodeRoot.getValue().getName()));
    }
    
    @Test
    public void testHashCode() {
        final int hash1 = new NodeRoot(1, "name").hashCode();
        final int hash2 = new NodeRoot(2, "name").hashCode();
        final int hash3 = new NodeRoot(3, "name_3").hashCode();
        
        assertThat(nodeRoot.hashCode(), is(hash1));
        assertThat(nodeRoot.hashCode(), not(is(hash2)));
        assertThat(nodeRoot.hashCode(), not(is(hash3)));
    }
    
    @Test
    public void testGetParentPath_no_parent() {
        final Node[] parents = nodeRoot.getParentPath();
        
        assertTrue(ArrayUtils.isEmpty(parents));
    }
    
    @Test
    public void testEquals() {
        
        final NodeRoot node1 = new NodeRoot(1, "name");
        final NodeRoot node2 = new NodeRoot(2, "name");
        final NodeRoot node3 = new NodeRoot(3, "name_3");
        
        assertTrue(nodeRoot.equals(node1));
        
        assertFalse(nodeRoot.equals(node2));
        assertFalse(nodeRoot.equals(node3));
        assertFalse(nodeRoot.equals(null));
        assertFalse(nodeRoot.equals(new Object()));
    }    
}
