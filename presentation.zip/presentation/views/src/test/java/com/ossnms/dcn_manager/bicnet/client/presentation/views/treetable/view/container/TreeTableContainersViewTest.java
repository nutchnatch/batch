package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.container;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.CurrentViewSingleton;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.TreeTableViewTypes;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.swing.event.ListSelectionEvent;

import java.util.List;
import java.util.Properties;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TreeTableContainersViewTest extends TestsHelper {

    @Mock private TreeTableContainersDocument document;
    @Mock private ListSelectionEvent selectionEvent;
    @Mock private Properties properties;

    private TreeTableContainersView containersView;

    @Before public void setUp() throws Exception {
        when(document.getCommonServices()).thenReturn(commonServices);
        when(document.getRepositoryManager()).thenReturn(repositoryManager);
        CurrentViewSingleton.getInstance().changeCurrentView(TreeTableViewTypes.CONTAINER);

        this.containersView = new TreeTableContainersView("title", document);
    }

    @Test public void testGetButtonActions() throws Exception {
        List<?> buttonActions = containersView.getButtonActions();

        assertNotNull(buttonActions);
        assertThat(buttonActions.size(), is(8));
        assertThat(buttonActions, notNullValue());
    }

    @Test public void testGetProfileId() throws Exception {
        String profileId = containersView.getProfileId();
        assertThat(profileId, is(TreeTableContainersView.class.getName()));
    }

    @Test public void testValueChanged() throws Exception {
        containersView.valueChanged(selectionEvent);
    }

    @Test public void testAddExtraPropertiesToSave() throws Exception {
        containersView.addExtraPropertiesToSave(properties);
    }
    
    @Test public void testGetPrintData(){
        String currentView = containersView.getPrintData().getTitle();
        assertThat(currentView, containsString(TreeTableLabels.CONTAINER_VIEW_TITLE.toString()));
    }
}