package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions;

import com.coriant.widgets.treetable.TreeTable;
import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentTypes;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionCut;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers.CutPasteHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeRoot;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ActionCutTest {

    private final NodeRoot nodeRoot;
    private NeRepository neRepository;
    private ActionCut actionCut;
    private SecureActionValidation secureValidation;
    private final FullNeData ne;

    public ActionCutTest() {
        nodeRoot = new NodeRoot(1, "Root");
        INE neItem = createNe();
        ne = new FullNeData(neItem, new NeInfo(neItem.getId()), null);
    }

    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        TreeTable<Node> table = mock(TreeTable.class);
        neRepository = mock(NeRepository.class);
        RepositoryManager repositoryManager = mock(RepositoryManager.class);
        CommonServices commonServices = mock(CommonServices.class);

        secureValidation =  mock(SecureActionValidation.class);
        Node nodeNe = new NodeNe(ne.getNe().getId(), nodeRoot);

        when(table.getSelectedNodes()).thenReturn(ImmutableList.of(nodeNe));
        when(repositoryManager.getNeRepository()).thenReturn(neRepository);
        when(commonServices.getSecureActionValidation()).thenReturn(secureValidation);

        CutPasteHandler cutPasteHandler = mock(CutPasteHandler.class);
        when(cutPasteHandler.canCut(asList(ne.getNe()))).thenReturn(true);
        
        actionCut = new ActionCut(commonServices, cutPasteHandler);
    }

    @Test
    public void testFulfilled() throws Exception {
        when(neRepository.get(ne.getNe().getId())).thenReturn(Optional.of(ne));
        IManagedObject[] managedObjects = {ne.getNe()};
        when(secureValidation.checkPermission(SecureAction.OP_CUT_SAN, managedObjects)).thenReturn(true);

        assertTrue(actionCut.isPluginActionAllowed(managedObjects));
    }
    
    @Test
    public void testFulfilled_false() {
        assertFalse(actionCut.isPluginActionAllowed(new IManagedObject[0]));
    }
    
    @Test
    public void testActionPerformed() throws Exception {
        actionCut.eventPluginActionPerformed(new IManagedObject[]{createNe()});
    }
    
    private INE createNe() {
        final INE neItem = new NEItem();
        
        neItem.setId(1);
        neItem.setActivation(EnableSwitch.DISABLED);
        neItem.setCommunicationState(CommunicationState.DISCONNECTED);
        neItem.setInitState(InitState.NOT_INITIALIZED);
        neItem.setIdName("NE_IdName");
        neItem.setDisplayAddress("127.0.0.1");
        neItem.setDisplayState("state");
        neItem.setAdditionalInfo("additionalInfo");
        neItem.setConnectedVia("connectedVia");
        neItem.setUsedBy(BiCNetComponentTypes.none());
        neItem.setNeProxyType("hiT7300");
        neItem.setRealNeName("NE_realName");
        
        return neItem;
    }
}
