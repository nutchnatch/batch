package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class ActionDeactivateNEsUnderSystemContainerTest extends TestsHelper {
    private ActionDeactivateNEsUnderSystemContainer action;
    private ISystemContainer systemContainer;

    @Before public void setUp() throws Exception {
        action = new ActionDeactivateNEsUnderSystemContainer(repositoryManager, commonServices);

        systemContainer = buildSystemContainer(ID_1);

        final FullNeData fullNeDataWrongState = buildFullNeData(ID_1, ID_1, "");
        fullNeDataWrongState.getNe().setAssociatedSystemContainerId(ID_1);
        fullNeDataWrongState.getNe().setActivation(EnableSwitch.DISABLED);

        final FullNeData fullNeDataOk = buildFullNeData(ID_2, ID_1, "");
        fullNeDataOk.getNe().setAssociatedSystemContainerId(ID_1);
        fullNeDataOk.getNe().setActivation(EnableSwitch.ENABLED);

        final FullNeData fullNeDataWrongSystemId = buildFullNeData(ID_3, ID_1, "");
        fullNeDataWrongSystemId.getNe().setAssociatedSystemContainerId(0);
        fullNeDataWrongSystemId.getNe().setActivation(EnableSwitch.DISABLED);

        when(neSearchable.findBySystemContainerId(ID_1))
                .thenReturn(ImmutableList.of(fullNeDataWrongState, fullNeDataOk, fullNeDataWrongSystemId));
    }

    @Test public void testGetNEsActive() throws Exception {
        final Collection<INE> nesActive = action.activeNEs(systemContainer).collect(Collectors.toList());

        assertThat(nesActive.size(), is(1));
        assertThat(nesActive.stream().findFirst().filter(n -> n.getId() == ID_2).isPresent(), is(true));
    }
}