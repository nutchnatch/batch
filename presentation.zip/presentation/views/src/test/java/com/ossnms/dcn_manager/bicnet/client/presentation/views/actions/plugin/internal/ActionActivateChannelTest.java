package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobChannelsActivate;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_CHANNELS_SAN;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionActivateChannelTest extends TestsHelper {

    private ActionActivateChannel actionActivateChannel;

    private FullChannelData fullChannelData;

    @Before public void setUp() throws Exception {
        fullChannelData = buildFullChannelData(ID_1, ID_2);
        fullChannelData.getChannel().setActivation(EnableSwitch.DISABLED);

        actionActivateChannel = new ActionActivateChannel(commonServices);
    }

    private <T extends IManagedObjectId> T[] withPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_ACTIVATE_CHANNELS_SAN, objectsToCheck)).thenReturn(true);
        return objectsToCheck;
    }

    private <T extends IManagedObjectId> T[] withoutPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_ACTIVATE_CHANNELS_SAN, objectsToCheck)).thenReturn(false);
        return objectsToCheck;
    }

    @Test public void testMenuName() throws Exception {
        assertThat(actionActivateChannel.getMenuName(), is(TreeTableLabels.ACTIVATE_CHANNEL.toString()));
    }

    @Test public void testDescription() throws Exception {
        assertThat(actionActivateChannel.getShortDescription(), is(TreeTableLabels.ACTIVATE_CHANNEL.toString()));
    }

    @Test public void testIsPluginAllowed_ok_for_IEM_2_objects() throws Exception {
        FullChannelData wrong = buildFullChannelData(ID_2, ID_2);
        wrong.getChannel().setActivation(EnableSwitch.ENABLED);

        boolean pluginActionAllowed = actionActivateChannel
                .isPluginActionAllowed(withPermissions(fullChannelData.getChannel(), wrong.getChannel()));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_for_IEM() throws Exception {
        boolean pluginActionAllowed = actionActivateChannel.isPluginActionAllowed(withPermissions(fullChannelData.getChannel()));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_wrong_object() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        topologicalSymbol.setNetworkElement(new NEIdItem(ID_1));

        boolean pluginActionAllowed = actionActivateChannel
                .isPluginActionAllowed(withPermissions(topologicalSymbol));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_no_permission() throws Exception {
        boolean pluginActionAllowed = actionActivateChannel.isPluginActionAllowed(withoutPermissions(fullChannelData.getChannel()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_wrong_required_state() {
        fullChannelData.getChannel().setActivation(EnableSwitch.ENABLED);

        boolean pluginActionAllowed = actionActivateChannel.isPluginActionAllowed(withPermissions(fullChannelData.getChannel()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void eventPluginActionPerformed_ok_for_IEM() throws Exception {
        actionActivateChannel.eventPluginActionPerformed(withPermissions(fullChannelData.getChannel()));

        verify(dcnPluginHelper, times(1)).queueJob(any(JobChannelsActivate.class));
    }

    @Test public void eventPluginActionPerformed_wrong_object() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        topologicalSymbol.setNetworkElement(new NEIdItem(ID_1));

        actionActivateChannel.eventPluginActionPerformed(withPermissions(topologicalSymbol));

        verify(dcnPluginHelper, never()).queueJob(any(JobChannelsActivate.class));
    }
}