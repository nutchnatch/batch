package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.state;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainProcessException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainRoot;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import org.junit.Before;
import org.junit.Ignore;
import org.mockito.Mockito;

import static java.util.Comparator.comparing;
import static org.mockito.Mockito.mock;

public class RequiredActivationStateChangedTest {
    
    private final NodeDomainRoot nodeRoot = new NodeDomainRoot("Root");
    private RequiredActivationStateChanged activationStateChanged;
    private IconManager iconManager;
    private NodeDomain nodeDomain;
    private NeRepository neRepository;
    private ActivateMediator activateMediator;
    private SecureActionValidation secureActionValidation;
    
    @Before
    public void setup() {
        activationStateChanged = new RequiredActivationStateChanged();
        iconManager = mock(IconManager.class);
        neRepository = mock(NeRepository.class);
        secureActionValidation = mock(SecureActionValidation.class);
        nodeDomain = new NodeDomain(1, nodeRoot, comparing(Object::toString, String::compareToIgnoreCase));
        activateMediator =  mock(ActivateMediator.class);
    }
    
    @Ignore
    public void testProcess() throws ChainProcessException{
        final ImmutableList<Node> nodes = ImmutableList.of((Node)nodeDomain);
        activationStateChanged.process(nodes);
        Mockito.verify(activateMediator, Mockito.atLeastOnce()).process(nodes);
    }
}
