package com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.assignment;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.FrameworkView;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobAssociateNEsWithContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.assignment.load.NeAssignmentLoader;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeContainerAssignmentSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ContainerRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NEContainerAssignmentRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.tools.jfx.JfxLookAndFeel;

import javax.swing.JComponent;
import javax.swing.JPanel;
import java.util.Collection;
import java.util.List;

import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AssignmentDialogTest {


    /**
     * Launcher of the view to test layout locally
     */
    public static void main(String[] args) throws RepositoryException {
        JfxLookAndFeel.initLookAndFeel();
        List<IGenericContainer> containers = asList(
                container(0, "Root", 0),
                container(1, "Container 1", 0),
                    container(11, "Container 1 1", 1),
                    container(12, "Container 1 2", 1),
                    container(13, "Container 1 3", 1),
                container(2, "Container 2", 0),
                    container(21, "Container 2 1", 2),
                container(3, "Container 3", 0),
                    container(31, "Container 3 1", 3),
                    container(32, "Container 3 2", 3),
                    container(33, "Container 3 3", 3),
                container(4, "Container 4", 0),
                    container(41, "Container 4 1", 4),
                    container(42, "Container 4 2", 4),
                    container(43, "Container 4 3", 4),
                container(5, "Container 5", 0),
                    container(51, "Container 5 1", 5),
                    container(52, "Container 5 2", 5),
                    container(53, "Container 5 3", 5),
                container(6, "Container 6", 0),
                    container(61, "Container 6 1", 6),
                    container(62, "Container 6 2", 6),
                    container(63, "Container 6 3", 6)
                
                );

        INE neId = ne(2, "Some NE 123");
        
        List<INeGenericContainerAssignment> assignments = asList(
                association(1, neId, true),
                association(21, neId, false)
                );
        
        new AssignmentDialog(emptyView(), new AssignmentController(model(containers, assignments, neId), common())).showDialogWindow();
    }

    private static CommonServices common() {
        return mock(CommonServices.class);
    }

    private static AssignmentModel<INEId> model(List<IGenericContainer> containers, List<INeGenericContainerAssignment> assignments, INE neId) throws RepositoryException {
        ContainerRepository containerRepo = mock(ContainerRepository.class);
        when(containerRepo.getAll()).thenReturn(containers);
        RepositoryManager repo = mock(RepositoryManager.class);
        when(repo.getContainerRepository()).thenReturn(containerRepo);
        NEContainerAssignmentRepository assignmentRepository = mock(NEContainerAssignmentRepository.class);
        NeContainerAssignmentSearchable queries = mock(NeContainerAssignmentSearchable.class);
        when(queries.findByNetworkElementId(neId.getId())).thenReturn(assignments);
        when(assignmentRepository.queries()).thenReturn(queries);
        when(repo.getNEContainerAssignmentRepository()).thenReturn(assignmentRepository);
        NeRepository neRepo = neRepo(asList(neId));
        when(repo.getNeRepository()).thenReturn(neRepo);
        NeAssignmentLoader loader = new NeAssignmentLoader(repo, asList(neId));
        return new AssignmentModel<>(loader, JobAssociateNEsWithContainer::new);
    }

    private static INE ne(int id, String name) {
        NEItem ne = new NEItem();
        ne.setId(id);
        ne.setIdName(name);
        return ne;
    }

    private static INeGenericContainerAssignment association(int container, INE neId, boolean isDefault) {
        NeGenericContainerAssignmentItem assignmentItem = new NeGenericContainerAssignmentItem();
        assignmentItem.setGenericContainerId(container);
        assignmentItem.setNetworkElement(neId);
        assignmentItem.setPrimary(isDefault);
        return assignmentItem;
    }

    private static IGenericContainer container(int id, String name, int parent) {
        GenericContainerItem container = new GenericContainerItem();
        container.setId(id);
        container.setIdName(name);
        container.setParentId(parent);
        return container;
    }

    private static NeRepository neRepo(Collection<INE> nes) throws RepositoryException {
        NeRepository neRepo = mock(NeRepository.class);
        List<Integer> ids = nes.stream().map(INEId::getId).collect(toList());
        List<FullNeData> data = nes.stream().map(ne -> new FullNeData(ne, null, null)).collect(toList());
        when(neRepo.get(ids)).thenReturn(data);
        return neRepo;
    }
    
    private static FrameworkView emptyView() {
        FrameworkDocument doc = mock(FrameworkDocument.class);
        return new FrameworkView("", "", doc, false, 0) {
            @Override protected JComponent getMainComponent() {
                return new JPanel();
            }
            @Override public void updateData(Object p_key) {
            }
        };
    }
}