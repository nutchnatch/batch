package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentTypes;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;

import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_COMMISSIONING_STATUS;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_INFO;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NAME;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NETWORK_NAME;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NE_STATE;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_STATE;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_SYNC_STATE;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_TYPE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class NodeNeTest {
    private NodeRoot nodeRoot;
    private NodeChannel nodeChannel;
    private FullNeData fullNeData;
    private NodeNe nodeNe;

    @Before
    public void setup() {
        nodeRoot = new NodeRoot(1, "Root");
        nodeChannel = new NodeChannel(1, nodeRoot);
        INE ne = createNe();

        fullNeData = new FullNeData(ne, new NeInfo(ne.getId()), null);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        nodeNe = new NodeNe(fullNeData.getNe().getId(), nodeChannel);
    }

    @Test public void testToolTip_for_inactive_ne() throws Exception {
        nodeNe.getValue().setActualActivationState(GuiActualActivationState.INACTIVE);

        nodeNe.getValue().setName("ne_name");
        nodeNe.getColumns().setValue(ColumnId.STATE, "ne_state");
        nodeNe.getColumns().setValue(ColumnId.TYPE, "ne_type");
        nodeNe.getColumns().setValue(ColumnId.NETWORK_NAME, "ne_nw_name");
        nodeNe.getColumns().setValue(ColumnId.INFO, "ne_info");

        final String toolTip = nodeNe.getToolTip(ToolTipType.NODE);

        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_NAME) + "</b>ne_name"));
        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_NETWORK_NAME) + "</b>ne_nw_name"));
        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_TYPE) + "</b>ne_type"));
        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_STATE) + "</b>ne_state"));
        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_INFO) + "</b>ne_info"));

        assertThat(toolTip, Matchers.not(containsString(COLUMN_SYNC_STATE.toString())));
        assertThat(toolTip, Matchers.not(containsString(COLUMN_NE_STATE.toString())));
        assertThat(toolTip, Matchers.not(containsString(COLUMN_COMMISSIONING_STATUS.toString())));
    }

    @Test public void testToolTip_for_active_ne() throws Exception {
        nodeNe.getValue().setActualActivationState(GuiActualActivationState.ACTIVE);

        nodeNe.getValue().setName("ne_name");
        nodeNe.getColumns().setValue(ColumnId.STATE, "ne_state");
        nodeNe.getColumns().setValue(ColumnId.TYPE, "ne_type");
        nodeNe.getColumns().setValue(ColumnId.NETWORK_NAME, "ne_nw_name");
        nodeNe.getColumns().setValue(ColumnId.INFO, "ne_info");

        nodeNe.setSynchState(ScsSyncState.SYNCHRONIZED);
        nodeNe.setCommissioningStatus(CommissioningStatusSummary.NOT_COMMISSIONED);
        nodeNe.setNeStatusInfo(fullNeData.getNeStatusInfo());

        final String toolTip = nodeNe.getToolTip(ToolTipType.NODE);

        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_NAME) + "</b>ne_name"));
        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_NETWORK_NAME) + "</b>ne_nw_name"));
        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_TYPE) + "</b>ne_type"));
        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_STATE) + "</b>ne_state"));
        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_INFO) + "</b>ne_info"));
        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_SYNC_STATE) + "</b>" + ScsSyncState.SYNCHRONIZED.guiLabel()));
        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_NE_STATE) + "</b>" + fullNeData.getNeStatusInfo().getInfo().getName()));
        assertThat(toolTip, containsString("<b>" + nodeNe.delimiter(COLUMN_COMMISSIONING_STATUS) + "</b>" + CommissioningStatusSummary.NOT_COMMISSIONED.guiLabel()));
    }

    @Test public void testToolTip_no_network_name() throws Exception {
        // null
        nodeNe.getColumns().setValue(ColumnId.NETWORK_NAME, null);
        String toolTip = nodeNe.getToolTip(ToolTipType.NODE);
        assertThat(toolTip, containsString("Type"));
        assertThat(toolTip, Matchers.not(containsString("Network name:")));

        // blank
        nodeNe.getColumns().setValue(ColumnId.NETWORK_NAME, " ");
        toolTip = nodeNe.getToolTip(ToolTipType.NODE);
        assertThat(toolTip, containsString("Type"));
        assertThat(toolTip, Matchers.not(containsString("Network name:")));
    }

    @Test public void testToolTip_no_info() throws Exception {
        // null
        nodeNe.getColumns().setValue(ColumnId.INFO, null);
        String toolTip = nodeNe.getToolTip(ToolTipType.NODE);
        assertThat(toolTip, containsString("Type"));
        assertThat(toolTip, Matchers.not(containsString("Info:")));

        // blank
        nodeNe.getColumns().setValue(ColumnId.INFO, " ");
        toolTip = nodeNe.getToolTip(ToolTipType.NODE);
        assertThat(toolTip, containsString("Type"));
        assertThat(toolTip, Matchers.not(containsString("Info:")));
    }

    @Test public void testToolTip_no_commissioning() throws Exception {
        nodeNe.getValue().setActualActivationState(GuiActualActivationState.ACTIVE);

        // null
        nodeNe.setCommissioningStatus(null);
        String toolTip = nodeNe.getToolTip(ToolTipType.NODE);
        assertThat(toolTip, containsString("NE state:"));
        assertThat(toolTip, Matchers.not(containsString("Commissioning status:")));

        // not supported for tool tip
        nodeNe.setCommissioningStatus(CommissioningStatusSummary.COMMISSIONED );
        toolTip = nodeNe.getToolTip(ToolTipType.NODE);
        assertThat(toolTip, containsString("NE state:"));
        assertThat(toolTip, Matchers.not(containsString("Commissioning status:")));
    }

    @Test
    public void testGetAllowsChildren() {
        assertFalse(nodeNe.getAllowsChildren());
    }
    
    @Test
    public void testToString() {
        assertThat(nodeNe.toString(), is(nodeNe.getValue().getName()));
    }
    
    @Test
    public void testHashCode() {
        final int hash1 = new NodeNe(1, nodeChannel).hashCode();
        final int hash2 = new NodeNe(2, nodeChannel).hashCode();
        final int hash3 = new NodeNe(1, new NodeRoot(2, "Root")).hashCode();
        
        assertThat(nodeNe.hashCode(), is(hash1));
        assertThat(nodeNe.hashCode(), not(is(hash2)));
        assertThat(nodeNe.hashCode(), not(is(hash3)));
    }
    
    @Test
    public void testEquals() {
        final NodeNe node1 = new NodeNe(1, nodeChannel);
        final NodeNe node2 = new NodeNe(2, nodeChannel);
        final NodeNe node3 = new NodeNe(1, new NodeRoot(2, "Root"));

        assertTrue(nodeNe.equals(node1));
        
        assertFalse(nodeNe.equals(node2));
        assertFalse(nodeNe.equals(node3));
        assertFalse(nodeNe.equals(null));
        assertFalse(nodeNe.equals(new Object()));
    }
    
    @Test
    public void testGetParentPath() {
        final Collection<Node> parents = ImmutableList.copyOf(nodeNe.getParentPath());

        assertThat(Iterables.getFirst(parents, null), is((Node)nodeRoot));
        assertThat(Iterables.getLast(parents, null), is((Node)nodeChannel));
    }

    @Test public void testSort() throws Exception {
        final NodeChannel channel = new NodeChannel(0, new NodeRoot(0, "root"));

        final NodeNe nodeNe1 = new NodeNe(1, channel);
        nodeNe1.getValue().setName("node1");

        final NodeNe nodeNe2 = new NodeNe(2, channel);
        nodeNe2.getValue().setName("node2");

        final NodeNe nodeNe3 = new NodeNe(3, channel);
        nodeNe3.getValue().setName("node3");

        channel.addChild(nodeNe3);
        channel.addChild(nodeNe2);
        channel.addChild(nodeNe1);

        channel.sortChildrenNodes();

        assertThat(channel.getAllChildren(), contains(nodeNe1, nodeNe2, nodeNe3));

    }

    private INE createNe() {
        final INE ne = new NEItem();
        
        ne.setId(1);
        ne.setActivation(EnableSwitch.DISABLED);
        ne.setCommunicationState(CommunicationState.DISCONNECTED);
        ne.setInitState(InitState.NOT_INITIALIZED);
        ne.setIdName("NE_IdName");
        ne.setDisplayAddress("127.0.0.1");
        ne.setDisplayState("state");
        ne.setAdditionalInfo("additionalInfo");
        ne.setConnectedVia("connectedVia");
        ne.setUsedBy(BiCNetComponentTypes.none());
        ne.setNeProxyType("hiT7300");
        ne.setNeSubType("hit7300 ONN");
        ne.setRealNeName("NE_realName");
        
        return ne;
    }
}
