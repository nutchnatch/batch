package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.junit.Test;

import javax.swing.tree.TreeNode;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static java.util.Optional.of;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.lessThan;
import static org.junit.Assert.assertThat;

public class NodeTemplateTest {

    @Test public void getChildCount_shouldCountOnlyVisibleChildren() throws Exception {
        Node parent = new NodeChannel(1, null);
        Node visibleChild = child(1, parent, true);
        parent.addChild(visibleChild);
        Node invisibleChild = child(2, parent, false);
        parent.addChild(invisibleChild);

        int childCount = parent.getChildCount();

        assertThat(childCount, is(1));
    }

    private Node child(int id, Node parent, boolean visible) {
        NodeNe child = new NodeNe(id, parent);
        child.getValue().setVisible(visible);
        return child;
    }

    @Test public void getIndex_shouldGetIndexOnlyForVisibleChildren() throws Exception {
        Node parent = new NodeChannel(1, null);
        Node visibleChild = child(1, parent, true);
        parent.addChild(visibleChild);
        Node invisibleChild = child(2, parent, false);
        parent.addChild(invisibleChild);

        int indexOfVisible = parent.getIndex(visibleChild);
        int indexOfInvisible = parent.getIndex(invisibleChild);

        assertThat(indexOfVisible, is(greaterThanOrEqualTo(0)));
        assertThat(indexOfInvisible, is(lessThan(0)));
    }

    @Test public void getChildAt_shouldFindOnlyVisibleNodesByIndex() throws Exception {
        Node parent = new NodeChannel(1, null);
        Node visibleChild = child(1, parent, true);
        parent.addChild(visibleChild);
        Node invisibleChild = child(2, parent, false);
        parent.addChild(invisibleChild);

        TreeNode node = parent.getChildAt(0);
        assertThat(node, is(visibleChild));

        try {
            parent.getChildAt(1);
        } catch (Exception e) {
            assertThat(e, is(instanceOf(IllegalArgumentException.class)));
        }
    }

    @Test public void children_shouldEnumerateOnlyVisibleNodes() throws Exception {
        Node parent = new NodeChannel(1, null);
        Node visibleChild = child(1, parent, true);
        parent.addChild(visibleChild);
        Node invisibleChild = child(2, parent, false);
        parent.addChild(invisibleChild);

        Collection<Node> visibleChildren = Collections.list(parent.children());

        assertThat(visibleChildren, contains(visibleChild));
    }

    @Test public void isLeaf_shouldConsiderOnlyVisibleChildren() throws Exception {
        Node parent = new NodeChannel(1, null);
        Node visibleChild = child(1, parent, true);
        parent.addChild(visibleChild);

        Node parentWithInvisible = new NodeChannel(2, null);
        Node invisibleChild = child(2, parentWithInvisible, false);
        parentWithInvisible.addChild(invisibleChild);

        assertThat(parent.isLeaf(), is(false));
        assertThat(parentWithInvisible.isLeaf(), is(true));
    }

    @Test public void getAllChildren_shouldProvideAllChildren() throws Exception {
        Node parent = new NodeChannel(1, null);
        Node visibleChild = child(1, parent, true);
        parent.addChild(visibleChild);
        Node invisibleChild = child(2, parent, false);
        parent.addChild(invisibleChild);

        List<Node> allChildren = parent.getAllChildren();

        assertThat(allChildren, containsInAnyOrder(visibleChild, invisibleChild));
    }

    @Test public void hasNotActiveChild_shouldConsiderInvisibleChildrenAlso() throws Exception {
        Node parent = new NodeChannel(1, null);
        Node invisibleChild = child(2, parent, false);
        invisibleChild.getValue().setActualActivationState(GuiActualActivationState.INACTIVE);
        parent.addChild(invisibleChild);

        boolean hasNotActiveChild = parent.hasNotActiveChild();

        assertThat(hasNotActiveChild, is(true));
    }

    @Test public void hasChildrenActivated_shouldConsiderInvisibleChildrenAlso() throws Exception {
        Node parent = new NodeChannel(1, null);
        Node invisibleChild = child(2, parent, false);
        invisibleChild.getValue().setActualActivationState(GuiActualActivationState.ACTIVE);
        parent.addChild(invisibleChild);

        boolean hasChildrenActivated = parent.hasChildrenActivated();

        assertThat(hasChildrenActivated, is(true));
    }
    
    @Test public void findChild_shouldAlsoConsiderInvisibleChildren() throws Exception {
        Node parent = new NodeChannel(1, null);
        Node visibleChild = child(1, parent, true);
        parent.addChild(visibleChild);
        Node invisibleChild = child(2, parent, false);
        parent.addChild(invisibleChild);

        Optional<Node> visible = parent.findChild(1);
        Optional<Node> invisible = parent.findChild(2);

        assertThat(visible, is(of(visibleChild)));
        assertThat(invisible, is(of(invisibleChild)));
    }

}