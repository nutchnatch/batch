package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.builder;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.api.action.PluginAction;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateNeOnStandby;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateNeOnStandby;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionResynchronizeNeOnStandby;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.Collections.singletonList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionBuilderNeHotStandbyOperationsTest extends TestsHelper {

    private static final Collection<IManagedObject> INVALID_VALUES = ImmutableList
            .of((IManagedObject) new MediatorItem());

    private static final Collection<IManagedObject> VALID_WITH_INVALID_TYPES = ImmutableList
            .of((IManagedObject) new EMItem(), new NEItem(), new MediatorItem());

    private FullNeData fullNeData;
    private ActionBuilderNeHotStandbyOperations actionsBuilder;

    @Before public void setUp() throws Exception {
        actionsBuilder = new ActionBuilderNeHotStandbyOperations(repositoryManager, commonServices);
        fullNeData = buildFullNeData(ID_3, ID_1, "");

        FullChannelData fullChannelData = buildFullChannelData(ID_1, ID_2);

        final FullMediatorData fullMediatorData = buildFullMediatorData(ID_2);
        fullMediatorData.getInfo().setStandbyMediatorConfigured(true);

        when(channelRepository.get(ID_1)).thenReturn(Optional.of(fullChannelData));
        when(mediatorRepository.get(ID_2)).thenReturn(Optional.of(fullMediatorData));
    }

    @Test public void testValidActions() {
        final Collection<PluginAction> actions = actionsBuilder.createList()
                .actionsOf(singletonList(fullNeData.getNe()));

        assertThat(actions.size(), is(3));
        assertThat(actions.stream().map(PluginAction::getMenuID).collect(Collectors.toList()),
                containsInAnyOrder(
                        ActionActivateNeOnStandby.class.getName(),
                        ActionDeactivateNeOnStandby.class.getName(),
                        ActionResynchronizeNeOnStandby.class.getName()));
    }

    @Test public void testInvalidActions() {
        final Collection<PluginAction> actions = actionsBuilder.actionsOf(INVALID_VALUES);

        assertTrue(actions.isEmpty());
    }

    @Test public void testAllMatch() {
        assertTrue(actionsBuilder.allMatch(singletonList(fullNeData.getNe())));
    }

    @Test public void testAllMatch_no_standby_configured() throws RepositoryException {
        final FullMediatorData fullMediatorData = buildFullMediatorData(ID_2);
        fullMediatorData.getInfo().setStandbyMediatorConfigured(false);

        when(mediatorRepository.get(ID_2)).thenReturn(Optional.of(fullMediatorData));

        assertFalse(actionsBuilder.allMatch(singletonList(fullNeData.getNe())));
    }

    @Test public void testAllMatch_valid_with_invalid_types() {
        assertFalse(actionsBuilder.allMatch(VALID_WITH_INVALID_TYPES));
    }

    @Test public void testAllMatchFalse() {
        assertFalse(actionsBuilder.allMatch(INVALID_VALUES));
    }

    @Test public void testActions() {
        assertTrue(actionsBuilder.getActions().isEmpty());
    }
}