package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.Job;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobAssociateNEsWithDefaultContainer;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.MOVE_NE_SAN;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ActionRemoveNeFromContainerTest {

    private final DcnPluginHelper pluginHelper = mock(DcnPluginHelper.class);

    @Test public void shouldAllowSubsystemNEWithPermission() throws Exception {
        IManagedObject[] nes = {ne(1, 1), ne(2, 1)};
        CommonServices commonServices = services(security(nes, MOVE_NE_SAN, true));
        ActionRemoveNeFromContainer action = new ActionRemoveNeFromContainer(commonServices);

        boolean actionAllowed = action.isPluginActionAllowed(nes);

        assertThat(actionAllowed, is(true));
    }

    @Test public void shouldNotAllowNeNotUnderSystem() throws Exception {
        IManagedObject[] nes = {ne(1, 0)}; //not under a system
        CommonServices commonServices = services(security(nes, MOVE_NE_SAN, true));
        ActionRemoveNeFromContainer action = new ActionRemoveNeFromContainer(commonServices);

        boolean actionAllowed = action.isPluginActionAllowed(nes);

        assertThat(actionAllowed, is(false));
    }

    @Test public void shouldNotAllowNeOutOfSecurityDomain() throws Exception {
        IManagedObject[] nes = {ne(1, 1)};
        CommonServices commonServices = services(security(nes, MOVE_NE_SAN, false)); //no permission
        ActionRemoveNeFromContainer action = new ActionRemoveNeFromContainer(commonServices);

        boolean actionAllowed = action.isPluginActionAllowed(nes);

        assertThat(actionAllowed, is(false));
    }

    @Test public void shouldFireAJobOnActionPerformed() throws Exception {
        IManagedObject[] nes = {ne(1, 1)};
        CommonServices commonServices = services(security(nes, MOVE_NE_SAN, true));
        ActionRemoveNeFromContainer action = new ActionRemoveNeFromContainer(commonServices);

        action.eventPluginActionPerformed(nes);

        ArgumentCaptor<Job<?>> job = new ArgumentCaptor<>();
        verify(pluginHelper).queueJob(job.capture());
        assertThat(job.getValue(), instanceOf(JobAssociateNEsWithDefaultContainer.class));
    }

    private SecureActionValidation security(IManagedObject[] nes, SecureAction permission, boolean isPermitted) {
        SecureActionValidation actionValidation = mock(SecureActionValidation.class);
        when(actionValidation.checkPermission(permission, nes)).thenReturn(isPermitted);
        return actionValidation;
    }

    private SecureActionValidation security(IManagedObject[] nes, SecureAction permission, Throwable ex) {
        SecureActionValidation actionValidation = mock(SecureActionValidation.class);
        when(actionValidation.checkPermission(permission, nes)).thenThrow(ex);
        return actionValidation;
    }

    private CommonServices services(SecureActionValidation actionValidation) {
        CommonServices commonServices = mock(CommonServices.class);
        when(commonServices.getSecureActionValidation()).thenReturn(actionValidation);
        when(commonServices.getDcnPluginHelper()).thenReturn(pluginHelper);
        return commonServices;
    }

    private IManagedObject ne(int id, int system) {
        INE ne = new NEItem();
        ne.setId(id);
        ne.setAssociatedSystemContainerId(system);
        return ne;
    }
}