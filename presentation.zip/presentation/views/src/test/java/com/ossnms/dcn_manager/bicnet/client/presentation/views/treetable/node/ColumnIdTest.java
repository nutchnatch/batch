package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ColumnIdTest {

    @Test
    public void testValidPosition() {
        assertThat(ColumnId.valueOf(0), is(ColumnId.TREE_MODEL));
        assertThat(ColumnId.valueOf(1), is(ColumnId.STATE));
        assertThat(ColumnId.valueOf(2), is(ColumnId.NETWORK_NAME));
        assertThat(ColumnId.valueOf(3), is(ColumnId.TYPE));
        assertThat(ColumnId.valueOf(4), is(ColumnId.INFO));
        assertThat(ColumnId.valueOf(5), is(ColumnId.ADDRESS));
        assertThat(ColumnId.valueOf(6), is(ColumnId.CONNECT_VIA));
    }
    
    @Test(expected=UnsupportedOperationException.class)
    public void testInvalidPosition() {
        ColumnId.valueOf(100);
    }
}
