package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.coriant.widgets.icons.DoubleIcon;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.MediatorGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class NodeMediatorMutationApplierTest extends TestsHelper {

    @Mock private MediatorGraphicalRepresentationBuilder graphicalRepresentationBuilder;

    private NodeMediatorMutationApplier mediatorMutationApplier;
    private NodeMediator nodeMediator;
    private FullMediatorData fullMediatorData;

    public NodeMediatorMutationApplierTest() {
    }

    @Before public void setUp() throws Exception {
        this.mediatorMutationApplier = new NodeMediatorMutationApplier(repositoryManager, commonServices,
                graphicalRepresentationBuilder);

        nodeMediator = new NodeMediator(ID_1, buildNodeMediatorRoot());
        fullMediatorData = buildFullMediatorData(ID_1);
        when(graphicalRepresentationBuilder.getIconManager()).thenReturn(new IconManager());
        when(commonServices.getSecureActionValidation()).thenReturn(secureActionValidation);
        when(secureActionValidation.checkPermission(any(SecureAction.class), any(IMediator.class))).thenReturn(true);
        when(secureActionValidation.checkPermission(any(SecureAction.class))).thenReturn(true);
    }

    @Test public void testApplyMutation() throws Exception {
        when(graphicalRepresentationBuilder.build(any(FullMediatorData.class))).thenReturn(any(DoubleIcon.class));

        mediatorMutationApplier.applyMutation(fullMediatorData, nodeMediator);

        IMediator m = fullMediatorData.getMediator();

        assertThat(nodeMediator.getColumns().valueOf(ColumnId.ADDRESS).get().getValue(), is(m.getDisplayAddress()));
        assertThat(nodeMediator.getColumns().valueOf(ColumnId.INFO).get().getValue(), is(m.getAdditionalInfo()));
        assertThat(nodeMediator.getColumns().valueOf(ColumnId.STATE).get().getValue(), is(m.getDisplayState()));
        assertThat(nodeMediator.getColumns().valueOf(ColumnId.TYPE).get().getValue(), is(m.getMediatorType().guiLabel()));

        assertThat(nodeMediator.getColumns().valueOf(ColumnId.STANDBY_STATE).get().getValue(),
                is(fullMediatorData.getInfo().getStandbyDisplayState().orElse(EMPTY)));

        assertThat(nodeMediator.getColumns().valueOf(ColumnId.USER_TEXT).get().getValue(),
                is(fullMediatorData.getInfo().getUserText().orElse(EMPTY)));

    }

    @Test public void testLoadChildrenNodes() throws Exception {

    }

    @Test public void testApplyToogleButtonChanges_active() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.ENABLED);
        fullMediatorData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        mediatorMutationApplier.applyToogleButtonChanges(fullMediatorData, nodeMediator);

        assertThat(nodeMediator.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeMediator.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeMediator.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_active_with_children_active() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.ENABLED);
        fullMediatorData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        NodeChannel nodeChannel = new NodeChannel(ID_1, nodeMediator);
        nodeChannel.getValue().setToogleButtonChecked(true);
        nodeChannel.getValue().setActualActivationState(GuiActualActivationState.ACTIVE);
        nodeMediator.addChild(nodeChannel);

        mediatorMutationApplier.applyToogleButtonChanges(fullMediatorData, nodeMediator);

        assertThat(nodeMediator.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeMediator.getValue().isToogleButtonEnable(), is(false));

        assertThat(nodeMediator.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_active_with_children_inactive() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.ENABLED);
        fullMediatorData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        NodeChannel nodeChannel = new NodeChannel(ID_1, nodeMediator);
        nodeChannel.getValue().setToogleButtonChecked(false);
        nodeMediator.addChild(nodeChannel);

        mediatorMutationApplier.applyToogleButtonChanges(fullMediatorData, nodeMediator);

        assertThat(nodeMediator.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeMediator.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeMediator.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_inactive_disabled() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.DISABLED);
        fullMediatorData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        mediatorMutationApplier.applyToogleButtonChanges(fullMediatorData, nodeMediator);

        assertThat(nodeMediator.getValue().isToogleButtonChecked(), is(false));
        assertThat(nodeMediator.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeMediator.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_inactive_enabled() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.DISABLED);
        fullMediatorData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        mediatorMutationApplier.applyToogleButtonChanges(fullMediatorData, nodeMediator);

        assertThat(nodeMediator.getValue().isToogleButtonChecked(), is(false));
        assertThat(nodeMediator.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeMediator.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_deactivating() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.DISABLED);
        fullMediatorData.getInfo().setGuiActualActivationState(GuiActualActivationState.DEACTIVATING);

        mediatorMutationApplier.applyToogleButtonChanges(fullMediatorData, nodeMediator);

        assertThat(nodeMediator.getValue().isToogleButtonChecked(), is(false));
        assertThat(nodeMediator.getValue().isToogleButtonEnable(), is(false));

        assertThat(nodeMediator.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_activating() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.ENABLED);
        fullMediatorData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVATING);

        mediatorMutationApplier.applyToogleButtonChanges(fullMediatorData, nodeMediator);

        assertThat(nodeMediator.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeMediator.getValue().isToogleButtonEnable(), is(false));

        assertThat(nodeMediator.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_failed() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.ENABLED);
        fullMediatorData.getInfo().setGuiActualActivationState(GuiActualActivationState.FAILED);

        mediatorMutationApplier.applyToogleButtonChanges(fullMediatorData, nodeMediator);

        assertThat(nodeMediator.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeMediator.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeMediator.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_noPermission() throws Exception {
        when(secureActionValidation.checkPermission(any(SecureAction.class), any())).thenReturn(false);

        fullMediatorData.getMediator().setActivation(EnableSwitch.ENABLED);
        fullMediatorData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        mediatorMutationApplier.applyToogleButtonChanges(fullMediatorData, nodeMediator);

        assertThat(nodeMediator.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeMediator.getValue().isToogleButtonEnable(), is(false));

        assertThat(nodeMediator.getValue().isToogleButtonVisible(), is(true));
    }
}
