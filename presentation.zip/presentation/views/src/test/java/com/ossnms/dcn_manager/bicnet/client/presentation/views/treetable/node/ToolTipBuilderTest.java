package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.coriant.widgets.togglebuttontree.ToggleButtonTree;
import com.coriant.widgets.togglebuttontree.ToggleButtonTree.Handler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.DcnTreeTable;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ToolTipBuilder;
import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.swing.tree.TreePath;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.Optional;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ToolTipBuilderTest {

    private static final String MSG_NODE = "node";
    private static final String MSG_CHECKBOX = "checkbox";
    private static final int DEFAULT_POINT = 1;
    
    private MouseEvent event;
    private DcnTreeTable table;
    private Point point;
    private Node node;
    private ToggleButtonTree<Node> buttonTree;
    private TreePath treePath;
    private Handler<Node> treeHandler;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        event = mock(MouseEvent.class);
        table = mock(DcnTreeTable.class);
        point = mock(Point.class);
        node = mock(Node.class);
        buttonTree = mock(ToggleButtonTree.class);
        treePath = mock(TreePath.class);
        treeHandler = mock(Handler.class);

        when(event.getPoint()).thenReturn(point);
        when(table.rowAtPoint(point)).thenReturn(DEFAULT_POINT);
        when(table.columnAtPoint(point)).thenReturn(DEFAULT_POINT);
        when(table.getTree()).thenReturn(buttonTree);               
        when(event.getX()).thenReturn(DEFAULT_POINT);
        when(event.getY()).thenReturn(DEFAULT_POINT);
        
        when(node.getToolTip(ToolTipType.CHECKBOX)).thenReturn(MSG_CHECKBOX);
        when(node.getToolTip(ToolTipType.NODE)).thenReturn(MSG_NODE);
    }

    @Test
    public void testBuildTooltip_forCheckBox() {
        when(event.getSource()).thenReturn(table);
        when(table.getValueAt(DEFAULT_POINT, DEFAULT_POINT)).thenReturn(node);
        when(buttonTree.getPathForLocation(DEFAULT_POINT, DEFAULT_POINT)).thenReturn(treePath);
        when(buttonTree.getHandler()).thenReturn(treeHandler);
        when(treeHandler.isClickInToggleButton(event, treePath)).thenReturn(true);
        
        final ToolTipBuilder builder = new ToolTipBuilder();
        final Optional<String> toolTip = builder.build(event);

        assertTrue(toolTip.isPresent());
        Assert.assertThat(toolTip.get(), CoreMatchers.is(MSG_CHECKBOX));
    }
    
    @Test
    public void testBuildTooltip_forNode() {
        when(event.getSource()).thenReturn(table);
        when(table.getValueAt(DEFAULT_POINT, DEFAULT_POINT)).thenReturn(node);
        when(buttonTree.getPathForLocation(DEFAULT_POINT, DEFAULT_POINT)).thenReturn(treePath);
        when(buttonTree.getHandler()).thenReturn(treeHandler);
        when(treeHandler.isClickInToggleButton(event, treePath)).thenReturn(false);
        
        final ToolTipBuilder builder = new ToolTipBuilder();
        final Optional<String> toolTip = builder.build(event);

        assertTrue(toolTip.isPresent());
        Assert.assertThat(toolTip.get(), CoreMatchers.is(MSG_NODE));
    }
    
    @Test
    public void testBuildTooltip_treePathNotPresent() {
        when(event.getSource()).thenReturn(table);
        when(table.getValueAt(DEFAULT_POINT, DEFAULT_POINT)).thenReturn(node);
        when(buttonTree.getPathForLocation(DEFAULT_POINT, DEFAULT_POINT)).thenReturn(null);
        when(buttonTree.getHandler()).thenReturn(treeHandler);
        
        final ToolTipBuilder builder = new ToolTipBuilder();
        final Optional<String> toolTip = builder.build(event);

        assertTrue(toolTip.isPresent());
        Assert.assertThat(toolTip.get(), CoreMatchers.is(MSG_NODE));
    }
    
    @Test
    public void testBuild_notsupported_source() {
        when(event.getSource()).thenReturn(new Object());
        
        final ToolTipBuilder builder = new ToolTipBuilder();
        final Optional<String> toolTip = builder.build(event);

        assertFalse(toolTip.isPresent());
    }
    
    @Test
    public void testBuild_notsupported_cell() {
        when(table.getValueAt(DEFAULT_POINT, DEFAULT_POINT)).thenReturn(new Object());
        
        final ToolTipBuilder builder = new ToolTipBuilder();
        final Optional<String> toolTip = builder.build(event);

        assertFalse(toolTip.isPresent());
    }
}
