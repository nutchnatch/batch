package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediatorRoot;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ChannelTreeNodeEventListenerTest extends TestsHelper {
    @Mock private ModelUpdater modelUpdater;
    @Mock private GraphicalRepresentationBuilder<FullChannelData> graphicalRepresentationBuilder;
    @Mock private NodeMediatorRoot mediatorRoot;

    private ChannelTreeNodeEventListener channelTreeNodeEventListener;

    @Before public void setUp() throws Exception {
        channelTreeNodeEventListener = new ChannelTreeNodeEventListener(modelUpdater, commonServices,
                repositoryManager, graphicalRepresentationBuilder);

        mediatorRoot = new NodeMediatorRoot("Root");

        when(modelUpdater.getNodeRoot()).thenReturn(mediatorRoot);
        when(graphicalRepresentationBuilder.getIconManager()).thenReturn(new IconManager());
    }

    @Test public void testRemove() throws Exception {
        NodeMediator nodeMediator = buildNodeMediator(mediatorRoot, ID_1);
        mediatorRoot.addChild(nodeMediator);

        FullChannelData fullChannelData = buildFullChannelData(ID_1, ID_1);
        NodeChannel nodeChannel = buildNodeChannel(nodeMediator, ID_1);

        nodeMediator.addChild(nodeChannel);

        channelTreeNodeEventListener.remove(fullChannelData);

        assertTrue(nodeMediator.getAllChildren().isEmpty());
        verify(modelUpdater, atLeastOnce()).removeNode(nodeChannel);
    }

    @Test public void testAdd() throws Exception {
        NodeMediator nodeMediator = buildNodeMediator(mediatorRoot, ID_1);
        mediatorRoot.addChild(nodeMediator);

        FullChannelData fullChannelData = buildFullChannelData(ID_1, ID_1);

        channelTreeNodeEventListener.add(fullChannelData);

        assertThat(nodeMediator.getAllChildren().size(), is(1));
        verify(modelUpdater, atLeastOnce()).insertNode(any(NodeChannel.class));
    }

    @Test public void testUpdate() throws Exception {
        NodeMediator nodeMediator = buildNodeMediator(mediatorRoot, ID_1);
        mediatorRoot.addChild(nodeMediator);

        NodeChannel nodeChannel = buildNodeChannel(nodeMediator, ID_1);
        nodeMediator.addChild(nodeChannel);

        FullChannelData fullChannelData = buildFullChannelData(ID_1, ID_1);
        fullChannelData.getChannel().setIdName("new_name");
        channelTreeNodeEventListener.update(fullChannelData);

        assertThat(mediatorRoot.getAllChildren().size(), is(1));
        assertThat(nodeChannel.getValue().getName(), is("new_name"));
        verify(modelUpdater, atLeastOnce()).applyStructureChanged(any(NodeChannel.class));
    }
}