package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.containerview;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.junit.Test;

import java.util.List;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.MOVE_SYSTEM_SAN;
import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class SystemAcceptorTest {
    @Test public void shouldAcceptOnHappyPath() throws Exception {
        GenericContainerItem destination = new GenericContainerItem();
        SystemContainerItem system = new SystemContainerItem();
        List<FullNeData> nes = asList(new FullNeData(new NEItem(), null, null));
        boolean hasPermission = true;
        boolean visible = true;
        SystemAcceptor systemAcceptor = new SystemAcceptor(
                repo(system, nes),
                services(nes, hasPermission, visible));

        boolean canAccept = systemAcceptor.canAccept(asList(system), destination);

        assertThat(canAccept, is(true));
    }

    @Test public void shouldRejectWithInvisibleNes() throws Exception {
        GenericContainerItem destination = new GenericContainerItem();
        SystemContainerItem system = new SystemContainerItem();
        List<FullNeData> nes = asList(new FullNeData(new NEItem(), null, null));
        boolean hasPermission = true;
        boolean visible = false; //invisible nes
        SystemAcceptor systemAcceptor = new SystemAcceptor(
                repo(system, nes),
                services(nes, hasPermission, visible));

        boolean canAccept = systemAcceptor.canAccept(asList(system), destination);

        assertThat(canAccept, is(false));
    }

    @Test public void shouldRejectNoSystemPermission() throws Exception {
        GenericContainerItem destination = new GenericContainerItem();
        SystemContainerItem system = new SystemContainerItem();
        List<FullNeData> nes = asList(new FullNeData(new NEItem(), null, null));
        boolean hasPermission = false; //no permission
        boolean visible = true;
        SystemAcceptor systemAcceptor = new SystemAcceptor(
                repo(system, nes),
                services(nes, hasPermission, visible));

        boolean canAccept = systemAcceptor.canAccept(asList(system), destination);

        assertThat(canAccept, is(false));
    }

    @Test public void shouldRejectDropOnNotContainer() throws Exception {
        SystemContainerItem destination = new SystemContainerItem(); //not container
        SystemContainerItem system = new SystemContainerItem();
        List<FullNeData> nes = asList(new FullNeData(new NEItem(), null, null));
        boolean hasPermission = true;
        boolean visible = true;
        SystemAcceptor systemAcceptor = new SystemAcceptor(
                repo(system, nes),
                services(nes, hasPermission, visible));

        boolean canAccept = systemAcceptor.canAccept(asList(system), destination);

        assertThat(canAccept, is(false));
    }

    private CommonServices services(List<FullNeData> nes, boolean hasPermission, boolean visible) {
        SecureActionValidation validation = mock(SecureActionValidation.class);
        when(validation.checkPermission(MOVE_SYSTEM_SAN)).thenReturn(hasPermission);
        nes.forEach(ne -> when(validation.checkVisibility(ne.getNe())).thenReturn(visible));

        CommonServices commonServices = mock(CommonServices.class);
        when(commonServices.getSecureActionValidation()).thenReturn(validation);
        return commonServices;
    }

    private RepositoryManager repo(SystemContainerItem system, List<FullNeData> nes) throws RepositoryException {
        NeSearchable searchable = mock(NeSearchable.class);
        when(searchable.findBySystemContainerId(system.getId())).thenReturn(nes);

        NeRepository neRepo = mock(NeRepository.class);
        when(neRepo.queries()).thenReturn(searchable);

        RepositoryManager repo = mock(RepositoryManager.class);
        when(repo.getNeRepository()).thenReturn(neRepo);
        return repo;
    }
}