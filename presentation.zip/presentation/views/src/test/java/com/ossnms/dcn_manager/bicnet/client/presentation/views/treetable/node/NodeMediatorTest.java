package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import javax.swing.ImageIcon;
import javax.swing.tree.TreeNode;
import java.util.Enumeration;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NAME;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NUMBER_CHANNELS;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NUMBER_NES;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_STATE;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_TYPE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
public class NodeMediatorTest {

    private static final String NODE1_NAME = "NODE1";
    private static final String NODE2_NAME = "NODE2";
    private static final String NODE3_NAME = "NODE3";
    private final NodeRoot nodeRoot;
    private IconManager iconManager;
    
    private final FullMediatorData mediator;
    private NodeMediator nodeMediator;

    public NodeMediatorTest() {
        nodeRoot = new NodeRoot(1, "Root");
        mediator = createFullMediator();
    }

    @Before
    public void setup() {
        final Optional<ImageIcon> imaOptional = Optional.empty();
        iconManager = mock(IconManager.class);
        when(iconManager.findNetworkIcon(Matchers.any(IMediator.class), Matchers.anyInt())).thenReturn(imaOptional);
        when(iconManager.findNetworkIcon(Matchers.any(IEM.class), Matchers.anyInt())).thenReturn(imaOptional);
        
        nodeMediator = new NodeMediator(mediator.getMediator().getId(), nodeRoot);
        nodeMediator.getValue().setToogleButtonChecked(true);
    }

    @Test public void testCheckBoxToolTip() throws Exception {
        nodeMediator.getValue().setToogleButtonEnable(false);
        nodeMediator.getValue().setToogleButtonChecked(true);

        final String toolTip = nodeMediator.getToolTip(ToolTipType.CHECKBOX);

        assertThat(toolTip, is(TreeTableLabels.MEDIATOR_CHECKBOX_TOOLTIP.toString()));
    }

    @Test public void testNodeToolTip() throws Exception {
        nodeMediator.getValue().setToogleButtonEnable(true);
        nodeMediator.getValue().setToogleButtonChecked(false);

        nodeMediator.getValue().setName("mediator_name");
        nodeMediator.getColumns().setValue(ColumnId.TYPE, "mediator_type");
        nodeMediator.getColumns().setValue(ColumnId.STATE, "mediator_state");

        final NodeChannel nodeChannel1 = new NodeChannel(1, nodeMediator);
        final NodeNe nodeNe1 = new NodeNe(1, nodeChannel1);
        nodeChannel1.addChild(nodeNe1);

        final NodeChannel nodeChannel2 = new NodeChannel(2, nodeMediator);
        final NodeNe nodeNe2 = new NodeNe(2, nodeChannel1);
        final NodeNe nodeNe3 = new NodeNe(3, nodeChannel1);
        nodeChannel1.addChild(nodeNe2);
        nodeChannel1.addChild(nodeNe3);

        final NodeChannel nodeChannel3 = new NodeChannel(3, nodeMediator);
        final NodeNe nodeNe4 = new NodeNe(4, nodeChannel1);
        nodeChannel1.addChild(nodeNe4);

        nodeMediator.addChild(nodeChannel1);
        nodeMediator.addChild(nodeChannel2);
        nodeMediator.addChild(nodeChannel3);

        final String toolTip = nodeMediator.getToolTip(ToolTipType.NODE);

        assertThat(toolTip, containsString("<b>" + nodeMediator.delimiter(COLUMN_NAME) + "</b>mediator_name"));
        assertThat(toolTip, containsString("<b>" + nodeMediator.delimiter(COLUMN_TYPE) + "</b>mediator_type"));
        assertThat(toolTip, containsString("<b>" + nodeMediator.delimiter(COLUMN_STATE) + "</b>mediator_state"));
        assertThat(toolTip, containsString("<b>" + nodeMediator.delimiter(COLUMN_NUMBER_CHANNELS) + "</b>3"));
        assertThat(toolTip, containsString("<b>" + nodeMediator.delimiter(COLUMN_NUMBER_NES) + "</b>4"));
    }

    @Test
    public void testEnableNodeParentToggleButton() {
        assertEquals(nodeRoot.getValue().isToogleButtonChecked(), false);
        
        nodeMediator.tryUpdateNodeParentToggleButton(true);
        
        assertEquals(nodeRoot.getValue().isToogleButtonChecked(), false);
    }

    @Test
    public void testFindChildPresent() {
        Node child1 = new NodeChannel(1, nodeMediator);
        child1.getValue().setName(NODE1_NAME);
        nodeMediator.addChild(new NodeChannel(1, nodeMediator));

        final Node node = nodeMediator.findChild(1).get();
        
        assertThat(node.getId(), is(1));
    }
    
    @Test
    public void testFindChildNotPresent() {
        final Optional<Node> node = nodeMediator.findChild(1);
        
        assertFalse(node.isPresent());
    }
    
    @Test
    public void testRemoveExistChild() {
        final Node child = new NodeChannel(1, nodeMediator);
        
        nodeMediator.addChild(child);
        
        assertTrue(nodeMediator.removeChild(child));
    }
    
    @Test
    public void testRemoveNotExistChild() {
        final Node child1 = new NodeChannel(1, nodeMediator);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeChannel(2, nodeMediator);
        child2.getValue().setName(NODE2_NAME);
        
        nodeMediator.addChild(child1);
        
        assertFalse(nodeMediator.removeChild(child2));
    }
    
    @Test
    public void testGetChildIndex() {
        final Node child1 = new NodeChannel(1, nodeMediator);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeChannel(2, nodeMediator);
        child2.getValue().setName(NODE2_NAME);
        final Node child3 = new NodeChannel(3, nodeMediator);
        child3.getValue().setName(NODE3_NAME);
        
        nodeMediator.addChild(child1);
        nodeMediator.addChild(child2);
        
        assertThat(nodeMediator.getIndex(child1), is(0));
        assertThat(nodeMediator.getIndex(child2), is(1));
        assertThat(nodeMediator.getIndex(child3), is(-1));
    }

    @Test public void testHasChildrenActivated_all_children_inactive() throws Exception {
        NodeChannel channel1 = new NodeChannel(1, nodeMediator);
        channel1.getValue().setName(NODE1_NAME);
        NodeChannel channel2 = new NodeChannel(2, nodeMediator);
        channel2.getValue().setName(NODE2_NAME);

        nodeMediator.addChild(channel1);
        nodeMediator.addChild(channel2);

        channel1.tryUpdateNodeParentToggleButton(true);
        channel2.tryUpdateNodeParentToggleButton(true);

        assertFalse(nodeMediator.hasChildrenActivated());
        assertTrue(nodeMediator.getValue().isToogleButtonEnable());
    }

    @Test public void testHasChildrenActivated_no_child() throws Exception {
        assertFalse(nodeMediator.hasChildrenActivated());
        assertTrue(nodeMediator.getValue().isToogleButtonEnable());
    }

    @Test public void testCheckBox_all_failed() throws Exception {
        NodeChannel channel1 = new NodeChannel(1, nodeMediator);
        channel1.getValue().setName(NODE1_NAME);
        channel1.getValue().setToogleButtonChecked(true);
        channel1.getValue().setActualActivationState(GuiActualActivationState.FAILED);

        NodeChannel channel2 = new NodeChannel(2, nodeMediator);
        channel2.getValue().setName(NODE2_NAME);
        channel2.getValue().setToogleButtonChecked(true);
        channel2.getValue().setActualActivationState(GuiActualActivationState.FAILED);

        nodeMediator.addChild(channel1);
        nodeMediator.addChild(channel2);
        nodeMediator.getValue().setActualActivationState(GuiActualActivationState.FAILED);
        nodeMediator.tryUpdateNodeParentToggleButton(true);

        channel1.tryUpdateNodeParentToggleButton(true);
        channel2.tryUpdateNodeParentToggleButton(true);

        assertTrue(nodeMediator.getValue().isToogleButtonEnable());
    }

    @Test public void testHasChildrenActivated_all_children_active() throws Exception {
        NodeChannel channel1 = new NodeChannel(1, nodeMediator);
        channel1.getValue().setName(NODE1_NAME);
        channel1.getValue().setToogleButtonChecked(true);
        channel1.getValue().setActualActivationState(GuiActualActivationState.ACTIVE);

        NodeChannel channel2 = new NodeChannel(2, nodeMediator);
        channel2.getValue().setName(NODE2_NAME);
        channel2.getValue().setToogleButtonChecked(true);
        channel2.getValue().setActualActivationState(GuiActualActivationState.ACTIVE);

        nodeMediator.addChild(channel1);
        nodeMediator.addChild(channel2);

        channel1.tryUpdateNodeParentToggleButton(true);
        channel2.tryUpdateNodeParentToggleButton(true);

        assertTrue(nodeMediator.hasChildrenActivated());
        assertFalse(nodeMediator.getValue().isToogleButtonEnable());
    }

    @Test public void testHasChildrenActivated_child_active() throws Exception {
        NodeChannel channel1 = new NodeChannel(1, nodeMediator);
        channel1.getValue().setName(NODE1_NAME);
        channel1.getValue().setToogleButtonChecked(true);
        channel1.getValue().setActualActivationState(GuiActualActivationState.ACTIVE);

        nodeMediator.addChild(channel1);

        channel1.tryUpdateNodeParentToggleButton(true);

        assertTrue(nodeMediator.hasChildrenActivated());
        assertFalse(nodeMediator.getValue().isToogleButtonEnable());
    }

    @Test public void testHasChildrenActivated_child_deactivating() throws Exception {
        NodeChannel channel1 = new NodeChannel(1, nodeMediator);
        channel1.getValue().setName(NODE1_NAME);

        channel1.getValue().setToogleButtonChecked(false);
        channel1.getValue().setActualActivationState(GuiActualActivationState.DEACTIVATING);

        nodeMediator.addChild(channel1);

        channel1.tryUpdateNodeParentToggleButton(true);

        assertTrue(nodeMediator.hasChildrenActivated());
        assertFalse(nodeMediator.getValue().isToogleButtonEnable());
    }
    
    @Test public void testMediatorActivating_addNewChannel() throws Exception {
        nodeMediator.getValue().setActualActivationState(GuiActualActivationState.ACTIVATING);
        nodeMediator.getValue().setToogleButtonEnable(false);
        
        NodeChannel channel1 = new NodeChannel(1, nodeMediator);
        channel1.getValue().setName(NODE1_NAME);

        channel1.getValue().setToogleButtonChecked(false);
        channel1.getValue().setActualActivationState(GuiActualActivationState.INACTIVE);

        nodeMediator.addChild(channel1);

        channel1.tryUpdateNodeParentToggleButton(true);

        assertFalse(nodeMediator.hasChildrenActivated());
        assertFalse(nodeMediator.getValue().isToogleButtonEnable());
    }
    
    @Test public void testMediatorDeactivating_addNewChannel() throws Exception {
        nodeMediator.getValue().setActualActivationState(GuiActualActivationState.DEACTIVATING);
        nodeMediator.getValue().setToogleButtonEnable(false);
        
        NodeChannel channel1 = new NodeChannel(1, nodeMediator);
        channel1.getValue().setName(NODE1_NAME);

        channel1.getValue().setToogleButtonChecked(false);
        channel1.getValue().setActualActivationState(GuiActualActivationState.INACTIVE);

        nodeMediator.addChild(channel1);

        channel1.tryUpdateNodeParentToggleButton(true);

        assertFalse(nodeMediator.hasChildrenActivated());
        assertFalse(nodeMediator.getValue().isToogleButtonEnable());
    }
    
    @Test
    public void testGetAllowsChildren() {
        assertTrue(nodeMediator.getAllowsChildren());
    }
    
    @Test
    public void testIsLeaf() {
        assertTrue(nodeMediator.isLeaf());
    }
    
    @Test
    public void testIsLeafFalse() {
        final Node child1 = new NodeChannel(1, nodeMediator);
        nodeMediator.addChild(child1);
        
        assertFalse(nodeMediator.isLeaf());
    }
    
    @Test
    public void testGetColumnByPosition() {
        assertThat(nodeMediator, is(nodeMediator.getColumnByPosition(0)));
        assertThat(nodeMediator, is(nodeMediator.getColumnByPosition(0)));        
    }
    
    @Test(expected=UnsupportedOperationException.class)
    public void testGetColumnByWrongPosition() {
        nodeMediator.getColumnByPosition(100);        
    }
        
    @Test
    public void testGets() {
        Assert.assertNotNull(nodeMediator.getColumns());
        Assert.assertNotNull(nodeMediator.getValue());
                
        assertThat(nodeMediator.getId(), is(1)); 
    }
    
    @Test
    public void testChildren() {
        final Node child1 = new NodeChannel(1, nodeMediator);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeChannel(2, nodeMediator);
        child2.getValue().setName(NODE2_NAME);
        
        nodeMediator.addChild(child1);
        nodeMediator.addChild(child2);
        
        final Enumeration<TreeNode> nodes = nodeMediator.children();

        int totalNodes = 0;
        
        while(nodes.hasMoreElements()) {
            nodes.nextElement();
            totalNodes++;
        }
        
        assertThat(nodeMediator.getChildCount(), is(totalNodes));
    }
    
    @Test
    public void testToString() {
        assertThat(nodeMediator.toString(), is(nodeMediator.getValue().getName()));
    }
    
    @Test
    public void testHashCode() {
        
        final int hash1 = new NodeMediator(1, nodeRoot).hashCode();
        final int hash2 = new NodeMediator(2, nodeRoot).hashCode();
        final int hash3 = new NodeMediator(1, new NodeRoot(2, "Root")).hashCode();
        
        assertThat(nodeMediator.hashCode(), is(hash1));
        assertThat(nodeMediator.hashCode(), not(is(hash2)));
        assertThat(nodeMediator.hashCode(), not(is(hash3)));
    }
    
    @Test
    public void testEquals() {
        final NodeMediator mediator1 = new NodeMediator(1, nodeRoot);
        final NodeMediator mediator2 = new NodeMediator(2, nodeRoot);
        final NodeMediator mediator3 = new NodeMediator(1, new NodeRoot(2, "Root"));
        
        assertTrue(nodeMediator.equals(mediator1));
        
        assertFalse(nodeMediator.equals(mediator2));
        assertFalse(nodeMediator.equals(mediator3));
        assertFalse(nodeMediator.equals(null));
        assertFalse(nodeMediator.equals(nodeRoot));
    }
    
    private FullMediatorData createFullMediator() {
        final IMediator mediatorBcb = new MediatorItem();
        mediatorBcb.setId(1);
        mediatorBcb.setActivation(EnableSwitch.DISABLED);
        mediatorBcb.setIdName("Mediator_IdName");
        mediatorBcb.setDisplayAddress("127.0.0.1");
        mediatorBcb.setDisplayState("state");
        mediatorBcb.setAdditionalInfo("additionalInfo");
        mediatorBcb.setMediatorType(MediatorType.GM);

        FullMediatorData fullMediatorData = new FullMediatorData(mediatorBcb, new MediatorInfo(mediatorBcb.getId()));
        fullMediatorData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        return fullMediatorData;
    }
}
