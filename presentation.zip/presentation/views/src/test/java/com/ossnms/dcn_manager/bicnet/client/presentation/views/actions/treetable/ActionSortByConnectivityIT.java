package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.JfxText;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static com.google.code.tempusfugit.temporal.Duration.seconds;
import static com.google.code.tempusfugit.temporal.Timeout.timeout;
import static com.google.code.tempusfugit.temporal.WaitFor.waitUntil;
import static java.util.Comparator.comparing;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class ActionSortByConnectivityIT {
    private ActionSortByConnectivity actionSortByConnectivity;

    private JfxAction action;
    private TreeTableViewModel model;

    @Before public void setUp() throws Exception {
        model = mock(TreeTableViewModel.class);
        action = mock(JfxAction.class);

        NodeDomainRoot root = new NodeDomainRoot("root");

        NodeDomain nodeDomain = new NodeDomain(1, root, comparing(Object::toString, String::compareToIgnoreCase));
        nodeDomain.getValue().setName("domain_name");
        nodeDomain.setSelectedGneId(Optional.of(100));

        NodeNe gne1 = new NodeNe(1, nodeDomain);
        gne1.getValue().setName("gne1_id_name");

        NodeNe gne2 = new NodeNe(2, nodeDomain);
        gne2.getValue().setName("gne2_id_name");

        nodeDomain.addChild(gne1);
        nodeDomain.addChild(gne2);

        Pair<Integer, JfxText> selectedGne = ImmutablePair.of(1, new JfxText(gne1.getValue().getName()));

        actionSortByConnectivity = new ActionSortByConnectivity(nodeDomain, selectedGne, model);
    }

    @Test public void testFulfilled() throws Exception {
        assertTrue(actionSortByConnectivity.fulfilled(action));
    }

    @Test public void testActionPerformed() throws Exception {
        actionSortByConnectivity.actionPerformed(action);

        waitUntil(timeout(seconds(5)));

        verify(model, times(2)).eventNodeRemoved(any(Node.class));
        verify(model, times(2)).eventNodeInserted(any(Node.class));
    }
}
