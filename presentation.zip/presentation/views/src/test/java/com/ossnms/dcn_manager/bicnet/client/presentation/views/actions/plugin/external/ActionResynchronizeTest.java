package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalContainerItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeActivationState;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainer;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobResynchronizeNe;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_RESYNCHRONIZE_DATA_SAN;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ActionResynchronizeTest extends TestsHelper {

    private ActionResynchronize actionResynchronize;

    private FullNeData fullNeData;
    private FullNeData wrong;

    @Before public void setUp() throws Exception {
        fullNeData = buildFullNeData(ID_1, ID_1, "");
        fullNeData.getNe().setActualActivationState(NeActivationState.ACTIVE);
        fullNeData.getNe().setAssociatedSystemContainerId(ID_3);
        wrong = buildFullNeData(ID_2, ID_2, "");
        wrong.getNe().setActualActivationState(NeActivationState.ACTIVATING);

        when(neRepository.get(ImmutableList.of(ID_1))).thenReturn(ImmutableList.of(fullNeData));
        when(neRepository.get(ImmutableList.of(ID_1, ID_2))).thenReturn(ImmutableList.of(fullNeData, wrong));
        when(neRepository.get(ID_1)).thenReturn(Optional.of(fullNeData));
        when(neRepository.get(ID_2)).thenReturn(Optional.of(wrong));

        actionResynchronize = new ActionResynchronize(repositoryManager, commonServices);
    }

    @Test public void testMenuName() throws Exception {
        assertThat(actionResynchronize.getMenuName(), is(TreeTableLabels.RESYNCHRONIZE.toString()));
    }

    @Test public void testDescription() throws Exception {
        assertThat(actionResynchronize.getShortDescription(),
                is(TreeTableLabels.RESYNCHRONIZE_DESC.toString()));
    }

    @Test public void testIsPluginAllowed_ok_for_INE_2_objects() throws Exception {
        when(secureActionValidation.checkPermission(OP_RESYNCHRONIZE_DATA_SAN, fullNeData.getNe())).thenReturn(true);
        when(secureActionValidation.checkPermission(OP_RESYNCHRONIZE_DATA_SAN, wrong.getNe())).thenReturn(true);
        
        boolean pluginActionAllowed = actionResynchronize.isPluginActionAllowed(new INE[]{fullNeData.getNe(), wrong.getNe()});

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_for_INE() throws Exception {
        INE[] objectsToCheck = {fullNeData.getNe()};
        when(secureActionValidation.checkPermission(OP_RESYNCHRONIZE_DATA_SAN, objectsToCheck)).thenReturn(true);
        
        boolean pluginActionAllowed = actionResynchronize.isPluginActionAllowed(objectsToCheck);

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_TOPO_SYMBOL() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        NEIdItem neId = new NEIdItem(ID_1);
        topologicalSymbol.setNetworkElement(neId);
        ITopologicalSymbol[] objectsToCheck = {topologicalSymbol};
        when(secureActionValidation.checkPermission(OP_RESYNCHRONIZE_DATA_SAN, neId)).thenReturn(true);

        boolean pluginActionAllowed = actionResynchronize.isPluginActionAllowed(objectsToCheck);

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_system_container() throws Exception {
        ISystemContainer system = new SystemContainerItem();
        system.setId(ID_1);

        ISystemContainer[] objectsToCheck = {system};
        fullNeData.getNe().setAssociatedSystemContainerId(ID_1);

        when(neSearchable.findBySystemContainerId(ID_1)).thenReturn(ImmutableList.of(fullNeData));
        when(secureActionValidation.checkPermission(OP_RESYNCHRONIZE_DATA_SAN, fullNeData.getNe())).thenReturn(true);

        boolean pluginActionAllowed = actionResynchronize.isPluginActionAllowed(objectsToCheck);

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_no_permission() throws Exception {
        INE[] objectsToCheck = {fullNeData.getNe()};
        when(secureActionValidation.checkPermission(OP_RESYNCHRONIZE_DATA_SAN, objectsToCheck)).thenReturn(false);

        boolean pluginActionAllowed = actionResynchronize.isPluginActionAllowed(objectsToCheck);

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_wrong_actual_state() {
        fullNeData.getNe().setActualActivationState(NeActivationState.ACTIVATING);
        INE[] managedObjects = {fullNeData.getNe()};

        boolean pluginActionAllowed = actionResynchronize.isPluginActionAllowed(managedObjects);

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void eventPluginActionPerformed_ok_for_INE() throws Exception {
        INE[] objectsToCheck = {fullNeData.getNe()};
        when(secureActionValidation.checkPermission(OP_RESYNCHRONIZE_DATA_SAN, objectsToCheck)).thenReturn(true);

        actionResynchronize.eventPluginActionPerformed(objectsToCheck);

        verify(dcnPluginHelper, times(1)).queueJob(any(JobResynchronizeNe.class));
    }

    @Test public void eventPluginActionPerformed_ok_for_TOPO() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        topologicalSymbol.setNetworkElement(new NEIdItem(ID_1));
        when(secureActionValidation.checkPermission(OP_RESYNCHRONIZE_DATA_SAN, fullNeData.getNe())).thenReturn(true);

        actionResynchronize.eventPluginActionPerformed(new ITopologicalSymbol[] { topologicalSymbol });

        verify(dcnPluginHelper, times(1)).queueJob(any(JobResynchronizeNe.class));
    }

    @Test public void eventPluginActionPerformed_ok_for_topo_container_system() throws Exception {
        ITopologicalContainer container = new TopologicalContainerItem();
        container.setId(ID_2);
        container.setSystemContainerId(ID_3);

        final SystemContainerItem systemContainerItem = new SystemContainerItem();
        systemContainerItem.setId(ID_3);
        when(systemContainerRepository.get(ID_3)).thenReturn(Optional.of(systemContainerItem));

        when(neSearchable.findBySystemContainerId(ID_3)).thenReturn(Collections.singletonList(fullNeData));
        when(secureActionValidation.checkPermission(OP_RESYNCHRONIZE_DATA_SAN, fullNeData.getNe())).thenReturn(true);

        actionResynchronize.eventPluginActionPerformed(new ITopologicalContainer[] { container });

        verify(dcnPluginHelper, times(1)).queueJob(any(JobResynchronizeNe.class));
    }
}