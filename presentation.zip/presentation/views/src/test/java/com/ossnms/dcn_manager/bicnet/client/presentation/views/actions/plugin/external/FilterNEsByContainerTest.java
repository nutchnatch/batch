package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class FilterNEsByContainerTest extends TestsHelper {

    private FilterNEsByContainer containerFilter;

    @Before public void setUp() throws Exception {
        this.containerFilter = new FilterNEsByContainer(repositoryManager);

        final FullNeData fullNeData = buildFullNeData(ID_2, ID_3, "");
        fullNeData.getNe().setAssociatedSystemContainerId(ID_1);

        when(neSearchable.findBySystemContainerId(ID_1)).thenReturn(ImmutableList.of(fullNeData));
        when(neRepository.get(Collections.singletonList(ID_2))).thenReturn(ImmutableList.of(fullNeData));
    }

    @Test public void testFilter_for_system() throws Exception {
        final ISystemContainer systemContainer = buildSystemContainer(ID_1);

        final Stream<INE> nes = containerFilter
                .resolveNEs(new IManagedObject[] { systemContainer});

        assertThat(nes.filter(n -> n.getId() == ID_2).collect(toList()), hasSize(1));

        verify(neSearchable, atLeastOnce()).findBySystemContainerId(anyInt());
        verify(neRepository, never()).get(Collections.singletonList(ID_2));
    }

    @Test public void testFilter_only_for_container() throws Exception {
        final IGenericContainer container = buildContainer(ID_1);

        when(neContainerAssignmentRepository.getNeIdList(container.getId())).thenReturn(Collections.singletonList(ID_2));

        final Stream<INE> nes = containerFilter
                .resolveNEs(new IManagedObject[] { container});

        assertThat(nes.filter(n -> n.getId() == ID_2).collect(toList()), hasSize(1));

        verify(neSearchable, never()).findBySystemContainerId(anyInt());
        verify(neRepository, atLeastOnce()).get(Collections.singletonList(ID_2));
    }

    @Test public void testFilter_for_container_and_system() throws Exception {
        final ISystemContainer systemContainer = buildSystemContainer(ID_1);
        final IGenericContainer container = buildContainer(ID_3);

        when(neContainerAssignmentRepository.getNeIdList(container.getId())).thenReturn(Collections.singletonList(ID_2));

        final Stream<INE> nes = containerFilter
                .resolveNEs(new IManagedObject[] { container, systemContainer});

        assertThat(nes.filter(n -> n.getId() == ID_2).collect(toList()), hasSize(1));

        verify(neSearchable, atLeastOnce()).findBySystemContainerId(ID_1);
    }

    @Test public void testFilter_not_system_object() throws Exception {
        final FullNeData fullNeData = buildFullNeData(ID_2, ID_3, "");

        final Stream<INE> nes = containerFilter
                .resolveNEs(new IManagedObject[] { fullNeData.getNe()});

        assertThat(nes.filter(n -> n.getId() == ID_2).collect(toList()), hasSize(1));
    }
}