package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeRouteInfo;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.hamcrest.Matchers.contains;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class NodeDomainComparatorTest extends TestsHelper {

    public static final int ID_4 = 4;

    private NodeDomain nodeDomain;
    private NodeNe nodeNe1;
    private NodeNe nodeNe2;
    private NodeNe nodeNe3;
    private NodeNe nodeNe4;

    @Before public void setUp() throws Exception {
        NodeDomainComparator nodeDomainComparator = new NodeDomainComparator(repositoryManager);
        nodeDomain = new NodeDomain(ID_1, new NodeRoot(1, "Root"),nodeDomainComparator);
        nodeDomain.getValue().setName("domain1");

        nodeNe1 = new NodeNe(ID_1, nodeDomain);
        nodeNe1.getValue().setName("ne1");

        nodeNe2 = new NodeNe(ID_2, nodeDomain);
        nodeNe2.getValue().setName("ne2");

        nodeNe3 = new NodeNe(ID_3, nodeDomain);
        nodeNe3.getValue().setName("ne3");

        nodeNe4 = new NodeNe(ID_4, nodeDomain);
        nodeNe4.getValue().setName("ne4");

        FullNeData fullNeData1 = buildNe1();
        FullNeData fullNeData2 = buildNe2();
        FullNeData fullNeData3 = buildNe3();
        FullNeData fullNeData4 = buildNe4_with_no_gne_route();

        when(neRepository.get(ID_1)).thenReturn(Optional.of(fullNeData1));
        when(neRepository.get(ID_2)).thenReturn(Optional.of(fullNeData2));
        when(neRepository.get(ID_3)).thenReturn(Optional.of(fullNeData3));
        when(neRepository.get(ID_4)).thenReturn(Optional.of(fullNeData4));
    }

    @Test public void testCompare_sortByConnectivity() throws Exception {
        nodeDomain.setSelectedGneId(Optional.of(ID_1));

        nodeDomain.addChild(nodeNe1);
        nodeDomain.addChild(nodeNe2);
        nodeDomain.addChild(nodeNe3);
        nodeDomain.addChild(nodeNe4);

        assertThat(nodeDomain.getAllChildren(), contains(nodeNe1, nodeNe3, nodeNe2, nodeNe4));
    }

    @Test public void testCompare_byNodeName() throws Exception {
        nodeDomain.setSelectedGneId(Optional.of(ID_1));
        nodeDomain.setSelectedGneId(Optional.empty());

        nodeDomain.addChild(nodeNe1);
        nodeDomain.addChild(nodeNe2);
        nodeDomain.addChild(nodeNe3);
        nodeDomain.addChild(nodeNe4);

        assertThat(nodeDomain.getAllChildren(), contains(nodeNe1, nodeNe2, nodeNe3, nodeNe4));
    }

    private FullNeData buildNe1() {
        FullNeData fullNeData1 = buildFullNeData(ID_1, ID_1, EMPTY);
        fullNeData1.getNe().setNeighbourhoodId("ne1");

        fullNeData1.getInfo().getNeRouteInfo().get().add(new NeRouteInfo("domain1", 200, "ne2"));

        return fullNeData1;
    }

    private FullNeData buildNe2() {
        FullNeData fullNeData1 = buildFullNeData(ID_2, ID_1, EMPTY);
        fullNeData1.getNe().setNeighbourhoodId("ne2");

        fullNeData1.getInfo().getNeRouteInfo().get().add(new NeRouteInfo("domain1", 200, "ne1"));
        fullNeData1.getInfo().getNeRouteInfo().get().add(new NeRouteInfo("domain2", 100, "ne2"));

        return fullNeData1;
    }

    private FullNeData buildNe3() {
        FullNeData fullNeData1 = buildFullNeData(ID_3, ID_1, EMPTY);
        fullNeData1.getNe().setNeighbourhoodId("ne3");

        fullNeData1.getInfo().getNeRouteInfo().get().add(new NeRouteInfo("domain1", 100, "ne1"));
        fullNeData1.getInfo().getNeRouteInfo().get().add(new NeRouteInfo("domain2", 300, "ne2"));

        return fullNeData1;
    }

    private FullNeData buildNe4_with_no_gne_route() {
        FullNeData fullNeData1 = buildFullNeData(ID_4, ID_1, EMPTY);
        fullNeData1.getNe().setNeighbourhoodId("ne4");

        fullNeData1.getInfo().getNeRouteInfo().get().add(new NeRouteInfo("domain2", 300, "ne2"));

        return fullNeData1;
    }
}