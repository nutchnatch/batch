package com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.assignment.node;

import com.coriant.widgets.togglebuttontree.ToggleButtonTree;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import org.junit.Test;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;
import java.awt.Font;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ContainerNodeRendererTest {

    @Test public void testGetTreeCellRendererComponent() throws Exception {

        final ContainerNode root = buildContainerNode(0, 0, false);
        final ContainerNode node1 = buildContainerNode(1, 0, true);
        final ContainerNode node2 = buildContainerNode(2, 0, false);

        root.add(node1);
        root.add(node2);

        final ContainerNodeRenderer renderer = new ContainerNodeRenderer();

        final JTree tree = new ToggleButtonTree<>(new DefaultTreeModel(root));
        tree.setCellRenderer(renderer);
        tree.repaint();

        final JLabel rootRendered = (JLabel) renderer
                .getTreeCellRendererComponent(tree, root, false, true, false, 0, false);

        assertThat(rootRendered.getText(), is("container_0"));
        assertThat(rootRendered.getFont().getStyle(), is(Font.PLAIN));

        final JLabel node1Rendered = (JLabel) renderer
                .getTreeCellRendererComponent(tree, node1, false, true, true, 1, false);

        assertThat(node1Rendered.getText(), is("container_1"));
        assertThat(node1Rendered.getFont().getStyle(), is(Font.BOLD));

        final JLabel node2Rendered = (JLabel) renderer
                .getTreeCellRendererComponent(tree, node2, false, true, true, 2, false);

        assertThat(node2Rendered.getText(), is("container_2"));
        assertThat(node2Rendered.getFont().getStyle(), is(Font.PLAIN));
    }

    private ContainerNode buildContainerNode(int i, int parentId, boolean isPrimary) {
        final IGenericContainer genericContainer = new GenericContainerItem();
        genericContainer.setId(i);
        genericContainer.setIdName("container_" + i);
        genericContainer.setParentId(parentId);

        final ContainerNode containerNode = new ContainerNode(genericContainer, new ImageIcon());
        containerNode.setPrimaryContainer(isPrimary);

        return containerNode;
    }
}