package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobNEsActivate;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateNEs.ActivateNEs;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_ALL_NES_SAN;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_NES_SAN;
import static java.util.stream.Collectors.toList;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionActivateNEsUnderChannelTest extends TestsHelper {

    private ActionActivateNEsUnderChannel actionActivateNEsUnderChannel;

    private FullChannelData fullChannelData;
    private FullNeData fullNeDataOk;

    @Before public void setUp() throws Exception {
        actionActivateNEsUnderChannel = new ActionActivateNEsUnderChannel(repositoryManager, commonServices);

        fullChannelData = buildFullChannelData(ID_2, ID_2);

        fullNeDataOk = buildFullNeData(ID_1, ID_2, "");
        fullNeDataOk.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeDataOk.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        FullNeData fullNeDataActive = buildFullNeData(ID_2, ID_2, "");
        fullNeDataActive.getNe().setActivation(EnableSwitch.ENABLED);
        fullNeDataActive.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        FullNeData fullNeDataDeactivating = buildFullNeData(ID_3, ID_2, "");
        fullNeDataDeactivating.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeDataDeactivating.getInfo().setGuiActualActivationState(GuiActualActivationState.DEACTIVATING);

        when(neSearchable.findByParentId(ID_2))
                .thenReturn(ImmutableList.of(fullNeDataActive, fullNeDataOk, fullNeDataDeactivating));

        withPermissions(OP_ACTIVATE_NES_SAN, fullNeDataOk.getNe());
    }

    private <T extends IManagedObjectId> T[] withPermissions(SecureAction action, T... objectsToCheck) {
        when(secureActionValidation.checkPermission(action, objectsToCheck)).thenReturn(true);
        when(secureActionValidation.checkPermission(action)).thenReturn(true);
        return objectsToCheck;
    }

    @Test public void testGetNEsInactive() throws Exception {
        Collection<INEId> nesInactive = actionActivateNEsUnderChannel.inactiveNEs(fullChannelData.getChannel())
                .collect(toList());

        assertThat(nesInactive.size(), is(1));
        assertThat(nesInactive.contains(fullNeDataOk.getNe().getNEId()), is(true));
        verify(loggerManager, never()).error(any(String.class), any(String.class));
    }

    @Test public void testIsPluginActionAllowed() throws Exception {

        boolean pluginActionAllowed = actionActivateNEsUnderChannel.isPluginActionAllowed(
                withPermissions(OP_ACTIVATE_ALL_NES_SAN, fullChannelData.getChannel()));

        assertThat(pluginActionAllowed, is(true));
        verify(loggerManager, never()).error(any(String.class), any(String.class));
    }

    @Test public void testEventPluginActionPerformed() throws Exception {
        actionActivateNEsUnderChannel.eventPluginActionPerformed(
                withPermissions(OP_ACTIVATE_ALL_NES_SAN, fullChannelData.getChannel()));
        
        verify(loggerManager, never()).error(any(String.class), any(String.class));
    }

    @Test public void testInternalWorker() throws Exception {
        ActivateNEs activateNEs = actionActivateNEsUnderChannel.new ActivateNEs(
                ImmutableList.of(fullChannelData.getChannel()));

        boolean executed = activateNEs.doInBackground();
        activateNEs.done();

        assertThat(executed, is(true));
        verify(dcnPluginHelper, times(1)).queueJob(any(JobNEsActivate.class));
    }
}
