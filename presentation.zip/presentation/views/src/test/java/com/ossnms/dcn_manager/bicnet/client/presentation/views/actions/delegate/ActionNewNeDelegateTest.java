package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static java.util.Optional.of;
import static junit.framework.TestCase.assertFalse;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ActionNewNeDelegateTest extends TestsHelper {

    @Mock
    NewElementDialogHandler dialogHandler;
    @Mock
    ChannelType channelType;
    IEM channel = new EMItem();

    private ActionNewNeDelegate actionNewNeDelegate;

    @Before
    public void setUp() throws Exception {
        actionNewNeDelegate = new ActionNewNeDelegate(commonServices, dialogHandler);

        channel.setId(ID_1);
        channel.setEmType("type");

        when(secureActionValidation.checkPermission(SecureAction.OP_NEW_NE_SAN)).thenReturn(true);
        when(staticConfiguration.findChannelType("type")).thenReturn(of(channelType));
        when(channelType.supportsNeCreation()).thenReturn(true);
    }

    @Test
    public void testIsActionAllowed() throws Exception {
        boolean actionAllowed = actionNewNeDelegate.isActionAllowed(new IManagedObject[]{channel});
        assertTrue(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_no_permission() throws Exception {
        when(secureActionValidation.checkPermission(SecureAction.OP_NEW_NE_SAN)).thenReturn(false);

        boolean actionAllowed = actionNewNeDelegate.isActionAllowed(new IManagedObject[]{channel});
        assertFalse(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_channel_not_support_ne_creation() throws Exception {
        when(channelType.supportsNeCreation()).thenReturn(false);

        boolean actionAllowed = actionNewNeDelegate.isActionAllowed(new IManagedObject[]{channel});
        assertFalse(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_not_single_selection() throws Exception {
        boolean actionAllowed = actionNewNeDelegate.isActionAllowed(new IManagedObject[]{channel, buildFullChannelData(1, 1).getChannel()});
        assertFalse(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_not_channel() throws Exception {
        boolean actionAllowed = actionNewNeDelegate.isActionAllowed(new IManagedObject[]{buildContainer(1)});
        assertFalse(actionAllowed);
    }

    @Test
    public void testEventActionPerformed() throws Exception {
        actionNewNeDelegate.eventActionPerformed(new IManagedObject[]{channel});

        verify(dialogHandler, times(1)).showNewNeDialog(channel);
    }

    @Test
    public void testGetActionId() throws Exception {
        assertThat(actionNewNeDelegate.getMenuName(), is(TreeTableLabels.NEW_NE));
    }

    @Test
    public void testGetMenuName() throws Exception {
        assertThat(actionNewNeDelegate.getActionId(), is(ActionNewNeDelegate.class.getName()));
    }
}
