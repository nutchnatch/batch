package com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.finder;

import com.coriant.widgets.togglebuttontree.ToggleButtonTree;
import com.coriant.widgets.treetable.TreeTable;
import com.coriant.widgets.treetable.TreeTableModel;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.framework.client.persistence.FrameworkPersistentView;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeRoot;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.swing.tree.TreePath;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class FindDialogHighlightTest extends TestsHelper {
    @Mock FrameworkPersistentView view;
    @Mock private BiCNetPluginFrame frame;
    @Mock private TreeTable<Node> treeTable;
    @Mock private TreeTableModel<Node> model;
    @Mock private ToggleButtonTree<Node> tree;

    private FindDialogHighlight highlight;

    @Before public void setUp() throws Exception {
        highlight = new FindDialogHighlight(view, treeTable, repositoryManager);

        NodeRoot nodeRoot = buildNodeMediatorRoot();
        NodeMediator nodeMediator = new NodeMediator(ID_1, nodeRoot);
        nodeMediator.getValue().setName("NODE");
        nodeRoot.addChild(nodeMediator);

        when(view.getFrame()).thenReturn(frame);
        when(treeTable.getTreeModel()).thenReturn(model);
        when(model.getRoot()).thenReturn(nodeRoot);
        when(treeTable.getTree()).thenReturn(tree);
    }

    @Test public void testHighlight() throws Exception {
        highlight.highlight("NODE");

        verify(frame, times(1)).activateFrame();
        verify(treeTable, times(1)).requestFocusInWindow();
        verify(tree, times(1)).expandPath(any(TreePath.class));
    }

    @Test public void testHighlight_node_not_found() throws Exception {
        highlight.highlight("NODE_WRONG");

        verify(frame, times(1)).activateFrame();
        verify(treeTable, times(1)).requestFocusInWindow();
        verify(tree, never()).expandPath(any(TreePath.class));
        verify(tree, never()).setSelectionPath(any(TreePath.class));
    }
}