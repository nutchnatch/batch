package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.builder;

import com.coriant.widgets.treetable.TreeTable;
import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.api.action.PluginAction;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.delegate.ActionNewChannelDelegate;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ActionBuilderMediatorOperationsTest {
    @Mock private RepositoryManager repositoryManager;
    @Mock private CommonServices commonServices;
    @Mock private TreeTable<Node> treeTable;
    @Mock private NewElementDialogHandler dialogHandler;

    private static final Collection<IManagedObject> VALID_VALUES = ImmutableList
            .of((IManagedObject) new MediatorItem());

    private static final Collection<IManagedObject> INVALID_VALUES = ImmutableList
            .of((IManagedObject)new EMItem());

    private static final Collection<IManagedObject> VALID_WITH_INVALID_TYPES = ImmutableList
            .of((IManagedObject) new EMItem(), new MediatorItem());

    private ActionBuilderMediatorOperations actionBuilder;

    @Before public void setUp() throws Exception {
        actionBuilder = new ActionBuilderMediatorOperations(repositoryManager, commonServices,
                dialogHandler);
    }

    @Test public void testValidActions() {
        final Collection<PluginAction> actions = actionBuilder.createList().actionsOf(VALID_VALUES);

        assertThat(actions.size(), is(3));
        assertThat(actions.stream().map(PluginAction::getMenuID).collect(Collectors.toList()),
                containsInAnyOrder(
                        ActionActivateMediator.class.getName(),
                        ActionDeactivateMediator.class.getName(),
                        ActionNewChannelDelegate.class.getName()));
    }

    @Test public void testInvalidActions() {
        final Collection<PluginAction> actions = actionBuilder.actionsOf(INVALID_VALUES);

        assertTrue(actions.isEmpty());
    }

    @Test public void testAllMatch() {
        assertTrue(actionBuilder.allMatch(VALID_VALUES));
    }

    @Test public void testAllMatch_valid_with_invalid_types() {
        assertFalse(actionBuilder.allMatch(VALID_WITH_INVALID_TYPES));
    }

    @Test public void testAllMatchFalse() {
        assertFalse(actionBuilder.allMatch(INVALID_VALUES));
    }

    @Test public void testActions() {
        assertTrue(actionBuilder.getActions().isEmpty());
    }
}
