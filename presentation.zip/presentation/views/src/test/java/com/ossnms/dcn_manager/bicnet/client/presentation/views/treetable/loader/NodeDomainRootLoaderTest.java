package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader;

import com.google.code.tempusfugit.temporal.Duration;
import com.google.code.tempusfugit.temporal.Timeout;
import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static com.google.code.tempusfugit.temporal.WaitFor.waitOrTimeout;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NodeDomainRootLoaderTest extends TestsHelper {

    private NodeDomainRootLoader nodeDomainRootLoader;

    @Before public void setUp() throws Exception {
        ISecureClientSession secureClientSession = mock(ISecureClientSession.class);
        NodeDomainRoot nodeDomainRoot = new NodeDomainRoot("TNMS");

        IAS domain = buildDomain(ID_1, new NEIdItem[] { new NEIdItem(ID_1), new NEIdItem(ID_2) });
        FullNeData fullNeData1 = buildFullNeData(ID_1, ID_1, "");
        fullNeData1.getNe().setActivation(EnableSwitch.ENABLED);
        fullNeData1.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        FullNeData fullNeData2 = buildFullNeData(ID_2, ID_1, "");
        fullNeData2.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeData2.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        when(domainSearchable.findByIdName(anyString())).thenReturn(Optional.of(domain));
        when(domainRepository.getAll()).thenReturn(ImmutableList.of(domain));
        when(neRepository.get(ImmutableList.of(ID_1, ID_2))).thenReturn(ImmutableList.of(fullNeData1, fullNeData2));
        when(secureActionValidation.checkPermission(any(SecureAction.class), any(IManagedObject.class)))
                .thenReturn(true);
        when(secureActionValidation.checkVisibility(any(INEId.class))).thenReturn(true);
        when(iconManager.findNeOverlayIcon(any(FullNeData.class), anyInt())).thenReturn(Optional.empty());
        when(iconManager.findNeOverlayIcon(any(INE.class), anyInt())).thenReturn(Optional.empty());

        when(dcnPluginHelper.getPluginId()).thenReturn("plugin_id");
        when(dcnPluginHelper.getClientSession()).thenReturn(Optional.of(secureClientSession));

        nodeDomainRootLoader = new NodeDomainRootLoader(repositoryManager, commonServices, nodeDomainRoot);
    }

    @Test public void testLoad() throws Exception {
        Node root = nodeDomainRootLoader.load();

        waitOrTimeout(() -> root.getChildCount() > 0, Timeout.timeout(Duration.seconds(10)));

        assertTrue(NodeDomainRoot.class.isInstance(root));
        assertThat(root.getChildCount(), is(1));

        assertTrue(NodeDomain.class.isInstance(root.getChildAt(0)));
        NodeDomain nodeDomain = (NodeDomain) root.getChildAt(0);
        assertThat(nodeDomain.getChildCount(), is(2));

        assertTrue(NodeNe.class.isInstance(nodeDomain.getChildAt(0)));
        NodeNe nodeNe1 = (NodeNe) nodeDomain.getChildAt(0);
        assertThat(nodeNe1.getChildCount(), is(0));

        assertTrue(NodeNe.class.isInstance(nodeDomain.getChildAt(1)));
        NodeNe nodeNe2 = (NodeNe) nodeDomain.getChildAt(1);
        assertThat(nodeNe2.getChildCount(), is(0));

        /*
         * Test CheckBox state
         */

        assertFalse(nodeDomain.getValue().isToogleButtonChecked());
        assertFalse(nodeDomain.getValue().isToogleButtonVisible());

        assertTrue(nodeNe1.getValue().isToogleButtonEnable());
        assertTrue(nodeNe1.getValue().isToogleButtonChecked());
        assertTrue(nodeNe1.getValue().isToogleButtonVisible());

        assertTrue(nodeNe2.getValue().isToogleButtonEnable());
        assertFalse(nodeNe2.getValue().isToogleButtonChecked());
        assertTrue(nodeNe2.getValue().isToogleButtonVisible());
    }
}
