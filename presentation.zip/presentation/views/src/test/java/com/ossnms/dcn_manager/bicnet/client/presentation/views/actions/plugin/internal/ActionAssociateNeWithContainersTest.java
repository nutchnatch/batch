package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeContainerAssignmentSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NEContainerAssignmentRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Test;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.MOVE_NE_SAN;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ActionAssociateNeWithContainersTest {

    @Test public void shouldAllowSingleSelection() throws Exception {
        SecureAction secAction = MOVE_NE_SAN;
        boolean secAllowed = true;
        Map<INE, Collection<INeGenericContainerAssignment>> nes = of(
                ne(1, 0), asList(assignment(1, 1, true)));

        ActionAssociateNeWithContainers action = new ActionAssociateNeWithContainers(
                commonService(secAction, secAllowed, nes.keySet()),
                repo(neRepo(nes.keySet()), assignmentRepo(nes)),
                mock(NewElementDialogHandler.class));

        boolean allowed = action.isPluginActionAllowed(nes.keySet().toArray(new IManagedObject[0]));

        assertThat(allowed, is(true));
    }

    @Test public void shouldAllowMiltipleSelection() throws Exception {
        SecureAction secAction = MOVE_NE_SAN;
        boolean secAllowed = true;
        Map<INE, Collection<INeGenericContainerAssignment>> nes = of(
                ne(1, 0), asList(assignment(1, 100, true), assignment(1, 200, false)),
                ne(2, 0), asList(assignment(2, 100, true), assignment(2, 200, false)));

        ActionAssociateNeWithContainers action = new ActionAssociateNeWithContainers(
                commonService(secAction, secAllowed, nes.keySet()),
                repo(neRepo(nes.keySet()), assignmentRepo(nes)),
                mock(NewElementDialogHandler.class));

        boolean allowed = action.isPluginActionAllowed(nes.keySet().toArray(new IManagedObject[0]));

        assertThat(allowed, is(true));
    }

    @Test public void shouldNotAllowUnderSystem() throws Exception {
        SecureAction secAction = MOVE_NE_SAN;
        boolean secAllowed = true;
        Map<INE, Collection<INeGenericContainerAssignment>> nes = of(ne(1, 100), emptyList()); //is under a system

        ActionAssociateNeWithContainers action = new ActionAssociateNeWithContainers(
                commonService(secAction, secAllowed, nes.keySet()),
                repo(neRepo(nes.keySet()), assignmentRepo(nes)),
                mock(NewElementDialogHandler.class));

        boolean allowed = action.isPluginActionAllowed(nes.keySet().toArray(new IManagedObject[0]));

        assertThat(allowed, is(false));
    }

    @Test public void shouldNotAllowWithNoPermissions() throws Exception {
        SecureAction secAction = MOVE_NE_SAN;
        boolean secAllowed = false; // no permissions
        Map<INE, Collection<INeGenericContainerAssignment>> nes = of(
                ne(1, 0), asList(assignment(1, 100, true)),
                ne(2, 0), asList(assignment(2, 100, true)));

        ActionAssociateNeWithContainers action = new ActionAssociateNeWithContainers(
                commonService(secAction, secAllowed, nes.keySet()),
                repo(neRepo(nes.keySet()), assignmentRepo(nes)),
                mock(NewElementDialogHandler.class));

        boolean allowed = action.isPluginActionAllowed(nes.keySet().toArray(new IManagedObject[0]));

        assertThat(allowed, is(false));
    }

    @Test public void shouldNotAllowForNesUnderDifferentContainers() throws Exception {
        SecureAction secAction = MOVE_NE_SAN;
        boolean secAllowed = true;
        Map<INE, Collection<INeGenericContainerAssignment>> nes = of(
                ne(1, 0), asList(assignment(1, 100, true)),
                ne(2, 0), asList(assignment(2, 1000, true)));

        ActionAssociateNeWithContainers action = new ActionAssociateNeWithContainers(
                commonService(secAction, secAllowed, nes.keySet()),
                repo(neRepo(nes.keySet()), assignmentRepo(nes)),
                mock(NewElementDialogHandler.class));

        boolean allowed = action.isPluginActionAllowed(nes.keySet().toArray(new IManagedObject[0]));

        assertThat(allowed, is(false));
    }

    @Test public void shouldNotAllowForNesWithDifferentPrimaryContainer() throws Exception {
        SecureAction secAction = MOVE_NE_SAN;
        boolean secAllowed = true;
        Map<INE, Collection<INeGenericContainerAssignment>> nes = of( 
                ne(1, 0), asList(assignment(1, 100, true), assignment(1, 200, false)),
                ne(2, 0), asList(assignment(2, 100, false), assignment(2, 200, true)));

        ActionAssociateNeWithContainers action = new ActionAssociateNeWithContainers(
                commonService(secAction, secAllowed, nes.keySet()),
                repo(neRepo(nes.keySet()), assignmentRepo(nes)),
                mock(NewElementDialogHandler.class));

        boolean allowed = action.isPluginActionAllowed(nes.keySet().toArray(new IManagedObject[0]));

        assertThat(allowed, is(false));
    }


    @Test public void shouldAllowOnlyForNEs() throws Exception {
        SecureAction secAction = MOVE_NE_SAN;
        boolean secAllowed = true;
        Map<INE, Collection<INeGenericContainerAssignment>> nes = of(ne(1, 0), emptyList());

        ActionAssociateNeWithContainers action = new ActionAssociateNeWithContainers(
                commonService(secAction, secAllowed, nes.keySet()),
                repo(neRepo(nes.keySet()), assignmentRepo(nes)),
                mock(NewElementDialogHandler.class));

        boolean allowed = action.isPluginActionAllowed(new IManagedObject[]{new SystemContainerItem()});

        assertThat(allowed, is(false));
    }

    private RepositoryManager repo(NeRepository neRepo, NEContainerAssignmentRepository assignmentRepo) {
        RepositoryManager repo = mock(RepositoryManager.class);
        when(repo.getNeRepository()).thenReturn(neRepo);
        when(repo.getNEContainerAssignmentRepository()).thenReturn(assignmentRepo);
        return repo;
    }

    private INeGenericContainerAssignment assignment(int neId, int containerId, boolean primary) {
        NeGenericContainerAssignmentItem item = new NeGenericContainerAssignmentItem();
        item.setNetworkElementId(neId);
        item.setGenericContainerId(containerId);
        item.setPrimary(primary);
        return item;
    }

    private NEContainerAssignmentRepository assignmentRepo(Map<INE, Collection<INeGenericContainerAssignment>> assignments) throws RepositoryException {
        NEContainerAssignmentRepository assignmentRepository = mock(NEContainerAssignmentRepository.class);
        NeContainerAssignmentSearchable queries = mock(NeContainerAssignmentSearchable.class);
        assignments.forEach((ne, asses) ->
                when(queries.findByNetworkElementId(ne.getId())).thenReturn(asses));
        when(assignmentRepository.queries()).thenReturn(queries);
        return assignmentRepository;
    }

    private CommonServices commonService(SecureAction secAction, boolean allowed, Collection<? extends IManagedObjectId> items) {
        CommonServices commonServices = mock(CommonServices.class);
        SecureActionValidation validation = mock(SecureActionValidation.class);
        when(validation.checkPermission(secAction, items.toArray(new IManagedObjectId[0]))).thenReturn(allowed);
        when(commonServices.getSecureActionValidation()).thenReturn(validation);
        return commonServices;
    }

    private NeRepository neRepo(Collection<INE> nes) throws RepositoryException {
        NeRepository neRepo = mock(NeRepository.class);
        List<Integer> ids = nes.stream().map(INEId::getId).collect(toList());
        List<FullNeData> data = nes.stream().map(ne -> new FullNeData(ne, null, null)).collect(toList());
        when(neRepo.get(ids)).thenReturn(data);
        return neRepo;
    }

    private INE ne(int id, int system) {
        INE ne = new NEItem();
        ne.setId(id);
        ne.setAssociatedSystemContainerId(system);
        return ne;
    }
}