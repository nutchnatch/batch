package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionPaste;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers.CutPasteHandler;
import org.junit.Test;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ActionPasteTest extends TestsHelper {

    private final CutPasteHandler cutPasteHandler = mock(CutPasteHandler.class);
    private final ActionPaste actionPaste = new ActionPaste(cutPasteHandler);

    private IManagedObject destination(int id) {
        return buildFullChannelData(id, ID_1).getChannel();
    }

    @Test public void shouldAllowForSingleDestination() throws Exception {
        IManagedObject[] destinations = {destination(ID_1)};
        when(cutPasteHandler.canPaste(asList(destinations))).thenReturn(true);

        assertTrue(actionPaste.isPluginActionAllowed(destinations));
    }

    @Test public void shouldNotAllowForMultipleDestinations() throws Exception {
        IManagedObject[] destinations = {destination(ID_1), destination(ID_2)}; //when multiple destinations
        when(cutPasteHandler.canPaste(asList(destinations))).thenReturn(true);

        assertFalse(actionPaste.isPluginActionAllowed(destinations));
    }

    @Test public void shouldNotAllowWhenPasteHandlerRejects() throws Exception {
        IManagedObject[] destinations = {destination(ID_1)};
        when(cutPasteHandler.canPaste(asList(destinations))).thenReturn(false); //when handler rejects

        assertFalse(actionPaste.isPluginActionAllowed(destinations));
    }
}
