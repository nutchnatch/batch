package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableList;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;

public class TableColumnTest {

    @Test
    public void testDefaultValues() {

        final ImmutableList<TableColumn> columns = new TableColumnsBuilder().build();

        assertFalse(getColumnName(ColumnId.TREE_MODEL, columns).isRemovable());
        assertThat(getColumnName(ColumnId.INFO, columns).getWidth(), is(TableColumnsBuilder.DEFAULT_INFO_WIDTH));
    }

    private TableColumn getColumnName(final ColumnId columnId, ImmutableList<TableColumn> columns) {
        return FluentIterable.from(columns).firstMatch(new Predicate<TableColumn>() {
            @Override
            public boolean apply(TableColumn input) {
                return input.getId() == columnId;
            }
        }).get();
    }
}
