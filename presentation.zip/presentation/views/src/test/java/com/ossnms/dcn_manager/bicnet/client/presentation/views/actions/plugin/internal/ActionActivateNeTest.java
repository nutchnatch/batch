package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobNEsActivate;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_NES_SAN;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionActivateNeTest extends TestsHelper {

    private ActionActivateNe actionActivateNe;
    private FullNeData fullNeData;

    @Before public void setUp() throws Exception {
        fullNeData = buildFullNeData(ID_1, ID_1, "");
        fullNeData.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        when(neRepository.get(ImmutableList.of(ID_1))).thenReturn(ImmutableList.of(fullNeData));

        actionActivateNe = new ActionActivateNe(repositoryManager, commonServices);
    }

    private <T extends IManagedObjectId> T[] withPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_ACTIVATE_NES_SAN, objectsToCheck)).thenReturn(true);
        return objectsToCheck;
    }

    private <T extends IManagedObjectId> T[] withoutPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_ACTIVATE_NES_SAN, objectsToCheck)).thenReturn(false);
        return objectsToCheck;
    }

    @Test public void testMenuName() throws Exception {
        assertThat(actionActivateNe.getMenuName(), is(TreeTableLabels.ACTIVATE_NE.toString()));
    }

    @Test public void testDescription() throws Exception {
        assertThat(actionActivateNe.getShortDescription(), is(TreeTableLabels.ACTIVATE_NE.toString()));
    }

    @Test public void testIsPluginAllowed_ok_for_INE_2_objects() throws Exception {
        FullNeData wrong = buildFullNeData(ID_2, ID_2, "");
        wrong.getNe().setActivation(EnableSwitch.ENABLED);

        when(neRepository.get(ImmutableList.of(ID_1, ID_2))).thenReturn(ImmutableList.of(fullNeData, wrong));

        boolean pluginActionAllowed = actionActivateNe
                .isPluginActionAllowed(withPermissions(fullNeData.getNe(), wrong.getNe()));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_for_INE() throws Exception {
        boolean pluginActionAllowed = actionActivateNe
                .isPluginActionAllowed(withPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_wrong_object() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        topologicalSymbol.setNetworkElement(new NEIdItem(ID_1));

        boolean pluginActionAllowed = actionActivateNe
                .isPluginActionAllowed(withPermissions(topologicalSymbol));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_no_permission() throws Exception {
        boolean pluginActionAllowed = actionActivateNe
                .isPluginActionAllowed(withoutPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_wrong_required_state() throws Exception {
        fullNeData.getNe().setActivation(EnableSwitch.ENABLED);

        boolean pluginActionAllowed = actionActivateNe
                .isPluginActionAllowed(withPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_deactivating() throws Exception {
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.DEACTIVATING);

        boolean pluginActionAllowed = actionActivateNe
                .isPluginActionAllowed(withPermissions(fullNeData.getNe()));
        
        assertThat(pluginActionAllowed, is(false));
    }

    @SuppressWarnings("unchecked")
    @Test public void eventPluginActionPerformed_ok_for_INE() throws Exception {
        actionActivateNe.eventPluginActionPerformed(withPermissions(fullNeData.getNe()));

        verify(dcnPluginHelper, times(1)).queueJob(any(JobNEsActivate.class));
    }

    @SuppressWarnings("unchecked")
    @Test public void eventPluginActionPerformed_wrong_object() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        topologicalSymbol.setNetworkElement(new NEIdItem(ID_1));

        actionActivateNe.eventPluginActionPerformed(withPermissions(topologicalSymbol));

        verify(dcnPluginHelper, never()).queueJob(any(JobNEsActivate.class));
    }
}
