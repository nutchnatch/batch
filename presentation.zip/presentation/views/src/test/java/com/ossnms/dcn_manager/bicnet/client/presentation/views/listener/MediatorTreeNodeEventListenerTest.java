package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediatorRoot;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MediatorTreeNodeEventListenerTest extends TestsHelper {
    @Mock private ModelUpdater modelUpdater;
    @Mock private GraphicalRepresentationBuilder<FullMediatorData> graphicalRepresentationBuilder;
    @Mock private NodeMediatorRoot mediatorRoot;

    private MediatorTreeNodeEventListener mediatorTreeNodeEventListener;

    @Before public void setUp() throws Exception {
        mediatorTreeNodeEventListener = new MediatorTreeNodeEventListener(modelUpdater, commonServices,
                repositoryManager, graphicalRepresentationBuilder);

        mediatorRoot = new NodeMediatorRoot("Root");

        when(modelUpdater.getNodeRoot()).thenReturn(mediatorRoot);
        when(graphicalRepresentationBuilder.getIconManager()).thenReturn(new IconManager());
    }

    @Test public void testRemove() throws Exception {
        FullMediatorData mediatorData = buildFullMediatorData(ID_1);
        NodeMediator nodeMediator = buildNodeMediator(mediatorRoot, ID_1);
        mediatorRoot.addChild(nodeMediator);

        mediatorTreeNodeEventListener.remove(mediatorData);

        assertTrue(mediatorRoot.getAllChildren().isEmpty());
        verify(modelUpdater, atLeastOnce()).removeNode(nodeMediator);
    }

    @Test public void testAdd() throws Exception {
        FullMediatorData mediatorData = buildFullMediatorData(ID_1);

        mediatorTreeNodeEventListener.add(mediatorData);
        assertThat(mediatorRoot.getAllChildren().size(), is(1));
        verify(modelUpdater, atLeastOnce()).insertNode(any(NodeMediator.class));
    }

    @Test public void testUpdate() throws Exception {
        FullMediatorData mediatorData = buildFullMediatorData(ID_1);
        mediatorData.getMediator().setIdName("new_name");

        NodeMediator nodeMediator = buildNodeMediator(mediatorRoot, ID_1);
        mediatorRoot.addChild(nodeMediator);

        mediatorTreeNodeEventListener.update(mediatorData);

        assertThat(mediatorRoot.getAllChildren().size(), is(1));
        assertThat(nodeMediator.getValue().getName(), is("new_name"));
        verify(modelUpdater, atLeastOnce()).applyStructureChanged(any(NodeMediator.class));
    }
}