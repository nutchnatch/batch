package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.domain;

import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class TreeTableDomainsDocumentTest {
    private RepositoryManager repositoryManager;
    private CommonServices commonServices;

    private FrameworkPluginHelper pluginHelper;
    private IconManager iconManager;
    private ListenersRegistrationManager changeListener;

    private ModelUpdater modelUpdater;
    private TreeTableDomainsDocument document;
    private SecureActionValidation secureActionValidation;

    @Before
    public void setup() throws RepositoryException {
        repositoryManager = mock(RepositoryManager.class);
        commonServices = mock(CommonServices.class);
        changeListener = mock(ListenersRegistrationManager.class);
        modelUpdater = mock(ModelUpdater.class);

        document = new TreeTableDomainsDocument(commonServices, repositoryManager, changeListener);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testAddChangeListeners() {
        document.addChangeListeners(modelUpdater);

        verify(changeListener).addNeListener(Mockito.any(EventChangeListener.class));
        verify(changeListener).addDomainListener(Mockito.any(EventChangeListener.class));
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testRemoveChangeListeners() {
        document.removeChangeListeners();

        verify(changeListener).removeNeListener(Mockito.any(EventChangeListener.class));
        verify(changeListener).removeDomainListener(Mockito.any(EventChangeListener.class));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testGetObject() {
        document.getObject(null);
    }
}
