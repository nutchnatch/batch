package com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.container;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INamedObjectPkg;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ContainerRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.SystemContainerRepository;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;

import static java.util.Arrays.asList;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NewNeUnderContainerModelTest {
    @Test public void shouldResolveGenericContainer() throws Exception {
        IGenericContainer genericContainer = genericContainer(42);
        NewNeUnderContainerModel model = new NewNeUnderContainerModel(
                repoManager(
                        containerRepo(genericContainer),
                        systemRepo()),
                mock(CommonServices.class),
                mock(RegisteredTypesIndex.class),
                of(genericContainer),
                empty());
        
        Optional<INamedObjectPkg> container = model.getContainer();

        assertThat(container, is(of(genericContainer)));
    }

    @Test public void shouldResolveSystemContainer() throws Exception {
        ISystemContainer systemContainer = systemContainer(17);
        NewNeUnderContainerModel model = new NewNeUnderContainerModel(
                repoManager(
                        containerRepo(),
                        systemRepo(systemContainer)),
                mock(CommonServices.class),
                mock(RegisteredTypesIndex.class),
                empty(),
                of(systemContainer));

        Optional<INamedObjectPkg> container = model.getContainer();

        assertThat(container, is(of(systemContainer)));
    }

    @Test public void shouldNotResolveAbsentContainer() throws Exception {
        NewNeUnderContainerModel model = new NewNeUnderContainerModel(
                repoManager(
                        containerRepo(),
                        systemRepo()),
                mock(CommonServices.class),
                mock(RegisteredTypesIndex.class),
                empty(),
                empty());

        Optional<INamedObjectPkg> container = model.getContainer();

        assertThat(container, is(empty()));
    }


    private RepositoryManager repoManager(ContainerRepository containerRepository, SystemContainerRepository systemContainerRepository) {
        RepositoryManager repoManager = mock(RepositoryManager.class);
        when(repoManager.getContainerRepository()).thenReturn(containerRepository);
        when(repoManager.getSystemContainerRepository()).thenReturn(systemContainerRepository);
        return repoManager;
    }

    private SystemContainerRepository systemRepo(ISystemContainer... containers) throws Exception {
        return repository(SystemContainerRepository.class, ISystemContainerId::getId, containers);
    }

    private ContainerRepository containerRepo(IGenericContainer... containers) throws Exception {
        return repository(ContainerRepository.class, IGenericContainer::getId, containers);
    }

    private <R extends Repository<K, V>, V, K> R repository(Class<R> repoClass, Function<V, K> getKey, V... values) throws Exception {
        R repo = mock(repoClass);

        //present keys
        for (V value : values) {
            when(repo.get(getKey.apply(value))).thenReturn(of(value));
        }
        when(repo.getAll()).thenReturn(asList(values));

        //other (absent) keys
        Matcher<K>[] ids = Stream.of(values).map(getKey).map(Matchers::equalTo).toArray(Matcher[]::new);
        Matcher<K> notPresent = not(anyOf(ids));
        when(repo.get(argThat(notPresent))).thenReturn(empty());

        return repo;
    }

    private IGenericContainer genericContainer(int id) {
        IGenericContainer container = new GenericContainerItem();
        container.setIdName("name");
        container.setId(id);
        return container;
    }

    private ISystemContainer systemContainer(int id) {
        ISystemContainer container = new SystemContainerItem();
        container.setIdName("name");
        container.setId(id);
        return container;
    }
}