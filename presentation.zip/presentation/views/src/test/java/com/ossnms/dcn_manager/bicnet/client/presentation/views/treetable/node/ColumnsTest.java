package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import org.junit.Assert;
import org.junit.Test;

import java.util.NoSuchElementException;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ColumnsTest {

    @Test
    public void testSetValue() {
        final Columns columns = new Columns();
        
        columns.setValue(ColumnId.ADDRESS, "address");
        columns.setValue(ColumnId.CONNECT_VIA, "connectVia");
        columns.setValue(ColumnId.INFO, "info");
        columns.setValue(ColumnId.STATE, "state");
        columns.setValue(ColumnId.NETWORK_NAME, "networkName");
        columns.setValue(ColumnId.TYPE, "type");
        
        assertThat(columns.valueOf(ColumnId.ADDRESS).get().getValue(), is("address"));
        assertThat(columns.valueOf(ColumnId.CONNECT_VIA).get().getValue(), is("connectVia"));
        assertThat(columns.valueOf(ColumnId.INFO).get().getValue(), is("info"));
        assertThat(columns.valueOf(ColumnId.STATE).get().getValue(), is("state"));
        assertThat(columns.valueOf(ColumnId.NETWORK_NAME).get().getValue(), is("networkName"));
        assertThat(columns.valueOf(ColumnId.TYPE).get().getValue(), is("type"));
    }
    
    @Test(expected=NoSuchElementException.class)
    public void testInvalidColumnValue() {
        new Columns().setValue(ColumnId.TREE_MODEL, "address");        
    }
    
    @Test
    public void testInvalidValueOfColumnValue() {
        final Optional<ColumnValue> value = new Columns().valueOf(ColumnId.TREE_MODEL);
        
        Assert.assertFalse(value.isPresent());
    }
}
