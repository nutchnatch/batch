package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ActionNewContainerDelegateTest extends TestsHelper {

    @Mock
    NewElementDialogHandler dialogHandler;
    IGenericContainer container = new GenericContainerItem();

    private ActionNewContainerDelegate action;

    @Before
    public void setUp() throws Exception {
        action = new ActionNewContainerDelegate(dialogHandler, commonServices);
        container.setId(0);

        when(secureActionValidation.checkPermission(SecureAction.OP_NEW_NE_CONTAINER_SAN)).thenReturn(true);
    }

    @Test
    public void testIsActionAllowed_nodeContainerRoot() throws Exception {
        final boolean actionAllowed = action.isActionAllowed(new IManagedObject[]{container});
        assertTrue(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_nodeNeContainer() throws Exception {
        final boolean actionAllowed = action.isActionAllowed(new IManagedObject[]{container});
        assertTrue(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_false_not_supported_container() throws Exception {
        ISystemContainer system = buildSystemContainer(1);
        final boolean actionAllowed = action.isActionAllowed(new IManagedObject[]{system});
        assertFalse(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_false_not_single_selection() throws Exception {
        final boolean actionAllowed = action.isActionAllowed(new IManagedObject[]{container, buildContainer(3)});
        assertFalse(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_false_no_permission() throws Exception {
        when(secureActionValidation.checkPermission(SecureAction.OP_NEW_NE_CONTAINER_SAN)).thenReturn(false);
        final boolean actionAllowed = action.isActionAllowed(new IManagedObject[]{container});
        assertFalse(actionAllowed);
    }

    @Test
    public void testEventActionPerformed() throws Exception {
        action.eventActionPerformed(new IManagedObject[]{container});
        verify(dialogHandler, times(1)).showNewNeContainerDialog(container);
    }

    @Test
    public void testEventActionPerformed_no_data() throws Exception {
        action.eventActionPerformed(new IManagedObject[]{});
        verify(dialogHandler, never()).showNewNeContainerDialog(container);
    }

    @Test
    public void testGetActionId() throws Exception {
        assertThat(action.getActionId(), is(ActionNewContainerDelegate.class.getName()));
    }

    @Test
    public void testGetMenuName() throws Exception {
        assertThat(action.getMenuName(), is(TreeTableLabels.NEW_CONTAINER));
    }
}