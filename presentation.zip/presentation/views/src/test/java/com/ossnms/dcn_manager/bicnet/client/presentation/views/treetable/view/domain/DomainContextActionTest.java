package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.domain;

import com.ossnms.bicnet.bcb.model.common.GatewayRole;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.tools.jfx.components.JfxCheckBoxMenuItem;
import com.ossnms.tools.jfx.components.JfxMenu;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.swing.JMenuItem;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.google.common.collect.Lists.newArrayList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DomainContextActionTest extends TestsHelper {

    @Mock private TreeTableViewModel model;

    private DomainContextAction action;

    @Before public void setUp() throws Exception {
        action = new DomainContextAction(commonServices, repositoryManager);

        final IAS domain = buildDomain(ID_1);
        domain.setDiscoveryPermited(true);
        when(domainRepository.get(ID_1)).thenReturn(Optional.of(domain));
    }

    @Test public void createAction_for_multi_selection() throws Exception {
        final Collection<Node> nodeDomains = newArrayList(buildNodeDomain(null, ID_1), buildNodeDomain(null, ID_2));
        final Collection<JMenuItem> action = this.action.createAction(nodeDomains, model);

        assertThat(action.isEmpty(), is(true));
    }

    @Test public void createAction() throws Exception {
        final FullNeData fullNeData1 = buildFullNeData(ID_1, ID_3, "");
        final FullNeData fullNeData2 = buildFullNeData(ID_2, ID_3, "");
        final FullNeData fullNeData3 = buildFullNeData(ID_3, ID_3, "");

        fullNeData1.getNe().setGatewayRole(GatewayRole.PRIMARY);
        fullNeData2.getNe().setGatewayRole(GatewayRole.PRIMARY);
        fullNeData3.getNe().setGatewayRole(GatewayRole.NONE);

        when(neRepository.get(newArrayList(ID_1, ID_2, ID_3))).thenReturn(newArrayList(fullNeData1, fullNeData2, fullNeData3));

        final NodeDomain nodeDomain = buildNodeDomain(null, ID_1);
        nodeDomain.setSelectedGneId(Optional.of(ID_2));
        nodeDomain.addChild(buildNodeNe(nodeDomain, ID_1));
        nodeDomain.addChild(buildNodeNe(nodeDomain, ID_2));
        nodeDomain.addChild(buildNodeNe(nodeDomain, ID_3));

        final NodeNe notVisibleNE = buildNodeNe(nodeDomain, ID_4);
        notVisibleNE.getValue().setVisible(false);
        nodeDomain.addChild(notVisibleNE);

        final Collection<Node> nodeDomains = newArrayList(nodeDomain);
        final Collection<JMenuItem> menuItems = action.createAction(nodeDomains, model);

        assertDiscoveryPermittedMenu(fullNeData1, fullNeData2, menuItems);
        assertSortByConnectivityMenu(fullNeData1, fullNeData2, fullNeData3, notVisibleNE, menuItems);
    }

    private void assertDiscoveryPermittedMenu(FullNeData fullNeData1, FullNeData fullNeData2,
            Collection<JMenuItem> menuItems) {
        final Optional<JfxCheckBoxMenuItem> menuDiscoveryPermitted = menuItems.stream()
                .filter(JfxCheckBoxMenuItem.class::isInstance)
                .map(JfxCheckBoxMenuItem.class::cast)
                .findAny();

        assertThat(menuDiscoveryPermitted.isPresent(), is(true));
        menuDiscoveryPermitted.ifPresent( menu ->
                assertThat("DiscoveryPermitted menu is not selected", menu.isSelected(), is(true)) );
    }

    private void assertSortByConnectivityMenu(FullNeData fullNeData1, FullNeData fullNeData2, FullNeData fullNeData3, NodeNe notVisibleNE,
            Collection<JMenuItem> menuItems) {
        final Optional<JfxMenu> menuSortByConnectivity = menuItems.stream()
                .filter(menu -> TreeTableLabels.SORT_BY_CONNECTIVITY.toString().equals(menu.getText()))
                .map(JfxMenu.class::cast).findAny();

        assertThat(menuSortByConnectivity.isPresent(), is(true));

        menuSortByConnectivity.ifPresent(menu -> {
            final List<String> menuNames = Stream.of(menu.getMenuComponents())
                    .filter(JfxCheckBoxMenuItem.class::isInstance)
                    .map(JfxCheckBoxMenuItem.class::cast)
                    .map(JfxCheckBoxMenuItem::getText)
                    .collect(Collectors.toList());

            // Assert sub-menus names
            assertThat("The sort by connectivity doesn't have all items", menuNames,
                    containsInAnyOrder(fullNeData1.getIdName(), fullNeData2.getIdName()));

            // must not contains the not visible NE.
            assertThat("The sort by connectivity is printing the invisible NEs", menuNames,
                    not(containsInAnyOrder(notVisibleNE.getValue().getName())));

            // must not contains NEs that is not a GNE.
            assertThat("The sort by connectivity is printing  not GNE NEs", menuNames,
                    not(containsInAnyOrder(fullNeData3.getIdName())));

            final List<JfxCheckBoxMenuItem> items = Stream.of(menu.getMenuComponents())
                    .filter(JfxCheckBoxMenuItem.class::isInstance)
                    .map(JfxCheckBoxMenuItem.class::cast)
                    .filter(JfxCheckBoxMenuItem::isSelected)
                    .collect(Collectors.toList());

            // Assert selected NE
            assertThat("The sort be connectivity has more than one selected item", items.size(), is(1));

            final Optional<JfxCheckBoxMenuItem> item = items.stream().findFirst();
            assertThat("The sort be connectivity has no selection", item.isPresent(), is(true));

            item.ifPresent(selectedItem -> assertThat("The sort be connectivity has a invalid selection",
                    fullNeData2.getIdName().equals(selectedItem.getText()), is(true)));
        });
    }
}
