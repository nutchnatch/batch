package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.swing.tree.TreeNode;
import java.util.Enumeration;
import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;

public class NodeContainerTest {

    private final NodeContainerRoot nodeRoot;

    private final IGenericContainer containerItem;
    private NodeContainer nodeContainer;

    private static final String NODE1_NAME = "NODE1";
    private static final String NODE2_NAME = "NODE2";
    private static final String NODE3_NAME = "NODE3";
    private static final String NE1_NAME = "NE1";

    public NodeContainerTest() {
        nodeRoot = new NodeContainerRoot("TNMS");
        containerItem = createContainerItem();
    }

    @Before
    public void setup() {
        nodeContainer = new NodeContainer(containerItem.getId(), nodeRoot);
    }

    @Test
    public void testCreate() {
        NodeContainer container = new NodeContainer(2, nodeContainer);
        container.getValue().setName(NODE1_NAME);

        assertThat(container.getId(), is(2));
        assertThat(container.getColumns().valueOf(ColumnId.TYPE).get().getValue(), is("NE Container"));
    }

    @Test
    public void testFindChildPresent() {
        Node container = new NodeContainer(2, nodeContainer);
        container.getValue().setName(NODE1_NAME);
        nodeContainer.addChild(container);
        
        final Node node = nodeContainer.findChild(2).get();
        
        assertThat(node.getId(), is(2));
    }
    
    @Test
    public void testFindChildNotPresent() {
        final Optional<Node> node = nodeContainer.findChild(3);
        
        assertFalse(node.isPresent());
    }
    
    @Test
    public void testRemoveExistChild() {
        final Node child = new NodeNe(1, nodeContainer);
        child.getValue().setName(NE1_NAME);
        nodeContainer.addChild(child);
        
        assertTrue(nodeContainer.removeChild(child));
    }
    
    @Test
    public void testRemoveNotExistChild() {
        final Node child1 = new NodeNe(1, nodeContainer);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeNe(2, nodeContainer);
        child2.getValue().setName(NODE2_NAME);

        nodeContainer.addChild(child1);
        
        assertFalse(nodeContainer.removeChild(child2));
    }
    
    @Test
    public void testGetChildIndex() {
        final Node child1 = new NodeNe(1, nodeContainer);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeNe(2, nodeContainer);
        child2.getValue().setName(NODE2_NAME);
        final Node child3 = new NodeNe(3, nodeContainer);
        child3.getValue().setName(NODE3_NAME);
        
        nodeContainer.addChild(child1);
        nodeContainer.addChild(child2);
        
        assertThat(nodeContainer.getIndex(child1), is(0));
        assertThat(nodeContainer.getIndex(child2), is(1));
        assertThat(nodeContainer.getIndex(child3), is(-1));
    }
    
    @Test
    public void testGetAllowsChildren() {
        assertTrue(nodeContainer.getAllowsChildren());
    }
    
    @Test
    public void testIsLeaf() {
        assertTrue(nodeContainer.isLeaf());
    }
    
    @Test
    public void testIsLeafFalse() {
        final Node child1 = new NodeNe(1, nodeContainer);
        child1.getValue().setName(NODE1_NAME);
        nodeContainer.addChild(child1);
        
        assertFalse(nodeContainer.isLeaf());
    }
    
    @Test
    public void testGetColumnByPosition() {
        assertThat(nodeContainer, is(nodeContainer.getColumnByPosition(0)));
        assertThat(nodeContainer, is(nodeContainer.getColumnByPosition(0)));
    }
    
    @Test(expected=UnsupportedOperationException.class)
    public void testGetColumnByWrongPosition() {
        nodeContainer.getColumnByPosition(100);
    }
        
    @Test
    public void testGets() {
        Assert.assertNotNull(nodeContainer.getColumns());
        Assert.assertNotNull(nodeContainer.getValue());
                
        assertThat(nodeContainer.getId(), is(1));
    }
    
    @Test
    public void testChildren() {
        final Node child1 = new NodeNe(1, nodeContainer);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeNe(2, nodeContainer);
        child2.getValue().setName(NODE2_NAME);
        
        nodeContainer.addChild(child1);
        nodeContainer.addChild(child2);
        
        final Enumeration<TreeNode> nodes = nodeContainer.children();

        int totalNodes = 0;
        
        while(nodes.hasMoreElements()) {
            nodes.nextElement();
            totalNodes++;
        }
        
        assertThat(nodeContainer.getChildCount(), is(totalNodes));
    }
    
    @Test
    public void testToString() {
        assertThat(nodeContainer.toString(), is(nodeContainer.getValue().getName()));
    }
    
    @Test
    public void testHashCode() {
        
        final int hash1 = new NodeContainer(1, nodeRoot).hashCode();
        final int hash2 = new NodeContainer(2, nodeRoot).hashCode();
        final int hash3 = new NodeContainer(1, new NodeRoot(2, "Root")).hashCode();
        
        assertThat(nodeContainer.hashCode(), is(hash1));
        assertThat(nodeContainer.hashCode(), not(is(hash2)));
        assertThat(nodeContainer.hashCode(), not(is(hash3)));
    }
    
    @Test
    public void testEquals() {
        final NodeContainer container1 = new NodeContainer(1, nodeRoot);
        final NodeContainer container2 = new NodeContainer(2, nodeRoot);
        final NodeContainer container3 = new NodeContainer(1, new NodeRoot(2, "Root"));
        
        assertTrue(nodeContainer.equals(container1));
        
        assertFalse(nodeContainer.equals(container2));
        assertFalse(nodeContainer.equals(container3));
        assertFalse(nodeContainer.equals(new Object()));
    }
    
    private IGenericContainer createContainerItem() {
        final IGenericContainer containerItem = new GenericContainerItem();
        containerItem.setId(1);
        containerItem.setIdName("Container_IdName");
        return containerItem;
    }
}

