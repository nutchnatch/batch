package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.mediator;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeHandler;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ChannelRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.MediatorRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;

import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TreeTableMediatorsNodeHandlerTest {
    private static final int NE_ID = 3;
    private static final int MEDIATOR_ID = 1;
    private static final int CHANNEL_ID = 2;

    private NodeHandler nodeHandler;

    private TreeTableMediatorsDocument document;

    private NodeMediator nodeMediator;
    private NodeChannel nodeChannel;
    private NodeNe nodeNe;

    private INE ne;
    private IEM em;
    private IMediator mediator;
    private FullMediatorData fullMediatorData;

    private RepositoryManager repositoryManager;
    private MediatorRepository mediatorRepository;
    private ChannelRepository channelRepository;
    private NeRepository neRepository;
    private FullChannelData fullChannelData;

    @Before
    public void setup() throws RepositoryException {
        document = mock(TreeTableMediatorsDocument.class);

        nodeMediator = mock(NodeMediator.class);
        nodeChannel = mock(NodeChannel.class);
        nodeNe = mock(NodeNe.class);

        ne = mock(INE.class);
        em = mock(IEM.class);
        mediator = mock(IMediator.class);

        repositoryManager = mock(RepositoryManager.class);
        mediatorRepository = mock(MediatorRepository.class);
        fullMediatorData = new FullMediatorData(mediator, new MediatorInfo(mediator.getId()));
        fullChannelData = new FullChannelData(em, new ChannelInfo(em.getId()));
        channelRepository = mock(ChannelRepository.class);
        neRepository = mock(NeRepository.class);

        when(document.getRepositoryManager()).thenReturn(repositoryManager);
        when(repositoryManager.getMediatorRepository()).thenReturn(mediatorRepository);
        when(repositoryManager.getChannelRepository()).thenReturn(channelRepository);
        when(repositoryManager.getNeRepository()).thenReturn(neRepository);

        when(mediatorRepository.get(ImmutableList.of(MEDIATOR_ID))).thenReturn(ImmutableList.of(fullMediatorData));
        when(channelRepository.get(ImmutableList.of(CHANNEL_ID))).thenReturn(ImmutableList.of(fullChannelData));
        FullNeData element = new FullNeData(ne, new NeInfo(ne.getId()), null);
        when(neRepository.get(ImmutableList.of(NE_ID))).thenReturn(ImmutableList.of(element));
        
        when(mediator.getId()).thenReturn(MEDIATOR_ID);
        when(em.getId()).thenReturn(CHANNEL_ID);
        when(ne.getId()).thenReturn(NE_ID);
        
        when(nodeMediator.getId()).thenReturn(MEDIATOR_ID);
        when(nodeChannel.getId()).thenReturn(CHANNEL_ID);
        when(nodeNe.getId()).thenReturn(NE_ID);
                
        nodeHandler = new TreeTableMediatorsNodeHandler(document);
    }
    
    @Test
    public void testTransformOnlyFirstMatchNodeType_with_all_types() throws RepositoryException {
        final Iterable<Node> nodes = ImmutableList.<Node>of(nodeNe, nodeChannel, nodeMediator);
        
        final Collection<IManagedObject> manageObjects = ImmutableList.copyOf(nodeHandler.transformOnlyFirstMatchNodeType(nodes));
        
        assertThat(manageObjects.size(), CoreMatchers.is(1));
        assertThat(manageObjects.contains(mediator), CoreMatchers.is(true));
    }
    
    @Test
    public void testTransformOnlyFirstMatchNodeType_only_channels_nes() throws RepositoryException {
        final Iterable<Node> nodes = ImmutableList.<Node>of(nodeNe, nodeChannel);
        
        final Collection<IManagedObject> manageObjects = ImmutableList.copyOf(nodeHandler.transformOnlyFirstMatchNodeType(nodes));
        
        assertThat(manageObjects.size(), CoreMatchers.is(1));        
        assertThat(manageObjects.contains(em), CoreMatchers.is(true));
    }
    
    @Test
    public void testTransformOnlyFirstMatchNodeType_only_nes() throws RepositoryException {
        final Iterable<Node> nodes = ImmutableList.<Node>of(nodeNe);
        
        final Collection<IManagedObject> manageObjects = ImmutableList.copyOf(nodeHandler.transformOnlyFirstMatchNodeType(nodes));
        
        assertThat(manageObjects.size(), CoreMatchers.is(1));
        assertThat(manageObjects.contains(ne), CoreMatchers.is(true));
    }
    
    @Test
    public void testTransformAllKnownNodeTypes() throws RepositoryException {
        final Iterable<Node> nodes = ImmutableList.<Node>of(nodeNe, nodeChannel, nodeMediator);
        
        final Collection<IManagedObject> manageObjects = ImmutableList.copyOf(nodeHandler.transformAllKnownNodeTypes(nodes));
        
        assertThat(manageObjects.size(), CoreMatchers.is(3));
        assertThat(manageObjects.contains(ne), CoreMatchers.is(true));
        assertThat(manageObjects.contains(em), CoreMatchers.is(true));
        assertThat(manageObjects.contains(mediator), CoreMatchers.is(true));
    }
}
