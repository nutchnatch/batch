package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.container;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainerRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeHandler;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;

import static com.google.common.collect.ImmutableList.copyOf;
import static com.ossnms.dcn_manager.bicnet.client.api.Containers.ROOT_CONTAINER_ID;
import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TreeTableContainerNodeHandlerTest extends TestsHelper {

    @Mock private NodeHandler nodeHandler;
    @Mock private NodeContainerRoot nodeContainerRoot;
    @Mock private NodeContainer nodeContainer;
    @Mock private NodeSystemContainer nodeSystemContainer;
    @Mock private NodeNe nodeNe;

    private INE ne;
    private IGenericContainer container;
    private IGenericContainer rootContainer;
    private ISystemContainer sysContainer;

    @Before public void setUp() throws RepositoryException {
        ne = buildFullNeData(ID_1, ID_1, "").getNe();
        rootContainer = buildContainer(ROOT_CONTAINER_ID);
        container = buildContainer(ID_1);
        sysContainer = buildSystemContainer(ID_2);

        when(containerRepository.get(asList(ID_1))).thenReturn(asList(container));
        when(containerRepository.get(asList(ROOT_CONTAINER_ID))).thenReturn(asList(rootContainer));
        when(systemContainerRepository.get(asList(ID_2))).thenReturn(asList(sysContainer));

        FullNeData element = new FullNeData(ne, new NeInfo(ne.getId()), null);
        when(neRepository.get(asList(ID_1))).thenReturn(asList(element));

        when(nodeContainer.getId()).thenReturn(ID_1);
        when(nodeSystemContainer.getId()).thenReturn(ID_2);
        when(nodeNe.getId()).thenReturn(ID_1);

        nodeHandler = new TreeTableContainersNodeHandler(repositoryManager);
    }

    @Test public void testTransformOnlyFirstMatchNodeType_with_all_types() throws RepositoryException {
        final Iterable<Node> nodes = asList(nodeNe, nodeContainer, nodeSystemContainer, nodeContainerRoot);

        final Collection<IManagedObject> manageObjects = copyOf(nodeHandler.transformOnlyFirstMatchNodeType(nodes));

        assertThat(manageObjects, contains(rootContainer));
    }

    @Test public void testTransformOnlyFirstMatchNodeType_only_nes() throws RepositoryException {
        final Iterable<Node> nodes = asList(nodeNe);

        final Collection<IManagedObject> manageObjects = copyOf(nodeHandler.transformOnlyFirstMatchNodeType(nodes));

        assertThat(manageObjects, contains(ne));
    }

    @Test public void testTransformAllKnownNodeTypes() throws RepositoryException {
        final Iterable<Node> nodes = asList(nodeNe, nodeContainer, nodeSystemContainer, nodeContainerRoot);

        final Collection<IManagedObject> manageObjects = copyOf(nodeHandler.transformAllKnownNodeTypes(nodes));

        assertThat(manageObjects, containsInAnyOrder(ne, container, sysContainer, rootContainer));
    }

    @Test public void shouldTransformRootContainer() throws Exception {
        final Iterable<Node> nodes = asList(nodeContainerRoot);

        final Collection<IManagedObject> manageObjects = copyOf(nodeHandler.transformOnlyFirstMatchNodeType(nodes));

        assertThat(manageObjects, contains(rootContainer));
    }
}
