package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import javax.swing.ImageIcon;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NAME;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NUMBER_NES;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_STATE;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_TYPE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NodeChannelTest {
    private final NodeRoot nodeRoot;
    private IconManager iconManager;
    
    private final IEM emBcb;
    private final FullChannelData fullChannelData;
    private NodeChannel nodeChannel;
    private static final String NODE1_NAME = "NE1";
    private static final String NODE2_NAME = "NE2";

    
    public NodeChannelTest() {
        nodeRoot = new NodeRoot(1, "Root");
        emBcb = createEm();
        fullChannelData = new FullChannelData(emBcb, new ChannelInfo(emBcb.getId()));
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);
    }

    @Before
    public void setup() {
        final Optional<ImageIcon> imaOptional = Optional.empty();
        iconManager = mock(IconManager.class);
        when(iconManager.findNetworkIcon(Matchers.any(IEM.class), Matchers.anyInt())).thenReturn(imaOptional);
        
        nodeChannel = new NodeChannel(emBcb.getId(), nodeRoot);
        nodeChannel.getValue().setToogleButtonChecked(true);
    }

    @Test public void testCheckBoxToolTip() throws Exception {
        nodeChannel.getValue().setToogleButtonEnable(false);
        nodeChannel.getValue().setToogleButtonChecked(true);

        final String toolTip = nodeChannel.getToolTip(ToolTipType.CHECKBOX);

        assertThat(toolTip, is(TreeTableLabels.CHANNEL_CHECKBOX_TOOLTIP.toString()));
    }

    @Test public void testNodeToolTip() throws Exception {
        nodeChannel.getValue().setToogleButtonEnable(true);
        nodeChannel.getValue().setToogleButtonChecked(false);

        nodeChannel.getValue().setName("channel_name");
        nodeChannel.getColumns().setValue(ColumnId.TYPE, "channel_type");
        nodeChannel.getColumns().setValue(ColumnId.STATE, "channel_state");

        final NodeNe nodeNe1 = new NodeNe(1, nodeChannel);
        final NodeNe nodeNe2 = new NodeNe(2, nodeChannel);
        final NodeNe nodeNe3 = new NodeNe(3, nodeChannel);

        nodeChannel.addChild(nodeNe1);
        nodeChannel.addChild(nodeNe2);
        nodeChannel.addChild(nodeNe3);

        final String toolTip = nodeChannel.getToolTip(ToolTipType.NODE);

        assertThat(toolTip, containsString("<b>" + nodeChannel.delimiter(COLUMN_NAME) + "</b>channel_name"));
        assertThat(toolTip, containsString("<b>" + nodeChannel.delimiter(COLUMN_TYPE) + "</b>channel_type"));
        assertThat(toolTip, containsString("<b>" + nodeChannel.delimiter(COLUMN_STATE) + "</b>channel_state"));
        assertThat(toolTip, containsString("<b>" + nodeChannel.delimiter(COLUMN_NUMBER_NES) + "</b>3"));
    }

    @Test
    public void testGetAllowsChildren() {
        assertTrue(nodeChannel.getAllowsChildren());
    }
    
    @Test
    public void testToString() {
        assertThat(nodeChannel.toString(), is(nodeChannel.getValue().getName()));
    }
    
    @Test
    public void testHashCode() {
        final int hash1 = new NodeChannel(1, nodeRoot).hashCode();
        final int hash2 = new NodeChannel(2, nodeRoot).hashCode();
        final int hash3 = new NodeChannel(1, new NodeRoot(2, "Root")).hashCode();
        
        assertThat(nodeChannel.hashCode(), is(hash1));
        assertThat(nodeChannel.hashCode(), not(is(hash2)));
        assertThat(nodeChannel.hashCode(), not(is(hash3)));
    }

    @Test public void testHasChildrenActivated_all_children_inactive() throws Exception {
        NodeNe ne1 = new NodeNe(1, nodeChannel);
        ne1.getValue().setName(NODE1_NAME);
        NodeNe ne2 = new NodeNe(2, nodeChannel);
        ne2.getValue().setName(NODE2_NAME);

        nodeChannel.addChild(ne1);
        nodeChannel.addChild(ne2);

        assertFalse(nodeChannel.hasChildrenActivated());
    }

    @Test public void testHasChildrenActivated_no_child() throws Exception {
        assertFalse(nodeChannel.hasChildrenActivated());
    }

    @Test public void testCheckBox_all_failed() throws Exception {
        NodeNe ne1 = new NodeNe(1, nodeChannel);
        ne1.getValue().setName(NODE1_NAME);
        ne1.getValue().setToogleButtonChecked(true);
        ne1.getValue().setActualActivationState(GuiActualActivationState.FAILED);

        NodeNe ne2 = new NodeNe(2, nodeChannel);
        ne2.getValue().setName(NODE2_NAME);
        ne2.getValue().setToogleButtonChecked(true);
        ne2.getValue().setActualActivationState(GuiActualActivationState.FAILED);

        nodeChannel.getValue().setActualActivationState(GuiActualActivationState.FAILED);

        nodeChannel.addChild(ne1);
        nodeChannel.addChild(ne2);
        nodeChannel.tryUpdateNodeParentToggleButton(true);

        assertTrue(nodeChannel.getValue().isToogleButtonEnable());
    }

    @Test public void testHasChildrenActivated_all_children_active() throws Exception {
        NodeNe ne1 = new NodeNe(1, nodeChannel);
        ne1.getValue().setName(NODE1_NAME);
        ne1.getValue().setToogleButtonChecked(true);

        NodeNe ne2 = new NodeNe(2, nodeChannel);
        ne2.getValue().setName(NODE2_NAME);
        ne2.getValue().setToogleButtonChecked(true);

        nodeChannel.addChild(ne1);
        nodeChannel.addChild(ne2);

        assertFalse(nodeChannel.hasChildrenActivated());
    }

    @Test public void testHasChildrenActivated_child_active() throws Exception {
        NodeNe ne1 = new NodeNe(1, nodeChannel);
        ne1.getValue().setToogleButtonChecked(true);
        ne1.getValue().setActualActivationState(GuiActualActivationState.ACTIVE);

        nodeChannel.addChild(ne1);

        assertTrue(nodeChannel.hasChildrenActivated());
    }

    @Test
    public void testEquals() {
        final NodeChannel node1 = new NodeChannel(1, nodeRoot);
        final NodeChannel node2 = new NodeChannel(2, nodeRoot);
        final NodeChannel node3 = new NodeChannel(1, new NodeRoot(2, "Root"));
        
        assertTrue(nodeChannel.equals(node1));
        
        assertFalse(nodeChannel.equals(node2));
        assertFalse(nodeChannel.equals(node3));
        assertFalse(nodeChannel.equals(null));
        assertFalse(nodeChannel.equals(nodeRoot));
    }
    
    private IEM createEm() {
        final IEM em = new EMItem();
        
        em.setId(1);
        em.setActivation(EnableSwitch.DISABLED);
        em.setCommunicationState(CommunicationState.DISCONNECTED);
        em.setIdName("NE_IdName");
        em.setDisplayAddress("127.0.0.1");
        em.setDisplayState("state");
        em.setAdditionalInfo("additionalInfo");
        em.setEmType("EM-GM");
        
        return em;
    }
}
