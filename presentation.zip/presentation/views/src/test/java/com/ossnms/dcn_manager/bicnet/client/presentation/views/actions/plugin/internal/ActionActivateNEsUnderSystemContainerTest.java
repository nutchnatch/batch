package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobNEsActivate;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateNEs.ActivateNEs;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_ALL_NES_SAN;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_NES_SAN;
import static java.util.stream.Collectors.toList;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionActivateNEsUnderSystemContainerTest extends TestsHelper {

    private ActionActivateNEsUnderSystemContainer actionActivateNEsUnderSystemContainer;

    private ISystemContainer systemContainer;
    private FullNeData fullNeDataOk;

    @Before public void setUp() throws Exception {
        this.actionActivateNEsUnderSystemContainer = new ActionActivateNEsUnderSystemContainer(repositoryManager, commonServices);

        systemContainer = buildSystemContainer(ID_3);

        fullNeDataOk = buildFullNeData(ID_1, ID_2, "");
        fullNeDataOk.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeDataOk.getNe().setAssociatedSystemContainerId(ID_3);
        fullNeDataOk.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        FullNeData fullNeDataActive = buildFullNeData(ID_2, ID_2, "");
        fullNeDataActive.getNe().setActivation(EnableSwitch.ENABLED);
        fullNeDataActive.getNe().setAssociatedSystemContainerId(ID_3);
        fullNeDataActive.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        FullNeData fullNeDataDeactivating = buildFullNeData(ID_3, ID_2, "");
        fullNeDataDeactivating.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeDataDeactivating.getNe().setAssociatedSystemContainerId(ID_3);
        fullNeDataDeactivating.getInfo().setGuiActualActivationState(GuiActualActivationState.DEACTIVATING);

        when(neSearchable.findBySystemContainerId(ID_3))
                .thenReturn(ImmutableList.of(fullNeDataActive, fullNeDataOk, fullNeDataDeactivating));
        withPermissions(OP_ACTIVATE_NES_SAN, fullNeDataOk.getNe());
    }

    private <T extends IManagedObjectId> T[] withPermissions(SecureAction action, T... objectsToCheck) {
        when(secureActionValidation.checkPermission(action, objectsToCheck)).thenReturn(true);
        when(secureActionValidation.checkPermission(action)).thenReturn(true);
        return objectsToCheck;
    }

    @Test public void testGetNEsInactive() throws Exception {
        Collection<INEId> nesInactive = actionActivateNEsUnderSystemContainer.inactiveNEs(systemContainer)
                .collect(toList());

        assertThat(nesInactive.size(), is(1));
        assertThat(nesInactive.contains(fullNeDataOk.getNe().getNEId()), is(true));
        verify(loggerManager, never()).error(any(String.class), any(String.class));
    }

    @Test public void testIsPluginActionAllowed() throws Exception {

        boolean pluginActionAllowed = actionActivateNEsUnderSystemContainer.isPluginActionAllowed(
                withPermissions(OP_ACTIVATE_ALL_NES_SAN, systemContainer));
        
        assertThat(pluginActionAllowed, is(true));
        verify(loggerManager, never()).error(any(String.class), any(String.class));
    }

    @Test public void testEventPluginActionPerformed() throws Exception {
        actionActivateNEsUnderSystemContainer.eventPluginActionPerformed(
                withPermissions(OP_ACTIVATE_ALL_NES_SAN, systemContainer));

        verify(loggerManager, never()).error(any(String.class), any(String.class));
    }

    @Test public void testInternalWorker() throws Exception {
        ActivateNEs activateNEs = actionActivateNEsUnderSystemContainer.new ActivateNEs(
                ImmutableList.of(systemContainer));

        boolean executed = activateNEs.doInBackground();
        activateNEs.done();

        assertThat(executed, is(true));
        verify(dcnPluginHelper, times(1)).queueJob(any(JobNEsActivate.class));
    }
}
