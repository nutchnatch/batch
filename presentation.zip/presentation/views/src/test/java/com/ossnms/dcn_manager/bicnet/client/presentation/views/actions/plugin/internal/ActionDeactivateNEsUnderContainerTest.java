package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ActionDeactivateNEsUnderContainerTest extends TestsHelper {

    private ActionDeactivateNEsUnderContainer action;
    private IGenericContainer container;

    @Before
    public void setUp() throws Exception {
        action = new ActionDeactivateNEsUnderContainer(repositoryManager, commonServices);
        container = buildContainer(ID_1);

        final FullNeData fullNeData = buildFullNeData(ID_2, ID_3, "");
        fullNeData.getNe().setActivation(EnableSwitch.ENABLED);

        when(neContainerAssignmentRepository.getNeIdList(container.getId())).thenReturn(Collections.singletonList(ID_2));
        when(neRepository.get(Collections.singletonList(ID_2))).thenReturn(Collections.singletonList(fullNeData));

        when(secureActionValidation.checkPermission(SecureAction.OP_DEACTIVATE_ALL_NES_SAN)).thenReturn(true);
        when(secureActionValidation.checkPermission(SecureAction.OP_DEACTIVATE_NES_SAN, fullNeData.getNe())).thenReturn(true);
    }

    @Test public void testOperationAllowed() throws Exception {
        final boolean actionAllowed = action.isPluginActionAllowed(new IGenericContainer[] { container });

        assertTrue(actionAllowed);

        verify(neContainerAssignmentRepository, atLeastOnce()).getNeIdList(container.getId());
        verify(neRepository, atLeastOnce()).get(Collections.singletonList(ID_2));
    }

    @Test public void testOperationAllowed_no_permission() throws Exception {
        when(secureActionValidation.checkPermission(SecureAction.OP_DEACTIVATE_ALL_NES_SAN)).thenReturn(false);

        final boolean actionAllowed = action.isPluginActionAllowed(new IGenericContainer[] { container });

        assertFalse(actionAllowed);

        verify(neContainerAssignmentRepository, never()).getNeIdList(container.getId());
        verify(neRepository, never()).get(Collections.singletonList(ID_2));
    }

    @Test public void testOperationAllowed_no_children_nes() throws Exception {
        when(neContainerAssignmentRepository.getNeIdList(container.getId())).thenReturn(Collections.emptyList());

        final boolean actionAllowed = action.isPluginActionAllowed(new IGenericContainer[] { container });

        assertFalse(actionAllowed);

        verify(neContainerAssignmentRepository, atLeastOnce()).getNeIdList(container.getId());
        verify(secureActionValidation, atLeastOnce()).checkPermission(SecureAction.OP_DEACTIVATE_ALL_NES_SAN);
    }
}