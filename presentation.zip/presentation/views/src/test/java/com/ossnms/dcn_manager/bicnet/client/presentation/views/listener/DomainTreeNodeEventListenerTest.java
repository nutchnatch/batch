package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainRoot;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DomainTreeNodeEventListenerTest extends TestsHelper {
    @Mock private ModelUpdater modelUpdater;
    @Mock private GraphicalRepresentationBuilder<IAS> graphicalRepresentationBuilder;
    @Mock private NodeDomainRoot domainRoot;

    private DomainTreeNodeEventListener domainTreeNodeEventListener;

    @Before public void setUp() throws Exception {
        domainTreeNodeEventListener = new DomainTreeNodeEventListener(modelUpdater, commonServices,
                repositoryManager, graphicalRepresentationBuilder);

        domainRoot = new NodeDomainRoot("Root");

        when(modelUpdater.getNodeRoot()).thenReturn(domainRoot);
        when(graphicalRepresentationBuilder.getIconManager()).thenReturn(new IconManager());
        when(domainSearchable.findByIdName(any())).thenReturn(Optional.empty());
    }

    @Test public void testRemove() throws Exception {
        IAS domain = buildDomain(ID_1);
        NodeDomain nodeDomain = buildNodeDomain(domainRoot, ID_1);
        domainRoot.addChild(nodeDomain);

        domainTreeNodeEventListener.remove(domain);

        assertTrue(nodeDomain.getAllChildren().isEmpty());
        verify(modelUpdater, atLeastOnce()).removeNode(nodeDomain);
    }

    @Test public void testAdd() throws Exception {
        IAS domain = buildDomain(ID_1);

        domainTreeNodeEventListener.add(domain);
        assertThat(domainRoot.getAllChildren().size(), is(1));

        verify(modelUpdater, atLeastOnce()).insertNode(any(NodeDomain.class));
    }

    @Test public void testUpdate() throws Exception {
        IAS domain = buildDomain(ID_1);
        domain.setIdName("new_name");

        NodeDomain nodeDomain = buildNodeDomain(domainRoot, ID_1);
        domainRoot.addChild(nodeDomain);

        domainTreeNodeEventListener.update(domain);

        assertThat(domainRoot.getAllChildren().size(), is(1));
        assertThat(nodeDomain.getValue().getName(), is("new_name"));
        verify(modelUpdater, atLeastOnce()).applyStructureChanged(any(NodeDomain.class));
    }
}