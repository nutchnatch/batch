package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import javax.swing.ImageIcon;
import javax.swing.tree.TreeNode;
import java.util.Enumeration;
import java.util.Optional;

import static java.util.Comparator.comparing;
import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NodeDomainTest {

    private final NodeRoot nodeRoot;

    private final IAS domainBcb;        
    private NodeDomain nodeDomain;
    private static final String NODE1_NAME = "NODE1";
    private static final String NODE2_NAME = "NODE2";
    private static final String NODE3_NAME = "NODE3";
    
    public NodeDomainTest() {
        nodeRoot = new NodeRoot(1, "Root");
        domainBcb = createBcbMediator();
    }

    @Before
    public void setup() {
        final Optional<ImageIcon> imaOptional = Optional.empty();
        IconManager iconManager = mock(IconManager.class);
        when(iconManager.findNetworkIcon(Matchers.any(IMediator.class), Matchers.anyInt())).thenReturn(imaOptional);
        when(iconManager.findNetworkIcon(Matchers.any(IEM.class), Matchers.anyInt())).thenReturn(imaOptional);
        
        nodeDomain = new NodeDomain(domainBcb.getId(), nodeRoot, comparing(Object::toString, String::compareToIgnoreCase));
    }

    @Test
    public void testFindChildPresent() {
        final Node child1 = new NodeNe(1, nodeDomain);
        child1.getValue().setName(NODE1_NAME);
        nodeDomain.addChild(child1);
        
        final Node node = nodeDomain.findChild(1).get();
        
        assertThat(node.getId(), is(1));
    }
    
    @Test
    public void testFindChildNotPresent() {
        final Optional<Node> node = nodeDomain.findChild(1);
        
        assertFalse(node.isPresent());
    }
    
    @Test
    public void testRemoveExistChild() {
        final Node child = new NodeNe(1, nodeDomain);
        child.getValue().setName(NODE1_NAME);

        nodeDomain.addChild(child);
        
        assertTrue(nodeDomain.removeChild(child));
    }
    
    @Test
    public void testRemoveNotExistChild() {
        final Node child1 = new NodeNe(1, nodeDomain);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeNe(2, nodeDomain);
        child2.getValue().setName(NODE2_NAME);
        
        nodeDomain.addChild(child1);
        
        assertFalse(nodeDomain.removeChild(child2));
    }
    
    @Test
    public void testGetChildIndex() {
        final Node child1 = new NodeNe(1, nodeDomain);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeNe(2, nodeDomain);
        child2.getValue().setName(NODE2_NAME);
        final Node child3 = new NodeNe(3, nodeDomain);
        child3.getValue().setName(NODE3_NAME);
        
        nodeDomain.addChild(child1);
        nodeDomain.addChild(child2);
        
        assertThat(nodeDomain.getIndex(child1), is(0));
        assertThat(nodeDomain.getIndex(child2), is(1));
        assertThat(nodeDomain.getIndex(child3), is(-1));
    }
    
    @Test
    public void testGetAllowsChildren() {
        assertTrue(nodeDomain.getAllowsChildren());
    }
    
    @Test
    public void testIsLeaf() {
        assertTrue(nodeDomain.isLeaf());
    }
    
    @Test
    public void testIsLeafFalse() {
        final Node child1 = new NodeNe(1, nodeDomain);
        child1.getValue().setName(NODE1_NAME);
        nodeDomain.addChild(child1);
        
        assertFalse(nodeDomain.isLeaf());
    }
    
    @Test
    public void testGetColumnByPosition() {
        assertThat(nodeDomain, is(nodeDomain.getColumnByPosition(0)));
        assertThat(nodeDomain, is(nodeDomain.getColumnByPosition(0)));        
    }
    
    @Test(expected=UnsupportedOperationException.class)
    public void testGetColumnByWrongPosition() {
        nodeDomain.getColumnByPosition(100);        
    }
        
    @Test
    public void testGets() {
        Assert.assertNotNull(nodeDomain.getColumns());
        Assert.assertNotNull(nodeDomain.getValue());
                
        assertThat(nodeDomain.getId(), is(1)); 
    }
    
    @Test
    public void testChildren() {
        final Node child1 = new NodeNe(1, nodeDomain);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeNe(2, nodeDomain);
        child2.getValue().setName(NODE2_NAME);
        
        nodeDomain.addChild(child1);
        nodeDomain.addChild(child2);
        
        final Enumeration<TreeNode> nodes = nodeDomain.children();

        int totalNodes = 0;
        
        while(nodes.hasMoreElements()) {
            nodes.nextElement();
            totalNodes++;
        }
        
        assertThat(nodeDomain.getChildCount(), is(totalNodes));
    }
    
    @Test
    public void testToString() {
        assertThat(nodeDomain.toString(), is(nodeDomain.getValue().getName()));
    }
    
    @Test
    public void testHashCode() {
        
        final int hash1 = new NodeDomain(1, nodeRoot, comparing(Object::toString, String::compareToIgnoreCase)).hashCode();
        final int hash2 = new NodeDomain(2, nodeRoot, comparing(Object::toString, String::compareToIgnoreCase)).hashCode();

        final int hash3 = new NodeDomain(1, new NodeRoot(2, "Root"), comparing(Object::toString, String::compareToIgnoreCase)).hashCode();
        
        assertThat(nodeDomain.hashCode(), is(hash1));
        assertThat(nodeDomain.hashCode(), not(is(hash2)));
        assertThat(nodeDomain.hashCode(), not(is(hash3)));
    }
    
    @Test
    public void testEquals() {
        final NodeDomain mediator1 = new NodeDomain(1, nodeRoot, comparing(Object::toString, String::compareToIgnoreCase));
        final NodeDomain mediator2 = new NodeDomain(2, nodeRoot, comparing(Object::toString, String::compareToIgnoreCase));
        final NodeDomain mediator3 = new NodeDomain(1, new NodeRoot(2, "Root"), comparing(Object::toString, String::compareToIgnoreCase));
        
        assertTrue(nodeDomain.equals(mediator1));
        
        assertFalse(nodeDomain.equals(mediator2));
        assertFalse(nodeDomain.equals(mediator3));
        assertFalse(nodeDomain == null);
        assertFalse(nodeDomain.equals(new Object()));
    }
    
    private IAS createBcbMediator() {
        final IAS domainBcb = new ASItem();
        domainBcb.setId(1);
        domainBcb.setIdName("Domain_IdName");
        return domainBcb;
    }
}
