package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.coriant.widgets.treetable.TreeTableModel;
import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class TreeTableViewModelTest {

    private final NodeRoot nodeRoot = new NodeRoot(1, "Root");
    private final ImmutableList<TableColumn> columns = new TableColumnsBuilder().build();
    private TreeTableViewModel model;
    
    @Before
    public void setup() {
        model = new TreeTableViewModel(nodeRoot);
    }
    
    @Test
    public void testGetColumnCount() {
        assertEquals(model.getColumnCount(), columns.size());
    }
    
    @Test
    public void testGetColumnName() {
        assertThat(model.getColumnName(ColumnId.INFO.position()), is(TreeTableLabels.COLUMN_INFO.toString()));
    }
    
    @Test(expected=IllegalArgumentException.class)
    public void testGetInvalidColumnName() {
        model.getColumnName(100);
    }
    
    @Test
    public void testGetColumnClass() {
        assertEquals(model.getColumnClass(ColumnId.TREE_MODEL.position()), TreeTableModel.class);
        assertEquals(model.getColumnClass(ColumnId.INFO.position()), String.class);
    }
    
    @Test
    public void testIsColumnRemovable() {
       assertFalse(model.isColumnRemovable(ColumnId.TREE_MODEL.position()));
       assertTrue(model.isColumnRemovable(ColumnId.INFO.position()));
    }
    
    @Test
    public void testGetPreferredColumnWidth() {
       assertThat(model.getPreferredColumnWidth(ColumnId.INFO.position()), is(TableColumnsBuilder.DEFAULT_INFO_WIDTH));
    }
    
    @Test
    public void testGetDefaultVisibleColumnsNames() {
        final Collection<String> names = model.getDefaultVisibleColumnsNames();
        
        Assert.assertTrue(names.contains(TreeTableLabels.COLUMN_NETWORK_NAME.toString()));
        Assert.assertTrue(names.contains(TreeTableLabels.COLUMN_TYPE.toString()));
    }
    
    @Test
    public void testIsToggleButtonEnabled() {
        assertTrue(model.isToggleButtonEnabled(nodeRoot));
    }
    
    @Test
    public void testIsToggleButtonVisible() {
        assertFalse(model.isToggleButtonVisible(nodeRoot));
    }
    
    @Test
    public void testGetNodeIcon() {
        Assert.assertNotNull(model.getNodeIcon(nodeRoot));
    }
    
    @Test
    public void testGetChildCount() {
       assertThat(model.getChildCount(nodeRoot), is(0));
    }
}
