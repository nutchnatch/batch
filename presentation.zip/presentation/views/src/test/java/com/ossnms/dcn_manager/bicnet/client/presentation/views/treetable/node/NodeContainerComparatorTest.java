package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import org.hamcrest.Matchers;
import org.junit.Test;

import static org.junit.Assert.*;

public class NodeContainerComparatorTest {

    @Test public void testCompare() throws Exception {
        NodeContainerRoot root = new NodeContainerRoot("root");

        final NodeNe nodeNe = new NodeNe(1, root);
        nodeNe.getValue().setName("4Name");

        final NodeNe nodeNe2 = new NodeNe(2, root);
        nodeNe2.getValue().setName("3Name");

        final NodeSystemContainer nodeSystemContainer = new NodeSystemContainer(1, root);
        nodeSystemContainer.getValue().setName("2Name");

        final NodeContainer nodeContainer = new NodeContainer(1, root);
        nodeContainer.getValue().setName("1Name");

        root.addChild(nodeNe);
        root.addChild(nodeContainer);
        root.addChild(nodeNe2);
        root.addChild(nodeSystemContainer);

        assertThat(root.getAllChildren(), Matchers.contains(nodeContainer, nodeSystemContainer, nodeNe2, nodeNe));
    }
}