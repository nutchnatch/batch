package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainerRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import org.junit.Before;
import org.junit.Test;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindAllNeNodes;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindAllSystemContainerNodes;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindContainerNode;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindNodeByName;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class NodeFinderContainerViewTest extends TestsHelper {
    public static final int NE_ID_OUT_OF_RANGE = 100;
    private Node root;

    @Before public void setUp() {
        root = new NodeContainerRoot("TNMS");

        final NodeContainer nodeContainer1 = buildNodeNeContainer(root, ID_1);
        final NodeContainer nodeContainer2 = buildNodeNeContainer(root, ID_2);
        final NodeContainer nodeContainer3 = buildNodeNeContainer(nodeContainer2, ID_3);

        final NodeSystemContainer nodeSystemContainer1 = buildNodeSystemContainer(nodeContainer1, ID_1);
        final NodeSystemContainer nodeSystemContainer2 = buildNodeSystemContainer(nodeContainer1, ID_2);
        final NodeSystemContainer nodeSystemContainer22 = buildNodeSystemContainer(nodeContainer2, ID_2);
        final NodeSystemContainer nodeSystemContainer3 = buildNodeSystemContainer(root, ID_3);

        final NodeNe nodeNe1 = buildNodeNe(nodeSystemContainer1, ID_1);
        final NodeNe nodeNe2 = buildNodeNe(nodeContainer1, ID_2);
        final NodeNe nodeNe22 = buildNodeNe(nodeContainer2, ID_2);
        final NodeNe nodeNe3 = buildNodeNe(root, ID_3);

        root.addChild(nodeContainer1);
        root.addChild(nodeContainer2);
        root.addChild(nodeSystemContainer3);
        root.addChild(nodeNe3);

        nodeContainer1.addChild(nodeSystemContainer1);
        nodeContainer1.addChild(nodeSystemContainer2);
        nodeContainer1.addChild(nodeNe2);

        nodeContainer2.addChild(nodeContainer3);
        nodeContainer2.addChild(nodeSystemContainer22);
        nodeContainer2.addChild(nodeNe22);

        nodeSystemContainer1.addChild(nodeNe1);
    }

    @Test public void testTryFindByName() {
        assertTrue(tryFindNodeByName(root, "TNMS").findFirst().isPresent());

        assertTrue(tryFindNodeByName(root, CONTAINER_NAME + ID_1).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, CONTAINER_NAME + ID_2).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, CONTAINER_NAME + ID_3).findFirst().isPresent());

        assertTrue(tryFindNodeByName(root, SYS_CONTAINER_NAME + ID_1).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, SYS_CONTAINER_NAME + ID_2).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, SYS_CONTAINER_NAME + ID_3).findFirst().isPresent());

        assertTrue(tryFindNodeByName(root, NE_NAME + ID_1).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, NE_NAME + ID_2).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, NE_NAME + ID_3).findFirst().isPresent());
    }

    @Test public void testTryFindAllNodeNEs() throws Exception {
        assertThat(tryFindAllNeNodes(root, ID_1).size(), is(1));
        assertThat(tryFindAllNeNodes(root, ID_2).size(), is(2));
        assertThat(tryFindAllNeNodes(root, ID_3).size(), is(1));
    }

    @Test public void testTryFindAllNodeSysContainer() throws Exception {
        assertThat(tryFindAllSystemContainerNodes(root, ID_1).size(), is(1));
        assertThat(tryFindAllSystemContainerNodes(root, ID_2).size(), is(2));
        assertThat(tryFindAllSystemContainerNodes(root, ID_3).size(), is(1));
    }

    @Test public void testTryFindContainer() throws Exception {
        assertThat(tryFindContainerNode(root, ID_1).isPresent(), is(true));
        assertThat(tryFindContainerNode(root, ID_2).isPresent(), is(true));
        assertThat(tryFindContainerNode(root, ID_3).isPresent(), is(true));
    }
}
