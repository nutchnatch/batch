package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader.job;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.dcn_manager.bicnet.client.api.exception.DcnClientException;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader.NodeLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class FetchTreeNodesTest {
    
    private NodeLoader loader;
    private Node node;
    private FrameworkDocument document;
    
    @Before
    @SuppressWarnings("unchecked")
    public void setup() throws DcnClientException {
        loader = mock(NodeLoader.class);
        node = mock(Node.class); 
        document = mock(FrameworkDocument.class);

        when(loader.load()).thenReturn(node);
    }        
    
    @Test
    public void testExecute() throws FrameworkException, DcnClientException {
        final FetchTreeNodes<Integer, IMediator> fetch = new FetchTreeNodes<>(loader, document);
        
        final Node nodeResult = fetch.execute(null);
        
        assertNotNull(nodeResult);
        assertThat(nodeResult, CoreMatchers.is(node));
        
        verify(loader, Mockito.times(1)).load();
    }
    
    @Test(expected=FrameworkException.class)
    public void testExecute_error() throws FrameworkException, DcnClientException {
        final FetchTreeNodes<Integer, IMediator> fetch = new FetchTreeNodes<>(loader, document);
        
        doThrow(FrameworkException.class).when(loader).load();
        
        fetch.execute(null);        
    }
}
