package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.junit.Before;
import org.junit.Test;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_DEACTIVATE_ALL_NES_SAN;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_DEACTIVATE_NES_SAN;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

public class ActionDeactivateNEsUnderDomainTest extends TestsHelper{
    private ActionDeactivateNEsUnderDomain actionDeactivateNEsUnderDomain;

    @Before public void setUp() throws Exception {
        this.actionDeactivateNEsUnderDomain = new ActionDeactivateNEsUnderDomain(repositoryManager, commonServices);

        FullNeData fullNeData1 = buildFullNeData(ID_1, ID_2, "");
        FullNeData fullNeData2 = buildFullNeData(ID_2, ID_2, "");

        fullNeData1.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeData1.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        fullNeData2.getNe().setActivation(EnableSwitch.ENABLED);
        fullNeData2.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        when(neRepository.get(ImmutableList.of(ID_1,ID_2))).thenReturn(ImmutableList.of(fullNeData1, fullNeData2));

        when(secureActionValidation.checkPermission(OP_DEACTIVATE_ALL_NES_SAN)).thenReturn(true);
        when(secureActionValidation.checkPermission(OP_DEACTIVATE_NES_SAN, fullNeData1.getNe())).thenReturn(true);
        when(secureActionValidation.checkPermission(OP_DEACTIVATE_NES_SAN, fullNeData2.getNe())).thenReturn(true);
    }

    @Test public void testIsOperationAllowed() throws Exception {
        IAS domain = new ASItem();
        domain.setId(ID_2);
        domain.setNeList(new INEId[]{new NEIdItem(ID_1), new NEIdItem(ID_2)});
        IAS[] managedObjects = {domain};

        boolean actionAllowed = actionDeactivateNEsUnderDomain.isPluginActionAllowed(managedObjects);

        assertTrue(actionAllowed);
    }
}