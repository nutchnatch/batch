package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.domain;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.util.Properties;

import javax.swing.event.ListSelectionEvent;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.CurrentViewSingleton;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.TreeTableViewTypes;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;

@RunWith(MockitoJUnitRunner.class)
public class TreeTableDomainsViewTest extends TestsHelper {

    @Mock private TreeTableDomainsDocument document;
    @Mock private ListSelectionEvent selectionEvent;
    @Mock private Properties properties;

    private TreeTableDomainsView domainsView;

    @Before public void setUp() throws Exception {
        when(document.getCommonServices()).thenReturn(commonServices);
        when(document.getRepositoryManager()).thenReturn(repositoryManager);
        CurrentViewSingleton.getInstance().changeCurrentView(TreeTableViewTypes.DOMAIN);

        this.domainsView = new TreeTableDomainsView("title", document);
    }

    @Test public void testGetProfileId() throws Exception {
        String profileId = domainsView.getProfileId();
        assertThat(profileId, is(TreeTableDomainsView.class.getName()));
    }

    @Test public void testValueChanged() throws Exception {
        domainsView.valueChanged(selectionEvent);
    }

    @Test public void testAddExtraPropertiesToSave() throws Exception {
        domainsView.addExtraPropertiesToSave(properties);
    }
    
    @Test public void testGetPrintData(){
        String currentView = domainsView.getPrintData().getTitle();
        assertThat(currentView, containsString(TreeTableLabels.DOMAIN_VIEW_TITLE.toString()));
    }
}