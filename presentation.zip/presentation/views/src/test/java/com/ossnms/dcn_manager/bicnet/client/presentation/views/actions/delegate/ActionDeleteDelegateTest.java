package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentTypes;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.view.MessageBox;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.CurrentViewSingleton;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.TreeTableViewTypes;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionDeleteDelegateTest extends TestsHelper {

    private IEM channel = new EMItem();

    private ActionDeleteDelegate actionDeleteDelegate;

    @Before
    public void setUp() throws Exception {
        CurrentViewSingleton.getInstance().changeCurrentView(TreeTableViewTypes.MEDIATOR);

        actionDeleteDelegate = new ActionDeleteDelegate(repositoryManager, commonServices);

        when(messageBox.warnConfirmationBox(any(TreeTableLabels.class), anyString())).thenReturn(MessageBox.OPTION.YES);
        when(secureActionValidation.checkPermission(eq(SecureAction.OP_DELETE_SAN), any(IManagedObjectId[].class))).thenReturn(true);
        when(secureActionValidation.checkPermission(eq(SecureAction.OP_DELETE_SAN))).thenReturn(true);

        channel.setIdName("name");
        channel.setId(1);

        when(neSearchable.findByChannel(channel.getId())).thenReturn(emptyList());
    }

    @Test
    public void testIsActionAllowed() throws Exception {
        boolean actionAllowed = actionDeleteDelegate.isActionAllowed(new IManagedObject[]{channel});

        assertTrue(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_supportedView_container() throws Exception {
        CurrentViewSingleton.getInstance().changeCurrentView(TreeTableViewTypes.CONTAINER);

        boolean actionAllowed = actionDeleteDelegate.isActionAllowed(new IManagedObject[]{channel});

        assertTrue(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_not_on_supportedView() throws Exception {
        CurrentViewSingleton.getInstance().changeCurrentView(TreeTableViewTypes.DOMAIN);

        boolean actionAllowed = actionDeleteDelegate.isActionAllowed(new IManagedObject[]{channel});

        assertFalse(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_false_node_active() throws Exception {
        channel.setActivation(EnableSwitch.ENABLED);

        boolean actionAllowed = actionDeleteDelegate.isActionAllowed(new IManagedObject[]{channel});

        assertFalse(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_false_node_hasChildren() throws Exception {
        channel.setActivation(EnableSwitch.DISABLED);
        when(neSearchable.findByChannel(channel.getId())).thenReturn(asList(buildFullNeData(1, channel.getId(), "")));

        boolean actionAllowed = actionDeleteDelegate.isActionAllowed(new IManagedObject[]{channel});

        assertFalse(actionAllowed);
    }

    @Test
    public void testIsActionAllowed_false_node_active_hasChildren() throws Exception {
        channel.setActivation(EnableSwitch.ENABLED);

        boolean actionAllowed = actionDeleteDelegate.isActionAllowed(new IManagedObject[]{channel});

        assertFalse(actionAllowed);
    }

    @Test
    public void testGetActionId() throws Exception {
        assertThat(actionDeleteDelegate.getActionId(), is(ActionDeleteDelegate.class.getName()));
    }

    @Test
    public void testGetMenuName() throws Exception {
        assertThat(actionDeleteDelegate.getMenuName(), is(TreeTableLabels.DELETE));
    }

    @Test
    public void testMessageDefault_single() throws Exception {
        INE node = ne(1, "name");

        final FullNeData buildFullNeData = buildFullNeData(1, 1, "");

        when(repositoryManager.getNeRepository().get(singletonList(1))).thenReturn(singletonList(buildFullNeData));

        final String messageDefault = "default";

        final String text = actionDeleteDelegate
                .messageForNEDeletion(array(node), node.getIdName(), messageDefault);

        assertThat(text, is(messageDefault));
    }

    private INE ne(int id, String name) {
        NEItem ne = new NEItem();
        ne.setIdName(name);
        ne.setId(id);
        return ne;
    }

    @Test
    public void testMessageUsedBy_single() throws Exception {
        INE ne = ne(1, "name");
        ne.setUsedBy(BiCNetComponentTypes.of(BiCNetComponentType.AP_NOTIFY));

        final String usedByMessage = TreeTableLabels.USED_BY_WARN_MESSAGE_SINGLE.guiName()
                .getFormatedMessage("names", BiCNetComponentType.AP_NOTIFY.guiLabel());

        final String text = actionDeleteDelegate
                .messageForNEDeletion(array(ne), "names", "default");

        assertThat(text, is(usedByMessage));
    }

    private IManagedObject[] array(IManagedObject... objects) {
        return objects;
    }

    @Test
    public void testMessageDefault_multi() throws Exception {
        INE node1 = ne(1, "name1");
        INE node2 = ne(2, "name2");

        final FullNeData buildFullNeData1 = buildFullNeData(1, 1, "");
        final FullNeData buildFullNeData2 = buildFullNeData(2, 1, "");

        when(repositoryManager.getNeRepository().get(asList(1, 2))).thenReturn(asList(buildFullNeData1, buildFullNeData2));

        final String messageDefault = "default";

        final String text = actionDeleteDelegate
                .messageForNEDeletion(array(node1, node2), channel.getIdName(), messageDefault);

        assertThat(text, is(messageDefault));
    }

    @Test
    public void testMessageUsedBy_multi() throws Exception {
        INE node1 = ne(1, "name1");
        node1.setUsedBy(BiCNetComponentTypes.of(BiCNetComponentType.AP_NOTIFY));
        INE node2 = ne(2, "name2");
        node2.setUsedBy(BiCNetComponentTypes.of(BiCNetComponentType.AP_NOTIFY));

        final String usedByMessage = TreeTableLabels.USED_BY_WARN_MESSAGE_MULTI.guiName()
                .getFormatedMessage("names", BiCNetComponentType.AP_NOTIFY.guiLabel());

        final String text = actionDeleteDelegate
                .messageForNEDeletion(array(node1, node2), "names", "default");

        assertThat(text, is(usedByMessage));
    }

    @Test
    public void testMessageUsedBy_multi_one_with_used_by() throws Exception {
        INE node1 = ne(1, "name1");
        node1.setUsedBy(BiCNetComponentTypes.of(BiCNetComponentType.AP_NOTIFY));
        INE node2 = ne(2, "name2");

        final String usedByMessage = TreeTableLabels.USED_BY_WARN_MESSAGE_MULTI.guiName()
                .getFormatedMessage("names", BiCNetComponentType.AP_NOTIFY.guiLabel());

        final String text = actionDeleteDelegate
                .messageForNEDeletion(array(node1, node2), "names", "default");

        assertThat(text, is(usedByMessage));
    }
}