package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobMediatorsActivate;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_MEDIATORS_SAN;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionActivateMediatorTest extends TestsHelper {

    private ActionActivateMediator actionActivateMediator;
    private FullMediatorData fullMediatorData;

    @Before public void setUp() throws Exception {
        fullMediatorData = buildFullMediatorData(ID_1);
        fullMediatorData.getMediator().setActivation(EnableSwitch.DISABLED);

        actionActivateMediator = new ActionActivateMediator(commonServices);
    }

    private <T extends IManagedObjectId> T[] withPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_ACTIVATE_MEDIATORS_SAN, objectsToCheck)).thenReturn(true);
        return objectsToCheck;
    }

    private <T extends IManagedObjectId> T[] withoutPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_ACTIVATE_MEDIATORS_SAN, objectsToCheck)).thenReturn(false);
        return objectsToCheck;
    }

    @Test public void testMenuName() throws Exception {
        assertThat(actionActivateMediator.getMenuName(), is(TreeTableLabels.ACTIVATE_MEDIATOR.toString()));
    }

    @Test public void testDescription() throws Exception {
        assertThat(actionActivateMediator.getShortDescription(), is(TreeTableLabels.ACTIVATE_MEDIATOR.toString()));
    }

    @Test public void testIsPluginAllowed_ok_for_IMediator_2_objects() throws Exception {
        FullMediatorData wrong = buildFullMediatorData(ID_2);
        wrong.getMediator().setActivation(EnableSwitch.ENABLED);

        boolean pluginActionAllowed = actionActivateMediator
                .isPluginActionAllowed(withPermissions(fullMediatorData.getMediator(), wrong.getMediator()));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_for_IMediator() throws Exception {
        boolean pluginActionAllowed = actionActivateMediator
                .isPluginActionAllowed(withPermissions(fullMediatorData.getMediator()));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_wrong_object() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        topologicalSymbol.setNetworkElement(new NEIdItem(ID_1));

        boolean pluginActionAllowed = actionActivateMediator
                .isPluginActionAllowed(withPermissions(topologicalSymbol));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_no_permission() throws Exception {
        boolean pluginActionAllowed = actionActivateMediator
                .isPluginActionAllowed(withoutPermissions(fullMediatorData.getMediator()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_wrong_required_state() {
        fullMediatorData.getMediator().setActivation(EnableSwitch.ENABLED);

        boolean pluginActionAllowed = actionActivateMediator
                .isPluginActionAllowed(withPermissions(fullMediatorData.getMediator()));

        assertThat(pluginActionAllowed, is(false));
    }

    @SuppressWarnings("unchecked")
    @Test public void eventPluginActionPerformed_ok_for_IMediator() throws Exception {
        actionActivateMediator.eventPluginActionPerformed(withPermissions(fullMediatorData.getMediator()));

        verify(dcnPluginHelper, times(1)).queueJob(any(JobMediatorsActivate.class));
    }

    @SuppressWarnings("unchecked")
    @Test public void eventPluginActionPerformed_wrong_object() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        topologicalSymbol.setNetworkElement(new NEIdItem(ID_1));

        actionActivateMediator.eventPluginActionPerformed(withPermissions(topologicalSymbol));

        verify(dcnPluginHelper, never()).queueJob(any(JobMediatorsActivate.class));
    }
}
