package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.api.Containers;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ContainerCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NEContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.SystemContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.SystemContainerCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.Collections;

import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

public class ActionsIT extends TestsHelper {

    private IGenericContainer parent;
    private RepositoryManager repositoryManager;

    @Before public void setUp() throws Exception {
        repositoryManager = new RepositoryManager();

        // Init Caches
        ContainerCacheManager.getInstance().cache().fetch(Collections.emptyList());
        SystemContainerCacheManager.getInstance().cache().fetch(Collections.emptyList());
        NeCacheManager.getInstance().cache().fetch(Collections.emptyList());
        SystemContainerAssignmentCacheManager.getInstance().cache().fetch(Collections.emptyList());
        NEContainerAssignmentCacheManager.getInstance().cache().fetch(Collections.emptyList());

        // Parent - Root
        parent = buildContainer(ID_1, Containers.ROOT_CONTAINER_ID);
        ContainerCacheManager.getInstance().cache().put(ID_1, parent);

        // Parent Container = ID_1
        ContainerCacheManager.getInstance().cache().put(ID_2, buildContainer(ID_2, ID_1));

        // Parent Container = ID_2
        ContainerCacheManager.getInstance().cache().put(ID_3, buildContainer(ID_3, ID_2));

        // Parent Container = ID_2
        SystemContainerCacheManager.getInstance().cache().put(ID_4, buildSystemContainer(ID_4));

        // Parent Container = ID_2 , System = ID_4
        SystemContainerAssignmentCacheManager.getInstance().cache()
                .put(new SystemGenericContainerAssignmentIdItem(ID_4, ID_2), buildSystemAssigment(ID_4, ID_2));

        // NE associated with System 4
        final FullNeData fullNeData = buildFullNeData(ID_1, ID_1, "");
        fullNeData.getNe().setAssociatedSystemContainerId(ID_4);
        NeCacheManager.getInstance().cache().put(ID_1, fullNeData);

        // NE associated with Container ID_1
        NeCacheManager.getInstance().cache().put(ID_2, buildFullNeData(ID_2, ID_1, ""));
        NEContainerAssignmentCacheManager.getInstance().cache()
                .put(new NeGenericContainerAssignmentIdItem(ID_2, ID_1), buildNeAssigment(ID_2, ID_1));

        // NE associated with Container ID_2
        NeCacheManager.getInstance().cache().put(ID_3, buildFullNeData(ID_3, ID_1, ""));
        NEContainerAssignmentCacheManager.getInstance().cache()
                .put(new NeGenericContainerAssignmentIdItem(ID_3, ID_2), buildNeAssigment(ID_3, ID_2));

        // NE associated with Container ID_3
        NeCacheManager.getInstance().cache().put(ID_4, buildFullNeData(ID_4, ID_1, ""));
        NEContainerAssignmentCacheManager.getInstance().cache()
                .put(new NeGenericContainerAssignmentIdItem(ID_4, ID_3), buildNeAssigment(ID_4, ID_3));

        // NE associated with Container ROOT
        NeCacheManager.getInstance().cache().put(ID_5, buildFullNeData(ID_5, ID_1, ""));
        NEContainerAssignmentCacheManager.getInstance().cache()
                .put(new NeGenericContainerAssignmentIdItem(ID_5, Containers.ROOT_CONTAINER_ID),
                        buildNeAssigment(ID_5, Containers.ROOT_CONTAINER_ID));
    }

    @Test public void getAllNEsInContainerAndSubContainers() throws Exception {
        final Collection<Integer> neList = Actions.getAllNEsInContainerAndSubContainers(parent.getId(), repositoryManager);

        assertThat(neList, containsInAnyOrder(ID_1, ID_2, ID_3, ID_4));
        assertThat(neList, not(containsInAnyOrder(ID_5)));
    }
}