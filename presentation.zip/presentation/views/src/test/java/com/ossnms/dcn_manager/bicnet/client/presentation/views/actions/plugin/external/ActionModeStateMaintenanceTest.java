package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeActivationState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapabilities;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapability;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.Job;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobModeStateMaintenance;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;

import static com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapability.ADMIN_STATE_NO_CHANGE;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_MOGCM_MAINTENANCE_SAN;
import static java.util.Optional.of;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionModeStateMaintenanceTest extends TestsHelper {
    @Mock ChannelType channelType;

    private ActionModeStateMaintenance actionModeStateMaintenance;
    private FullNeData fullNeData;

    @Before public void setUp() throws Exception {
        fullNeData = buildFullNeData(ID_1, ID_1, "");
        fullNeData.getNe().setActualActivationState(NeActivationState.ACTIVE);
        fullNeData.getNe().setEventForwarding(EnableSwitch.ENABLED);
        fullNeData.getNe().setCapabilities(NeCapabilities.of(NeCapability.MAINTENANCE_MODE));

        FullChannelData fullChannelData = buildFullChannelData(ID_1, ID_1);
        when(channelRepository.get(ID_1)).thenReturn(of(fullChannelData));
        when(staticConfiguration.findChannelType(anyString())).thenReturn(of(channelType));
        when(channelType.supportsNeCreation()).thenReturn(true);

        when(neRepository.get(ImmutableList.of(ID_1))).thenReturn(ImmutableList.of(fullNeData));

        actionModeStateMaintenance = new ActionModeStateMaintenance(repositoryManager, commonServices);
    }

    private <T extends IManagedObjectId> T[] withPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_MOGCM_MAINTENANCE_SAN, objectsToCheck)).thenReturn(true);
        for (T object : objectsToCheck) {
            when(secureActionValidation.checkPermission(OP_MOGCM_MAINTENANCE_SAN, object)).thenReturn(true);
        }
        return objectsToCheck;
    }

    private <T extends IManagedObjectId> T[] withoutPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_MOGCM_MAINTENANCE_SAN, objectsToCheck)).thenReturn(false);
        return objectsToCheck;
    }

    @Test public void testMenuName() throws Exception {
        assertThat(actionModeStateMaintenance.getMenuName(), is(TreeTableLabels.MAINTENANCE.toString()));
    }

    @Test public void testDescription() throws Exception {
        assertThat(actionModeStateMaintenance.getShortDescription(), is(TreeTableLabels.MAINTENANCE_DESC.toString()));
    }

    @Test public void testIsPluginAllowed_ok_for_INE_2_objects() throws Exception {
        FullNeData wrong = buildFullNeData(ID_2, ID_2, "");
        wrong.getNe().setActualActivationState(NeActivationState.ACTIVATING);

        boolean pluginActionAllowed = actionModeStateMaintenance
                .isPluginActionAllowed(withPermissions(fullNeData.getNe(), wrong.getNe()));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_for_INE() throws Exception {
        boolean pluginActionAllowed = actionModeStateMaintenance.isPluginActionAllowed(withPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_TOPO_SYMBOL() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        NEIdItem neId = new NEIdItem(ID_1);
        topologicalSymbol.setNetworkElement(neId);
        withPermissions(neId);
        ITopologicalSymbol[] toCheck = {topologicalSymbol};

        boolean pluginActionAllowed = actionModeStateMaintenance.isPluginActionAllowed(toCheck);

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_system() throws Exception {
        ISystemContainer system = new SystemContainerItem();
        system.setId(ID_1);

        ISystemContainer[] objectsToCheck = {system};
        fullNeData.getNe().setAssociatedSystemContainerId(ID_1);

        when(neSearchable.findBySystemContainerId(ID_1)).thenReturn(ImmutableList.of(fullNeData));
        when(secureActionValidation.checkPermission(OP_MOGCM_MAINTENANCE_SAN, fullNeData.getNe())).thenReturn(true);

        boolean pluginActionAllowed = actionModeStateMaintenance.isPluginActionAllowed(withPermissions(objectsToCheck));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_no_permission() throws Exception {

        boolean pluginActionAllowed = actionModeStateMaintenance.isPluginActionAllowed(withoutPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_wrong_capability() throws Exception {
        fullNeData.getNe().setCapabilities(NeCapabilities.of(ADMIN_STATE_NO_CHANGE));

        boolean pluginActionAllowed = actionModeStateMaintenance.isPluginActionAllowed(withPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_wrong_actual_state() throws Exception {
        fullNeData.getNe().setActualActivationState(NeActivationState.ACTIVATING);

        boolean pluginActionAllowed = actionModeStateMaintenance.isPluginActionAllowed(withPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void eventPluginActionPerformed_ok_for_INE() throws Exception {
        actionModeStateMaintenance.eventPluginActionPerformed(withPermissions(fullNeData.getNe()));

        verify(dcnPluginHelper, times(1)).queueJob(any(JobModeStateMaintenance.class));
    }

    @Test public void eventPluginActionPerformed_ok_for_TOPO() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        NEIdItem neId = new NEIdItem(ID_1);
        withPermissions(neId);
        topologicalSymbol.setNetworkElement(neId);
        ITopologicalSymbol[] toCheck = {topologicalSymbol};

        actionModeStateMaintenance.eventPluginActionPerformed(toCheck);

        verify(dcnPluginHelper, times(1)).queueJob(any(JobModeStateMaintenance.class));
    }

    @Test public void testCreateJob() throws Exception {
        Collection<INEId> neIds = ImmutableList.of(new NEIdItem(ID_1));
        Job<INEId> job = actionModeStateMaintenance.createJob(neIds);
        assertThat(job.getClass().getName(), is(JobModeStateMaintenance.class.getName()));
    }

    @Test public void testSupportsActionModeState() throws Exception {
        INE ne = fullNeData.getNe();
        boolean supportsActionModeState = actionModeStateMaintenance.supportsActionModeState(ne);
        assertThat(supportsActionModeState, is(true));
    }

    @Test public void testSupportsActionModeState_false_no_operationSupported() throws Exception {
        INE ne = fullNeData.getNe();
        when(channelType.supportsNeCreation()).thenReturn(false);

        boolean supportsActionModeState = actionModeStateMaintenance.supportsActionModeState(ne);
        assertThat(supportsActionModeState, is(false));
    }

    @Test public void testSupportsActionModeState_false_wrong_eventForwarding() throws Exception {
        INE ne = fullNeData.getNe();
        ne.setEventForwarding(EnableSwitch.DISABLED);

        boolean supportsActionModeState = actionModeStateMaintenance.supportsActionModeState(ne);
        assertThat(supportsActionModeState, is(false));
    }

    @Test public void testGetSecureAction() throws Exception {
        SecureAction secureAction = actionModeStateMaintenance.getSecureAction();
        assertThat(secureAction, is(OP_MOGCM_MAINTENANCE_SAN));
    }

}