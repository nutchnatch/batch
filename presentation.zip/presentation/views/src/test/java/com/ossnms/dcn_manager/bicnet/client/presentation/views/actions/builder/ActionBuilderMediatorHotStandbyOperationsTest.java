package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.builder;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.api.action.PluginAction;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateMediatorOnStandby;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateMediatorOnStandby;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.Collections.singletonList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionBuilderMediatorHotStandbyOperationsTest extends TestsHelper{

    private static final Collection<IManagedObject> INVALID_VALUES = ImmutableList
            .of((IManagedObject) new EMItem());

    private static final Collection<IManagedObject> VALID_WITH_INVALID_TYPES = ImmutableList
            .of((IManagedObject) new EMItem(), new MediatorItem());

    private FullMediatorData fullMediatorData;
    private ActionBuilderMediatorHotStandbyOperations actionsBuilder;

    @Before public void setUp() throws Exception {
        actionsBuilder = new ActionBuilderMediatorHotStandbyOperations(repositoryManager, commonServices);

        fullMediatorData = buildFullMediatorData(ID_2);
        fullMediatorData.getInfo().setStandbyMediatorConfigured(true);

        when(mediatorRepository.get(ID_2)).thenReturn(Optional.of(fullMediatorData));
    }

    @Test public void testValidActions() {
        final Collection<PluginAction> actions = actionsBuilder.createList()
                .actionsOf(singletonList(fullMediatorData.getMediator()));

        assertThat(actions.size(), is(2));
        assertThat(actions.stream().map(PluginAction::getMenuID).collect(Collectors.toList()),
                containsInAnyOrder(
                        ActionActivateMediatorOnStandby.class.getName(),
                        ActionDeactivateMediatorOnStandby.class.getName()));
    }

    @Test public void testInvalidActions() {
        final Collection<PluginAction> actions = actionsBuilder.actionsOf(INVALID_VALUES);

        assertTrue(actions.isEmpty());
    }

    @Test public void testAllMatch() {
        assertTrue(actionsBuilder.allMatch(singletonList(fullMediatorData.getMediator())));
    }

    @Test public void testAllMatch_no_standby_configured() throws RepositoryException {
        fullMediatorData.getInfo().setStandbyMediatorConfigured(false);

        when(mediatorRepository.get(ID_2)).thenReturn(Optional.of(fullMediatorData));

        assertFalse(actionsBuilder.allMatch(singletonList(fullMediatorData.getMediator())));
    }

    @Test public void testAllMatch_valid_with_invalid_types() {
        assertFalse(actionsBuilder.allMatch(VALID_WITH_INVALID_TYPES));
    }

    @Test public void testAllMatchFalse() {
        assertFalse(actionsBuilder.allMatch(INVALID_VALUES));
    }

    @Test public void testActions() {
        assertTrue(actionsBuilder.getActions().isEmpty());
    }
}