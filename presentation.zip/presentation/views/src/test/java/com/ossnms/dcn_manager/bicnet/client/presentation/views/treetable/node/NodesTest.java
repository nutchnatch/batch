package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class NodesTest {

    @Test
    public void testIsSingleSelection() throws Exception {
        boolean value = Nodes.isSingleSelection(ImmutableList.of(new NodeRoot(1, "node1")));
        assertThat(value, is(true));
    }

    @Test
    public void testIsSingleSelection_null() throws Exception {
        IManagedObject[] o = null;
        boolean value = Nodes.isSingleSelection(o);
        assertThat(value, is(false));
    }

    @Test
    public void testIsSingleSelection_false() throws Exception {
        boolean value = Nodes.isSingleSelection(ImmutableList.of(new NodeRoot(1, "node1"), new NodeRoot(2, "node2")));
        assertThat(value, is(false));
    }
}