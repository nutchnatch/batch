package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.mediator;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static com.google.code.tempusfugit.temporal.Duration.seconds;
import static com.google.code.tempusfugit.temporal.Timeout.timeout;
import static com.google.code.tempusfugit.temporal.WaitFor.waitOrTimeout;
import static java.util.Collections.singleton;
import static javax.swing.SwingUtilities.invokeLater;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class) public class CheckTreeTableReorderNodesIT extends TestsHelper {
    private static final int TIMEOUT = 5;
    @Mock private TreeTableMediatorsDocument document;
    private TreeTableMediatorsView view;

    @Before public void setUp() throws Exception {
        when(document.getCommonServices()).thenReturn(commonServices);
        when(document.getRepositoryManager()).thenReturn(repositoryManager);

        view = new TreeTableMediatorsView("view", document);
    }

    @Test public void testReorder() throws Exception {
        final TreeTableViewModel model = view.getTreeTableModel();
        Node root = model.getNodeRoot();

        NodeMediator node1 = new NodeMediator(ID_1, root);
        node1.getValue().setName("node1");

        NodeMediator node2 = new NodeMediator(ID_2, root);
        node2.getValue().setName("node4");

        NodeMediator node3 = new NodeMediator(ID_3, root);
        node3.getValue().setName("node6");

        invokeLater(() -> {
            root.addChild(node3);
            model.eventNodeInserted(node3);

            root.addChild(node1);
            model.eventNodeInserted(node1);

            root.addChild(node2);
            model.eventNodeInserted(node2);
        });

        waitOrTimeout(() -> root.getAllChildren().size() == 3, timeout(seconds(TIMEOUT)));

        assertThat(model.getChild(root, 0), is(node1));
        assertThat(model.getChild(root, 1), is(node2));
        assertThat(model.getChild(root, 2), is(node3));

        invokeLater(() -> {
            node1.getValue().setName("node5");
            model.eventNodesChanged(singleton(node1));
            model.structureChanged(node1);
        });

        waitOrTimeout(() -> node1.equals(model.getChild(root, 1)), timeout(seconds(TIMEOUT)));

        assertThat(model.getChild(root, 0), is(node2));
        assertThat(model.getChild(root, 1), is(node1));
        assertThat(model.getChild(root, 2), is(node3));
    }
}
