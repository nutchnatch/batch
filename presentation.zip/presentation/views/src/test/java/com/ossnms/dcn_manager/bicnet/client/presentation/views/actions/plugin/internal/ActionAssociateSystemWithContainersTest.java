package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.SystemAssignmentSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.SystemContainerAssignmentRepository;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Test;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.MOVE_SYSTEM_SAN;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ActionAssociateSystemWithContainersTest {

    @Test public void shouldAllowSingleSelection() throws Exception {
        Map<ISystemContainer, Collection<ISystemGenericContainerAssignment>> systems = ImmutableMap.of(
                system(1), asList(assignment(1, 1, true)));
        SecureAction secAction = MOVE_SYSTEM_SAN;
        boolean secAllowed = true;

        ActionAssociateSystemWithContainers action = new ActionAssociateSystemWithContainers(
                commonService(secAction, secAllowed, systems.keySet()),
                repo(systems),
                mock(NewElementDialogHandler.class));

        boolean actionAllowed = action.isPluginActionAllowed(systems.keySet().toArray(new IManagedObject[0]));

        assertThat(actionAllowed, is(true));
    }

    @Test public void shouldAllowMultipleSelection() throws Exception {
        Map<ISystemContainer, Collection<ISystemGenericContainerAssignment>> systems = ImmutableMap.of(
                system(1), asList(assignment(1, 1, true)),
                system(2), asList(assignment(2, 1, true))
        );
        SecureAction secAction = MOVE_SYSTEM_SAN;
        boolean secAllowed = true;

        ActionAssociateSystemWithContainers action = new ActionAssociateSystemWithContainers(
                commonService(secAction, secAllowed, systems.keySet()),
                repo(systems),
                mock(NewElementDialogHandler.class));

        boolean actionAllowed = action.isPluginActionAllowed(systems.keySet().toArray(new IManagedObject[0]));

        assertThat(actionAllowed, is(true));
    }

    @Test public void shouldNotAllowWithoutPermission() throws Exception {
        Map<ISystemContainer, Collection<ISystemGenericContainerAssignment>> systems = ImmutableMap.of(
                system(1), emptyList()
        );
        SecureAction secAction = MOVE_SYSTEM_SAN;
        boolean secAllowed = false;                  //no permission

        ActionAssociateSystemWithContainers action = new ActionAssociateSystemWithContainers(
                commonService(secAction, secAllowed, systems.keySet()),
                repo(systems),
                mock(NewElementDialogHandler.class));

        boolean actionAllowed = action.isPluginActionAllowed(systems.keySet().toArray(new IManagedObject[0]));

        assertThat(actionAllowed, is(false));
    }

    @Test public void shouldAllowDifferentPrimaryContainer() throws Exception {
        Map<ISystemContainer, Collection<ISystemGenericContainerAssignment>> systems = ImmutableMap.of(
                system(1), asList(assignment(1, 2, false), assignment(1, 1, true)),
                system(2), asList(assignment(2, 2, true), assignment(2, 1, false))
        );
        SecureAction secAction = MOVE_SYSTEM_SAN;
        boolean secAllowed = true;

        ActionAssociateSystemWithContainers action = new ActionAssociateSystemWithContainers(
                commonService(secAction, secAllowed, systems.keySet()),
                repo(systems),
                mock(NewElementDialogHandler.class));

        boolean actionAllowed = action.isPluginActionAllowed(systems.keySet().toArray(new IManagedObject[0]));

        assertThat(actionAllowed, is(false));
    }

    @Test public void shouldAllowDifferentAssignments() throws Exception {
        Map<ISystemContainer, Collection<ISystemGenericContainerAssignment>> systems = ImmutableMap.of(
                system(1), asList(assignment(1, 1, true)),
                system(2), asList(assignment(2, 2, true))
        );
        SecureAction secAction = MOVE_SYSTEM_SAN;
        boolean secAllowed = true;

        ActionAssociateSystemWithContainers action = new ActionAssociateSystemWithContainers(
                commonService(secAction, secAllowed, systems.keySet()),
                repo(systems),
                mock(NewElementDialogHandler.class));

        boolean actionAllowed = action.isPluginActionAllowed(systems.keySet().toArray(new IManagedObject[0]));

        assertThat(actionAllowed, is(false));
    }

    @Test public void shouldAllowOnlyForSystems() throws Exception {
        Map<ISystemContainer, Collection<ISystemGenericContainerAssignment>> systems = ImmutableMap.of(
                system(1), asList(assignment(1, 1, true)),
                system(2), asList(assignment(2, 2, true))
        );
        SecureAction secAction = MOVE_SYSTEM_SAN;
        boolean secAllowed = true;

        ActionAssociateSystemWithContainers action = new ActionAssociateSystemWithContainers(
                commonService(secAction, secAllowed, systems.keySet()),
                repo(systems),
                mock(NewElementDialogHandler.class));

        boolean actionAllowed = action.isPluginActionAllowed(new IManagedObject[]{new NEItem()});  // not system

        assertThat(actionAllowed, is(false));
    }

    private ISystemContainer system(int id) {
        SystemContainerItem system = new SystemContainerItem();
        system.setId(id);
        return system;
    }

    private ISystemGenericContainerAssignment assignment(int systemId, int containerId, boolean primary) {
        ISystemGenericContainerAssignment item = new SystemGenericContainerAssignmentItem();
        item.setSystemContainerId(systemId);
        item.setGenericContainerId(containerId);
        item.setPrimary(primary);
        return item;
    }

    private RepositoryManager repo(Map<ISystemContainer, Collection<ISystemGenericContainerAssignment>> systemAssignments) throws Exception {

        SystemAssignmentSearchable queries = mock(SystemAssignmentSearchable.class);
        for (Entry<ISystemContainer, Collection<ISystemGenericContainerAssignment>> entry : systemAssignments.entrySet()) {
            when(queries.findBySystemContainerId(entry.getKey().getId())).thenReturn(entry.getValue());
        }

        SystemContainerAssignmentRepository systemRepo = mock(SystemContainerAssignmentRepository.class);
        when(systemRepo.queries()).thenReturn(queries);

        NeSearchable neQueries = mock(NeSearchable.class);
        systemAssignments.keySet().forEach(system -> when(neQueries.findBySystemContainerId(system.getId())).thenReturn(emptyList()));
        
        NeRepository neRepository = mock(NeRepository.class);
        when(neRepository.queries()).thenReturn(neQueries);
        
        RepositoryManager repo = mock(RepositoryManager.class);
        when(repo.getSystemContainerAssignmentRepository()).thenReturn(systemRepo);
        when(repo.getNeRepository()).thenReturn(neRepository);
        return repo;
    }

    private CommonServices commonService(SecureAction secAction, boolean allowed, Collection<? extends IManagedObjectId> items) {
        CommonServices commonServices = mock(CommonServices.class);
        SecureActionValidation validation = mock(SecureActionValidation.class);
        when(validation.checkPermission(secAction, items.toArray(new IManagedObjectId[0]))).thenReturn(allowed);
        when(commonServices.getSecureActionValidation()).thenReturn(validation);
        return commonServices;
    }
}