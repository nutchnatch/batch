package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.containerview;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.Collections;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.MOVE_NE_SAN;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_PROPERTIES_NE_SAN;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class NeToContainersTest extends TestsHelper {
    private NeToContainers neToContainers;
    private Collection<INEId> neIdsToDrop;
    private FullNeData neInsideSystemContainer;
    private ISystemContainer systemContainer;
    private ISystemContainer emptySystemContainer;
    private NEIdItem neIdToDrop;

    @Before public void setUp() throws Exception {
        neToContainers = new NeToContainers(repositoryManager, commonServices);

        neIdToDrop = new NEIdItem(ID_1);
        neIdsToDrop = Collections.singletonList(neIdToDrop);

        neInsideSystemContainer = buildFullNeData(ID_2, ID_2, "");
        neInsideSystemContainer.getNe().setAssociatedSystemContainerId(ID_3);

        systemContainer = buildSystemContainer(ID_3);
        emptySystemContainer = buildSystemContainer(ID_4);

        when(neSearchable.findBySystemContainerId(ID_3)).thenReturn(ImmutableList.of(neInsideSystemContainer));
        when(neSearchable.findBySystemContainerId(ID_4)).thenReturn(Collections.emptyList());
    }

    @Test public void testDropNesToSystemContainerAllowed_with_same_permissions() throws Exception {
        when(secureActionValidation.checkPermission(OP_PROPERTIES_NE_SAN, neIdToDrop)).thenReturn(true);
        when(secureActionValidation.checkPermission(OP_PROPERTIES_NE_SAN, neInsideSystemContainer.getNe())).thenReturn(true);
        when(secureActionValidation.checkPermission(MOVE_NE_SAN, neIdToDrop)).thenReturn(true);

        assertThat(neToContainers.canAccept(neIdsToDrop, systemContainer), is(true));
    }

    @Test public void testDropNesToSystemContainerNotAllowed_with_different_permissions() throws Exception {
        when(secureActionValidation.checkPermission(OP_PROPERTIES_NE_SAN, neIdToDrop)).thenReturn(true);
        when(secureActionValidation.checkPermission(OP_PROPERTIES_NE_SAN, neInsideSystemContainer.getNe())).thenReturn(false);
        when(secureActionValidation.checkPermission(MOVE_NE_SAN, neIdToDrop)).thenReturn(true);

        assertThat(neToContainers.canAccept(neIdsToDrop, systemContainer), is(false));
    }

    @Test public void testDropNesToSystemContainerAllowed_with_empty_system() throws Exception {
        when(secureActionValidation.checkPermission(OP_PROPERTIES_NE_SAN, neIdToDrop)).thenReturn(true);
        when(secureActionValidation.checkPermission(MOVE_NE_SAN, neIdToDrop)).thenReturn(true);

        assertThat(neToContainers.canAccept(neIdsToDrop, emptySystemContainer), is(true));
    }
}