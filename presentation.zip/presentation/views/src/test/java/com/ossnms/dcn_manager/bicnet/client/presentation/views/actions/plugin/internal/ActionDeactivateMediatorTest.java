package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_DEACTIVATE_MEDIATORS_SAN;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionDeactivateMediatorTest extends TestsHelper {

    private ActionDeactivateMediator actionDeactivateMediator;

    private FullMediatorData fullMediatorData;
    private FullChannelData fullChannelData;

    @Before public void setUp() throws Exception {
        fullMediatorData = buildFullMediatorData(ID_1);
        fullChannelData = buildFullChannelData(ID_2, ID_1);

        when(channelSearchable.findByParentId(ID_1)).thenReturn(ImmutableList.of(fullChannelData));

        actionDeactivateMediator = new ActionDeactivateMediator(repositoryManager, commonServices);
    }

    private <T extends IManagedObjectId> T[] withPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_DEACTIVATE_MEDIATORS_SAN, objectsToCheck)).thenReturn(true);
        return objectsToCheck;
    }

    private <T extends IManagedObjectId> T[] withoutPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_DEACTIVATE_MEDIATORS_SAN, objectsToCheck)).thenReturn(false);
        return objectsToCheck;
    }

    @Test public void testIsPluginActionAllowed() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.ENABLED);

        fullChannelData.getChannel().setActivation(EnableSwitch.DISABLED);
        fullChannelData.getChannel().setCommunicationState(CommunicationState.DISCONNECTED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        boolean pluginActionAllowed = actionDeactivateMediator
                .isPluginActionAllowed(withPermissions(fullMediatorData.getMediator()));

        assertTrue(pluginActionAllowed);
    }

    @Test public void testIsPluginActionAllowed_false_mediator_inactive() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.DISABLED);

        fullChannelData.getChannel().setActivation(EnableSwitch.DISABLED);
        fullChannelData.getChannel().setCommunicationState(CommunicationState.DISCONNECTED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        boolean pluginActionAllowed = actionDeactivateMediator
                .isPluginActionAllowed(withPermissions(fullMediatorData.getMediator()));

        assertFalse(pluginActionAllowed);
    }

    @Test public void testIsPluginActionAllowed_false_channel_deactivating() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.ENABLED);

        fullChannelData.getChannel().setActivation(EnableSwitch.DISABLED);
        fullChannelData.getChannel().setCommunicationState(CommunicationState.DISCONNECTING);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.DEACTIVATING);

        boolean pluginActionAllowed = actionDeactivateMediator
                .isPluginActionAllowed(withPermissions(fullMediatorData.getMediator()));

        assertFalse(pluginActionAllowed);
    }

    @Test public void testIsPluginActionAllowed_false_has_channels_active() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.ENABLED);

        fullChannelData.getChannel().setActivation(EnableSwitch.ENABLED);
        fullChannelData.getChannel().setCommunicationState(CommunicationState.CONNECTED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        boolean pluginActionAllowed = actionDeactivateMediator
                .isPluginActionAllowed(withPermissions(fullMediatorData.getMediator()));

        assertFalse(pluginActionAllowed);
    }

    @Test public void testIsPluginActionAllowed_false_no_permission() throws Exception {
        fullMediatorData.getMediator().setActivation(EnableSwitch.ENABLED);

        fullChannelData.getChannel().setActivation(EnableSwitch.DISABLED);
        fullChannelData.getChannel().setCommunicationState(CommunicationState.DISCONNECTED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        boolean pluginActionAllowed = actionDeactivateMediator
                .isPluginActionAllowed(withoutPermissions(fullMediatorData.getMediator()));

        assertFalse(pluginActionAllowed);
    }
}