package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediatorRoot;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class) public class NodeContainerMutationApplierTest extends TestsHelper {
    @Mock private GraphicalRepresentationBuilder<IGenericContainer> graphicalRepresentationBuilder;

    private NodeContainerMutationApplier nodeContainerMutationApplier;

    @Before public void setUp() throws Exception {
        nodeContainerMutationApplier = new NodeContainerMutationApplier(repositoryManager, commonServices,
                graphicalRepresentationBuilder);
    }

    @Test public void testApplyMutation() throws Exception {
        final IGenericContainer container = buildContainer(ID_1);
        container.setUserLabel("l1");

        final NodeContainer nodeContainer = buildNodeNeContainer(new NodeMediatorRoot("TNMS"), ID_1);

        nodeContainerMutationApplier.applyMutation(container, nodeContainer);

        assertThat(nodeContainer.getId(), is(ID_1));
        assertThat(nodeContainer.getValue().getName(), is(CONTAINER_NAME + ID_1));
        assertThat(nodeContainer.getColumns().valueOf(ColumnId.USER_TEXT).get().getValue(), is("l1"));
    }

    @Test public void testApplyMutation_no_usertext() throws Exception {
        final IGenericContainer container = buildContainer(ID_1);

        final NodeContainer nodeContainer = buildNodeNeContainer(new NodeMediatorRoot("TNMS"), ID_1);

        nodeContainerMutationApplier.applyMutation(container, nodeContainer);

        assertThat(nodeContainer.getId(), is(ID_1));
        assertThat(nodeContainer.getValue().getName(), is(CONTAINER_NAME + ID_1));
        assertThat(nodeContainer.getColumns().valueOf(ColumnId.USER_TEXT).get().getValue(), is(""));
    }

    @Test public void testLoadChildrenNodes() throws Exception {
        when(containerSearchable.findByParentId(ID_1))
                .thenReturn(ImmutableList.of(buildContainer(ID_2), buildContainer(ID_3)));
        when(containerSearchable.findByParentId(ID_2)).thenReturn(Collections.emptyList());
        when(containerSearchable.findByParentId(ID_3)).thenReturn(ImmutableList.of(buildContainer(ID_4)));
        when(neAssignmentSearchable.findByContainerId(anyInt())).thenReturn(Collections.emptyList());
        when(systemAssignmentSearchable.findByContainerId(anyInt())).thenReturn(Collections.emptyList());

        final NodeContainer nodeContainer = buildNodeNeContainer(new NodeMediatorRoot("TNMS"), ID_1);

        nodeContainerMutationApplier.loadChildrenNodes(nodeContainer);

        verify(containerSearchable, times(4)).findByParentId(anyInt());
        assertThat(nodeContainer.getAllChildren().size(), is(2));

        final Optional<Node> c2 = nodeContainer.getAllChildren().stream().filter(c -> c.getId() == ID_2).findFirst();
        assertTrue(c2.isPresent());
        assertTrue(c2.get().getAllChildren().isEmpty());

        final Optional<Node> c3 = nodeContainer.getAllChildren().stream().filter(c -> c.getId() == ID_3).findFirst();
        assertTrue(c3.isPresent());
        assertThat(c3.get().getAllChildren().size(), is(1));

        final Optional<Node> c4 = c3.get().getAllChildren().stream().filter(c -> c.getId() == ID_4).findFirst();
        assertTrue(c4.isPresent());
        assertTrue(c4.get().getAllChildren().isEmpty());
    }
}