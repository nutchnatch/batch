package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.delegate;

import com.coriant.widgets.treetable.TreeTable;
import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediatorRoot;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.TestCase.assertFalse;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionNewMediatorDelegateTest extends TestsHelper {

    @Mock private TreeTable<Node> treeTable;
    @Mock NewElementDialogHandler dialogHandler;

    private ActionNewMediatorDelegate actionNewMediatorDelegate;

    @Before public void setUp() throws Exception {
        actionNewMediatorDelegate = new ActionNewMediatorDelegate(treeTable, commonServices, dialogHandler);

        NodeMediatorRoot nodeMediatorRoot = buildNodeMediatorRoot();

        when(treeTable.getSelectedNodes()).thenReturn(ImmutableList.of(nodeMediatorRoot));
        when(secureActionValidation.checkPermission(SecureAction.OP_NEW_MEDIATOR_SAN)).thenReturn(true);
    }

    @Test public void testIsActionAllowed() throws Exception {
        boolean actionAllowed = actionNewMediatorDelegate.isActionAllowed(new IManagedObject[]{});
        assertTrue(actionAllowed);
    }

    @Test public void testIsActionAllowed_no_permission() throws Exception {
        when(secureActionValidation.checkPermission(SecureAction.OP_NEW_MEDIATOR_SAN)).thenReturn(false);

        boolean actionAllowed = actionNewMediatorDelegate.isActionAllowed(new IManagedObject[]{});
        assertFalse(actionAllowed);
    }

    @Test public void testIsActionAllowed_not_single_selection() throws Exception {
        when(treeTable.getSelectedNodes()).thenReturn(ImmutableList.of(buildNodeMediatorRoot(), buildNodeMediatorRoot()));

        boolean actionAllowed = actionNewMediatorDelegate.isActionAllowed(new IManagedObject[]{});
        assertFalse(actionAllowed);
    }

    @Test public void testIsActionAllowed_not_mediator_root() throws Exception {
        when(treeTable.getSelectedNodes()).thenReturn(ImmutableList.of(new NodeDomainRoot("domain")));

        boolean actionAllowed = actionNewMediatorDelegate.isActionAllowed(new IManagedObject[]{});
        assertFalse(actionAllowed);
    }

    @Test public void testEventActionPerformed() throws Exception {
        actionNewMediatorDelegate.eventActionPerformed(new IManagedObject[]{});

        verify(dialogHandler, times(1)).showNewMediatorDialog();
    }

    @Test public void testGetActionId() throws Exception {
        assertThat(actionNewMediatorDelegate.getMenuName(), is(TreeTableLabels.NEW_MEDIATOR));
    }

    @Test public void testGetMenuName() throws Exception {
        assertThat(actionNewMediatorDelegate.getActionId(), is(ActionNewMediatorDelegate.class.getName()));
    }
}