package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeActivationState;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_DEACTIVATE_CHANNELS_SAN;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionDeactivateChannelTest extends TestsHelper {

    private ActionDeactivateChannel actionDeactivateChannel;

    private FullChannelData fullChannelData;
    private FullNeData fullNeData;

    @Before public void setUp() throws Exception {
        fullChannelData = buildFullChannelData(ID_1, ID_2);
        fullNeData = buildFullNeData(ID_1, ID_1, "");

        when(neSearchable.findByParentId(ID_1)).thenReturn(ImmutableList.of(fullNeData));

        actionDeactivateChannel = new ActionDeactivateChannel(repositoryManager, commonServices);
    }

    private <T extends IManagedObjectId> T[] withPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_DEACTIVATE_CHANNELS_SAN, objectsToCheck)).thenReturn(true);
        return objectsToCheck;
    }

    private <T extends IManagedObjectId> T[] withoutPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_DEACTIVATE_CHANNELS_SAN, objectsToCheck)).thenReturn(false);
        return objectsToCheck;
    }

    @Test public void testIsPluginActionAllowed() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.ENABLED);

        fullNeData.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeData.getNe().setActualActivationState(NeActivationState.INACTIVE);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        boolean pluginActionAllowed = actionDeactivateChannel
                .isPluginActionAllowed(withPermissions(fullChannelData.getChannel()));

        assertTrue(pluginActionAllowed);
    }

    @Test public void testIsPluginActionAllowed_false_channel_inactive() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.DISABLED);

        fullNeData.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeData.getNe().setActualActivationState(NeActivationState.INACTIVE);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        boolean pluginActionAllowed = actionDeactivateChannel
                .isPluginActionAllowed(withPermissions(fullChannelData.getChannel()));

        assertFalse(pluginActionAllowed);
    }

    @Test public void testIsPluginActionAllowed_false_ne_deactivating() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.DISABLED);

        fullNeData.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeData.getNe().setActualActivationState(NeActivationState.INACTIVE);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.DEACTIVATING);

        boolean pluginActionAllowed = actionDeactivateChannel
                .isPluginActionAllowed(withPermissions(fullChannelData.getChannel()));

        assertFalse(pluginActionAllowed);
    }

    @Test public void testIsPluginActionAllowed_false_has_nes_active() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.ENABLED);

        fullNeData.getNe().setActivation(EnableSwitch.ENABLED);
        fullNeData.getNe().setActualActivationState(NeActivationState.ACTIVE);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        boolean pluginActionAllowed = actionDeactivateChannel
                .isPluginActionAllowed(withPermissions(fullChannelData.getChannel()));

        assertFalse(pluginActionAllowed);
    }

    @Test public void testIsPluginActionAllowed_false_no_permission() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.ENABLED);

        fullNeData.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeData.getNe().setActualActivationState(NeActivationState.INACTIVE);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        boolean pluginActionAllowed = actionDeactivateChannel
                .isPluginActionAllowed(withoutPermissions(fullChannelData.getChannel()));

        assertFalse(pluginActionAllowed);
    }
}