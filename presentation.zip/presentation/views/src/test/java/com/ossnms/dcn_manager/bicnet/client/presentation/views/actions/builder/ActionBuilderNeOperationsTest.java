package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.builder;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalContainerItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.api.action.PluginAction;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.delegate.ActionDuplicateDelegate;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionAssociateNeWithContainers;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionCopyNeNameToIdName;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionRemoveNeFromContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.DcnTreeTable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class) public class ActionBuilderNeOperationsTest {
    @Mock private RepositoryManager repositoryManager;
    @Mock private CommonServices commonServices;
    @Mock private DcnTreeTable table;

    private static final Collection<IManagedObject> VALID_VALUES = ImmutableList
            .of((IManagedObject) new NEItem(), new TopologicalSymbolItem());

    private static final Collection<IManagedObject> INVALID_VALUES = ImmutableList
            .of((IManagedObject) new TopologicalContainerItem(), new EMItem(), new MediatorItem());

    private static final Collection<IManagedObject> VALID_WITH_INVALID_TYPES = ImmutableList
            .of((IManagedObject) new EMItem(), new NEItem(), new MediatorItem());

    private ActionBuilderNeOperations actionBuilder;

    @Before public void setUp() throws Exception {
        actionBuilder = new ActionBuilderNeOperations(repositoryManager, commonServices, mock(NewElementDialogHandler.class));
    }

    @Test public void testValidActions() {
        final Collection<PluginAction> actions = actionBuilder.createList().actionsOf(VALID_VALUES);

        assertThat(actions.size(), is(6));
        assertThat(actions.stream().map(PluginAction::getMenuID).collect(Collectors.toList()),
                containsInAnyOrder(
                        ActionActivateNe.class.getName(),
                        ActionDeactivateNe.class.getName(),
                        ActionDuplicateDelegate.class.getName(),
                        ActionCopyNeNameToIdName.class.getName(),
                        ActionRemoveNeFromContainer.class.getName(),
                        ActionAssociateNeWithContainers.class.getName()));
    }

    @Test public void testInvalidActions() {
        final Collection<PluginAction> actions = actionBuilder.actionsOf(INVALID_VALUES);

        assertTrue(actions.isEmpty());
    }

    @Test public void testAllMatch() {
        assertTrue(actionBuilder.allMatch(VALID_VALUES));
    }

    @Test public void testAllMatch_valid_with_invalid_types() {
        assertFalse(actionBuilder.allMatch(VALID_WITH_INVALID_TYPES));
    }

    @Test public void testAllMatchFalse() {
        assertFalse(actionBuilder.allMatch(INVALID_VALUES));
    }

    @Test public void testActions() {
        assertTrue(actionBuilder.getActions().isEmpty());
    }
}