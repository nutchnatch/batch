package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandManager;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandRegistrar;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import java.util.AbstractMap;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Properties;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class RestoreViewsTest {
    
    private static final String DCN_OPEN_VIEWS_ID = "DCN.OpenViews";
    private static final FrameworkCommandID COMMAND_ID = new FrameworkCommandID("Command");
    
    private DcnPluginHelper pluginHelper;
    private IFrameworkCommand command;
    private ISecureClientSession clientSession;
    private RestoreViews restoreViews; 
    private SecureActionValidation secureValidation;
    
    @Before    
    public void setup() throws Exception {
        pluginHelper = mock(DcnPluginHelper.class);
        command = mock(IFrameworkCommand.class);
        clientSession = mock(ISecureClientSession.class);
        
        when(command.getCommandID()).thenReturn(COMMAND_ID);
        when(command.clone(null)).thenReturn(command);
        when(pluginHelper.getClientSession()).thenReturn(Optional.of(clientSession));
        
        secureValidation =  mock(SecureActionValidation.class);
        restoreViews = new RestoreViews(pluginHelper, ImmutableList.of(command), secureValidation);
        when(secureValidation.checkPermission(SecureAction.OPEN_MANAGEMENT_VIEW_SAN)).thenReturn(true);
    }
    
    @Test
    public void testSaveOpenedViews() {
        CurrentViewSingleton.getInstance().changeCurrentView(TreeTableViewTypes.DOMAIN);
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(command);
        FrameworkCommandManager.getCommandMgr().executeCmd(COMMAND_ID);  // Force to put the mock Command in active commands
        
        restoreViews.saveOpenedViews();
        
        final ArgumentCaptor<Properties> properties = ArgumentCaptor.forClass(Properties.class);
        final ArgumentCaptor<String> view = ArgumentCaptor.forClass(String.class);
        
        verify(clientSession).setUserProfile(view.capture(), properties.capture());
        
        assertNotNull(properties.getValue());
        assertNotNull(view.getValue());
        
        assertThat(properties.getValue().entrySet().size(), CoreMatchers.is(2));
        assertThat(properties.getValue().get(RestoreViews.CURRENT_VIEW).toString(), is(TreeTableViewTypes.DOMAIN.name()));
        assertThat(properties.getValue().get("Command.CMD").toString(), is(command.getCommandID().toString()));
    }
    
    @Test
    public void restoreOpenedViews() throws Exception {
        final Properties properties = mock(Properties.class);
        final Entry<Object,Object> entry = new AbstractMap.SimpleEntry<Object,Object>("Command.CMD", COMMAND_ID.toString());
        
        when(properties.entrySet()).thenReturn(ImmutableSet.of(entry));        
        when(clientSession.getUserProfile(DCN_OPEN_VIEWS_ID)).thenReturn(properties);
        
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(command);
        
        restoreViews.restoreOpenedViews();
                
        verify(clientSession, Mockito.times(1)).getUserProfile(DCN_OPEN_VIEWS_ID);
        verify(properties, Mockito.times(1)).entrySet();
        verify(command, Mockito.times(1)).execute(null);
    }
    
    @Test
    public void restoreOpenedViews_wrong_command_extention() throws Exception {
        final Properties properties = mock(Properties.class);
        final Entry<Object,Object> entry = new AbstractMap.SimpleEntry<Object,Object>("Command.C", COMMAND_ID.toString());
        
        when(properties.entrySet()).thenReturn(ImmutableSet.of(entry));        
        when(clientSession.getUserProfile(DCN_OPEN_VIEWS_ID)).thenReturn(properties);
        
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(command);
        
        restoreViews.restoreOpenedViews();
                
        verify(clientSession, Mockito.times(1)).getUserProfile(DCN_OPEN_VIEWS_ID);
        verify(properties, Mockito.times(1)).entrySet();
        verify(command, Mockito.never()).execute(null);
    }
    
    @Test
    public void restoreOpenedViews_profile_not_defined() throws Exception {            
        when(clientSession.getUserProfile(DCN_OPEN_VIEWS_ID)).thenReturn(null);
        
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(command);
        
        restoreViews.restoreOpenedViews();
        
        verify(clientSession, Mockito.times(1)).getUserProfile(DCN_OPEN_VIEWS_ID);
        verify(command, Mockito.never()).execute(null);
    }
}
