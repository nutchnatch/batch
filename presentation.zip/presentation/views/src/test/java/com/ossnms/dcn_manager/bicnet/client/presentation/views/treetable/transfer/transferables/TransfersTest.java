package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import org.junit.Test;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;

import static com.google.common.collect.ImmutableMap.of;
import static org.hamcrest.Matchers.arrayContainingInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class TransfersTest {

    @Test public void shouldJoinWithEmpty() throws Exception {
        DataFlavor first = new DataFlavor(INEId.MIME_TYPE);
        DataFlavor second = new DataFlavor(IEMId.MIME_TYPE);
        Transferable transferable = new Transfers(of(
                first, Object::new,
                second, Object::new));

        Transferable leftId = Transfers.join(transferable, Transfers.NO_TRANSFER);
        Transferable rightId = Transfers.join(Transfers.NO_TRANSFER, transferable);

        assertThat(leftId.getTransferDataFlavors(), is(rightId.getTransferDataFlavors()));
        assertThat(leftId.getTransferDataFlavors(), arrayContainingInAnyOrder(first, second));
        assertThat(rightId.getTransferDataFlavors(), arrayContainingInAnyOrder(first, second));
    }

    @Test public void shouldJoinBoth() throws Exception {
        DataFlavor first = new DataFlavor(INEId.MIME_TYPE);
        DataFlavor second = new DataFlavor(IEMId.MIME_TYPE);
        Transferable transferable1 = new Transfers(of(first, Object::new));
        Transferable transferable2 = new Transfers(of(second, Object::new));

        Transferable joined = Transfers.join(transferable1, transferable2);

        assertThat(joined.getTransferDataFlavors(), arrayContainingInAnyOrder(first, second));
    }
}