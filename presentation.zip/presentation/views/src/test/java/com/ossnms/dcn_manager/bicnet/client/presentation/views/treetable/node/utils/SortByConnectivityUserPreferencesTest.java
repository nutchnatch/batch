package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils;

import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainRoot;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;
import java.util.Properties;

import static java.util.Comparator.comparing;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class) public class SortByConnectivityUserPreferencesTest {
    @Mock private CommonServices commonServices;
    @Mock private DcnPluginHelper dcnPluginHelper;
    @Mock private ISecureClientSession secureClientSession;

    private SortByConnectivityUserPreferences sortByConnectivityUserPreferences;

    @Before public void setUp() throws Exception {
        sortByConnectivityUserPreferences = new SortByConnectivityUserPreferences(commonServices);

        when(commonServices.getDcnPluginHelper()).thenReturn(dcnPluginHelper);
        when(dcnPluginHelper.getPluginId()).thenReturn("plugin_id");
        when(dcnPluginHelper.getClientSession()).thenReturn(Optional.of(secureClientSession));
    }

    @Test public void testSetSortByConnectivityPreferences() throws Exception {
        NodeDomainRoot root = new NodeDomainRoot("root");

        NodeDomain nodeDomain = new NodeDomain(1, root, comparing(Object::toString, String::compareToIgnoreCase));
        nodeDomain.getValue().setName("domain_name");
        nodeDomain.setSelectedGneId(Optional.of(100));
        String sortByConnectivityId = sortByConnectivityUserPreferences.getSortByConnectivityId(nodeDomain);

        root.addChild(nodeDomain);

        Properties properties = new Properties();
        String removedDomainName = sortByConnectivityId + "old";

        properties.put(removedDomainName, "200");
        properties.put("other_key", "other_value");

        sortByConnectivityUserPreferences.setSortByConnectivityPreferences(root, properties);

        assertThat(properties.size(), is(2));
        assertNull(properties.getProperty(removedDomainName));
        assertThat(properties.getProperty("other_key"), is("other_value"));
        assertThat(properties.getProperty(sortByConnectivityId), is("100"));
    }

    @Test public void testLoadSortByConnectivityPreferences() throws Exception {
        NodeDomain nodeDomain = new NodeDomain(1, new NodeDomainRoot("root"),
                comparing(Object::toString, String::compareToIgnoreCase));
        nodeDomain.getValue().setName("domain_name");

        Properties properties = new Properties();
        properties.put(sortByConnectivityUserPreferences.getSortByConnectivityId(nodeDomain), "100");

        sortByConnectivityUserPreferences.loadSortByConnectivityPreferences(properties, nodeDomain);

        assertTrue(nodeDomain.getSelectedGneId().isPresent());
        assertThat(nodeDomain.getSelectedGneId().get(), is(100));
    }

    @Test public void testLoadSortByConnectivityPreferences_not_defined() throws Exception {
        NodeDomain nodeDomain = new NodeDomain(1, new NodeDomainRoot("root"),
                comparing(Object::toString, String::compareToIgnoreCase));
        nodeDomain.getValue().setName("domain_name");

        Properties properties = new Properties();
        properties.put(sortByConnectivityUserPreferences.getSortByConnectivityId(nodeDomain), "0");

        sortByConnectivityUserPreferences.loadSortByConnectivityPreferences(properties, nodeDomain);

        assertFalse(nodeDomain.getSelectedGneId().isPresent());
    }

    @Test public void testLoadUserPreferences() throws Exception {
        Properties propertiesLoaded = new Properties();
        when(secureClientSession.getUserProfile("plugin_id")).thenReturn(propertiesLoaded);

        Optional<Properties> properties = sortByConnectivityUserPreferences.loadUserPreferences();

        assertTrue(properties.isPresent());
        assertThat(properties.get(), is(propertiesLoaded));
    }

    @Test public void testLoadUserPreferences_not_present() throws Exception {
        when(secureClientSession.getUserProfile("plugin_id")).thenReturn(null);

        Optional<Properties> properties = sortByConnectivityUserPreferences.loadUserPreferences();
        assertFalse(properties.isPresent());
    }
}