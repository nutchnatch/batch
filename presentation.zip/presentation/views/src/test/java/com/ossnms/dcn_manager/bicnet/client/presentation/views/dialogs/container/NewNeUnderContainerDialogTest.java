package com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.container;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.FrameworkView;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeType;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;

import javax.swing.JComponent;
import javax.swing.JPanel;
import java.util.List;
import java.util.Optional;

import static java.util.Arrays.asList;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NewNeUnderContainerDialogTest {

    /**
     * Launcher to locally test layout
     */
    public static void main(String[] args) {
        List<NeType> neTypes = asList(type("Ne Type"), type("short"), type("soem long name asfd asdf asdf asdf "));
        List<FullChannelData> channels = asList(channel("Channel"), channel("seme long channel name asdf asdf asd f"));
        List<FullMediatorData> mediators = asList(mediator("Mediator Name"), mediator("some long mediator name asdf asdf asdf "));
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model(neTypes, channels, mediators));
        NewNeUnderContainerDialog dialog = new NewNeUnderContainerDialog(emptyView(), controller);
        dialog.showDialogWindow();
    }

    private static FrameworkView emptyView() {
        FrameworkDocument doc = mock(FrameworkDocument.class);
        return new FrameworkView("", "", doc, false, 0) {
            @Override protected JComponent getMainComponent() {
                return new JPanel();
            }
            @Override public void updateData(Object p_key) {
            }
        };
    }

    private static NewNeUnderContainerModel model(List<NeType> neTypes, List<FullChannelData> channels, List<FullMediatorData> mediators) {
        NewNeUnderContainerModel model = mock(NewNeUnderContainerModel.class);
        when(model.neTypes()).thenReturn(neTypes);
        when(model.channelsByNeTypeAndMediator(any(), any())).thenReturn(channels);
        when(model.mediatorsByNeType(any())).thenReturn(mediators);


        MediatorType mediatorType = mock(MediatorType.class);
        when(mediatorType.getName()).thenReturn("MEDIATOR");
        when(model.mediatorTypeFor(any())).thenReturn(mediatorType);

        ChannelType channelType = mock(ChannelType.class);
        when(channelType.getName()).thenReturn("CHANNEL");
        when(model.channelTypeFor(any())).thenReturn(channelType);

        GenericContainerItem containerItem = new GenericContainerItem();
        containerItem.setIdName("Some container");
        when(model.getContainer()).thenReturn(Optional.of(containerItem));
        
        return model;
    }

    private static FullMediatorData mediator(String idName) {
        MediatorItem mediator = new MediatorItem();
        mediator.setIdName(idName);
        mediator.setIconIdId("n_Mediator");
        return new FullMediatorData(mediator, null);
    }

    private static NeType type(String name) {
        NeType type = mock(NeType.class);
        when(type.guiLabel()).thenReturn(Optional.of(name));
        when(type.getName()).thenReturn(name);
        when(type.getDefaultIcon()).thenReturn("icon_pair_7090_default");
        return type;
    }

    private static FullChannelData channel(String idName) {
        EMItem em = new EMItem();
        em.setIdName(idName);
        em.setIconIdId("EM-GM");
        return new FullChannelData(em, null);
    }

}