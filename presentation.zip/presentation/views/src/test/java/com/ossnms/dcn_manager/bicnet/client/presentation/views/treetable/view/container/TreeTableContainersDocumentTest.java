package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.container;

import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class TreeTableContainersDocumentTest {
    private RepositoryManager repositoryManager;

    private CommonServices commonServices;
    private ListenersRegistrationManager changeListener;

    private ModelUpdater modelUpdater;
    private TreeTableContainersDocument document;

    @Before
    public void setup() throws RepositoryException {
        repositoryManager = mock(RepositoryManager.class);

        commonServices = mock(CommonServices.class);
        changeListener = mock(ListenersRegistrationManager.class);

        modelUpdater = mock(ModelUpdater.class);

        document = new TreeTableContainersDocument(commonServices, repositoryManager, changeListener);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testAddChangeListeners() {
        document.addChangeListeners(modelUpdater);

        verify(changeListener).addNeListener(Mockito.any(EventChangeListener.class));
        verify(changeListener).addContainerListener(Mockito.any(EventChangeListener.class));
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testRemoveChangeListeners() {
        document.removeChangeListeners();

        verify(changeListener).removeNeListener(Mockito.any(EventChangeListener.class));
        verify(changeListener).removeContainerListener(Mockito.any(EventChangeListener.class));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testGetObject() {
        document.getObject(null);
    }
}
