package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.elementMgmt.WriteAccessState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeActivationState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapabilities;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapability;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.Job;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobWriteAccessRequest;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_MOGCM_REQ_WRITE_ACC_SAN;
import static java.util.Optional.of;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionWriteAccessRequestTest extends TestsHelper {
    @Mock ChannelType channelType;

    private ActionWriteAccessRequest actionWriteAccessRequest;
    private FullNeData fullNeData;

    @Before public void setUp() throws Exception {
        fullNeData = buildFullNeData(ID_1, ID_1, "");
        fullNeData.getNe().setActualActivationState(NeActivationState.ACTIVE);
        fullNeData.getNe().setWriteAccessState(WriteAccessState.NO.getOrdinal());
        fullNeData.getNe().setCapabilities(NeCapabilities.of(NeCapability.WRITE_ACCESS));

        FullChannelData fullChannelData = buildFullChannelData(ID_1, ID_1);
        when(channelRepository.get(ID_1)).thenReturn(of(fullChannelData));
        when(staticConfiguration.findChannelType(anyString())).thenReturn(of(channelType));
        when(channelType.supportsNeCreation()).thenReturn(true);

        when(neRepository.get(ImmutableList.of(ID_1))).thenReturn(ImmutableList.of(fullNeData));

        actionWriteAccessRequest = new ActionWriteAccessRequest(repositoryManager, commonServices);
    }

    private <T extends IManagedObjectId> T[] withPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_MOGCM_REQ_WRITE_ACC_SAN, objectsToCheck)).thenReturn(true);
        for (T object : objectsToCheck) {
            when(secureActionValidation.checkPermission(OP_MOGCM_REQ_WRITE_ACC_SAN, object)).thenReturn(true);
        }
        return objectsToCheck;
    }

    private <T extends IManagedObjectId> T[] withoutPermissions(T... objectsToCheck) {
        when(secureActionValidation.checkPermission(OP_MOGCM_REQ_WRITE_ACC_SAN, objectsToCheck)).thenReturn(false);
        return objectsToCheck;
    }

    @Test public void testMenuName() throws Exception {
        assertThat(actionWriteAccessRequest.getMenuName(), is(TreeTableLabels.REQUEST_WRITE_ACCESS.toString()));
    }

    @Test public void testDescription() throws Exception {
        assertThat(actionWriteAccessRequest.getShortDescription(),
                is(TreeTableLabels.REQUEST_WRITE_ACCESS_DESC.toString()));
    }

    @Test public void testIsPluginAllowed_ok_for_INE_2_objects() throws Exception {
        FullNeData wrong = buildFullNeData(ID_2, ID_2, "");
        wrong.getNe().setActualActivationState(NeActivationState.ACTIVATING);

        boolean pluginActionAllowed = actionWriteAccessRequest
                .isPluginActionAllowed(withPermissions(fullNeData.getNe(), wrong.getNe()));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_for_INE() throws Exception {
        boolean pluginActionAllowed = actionWriteAccessRequest.isPluginActionAllowed(withPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_TOPO_SYMBOL() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        NEIdItem neId = new NEIdItem(ID_1);
        topologicalSymbol.setNetworkElement(neId);
        withPermissions(neId);
        ITopologicalSymbol[] toCheck = {topologicalSymbol};

        boolean pluginActionAllowed = actionWriteAccessRequest.isPluginActionAllowed(toCheck);

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_ok_system() throws Exception {
        ISystemContainer system = new SystemContainerItem();
        system.setId(ID_1);

        ISystemContainer[] objectsToCheck = {system};
        fullNeData.getNe().setAssociatedSystemContainerId(ID_1);

        when(neSearchable.findBySystemContainerId(ID_1)).thenReturn(ImmutableList.of(fullNeData));
        when(secureActionValidation.checkPermission(OP_MOGCM_REQ_WRITE_ACC_SAN, fullNeData.getNe())).thenReturn(true);

        boolean pluginActionAllowed = actionWriteAccessRequest
                .isPluginActionAllowed(withPermissions(objectsToCheck));

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void testIsPluginAllowed_no_permission() throws Exception {
        boolean pluginActionAllowed = actionWriteAccessRequest.isPluginActionAllowed(withoutPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_wrong_capability() throws Exception {
        fullNeData.getNe().setCapabilities(NeCapabilities.of(NeCapability.ADMIN_STATE_NO_CHANGE));

        boolean pluginActionAllowed = actionWriteAccessRequest.isPluginActionAllowed(withPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_wrong_write_access() throws Exception {
        fullNeData.getNe().setWriteAccessState(WriteAccessState.EXTERNAL.getOrdinal());

        boolean pluginActionAllowed = actionWriteAccessRequest.isPluginActionAllowed(withPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void testIsPluginAllowed_wrong_actual_state() throws Exception {
        fullNeData.getNe().setActualActivationState(NeActivationState.ACTIVATING);

        boolean pluginActionAllowed = actionWriteAccessRequest.isPluginActionAllowed(withPermissions(fullNeData.getNe()));

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void eventPluginActionPerformed_ok_for_INE() throws Exception {
        actionWriteAccessRequest.eventPluginActionPerformed(withPermissions(fullNeData.getNe()));

        verify(dcnPluginHelper, times(1)).queueJob(any(JobWriteAccessRequest.class));
    }

    @Test public void eventPluginActionPerformed_ok_for_TOPO() throws Exception {
        ITopologicalSymbol topologicalSymbol = new TopologicalSymbolItem();
        topologicalSymbol.setId(ID_2);
        NEIdItem neId = new NEIdItem(ID_1);
        topologicalSymbol.setNetworkElement(neId);
        withPermissions(neId);
        ITopologicalSymbol[] toCheck = {topologicalSymbol};

        actionWriteAccessRequest.eventPluginActionPerformed(toCheck);

        verify(dcnPluginHelper, times(1)).queueJob(any(JobWriteAccessRequest.class));
    }

    @Test public void testCreateJob() throws Exception {
        Collection<INEId> neIds = ImmutableList.of(new NEIdItem(ID_1));
        Job<INEId> job = actionWriteAccessRequest.createJob(neIds);
        assertThat(job.getClass().getName(), is(JobWriteAccessRequest.class.getName()));
    }

    @Test public void testSupportWriteAccessOperation_NO_WRITE_ACCESS() throws Exception {
        INE ne = fullNeData.getNe();
        ne.setWriteAccessState(WriteAccessState.NO.getOrdinal());
        ne.setCapabilities(NeCapabilities.of(NeCapability.WRITE_ACCESS));

        boolean supportWriteAccessOperation = actionWriteAccessRequest.supportsWriteAccessOperation(ne);
        assertThat(supportWriteAccessOperation, is(true));
    }

    @Test public void testGetSecureAction() throws Exception {
        SecureAction secureAction = actionWriteAccessRequest.getSecureAction();
        assertThat(secureAction, is(OP_MOGCM_REQ_WRITE_ACC_SAN));
    }
}
