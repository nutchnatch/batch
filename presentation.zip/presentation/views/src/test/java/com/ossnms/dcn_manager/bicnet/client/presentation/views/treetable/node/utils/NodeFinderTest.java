package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindNeNode;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindNodeByName;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindChannelNode;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindMediatorNode;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class NodeFinderTest extends TestsHelper {
    private Node root;

    @Before public void setUp() {
        root = buildNodeMediatorRoot();

        final NodeMediator nodeMediator1 = buildNodeMediator(root, ID_1);
        final NodeMediator nodeMediator2 = buildNodeMediator(root, ID_2);

        final NodeChannel nodeChannel1 = buildNodeChannel(nodeMediator1, ID_1);
        final NodeChannel nodeChannel2 = buildNodeChannel(nodeMediator1, ID_2);
        final NodeChannel nodeChannel3 = buildNodeChannel(nodeMediator2, ID_3);
        final NodeChannel nodeChannel4 = buildNodeChannel(nodeMediator2, ID_4);

        final NodeNe nodeNe1 = buildNodeNe(nodeChannel1, ID_1);
        final NodeNe nodeNe2 = buildNodeNe(nodeChannel1, ID_2);
        final NodeNe nodeNe3 = buildNodeNe(nodeChannel4, ID_3);
        final NodeNe nodeNe4 = buildNodeNe(nodeChannel2, ID_4);

        root.addChild(nodeMediator1);
        root.addChild(nodeMediator2);

        nodeMediator1.addChild(nodeChannel1);
        nodeMediator1.addChild(nodeChannel2);

        nodeMediator1.addChild(nodeChannel3);
        nodeMediator1.addChild(nodeChannel4);

        nodeChannel1.addChild(nodeNe1);
        nodeChannel1.addChild(nodeNe2);

        nodeChannel2.addChild(nodeNe4);

        nodeChannel4.addChild(nodeNe3);
    }

    @Test public void testTryFindByName() {
        assertTrue(tryFindNodeByName(root, "TNMS").findFirst().isPresent());

        assertTrue(tryFindNodeByName(root, MEDIATOR_NAME + ID_1).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, MEDIATOR_NAME + ID_2).findFirst().isPresent());

        assertTrue(tryFindNodeByName(root, CHANNEL_NAME + ID_1).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, CHANNEL_NAME + ID_2).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, CHANNEL_NAME + ID_3).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, CHANNEL_NAME + ID_4).findFirst().isPresent());

        assertTrue(tryFindNodeByName(root, NE_NAME + ID_1).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, NE_NAME + ID_2).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, NE_NAME + ID_3).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, NE_NAME + ID_4).findFirst().isPresent());
    }

    @Test public void testTryFindByName_not_found() {
        assertFalse(tryFindNodeByName(root, "not_exists").findFirst().isPresent());
    }

    @Test public void testTryFindMediator() throws Exception {
        assertTrue(tryFindMediatorNode(root, ID_1).isPresent());
        assertTrue(tryFindMediatorNode(root, ID_2).isPresent());
    }

    @Test public void testTryFindMediator_not_found() throws Exception {
        assertFalse(tryFindMediatorNode(root, ID_3).isPresent());
    }

    @Test public void testTryFindChannel() throws Exception {
        assertTrue(tryFindChannelNode(root, ID_1).isPresent());
        assertTrue(tryFindChannelNode(root, ID_2).isPresent());

        final Optional<NodeMediator> nodeMediator = tryFindMediatorNode(root, ID_1);
        assertTrue(nodeMediator.isPresent());
        assertTrue(tryFindChannelNode(nodeMediator.get(), ID_1).isPresent());
    }

    @Test public void testTryFindChannel_not_found() throws Exception {
        assertFalse(tryFindChannelNode(root, 100).isPresent());
    }

    @Test public void testTryFindNe() throws Exception {
        assertTrue(tryFindNeNode(root, ID_1).isPresent());
        assertTrue(tryFindNeNode(root, ID_2).isPresent());
        assertTrue(tryFindNeNode(root, ID_3).isPresent());
        assertTrue(tryFindNeNode(root, ID_4).isPresent());

        final Optional<NodeChannel> nodeChannel1 = tryFindChannelNode(root, ID_1);
        final Optional<NodeChannel> nodeChannel2 = tryFindChannelNode(root, ID_2);
        final Optional<NodeChannel> nodeChannel4 = tryFindChannelNode(root, ID_4);

        assertTrue(nodeChannel1.isPresent());
        assertTrue(nodeChannel2.isPresent());
        assertTrue(nodeChannel4.isPresent());

        assertTrue(tryFindNeNode(nodeChannel1.get(), ID_1).isPresent());
        assertTrue(tryFindNeNode(nodeChannel1.get(), ID_2).isPresent());
        assertTrue(tryFindNeNode(nodeChannel4.get(), ID_3).isPresent());
        assertTrue(tryFindNeNode(nodeChannel2.get(), ID_4).isPresent());
    }

    @Test public void testTryFindNe_not_found() throws Exception {
        assertFalse(tryFindChannelNode(root, 100).isPresent());
    }
}
