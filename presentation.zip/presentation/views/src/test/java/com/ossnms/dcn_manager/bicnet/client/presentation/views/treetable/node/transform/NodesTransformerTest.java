package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.transform;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;

import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NodesTransformerTest {
   
    private Repository<Integer, IMediator> mediatorRepository;
    private Repository<Integer, FullNeData> neRepository;
    
    private Node nodeRoot;
    
    private NodeMediator nodeMediator1;
    private NodeMediator nodeMediator2;
    
    private NodeNe nodeNe1;
    private NodeNe nodeNe2;
    
    private IMediator mediator1;
    private IMediator mediator2;
    
    private INE ne1;
    private INE ne2;

    private SecureActionValidation secureActionValidation;
        
    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        nodeRoot = mock(Node.class);
        mediatorRepository = mock(Repository.class);
        neRepository = mock(Repository.class);
        secureActionValidation = mock(SecureActionValidation.class);
       
        mediator1 = mock(IMediator.class);
        mediator2 = mock(IMediator.class);
        
        ne1 = mock(INE.class);
        ne2 = mock(INE.class);
        
        nodeMediator1 = new NodeMediator(1, nodeRoot);
        nodeMediator2 = new NodeMediator(2, nodeRoot);
                
        nodeNe1 = new NodeNe(11, nodeRoot);
        nodeNe2 = new NodeNe(22, nodeRoot);
    }
    
    @Test
    public void testTranform() throws RepositoryException {
        when(mediatorRepository.get(ImmutableList.of(1,2))).thenReturn(ImmutableList.of(mediator1,mediator2));
        FullNeData ne1 = new FullNeData(this.ne1, new NeInfo(this.ne1.getId()), null);
        FullNeData ne2 = new FullNeData(this.ne2, new NeInfo(this.ne2.getId()), null);
        when(neRepository.get(ImmutableList.of(11,22))).thenReturn(ImmutableList.of(ne1, ne2));
        
        final Collection<Node> nodes = ImmutableList.of((Node) nodeMediator1, (Node)nodeMediator2, (Node)nodeNe1, (Node)nodeNe2);
        
        final Iterable<IManagedObject> managedObjects = NodesTransformer.from(nodes)
                                                                         .transform(mediatorRepository, NodeMediator.class)
                                                                         .transform(neRepository)
                                                                         .iterable();
        assertThat(Iterables.size(managedObjects), CoreMatchers.is(4));
        assertTrue(Iterables.contains(managedObjects, mediator1));
        assertTrue(Iterables.contains(managedObjects, mediator2));        
        assertTrue(Iterables.contains(managedObjects, this.ne1));
        assertTrue(Iterables.contains(managedObjects, this.ne2));
    }
    
    @Test
    public void testTranform_stopWhenTransformationHasValues() throws RepositoryException {
        when(mediatorRepository.get(ImmutableList.of(1,2))).thenReturn(ImmutableList.of(mediator1,mediator2));
        FullNeData ne1 = new FullNeData(this.ne1, new NeInfo(this.ne1.getId()), null);
        FullNeData ne2 = new FullNeData(this.ne2, new NeInfo(this.ne2.getId()), null);
        when(neRepository.get(ImmutableList.of(11,22))).thenReturn(ImmutableList.of(ne1, ne2));
        
        final Collection<Node> nodes = ImmutableList.of((Node) nodeMediator1, (Node)nodeMediator2, (Node)nodeNe1, (Node)nodeNe2);
        
        final Iterable<IManagedObject> managedObjects = NodesTransformer.from(nodes)
                                                                        .stopWhenFirstTransformationHasValues()
                                                                        .transform(mediatorRepository, NodeMediator.class)
                                                                        .transform(neRepository)
                                                                        .iterable();
        assertThat(Iterables.size(managedObjects), CoreMatchers.is(2));
        assertTrue(Iterables.contains(managedObjects, mediator1));
        assertTrue(Iterables.contains(managedObjects, mediator2));
    }
    
    @Test
    public void testTranform_NoDuplication() throws RepositoryException {
        when(mediatorRepository.get(ImmutableList.of(1,1))).thenReturn(ImmutableList.of(mediator1,mediator1));
        FullNeData ne1 = new FullNeData(this.ne1, new NeInfo(this.ne1.getId()), null);
        when(neRepository.get(ImmutableList.of(11,11))).thenReturn(ImmutableList.of(ne1, ne1));
        
        final Collection<Node> nodes = ImmutableList.of((Node) nodeMediator1, (Node)nodeMediator1, (Node)nodeNe1, (Node)nodeNe1);
        
        final Iterable<IManagedObject> managedObjects = NodesTransformer.from(nodes)
                                                                         .transform(mediatorRepository, NodeMediator.class)
                                                                         .transform(neRepository)
                                                                         .iterable();
        assertThat(Iterables.size(managedObjects), CoreMatchers.is(2));
        assertTrue(Iterables.contains(managedObjects, mediator1));
        assertTrue(Iterables.contains(managedObjects, this.ne1));
    }
}


