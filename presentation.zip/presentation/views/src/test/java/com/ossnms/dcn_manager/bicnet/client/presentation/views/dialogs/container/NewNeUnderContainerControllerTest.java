package com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.container;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeType;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.tools.jfx.JfxAutoCompleteComboBox;
import com.ossnms.tools.jfx.JfxAutoCompleteComboBox.DataItem;
import org.junit.Test;

import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.google.common.collect.ImmutableMap.of;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NewNeUnderContainerControllerTest {

    @Test public void shouldStartWithEmptyNeTypeSelected() throws Exception {
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model(emptyMap()));

        Object selectedNeType = controller.neTypesCombo().getSelectedItem();

        assertThat(selectedNeType, is(nullValue()));
    }

    @Test public void shouldStartWithDisabledOKButton() throws Exception {
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model(emptyMap()));

        boolean enabled = controller.getOkButtonModel().isEnabled();

        assertThat(enabled, is(false));
    }

    @Test public void shouldContainRegisteredNeTypesInCombo() throws Exception {
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model(of(
                neType("first type"), emptyMap(),
                neType("second type"), emptyMap())));

        DataItem[] neTypeItems = controller.neTypesCombo().getDataItems();

        assertThat(neTypeItems.length, is(2));
    }

    @Test public void shouldHaveWarningMessageInMediatorsComboForNotSelectedNeType() throws Exception {
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model(emptyMap()));

        controller.neTypesCombo().setSelectedItem(null); //deselect ne
        String mediatorMessage = message(controller.mediatorCombo());

        assertThat(mediatorMessage, is("Select NE Type"));
    }

    @Test public void shouldShowWarningMessageWhenNoMediatorConfiguredForSelectedNeType() throws Exception {
        MediatorType mediatorType = mediatorType("Mediator Type");
        NewNeUnderContainerModel model = model(of(
                neType("some ne type"), emptyMap()));
        when(model.mediatorTypeFor(any())).thenReturn(mediatorType);
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model);

        controller.neTypesCombo().setSelectedIndex(0); //select fist ne type
        String mediatorMessage = message(controller.mediatorCombo());

        assertThat(mediatorMessage, is("No configured Mediator Type found"));
    }

    @Test public void shouldPopulateMediatorsComboAfterNeTypeIsSelected() throws Exception {
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model(of(
                neType("first type"), of(
                        mediator("first mediator"), emptyList(),
                        mediator("second mediator"), emptyList()))));

        controller.neTypesCombo().setSelectedIndex(0); //select some ne type
        DataItem[] availableMediators = controller.mediatorCombo().getDataItems();

        assertThat(availableMediators.length, is(2));
    }

    @Test public void shouldSelectTheSmallestMediatorsAutomatically() throws Exception {
        FullMediatorData smallMediator = mediator("small Mediator");
        FullMediatorData bigMediator = mediator("big Mediator");
        NewNeUnderContainerModel model = model(of(
                neType("NE type"), of(
                        smallMediator, emptyList(),
                        bigMediator, emptyList())));
        when(model.numberOfNes(smallMediator)).thenReturn(10);
        when(model.numberOfNes(bigMediator)).thenReturn(100);
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model);

        controller.neTypesCombo().setSelectedIndex(0); //select some ne type
        Object selectedMediator = controller.mediatorCombo().getSelectedItem();

        assertThat(selectedMediator.toString(), is(smallMediator.getIdName()));
    }

    @Test public void shouldPopulateChannelsComboAfterNeMediatorIsSelected() throws Exception {
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model(of(
                neType("ne type"), of(
                        mediator("mediator"), asList(
                                channel("Channel 1"), 
                                channel("Channel 2"))))));

        controller.neTypesCombo().setSelectedIndex(0); //select some ne type
        DataItem[] availableChannels = controller.channelCombo().getDataItems();

        assertThat(availableChannels.length, is(2));
    }

    @Test public void shouldSelectTheSmallestChannelsOnMediatorSelection() throws Exception {
        FullChannelData big = channel("Channel Big");
        FullChannelData small = channel("Channel Small");
        NewNeUnderContainerModel model = model(of(
                neType("ne type"), of(
                        mediator("mediator"), asList(
                                big, 
                                small))));
        when(model.numberOfNes(big)).thenReturn(100);
        when(model.numberOfNes(small)).thenReturn(10);
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model);

        controller.neTypesCombo().setSelectedIndex(0); //select some ne type
        Object selectedMediator = controller.channelCombo().getSelectedItem();

        assertThat(selectedMediator.toString(), is("Channel Small"));
    }

    @Test public void shouldShowWarningMessageWhenNoChannelConfiguredForSelectedNeType() throws Exception {
        NeType singleNeType = neType("ne type");
        ChannelType channelType = channelType("Channel Type");
        NewNeUnderContainerModel model = model(of(
                singleNeType, of(
                        mediator("mediator"), emptyList())));
        when(model.channelTypeFor(singleNeType)).thenReturn(channelType);
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model);

        controller.neTypesCombo().setSelectedIndex(0); //select fist ne type
        String channelMessage = message(controller.channelCombo());

        assertThat(channelMessage, is("No configured Channel Type found"));
    }

    @Test public void shouldHaveWarningMessageInChannelsComboForNotSelectedNeType() throws Exception {
        NewNeUnderContainerController controller = new NewNeUnderContainerController(mock(NewNeUnderContainerModel.class));

        controller.neTypesCombo().setSelectedItem(null); //deselect ne
        String channelMessage = message(controller.channelCombo());

        assertThat(channelMessage, is("Select NE Type"));
    }

    @Test public void shouldEnableOKButtonOnSelectedChannel() throws Exception {
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model(of(
                neType("ne type"), of(
                        mediator("mediator"), asList(
                                channel("Channel 1"),
                                channel("Channel 2"))))));

        controller.neTypesCombo().setSelectedIndex(0); //select some ne type -> automatically selects channel
        boolean okButtonEnabled = controller.getOkButtonModel().isEnabled();

        assertThat(okButtonEnabled, is(true));
    }

    @Test public void shouldDisableOKButtonOnDeselectedChannel() throws Exception {
        NewNeUnderContainerController controller = new NewNeUnderContainerController(model(of(
                neType("ne type"), of(
                        mediator("mediator"), asList(
                                channel("Channel 1"),
                                channel("Channel 2"))))));

        controller.neTypesCombo().setSelectedIndex(0); //select some ne type -> automatically selects channel
        controller.channelCombo().setSelectedItem(null); //deselect channel
        boolean okButtonEnabled = controller.getOkButtonModel().isEnabled();

        assertThat(okButtonEnabled, is(false));
    }

    private NewNeUnderContainerModel model(Map<NeType, Map<FullMediatorData, Collection<FullChannelData>>> neToMedToChannel) {
        NewNeUnderContainerModel model = mock(NewNeUnderContainerModel.class);
        when(model.neTypes()).thenReturn(neToMedToChannel.keySet());
        neToMedToChannel.forEach((neType, medToCh) ->
                when(model.mediatorsByNeType(neType)).thenReturn(medToCh.keySet()));
        neToMedToChannel.forEach((neType, medToCh) -> medToCh.forEach((mediator, channels) ->
                when(model.channelsByNeTypeAndMediator(neType, mediator)).thenReturn(channels)));
        return model;
    }

    private String message(JfxAutoCompleteComboBox combo) {
        return Objects.toString(combo.getSelectedItem());
    }

    private ChannelType channelType(String name) {
        ChannelType channelType = mock(ChannelType.class);
        when(channelType.guiLabel()).thenReturn(Optional.of(name));
        return channelType;
    }

    private FullChannelData channel(String name) {
        EMItem em = new EMItem();
        em.setIdName(name);
        em.setId(name.hashCode()); //some unique id
        return new FullChannelData(em, new ChannelInfo(0));
    }

    private MediatorType mediatorType(String name) {
        MediatorType mediatorType = mock(MediatorType.class);
        when(mediatorType.getName()).thenReturn(name);
        when(mediatorType.guiLabel()).thenReturn(Optional.of(name));
        return mediatorType;
    }

    private FullMediatorData mediator(String name) {
        MediatorItem mediator = new MediatorItem();
        mediator.setIdName(name);
        mediator.setId(name.hashCode()); //some unique id
        return new FullMediatorData(mediator, new MediatorInfo(1));
    }

    private NeType neType(String name) {
        NeType neType = mock(NeType.class);
        when(neType.getName()).thenReturn(name);
        return neType;
    }
}