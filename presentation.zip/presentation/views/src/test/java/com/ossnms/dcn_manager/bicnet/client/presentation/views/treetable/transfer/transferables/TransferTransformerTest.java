package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import org.junit.Test;

import java.awt.datatransfer.Transferable;
import java.util.Collection;

import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toList;
import static java.util.stream.IntStream.iterate;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class TransferTransformerTest {

    @Test public void shouldExtractBackFromTransferable() throws Exception {
        TransferTransformer<INEId> transformer = new Nes();
        Collection<IManagedObject> managedObjects = asList(ne(1), ne(2), ne(3));

        Transferable transferable = transformer.transferable(managedObjects);
        Collection<INEId> extracted = transformer.extract(transferable);

        assertThat(extracted, is(managedObjects));
    }

    @Test public void shouldBeAbleToReadFromTransferableSeveralTimes() throws Exception {
        TransferTransformer<INEId> transformer = new Nes();
        Collection<IManagedObject> managedObjects = asList(ne(1), ne(2), ne(3));

        Transferable transferable = transformer.transferable(managedObjects);
        Collection<Collection<INEId>> multipleTimes = iterate(0, i -> i + 1)
                .limit(10)
                .mapToObj(i -> transformer.extract(transferable))
                .collect(toList());

        multipleTimes.forEach(extracted -> assertThat(extracted, is(managedObjects)));
    }

    private NEItem ne(int id) {
        NEItem neItem = new NEItem();
        neItem.setId(id);
        return neItem;
    }
}