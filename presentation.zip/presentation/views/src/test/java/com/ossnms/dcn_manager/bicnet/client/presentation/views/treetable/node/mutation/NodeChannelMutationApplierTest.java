package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.coriant.widgets.icons.DoubleIcon;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.ChannelGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class NodeChannelMutationApplierTest extends TestsHelper {

    @Mock private ChannelGraphicalRepresentationBuilder graphicalRepresentationBuilder;

    private NodeChannelMutationApplier channelMutationApplier;
    private NodeChannel nodeChannel;
    private FullChannelData fullChannelData;

    public NodeChannelMutationApplierTest() {
    }

    @Before public void setUp() throws Exception {
        this.channelMutationApplier = new NodeChannelMutationApplier(repositoryManager, commonServices,
                graphicalRepresentationBuilder);

        nodeChannel = new NodeChannel(ID_1, new NodeMediator(ID_1, buildNodeMediatorRoot()));
        fullChannelData = buildFullChannelData(ID_1, ID_1);

        when(graphicalRepresentationBuilder.getIconManager()).thenReturn(new IconManager());
        when(secureActionValidation.checkPermission(any(SecureAction.class), any(IEM.class))).thenReturn(true);
        when(secureActionValidation.checkPermission(any(SecureAction.class))).thenReturn(true);
    }

    @Test public void testApplyMutation() throws Exception {
        when(graphicalRepresentationBuilder.build(any(FullChannelData.class))).thenReturn(any(DoubleIcon.class));

        channelMutationApplier.applyMutation(fullChannelData, nodeChannel);

        IEM m = fullChannelData.getChannel();

        assertThat(nodeChannel.getColumns().valueOf(ColumnId.ADDRESS).get().getValue(), is(m.getDisplayAddress()));
        assertThat(nodeChannel.getColumns().valueOf(ColumnId.INFO).get().getValue(), is(m.getAdditionalInfo()));
        assertThat(nodeChannel.getColumns().valueOf(ColumnId.STATE).get().getValue(), is(m.getDisplayState()));
        assertThat(nodeChannel.getColumns().valueOf(ColumnId.TYPE).get().getValue(), is(m.getEmType()));

        assertThat(nodeChannel.getColumns().valueOf(ColumnId.STANDBY_STATE).get().getValue(),
                is(fullChannelData.getInfo().getStandbyDisplayState().orElse(EMPTY)));

        assertThat(nodeChannel.getColumns().valueOf(ColumnId.USER_TEXT).get().getValue(),
                is(fullChannelData.getInfo().getUserText().orElse(EMPTY)));
    }

    @Test public void testApplyToogleButtonChanges_active() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.ENABLED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        channelMutationApplier.applyToogleButtonChanges(fullChannelData, nodeChannel);

        assertThat(nodeChannel.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeChannel.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeChannel.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_active_with_children_active() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.ENABLED);
        fullChannelData.getChannel().setCommunicationState(CommunicationState.CONNECTED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        NodeNe nodeNe = new NodeNe(ID_1, nodeChannel);
        nodeNe.getValue().setToogleButtonChecked(true);
        nodeNe.getValue().setActualActivationState(GuiActualActivationState.ACTIVE);
        nodeChannel.addChild(nodeNe);

        channelMutationApplier.applyToogleButtonChanges(fullChannelData, nodeChannel);

        assertThat(nodeChannel.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeChannel.getValue().isToogleButtonEnable(), is(false));

        assertThat(nodeChannel.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_active_with_children_inactive() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.ENABLED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        NodeNe nodeNe = new NodeNe(ID_1, nodeChannel);
        nodeNe.getValue().setToogleButtonChecked(false);
        nodeChannel.addChild(nodeNe);

        channelMutationApplier.applyToogleButtonChanges(fullChannelData, nodeChannel);

        assertThat(nodeChannel.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeChannel.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeChannel.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_inactive_disabled() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.DISABLED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        channelMutationApplier.applyToogleButtonChanges(fullChannelData, nodeChannel);

        assertThat(nodeChannel.getValue().isToogleButtonChecked(), is(false));
        assertThat(nodeChannel.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeChannel.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_inactive_enabled() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.DISABLED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        channelMutationApplier.applyToogleButtonChanges(fullChannelData, nodeChannel);

        assertThat(nodeChannel.getValue().isToogleButtonChecked(), is(false));
        assertThat(nodeChannel.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeChannel.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_deactivating() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.DISABLED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.DEACTIVATING);

        channelMutationApplier.applyToogleButtonChanges(fullChannelData, nodeChannel);

        assertThat(nodeChannel.getValue().isToogleButtonChecked(), is(false));
        assertThat(nodeChannel.getValue().isToogleButtonEnable(), is(false));

        assertThat(nodeChannel.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_activating() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.ENABLED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVATING);

        channelMutationApplier.applyToogleButtonChanges(fullChannelData, nodeChannel);

        assertThat(nodeChannel.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeChannel.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeChannel.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_failed() throws Exception {
        fullChannelData.getChannel().setActivation(EnableSwitch.ENABLED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.FAILED);

        channelMutationApplier.applyToogleButtonChanges(fullChannelData, nodeChannel);

        assertThat(nodeChannel.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeChannel.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeChannel.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_noPermission() throws Exception {
        when(secureActionValidation.checkPermission(any(SecureAction.class), any())).thenReturn(false);

        fullChannelData.getChannel().setActivation(EnableSwitch.ENABLED);
        fullChannelData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        channelMutationApplier.applyToogleButtonChanges(fullChannelData, nodeChannel);

        assertThat(nodeChannel.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeChannel.getValue().isToogleButtonEnable(), is(false));

        assertThat(nodeChannel.getValue().isToogleButtonVisible(), is(true));
    }
}
