package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.IMoFacet;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainerRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;

import static com.ossnms.dcn_manager.bicnet.client.api.Containers.ROOT_CONTAINER_ID;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SystemContainerTreeNodeEventListenerTest extends TestsHelper {
    @Mock private ModelUpdater modelUpdater;
    @Mock private GraphicalRepresentationBuilder<ISystemContainer> graphicalRepresentationBuilder;
    @Mock private NodeContainerRoot containerRoot;

    private SystemContainerTreeNodeEventListener containerEventListener;

    @Before public void setUp() throws Exception {
        containerEventListener = new SystemContainerTreeNodeEventListener(modelUpdater, commonServices,
                repositoryManager, graphicalRepresentationBuilder);

        containerRoot = new NodeContainerRoot("Root");

        when(modelUpdater.getNodeRoot()).thenReturn(containerRoot);
        when(graphicalRepresentationBuilder.getIconManager()).thenReturn(new IconManager());
    }

    @Test public void testRemove() throws Exception {
        ISystemContainer containerBcb = buildSystemContainer(ID_1);
        NodeSystemContainer nodeContainer = buildNodeSystemContainer(containerRoot, ID_1);
        containerRoot.addChild(nodeContainer);

        containerEventListener.remove(containerBcb);

        assertTrue(nodeContainer.getAllChildren().isEmpty());
        verify(modelUpdater, atLeastOnce()).removeNode(nodeContainer);
    }

    @Test public void testAdd() throws Exception {
        ISystemContainer containerBcb = buildSystemContainer(ID_1);
        when(systemAssignmentSearchable.findBySystemContainerId(ID_1)).thenReturn(Arrays.asList(new SystemGenericContainerAssignmentItem(new IMoFacet[]{}, ID_1, ROOT_CONTAINER_ID, true)));

        containerEventListener.add(containerBcb);
        assertThat(containerRoot.getAllChildren().size(), is(1));
        verify(modelUpdater, atLeastOnce()).insertNode(any(NodeContainer.class));
    }

    @Test public void testUpdate() throws Exception {
        ISystemContainer containerBcb = buildSystemContainer(ID_1);
        containerBcb.setIdName("new_name");

        NodeSystemContainer nodeContainer = buildNodeSystemContainer(containerRoot, ID_1);
        containerRoot.addChild(nodeContainer);

        containerEventListener.update(containerBcb);

        assertThat(containerRoot.getAllChildren().size(), is(1));
        assertThat(nodeContainer.getValue().getName(), is("new_name"));
        verify(modelUpdater, atLeastOnce()).applyStructureChanged(any(NodeContainer.class));
    }
}