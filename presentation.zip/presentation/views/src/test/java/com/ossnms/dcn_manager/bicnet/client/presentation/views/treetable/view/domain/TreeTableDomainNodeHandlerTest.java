package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.domain;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeHandler;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.DomainRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;

import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TreeTableDomainNodeHandlerTest {

    private static final int NE_ID = 3;
    private static final int DOMAIN_ID = 1;

    private NodeHandler nodeHandler;

    private TreeTableDomainsDocument document;

    private NodeDomain nodeDomain;
    private NodeNe nodeNe;

    private INE ne;
    private IAS domain;

    private RepositoryManager repositoryManager;
    private DomainRepository domainRepository;
    private NeRepository neRepository;

    @Before
    public void setup() throws RepositoryException {
        document = mock(TreeTableDomainsDocument.class);

        nodeDomain = mock(NodeDomain.class);
        nodeNe = mock(NodeNe.class);

        ne = mock(INE.class);
        domain = mock(IAS.class);

        repositoryManager = mock(RepositoryManager.class);
        domainRepository = mock(DomainRepository.class);
        neRepository = mock(NeRepository.class);

        when(document.getRepositoryManager()).thenReturn(repositoryManager);
        when(repositoryManager.getDomainRepository()).thenReturn(domainRepository);
        when(repositoryManager.getNeRepository()).thenReturn(neRepository);

        when(domainRepository.get(ImmutableList.of(DOMAIN_ID))).thenReturn(ImmutableList.of(domain));
        FullNeData element = new FullNeData(ne, new NeInfo(ne.getId()), null);
        when(neRepository.get(ImmutableList.of(NE_ID))).thenReturn(ImmutableList.of(element));
        
        when(domain.getId()).thenReturn(DOMAIN_ID);
        when(ne.getId()).thenReturn(NE_ID);
        
        when(nodeDomain.getId()).thenReturn(DOMAIN_ID);
        when(nodeNe.getId()).thenReturn(NE_ID);
                
        nodeHandler = new TreeTableDomainsNodeHandler(document);
    }
    
    @Test
    public void testTransformOnlyFirstMatchNodeType_with_all_types() throws RepositoryException {
        final Iterable<Node> nodes = ImmutableList.<Node>of(nodeNe, nodeDomain);
        
        final Collection<IManagedObject> manageObjects = ImmutableList.copyOf(nodeHandler.transformOnlyFirstMatchNodeType(nodes));
        
        assertThat(manageObjects.size(), CoreMatchers.is(1));
        assertThat(manageObjects.contains(domain), CoreMatchers.is(true));
    }
        
    @Test
    public void testTransformOnlyFirstMatchNodeType_only_nes() throws RepositoryException {
        final Iterable<Node> nodes = ImmutableList.<Node>of(nodeNe);
        
        final Collection<IManagedObject> manageObjects = ImmutableList.copyOf(nodeHandler.transformOnlyFirstMatchNodeType(nodes));
        
        assertThat(manageObjects.size(), CoreMatchers.is(1));
        assertThat(manageObjects.contains(ne), CoreMatchers.is(true));
    }
    
    @Test
    public void testTransformAllKnownNodeTypes() throws RepositoryException {
        final Iterable<Node> nodes = ImmutableList.<Node>of(nodeNe, nodeDomain);
        
        final Collection<IManagedObject> manageObjects = ImmutableList.copyOf(nodeHandler.transformAllKnownNodeTypes(nodes));
        
        assertThat(manageObjects.size(), CoreMatchers.is(2));
        assertThat(manageObjects.contains(ne), CoreMatchers.is(true));
        assertThat(manageObjects.contains(domain), CoreMatchers.is(true));
    }
}
