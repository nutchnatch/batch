package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeStatusInfo;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.swing.tree.TreeNode;
import java.util.Enumeration;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class NodeSystemContainerTest {

    private final NodeContainerRoot nodeRoot;

    private final ISystemContainer containerItem;
    private NodeSystemContainer nodeSystemContainer;

    private static final String NODE1_NAME = "NODE1";
    private static final String NODE2_NAME = "NODE2";
    private static final String NODE3_NAME = "NODE3";
    private static final String NE1_NAME = "NE1";

    public NodeSystemContainerTest() {
        nodeRoot = new NodeContainerRoot("TNMS");
        containerItem = createContainerItem();
    }

    @Before public void setup() {
        nodeSystemContainer = new NodeSystemContainer(containerItem.getId(), nodeRoot);
    }

    @Test public void testFindChildPresent() {
        Node container = new NodeSystemContainer(2, nodeSystemContainer);
        container.getValue().setName(NODE1_NAME);
        nodeSystemContainer.addChild(container);

        final Node node = nodeSystemContainer.findChild(2).get();

        assertThat(node.getId(), is(2));
    }

    @Test public void testFindChildNotPresent() {
        final Optional<Node> node = nodeSystemContainer.findChild(3);

        assertFalse(node.isPresent());
    }

    @Test public void testRemoveExistChild() {
        final Node child = new NodeNe(1, nodeSystemContainer);
        child.getValue().setName(NE1_NAME);
        nodeSystemContainer.addChild(child);

        assertTrue(nodeSystemContainer.removeChild(child));
    }

    @Test public void testRemoveNotExistChild() {
        final Node child1 = new NodeNe(1, nodeSystemContainer);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeNe(2, nodeSystemContainer);
        child2.getValue().setName(NODE2_NAME);

        nodeSystemContainer.addChild(child1);

        assertFalse(nodeSystemContainer.removeChild(child2));
    }

    @Test public void testGetChildIndex() {
        final Node child1 = new NodeNe(1, nodeSystemContainer);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeNe(2, nodeSystemContainer);
        child2.getValue().setName(NODE2_NAME);
        final Node child3 = new NodeNe(3, nodeSystemContainer);
        child3.getValue().setName(NODE3_NAME);

        nodeSystemContainer.addChild(child1);
        nodeSystemContainer.addChild(child2);

        assertThat(nodeSystemContainer.getIndex(child1), is(0));
        assertThat(nodeSystemContainer.getIndex(child2), is(1));
        assertThat(nodeSystemContainer.getIndex(child3), is(-1));
    }

    @Test public void testGetAllowsChildren() {
        assertTrue(nodeSystemContainer.getAllowsChildren());
    }

    @Test public void testIsLeaf() {
        assertTrue(nodeSystemContainer.isLeaf());
    }

    @Test public void testIsLeafFalse() {
        final Node child1 = new NodeNe(1, nodeSystemContainer);
        child1.getValue().setName(NODE1_NAME);
        nodeSystemContainer.addChild(child1);

        assertFalse(nodeSystemContainer.isLeaf());
    }

    @Test public void testGetColumnByPosition() {
        assertThat(nodeSystemContainer, is(nodeSystemContainer.getColumnByPosition(0)));
        assertThat(nodeSystemContainer, is(nodeSystemContainer.getColumnByPosition(0)));
    }

    @Test(expected = UnsupportedOperationException.class) public void testGetColumnByWrongPosition() {
        nodeSystemContainer.getColumnByPosition(100);
    }

    @Test public void testGets() {
        Assert.assertNotNull(nodeSystemContainer.getColumns());
        Assert.assertNotNull(nodeSystemContainer.getValue());

        assertThat(nodeSystemContainer.getId(), is(1));
    }

    @Test public void testChildren() {
        final Node child1 = new NodeNe(1, nodeSystemContainer);
        child1.getValue().setName(NODE1_NAME);
        final Node child2 = new NodeNe(2, nodeSystemContainer);
        child2.getValue().setName(NODE2_NAME);

        nodeSystemContainer.addChild(child1);
        nodeSystemContainer.addChild(child2);

        final Enumeration<TreeNode> nodes = nodeSystemContainer.children();

        int totalNodes = 0;

        while (nodes.hasMoreElements()) {
            nodes.nextElement();
            totalNodes++;
        }

        assertThat(nodeSystemContainer.getChildCount(), is(totalNodes));
    }

    @Test public void testToString() {
        assertThat(nodeSystemContainer.toString(), is(nodeSystemContainer.getValue().getName()));
    }

    @Test public void testHashCode() {

        final int hash1 = new NodeSystemContainer(1, nodeRoot).hashCode();
        final int hash2 = new NodeSystemContainer(2, nodeRoot).hashCode();
        final int hash3 = new NodeSystemContainer(1, new NodeRoot(2, "Root")).hashCode();

        assertThat(nodeSystemContainer.hashCode(), is(hash1));
        assertThat(nodeSystemContainer.hashCode(), not(is(hash2)));
        assertThat(nodeSystemContainer.hashCode(), not(is(hash3)));
    }

    @Test public void testEquals() {
        final NodeSystemContainer container1 = new NodeSystemContainer(1, nodeRoot);
        final NodeSystemContainer container2 = new NodeSystemContainer(2, nodeRoot);
        final NodeSystemContainer container3 = new NodeSystemContainer(1, new NodeRoot(2, "Root"));

        assertTrue(nodeSystemContainer.equals(container1));

        assertFalse(nodeSystemContainer.equals(container2));
        assertFalse(nodeSystemContainer.equals(container3));
        assertFalse(nodeSystemContainer.equals(new Object()));
    }
    
    @Test public void shouldHaveSameActivationStatesForOneChild() throws Exception {
        NodeSystemContainer system = new NodeSystemContainer(1, nodeRoot);
        withChildNe(system, 1, GuiActualActivationState.ACTIVATING);

        assertThat(system.hasChildrenWithDifferentActivations(), is(false));
    }

    @Test public void shouldHaveSameActivationStatesForNoChildren() throws Exception {
        NodeSystemContainer system = new NodeSystemContainer(1, nodeRoot);

        assertThat(system.hasChildrenWithDifferentActivations(), is(false));
    }

    @Test public void shouldHaveSameActivationStatesForChildrenWithSameActivation() throws Exception {
        NodeSystemContainer system = new NodeSystemContainer(1, nodeRoot);
        withChildNe(system, 1, GuiActualActivationState.INACTIVE);
        withChildNe(system, 2, GuiActualActivationState.INACTIVE);
        
        assertThat(system.hasChildrenWithDifferentActivations(), is(false));
    }

    @Test public void shouldHaveDifferentActivationStatesForChildrenWithDifferentActivation() throws Exception {
        NodeSystemContainer system = new NodeSystemContainer(1, nodeRoot);
        withChildNe(system, 1, GuiActualActivationState.INACTIVE);
        withChildNe(system, 2, GuiActualActivationState.ACTIVATING);

        assertThat(system.hasChildrenWithDifferentActivations(), is(true));
    }

    @Test public void shouldHaveDifferentActivationStatesForChildrenWithDifferentActivation_failed_state() throws Exception {
        NodeSystemContainer system = new NodeSystemContainer(1, nodeRoot);
        withChildNe(system, 1, GuiActualActivationState.FAILED);
        withChildNe(system, 2, GuiActualActivationState.FAILED);

        assertThat(system.hasChildrenWithDifferentActivations(), is(true));
    }

    @Test public void testTooltipDifferentStates() throws Exception {
        NodeSystemContainer system = new NodeSystemContainer(1, nodeRoot);
        system.getValue().setName("NodeContainer");
        withChildNe(system, 1, GuiActualActivationState.ACTIVE, ScsSyncState.SYNCHRONIZED);
        withChildNe(system, 2, GuiActualActivationState.ACTIVATING, ScsSyncState.OUT_OF_SYNC);

        final String toolTip = system.getToolTip(ToolTipType.NODE);

        assertThat(toolTip, containsString("<br /><b>Synchronization state: </b>Out of Sync (Partial)"));
        assertThat(toolTip, containsString("<br /><b>Communication state: </b>ACTIVATING (Partial)"));
    }

    @Test public void testTooltipDifferentStates_failed() throws Exception {
        NodeSystemContainer system = new NodeSystemContainer(1, nodeRoot);
        system.getValue().setName("NodeContainer");
        withChildNe(system, 1, GuiActualActivationState.INACTIVE, ScsSyncState.OUT_OF_SYNC);
        withChildNe(system, 2, GuiActualActivationState.FAILED, ScsSyncState.OUT_OF_SYNC);

        final String toolTip = system.getToolTip(ToolTipType.NODE);

        assertThat(toolTip, containsString("Synchronization state: </b>Out of Sync"));
        assertThat(toolTip, containsString("Communication state: </b>INACTIVE (Partial)"));
    }

    @Test public void testTooltipAllStateEquals() throws Exception {
        NodeSystemContainer system = new NodeSystemContainer(1, nodeRoot);
        system.getValue().setName("NodeContainer");
        withChildNe(system, 1, GuiActualActivationState.ACTIVE, ScsSyncState.SYNCHRONIZED);
        withChildNe(system, 2, GuiActualActivationState.ACTIVE, ScsSyncState.SYNCHRONIZED);

        final String toolTip = system.getToolTip(ToolTipType.NODE);

        assertThat(toolTip, containsString("Synchronization state: </b>Synchronized"));
        assertThat(toolTip, containsString("Communication state: </b>ACTIVE"));
        assertThat(toolTip, containsString("NE state: </b>In Operation"));
        assertThat(toolTip, not(containsString(TreeTableLabels.DIFFERENT_CHILDREN_ACTUAL_STATE_DESC.toString())));
    }

    @Test public void testTooltipAllStatePartial() throws Exception {
        NodeSystemContainer system = new NodeSystemContainer(1, nodeRoot);
        system.getValue().setName("NodeContainer");
        withChildNe(system, 1, GuiActualActivationState.ACTIVE, ScsSyncState.SYNCHRONIZED);
        withChildNe(system, 2, GuiActualActivationState.ACTIVE, ScsSyncState.SYNCHRONIZED)
                .setNeStatusInfo(new NeStatusInfo(2, OperationalState.DISABLED, EnableSwitch.DISABLED));

        final String toolTip = system.getToolTip(ToolTipType.NODE);

        assertThat(toolTip, containsString("Synchronization state: </b>Synchronized"));
        assertThat(toolTip, containsString("Communication state: </b>ACTIVE"));
        assertThat(toolTip, containsString("NE state: </b>Under Maintenance (Partial)"));
    }

    @Test public void testTooltipAllStateInactive() throws Exception {
        NodeSystemContainer system = new NodeSystemContainer(1, nodeRoot);
        system.getValue().setName("NodeContainer");
        withChildNe(system, 1, GuiActualActivationState.ACTIVE, ScsSyncState.SYNCHRONIZED);
        withChildNe(system, 2, GuiActualActivationState.INACTIVE, ScsSyncState.OUT_OF_SYNC)
                .setNeStatusInfo(new NeStatusInfo(2, OperationalState.DISABLED, EnableSwitch.DISABLED));

        final String toolTip = system.getToolTip(ToolTipType.NODE);

        assertThat(toolTip, containsString("Synchronization state: </b>Out of Sync (Partial)"));
        assertThat(toolTip, containsString("Communication state: </b>INACTIVE (Partial)"));
        assertThat(toolTip, not(containsString("NE state")));
    }

    private NodeNe withChildNe(NodeSystemContainer system, int id, GuiActualActivationState state, ScsSyncState syncState) {
        NodeNe nodeNe = new NodeNe(id, system);
        nodeNe.getValue().setToogleButtonChecked(true);
        nodeNe.getValue().setName("node_" + id);
        nodeNe.getValue().setActualActivationState(state);
        nodeNe.getColumns().setValue(ColumnId.STATE, state.toString());
        nodeNe.setSynchState(syncState);
        system.addChild(nodeNe);
        return nodeNe;
    }

    private void withChildNe(NodeSystemContainer system, int id, GuiActualActivationState state) {
        withChildNe(system, id, state, ScsSyncState.OUT_OF_SYNC);
    }

    private ISystemContainer createContainerItem() {
        final ISystemContainer containerItem = new SystemContainerItem();
        containerItem.setId(1);
        containerItem.setIdName("Container_IdName");
        return containerItem;
    }
}
