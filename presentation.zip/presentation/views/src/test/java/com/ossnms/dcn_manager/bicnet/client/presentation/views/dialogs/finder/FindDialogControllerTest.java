package com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.finder;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeRoot;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class FindDialogControllerTest  extends TestsHelper {

    private FindDialogController findDialogController;
    private NodeRoot nodeRoot;
    @Before public void setUp() throws Exception {
        nodeRoot = buildNodeMediatorRoot();

        NodeMediator nodeMediator = new NodeMediator(ID_1, nodeRoot);
        nodeMediator.getValue().setName("Mediator");
        nodeMediator.getColumns().valueOf(ColumnId.ADDRESS).get().value("mediator_address");

        NodeChannel nodeChannel = new NodeChannel(ID_1, nodeMediator);
        nodeChannel.getValue().setName("Channel");
        nodeChannel.getColumns().valueOf(ColumnId.ADDRESS).get().value("channel_address");

        NodeNe nodeNeVisible = new NodeNe(ID_1, nodeChannel);
        nodeNeVisible.getValue().setName("Ne");
        nodeNeVisible.getColumns().valueOf(ColumnId.NETWORK_NAME).get().value("networkName");
        nodeNeVisible.getColumns().valueOf(ColumnId.ADDRESS).get().value("ne_address");

        NodeNe nodeNeInvisible = new NodeNe(ID_2, nodeChannel);
        nodeNeInvisible.getValue().setName("Ne invisible");
        nodeNeInvisible.getValue().setVisible(false);
        nodeNeInvisible.getColumns().valueOf(ColumnId.NETWORK_NAME).get().value("networkName");
        nodeNeInvisible.getColumns().valueOf(ColumnId.ADDRESS).get().value("ne_address");

        nodeRoot.addChild(nodeMediator);
        nodeMediator.addChild(nodeChannel);
        nodeChannel.addChild(nodeNeVisible);
        nodeChannel.addChild(nodeNeInvisible);

        findDialogController = new FindDialogController(nodeRoot);
    }

    @Test public void testUpdateData() throws Exception {
        findDialogController.updateData();

        assertThat(findDialogController.getElements().size(), is(3)); //only visible

        // check order
        FindDialogElement channel = findDialogController.getElements().get(0);
        FindDialogElement mediator = findDialogController.getElements().get(1);
        FindDialogElement ne = findDialogController.getElements().get(2);

        assertThat(channel.getName(), is("Channel"));
        assertThat(channel.getAddress(), is("channel_address"));
        assertThat(channel.getFullName(), is("Channel"));

        assertThat(mediator.getName(), is("Mediator"));
        assertThat(mediator.getAddress(), is("mediator_address"));
        assertThat(mediator.getFullName(), is("Mediator"));

        assertThat(ne.getName(), is("Ne"));
        assertThat(ne.getAddress(), is("ne_address"));
        assertThat(ne.getFullName(), is("networkName"));
    }

    @Test public void testUpdateData_tryAdd_duplicated() throws Exception {
        NodeMediator nodeMediator = new NodeMediator(ID_1, nodeRoot);
        nodeMediator.getValue().setName("Mediator");
        nodeMediator.getColumns().valueOf(ColumnId.ADDRESS).get().value("mediator_address");

        nodeRoot.addChild(nodeMediator);

        findDialogController.updateData();

        assertThat(findDialogController.getElements().size(), is(3)); //only visible

        // check order
        FindDialogElement channel = findDialogController.getElements().get(0);
        FindDialogElement mediator = findDialogController.getElements().get(1);
        FindDialogElement ne = findDialogController.getElements().get(2);

        assertThat(channel.getName(), is("Channel"));
        assertThat(channel.getAddress(), is("channel_address"));
        assertThat(channel.getFullName(), is("Channel"));

        assertThat(mediator.getName(), is("Mediator"));
        assertThat(mediator.getAddress(), is("mediator_address"));
        assertThat(mediator.getFullName(), is("Mediator"));

        assertThat(ne.getName(), is("Ne"));
        assertThat(ne.getAddress(), is("ne_address"));
        assertThat(ne.getFullName(), is("networkName"));
    }
}