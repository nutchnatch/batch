package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.coriant.widgets.icons.DoubleIcon;
import com.google.common.collect.ImmutableSet;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.CurrentViewSingleton;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.TreeTableViewTypes;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeRouteInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class NodeNeMutationApplierTest extends TestsHelper {

    @Mock private NeGraphicalRepresentationBuilder graphicalRepresentationBuilder;

    private NodeNeMutationApplier neMutationApplier;
    private NodeNe nodeNe;
    private FullNeData fullNeData;

    public NodeNeMutationApplierTest() {
    }

    @Before public void setUp() throws Exception {
        CurrentViewSingleton.getInstance().changeCurrentView(TreeTableViewTypes.DOMAIN);

        this.neMutationApplier = new NodeNeMutationApplier(repositoryManager, commonServices,
                graphicalRepresentationBuilder);

        nodeNe = new NodeNe(ID_1, new NodeChannel(ID_1, new NodeMediator(ID_1, buildNodeMediatorRoot())));
        fullNeData = buildFullNeData(ID_1, ID_1, null);

        when(commonServices.getSecureActionValidation()).thenReturn(secureActionValidation);
        when(secureActionValidation.checkPermission(any(SecureAction.class), any(INE.class))).thenReturn(true);
        when(secureActionValidation.checkVisibility(any(INEId.class))).thenReturn(true);
    }

    @Test public void testApplyMutation() throws Exception {
        when(graphicalRepresentationBuilder.build(any(FullNeData.class))).thenReturn(icon());

        neMutationApplier.applyMutation(fullNeData, nodeNe);

        INE ne = fullNeData.getNe();

        assertThat(nodeNe.getColumns().valueOf(ColumnId.ADDRESS).get().getValue(), is(ne.getDisplayAddress()));
        assertThat(nodeNe.getColumns().valueOf(ColumnId.INFO).get().getValue(), is(ne.getAdditionalInfo()));
        assertThat(nodeNe.getColumns().valueOf(ColumnId.STATE).get().getValue(), is(ne.getDisplayState()));
        assertThat(nodeNe.getColumns().valueOf(ColumnId.TYPE).get().getValue(), is(ne.getNeProxyType()));
        assertThat(nodeNe.getColumns().valueOf(ColumnId.CONNECT_VIA).get().getValue(), is(ne.getConnectedVia()));
        assertThat(nodeNe.getColumns().valueOf(ColumnId.NETWORK_NAME).get().getValue(), is(ne.getRealNeName()));

        assertThat(nodeNe.getColumns().valueOf(ColumnId.STANDBY_STATE).get().getValue(),
                is(fullNeData.getInfo().getStandbyDisplayState().orElse(EMPTY)));

        assertThat(nodeNe.getColumns().valueOf(ColumnId.USER_TEXT).get().getValue(),
                is(fullNeData.getInfo().getUserText().orElse(EMPTY)));
        assertThat(nodeNe.getColumns().valueOf(ColumnId.LOCATION).get().getValue(), is(ne.getLocation()));
    }

    @Test public void testApplyMutation_syncStateMessage_synchronizing() throws Exception {
        when(graphicalRepresentationBuilder.build(any(FullNeData.class))).thenReturn(icon());

        fullNeData = buildFullNeData(ID_1, ID_1, null, ScsSyncState.SYNCHRONIZING);

        neMutationApplier.applyMutation(fullNeData, nodeNe);

        assertThat(nodeNe.getColumns().valueOf(ColumnId.INFO).get().getValue(),
                is("Synchronization state: Synchronizing"));
    }

    private DoubleIcon icon() {
        return mock(DoubleIcon.class);
    }

    @Test public void testApplyMutation_syncStateMessage_out_of_sync() throws Exception {
        when(graphicalRepresentationBuilder.build(any(FullNeData.class))).thenReturn(icon());

        fullNeData = buildFullNeData(ID_1, ID_1, "Component1", ScsSyncState.OUT_OF_SYNC);

        neMutationApplier.applyMutation(fullNeData, nodeNe);

        assertThat(nodeNe.getColumns().valueOf(ColumnId.INFO).get().getValue(),
                is("Synchronization state: failed for Component1"));
    }

    @Test public void testApplyMutation_syncStateMessage_inactive() throws Exception {
        when(graphicalRepresentationBuilder.build(any(FullNeData.class))).thenReturn(icon());

        fullNeData = buildFullNeData(ID_1, ID_1, "Component1", ScsSyncState.OUT_OF_SYNC);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        neMutationApplier.applyMutation(fullNeData, nodeNe);

        assertThat(nodeNe.getColumns().valueOf(ColumnId.INFO).get().getValue(),
                is("info"));
    }

    @Test public void testApplyMutation_syncStateMessage_sync() throws Exception {
        when(graphicalRepresentationBuilder.build(any(FullNeData.class))).thenReturn(icon());

        fullNeData = buildFullNeData(ID_1, ID_1, null, ScsSyncState.SYNCHRONIZED);

        neMutationApplier.applyMutation(fullNeData, nodeNe);

        assertThat(nodeNe.getColumns().valueOf(ColumnId.INFO).get().getValue(),
                is("info"));
    }

    @Test public void testApplyMutation_typeColumn_subtype_value() throws Exception {
        when(graphicalRepresentationBuilder.build(any(FullNeData.class))).thenReturn(icon());

        fullNeData.getNe().setNeSubType("subType");

        neMutationApplier.applyMutation(fullNeData, nodeNe);

        assertThat(nodeNe.getColumns().valueOf(ColumnId.TYPE).get().getValue(), is("subType"));
    }

    @Test public void testApplyMutation_routes_changed() throws Exception {
        when(graphicalRepresentationBuilder.build(any(FullNeData.class))).thenReturn(icon());

        final NeRouteInfo route1 = new NeRouteInfo("domain1", 1, "gne1");
        final NeRouteInfo route2 = new NeRouteInfo("domain2", 1, "gne1");

        fullNeData.getInfo().setNeRouteInfo(ImmutableSet.of(route1, route2));
        nodeNe.getRoutes().add(route1);

        assertThat(neMutationApplier.structureChanged(fullNeData, nodeNe), is(true));

        neMutationApplier.applyMutation(fullNeData, nodeNe);

        assertThat(nodeNe.getRoutes(), containsInAnyOrder(route1, route2));
    }

    @Test public void testApplyMutation_routes_same() throws Exception {
        when(graphicalRepresentationBuilder.build(any(FullNeData.class))).thenReturn(icon());

        final NeRouteInfo route1 = new NeRouteInfo("domain1", 1, "gne1");
        final NeRouteInfo route2 = new NeRouteInfo("domain2", 1, "gne1");

        fullNeData.getInfo().setNeRouteInfo(ImmutableSet.of(route1, route2));
        nodeNe.getRoutes().add(route2);
        nodeNe.getRoutes().add(route1);

        nodeNe.getValue().setName("name");
        fullNeData.getNe().setIdName("name");

        assertThat(neMutationApplier.structureChanged(fullNeData, nodeNe), is(false));

        neMutationApplier.applyMutation(fullNeData, nodeNe);

        assertThat(nodeNe.getRoutes(), containsInAnyOrder(route1, route2));
    }

    @Test public void testApplyToogleButtonChanges_active() throws Exception {
        fullNeData.getNe().setActivation(EnableSwitch.ENABLED);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        neMutationApplier.applyToogleButtonChanges(fullNeData, nodeNe);

        assertThat(nodeNe.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeNe.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeNe.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_inactive_disabled() throws Exception {
        fullNeData.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        neMutationApplier.applyToogleButtonChanges(fullNeData, nodeNe);

        assertThat(nodeNe.getValue().isToogleButtonChecked(), is(false));
        assertThat(nodeNe.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeNe.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_inactive_enabled() throws Exception {
        fullNeData.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        neMutationApplier.applyToogleButtonChanges(fullNeData, nodeNe);

        assertThat(nodeNe.getValue().isToogleButtonChecked(), is(false));
        assertThat(nodeNe.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeNe.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_deactivating() throws Exception {
        fullNeData.getNe().setActivation(EnableSwitch.DISABLED);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.DEACTIVATING);

        neMutationApplier.applyToogleButtonChanges(fullNeData, nodeNe);

        assertThat(nodeNe.getValue().isToogleButtonChecked(), is(false));
        assertThat(nodeNe.getValue().isToogleButtonEnable(), is(false));

        assertThat(nodeNe.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_activating() throws Exception {
        fullNeData.getNe().setActivation(EnableSwitch.ENABLED);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVATING);

        neMutationApplier.applyToogleButtonChanges(fullNeData, nodeNe);

        assertThat(nodeNe.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeNe.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeNe.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_failed() throws Exception {
        fullNeData.getNe().setActivation(EnableSwitch.ENABLED);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.FAILED);

        neMutationApplier.applyToogleButtonChanges(fullNeData, nodeNe);

        assertThat(nodeNe.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeNe.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeNe.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_noPermission() throws Exception {
        when(secureActionValidation.checkPermission(any(SecureAction.class), any(INE.class))).thenReturn(false);

        fullNeData.getNe().setActivation(EnableSwitch.ENABLED);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        neMutationApplier.applyToogleButtonChanges(fullNeData, nodeNe);

        assertThat(nodeNe.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeNe.getValue().isToogleButtonEnable(), is(false));

        assertThat(nodeNe.getValue().isToogleButtonVisible(), is(true));
    }
    
    @Test public void testApplyToogleButtonChanges_startingUp() throws Exception {
        fullNeData.getNe().setActivation(EnableSwitch.ENABLED);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.STARTINGUP);

        neMutationApplier.applyToogleButtonChanges(fullNeData, nodeNe);

        assertThat(nodeNe.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeNe.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeNe.getValue().isToogleButtonVisible(), is(true));
    }

    @Test public void testApplyToogleButtonChanges_shuttingDown() throws Exception {
        fullNeData.getNe().setActivation(EnableSwitch.ENABLED);
        fullNeData.getInfo().setGuiActualActivationState(GuiActualActivationState.SHUTTINGDOWN);

        neMutationApplier.applyToogleButtonChanges(fullNeData, nodeNe);

        assertThat(nodeNe.getValue().isToogleButtonChecked(), is(true));
        assertThat(nodeNe.getValue().isToogleButtonEnable(), is(true));

        assertThat(nodeNe.getValue().isToogleButtonVisible(), is(true));
    }

}
