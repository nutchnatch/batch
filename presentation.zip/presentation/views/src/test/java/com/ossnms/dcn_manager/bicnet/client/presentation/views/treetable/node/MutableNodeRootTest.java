package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class MutableNodeRootTest {

    @Test
    public void testEquals() {
        final ImmutableNodeRoot node = new ImmutableNodeRoot(1, "name");

        final ImmutableNodeRoot node1 = new ImmutableNodeRoot(1, "name");
        final ImmutableNodeRoot node2 = new ImmutableNodeRoot(1, "name_1");
        final ImmutableNodeRoot node3 = new ImmutableNodeRoot(2, "name");
        final ImmutableNodeRoot node4 = new ImmutableNodeRoot(4, "name_4");

        assertTrue(node.equals(node1));

        assertFalse(node.equals(node2));
        assertFalse(node.equals(node3));
        assertFalse(node.equals(node4));
        assertFalse(node.equals(null));
        assertFalse(node.equals(new Object()));
    }

    @Test
    public void testHashCode() {
        final ImmutableNodeRoot node = new ImmutableNodeRoot(1, "name");

        final int hash1 = new ImmutableNodeRoot(1, "name").hashCode();
        final int hash2 = new ImmutableNodeRoot(1, "name_1").hashCode();
        final int hash3 = new ImmutableNodeRoot(2, "name").hashCode();
        final int hash4 = new ImmutableNodeRoot(4, "name_4").hashCode();

        assertThat(node.hashCode(), is(hash1));
        assertThat(node.hashCode(), not(is(hash2)));
        assertThat(node.hashCode(), not(is(hash3)));
        assertThat(node.hashCode(), not(is(hash4)));
    }
}
