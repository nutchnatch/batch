package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.builder;

import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginAction;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionModeStateActive;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionModeStateMaintenance;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionModeStateOperational;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionResynchronize;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionWriteAccessEnforce;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionWriteAccessRelease;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionWriteAccessRequest;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateChannelOnStandby;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateMediatorOnStandby;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateNEsUnderChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateNEsUnderContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateNEsUnderDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateNEsUnderSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionActivateNeOnStandby;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionAssociateNeWithContainers;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionAssociateSystemWithContainers;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionContextMenuDelete;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionContextMenuDuplicate;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionContextMenuNew;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionCopyNeNameToIdName;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionCut;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateChannelOnStandby;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateMediatorOnStandby;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateNEsUnderChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateNEsUnderContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateNEsUnderDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateNEsUnderSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionDeactivateNeOnStandby;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionPaste;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionRemoveNeFromContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.internal.ActionResynchronizeNeOnStandby;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.DcnTreeTable;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers.CutPasteHandler;
import com.ossnms.dcn_manager.bicnet.client.propertypage.ActionOpenPropertyPage;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class) public class ContextMenuActionsFactoryTest extends TestsHelper {

    @Mock private DcnTreeTable treeTable;
    @Mock private NewElementDialogHandler dialogHandler;
    @Mock private CutPasteHandler cutPasteHandler;

    private ContextMenuActionsFactory privateActions;
    private ContextMenuActionsFactory publicActions;

    @Before public void setUp() throws Exception {
        publicActions = new ContextMenuActionsFactory(repositoryManager, commonServices);

        privateActions = new ContextMenuActionsFactory(dialogHandler,
                repositoryManager, commonServices, cutPasteHandler);
    }

    @Test public void testPublicActions_ForNE() throws Exception {
        final FullNeData fullNeData = buildFullNeData(ID_1, ID_2, "");

        final BiCNetPluginAction[] actions = publicActions.build(new INE[] { fullNeData.getNe() });

        assertThat(actions.length, is(7));

        final List<String> collect = Stream.of(actions).map(BiCNetPluginAction::getClass).map(Class::getName)
                .collect(Collectors.toList());

        assertTrue(collect.stream().anyMatch(s -> ActionWriteAccessRequest.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionWriteAccessRelease.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionWriteAccessEnforce.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionModeStateMaintenance.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionModeStateOperational.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionModeStateActive.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionResynchronize.class.getName().equals(s)));
    }

    @Test public void testPublicActions_ForSystem() throws Exception {
        final ISystemContainer systemContainer = buildSystemContainer(ID_1);

        final BiCNetPluginAction[] actions = publicActions.build(new ISystemContainer[] { systemContainer });

        assertThat(actions.length, is(7));

        final List<String> collect = Stream.of(actions).map(BiCNetPluginAction::getClass).map(Class::getName)
                .collect(Collectors.toList());

        assertTrue(collect.stream().anyMatch(s -> ActionWriteAccessRequest.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionWriteAccessRelease.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionWriteAccessEnforce.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionModeStateMaintenance.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionModeStateOperational.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionModeStateActive.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionResynchronize.class.getName().equals(s)));
    }

    @Test public void testPrivateActions_ForNE() throws Exception {
        final FullNeData fullNeData = buildFullNeData(ID_3, ID_1, "");
        final FullChannelData fullChannelData = buildFullChannelData(ID_1, ID_2);
        final FullMediatorData fullMediatorData = buildFullMediatorData(ID_2);

        fullMediatorData.getInfo().setStandbyMediatorConfigured(true);

        when(channelRepository.get(ID_1)).thenReturn(Optional.of(fullChannelData));
        when(mediatorRepository.get(ID_2)).thenReturn(Optional.of(fullMediatorData));

        final BiCNetPluginAction[] actions = privateActions.build(new INE[] { fullNeData.getNe() });

        assertThat(actions.length, is(12));

        final List<String> collect = Stream.of(actions).map(BiCNetPluginAction::getClass).map(Class::getName)
                .collect(Collectors.toList());

        assertTrue(collect.stream().anyMatch(s -> ActionActivateNe.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionDeactivateNe.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionContextMenuDuplicate.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionCut.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionCopyNeNameToIdName.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionRemoveNeFromContainer.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionActivateNeOnStandby.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionDeactivateNeOnStandby.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionResynchronizeNeOnStandby.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionContextMenuDelete.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionOpenPropertyPage.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionAssociateNeWithContainers.class.getName().equals(s)));
    }

    @Test public void testPrivateActions_ForSystems() throws Exception {
        final ISystemContainer systemContainer = buildSystemContainer(ID_1);

        final BiCNetPluginAction[] actions = privateActions.build(new ISystemContainer[] { systemContainer });

        assertThat(actions.length, is(8));

        final List<String> collect = Stream.of(actions).map(BiCNetPluginAction::getClass).map(Class::getName)
                .collect(Collectors.toList());

        assertTrue(collect.stream().anyMatch(s -> ActionContextMenuDelete.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionContextMenuNew.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionActivateNEsUnderSystemContainer.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionDeactivateNEsUnderSystemContainer.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionOpenPropertyPage.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionAssociateSystemWithContainers.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionCut.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionPaste.class.getName().equals(s)));
    }

    @Test public void testPrivateActions_ForContainers() throws Exception {
        final IGenericContainer container = buildContainer(ID_1);

        final BiCNetPluginAction[] actions = privateActions.build(new IGenericContainer[] { container });

        assertThat(actions.length, is(6));

        final List<String> collect = Stream.of(actions).map(BiCNetPluginAction::getClass).map(Class::getName)
                .collect(Collectors.toList());

        assertTrue(collect.stream().anyMatch(s -> ActionContextMenuDelete.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionActivateNEsUnderContainer.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionDeactivateNEsUnderContainer.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionCut.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionPaste.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionOpenPropertyPage.class.getName().equals(s)));
    }

    @Test public void testPrivateActions_ForDomain() throws Exception {
        final IAS domain = buildDomain(ID_1);

        final BiCNetPluginAction[] actions = privateActions.build(new IAS[] { domain });

        assertThat(actions.length, is(2));

        final List<String> collect = Stream.of(actions).map(BiCNetPluginAction::getClass).map(Class::getName)
                .collect(Collectors.toList());

        assertTrue(collect.stream().anyMatch(s -> ActionActivateNEsUnderDomain.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionDeactivateNEsUnderDomain.class.getName().equals(s)));
    }

    @Test public void testPrivateActions_ForMediator() throws Exception {
        final FullMediatorData fullMediatorData = buildFullMediatorData(ID_2);

        fullMediatorData.getInfo().setStandbyMediatorConfigured(true);

        when(mediatorRepository.get(ID_2)).thenReturn(Optional.of(fullMediatorData));

        final BiCNetPluginAction[] actions = privateActions.build(new IMediator[] { fullMediatorData.getMediator() });

        assertThat(actions.length, is(8));

        final List<String> collect = Stream.of(actions).map(BiCNetPluginAction::getClass).map(Class::getName)
                .collect(Collectors.toList());

        assertTrue(collect.stream().anyMatch(s -> ActionActivateMediator.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionDeactivateMediator.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionContextMenuNew.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionActivateMediatorOnStandby.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionDeactivateMediatorOnStandby.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionContextMenuDelete.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionOpenPropertyPage.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionPaste.class.getName().equals(s)));
    }

    @Test public void testPrivateActions_ForChannel() throws Exception {
        final FullChannelData fullChannelData = buildFullChannelData(ID_1, ID_2);
        final FullMediatorData fullMediatorData = buildFullMediatorData(ID_2);

        fullMediatorData.getInfo().setStandbyMediatorConfigured(true);

        when(mediatorRepository.get(ID_2)).thenReturn(Optional.of(fullMediatorData));

        final BiCNetPluginAction[] actions = privateActions.build(new IEM[] { fullChannelData.getChannel() });

        assertThat(actions.length, is(11));

        final List<String> collect = Stream.of(actions).map(BiCNetPluginAction::getClass).map(Class::getName)
                .collect(Collectors.toList());

        assertTrue(collect.stream().anyMatch(s -> ActionActivateChannel.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionDeactivateChannel.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionActivateNEsUnderChannel.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionDeactivateNEsUnderChannel.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionContextMenuNew.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionCut.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionPaste.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionActivateChannelOnStandby.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionDeactivateChannelOnStandby.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionContextMenuDelete.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionOpenPropertyPage.class.getName().equals(s)));
    }

    @Test public void testPrivateActions_ForTopoSymbol() throws Exception {
        ITopologicalSymbol symbol = new TopologicalSymbolItem();
        symbol.setNetworkElementId(ID_1);
        symbol.setId(ID_3);

        final BiCNetPluginAction[] actions = privateActions.build(new ITopologicalSymbol[] { symbol });

        assertThat(actions.length, is(6));

        final List<String> collect = Stream.of(actions).map(BiCNetPluginAction::getClass).map(Class::getName)
                .collect(Collectors.toList());

        assertTrue(collect.stream().anyMatch(s -> ActionActivateNe.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionDeactivateNe.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionContextMenuDuplicate.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionCopyNeNameToIdName.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionRemoveNeFromContainer.class.getName().equals(s)));
        assertTrue(collect.stream().anyMatch(s -> ActionAssociateNeWithContainers.class.getName().equals(s)));
    }
}
