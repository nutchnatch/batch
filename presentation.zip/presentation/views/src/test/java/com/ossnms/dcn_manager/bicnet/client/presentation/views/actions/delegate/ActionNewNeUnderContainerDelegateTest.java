package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.delegate;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import org.junit.Before;
import org.junit.Test;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_NEW_NE_SAN;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

public class ActionNewNeUnderContainerDelegateTest extends TestsHelper {

    private NewElementDialogHandler dialogHandler;
    private SecureActionValidation validation;
    private ActionNewNeUnderContainerDelegate delegate;

    @Before
    public void setUp() throws Exception {
        CommonServices commonServices = mock(CommonServices.class);

        validation = mock(SecureActionValidation.class);
        when(validation.checkPermission(OP_NEW_NE_SAN)).thenReturn(true);
        when(commonServices.getSecureActionValidation()).thenReturn(validation);

        dialogHandler = mock(NewElementDialogHandler.class);
        delegate = new ActionNewNeUnderContainerDelegate(dialogHandler, commonServices);
    }

    @Test
    public void shouldNotAllowWhenNoPermissions() throws Exception {
        when(validation.checkPermission(OP_NEW_NE_SAN)).thenReturn(false);

        boolean actionAllowed = delegate.isActionAllowed(new IManagedObject[]{});

        assertThat(actionAllowed, is(false));
    }

    @Test
    public void shouldNotAllowOnMultipleSelection() throws Exception {
        boolean actionAllowed = delegate.isActionAllowed(new IManagedObject[]{buildContainer(1), buildContainer(2)});

        assertThat(actionAllowed, is(false));
    }

    @Test
    public void shouldNotAllowForUnknownNode() throws Exception {

        boolean actionAllowed = delegate.isActionAllowed(new IManagedObject[]{buildDomain(1)});

        assertThat(actionAllowed, is(false));
    }

    @Test
    public void shouldCreateUnderSystemForSystemContainer() throws Exception {
        ISystemContainer system = buildSystemContainer(1);

        delegate.eventActionPerformed(new IManagedObject[]{system});

        verify(dialogHandler).showNewNeUnderSystemDialog(system);
    }

    @Test
    public void shouldCreateUnderContainerForNeContainer() throws Exception {
        IGenericContainer container = buildContainer(1);

        delegate.eventActionPerformed(new IManagedObject[]{container});

        verify(dialogHandler).showNewNeUnderContainerDialog(container);
    }
}