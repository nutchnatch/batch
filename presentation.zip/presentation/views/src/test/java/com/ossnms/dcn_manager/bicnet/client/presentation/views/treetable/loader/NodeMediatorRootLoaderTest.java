package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader;

import com.google.code.tempusfugit.temporal.Duration;
import com.google.code.tempusfugit.temporal.Timeout;
import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediatorRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;

import static com.google.code.tempusfugit.temporal.WaitFor.waitOrTimeout;
import static java.util.Optional.empty;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.when;

public class NodeMediatorRootLoaderTest extends TestsHelper {

    private NodeMediatorRootLoader nodeMediatorRootLoader;

    @Before public void setUp() throws Exception {
        NodeMediatorRoot nodeMediatorRoot = buildNodeMediatorRoot();

        FullMediatorData fullMediatorData = buildFullMediatorData(ID_1);
        FullChannelData fullChannelData = buildFullChannelData(ID_1, ID_1);
        FullNeData fullNeData = buildFullNeData(ID_1, ID_1, "");

        when(mediatorRepository.getAll()).thenReturn(ImmutableList.of(fullMediatorData));
        when(channelSearchable.findByParentId(ID_1)).thenReturn(ImmutableList.of(fullChannelData));
        when(neSearchable.findByParentId(ID_1)).thenReturn(ImmutableList.of(fullNeData));
        when(secureActionValidation.checkPermission(any(SecureAction.class), any(IManagedObjectId.class))).thenReturn(true);
        when(secureActionValidation.checkVisibility(any(INEId.class))).thenReturn(true);

        when(iconManager.findNetworkIcon(any(IEM.class), anyInt())).thenReturn(empty());
        when(iconManager.findNetworkIcon(any(IMediator.class), anyInt())).thenReturn(empty());
        when(iconManager.findNeOverlayIcon(any(FullNeData.class), anyInt())).thenReturn(empty());
        when(iconManager.findNeOverlayIcon(any(INE.class), anyInt())).thenReturn(empty());

        when(commonServices.getIconManager()).thenReturn(new IconManager());

        nodeMediatorRootLoader = new NodeMediatorRootLoader(repositoryManager, commonServices, nodeMediatorRoot);
    }

    @Test public void testLoad() throws Exception {
        Node root = nodeMediatorRootLoader.load();

        waitOrTimeout(() -> root.getChildCount() > 0, Timeout.timeout(Duration.seconds(10)));

        assertTrue(NodeMediatorRoot.class.isInstance(root));
        assertThat(root.getChildCount(), is(1));

        assertTrue(NodeMediator.class.isInstance(root.getChildAt(0)));
        NodeMediator nodeMediator = (NodeMediator) root.getChildAt(0);
        assertThat(nodeMediator.getChildCount(), is(1));

        assertTrue(NodeChannel.class.isInstance(nodeMediator.getChildAt(0)));
        NodeChannel nodeChannel = (NodeChannel) nodeMediator.getChildAt(0);
        assertThat(nodeChannel.getChildCount(), is(1));

        assertTrue(NodeNe.class.isInstance(nodeChannel.getChildAt(0)));
        NodeNe nodeNe = (NodeNe) nodeChannel.getChildAt(0);
        assertThat(nodeNe.getChildCount(), is(0));

        /*
         * Test CheckBox state
         */

        assertFalse(nodeChannel.getValue().isToogleButtonEnable());
        assertTrue(nodeChannel.getValue().isToogleButtonChecked());
        assertTrue(nodeChannel.getValue().isToogleButtonVisible());

        assertFalse(nodeMediator.getValue().isToogleButtonEnable());
        assertTrue(nodeMediator.getValue().isToogleButtonChecked());
        assertTrue(nodeMediator.getValue().isToogleButtonVisible());

        assertTrue(nodeNe.getValue().isToogleButtonEnable());
        assertTrue(nodeNe.getValue().isToogleButtonChecked());
        assertTrue(nodeNe.getValue().isToogleButtonVisible());
    }
}
