package com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.assignment;

import com.coriant.widgets.togglebuttontree.ToggleButtonTreeSelectionModel;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobAssociateNEsWithContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.assignment.load.NeAssignmentLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.assignment.node.ContainerNode;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeContainerAssignmentSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ContainerRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NEContainerAssignmentRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.tools.jfx.JfxAutoCompleteComboBox;
import com.ossnms.tools.jfx.JfxAutoCompleteComboBox.DataItem;
import com.ossnms.tools.jfx.components.JfxButton;
import org.junit.Test;

import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static com.jayway.awaitility.Awaitility.await;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Optional.of;
import static java.util.concurrent.TimeUnit.SECONDS;
import static java.util.stream.Collectors.toList;
import static org.hamcrest.Matchers.arrayWithSize;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class AssignmentControllerTest {

    private static final int TIMEOUT = 10;

    @Test public void shouldPopulateTreeOfContainers() throws Exception {
        List<IGenericContainer> containers = asList(
                container(0, "Root", 0),
                container(1, "Container 1", 0),
                container(11, "Container 1 1", 1),
                container(2, "Container 2", 0),
                container(21, "Container 2 1", 2));

        AssignmentController<?> controller = new AssignmentController<>(model(containers, emptyList(), ne(0, "name")),common(pluginHelper()));
        TreeModel containersTreeModel = controller.containersTree().getModel();


        ContainerNode rootNode = (ContainerNode) await().atMost(TIMEOUT, SECONDS)
                .until(containersTreeModel::getRoot, is(notNullValue())); //fetch happens in background
        assertThat(rootNode.getName(), is("Root"));
        assertThat(((ContainerNode) rootNode.getChildAt(0)).getName(), is("Container 1"));
        assertThat(rootNode.getChildAt(0).getChildCount(), is(1));
        assertThat(((ContainerNode) rootNode.getChildAt(1)).getName(), is("Container 2"));
        assertThat(rootNode.getChildAt(1).getChildCount(), is(1));
    }

    @Test public void shouldLoadAssociationsAsCheckboxes() throws Exception {
        List<IGenericContainer> containers = asList(
                container(0, "Root", 0),
                container(1, "Container 1", 0),
                container(2, "Container 2", 0),
                container(21, "Container 2 1", 2),
                container(22, "Container 2 2", 2));

        INE neId = ne(2, "name");

        List<INeGenericContainerAssignment> assignments = asList(
                assignment(1, neId, false),
                assignment(21, neId, false)
        );

        AssignmentController<?> controller = new AssignmentController<>(model(containers, assignments, neId), common(pluginHelper()));
        ToggleButtonTreeSelectionModel<?> toggleModel = controller.containersTree().getToggleButtonTreeSelectionModel();


        TreePath[] checkedPaths = await().atMost(TIMEOUT, SECONDS)
                .until(toggleModel::getSelectionPaths, arrayWithSize(2)); //fetch happens in background
        assertThat(checkedPaths.length, is(2));
        assertThat(((ContainerNode) checkedPaths[0].getLastPathComponent()).getName(), is("Container 1"));
        assertThat(((ContainerNode) checkedPaths[1].getLastPathComponent()).getName(), is("Container 2 1"));
    }

    @Test public void shouldLoadPrimaryConainer() throws Exception {
        List<IGenericContainer> containers = asList(
                container(0, "Root", 0),
                container(1, "Container 1", 0),
                container(2, "Container 2", 0),
                container(21, "Container 2 1", 2),
                container(22, "Container 2 2", 2));

        INE neId = ne(2, "name");

        List<INeGenericContainerAssignment> assignments = asList(
                assignment(1, neId, true), // PRIMARY
                assignment(21, neId, false)
        );

        AssignmentController<?> controller = new AssignmentController<>(model(containers, assignments, neId), common(pluginHelper()));
        TreeModel containersTreeModel = controller.containersTree().getModel();

        ContainerNode rootNode = (ContainerNode) await().atMost(TIMEOUT, SECONDS)
                .until(containersTreeModel::getRoot, is(notNullValue())); //fetch happens in background
        Collection<ContainerNode> primaryContainers = rootNode.findAll(ContainerNode::isPrimaryContainer);
        assertThat(primaryContainers, hasSize(1));

        Optional<String> primaryContainer = primaryContainers.stream().findFirst().map(ContainerNode::getName);
        assertThat(primaryContainer, is(of("Container 1")));
    }

    @Test public void shouldLoadSmartFilterItems() throws Exception {
        List<IGenericContainer> containers = asList(
                container(0, "Root", 0),
                container(1, "Container 1", 0),
                container(2, "Container 2", 0),
                container(21, "Container 2 1", 2),
                container(22, "Container 2 2", 2));

        AssignmentController<?> controller = new AssignmentController<>(model(containers, emptyList(), ne(2, "name")), common(pluginHelper()));
        JfxAutoCompleteComboBox smartFilter = controller.smartFilter();


        await().atMost(TIMEOUT, SECONDS)
                .until(controller.containersTree().getModel()::getRoot, is(notNullValue()));
        DataItem[] dataItems = await().atMost(TIMEOUT, SECONDS)
                .until(smartFilter::getDataItems, is(not(emptyArray())));
        List<IGenericContainer> filterContainers = Stream.of(dataItems).map(DataItem::getData)
                .map(IGenericContainer.class::cast).collect(toList());
        assertThat(filterContainers, containsInAnyOrder(containers.toArray()));
    }

    @Test public void shouldProvideNeNames() throws Exception {
        INE ne = ne(2, "name");
        
        AssignmentController<?> controller = new AssignmentController<>(model(emptyList(), emptyList(), ne), common(pluginHelper()));

        assertThat(controller.names(), is("name"));
    }
    
    @Test public void shouldExecuteJobOnOKButton() throws Exception {
        List<IGenericContainer> containers = asList(
                container(0, "Root", 0),
                container(1, "Container 1", 0),
                container(2, "Container 2", 0),
                container(21, "Container 2 1", 2),
                container(22, "Container 2 2", 2));
        INE neId = ne(2, "name");
        List<INeGenericContainerAssignment> assignments = asList(
                assignment(1, neId, true),
                assignment(21, neId, false));

        DcnPluginHelper pluginHelper = pluginHelper();
        AssignmentController<?> controller = new AssignmentController<>(model(containers, assignments, neId), common(pluginHelper));
        JfxButton okButton = new JfxButton("OK");
        okButton.setModel(controller.okModel());

        // select root node
        ContainerNode rootNode = (ContainerNode) await().atMost(TIMEOUT, SECONDS)
                .until(controller.containersTree().getModel()::getRoot, is(notNullValue()));
        controller.containersTree().getToggleButtonTreeSelectionModel().setSelectionPath(new TreePath(rootNode));
        
        // wait and click OK
        await().atMost(TIMEOUT, SECONDS).until(okButton::isEnabled);
        okButton.doClick();
        
        // verify job is triggered
        await().atMost(TIMEOUT, SECONDS).until(unchecked(() -> verify(pluginHelper).queueJob(any())));
    }
    
    private CommonServices common(DcnPluginHelper pluginHelper) {
        CommonServices services = mock(CommonServices.class);
        when(services.getDcnPluginHelper()).thenReturn(pluginHelper);
        return services;
    }

    private DcnPluginHelper pluginHelper() {
        return mock(DcnPluginHelper.class);
    }

    private INE ne(int id, String name) {
        NEItem ne = new NEItem();
        ne.setId(id);
        ne.setIdName(name);
        return ne;
    }

    private AssignmentModel<INEId> model(List<IGenericContainer> containers, List<INeGenericContainerAssignment> assignments, INE ne) throws RepositoryException {
        ContainerRepository containerRepo = containerRepo(containers);
        
        NEContainerAssignmentRepository assignmentRepository = mock(NEContainerAssignmentRepository.class);
        NeContainerAssignmentSearchable queries = mock(NeContainerAssignmentSearchable.class);
        when(queries.findByNetworkElementId(ne.getId())).thenReturn(assignments);
        when(assignmentRepository.queries()).thenReturn(queries);


        RepositoryManager repo = mock(RepositoryManager.class);
        when(repo.getContainerRepository()).thenReturn(containerRepo);
        when(repo.getNEContainerAssignmentRepository()).thenReturn(assignmentRepository);
        NeRepository neRepo = neRepo(asList(ne));
        when(repo.getNeRepository()).thenReturn(neRepo);

        NeAssignmentLoader loader = new NeAssignmentLoader(repo, asList(ne));
        return new AssignmentModel<>(loader, JobAssociateNEsWithContainer::new);
    }

    private static ContainerRepository containerRepo(List<IGenericContainer> containers) throws RepositoryException {
        ContainerRepository containerRepo = mock(ContainerRepository.class);
        when(containerRepo.getAll()).thenReturn(containers);
        return containerRepo;
    }

    private NeRepository neRepo(Collection<INE> nes) throws RepositoryException {
        NeRepository neRepo = mock(NeRepository.class);
        List<Integer> ids = nes.stream().map(INEId::getId).collect(toList());
        List<FullNeData> data = nes.stream().map(ne -> new FullNeData(ne, null, null)).collect(toList());
        when(neRepo.get(ids)).thenReturn(data);
        return neRepo;
    }

    private static IGenericContainer container(int id, String name, int parent) {
        GenericContainerItem container = new GenericContainerItem();
        container.setId(id);
        container.setIdName(name);
        container.setParentId(parent);
        return container;
    }

    private static INeGenericContainerAssignment assignment(int container, INEId neId, boolean primary) {
        NeGenericContainerAssignmentItem assignmentItem = new NeGenericContainerAssignmentItem();
        assignmentItem.setGenericContainerId(container);
        assignmentItem.setNetworkElement(neId);
        assignmentItem.setPrimary(primary);
        return assignmentItem;
    }

    /**
     * Converts checked exceptions into unchecked 
     */
    private Runnable unchecked(RunnableEx exceptional) {
        return () -> {
            try {
                exceptional.run();
            } catch (Exception ex) {
                //just ignore
                throw new RuntimeException(ex);
            }
        };
    }

    @FunctionalInterface private interface RunnableEx {
        void run() throws Exception;
    }
}