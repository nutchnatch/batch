package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindAllNeNodes;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindDomainNode;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindNeNode;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindNodeByName;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class NodeFinderDomainViewTest extends TestsHelper {
    public static final int NE_ID_OUT_OF_RANGE = 100;
    private Node root;

    @Before public void setUp() {
        root = new NodeDomainRoot("TNMS");

        final NodeDomain nodeDomain1 = buildNodeDomain(root, ID_1);
        final NodeDomain nodeDomain2 = buildNodeDomain(root, ID_2);
        final NodeDomain nodeDomain3 = buildNodeDomain(root, ID_3);

        final NodeNe nodeNe1 = buildNodeNe(nodeDomain1, ID_1);

        final NodeNe nodeNe2 = buildNodeNe(nodeDomain1, ID_2);
        final NodeNe nodeNe22 = buildNodeNe(nodeDomain2, ID_2);
        final NodeNe nodeNe222 = buildNodeNe(nodeDomain3, ID_2);

        final NodeNe nodeNe3 = buildNodeNe(nodeDomain3, ID_3);

        root.addChild(nodeDomain1);
        root.addChild(nodeDomain2);
        root.addChild(nodeDomain3);

        nodeDomain1.addChild(nodeNe1);
        nodeDomain1.addChild(nodeNe2);

        nodeDomain2.addChild(nodeNe22);

        nodeDomain3.addChild(nodeNe222);
        nodeDomain3.addChild(nodeNe3);
    }

    @Test public void testTryFindByName() {
        assertTrue(tryFindNodeByName(root, "TNMS").findFirst().isPresent());

        assertTrue(tryFindNodeByName(root, DOMAIN_NAME + ID_1).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, DOMAIN_NAME + ID_2).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, DOMAIN_NAME + ID_3).findFirst().isPresent());

        assertTrue(tryFindNodeByName(root, NE_NAME + ID_1).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, NE_NAME + ID_2).findFirst().isPresent());
        assertTrue(tryFindNodeByName(root, NE_NAME + ID_3).findFirst().isPresent());
    }

    @Test public void testTryFindByName_not_found() {
        assertFalse(tryFindNodeByName(root, "not_exists").findFirst().isPresent());
    }

    @Test public void testTryFindDomain() throws Exception {
        assertTrue(tryFindDomainNode(root, ID_1).isPresent());
        assertTrue(tryFindDomainNode(root, ID_2).isPresent());
        assertTrue(tryFindDomainNode(root, ID_3).isPresent());
    }

    @Test public void testTryFindDomain_not_found() throws Exception {
        assertFalse(tryFindDomainNode(root, ID_4).isPresent());
    }

    @Test public void testTryFindNe() throws Exception {
        assertThat(tryFindAllNeNodes(root, ID_1).size(), is(1));
        assertThat(tryFindAllNeNodes(root, ID_2).size(), is(3));
        assertThat(tryFindAllNeNodes(root, ID_3).size(), is(1));

        final Optional<NodeDomain> nodeDomain1 = tryFindDomainNode(root, ID_1);
        final Optional<NodeDomain> nodeDomain2 = tryFindDomainNode(root, ID_2);
        final Optional<NodeDomain> nodeDomain3 = tryFindDomainNode(root, ID_3);

        assertTrue(nodeDomain1.isPresent());
        assertTrue(nodeDomain2.isPresent());
        assertTrue(nodeDomain3.isPresent());

        assertTrue(tryFindNeNode(nodeDomain1.get(), ID_1).isPresent());
        assertTrue(tryFindNeNode(nodeDomain1.get(), ID_2).isPresent());
        assertTrue(tryFindNeNode(nodeDomain2.get(), ID_2).isPresent());
        assertTrue(tryFindNeNode(nodeDomain3.get(), ID_2).isPresent());
        assertTrue(tryFindNeNode(nodeDomain3.get(), ID_3).isPresent());
    }

    @Test public void testTryFindNe_not_found() throws Exception {
        assertFalse(tryFindNeNode(root, NE_ID_OUT_OF_RANGE).isPresent());
    }

    @Test public void testTryFindAllNe_not_found() throws Exception {
        assertTrue(tryFindAllNeNodes(root, NE_ID_OUT_OF_RANGE).isEmpty());
    }
}
