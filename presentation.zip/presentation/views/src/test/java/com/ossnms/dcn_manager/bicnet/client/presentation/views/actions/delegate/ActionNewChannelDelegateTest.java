package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.delegate;

import com.coriant.widgets.treetable.TreeTable;
import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.TestCase.assertFalse;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ActionNewChannelDelegateTest extends TestsHelper {

    @Mock NewElementDialogHandler dialogHandler;
    private IMediator mediator = new MediatorItem();

    private ActionNewChannelDelegate actionNewChannelDelegate;

    @Before public void setUp() throws Exception {
        actionNewChannelDelegate = new ActionNewChannelDelegate(commonServices, dialogHandler);
        mediator.setId(ID_1);
        when(secureActionValidation.checkPermission(SecureAction.OP_NEW_CHANNEL_SAN)).thenReturn(true);
    }

    @Test public void testIsActionAllowed() throws Exception {
        boolean actionAllowed = actionNewChannelDelegate.isActionAllowed(new IManagedObject[]{mediator});
        assertTrue(actionAllowed);
    }

    @Test public void testIsActionAllowed_no_permission() throws Exception {
        when(secureActionValidation.checkPermission(SecureAction.OP_NEW_CHANNEL_SAN)).thenReturn(false);

        boolean actionAllowed = actionNewChannelDelegate.isActionAllowed(new IManagedObject[]{mediator});
        assertFalse(actionAllowed);
    }

    @Test public void testIsActionAllowed_not_single_selection() throws Exception {
        boolean actionAllowed = actionNewChannelDelegate.isActionAllowed(new IManagedObject[]{mediator, mediator});
        assertFalse(actionAllowed);
    }

    @Test public void testIsActionAllowed_not_mediator() throws Exception {
        IEM channel = buildFullChannelData(1, 1).getChannel();
        boolean actionAllowed = actionNewChannelDelegate.isActionAllowed(new IManagedObject[]{channel});
        assertFalse(actionAllowed);
    }

    @Test public void testEventActionPerformed() throws Exception {
        actionNewChannelDelegate.eventActionPerformed(new IManagedObject[]{mediator});

        verify(dialogHandler, times(1)).showNewChannelDialog(mediator);
    }

    @Test public void testGetActionId() throws Exception {
        assertThat(actionNewChannelDelegate.getMenuName(), is(TreeTableLabels.NEW_CHANNEL));
    }

    @Test public void testGetMenuName() throws Exception {
        assertThat(actionNewChannelDelegate.getActionId(), is(ActionNewChannelDelegate.class.getName()));
    }
}