package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.mediator;

import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@SuppressWarnings("unchecked")
@RunWith(MockitoJUnitRunner.class)
public class TreeTableMediatorsDocumentTest extends TestsHelper{

    @Mock private ListenersRegistrationManager changeListener;
    @Mock private ModelUpdater modelUpdater;

    private TreeTableMediatorsDocument document;

    @Before
    public void setup() throws RepositoryException {
        document = new TreeTableMediatorsDocument(commonServices, repositoryManager, changeListener);
    }

    @Test
    public void testAddChangeListeners() {
        document.addChangeListeners(modelUpdater);

        verify(changeListener, times(1)).addNeListener(any(EventChangeListener.class));
        verify(changeListener, times(1)).addChannelListener(any(EventChangeListener.class));
        verify(changeListener).addMediatorListener(any(EventChangeListener.class));
    }

    @Test
    public void testRemoveChangeListeners() {
        document.removeChangeListeners();

        verify(changeListener).removeMediatorListener(any(EventChangeListener.class));
        verify(changeListener, times(1)).removeChannelListener(any(EventChangeListener.class));
        verify(changeListener, times(1)).removeNeListener(any(EventChangeListener.class));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testGetObject() {
        document.getObject(null);
    }
}
