package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.mediatorview;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobMoveChannels;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ChannelRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.MediatorRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Test;
import org.mockito.Matchers;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.DISABLED;
import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.ENABLED;
import static com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.BCB;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.MOVE_CHANNEL_SAN;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ChannelAcceptorTest {

    @Test public void shouldAllowToDrop() throws Exception {
        IEM em = em("BCB", 0, DISABLED);                       //channel is disabled
        ChannelAcceptor channelAcceptor = new ChannelAcceptor(
                repoManager(
                        neRepo(of(em.getId(), emptyList())),   //channel without nes
                        channelRepo(
                                asList(em),
                                of(BCB, asList("BCB"))),       //mediator supports channel type
                        mediatorRepo(mediator(BCB, 0))),
                services(
                        validation(MOVE_CHANNEL_SAN, true),    //operator has permissions 
                        pluginHelper()));


        assertThat(channelAcceptor.canAccept(asList(em), mediator(BCB, 0)), is(true));
    }

    @Test public void shouldNotAllowToDrop_not_all_nes_are_visible() throws Exception {
        IEM em = em("BCB", 0, DISABLED);
        final SecureActionValidation validation = validation(MOVE_CHANNEL_SAN, true);
        when(validation.checkVisibility(Matchers.<Collection<INEId>>any())).thenReturn(false);
        
        ChannelAcceptor channelAcceptor = new ChannelAcceptor(
                repoManager(
                        neRepo(of(em.getId(), asList(ne(false)))), //channel has deactivated nes
                        channelRepo(
                                asList(em),
                                of(BCB, asList("BCB"))),
                        mediatorRepo(mediator(BCB, 0))),
                services(
                        validation,
                        pluginHelper()));


        assertThat(channelAcceptor.canAccept(asList(em), mediator(BCB, 0)), is(false));
    }

    @Test public void shouldAllowToDropOnlyOnMediatorNode() throws Exception {
        IEM em = em("BCB", 0, DISABLED);
        ChannelAcceptor channelAcceptor = new ChannelAcceptor(
                repoManager(
                        neRepo(of(em.getId(), emptyList())),
                        channelRepo(
                                asList(em),
                                of(BCB, asList("BCB"))),
                        mediatorRepo(mediator(BCB, 0))),
                services(
                        validation(MOVE_CHANNEL_SAN, true),
                        pluginHelper()));


        assertThat(channelAcceptor.canAccept(asList(em), new NEItem()), is(false));   //wrong node
        assertThat(channelAcceptor.canAccept(asList(em), new EMItem()), is(false));   //wrong node
    }

    @Test public void shouldNotAllowToDropWithoutPermissions() throws Exception {
        IEM em = em("BCB", 0, DISABLED);
        ChannelAcceptor channelAcceptor = new ChannelAcceptor(
                repoManager(
                        neRepo(of(em.getId(), emptyList())),
                        channelRepo(
                                asList(em),
                                of(BCB, asList("BCB"))),
                        mediatorRepo(mediator(BCB, 0))),
                services(
                        validation(MOVE_CHANNEL_SAN, false),   //operator doesn't have permissions 
                        pluginHelper()));

        assertThat(channelAcceptor.canAccept(asList(em), mediator(BCB, 0)), is(false));
    }

    @Test public void shouldNotAllowToDropChannelWithActivatedNes() throws Exception {
        IEM em = em("BCB", 0, DISABLED);
        ChannelAcceptor channelAcceptor = new ChannelAcceptor(
                repoManager(
                        neRepo(of(em.getId(), asList(ne(true)))), //channel has activated nes
                        channelRepo(
                                asList(em),
                                of(BCB, asList("BCB"))),
                        mediatorRepo(mediator(BCB, 0))),
                services(
                        validation(MOVE_CHANNEL_SAN, true),
                        pluginHelper()));


        assertThat(channelAcceptor.canAccept(asList(em), mediator(BCB, 0)), is(false));
    }

    @Test public void shouldAllowToDropChannelWithDeactivatedNe() throws Exception {
        IEM em = em("BCB", 0, DISABLED);

        final SecureActionValidation validation = validation(MOVE_CHANNEL_SAN, true);
        when(validation.checkVisibility(Matchers.<Collection<INEId>>any())).thenReturn(true);

        ChannelAcceptor channelAcceptor = new ChannelAcceptor(
                repoManager(
                        neRepo(of(em.getId(), asList(ne(false)))), //channel has deactivated nes
                        channelRepo(
                                asList(em),
                                of(BCB, asList("BCB"))),
                        mediatorRepo(mediator(BCB, 0))),
                services(
                        validation,
                        pluginHelper()));


        assertThat(channelAcceptor.canAccept(asList(em), mediator(BCB, 0)), is(true));
    }

    private FullNeData ne(boolean enabled) {
        NEItem ne = new NEItem();
        ne.setOperationalState(OperationalState.DISABLED);
        ne.setEventForwarding(ENABLED);
        ne.setActivation(enabled ? ENABLED : DISABLED);
        return new FullNeData(ne, new NeInfo(1), new ScsSynchronizationState(1, ScsSyncState.OUT_OF_SYNC, ""));
    }

    @Test public void shouldNotAllowToDropOnMediationWithUnsupportedType() throws Exception {
        IEM em = em("BCB", 0, DISABLED);
        ChannelAcceptor channelAcceptor = new ChannelAcceptor(
                repoManager(
                        neRepo(of(em.getId(), emptyList())),
                        channelRepo(
                                asList(em),
                                of(BCB, asList("another channel type"))), //mediator does not support channel type
                        mediatorRepo(mediator(BCB, 0))),
                services(
                        validation(MOVE_CHANNEL_SAN, true),
                        pluginHelper()));


        assertThat(channelAcceptor.canAccept(asList(em), mediator(BCB, 0)), is(false));
    }

    @Test public void shouldNotAllowToDropActivatedChannel() throws Exception {
        IEM em = em("BCB", 0, ENABLED);                                                 //activated channel
        ChannelAcceptor channelAcceptor = new ChannelAcceptor(
                repoManager(
                        neRepo(of(em.getId(), emptyList())),
                        channelRepo(
                                asList(em),
                                of(BCB, asList("BCB"))),
                        mediatorRepo(mediator(BCB, 0))),
                services(
                        validation(MOVE_CHANNEL_SAN, true),
                        pluginHelper()));


        assertThat(channelAcceptor.canAccept(asList(em), mediator(BCB, 0)), is(false));
    }

    @Test public void shouldTriggerJobOnDrop() throws Exception {
        IEM em = em("BCB", 0, DISABLED);
        DcnPluginHelper pluginHelper = pluginHelper();
        ChannelAcceptor channelAcceptor = new ChannelAcceptor(
                repoManager(
                        neRepo(of(em.getId(), emptyList())),   //channel without nes
                        channelRepo(
                                asList(em),
                                of(BCB, asList("BCB"))),       //mediator supports channel type
                        mediatorRepo(mediator(BCB, 0))),
                services(
                        validation(MOVE_CHANNEL_SAN, true),    //operator has permissions 
                        pluginHelper));

        boolean dropped = channelAcceptor.perform(asList(em), mediator(BCB, 0));

        assertThat(dropped, is(true));
        verify(pluginHelper).queueJob(any(JobMoveChannels.class));
    }

    private DcnPluginHelper pluginHelper() {
        return mock(DcnPluginHelper.class);
    }

    private MediatorItem mediator(MediatorType type, int id) {
        MediatorItem mediator = new MediatorItem();
        mediator.setMediatorType(type);
        mediator.setId(id);
        return mediator;
    }

    private EMItem em(String type, int iod, EnableSwitch activation) {
        EMItem em = new EMItem();
        em.setActivation(activation);
        em.setEmType(type);
        em.setId(iod);
        return em;
    }

    private CommonServices services(SecureActionValidation secureActionValidation, DcnPluginHelper pluginHelper) {
        CommonServices commonServices = mock(CommonServices.class);
        when(commonServices.getSecureActionValidation()).thenReturn(secureActionValidation);
        when(commonServices.getDcnPluginHelper()).thenReturn(pluginHelper);
        return commonServices;
    }

    private SecureActionValidation validation(SecureAction action, boolean permission) {
        SecureActionValidation secureActionValidation = mock(SecureActionValidation.class);
        when(secureActionValidation.checkPermission(action)).thenReturn(permission);
        when(secureActionValidation.checkVisibility(Matchers.<INEId>any())).thenReturn(true);
        when(secureActionValidation.checkVisibility(Matchers.<Collection<INEId>>any())).thenReturn(true);
        return secureActionValidation;
    }

    private RepositoryManager repoManager(NeRepository neRepository, ChannelRepository channelRepository, MediatorRepository mediatorRepository) {
        RepositoryManager repositoryManager = mock(RepositoryManager.class);
        when(repositoryManager.getNeRepository()).thenReturn(neRepository);
        when(repositoryManager.getChannelRepository()).thenReturn(channelRepository);
        when(repositoryManager.getMediatorRepository()).thenReturn(mediatorRepository);
        return repositoryManager;
    }

    private MediatorRepository mediatorRepo(IMediator mediator) throws RepositoryException {
        MediatorRepository mediatorRepository = mock(MediatorRepository.class);
        when(mediatorRepository.get(mediator.getId())).thenReturn(Optional.of(new FullMediatorData(mediator, new MediatorInfo(mediator.getId()))));
        return mediatorRepository;
    }

    private ChannelRepository channelRepo(List<IEM> channels, Map<MediatorType, Collection<String>> supportedChannels) throws RepositoryException {
        ChannelRepository channelRepository = mock(ChannelRepository.class);
        List<Integer> ids = channels.stream().map(IEM::getEMId).map(IEMId::getId).collect(Collectors.toList());
        List<FullChannelData> full = channels.stream().map(iem -> {
            final ChannelInfo channelInfo = new ChannelInfo(iem.getId());
            channelInfo.setGuiActualActivationState(GuiActualActivationState.INACTIVE);
            return new FullChannelData(iem, channelInfo);
        }).collect(Collectors.toList());

        when(channelRepository.get(ids)).thenReturn(full);

        for (Entry<MediatorType, Collection<String>> entry : supportedChannels.entrySet()) {
            MediatorType mediatorType = entry.getKey();
            Collection<String> channelTypes = entry.getValue();
            when(channelRepository.getRegisteredTypes(any(), eq(Optional.of(mediatorType.toString())))).thenReturn(channelTypes);
        }
        return channelRepository;
    }

    private NeRepository neRepo(Map<Integer, Collection<FullNeData>> nesByChannel) throws RepositoryException {
        NeSearchable neQueries = mock(NeSearchable.class);
        nesByChannel.forEach((channelId, nes) ->
                when(neQueries.findByParentId(channelId)).thenReturn(nes));

        NeRepository neRepository = mock(NeRepository.class);
        when(neRepository.queries()).thenReturn(neQueries);

        return neRepository;
    }
}