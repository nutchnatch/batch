package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainerRoot;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ContainerTreeNodeEventListenerTest extends TestsHelper {
    @Mock private ModelUpdater modelUpdater;
    @Mock private GraphicalRepresentationBuilder<IGenericContainer> graphicalRepresentationBuilder;
    @Mock private NodeContainerRoot containerRoot;

    private ContainerTreeNodeEventListener containerEventListener;

    @Before public void setUp() throws Exception {
        containerEventListener = new ContainerTreeNodeEventListener(modelUpdater, commonServices, repositoryManager,
                graphicalRepresentationBuilder);

        containerRoot = new NodeContainerRoot("Root");

        when(modelUpdater.getNodeRoot()).thenReturn(containerRoot);
    }

    @Test public void testRemove() throws Exception {
        IGenericContainer containerBcb = buildContainer(ID_1);
        NodeContainer nodeContainer = buildNodeNeContainer(containerRoot, ID_1);
        containerRoot.addChild(nodeContainer);

        containerEventListener.remove(containerBcb);

        assertTrue(nodeContainer.getAllChildren().isEmpty());
        verify(modelUpdater, atLeastOnce()).removeNode(nodeContainer);
    }

    @Test public void testAdd() throws Exception {
        IGenericContainer neContainer = buildContainer(ID_1);
        neContainer.setParent(new GenericContainerIdItem(containerRoot.getId()));

        containerEventListener.add(neContainer);
        assertThat(containerRoot.getAllChildren().size(), is(1));
        verify(modelUpdater, atLeastOnce()).insertNode(any(NodeContainer.class));
    }

    @Test public void testUpdate() throws Exception {
        IGenericContainer neContainer = buildContainer(ID_1);
        neContainer.setIdName("new_name");

        NodeContainer nodeContainer = buildNodeNeContainer(containerRoot, ID_1);
        containerRoot.addChild(nodeContainer);

        containerEventListener.update(neContainer);

        assertThat(containerRoot.getAllChildren().size(), is(1));
        assertThat(nodeContainer.getValue().getName(), is("new_name"));
        verify(modelUpdater, atLeastOnce()).applyStructureChanged(any(NodeContainer.class));
    }
}