package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.CacheInMemoryRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import org.junit.Test;

import java.util.Optional;

import static javax.swing.SwingUtilities.invokeAndWait;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class UpdateParentListenerTest {

    private final EventChangeListener<String> listener = mock(EventChangeListener.class);

    @Test public void shouldTriggerParentListenerOnChildAdd() throws Exception {
        String parent = "parent";
        String child = "child";
        UpdateParentListener<String, String> updateParentListener = of(listener, parent, child);

        invokeAndWait(() -> updateParentListener.elementAdded(child));

        verify(listener).elementUpdated(parent);

    }

    @Test public void shouldTriggerParentListenerOnChildUpdated() throws Exception {
        String parent = "parent";
        String child = "child";
        UpdateParentListener<String, String> updateParentListener = of(listener, parent, child);

        invokeAndWait(() -> updateParentListener.elementUpdated(child));

        verify(listener).elementUpdated(parent);
    }

    @Test public void shouldTriggerParentListenerOnChildRemoved() throws Exception {
        String parent = "parent";
        String child = "child";
        UpdateParentListener<String, String> updateParentListener = of(listener, parent, child);

        invokeAndWait(() -> updateParentListener.elementRemoved(child));

        verify(listener).elementUpdated(parent);
    }

    @Test public void shouldNotTriggerParentListenerIfParentAbsentInRepo() throws Exception {
        String parent = "parent";
        UpdateParentListener<String, String> updateParentListener = of(listener, parent, "some child");

        invokeAndWait(() -> updateParentListener.elementUpdated("another child"));

        verify(listener, never()).elementUpdated(parent);
    }

    private UpdateParentListener<String, String> of(EventChangeListener<String> listener, String parent, String child) throws RepositoryException {
        CacheInMemoryRepository<Integer, String> repository = mock(CacheInMemoryRepository.class);
        when(repository.get(1)).thenReturn(Optional.of(parent));
        when(repository.get(-1)).thenReturn(Optional.empty());
        
        return new UpdateParentListener<>(listener, repository, ch -> ch.equals(child) ? 1 : -1);
    }

}