package com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.builder;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalContainerItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.api.action.PluginAction;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionModeStateActive;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionModeStateMaintenance;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionModeStateOperational;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionWriteAccessEnforce;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionWriteAccessRelease;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.plugin.external.ActionWriteAccessRequest;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ActionBuilderSystemContainerOperationsTest {
    @Mock private RepositoryManager repositoryManager;
    @Mock private CommonServices commonServices;

    private static final Collection<IManagedObject> VALID_VALUES = ImmutableList
            .of((IManagedObject) new NEItem(), new SystemContainerItem(), new TopologicalSymbolItem());

    private static final Collection<IManagedObject> INVALID_VALUES = ImmutableList
            .of((IManagedObject) new TopologicalContainerItem(), new EMItem(), new MediatorItem());

    private static final Collection<IManagedObject> VALID_WITH_INVALID_TYPES = ImmutableList
            .of((IManagedObject) new EMItem(), new SystemContainerItem(), new MediatorItem());

    @Test public void testValidActions() {
        final Collection<PluginAction> actions = new ActionBuilderNeStateControl(repositoryManager, commonServices)
                .createList().actionsOf(VALID_VALUES);

        assertThat(actions.size(), is(6));
        assertThat(actions.stream().map(PluginAction::getMenuID).collect(Collectors.toList()),
                containsInAnyOrder(
                        ActionWriteAccessRequest.class.getName(),
                        ActionWriteAccessRelease.class.getName(),
                        ActionWriteAccessEnforce.class.getName(),
                        ActionModeStateMaintenance.class.getName(),
                        ActionModeStateOperational.class.getName(),
                        ActionModeStateActive.class.getName()));
    }

    @Test public void testInvalidActions() {
        final Collection<PluginAction> actions = new ActionBuilderNeStateControl(repositoryManager, commonServices)
                .actionsOf(INVALID_VALUES);

        assertTrue(actions.isEmpty());
    }

    @Test public void testAllMatch() {
        assertTrue(new ActionBuilderNeStateControl(repositoryManager, commonServices).allMatch(VALID_VALUES));
    }

    @Test public void testAllMatch_valid_with_invalid_types() {
        assertFalse(
                new ActionBuilderNeStateControl(repositoryManager, commonServices).allMatch(VALID_WITH_INVALID_TYPES));
    }

    @Test public void testAllMatchFalse() {
        assertFalse(new ActionBuilderNeStateControl(repositoryManager, commonServices).allMatch(INVALID_VALUES));
    }

    @Test public void testActions() {
        assertTrue(new ActionBuilderNeStateControl(repositoryManager, commonServices).getActions().isEmpty());
    }
}