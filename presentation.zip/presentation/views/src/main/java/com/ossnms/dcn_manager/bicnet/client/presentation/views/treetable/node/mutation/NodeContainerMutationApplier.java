package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader.NodeContainerRootLoader.NeUnderContainerLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader.NodeContainerRootLoader.SystemUnderContainerLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Objects;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.StringUtils.defaultString;

public class NodeContainerMutationApplier extends NodeMutationApplier<IGenericContainer, NodeContainer> {
    private final SystemUnderContainerLoader systemLoader;
    private final NeUnderContainerLoader neLoader;

    public NodeContainerMutationApplier(RepositoryManager repositoryManager, CommonServices commonServices,
                                        GraphicalRepresentationBuilder<IGenericContainer> graphicalRepresentation) {
        super(repositoryManager, commonServices, graphicalRepresentation);
        systemLoader = new SystemUnderContainerLoader(repositoryManager, commonServices);
        neLoader = new NeUnderContainerLoader(repositoryManager, commonServices);
    }

    @Override public NodeMutationApplier<IGenericContainer, NodeContainer> applyMutation(
            @Nonnull final IGenericContainer container, @Nonnull final NodeContainer node) {
        applyGraphicalRepresentationMutation(container, node);

        node.getValue().setName(container.getIdName());
        node.getColumns().setValue(ColumnId.USER_TEXT, defaultString(container.getUserLabel()));

        return this;
    }

    @Override public boolean structureChanged(IGenericContainer container, NodeContainer node) {
        return !Objects.equals(container.getIdName(), node.getValue().getName());
    }

    @Override public NodeMutationApplier<IGenericContainer, NodeContainer> loadChildrenNodes(
            @Nonnull final NodeContainer parentContainer) throws RepositoryException {
        final Collection<IGenericContainer> containerList = getRepositoryManager().getContainerRepository().queries()
                .findByParentId(parentContainer.getId()).stream()
                .sorted((e1, e2) -> e1.getIdName().compareTo(e2.getIdName())).collect(Collectors.toList());

        for (IGenericContainer container : containerList) {
            NodeContainer nodeContainer = new NodeContainer(container.getId(), parentContainer);
            applyMutation(container, nodeContainer);

            parentContainer.addChild(nodeContainer);

            try {
                loadChildrenNodes(nodeContainer);
            } catch (RepositoryException e) {
                Throwables.propagate(e);
            }
        }

        systemLoader.loadChildrenSystems(parentContainer);

        neLoader.loadChildrenNes(parentContainer);

        return this;
    }
}
