package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;


public enum ColumnId {
    TREE_MODEL(0),
    STATE(1),
    NETWORK_NAME(2),
    TYPE(3),
    INFO(4),
    ADDRESS(5),
    CONNECT_VIA(6),
    STANDBY_STATE(7),
    USER_TEXT(8),
    LOCATION(9);
    
    private final int position;
    
    private ColumnId(int position) {
        this.position = position;
    }
    
    public int position() {
        return position;
    }
    
    public static ColumnId valueOf(int position) {
        for (final ColumnId columnId : ColumnId.values()) {
            if (columnId.position == position) {
                return columnId;
            }
        }
        
        throw new UnsupportedOperationException();
    }
}