package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ossnms.dcn_manager.bicnet.client.api.transform.Transform.getNeIds;

public class NodeDomainMutationApplier extends NodeMutationApplier<IAS, NodeDomain>{

    private final NodeNeMutationApplier nodeNeMutationApplier;

    public NodeDomainMutationApplier(RepositoryManager repositoryManager, CommonServices commonServices,
            GraphicalRepresentationBuilder<IAS> graphicalRepresentation) {
        super(repositoryManager, commonServices, graphicalRepresentation);

        nodeNeMutationApplier = new NodeNeMutationApplier(repositoryManager, commonServices,
                new NeGraphicalRepresentationBuilder(commonServices.getIconManager()));
    }

    @Override public NodeMutationApplier<IAS, NodeDomain> applyMutation(IAS domain, NodeDomain node) {
        applyGraphicalRepresentationMutation(domain, node);
        node.getValue().setName(domain.getIdName());

        return this;
    }

    @Override public boolean structureChanged(IAS domain, NodeDomain node) {
        return !Objects.equals(domain.getIdName(), node.getValue().getName());
    }

    @Override public NodeMutationApplier<IAS, NodeDomain> loadChildrenNodes(@Nonnull final NodeDomain nodeDomain) throws RepositoryException {
        final Optional<IAS> domain = getRepositoryManager().getDomainRepository()
                .queries()
                .findByIdName(nodeDomain.getValue().getName());

        if (domain.isPresent()) {
            Collection<FullNeData> neList = getRepositoryManager().getNeRepository().get(getNeIds(domain.get()))
                    .stream()
                    .sorted((e1, e2) -> e1.getNe().getIdName().compareTo(e2.getNe().getIdName()))
                    .collect(Collectors.toList());

            neList.forEach(ne -> {
                NodeNe nodeNe = new NodeNe(ne.getNe().getId(), nodeDomain);
                nodeNeMutationApplier.applyMutation(ne, nodeNe);

                nodeDomain.addChild(nodeNe);
            });
        }
        return this;
    }
}
