package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.TransferHandler;
import java.awt.AWTPermission;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Collection;
import java.util.Optional;

import static java.awt.event.InputEvent.CTRL_MASK;
import static java.awt.event.KeyEvent.VK_V;
import static java.awt.event.KeyEvent.VK_X;
import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;
import static javax.swing.Action.NAME;

public class CutPasteHandler extends KeyAdapter {

    private static final Action CUT_ACTION = TransferHandler.getCutAction();
    private static final Action PASTE_ACTION = TransferHandler.getPasteAction();
    private static final AWTPermission ACCESS_CLIPBOARD = new AWTPermission("accessClipboard");
    private static final Logger LOGGER = LoggerFactory.getLogger(CutPasteHandler.class);

    private final JComponent component;
    private final CommonTransferHandler commonTransferHandler;

    public CutPasteHandler(JComponent component, CommonTransferHandler commonTransferHandler) {
        this.component = component;
        this.commonTransferHandler = commonTransferHandler;
    }

    @Override public void keyPressed(KeyEvent e) {
        if (matchesKeystroke(CTRL_MASK, VK_X, e)) {
            cut();
        }
        if (matchesKeystroke(CTRL_MASK, VK_V, e)) {
            paste();
        }
        super.keyPressed(e);
    }

    private boolean matchesKeystroke(int mask, int key, KeyEvent e) {
        return e.getKeyCode() == key && (e.getModifiers() & mask) != 0;
    }

    /**
     * Trigger cut action in the component
     */
    public void cut() {
        perform(component, CUT_ACTION);
    }

    /**
     * Trigger copy action in the component
     */
    public void paste() {
        perform(component, PASTE_ACTION);
    }

    public boolean canCut(Collection<IManagedObject> objects) {
        return commonTransferHandler.canProduceTransfer(objects);
    }

    /**
     * Validates if clipboard has a valid transferable for provided destinations
     */
    public boolean canPaste(Collection<IManagedObject> destinations) {
        return readClipboard()
                .map(transferable -> commonTransferHandler.canAcceptTransfer(transferable, destinations))
                .orElse(false);
    }

    private void perform(JComponent component, Action action) {
        action.actionPerformed(new ActionEvent(component, 0, (String) action.getValue(NAME)));
    }

    private Optional<Transferable> readClipboard() {
        return getClipboard(component).map(clipboard -> clipboard.getContents(null));
    }

    private Optional<Clipboard> getClipboard(JComponent component) {
        if (canAccessSystemClipboard()) {
            return ofNullable(component.getToolkit().getSystemClipboard());
        }
        return empty();
    }

    private boolean canAccessSystemClipboard() {
        try {
            System.getSecurityManager().checkPermission(ACCESS_CLIPBOARD);
            return true;
        } catch (SecurityException e) {
            LOGGER.error("No access to clipboard", e);
            return false;
        }
    }
}
