package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable;

import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.dnd.Autoscroll;
import java.awt.dnd.DropTarget;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Optional;

import javax.annotation.Nonnull;
import javax.swing.AbstractAction;
import javax.swing.JMenuItem;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.coriant.widgets.treetable.TreeTableModel;
import com.google.common.collect.Iterables;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPlugin;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginAction;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionToggleListener;
import com.ossnms.bicnet.framework.client.jfx.FrameworkActionUtils;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.ContextAction;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.builder.ContextMenuActionsFactory;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.state.RequiredActivationStateChanged;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionCollapseTreeNode;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionExpandAllTreeNodes;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionExpandTreeNode;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionOpenTable;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.ToggleButtonListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listtable.DcnListTableCommand;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.builder.TransferHandlers;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.JfxActionCondition;
import com.ossnms.tools.jfx.JfxActionPerformed;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.components.JfxMenu;
import com.ossnms.tools.jfx.components.JfxMenuItem;
import com.ossnms.tools.jfx.components.JfxPopupMenu;
import com.ossnms.tools.jfx.treetable.JfxTreeTable;

public class DcnTreeTable extends JfxTreeTable<Node> implements PopupMenuListener, TreeExpansionListener, Autoscroll {
    private static final long serialVersionUID = -600545521848789864L;

    private static final Logger LOGGER = LoggerFactory.getLogger(DcnTreeTable.class);

    private final NodeHandler nodeHandler;
    private final NewElementDialogHandler dialogHandler;
    private final ToolTipBuilder toolTipBuilder;

    private AbstractAction actionOnDoubleClick;
    private JfxMenuItem menuExpand;
    private JfxMenuItem menuCollapse;
    private JfxMenuItem menuExpandAll;
    private final JfxAction openTable;

    private final SecureActionValidation secureValidation;
    private final ContextAction contextAction;

    private final ContextMenuActionsFactory contextMenuActionsFactory;
    private static final int AUTO_SCROLL_THRESHOLD = 16; // distance from border where to start scrolling on drag

    public DcnTreeTable(@Nonnull final TreeTableModel<Node> model, NodeHandler nodeHandler,
                        NewElementDialogHandler dialogHandler, ContextAction contextAction, RepositoryManager repositoryManager,
                        CommonServices commonServices, TransferHandlers transferHandlers) {
        super(model);

        this.nodeHandler = nodeHandler;
        this.dialogHandler = dialogHandler;
        toolTipBuilder = new ToolTipBuilder();
        this.contextAction = contextAction;

        secureValidation = commonServices.getSecureActionValidation();
        contextMenuActionsFactory = new ContextMenuActionsFactory(dialogHandler,
                repositoryManager, commonServices, transferHandlers.cutPasteHandler(this));

        openTable = new ActionOpenTable(this, new DcnListTableCommand(repositoryManager, commonServices, new CacheListenersRegistrationManager()), nodeHandler, commonServices);
        
        setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        addToggleButtonListener(new ToggleButtonListener(new RequiredActivationStateChanged()));
        setDoubleClickExpandCollapseTree(false);
        setDefaultToolTipBehaviour(true);
        setHeaderToolTipsEnabled(true);
        addTablePopupListener(this);

        setTransferHandler(transferHandlers.transferHandler(this));
        addKeyListener(transferHandlers.cutPasteHandler(this));
        setDropTarget(new DropTarget(this, transferHandlers.dropTargetListener(this)));
        setDragEnabled(transferHandlers.hasDragHandlers());
        
        getSelectionModel().addListSelectionListener(this::reselectOnClear);
    }

    @Override public void popupTriggered(final MouseEvent event) {
        final Object table = event.getSource();
        if (table instanceof JfxTreeTable) {
            // Remove dynamic context menu items
            getTablePopupMenu().removeAll();

            try {
                addDynamicContextMenuItems(event);
            } catch (final RepositoryException e) {
                LOGGER.error("Repository not available", e);
            }
        }
    }

    /**
     * Add context menu items
     *
     * @param e mouse event that triggers the popup menu for context menu
     * @throws RepositoryException
     */
    public void addDynamicContextMenuItems(final MouseEvent e) throws RepositoryException {
        final JfxPopupMenu contextMenu = createPopupMenu(Optional.empty());
        contextMenu.show(e.getComponent(), e.getX(), e.getY());
    }

    private JfxPopupMenu createPopupMenu(Optional<JfxPopupMenu> contextMenu) throws RepositoryException {
        JfxPopupMenu menu = contextMenu.orElse(new JfxPopupMenu());

        setTablePopupMenu(menu);
        addDefaultTablePopupMenuItems();
        addTablePopupListener(this);

        // Add common actions
        if (areAllSelectedRowsNotLeafs()) {
            addCommonActions();
        }

        final BiCNetPlugin[] allPlugins = DcnPluginHelperSingleton.getInstance().getCfPluginSite().getPlugins();

        // Add all plugins actions to all nodes except root
        final IManagedObject[] manageObjects = Iterables
                .toArray(nodeHandler.transformAllKnownNodeTypes(getSelectedNodes()), IManagedObject.class);

        if (ArrayUtils.isNotEmpty(manageObjects)) {
            FrameworkActionUtils.addPluginActions(menu, allPlugins, manageObjects, null, null);
        } else {
            menu.addSeparator();
        }

        addDcnActions(manageObjects, menu);
        return menu;
    }

    private void addDcnActions(final IManagedObject[] manageObjects, final JfxPopupMenu contextMenu)
            throws RepositoryException {

        final BiCNetPluginAction[] privateActions = contextMenuActionsFactory.build(manageObjects);

        if (privateActions.length != 0) {
            contextMenu.addSeparator();
        }

        final Collection<JMenuItem> menus = contextAction.createAction(getSelectedNodes(), (TreeTableViewModel) getTreeModel());

        menus.forEach(getTablePopupMenu()::add);

        if (privateActions.length == 0 && menus.isEmpty()) {
            contextMenu.remove(contextMenu.getComponentCount() - 1);
        }

        contextMenu.add(new JfxMenuItem(openTable));
        
        for (final BiCNetPluginAction privatePluginActions : privateActions) {
            final JfxAction action = new JfxAction(privatePluginActions.getToolIcon(),
                    new JfxText(privatePluginActions.getMenuName()), null, null,
                    privatePluginActions.getLongDescription() != null ?
                            new JfxText(privatePluginActions.getLongDescription()) :
                            JfxStringTable.IDS_EmptyString, privatePluginActions.getMenuAccelerator(),
                    privatePluginActions.getMenuID(),
                    new PerformHandler(privatePluginActions.getActionListener(), manageObjects), null,
                    new ConditionHandler(privatePluginActions.getActionListener(), manageObjects));
            
            
            /* DCN Management will support at most one single level of sub menus on the context menu.
             * 
             * BiCNetPluginAction.getMenuPath() for DCN Actions will either return a null array, for menu entries to be placed directly on the context menu,
             * or a String array of size 2, populated with the menu name in the first position and the menu item name on the second position. 
             */
            String[] menuPath = privatePluginActions.getMenuPath();
            if (null != menuPath && menuPath.length > 1) {
                JfxMenu workingMenu;
                JfxText jfxTextSubMenu = new JfxText(menuPath[0]);
                JfxMenu subMenu = new JfxMenu(jfxTextSubMenu);
                JMenuItem presentSubMenu = contextMenu
                        .findItem(JfxStringTable.getStringWithoutMnemonic(jfxTextSubMenu));

        		/*If sub menu was already added to context menu, don't add it again, just have workingMenu set to already present menu*/
        		/* instanceof operator replies false for null instances, no need to check for null */
                if (presentSubMenu instanceof JfxMenu) {
                    workingMenu = (JfxMenu) presentSubMenu;
                } else {
                    contextMenu.add(subMenu);
                    workingMenu = subMenu;
                }

                workingMenu.add(new JfxMenuItem(action));
                workingMenu.updateActions();
            } else {
                contextMenu.add(new JfxMenuItem(action));
            }
        }
    }

    /**
     * Check if all selected objects are not leafs(NEs)
     */
    private boolean areAllSelectedRowsNotLeafs() {
        boolean areLeafs = true;
        for (final Node node : getSelectedNodes()) {
            areLeafs = areLeafs && !getTreeModel().isLeaf(node);
        }
        return areLeafs;
    }

    public void addCommonActions() {
        // EXPAND
        if (menuExpand == null) {
            menuExpand = new JfxMenuItem(new ActionExpandTreeNode(this));
        }
        addTablePopupItem(menuExpand, true);

        // EXPAND ALL
        if (menuExpandAll == null) {
            menuExpandAll = new JfxMenuItem(new ActionExpandAllTreeNodes(this));
        }
        addTablePopupItem(menuExpandAll, true);

        // COLLAPSE
        if (menuCollapse == null) {
            menuCollapse = new JfxMenuItem(new ActionCollapseTreeNode(this));
        }
        addTablePopupItem(menuCollapse, true);
    }

    @Override public void doubleClickTriggered(final MouseEvent ev) {
        if (actionOnDoubleClick != null) {
            actionOnDoubleClick.actionPerformed(createActionEvent(ev));
        }
    }

    public void setDoubleClickAction(final AbstractAction action) {
        actionOnDoubleClick = action;
    }

    private ActionEvent createActionEvent(final MouseEvent mouseEvent) {
        ActionEvent actionEvent = null;

        if (null != mouseEvent) {
            actionEvent = new ActionEvent(getSelectedNodes(), mouseEvent.getID(), mouseEvent.toString(),
                    mouseEvent.getWhen(), mouseEvent.getModifiers());
            mouseEvent.consume();
        }

        return actionEvent;
    }

    public NodeHandler getNodeHandler() {
        return nodeHandler;
    }

    public NewElementDialogHandler getDialogHandler() {
        return dialogHandler;
    }

    public SecureActionValidation getSecureValidator() {
        return secureValidation;
    }

    /**
     * Returns selected object
     *
     * @return the selected DCN-Objects in this view
     */
    public Optional<Node> getSelectedNode() {
        return getSelectedNodes().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     */
    @Override public String getToolTipText(@Nonnull final MouseEvent event) {
        final Optional<String> toolTip = toolTipBuilder.build(event);

        if (toolTip.isPresent()) {
            return toolTip.get();
        }

        return super.getToolTipText(event);
    }

    @Override public Insets getAutoscrollInsets() {
        return new Insets(getHeight(), getWidth(), getHeight(), getWidth());
    }

    @Override public void autoscroll(Point mousePosition) {
        //scrolls table in a such way that square around mouse is always visible
        scrollRectToVisible(squareAround(mousePosition, AUTO_SCROLL_THRESHOLD));
    }

    private Rectangle squareAround(Point point, int side) {
        return new Rectangle(point.x - side, point.y - side, 2 * side, 2 * side);
    }

    /**
     * Handler class for performing plugin actions.
     */
    private static class PerformHandler implements JfxActionPerformed {
        private final BiCNetPluginActionListener listener;
        private final IManagedObject[] objects;

        /**
         * Constructs the perform handler.
         *
         * @param listener Plugin action listener.
         * @param objects  Selected objects.
         */
        public PerformHandler(@Nonnull final BiCNetPluginActionListener listener,
                @Nonnull final IManagedObject[] objects) {
            this.listener = listener;
            this.objects = objects.clone();
        }

        /**
         * Called when menu item or toolbar button associated with action is pressed and condition is fulfilled.
         *
         * @param action Action object.
         */
        @Override public void actionPerformed(final JfxAction action) {
            try {
                listener.eventPluginActionPerformed(objects);

                if (listener instanceof BiCNetPluginActionToggleListener) {
                    action.setChecked(((BiCNetPluginActionToggleListener) listener).isPluginActionChecked(objects));
                }
            } catch (final Exception ex) {
                LOGGER.error("Caught exception while performing action, listener=" + listener.getClass(), ex);
            }
        }
    }

    /**
     * Handler class for updating plug-in actions.
     */
    private static class ConditionHandler implements JfxActionCondition {
        private final BiCNetPluginActionListener listener;
        private final IManagedObject[] objects;

        /**
         * Constructs the update handler.
         *
         * @param listener Plug-in action listener.
         * @param objects  Selected objects.
         */
        public ConditionHandler(@Nonnull final BiCNetPluginActionListener listener,
                @Nonnull final IManagedObject[] objects) {
            this.listener = listener;
            this.objects = objects.clone();
        }

        /**
         * Called when menu item or toolbar button associated with action needs to be updated.
         *
         * @param action Action object.
         * @return True if action can be enabled, false for disabling.
         */
        @Override public boolean fulfilled(final JfxAction action) {
            try {
                if (listener instanceof BiCNetPluginActionToggleListener) {
                    action.setChecked(((BiCNetPluginActionToggleListener) listener).isPluginActionChecked(objects));
                }

                return listener.isPluginActionAllowed(objects);
            } catch (final Exception ex) {
                LOGGER.error("Caught exception while updating action, listener=" + listener.getClass(), ex);
                return false;
            }
        }
    }


    @Override public void popupMenuWillBecomeVisible(final PopupMenuEvent e) {
        final Object menu = e.getSource();
        if (menu instanceof JfxPopupMenu) {
            try {
                // Remove dynamic context menu items
                getTablePopupMenu().removeAll();
                addDynamicContextMenuItems((JfxPopupMenu) menu);
            } catch (final RepositoryException ex) {
                LOGGER.error("An error occurred while while creating popup menu", ex);
            }
            ((JfxPopupMenu) menu).updateActions();
        }
    }

    /**
     * Add context menu items
     *
     * @param e mouse event that triggers the popup menu for context menu
     * @throws RepositoryException
     */
    public void addDynamicContextMenuItems(final JfxPopupMenu e) throws RepositoryException {
        createPopupMenu(Optional.of(e));
    }

    @Override public void popupMenuWillBecomeInvisible(final PopupMenuEvent e) {
        final Object menu = e.getSource();
        if (menu instanceof JfxPopupMenu) {
            ((JfxPopupMenu) menu).removeAll();
        }
    }

    @Override public void popupMenuCanceled(final PopupMenuEvent e) {
        final Object menu = e.getSource();
        if (menu instanceof JfxPopupMenu) {
            ((JfxPopupMenu) menu).removeAll();
        }
    }

    @SuppressWarnings("unchecked")
    @Override public void treeExpanded(final TreeExpansionEvent event) {
        final Node dcnObj = (Node) event.getPath().getLastPathComponent();
        if (dcnObj.getChildCount() == 1) {
            final Enumeration<Node> i = dcnObj.children();
            while (i.hasMoreElements()) {
                getTree().expandRow(getTree().getRowForPath(event.getPath()) + 1);
            }
        }

    }

    @Override public void treeCollapsed(final TreeExpansionEvent event) {
    }

    /**
     * A hammer for findInTree functionality<br/>
     * Sometimes on view initialization tree looses selection
     */
    private void reselectOnClear(ListSelectionEvent e) {
        int anchor = getSelectionModel().getAnchorSelectionIndex();
        int lead = getSelectionModel().getLeadSelectionIndex();
        boolean selectionCleared = anchor == -1 && lead == -1;
        if (!e.getValueIsAdjusting() && selectionCleared) {
            getSelectionModel().setSelectionInterval(e.getFirstIndex(), e.getLastIndex());
        }
    }
}
