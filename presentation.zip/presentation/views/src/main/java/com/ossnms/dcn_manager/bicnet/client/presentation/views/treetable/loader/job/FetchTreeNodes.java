package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader.job;

import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader.NodeLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;

import javax.annotation.Nonnull;

import static org.apache.commons.lang3.StringUtils.EMPTY;

/**
 * Loads the TreeTable Nodes and his dependent nodes. 
 */
public class FetchTreeNodes<K, V> extends FrameworkFetchJob {

    private static final String JOB_ID = FetchTreeNodes.class.getName();
    private static final String JOB_NAME = "Fetch TreeTable Nodes";
    private static final String JOB_ADDITIONAL_INFO = EMPTY;
    
    private final NodeLoader loader;
    
    public FetchTreeNodes(@Nonnull final NodeLoader loader, @Nonnull final FrameworkDocument document) {
        super(JOB_ID, JOB_NAME, JOB_ADDITIONAL_INFO, document);
        this.loader = loader;
    }

    @Override
    public Node execute(Object object) throws FrameworkException {
        try {
           return loader.load();
        } catch (final Exception e) {
            throw new FrameworkException(e);
        }
    }
}