package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import static java.util.Arrays.stream;
import static java.util.stream.Collectors.toList;

public final class NodeCommandExecutor {

    private final IManagedObject[] selection;
    private final Map<Command<IManagedObject>, Collection<IManagedObject>> commands;
    private boolean stopAfterFirstExecution;

    private NodeCommandExecutor(IManagedObject[] selection) {
        this.selection = selection;
        this.commands = new LinkedHashMap<>();
        this.stopAfterFirstExecution = false;
    }

    public static NodeCommandExecutor from(IManagedObject[] selectedNodes) {
        return new NodeCommandExecutor(selectedNodes);
    }

    public NodeCommandExecutor stopAfterFirstCommandExecution() {
        this.stopAfterFirstExecution = true;
        return this;
    }

    public <E extends IManagedObject> NodeCommandExecutor addCommand(@Nonnull Command<IManagedObject> command, @Nonnull Class<E> clazz) {
        commands.put(command, stream(selection).filter(clazz::isInstance).collect(toList()));
        return this;
    }

    public void execute() throws CommandException {
        boolean commandExecuted = false;

        for (final Entry<Command<IManagedObject>, Collection<IManagedObject>> entry : commands.entrySet()) {
            for (final IManagedObject element : entry.getValue()) {
                entry.getKey().call(element);
                commandExecuted = true;
            }

            if (commandExecuted && stopAfterFirstExecution) {
                break;
            }
        }
    }
}
