package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;

public class Containers extends TransferTransformer<IGenericContainerId> {
    public Containers() {
        super(IGenericContainerId.MIME_TYPE, IGenericContainerId.class);
    }
}
