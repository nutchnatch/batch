package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.state.RequiredActivationStateChanged;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;

import javax.annotation.Nonnull;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;
import java.util.Collection;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Listener to change the GUI element which represents the Require activation state.
 */
public class ToggleButtonListener implements TreeSelectionListener {
    private static final boolean ENABLE = true;
    private static final boolean DISABLE = false;

    private final RequiredActivationStateChanged activationStateChanged;

    public ToggleButtonListener(@Nonnull final RequiredActivationStateChanged activationStateChanged) {
        this.activationStateChanged = activationStateChanged;
    }

    /**
     * After process this method the relative GUI element will be checked(Active) or unchecked(Inactive).
     */
    @Override
    public void valueChanged(final TreeSelectionEvent event) {

        TreePath[] paths = event.getPaths();

        if (null != paths) {
            Collection<Node> nodes = Stream.of(paths)
                    .map(TreePath::getLastPathComponent)
                    .map(Node.class::cast)
                    .collect(Collectors.toList());

            toggleButtons(nodes, DISABLE);

            try {
                activationStateChanged.process(nodes);
            } catch (final Exception e) {
               toggleButtons(nodes, ENABLE);
               throw new IllegalStateException(e);
            }
        }
    }

    /*
     * Toggle button to prevent multiple operations calls.
     */
    private void toggleButtons(@Nonnull final Iterable<Node> nodes, final boolean enable) {
        nodes.forEach(node -> node.getValue().setToogleButtonEnable(enable));
    }
}
