package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;

import javax.annotation.Nonnull;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Iterator;
import java.util.Objects;
import java.util.Optional;
import java.util.Queue;
import java.util.stream.Stream;

import static java.util.Collections.asLifoQueue;
import static java.util.Collections.singleton;
import static java.util.Spliterators.spliteratorUnknownSize;
import static java.util.stream.Collectors.toList;
import static java.util.stream.StreamSupport.stream;

/**
 * Handler to find on DCN Tree Table all Type of Nodes.
 */
public final class NodeFinder {

    private NodeFinder() {
    }

    /**
     * Find the first Node Type in tree by Node Name.
     *
     * @param start    node to start the search
     * @param nodeName name to search
     * @return Stream of Nodes
     */
    public static Stream<Node> tryFindNodeByName(@Nonnull final Node start, @Nonnull final String nodeName) {
        return flatten(start).filter(node -> Objects.equals(node.getValue().getName(), nodeName));
    }

    /**
     * Try to find the first NodeMediator by mediatorId.
     *
     * @param start      Node to start the search
     * @param mediatorId Mediator ID to be found
     * @return Optional Node
     */
    public static Optional<NodeMediator> tryFindMediatorNode(@Nonnull final Node start, final int mediatorId) {
        return tryFindAllNodesById(start, mediatorId, NodeMediator.class).findFirst();
    }

    /**
     * Try to find the first Channel by channelId.
     *
     * @param start     Node to start the search
     * @param channelId Channel ID to be found
     * @return Optional Node
     */
    public static Optional<NodeChannel> tryFindChannelNode(@Nonnull final Node start, final int channelId) {
        return tryFindAllNodesById(start, channelId, NodeChannel.class).findFirst();
    }

    /**
     * Try to find the first NE by neId.
     *
     * @param start Node to start the search
     * @param neId  NE ID to be found
     * @return Optional Node
     */
    public static Optional<NodeNe> tryFindNeNode(@Nonnull final Node start, final int neId) {
        return tryFindAllNodesById(start, neId, NodeNe.class).findFirst();
    }

    /**
     * Try to find the first Container by containerId.
     *
     * @param start       Node to start the search
     * @param containerId Container ID to be found
     * @return Optional Node
     */
    public static Optional<NodeContainer> tryFindContainerNode(@Nonnull final Node start, final int containerId) {
        return tryFindAllNodesById(start, containerId, NodeContainer.class).findFirst();
    }

    /**
     * Try to find the first NodeDomain by domainId.
     *
     * @param start    Node to start the search
     * @param domainId Domain ID to be found
     * @return Optional Node
     */
    public static Optional<NodeDomain> tryFindDomainNode(@Nonnull final Node start, final int domainId) {
        return tryFindAllNodesById(start, domainId, NodeDomain.class).findFirst();
    }

    /**
     * Try to find the all NEs by neId.
     *
     * @param start Node to start the search
     * @param neId  NE ID to be found
     * @return Collection of Nodes
     */
    public static Collection<NodeNe> tryFindAllNeNodes(@Nonnull final Node start, final int neId) {
        return tryFindAllNodesById(start, neId, NodeNe.class).collect(toList());
    }

    /**
     * Try to find the all System Containers by id.
     *
     * @param start Node to start the search
     * @param systemContainerId  ID to be found
     * @return Collection of Nodes
     */
    public static Collection<NodeSystemContainer> tryFindAllSystemContainerNodes(@Nonnull final Node start, final int systemContainerId) {
        return tryFindAllNodesById(start, systemContainerId, NodeSystemContainer.class).collect(toList());
    }

    /**
     * Find all Nodes in tree based on Node Id and NodeType.
     *
     * @param start node to start the search
     * @param id    id of node to find
     * @param type  Node Type to find
     * @param <NODE> Generalization of Node Type that is searching
     * @return optional Node
     */
    private static <NODE extends Node> Stream<NODE> tryFindAllNodesById(@Nonnull final Node start, final int id,
            @Nonnull final Class<NODE> type) {
        return flatten(start)
                .filter(node -> node.getId() == id)
                .filter(type::isInstance).map(type::cast);
    }

    /**
     * Lazy stream of all nodes in subtree of provided node
     */
    private static Stream<Node> flatten(Node start) {
        Iterator<Node> iterator = new Iterator<Node>() {
            // LIFO for depth first search; FIFO for breadth first 
            private final Queue<Node> queue = asLifoQueue(new ArrayDeque<>(singleton(start)));

            @Override public Node next() {
                Node next = queue.poll();
                queue.addAll(next.getAllChildren());
                return next;
            }

            @Override public boolean hasNext() {
                return !queue.isEmpty();
            }
        };
        return stream(spliteratorUnknownSize(iterator, 0), false);
    }
}
