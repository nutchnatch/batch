package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.domain;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginView;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableView;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.SortByConnectivityUserPreferences;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.builder.TransferHandlersBuilder;

import javax.annotation.Nonnull;
import javax.swing.event.ListSelectionListener;
import java.util.Properties;

public class TreeTableDomainsView extends TreeTableView implements ListSelectionListener, BiCNetPluginView{
    private static final long serialVersionUID = 9206573062621912213L;
    private static final String ID = TreeTableDomainsView.class.getName();

    private final SortByConnectivityUserPreferences sortByConnectivityUserPreferences;

    public TreeTableDomainsView(String title, TreeTableDomainsDocument document) {
        super(title, document, new TreeTableViewModel(new NodeDomainRoot(DEFAULT_NODE_ROOT_NAME)),
                new TreeTableDomainsNodeHandler(document),
                new DomainContextAction(document.getCommonServices(), document.getRepositoryManager()), 
                TransferHandlersBuilder.domainView());

        sortByConnectivityUserPreferences = new SortByConnectivityUserPreferences(document.getCommonServices());

        initDomainButtons();
        initDomainGuiNames();
        initControls();
    }
    
    @Override
    protected String getProfileId() {
        // This method return this specific class name to store view collapse/expand tree status
        return ID;
    }
    
    /**
     * Initializes toolbar button actions
     */
    private void initDomainButtons() {
        getMenuDomain().setSelected(true);
    }
    
    /**
     * This method sets the GUI Component Labels.
     */
    private void initDomainGuiNames() {
        getTreeTable().setName("DomainsView");
    }

    @Override protected void addExtraPropertiesToSave(@Nonnull final Properties properties) {
        Node root = (Node) getTreeTable().getTreeModel().getRoot();
        sortByConnectivityUserPreferences.setSortByConnectivityPreferences(root, properties);
    }
}
