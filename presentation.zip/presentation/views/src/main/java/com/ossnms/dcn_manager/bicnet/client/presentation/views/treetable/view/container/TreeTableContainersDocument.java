package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.container;

import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.ContainerTreeNodeEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.NeAssignmentTreeEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.SystemAssignmentTreeEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.SystemContainerTreeNodeEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableDocument;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.ContainerGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.SystemContainerGraphicalRepresentationBuilder;

import javax.annotation.Nonnull;

public class TreeTableContainersDocument extends TreeTableDocument {

    private ContainerTreeNodeEventListener containerListener;
    private SystemContainerTreeNodeEventListener systemContainerListener;
    private NeEventListenerForContainerView neListener;
    private SystemAssignmentTreeEventListener systemAssignmentListener;
    private NeAssignmentTreeEventListener neAssignmentListener;

    public TreeTableContainersDocument(final CommonServices commonServices, final RepositoryManager repositoryManager,
                                       final ListenersRegistrationManager changeListener) {
        super(commonServices, repositoryManager, changeListener);
    }

    @Override protected final void addChangeListeners(@Nonnull final ModelUpdater modelUpdater) {
        containerListener = new ContainerTreeNodeEventListener(modelUpdater, getCommonServices(),
                getRepositoryManager(),
                new ContainerGraphicalRepresentationBuilder(getCommonServices().getIconManager()));

        systemContainerListener = new SystemContainerTreeNodeEventListener(modelUpdater, getCommonServices(),
                getRepositoryManager(), new SystemContainerGraphicalRepresentationBuilder(getCommonServices().getIconManager()));

        neListener = new NeEventListenerForContainerView(modelUpdater, getCommonServices(), getRepositoryManager(),
                new NeGraphicalRepresentationBuilder(getCommonServices().getIconManager()));

        systemAssignmentListener = new SystemAssignmentTreeEventListener(modelUpdater, getCommonServices(), getRepositoryManager());

        neAssignmentListener = new NeAssignmentTreeEventListener(modelUpdater, getCommonServices(), getRepositoryManager());

        getChangeListenersManager().addContainerListener(containerListener);
        getChangeListenersManager().addSystemContainerListener(systemContainerListener);
        getChangeListenersManager().addSystemContainerAssignmentListener(systemAssignmentListener);
        getChangeListenersManager().addNEContainerAssignmentListener(neAssignmentListener);
        getChangeListenersManager().addNeListener(neListener);
    }

    @Override protected final void removeChangeListeners() {
        getChangeListenersManager().removeContainerListener(containerListener);
        getChangeListenersManager().removeSystemContainerListener(systemContainerListener);
        getChangeListenersManager().removeSystemContainerAssignmentListener(systemAssignmentListener);
        getChangeListenersManager().removeNEContainerAssignmentListener(neAssignmentListener);
        getChangeListenersManager().removeNeListener(neListener);
    }
}
