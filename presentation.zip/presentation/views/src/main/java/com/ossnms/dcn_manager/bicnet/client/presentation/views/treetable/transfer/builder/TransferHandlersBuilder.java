package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.builder;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common.TransferAcceptor;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.containerview.ContainerAcceptor;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.containerview.NeToContainers;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.containerview.SystemAcceptor;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.mediatorview.ChannelAcceptor;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.mediatorview.NeToChannels;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables.Channels;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables.Containers;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables.Nes;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables.Systems;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;

public final class TransferHandlersBuilder {

    private TransferHandlersBuilder() {
    }

    public static TransferHandlers mediatorView(RepositoryManager repositoryManager, CommonServices commonServices) {
        return new TransferHandlers()
                .with(new Nes(), new NeToChannels(repositoryManager, commonServices))
                .with(new Channels(), new ChannelAcceptor(repositoryManager, commonServices));
    }

    public static TransferHandlers domainView() {
        return new TransferHandlers()
                .with(new Nes(), TransferAcceptor.empty());
    }

    public static TransferHandlers containerView(RepositoryManager repositoryManager, CommonServices commonServices) {
        return new TransferHandlers()
                .with(new Nes(), new NeToContainers(repositoryManager, commonServices))
                .with(new Systems(), new SystemAcceptor(repositoryManager, commonServices))
                .with(new Containers(), new ContainerAcceptor(repositoryManager, commonServices));
    }

    public static TransferHandlers dcnListView(RepositoryManager repositoryManager, CommonServices commonServices) {
        return new TransferHandlers()
                .with(new Nes(), new NeToChannels(repositoryManager, commonServices))
                .with(new Channels(), new ChannelAcceptor(repositoryManager, commonServices))
                .with(new Nes(), new NeToContainers(repositoryManager, commonServices))
                .with(new Systems(), new SystemAcceptor(repositoryManager, commonServices))
                .with(new Containers(), new ContainerAcceptor(repositoryManager, commonServices));
    }    
}
