package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeRouteInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Comparator;
import java.util.Optional;

import static com.google.common.base.Strings.nullToEmpty;

/**
 * Used to order by Node name.
 */
public class NodeDomainComparator implements Comparator<Node> {
    private static final Logger LOGGER = LoggerFactory.getLogger(NodeDomainComparator.class);

    private static final int TO_THE_BEGIN_OF_LIST = -1;
    private static final int TO_THE_END_OF_LIST = Integer.MAX_VALUE;

    private final RepositoryManager repositoryManager;

    public NodeDomainComparator(RepositoryManager repositoryManager) {
        this.repositoryManager = repositoryManager;
    }

    @Override public int compare(@Nonnull final Node node1, @Nonnull final Node node2) {
        return chooseComparator(node1, node2);
    }

    private int chooseComparator(Node node1, Node node2) {
        NodeDomain nodeDomain = (NodeDomain) node1.getParent();

        if (nodeDomain.getSelectedGneId().isPresent()) {
            return compareBySortByConnectivity(nodeDomain, node1, node2);
        }

        return compareByName(node1, node2);
    }

    private int compareBySortByConnectivity(NodeDomain nodeDomain, Node node1, Node node2) {
        Integer selectedGneId = nodeDomain.getSelectedGneId().get();

        try {
            Optional<FullNeData> selectedGne = repositoryManager.getNeRepository().get(selectedGneId);

            if (selectedGne.isPresent()) {
                int cost1 = extractCost(nodeDomain, selectedGne.get(), node1.getId());
                int cost2 = extractCost(nodeDomain, selectedGne.get(), node2.getId());

                return Integer.compare(cost1,cost2);
            }
        } catch (final Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        return compareByName(node1, node2);
    }

    private int extractCost(NodeDomain nodeDomain, FullNeData selectedGne, int neId) throws RepositoryException {
        if (selectedGne.getNe().getId() == neId) {
            return TO_THE_BEGIN_OF_LIST;
        }

        Optional<FullNeData> fullNeData = repositoryManager.getNeRepository().get(neId);

        if (fullNeData.isPresent() && fullNeData.get().getInfo().getNeRouteInfo().isPresent()) {
            Optional<Integer> cost = fullNeData.get().getInfo().getNeRouteInfo().get().stream()
                    .filter(route -> selectedGne.getNe().getNeighbourhoodId().equals(route.getGneNeighbourhoodId()))
                    .filter(route -> nodeDomain.getValue().getName().equals(route.getDomain())).map(NeRouteInfo::getCost).findFirst();
            return cost.orElse(TO_THE_END_OF_LIST);
        }

        return TO_THE_END_OF_LIST;
    }

    private int compareByName(Node node1, Node node2) {
        String node1Name = nullToEmpty(node1.getValue().getName()).toUpperCase();
        String node2Name = nullToEmpty(node2.getValue().getName()).toUpperCase();
        return node1Name.compareTo(node2Name);
    }
}
