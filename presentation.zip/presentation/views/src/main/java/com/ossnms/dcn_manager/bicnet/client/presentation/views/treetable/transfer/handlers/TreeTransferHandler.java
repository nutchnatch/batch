package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.DcnTreeTable;

import javax.annotation.Nonnull;
import javax.swing.JComponent;
import javax.swing.TransferHandler;
import java.awt.datatransfer.Transferable;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers.NodeToManagedObject.resolveManagedObjects;

public class TreeTransferHandler extends TransferHandler {
    private static final long serialVersionUID = 6204984541245068080L;

    private final DcnTreeTable treeTable;
    private final CommonTransferHandler commonTransferHandler;

    public TreeTransferHandler(@Nonnull final DcnTreeTable treeTable, CommonTransferHandler commonTransferHandler) {
        this.treeTable = treeTable;
        this.commonTransferHandler = commonTransferHandler;
    }

    @Override public int getSourceActions(final JComponent component) {
        return MOVE;
    }

    /**
     * Produces transferable for copy and drag from current component
     */
    @Override protected Transferable createTransferable(final JComponent component) {
        return commonTransferHandler.produceTransfer(resolveManagedObjects(treeTable, treeTable.getSelectedNodes()));
    }

    /**
     * Accepts transferable to paste into current component 
     */
    @Override public boolean importData(TransferSupport support) {
        return commonTransferHandler.acceptTransfer(support.getTransferable(), resolveManagedObjects(treeTable, treeTable.getSelectedNodes()));
    }
}
