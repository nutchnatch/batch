package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.google.common.collect.Lists;
import com.ossnms.dcn_manager.bicnet.client.api.html.HtmlGenerator;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;

import javax.annotation.Nonnull;
import javax.swing.tree.TreeNode;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isActivating;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isDeactivating;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isFailed;
import static com.google.common.collect.Iterables.toArray;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NAME;
import static java.util.Collections.binarySearch;
import static java.util.Collections.reverse;
import static java.util.Comparator.comparing;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toList;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.SPACE;

/**
 * Template Method for Node interface.
 */
public abstract class NodeTemplate implements Node {
    private final int id;
    private final Comparator<Node> childrenComparator;
    private Node parent;

    private final NodeValue value;
    private final Columns columns;
    private final List<Node> allChildren;
    private final List<Node> visibleChildren;

    NodeTemplate(final int id, final Columns columns) {
        this(id, columns, null);
    }

    NodeTemplate(int id, Columns columns, Node parent) {
        this(id, columns, parent, comparing(Object::toString, String::compareToIgnoreCase));
    }

    NodeTemplate(int id, Columns columns, Node parent, Comparator<Node> comparator) {
        this.id = id;
        this.columns = columns;
        this.parent = parent;
        this.value = new NodeValue();
        this.allChildren = Lists.newCopyOnWriteArrayList();
        this.visibleChildren = Lists.newCopyOnWriteArrayList();
        this.childrenComparator = comparator;
    }

    @Override
    public void tryUpdateNodeParentToggleButton(boolean parentHasPermission) {
        if (null == parent) {
            return;
        }

        if (!parentHasPermission) {
            parent.getValue().setToogleButtonEnable(false);
        } else {
            final Optional<GuiActualActivationState> parentActualState = Optional.of(parent.getValue().getActualActivationState());
            final boolean enabled = parent.getValue().isToogleButtonChecked() && !isFailed(parentActualState) && parent.hasChildrenActivated();
            final boolean disabled = !(enabled || (isActivating(parentActualState) || isDeactivating(parentActualState)));
            parent.getValue().setToogleButtonEnable(disabled);
        }
    }

    @Override
    public boolean hasChildrenActivated() {
        return allChildren.stream()
                .map(Node::getValue)
                .filter(NodeValue::isNotInactive)
                .findFirst().isPresent();
    }

    @Override public boolean hasNotActiveChild() {
        return allChildren.stream()
                .filter(child -> child.getValue().isNotActive() || child.hasNotActiveChild())
                .findAny().isPresent();
    }

    @Override
    public Optional<Node> getParentNode() {
        return ofNullable(parent);
    }

    @Override
    public void sortChildrenNodes() {
        visibleChildren.sort(childrenComparator);
        allChildren.sort(childrenComparator);
    }

    @Override
    public Optional<Node> findChild(final int childId) {
        return allChildren.stream()
                .filter(n -> n.getId() == childId)
                .findFirst();
    }

    @Override
    public <E extends Node> Optional<E> findChild(final int childId, final Class<E> clazz) {
        return allChildren.stream()
                .filter(clazz::isInstance).map(clazz::cast)
                .filter(n -> n.getId() == childId)
                .findFirst();
    }

    @Override
    public TreeNode getChildAt(final int childIndex) {
        if (childIndex >= 0 && visibleChildren.size() > childIndex) {
            return visibleChildren.get(childIndex);
        }
        throw new IllegalArgumentException("There is no visible child with index " + childIndex);
    }

    @Override
    public int getIndex(final TreeNode node) {
        return visibleChildren.indexOf(node);
    }

    @Override
    public int getChildCount() {
        return visibleChildren.size();
    }

    @Override
    public TreeNode getParent() {
        return parent;
    }

    @Override public boolean addChild(final Node node) {
        /* Verify if the Node already exists. This is a protection to not insert empty lines on TreeTable rows */
        if (allChildren.contains(node)) {
            return false;
        }

        node.setParent(this);
        allChildren.add(calculateIndex(node, allChildren), node);
        if (node.getValue().isVisible()) {
            visibleChildren.add(calculateIndex(node, visibleChildren), node);
        }
        return true;
    }

    @Override public boolean removeChild(@Nonnull final Node child) {
        visibleChildren.remove(child);
        return allChildren.remove(child);
    }

    @Override public Node updateVisibility(Node node) {
        visibleChildren.remove(node);
        if (node.getValue().isVisible()) {
            visibleChildren.add(calculateIndex(node, visibleChildren), node);
        }
        return node;
    }

    @Override
    public void setParent(final Node parent) {
        this.parent = parent;
    }

    @Override
    public boolean getAllowsChildren() {
        return true;
    }

    @Override
    public boolean isLeaf() {
        return visibleChildren.isEmpty();
    }

    @Override
    public Enumeration<TreeNode> children() {
        return visibleChildren.stream().map(TreeNode.class::cast).collect(collectingAndThen(toList(), Collections::enumeration));
    }

    @Override
    public List<Node> getAllChildren() {
        return allChildren;
    }

    @Override
    public Object getColumnByPosition(final int position) {
        final ColumnId columnId = ColumnId.valueOf(position);

        if (columnId == ColumnId.TREE_MODEL) {
            return this;
        } else {
            return columns.valueOf(columnId).map(ColumnValue::getValue).orElse(EMPTY);
        }
    }

    @Override
    @Nonnull
    public Columns getColumns() {
        return columns;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public NodeValue getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value.getName();
    }

    /**
     * Returns all parents of the DCN object in the tree from the direct parent up to the root object.
     *
     * @return Parent object array or null.
     */
    @Override
    public final Node[] getParentPath() {
        final List<Node> parents = new LinkedList<>();
        Node nodeParent = (Node) getParent();

        while (nodeParent != null) {
            parents.add(nodeParent);
            nodeParent = (Node) nodeParent.getParent();
        }

        reverse(parents);

        return toArray(parents, Node.class);
    }

    @Override
    public String getToolTip(@Nonnull final ToolTipType toolTipType) {
        return HtmlGenerator.start().boldText(delimiter(COLUMN_NAME)).simpleHtmlText(getValue().getName()).toHtml();
    }

    String delimiter(TreeTableLabels label) {
        return String.join(":", label.toString(), SPACE);
    }

    private int calculateIndex(Node node, List<Node> collection) {
        int index = binarySearch(collection, node, childrenComparator);
        return index < 0 ? -index - 1 : index;
    }
}
