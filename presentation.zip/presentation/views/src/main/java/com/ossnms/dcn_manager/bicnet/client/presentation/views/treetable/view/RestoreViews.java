package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view;

import com.google.common.base.Joiner;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandManager;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandRegistrar;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Map.Entry;
import java.util.Properties;

/**
 * Process the restore and save of the DCN manager views.
 */
public class RestoreViews {
    static final String CURRENT_VIEW = "CURRENT_VIEW";
    private static final Logger LOGGER = LoggerFactory.getLogger(RestoreViews.class);

    private final DcnPluginHelper pluginHelper;

    private static final String DCN_OPEN_VIEWS_ID = "DCN.OpenViews";
    private static final String CMD_EXTENTION = "CMD";

    private final Iterable<IFrameworkCommand> dcnCommands;
    private final SecureActionValidation secureValidation;

    /**
     * @param pluginHelper BiCNet plug-in resource to restore and save the DCN views.
     * @param dcnCommands All DCN manager registered commands.
     */
    public RestoreViews(@Nonnull final DcnPluginHelper pluginHelper, @Nonnull final Iterable<IFrameworkCommand> dcnCommands, @Nonnull final SecureActionValidation secureValidation) {
        this.dcnCommands = dcnCommands;
        this.pluginHelper = pluginHelper;
        this.secureValidation = secureValidation;
    }

    /**
     * Saves all DCN Manager open views for the current user profile.
     */
    public void saveOpenedViews() {
        final Properties dcnProfile = new Properties();

        for (final IFrameworkCommand dcnCommand : dcnCommands) {
            final List<IFrameworkCommand> activeCommands = FrameworkCommandRegistrar.getUICmdRegister()
                    .getListOfActiveCmds(dcnCommand.getCommandID());

            if (null != activeCommands) {
                for (final IFrameworkCommand activeCommand : activeCommands) {
                    final String cmdId = Joiner.on('.').join(activeCommand.getCommandID().toString(), CMD_EXTENTION);
                    dcnProfile.setProperty(cmdId, activeCommand.getCommandID().toString());
                }
            }
        }

        dcnProfile.setProperty(CURRENT_VIEW, CurrentViewSingleton.getInstance().getCurrentView().name());
        pluginHelper.getClientSession().ifPresent(session -> session.setUserProfile(DCN_OPEN_VIEWS_ID, dcnProfile));
    }

    /**
     * Loads from User profile the saved open views in the last user session.
     */
    public void restoreOpenedViews() {
        pluginHelper.getClientSession()
                .map(session -> session.getUserProfile(DCN_OPEN_VIEWS_ID))
                .ifPresent(userProfile -> {
                    loadCurrentView(userProfile);
                    final boolean operationPermitted = secureValidation
                            .checkPermission(SecureAction.OPEN_MANAGEMENT_VIEW_SAN);
                    for (final Entry<Object, Object> property : userProfile.entrySet()) {
                        final String key = property.getKey().toString();
                        final String value = property.getValue().toString();

                        if (operationPermitted && key.endsWith(CMD_EXTENTION)) {
                            FrameworkCommandManager.getCommandMgr().executeCmd(new FrameworkCommandID(value));
                        }
                    }
                });
    }

    private void loadCurrentView(Properties userProfile) {
        try {
            String property = userProfile.getProperty(CURRENT_VIEW);
            if (null != property) {
                TreeTableViewTypes currentView = TreeTableViewTypes.valueOf(property);
                CurrentViewSingleton.getInstance().changeCurrentView(currentView);
            }
        } catch (Exception e) {
            LOGGER.error("Error to load current view", e);
        }
    }
}