package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;

import javax.swing.Icon;
import javax.swing.UIManager;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;

import static org.apache.commons.lang3.StringUtils.EMPTY;

public class NodeValue {
    private static final Icon DEFAULT_TREE_ICON = UIManager.getIcon("Tree.leafIcon");

    private String name;

    private Icon cachedGraphicalRepresentation;
    private Icon baseIcon;

    private GuiActualActivationState actualActivationState;

    private final AtomicBoolean toogleButtonChecked;
    private final AtomicBoolean toogleButtonEnable;
    private final AtomicBoolean toogleButtonVisible;
    private final AtomicBoolean nodeVisible;

    private final Object mutex = new Object();

    public NodeValue() {
        name = EMPTY;
        toogleButtonChecked = new AtomicBoolean(false);
        toogleButtonEnable = new AtomicBoolean(true);
        toogleButtonVisible = new AtomicBoolean(true);
        nodeVisible = new AtomicBoolean(true);

        baseIcon = DEFAULT_TREE_ICON;
        cachedGraphicalRepresentation = baseIcon;

        actualActivationState = GuiActualActivationState.INACTIVE;
    }

    public String getName() {
        return name;
    }

    public void setName(String idName) {
        name = idName;
    }

    public Icon getGraphicalRepresentation() {
        synchronized (mutex) {
            return cachedGraphicalRepresentation;
        }
    }

    public void setGraphicalRepresentation(Icon icon) {
        synchronized (mutex) {
            baseIcon = icon;
            cachedGraphicalRepresentation = icon;
        }
    }

    public boolean isActive() {
        return actualActivationState == GuiActualActivationState.ACTIVE;
    }

    public boolean isNotInactive() {
        return actualActivationState != GuiActualActivationState.INACTIVE;
    }

    public boolean isNotActive() {
        return actualActivationState != GuiActualActivationState.ACTIVE;
    }

    public boolean isToogleButtonChecked() {
        return toogleButtonChecked.get();
    }

    public boolean isToogleButtonUnChecked() {
        return !toogleButtonChecked.get();
    }

    public void setToogleButtonChecked(boolean toogleButtonChecked) {
        this.toogleButtonChecked.set(toogleButtonChecked);
    }

    public boolean isToogleButtonEnable() {
        return toogleButtonEnable.get();
    }

    public void setToogleButtonEnable(boolean toogleButtonEnable) {
        this.toogleButtonEnable.set(toogleButtonEnable);
    }

    public boolean isToogleButtonVisible() {
        return toogleButtonVisible.get();
    }

    public void setToogleButtonVisible(boolean toogleButtonVisible) {
        this.toogleButtonVisible.set(toogleButtonVisible);
    }

    public GuiActualActivationState getActualActivationState() {
        synchronized (mutex) {
            return actualActivationState;
        }
    }

    public void setActualActivationState(GuiActualActivationState actualActivationState) {
        synchronized (mutex) {
            this.actualActivationState = actualActivationState;
        }
    }

    /**
     * Function that updates icon of Node
     * <p>
     * Input to the overlayAdder is always the same - base icon of the node.
     * This gives ability to add or remove some overlays.
     *
     * @param overlayAdder function from initial icon to updated one
     */
    public void updateOverlay(Function<Icon, Icon> overlayAdder) {
        synchronized (mutex) {
            cachedGraphicalRepresentation = overlayAdder.apply(baseIcon);
        }
    }

    /**
     * @return true if Node should be visible in tree
     */
    public boolean isVisible() {
        return nodeVisible.get();
    }

    /**
     * Changes visibility of Node in tree 
     */
    public void setVisible(boolean visible) {
        nodeVisible.set(visible);
    }
}
