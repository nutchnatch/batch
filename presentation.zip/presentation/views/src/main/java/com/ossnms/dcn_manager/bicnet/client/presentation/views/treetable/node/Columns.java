package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

public class Columns {
    private final Collection<ColumnValue> values;

    private final Object mutex = new Object();

    public Columns() {
        final Builder<ColumnValue> builder = ImmutableList.builder();

        builder.add(new ColumnValue(ColumnId.STATE));
        builder.add(new ColumnValue(ColumnId.NETWORK_NAME));
        builder.add(new ColumnValue(ColumnId.TYPE));
        builder.add(new ColumnValue(ColumnId.INFO));
        builder.add(new ColumnValue(ColumnId.ADDRESS));
        builder.add(new ColumnValue(ColumnId.CONNECT_VIA));
        builder.add(new ColumnValue(ColumnId.STANDBY_STATE));
        builder.add(new ColumnValue(ColumnId.USER_TEXT));
        builder.add(new ColumnValue(ColumnId.LOCATION));

        values = builder.build();
    }
    
    public Columns setValue(ColumnId columnId, String value) {
        synchronized (mutex) {
            valueOf(columnId).get().value(value);
        }
        return this;
    }
    
    public Optional<ColumnValue> valueOf(@Nonnull final ColumnId columnId) {
        synchronized (mutex) {
            return values.stream()
                    .filter(input -> input.getColumnId() == columnId)
                    .findFirst();
        }
    }    
}
