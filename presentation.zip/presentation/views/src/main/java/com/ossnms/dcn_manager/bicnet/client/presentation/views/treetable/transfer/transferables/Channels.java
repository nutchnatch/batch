package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;

public class Channels extends TransferTransformer<IEMId> {
    public Channels() {
        super(IEMId.MIME_TYPE, IEMId.class);
    }
}
