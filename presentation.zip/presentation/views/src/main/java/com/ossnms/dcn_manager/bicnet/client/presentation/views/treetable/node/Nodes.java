package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.bicnet.bcb.model.IManagedObject;

import java.util.Collection;

/**
 * Commons utils for Tree table Nodes.
 */
public final class Nodes {

    private Nodes() {
    }

    public static boolean isSingleSelection(IManagedObject[] nodes) {
        return nodes != null && nodes.length == 1;
    }

    public static boolean isSingleSelection(Collection<?> nodes) {
        return nodes != null && nodes.size() == 1;
    }
}
