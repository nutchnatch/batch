package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable;

import com.coriant.widgets.treetable.TreeTable;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;

import static com.google.common.base.Preconditions.checkNotNull;
import static java.util.Collections.singleton;

@Immutable
public class TreeTableModelUpdater implements ModelUpdater {

    /**
     * Updates the GUI
     */
    private static final boolean REPAINT = true;

    /**
     * Do not fire internal events.
     *
     * @see com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.ToggleButtonListener#valueChanged(javax.swing.event.TreeSelectionEvent)
     */
    private static final boolean SILENTLY = true;

    private final TreeTableViewModel treeTableModel;
    private final TreeTable<Node> table;

    public TreeTableModelUpdater(
            @Nonnull final TreeTableViewModel treeTableModel, @Nonnull final TreeTable<Node> table) {
        this.treeTableModel = treeTableModel;
        this.table = table;
    }

    @Override
    public void insertNode(@Nonnull final Node node) {
        checkNotNull(node);
        treeTableModel.eventNodeInserted(node);
    }

    @Override
    public void updateNode(@Nonnull final Node node) {
        checkNotNull(node);
        treeTableModel.eventNodesChanged(singleton(node));
    }

    @Override
    public void removeNode(@Nonnull final Node node) {
        checkNotNull(node);
        treeTableModel.eventNodeRemoved(node);
    }

    @Override
    public void updateRequiredActivationState(@Nonnull final Node node, final boolean selected) {
        checkNotNull(node);
        table.setToggleSelectedNodes(Collections.singletonList(node), selected, SILENTLY, REPAINT);
    }

    @Override public void applyStructureChanged(Node node) {
        treeTableModel.structureChanged(node);
    }

    void updateNodes(@Nonnull final Collection<Node> nodes) {
        if (!nodes.isEmpty()) {
            treeTableModel.eventNodesChanged(nodes);
        }
    }

    void updateRequiredActivationState(Collection<Node> nodes, boolean selected) {
        if (!nodes.isEmpty()) {
            table.setToggleSelectedNodes(new ArrayList<>(nodes), selected, SILENTLY, REPAINT);
        }
    }

    @Override
    public Node getNodeRoot() {
        return (Node) treeTableModel.getRoot();
    }


    /**
     * Updater that buffers updates to tree during defined period of time {@link BufferedUpdater#TIME_BUFFER_MILLIS}
     */
    public static final class BufferedUpdater implements ActionListener, ModelUpdater {

        private static final int TIME_BUFFER_MILLIS = 500;

        private static final boolean SELECTED = true;
        private static final boolean DESELECTED = false;

        private final Collection<Node> selectedNodes = new HashSet<>();
        private final Collection<Node> deselectedNodes = new HashSet<>();
        private final Collection<Node> updatedNodes = new HashSet<>();
        

        private final Timer modelUpdateTimer;
        private final TreeTableModelUpdater treeTableModelUpdater;

        public BufferedUpdater(TreeTableModelUpdater treeTableModelUpdater) {
            this.treeTableModelUpdater = treeTableModelUpdater;

            modelUpdateTimer = new Timer(TIME_BUFFER_MILLIS, this);
            modelUpdateTimer.setCoalesce(true);
        }

        @Override public void updateRequiredActivationState(@Nonnull final Node node, final boolean selected) {
            if (selected) {
                selectedNodes.add(node);
                deselectedNodes.remove(node);
            } else {
                selectedNodes.remove(node);
                deselectedNodes.add(node);
            }
            startTimer();
        }

        @Override public void applyStructureChanged(Node node) {
            //no buffers for now
            treeTableModelUpdater.applyStructureChanged(node);
        }

        @Override public Node getNodeRoot() {
            return treeTableModelUpdater.getNodeRoot();
        }

        @Override public void insertNode(Node node) {
            //no buffers for now
            treeTableModelUpdater.insertNode(node);
        }

        @Override public void updateNode(Node node) {
            updatedNodes.add(node);
            startTimer();
        }

        @Override public void removeNode(Node node) {
            //no buffers:
            // node should be removed from view immediately 
            // because later node looses reference to parent and parent forgets index of this node 
            // so it breaks algorithm of node removal and makes tree inconsistent
            // @see com.coriant.widgets.treetable.AbstractTreeTableModel.treeNodeRemoved()
            treeTableModelUpdater.removeNode(node);
        }

        @Override public void actionPerformed(ActionEvent e) {
            // called by timer tick

            treeTableModelUpdater.updateRequiredActivationState(selectedNodes, SELECTED);
            treeTableModelUpdater.updateRequiredActivationState(deselectedNodes, DESELECTED);
            treeTableModelUpdater.updateNodes(updatedNodes);

            selectedNodes.clear();
            deselectedNodes.clear();
            updatedNodes.clear();

            stopTimer();
        }

        private void startTimer() {
            if (!modelUpdateTimer.isRunning()) {
                modelUpdateTimer.start();
            }
        }

        private void stopTimer() {
            if (modelUpdateTimer.isRunning()) {
                modelUpdateTimer.stop();
            }
        }
    }
}
