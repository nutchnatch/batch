package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeMediatorMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

public class MediatorTreeNodeEventListener extends TreeNodeEventListener<FullMediatorData, NodeMediator> {

    private static final Logger LOGGER = LoggerFactory.getLogger(MediatorTreeNodeEventListener.class);

    public MediatorTreeNodeEventListener(@Nonnull final ModelUpdater modelUpdater, final CommonServices commonServices,
            final RepositoryManager repositoryManager, GraphicalRepresentationBuilder<FullMediatorData> graphicalRepresentation) {
        super(modelUpdater, commonServices, repositoryManager,
                new NodeMediatorMutationApplier(repositoryManager, commonServices, graphicalRepresentation));
    }

    @Override protected void remove(@Nonnull final FullMediatorData fullMediatorData) {
        final Node nodeRoot = getModelUpdater().getNodeRoot();

        nodeRoot.findChild(fullMediatorData.getMediator().getId()).ifPresent((node) -> {
            getModelUpdater().removeNode(node);
            nodeRoot.removeChild(node);

            LOGGER.debug("Mediator({}) removed.", fullMediatorData.getMediator().getIdName());
        });
    }

    @Override protected void add(@Nonnull final FullMediatorData fullMediatorData) {
        final Node nodeRoot = getModelUpdater().getNodeRoot();
        final NodeMediator nodeMediator = new NodeMediator(fullMediatorData.getMediator().getId(), nodeRoot);
        nodeMediator.getValue().setName(fullMediatorData.getIdName());

        if (nodeRoot.addChild(nodeMediator)) {
            getMutationApplier().applyMutation(fullMediatorData, nodeMediator);
            getModelUpdater().insertNode(nodeMediator);
            getModelUpdater().updateRequiredActivationState(nodeMediator, nodeMediator.getValue().isToogleButtonChecked());

            LOGGER.debug("Mediator({}) added.", fullMediatorData.getMediator().getIdName());
        }
    }

    @Override protected void update(@Nonnull final FullMediatorData fullMediatorData) {
        final Node nodeRoot = getModelUpdater().getNodeRoot();

        nodeRoot.findChild(fullMediatorData.getMediator().getId()).ifPresent((node) -> {
            if (getMutationApplier().structureChanged(fullMediatorData, (NodeMediator) node)) {
                getMutationApplier().applyMutation(fullMediatorData, (NodeMediator) node);
                getModelUpdater().applyStructureChanged(node);
            } else {
                getMutationApplier().applyMutation(fullMediatorData, (NodeMediator) node);
                getModelUpdater().updateNode(node);
            }

            getModelUpdater().updateRequiredActivationState(node, node.getValue().isToogleButtonChecked());

            LOGGER.debug("Mediator({}) updated. {}", fullMediatorData.getMediator().getIdName(), fullMediatorData);
        });
    }
}