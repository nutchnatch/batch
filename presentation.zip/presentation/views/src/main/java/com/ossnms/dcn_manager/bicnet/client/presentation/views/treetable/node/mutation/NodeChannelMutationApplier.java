package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.ossnms.dcn_manager.bicnet.client.api.state.RequiredStateVerification;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.StaticConfiguration;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;

import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isActive;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isDeactivating;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_CHANNELS_SAN;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_MEDIATORS_SAN;
import static java.util.Comparator.comparing;
import static org.apache.commons.lang3.StringUtils.EMPTY;

public class NodeChannelMutationApplier extends NodeMutationApplier<FullChannelData, NodeChannel> {

    private final NodeNeMutationApplier nodeNeMutationApplier;
    private final StaticConfiguration staticConfiguration;

    public NodeChannelMutationApplier(RepositoryManager repositoryManager,
                                      CommonServices commonServices, GraphicalRepresentationBuilder<FullChannelData> graphicalRepresentation) {
        super(repositoryManager, commonServices, graphicalRepresentation);
        staticConfiguration = commonServices.getStaticConfiguration();
        nodeNeMutationApplier = new NodeNeMutationApplier(repositoryManager, commonServices,
                new NeGraphicalRepresentationBuilder(commonServices.getIconManager()));
    }

    @Override
    public NodeMutationApplier<FullChannelData, NodeChannel> applyMutation(FullChannelData fullChannelData, NodeChannel node) {
        applyGraphicalRepresentationMutation(fullChannelData, node);
        updateWarningIcon(node, Node::hasNotActiveChild);

        applyToogleButtonChanges(fullChannelData, node);
        node.getValue().setName(fullChannelData.getChannel().getIdName());

        node.getColumns().setValue(ColumnId.ADDRESS, fullChannelData.getChannel().getDisplayAddress())
                .setValue(ColumnId.INFO, fullChannelData.getChannel().getAdditionalInfo())
                .setValue(ColumnId.STATE, fullChannelData.getChannel().getDisplayState())
                .setValue(ColumnId.STANDBY_STATE, fullChannelData.getInfo().getStandbyDisplayState().orElse(EMPTY))
                .setValue(ColumnId.TYPE, typeLabel(fullChannelData.getChannel().getEmType()))
                .setValue(ColumnId.USER_TEXT, fullChannelData.getInfo().getUserText().orElse(EMPTY));

        return this;
    }

    @Override
    public NodeMutationApplier<FullChannelData, NodeChannel> applyParentUpdate(FullChannelData fullChannelData, NodeChannel channel) {
        updateParentOf(channel, mediator -> updateWarningIcon(mediator, Node::hasNotActiveChild));
        return this;
    }

    private String typeLabel(String typeName) {
        return staticConfiguration.findChannelType(typeName)
                .flatMap(ChannelType::guiLabel)
                .orElse(typeName);
    }

    @Override public boolean structureChanged(FullChannelData fullChannelData, NodeChannel node) {
        return !Objects.equals(fullChannelData.getChannel().getIdName(), node.getValue().getName());
    }

    @Override
    public NodeMutationApplier<FullChannelData, NodeChannel> loadChildrenNodes(NodeChannel nodeChannel) throws RepositoryException {
        final Collection<FullNeData> neList = getRepositoryManager().getNeRepository()
                .queries()
                .findByParentId(nodeChannel.getId())
                .stream()
                .sorted(comparing(ne -> ne.getNe().getIdName()))
                .collect(Collectors.toList());

        neList.forEach(ne -> {
            NodeNe nodeNe = new NodeNe(ne.getInfo().getNeId(), nodeChannel);
            nodeNeMutationApplier.applyMutation(ne, nodeNe);
            nodeChannel.addChild(nodeNe);
        });

        return this;
    }

    void applyToogleButtonChanges(FullChannelData fullChannelData, NodeChannel node) {
        final Optional<GuiActualActivationState> actualActivationState = fullChannelData.getInfo()
                .getGuiActiveActualActivationState();

        boolean isRequiredStateActive = RequiredStateVerification.isEnable(fullChannelData.getChannel());

        node.getValue().setToogleButtonChecked(isRequiredStateActive);
        actualActivationState.ifPresent(activationState -> node.getValue().setActualActivationState(activationState));

        if (isRequiredStateActive && isActive(actualActivationState)) {
            node.getValue().setToogleButtonEnable(!node.hasChildrenActivated());

        } else if (isDeactivating(actualActivationState)) {
            node.getValue().setToogleButtonEnable(false);

        } else {
            node.getValue().setToogleButtonEnable(true);
        }

        checkRequiredActivationPermission(fullChannelData.getChannel(), node, OP_ACTIVATE_CHANNELS_SAN);

        node.tryUpdateNodeParentToggleButton(checkPermission(OP_ACTIVATE_MEDIATORS_SAN, fullChannelData.getChannel().getAssociatedMediator()));
    }
}
