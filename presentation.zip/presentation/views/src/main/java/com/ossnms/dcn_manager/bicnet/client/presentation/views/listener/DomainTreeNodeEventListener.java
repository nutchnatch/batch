package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainComparator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeDomainMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeNeMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toSet;

public class DomainTreeNodeEventListener extends TreeNodeEventListener<IAS, NodeDomain> {

    private static final Logger LOGGER = LoggerFactory.getLogger(DomainTreeNodeEventListener.class);

    private final NodeNeMutationApplier nodeNeMutationApplier;

    public DomainTreeNodeEventListener(@Nonnull final ModelUpdater modelUpdater, final CommonServices commonServices,
                                       final RepositoryManager repositoryManager,
                                       final GraphicalRepresentationBuilder<IAS> graphicalRepresentation) {
        super(modelUpdater, commonServices, repositoryManager,
                new NodeDomainMutationApplier(repositoryManager, commonServices, graphicalRepresentation));

        nodeNeMutationApplier = new NodeNeMutationApplier(repositoryManager, commonServices,
                new NeGraphicalRepresentationBuilder(commonServices.getIconManager()));
    }

    @Override
    protected void remove(@Nonnull IAS domain) {
        final Node nodeRoot = getModelUpdater().getNodeRoot();
        nodeRoot.findChild(domain.getId(), NodeDomain.class)
                .ifPresent(nodeDomain -> {
                    getModelUpdater().removeNode(nodeDomain);
                    nodeRoot.removeChild(nodeDomain);
                });
    }

    @Override
    protected void add(@Nonnull IAS domain) {
        final Node nodeRoot = getModelUpdater().getNodeRoot();
        final NodeDomain nodeDomain = new NodeDomain(domain.getId(), nodeRoot, new NodeDomainComparator(getRepositoryManager()));
        getMutationApplier().applyMutation(domain, nodeDomain);
        if (nodeRoot.addChild(nodeDomain)) {
            loadChildren(nodeDomain);
            getModelUpdater().insertNode(nodeDomain);
            LOGGER.debug("Domain({}) added.", domain.getIdName());
        }
    }

    @Override
    protected void update(@Nonnull IAS domain) {
        final Node nodeRoot = getModelUpdater().getNodeRoot();
        final Optional<NodeDomain> optDomain = nodeRoot.findChild(domain.getId(), NodeDomain.class);
        optDomain.ifPresent(nodeDomain -> {
            if (getMutationApplier().structureChanged(domain, nodeDomain)) {
                getMutationApplier().applyMutation(domain, nodeDomain);
                getModelUpdater().applyStructureChanged(nodeDomain);
            } else {
                getMutationApplier().applyMutation(domain, nodeDomain);
                getModelUpdater().updateNode(nodeDomain);
            }
            updateChildren(nodeDomain, domain.getNeList());
        });
    }

    /**
     * Loads children NEs to new domain
     */
    private void loadChildren(final NodeDomain nodeDomain) {
        try {
            getMutationApplier().loadChildrenNodes(nodeDomain);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch NEs", e);
        }
    }

    /**
     * Update NEs that belongs to the domain
     */
    private void updateChildren(final Node nodeDomain, final INEId[] neIds) {
        if (neIds == null) {
            return;
        }

        nodeDomain.getAllChildren()
                .stream()
                .filter(child -> !ArrayUtils.contains(neIds, child.getId()))
                .forEach(child -> {
                    getModelUpdater().removeNode(child);
                    nodeDomain.removeChild(child);
                });

        Set<Integer> currentChildren = nodeDomain.getAllChildren().stream()
                .map(Node::getId)
                .collect(toSet());

        Stream.of(neIds)
                .filter(neId -> !currentChildren.contains(neId.getId()))
                .flatMap(this::fetchNe)
                .forEach(fullNe -> createNeNode(nodeDomain, fullNe));
    }

    private void createNeNode(Node nodeDomain, FullNeData fullNeData) {
        final NodeNe nodeNe = new NodeNe(fullNeData.getNe().getId(), nodeDomain);
        nodeNeMutationApplier.applyMutation(fullNeData, nodeNe);
        nodeDomain.addChild(nodeNe);
        getModelUpdater().insertNode(nodeNe);
        getModelUpdater().updateRequiredActivationState(nodeNe, nodeNe.getValue().isToogleButtonChecked());
    }

    private Stream<FullNeData> fetchNe(INEId neId) {
        try {
            return getRepositoryManager().getNeRepository().get(neId.getId())
                    .map(Stream::of).orElseGet(Stream::empty);
        } catch (RepositoryException e) {
            LOGGER.error("Error on repository", e);
            return Stream.empty();
        }
    }
}