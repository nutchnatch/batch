package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NoOpsMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeSystemContainerMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.SystemContainerGraphicalRepresentationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.function.BiConsumer;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindContainerNode;
import static java.util.Optional.of;
import static java.util.function.Function.identity;

public class SystemAssignmentTreeEventListener extends TreeNodeEventListener<ISystemGenericContainerAssignment, Node> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SystemAssignmentTreeEventListener.class);
    private final NodeSystemContainerMutationApplier systemMutationApplier;

    public SystemAssignmentTreeEventListener(ModelUpdater modelUpdater, CommonServices commonServices, RepositoryManager repositoryManager) {
        super(modelUpdater, commonServices, repositoryManager, new NoOpsMutationApplier<>(repositoryManager, commonServices));

        systemMutationApplier = new NodeSystemContainerMutationApplier(
                repositoryManager, commonServices, new SystemContainerGraphicalRepresentationBuilder(commonServices.getIconManager()));
    }

    @Override protected void remove(@Nonnull ISystemGenericContainerAssignment assignment) {
        forNodesIn(assignment, (nodeContainer, nodeSystem) -> {
            getModelUpdater().removeNode(nodeSystem);
            nodeContainer.removeChild(nodeSystem);
        });
        LOGGER.debug("REMOVE {}", assignment);
    }

    @Override protected void add(@Nonnull ISystemGenericContainerAssignment assignment) {
        forContainerAndSystemIn(assignment, (nodeContainer, system) -> {
            try {
                NodeSystemContainer nodeSystem = new NodeSystemContainer(system.getId(), nodeContainer);
                systemMutationApplier.applyMutation(system, nodeSystem);
                systemMutationApplier.loadChildrenNodes(nodeSystem);
                if (nodeContainer.addChild(nodeSystem)) {
                    getModelUpdater().insertNode(nodeSystem);
                    nodeSystem.getAllChildren().forEach(node ->
                            getModelUpdater().updateRequiredActivationState(node, node.getValue().isToogleButtonChecked()));
                }
            } catch (RepositoryException e) {
                LOGGER.error("Error while loading children of system container {}", system, e);
            }
        });
        LOGGER.debug("ADD {}", assignment);
    }

    @Override protected void update(@Nonnull ISystemGenericContainerAssignment assignment) {
        //no changes in tree
    }

    private void forContainerAndSystemIn(ISystemGenericContainerAssignment assignment, BiConsumer<Node, ISystemContainer> consumer) {
        try {
            int systemId = assignment.getSystemContainerId();
            int containerId = assignment.getGenericContainerId();
            getRepositoryManager().getSystemContainerRepository().get(systemId).ifPresent(system ->
                    findContainer(containerId).ifPresent(nodeContainer ->
                            consumer.accept(nodeContainer, system)));
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch system", e);
        }

    }

    private void forNodesIn(ISystemGenericContainerAssignment assignment, BiConsumer<Node, NodeSystemContainer> consumer) {
        int containerId = assignment.getGenericContainerId();
        int systemId = assignment.getSystemContainerId();
        findContainer(containerId).ifPresent(nodeContainer ->
                nodeContainer.findChild(systemId, NodeSystemContainer.class).ifPresent(nodeSystemContainer ->
                        consumer.accept(nodeContainer, nodeSystemContainer)));
    }

    private Optional<Node> findContainer(int containerId) {
        return getModelUpdater().getNodeRoot().getId() == containerId
                ? of(getModelUpdater().getNodeRoot())
                : tryFindContainerNode(getModelUpdater().getNodeRoot(), containerId).map(identity());
    }
}
