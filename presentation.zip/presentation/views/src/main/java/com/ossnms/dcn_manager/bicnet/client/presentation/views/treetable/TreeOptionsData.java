package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable;

import com.ossnms.tools.jfx.JfxOptionsData;
import com.ossnms.tools.jfx.JfxProperties;

public class TreeOptionsData extends JfxOptionsData {

    private JfxProperties tableProperties;
    private JfxProperties ldapProperties;

    @Override
    public void loadData(JfxProperties propData) {
        ldapProperties = propData;
    }

    @Override
    public void saveData(JfxProperties propData) {
        if(tableProperties != null) {
            propData.putAll(tableProperties);
        }
    }

    public void setTableProperties(JfxProperties props) {
        this.tableProperties = props;
    }
    
    public JfxProperties getLdapProperties() {
        return ldapProperties;
    }
}
