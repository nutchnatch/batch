package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common.TransferAcceptor;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables.TransferTransformer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables.Transfers;

import java.awt.datatransfer.Transferable;
import java.util.Collection;

public class CommonTransferHandler {
    private final Collection<TransferTransformer<?>> transformers;
    private final Collection<TransferAcceptor<Transferable, IManagedObject>> acceptors;

    public CommonTransferHandler(Collection<TransferTransformer<?>> transformers, Collection<TransferAcceptor<Transferable, IManagedObject>> acceptors) {
        this.transformers = transformers;
        this.acceptors = acceptors;
    }

    /**
     * Validates if these object can be transferred
     */
    boolean canProduceTransfer(Collection<IManagedObject> objects) {
        return transformers.stream().anyMatch(transformer -> transformer.supports(objects));
    }

    /**
     * Produces Transferable for provided objects
     */
    public Transferable produceTransfer(Collection<IManagedObject> objects) {
        return transformers.stream()
                .map(transformer -> transformer.transferable(objects))
                .reduce(Transfers.NO_TRANSFER, Transfers::join);
    }

    /**
     * Validates if destination objects can accept transformers
     */
    boolean canAcceptTransfer(Transferable transferable, Collection<IManagedObject> destinations) {
        if (destinations.size() != 1) {
            return false; //can not paste into multiple destinations
        }
        return destinations.stream().findFirst().map(destination ->
                acceptors.stream()
                        .filter(acceptor -> acceptor.matches(transferable, destination))
                        .allMatch(acceptor -> acceptor.canAccept(transferable, destination)))
                .orElse(false);
    }

    /**
     * Performs transfer to destination objects
     *
     * @return true if transfer was completed
     */
    boolean acceptTransfer(Transferable transferable, Collection<IManagedObject> destinations) {
        return canAcceptTransfer(transferable, destinations) &&
                destinations.stream().findFirst().map(destination -> acceptors.stream()
                        .filter(acceptor -> acceptor.matches(transferable, destination))
                        .map(acceptor -> acceptor.perform(transferable, destination))
                        .reduce(true, Boolean::logicalAnd)) //the same as allMatch but actually process the whole stream
                        .orElse(false);
    }
}
