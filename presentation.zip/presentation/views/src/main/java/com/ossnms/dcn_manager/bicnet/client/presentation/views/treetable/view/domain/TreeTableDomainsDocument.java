package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.domain;

import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.DomainTreeNodeEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableDocument;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.DomainGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;

import javax.annotation.Nonnull;

public class TreeTableDomainsDocument extends TreeTableDocument {

    private DomainTreeNodeEventListener domainListener;
    private NeEventListenerForDomainView neListener;

    public TreeTableDomainsDocument(final CommonServices commonServices, final RepositoryManager repositoryManager,
            final ListenersRegistrationManager changeListener) {
        super(commonServices, repositoryManager, changeListener);
    }

    @Override protected final void addChangeListeners(@Nonnull final ModelUpdater modelUpdater) {
        domainListener = new DomainTreeNodeEventListener(modelUpdater, getCommonServices(), getRepositoryManager(),
            new DomainGraphicalRepresentationBuilder(getCommonServices().getIconManager()));

        neListener = new NeEventListenerForDomainView(modelUpdater, getCommonServices(), getRepositoryManager(),
            new NeGraphicalRepresentationBuilder(getCommonServices().getIconManager()));

        getChangeListenersManager().addDomainListener(domainListener);
        getChangeListenersManager().addNeListener(neListener);
    }

    @Override protected final void removeChangeListeners() {
        getChangeListenersManager().removeDomainListener(domainListener);
        getChangeListenersManager().removeNeListener(neListener);
    }
}
