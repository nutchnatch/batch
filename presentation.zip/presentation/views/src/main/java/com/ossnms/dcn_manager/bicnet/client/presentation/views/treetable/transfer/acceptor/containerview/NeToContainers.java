package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.containerview;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobAssociateNEsWithContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobAssociateNEsWithSystem;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common.AbstractAcceptor;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Set;
import java.util.function.Function;

import static com.ossnms.dcn_manager.bicnet.client.api.ObjectUtils.anyMatch;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.MOVE_NE_SAN;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_PROPERTIES_NE_SAN;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;

public class NeToContainers extends AbstractAcceptor<INEId> {
    private static final Logger LOGGER = LoggerFactory.getLogger(NeToContainers.class);

    public NeToContainers(RepositoryManager repositoryManager, CommonServices commonServices) {
        super(repositoryManager, commonServices);
    }

    @Override
    public boolean canAccept(Collection<INEId> nes, IManagedObject destination) {
        if (anyMatch(destination, IGenericContainer.class)) {
            return checkPermission(MOVE_NE_SAN, nes);
        }
        if (anyMatch(destination, ISystemContainer.class)) {
            return checkPermission(MOVE_NE_SAN, nes) &&
                    withTheSamePermissions(nes, (ISystemContainer) destination);
        }
        return false;
    }

    @Override
    public boolean perform(Collection<INEId> transfer, IManagedObject destination) {
        if (anyMatch(destination, IGenericContainer.class)) {
            return moveToContainer(transfer, (IGenericContainer) destination);
        }
        if (anyMatch(destination, ISystemContainer.class)) {
            return moveToSystem(transfer, (ISystemContainer) destination);
        }
        return false;
    }

    private boolean moveToSystem(Collection<INEId> nes, ISystemContainer systemContainer) {
        queueJob(new JobAssociateNEsWithSystem(getPluginHelper().getSessionContext(), getFacade(), nes, systemContainer));
        return true;
    }

    private boolean moveToContainer(Collection<INEId> nes, IGenericContainer container) {
        queueJob(new JobAssociateNEsWithContainer(getPluginHelper().getSessionContext(), getFacade(), nes, container, asList(container)));
        return true;
    }

    /**
     * Only allow move when all NEs to be transferred have the same permission as the System Container
     */
    private boolean withTheSamePermissions(Collection<INEId> nes, ISystemContainer system) {
        Collection<INEId> nesUnderSystem = fetchNesUnder(system.getId()).stream()
                .map(FullNeData::getNe)
                .limit(1) //for now we take any NE from target system
                .collect(toList());

        Set<Boolean> permissionsUnderSystem = checkAll(nesUnderSystem, this::canOpenProperties);
        Set<Boolean> nesPermissions = checkAll(nes, this::canOpenProperties);

        return nesUnderSystem.isEmpty() // there is no problem in moving an NE to empty System
                || permissionsUnderSystem.equals(nesPermissions);
    }

    private Set<Boolean> checkAll(Collection<INEId> nes, Function<INEId, Boolean> permission) {
        return nes.stream().map(permission).collect(toSet());
    }

    private boolean canOpenProperties(INEId neId) {
        return checkPermission(OP_PROPERTIES_NE_SAN, neId);
    }

    private Collection<FullNeData> fetchNesUnder(int systemContainerId) {
        try {
            return getRepositoryManager().getNeRepository().queries()
                    .findBySystemContainerId(systemContainerId);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch NEs while checking permissions", e);
            return emptyList();
        }
    }
}