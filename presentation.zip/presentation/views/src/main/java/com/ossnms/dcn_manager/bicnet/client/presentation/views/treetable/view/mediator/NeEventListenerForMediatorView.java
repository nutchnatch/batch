package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.mediator;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.NeTreeNodeEventListenerTemplate;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindChannelNode;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindNeNode;

public class NeEventListenerForMediatorView extends NeTreeNodeEventListenerTemplate {

    public NeEventListenerForMediatorView(ModelUpdater modelUpdater, CommonServices commonServices,
            RepositoryManager repositoryManager, NeGraphicalRepresentationBuilder graphicalRepresentation) {
        super(modelUpdater, commonServices, repositoryManager, graphicalRepresentation);
    }

    @Override protected void remove(@Nonnull FullNeData fullNeData) {
        final Optional<NodeNe> nodeNe = tryFindNeNode(getModelUpdater().getNodeRoot(), fullNeData.getNe().getId());

        nodeNe.ifPresent(node -> removeNe(fullNeData, node));
    }

    @Override protected void add(@Nonnull FullNeData fullNeData) {
        final Optional<NodeChannel> nodeChannel = tryFindChannelNode(getModelUpdater().getNodeRoot(),
                fullNeData.getNe().getAssociatedEmId());

        nodeChannel.ifPresent(nodeParent -> addNe(fullNeData, nodeParent));
    }

    @Override protected void update(@Nonnull FullNeData fullNeData) {
        final Optional<NodeNe> nodeNe = tryFindNeNode(getModelUpdater().getNodeRoot(), fullNeData.getNe().getId());

        nodeNe.ifPresent(node -> updateNe(fullNeData, node));
    }

    @Override protected Optional<Node> getParentIfChanged(final Node nodeNe, final INE element) {
        final Node oldParent = (Node) nodeNe.getParent();
        return oldParent.getId() != element.getAssociatedEmId() ? Optional.of(oldParent) : Optional.empty();
    }

    @Override protected void applyParentMutation(final Node oldParent, final Node nodeNe, final FullNeData parent) {
        final Optional<NodeChannel> newParent = tryFindChannelNode(getModelUpdater().getNodeRoot(),
                parent.getNe().getAssociatedEmId());

        newParent.ifPresent(node -> moveNode(oldParent, nodeNe, node));
    }
}
