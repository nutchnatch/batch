package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.mediator;

import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.ChannelTreeNodeEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.MediatorTreeNodeEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableDocument;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.ChannelGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.MediatorGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;

import javax.annotation.Nonnull;

public class TreeTableMediatorsDocument extends TreeTableDocument {

    private MediatorTreeNodeEventListener mediatorListener;
    private ChannelTreeNodeEventListener channelListener;
    private NeEventListenerForMediatorView neListener;

    public TreeTableMediatorsDocument(final CommonServices commonServices, final RepositoryManager repositoryManager,
            final ListenersRegistrationManager changeListener) {
        super(commonServices, repositoryManager, changeListener);
    }

    @Override protected final void addChangeListeners(@Nonnull final ModelUpdater modelUpdater) {
        mediatorListener = new MediatorTreeNodeEventListener(modelUpdater, getCommonServices(), getRepositoryManager(),
                new MediatorGraphicalRepresentationBuilder(getCommonServices().getIconManager()));

        channelListener = new ChannelTreeNodeEventListener(modelUpdater, getCommonServices(), getRepositoryManager(),
                new ChannelGraphicalRepresentationBuilder(getCommonServices().getIconManager()));

        neListener = new NeEventListenerForMediatorView(modelUpdater, getCommonServices(), getRepositoryManager(),
                new NeGraphicalRepresentationBuilder(getCommonServices().getIconManager()));

        getChangeListenersManager().addNeListener(neListener);
        getChangeListenersManager().addChannelListener(channelListener);
        getChangeListenersManager().addMediatorListener(mediatorListener);
    }

    @Override protected final void removeChangeListeners() {
        getChangeListenersManager().removeMediatorListener(mediatorListener);
        getChangeListenersManager().removeChannelListener(channelListener);
        getChangeListenersManager().removeNeListener(neListener);
    }
}