package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;

import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_ADDRESS;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_CONNECT_VIA;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_INFO;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_LOCATION;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NETWORK_NAME;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_ROOT;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_STANDBY_STATE;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_STATE;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_TYPE;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_USER_TEXT;

public class TableColumnsBuilder implements org.apache.commons.lang3.builder.Builder<ImmutableList<TableColumn>> {

    protected static final int DEFAULT_INFO_WIDTH = 150;

    @Override
    public ImmutableList<TableColumn> build() {
        final Builder<TableColumn> builder = ImmutableList.builder();

        builder.add(new TableColumn(ColumnId.TREE_MODEL, COLUMN_ROOT).width(DEFAULT_INFO_WIDTH).removable(false));
        builder.add(new TableColumn(ColumnId.STATE, COLUMN_STATE));
        builder.add(new TableColumn(ColumnId.NETWORK_NAME, COLUMN_NETWORK_NAME));
        builder.add(new TableColumn(ColumnId.TYPE, COLUMN_TYPE));
        builder.add(new TableColumn(ColumnId.INFO, COLUMN_INFO).width(DEFAULT_INFO_WIDTH));
        builder.add(new TableColumn(ColumnId.ADDRESS, COLUMN_ADDRESS));
        builder.add(new TableColumn(ColumnId.CONNECT_VIA, COLUMN_CONNECT_VIA));
        builder.add(new TableColumn(ColumnId.STANDBY_STATE, COLUMN_STANDBY_STATE));
        builder.add(new TableColumn(ColumnId.USER_TEXT, COLUMN_USER_TEXT).visible(false));
        builder.add(new TableColumn(ColumnId.LOCATION, COLUMN_LOCATION));

        return builder.build();
    }
}
