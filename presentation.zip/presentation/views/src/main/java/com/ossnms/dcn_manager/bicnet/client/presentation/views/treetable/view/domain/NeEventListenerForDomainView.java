package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.domain;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.NeTreeNodeEventListenerTemplate;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindAllNeNodes;

public class NeEventListenerForDomainView extends NeTreeNodeEventListenerTemplate {

    public NeEventListenerForDomainView(ModelUpdater modelUpdater, CommonServices commonServices,
            RepositoryManager repositoryManager, NeGraphicalRepresentationBuilder graphicalRepresentation) {
        super(modelUpdater, commonServices, repositoryManager, graphicalRepresentation);
    }

    @Override protected void remove(@Nonnull FullNeData fullNeData) {
        tryFindAllNeNodes(getModelUpdater().getNodeRoot(), fullNeData.getNe().getId())
                .forEach(nodeNe -> removeNe(fullNeData, nodeNe));
    }

    @Override protected void add(@Nonnull FullNeData fullNeData) {
        // Not supported for Domain View
    }

    @Override protected void update(@Nonnull FullNeData fullNeData) {
        tryFindAllNeNodes(getModelUpdater().getNodeRoot(), fullNeData.getNe().getId())
                .forEach(nodeNe -> updateNe(fullNeData, nodeNe));
    }

    /**
     * Used in Cut and Paste to know if the NE parent changed
     *
     * @param nodeNe  ne node
     * @param element updated ine element
     * @return old parent node if it was changed
     */
    @Override protected Optional<Node> getParentIfChanged(final Node nodeNe, final INE element) {
        // Not supported for Domain View
        return Optional.empty();
    }

    /**
     * Used in Cut and Paste when parent of NE changed to apply the change
     *  @param nodeNe ne node
     * @param parent updated ine element
     */
    @Override protected void applyParentMutation(final Node oldParent, final Node nodeNe, final FullNeData parent) {
        // Not supported for Domain View
    }
}
