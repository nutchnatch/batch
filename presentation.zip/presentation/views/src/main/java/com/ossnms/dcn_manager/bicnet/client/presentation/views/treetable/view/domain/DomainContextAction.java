package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.domain;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.model.common.GatewayRole;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.ContextAction;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionDiscoveryPermitted;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionSortByConnectivity;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.components.JfxCheckBoxMenuItem;
import com.ossnms.tools.jfx.components.JfxMenu;
import org.apache.commons.lang3.tuple.ImmutablePair;

import javax.annotation.Nonnull;
import javax.swing.JMenuItem;
import java.util.ArrayList;
import java.util.Collection;
import java.util.stream.Collectors;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Nodes.isSingleSelection;

public class DomainContextAction implements ContextAction {
    private final CommonServices commonServices;
    private final RepositoryManager repositoryManager;

    public DomainContextAction(CommonServices commonServices, RepositoryManager repositoryManager) {
        this.commonServices = commonServices;
        this.repositoryManager = repositoryManager;
    }

    @Override public Collection<JMenuItem> createAction(@Nonnull final Collection<Node> selectedNodes,
            @Nonnull final TreeTableViewModel model) throws RepositoryException {

        final Collection<JMenuItem> menuItems = new ArrayList<>();

        if (isSingleSelection(selectedNodes)) {
            selectedNodes.stream().filter(NodeDomain.class::isInstance).map(NodeDomain.class::cast).findFirst()
                    .ifPresent(nodeDomain -> {
                        try {
                            addSortByConnectivityMenu(nodeDomain, menuItems, model);
                            addDiscoveryPermittedMenu(nodeDomain, menuItems);
                        } catch (RepositoryException e) {
                            Throwables.propagate(e);
                        }
                    });
        }

        return menuItems;
    }

    @Override public void addActions(Collection<JfxAction> actions) {
    }

    private void addDiscoveryPermittedMenu(final NodeDomain nodeDomain, final Collection<JMenuItem> menuItems)
            throws RepositoryException {
        repositoryManager.getDomainRepository().get(nodeDomain.getId()).ifPresent(domain -> {
            JfxCheckBoxMenuItem menuItem = new JfxCheckBoxMenuItem(
                    new ActionDiscoveryPermitted(domain, commonServices));
            menuItem.setSelected(domain.getDiscoveryPermited());
            menuItems.add(menuItem);
        });
    }

    private void addSortByConnectivityMenu(final NodeDomain nodeDomain, final Collection<JMenuItem> menuItems, TreeTableViewModel model)
            throws RepositoryException {
        final JfxMenu menuSortByConnectivity = new JfxMenu(TreeTableLabels.SORT_BY_CONNECTIVITY.guiName());

        Collection<FullNeData> neList = repositoryManager.getNeRepository()
                .get(nodeDomain.getAllChildren().stream()
                        .filter(node -> node.getValue().isVisible())
                        .map(Node::getId)
                        .collect(Collectors.toList()));

        neList.stream()
                .map(FullNeData::getNe)
                .filter(ne -> ! GatewayRole.NONE.equals(ne.getGatewayRole()))
                .map(ne -> {
                    final ActionSortByConnectivity actionSortByConnectivity = new ActionSortByConnectivity(nodeDomain,
                            ImmutablePair.of(ne.getId(), new JfxText(ne.getIdName())), model);

                    final JfxCheckBoxMenuItem selectGneMenuItem = new JfxCheckBoxMenuItem(actionSortByConnectivity);
                    nodeDomain.getSelectedGneId().ifPresent(gneId -> selectGneMenuItem.setSelected(gneId == ne.getId()));

                    return selectGneMenuItem;
                }).forEach(menuSortByConnectivity::add);

        menuItems.add(menuSortByConnectivity);
    }
}
