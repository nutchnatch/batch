package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common;

public interface TransferAcceptor<D, T> {

    /**
     * Validates if can accept transfer to destination  
     */
    boolean canAccept(D transfer, T destination);


    /**
     * @return true if acceptor is suitable to this type of transfer and destination
     */
    default boolean matches(D transfer, T destination) {
        return true;
    }

    /**
     * Performs transfer to destination
     * @return true it transfer was successful
     */
    boolean perform(D transfer, T destination);

    static <D, T> TransferAcceptor<D, T> empty() {
        return new TransferAcceptor<D, T>() {
            @Override public boolean canAccept(D transfer, T destination) {
                return false;
            }

            @Override public boolean perform(D dragged, T destination) {
                return false;
            }
        };
    }

}


