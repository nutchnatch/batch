package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.container;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.NeTreeNodeEventListenerTemplate;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindAllNeNodes;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindAllSystemContainerNodes;
import static java.util.stream.Collectors.toList;

public class NeEventListenerForContainerView extends NeTreeNodeEventListenerTemplate {

    public NeEventListenerForContainerView(ModelUpdater modelUpdater, CommonServices commonServices,
            RepositoryManager repositoryManager, NeGraphicalRepresentationBuilder graphicalRepresentation) {
        super(modelUpdater, commonServices, repositoryManager, graphicalRepresentation);
    }

    @Override protected void remove(@Nonnull FullNeData fullNeData) {
        tryFindAllNeNodes(getModelUpdater().getNodeRoot(), fullNeData.getNe().getId())
                .forEach(nodeNe -> removeNe(fullNeData, nodeNe));
    }

    @Override protected void add(@Nonnull FullNeData fullNeData) {
        tryFindAllSystemContainerNodes(getModelUpdater().getNodeRoot(), fullNeData.getNe().getAssociatedSystemContainerId())
                .forEach(container -> addNe(fullNeData, container));
    }

    @Override protected void update(@Nonnull FullNeData fullNeData) {
        Collection<NodeNe> neNodes = tryFindAllNeNodes(getModelUpdater().getNodeRoot(), fullNeData.getNe().getId());

        if (isSystemChanged(fullNeData, neNodes)) {
            // there can be many nodes for the same System
            // moving multiple NEs from/to many System nodes has bigger complexity than just re-add NE to tree 
            remove(fullNeData);
            add(fullNeData);
        } else {
            neNodes.forEach(nodeNe -> updateNe(fullNeData, nodeNe));
        }
    }

    private boolean isSystemChanged(@Nonnull FullNeData fullNeData, Collection<NodeNe> neNodes) {
        int newSystemId = fullNeData.getNe().getAssociatedSystemContainerId();
        List<Node> systemNodes = neNodes.stream().map(neNode -> (Node) neNode.getParent())
                .filter(NodeSystemContainer.class::isInstance).collect(toList());
        
        
        boolean systemIdUpdated = systemNodes.stream().anyMatch(nodeSystem -> nodeSystem.getId() != newSystemId);
        
        boolean systemIdAdded = systemNodes.isEmpty() && newSystemId != 0;
        
        return systemIdUpdated || systemIdAdded;
    }

    @Override protected Optional<Node> getParentIfChanged(final Node nodeNe, final INE element) {
        return Optional.empty();
    }

    @Override protected void applyParentMutation(final Node oldParent, final Node nodeNe, final FullNeData parent) {
    }
}
