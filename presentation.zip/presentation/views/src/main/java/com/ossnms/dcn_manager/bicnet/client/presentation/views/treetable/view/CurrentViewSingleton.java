package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.listtable.DcnListTable;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.DcnTreeTable;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableView;

/**
 * Store the current/last opened TreeTable View.
 */
public final class CurrentViewSingleton {
    private static final CurrentViewSingleton CURRENT_VIEW_SINGLETON = new CurrentViewSingleton();

    private TreeTableViewTypes treeTableViewTypes = TreeTableViewTypes.MEDIATOR;
    private final Object mutex = new Object();
    private DcnTreeTable treeTable;
    private DcnListTable listTable;
    private TreeTableView treeTableView;

    private CurrentViewSingleton() {
    }

    public static CurrentViewSingleton getInstance() {
        return CURRENT_VIEW_SINGLETON;
    }

    public void changeCurrentView(TreeTableViewTypes treeTableViewTypes) {
        synchronized (mutex) {
            this.treeTableViewTypes = treeTableViewTypes;
        }
    }

    public TreeTableViewTypes getCurrentView() {
        synchronized (mutex) {
            return treeTableViewTypes;
        }
    }

    public boolean isOnContainerView() {
        synchronized (mutex) {
            return treeTableViewTypes == TreeTableViewTypes.CONTAINER;
        }
    }
    
    public void setTreeTable(DcnTreeTable treeTable){
        this.treeTable = treeTable;
    }
    
    public DcnListTable getListTable(){
        return listTable;
    }
    
    public void setListTable(DcnListTable listTable){
        this.listTable = listTable;
    }
    
    public DcnTreeTable getTreeTable(){
        return treeTable;
    }
    
    public void setTreeTableView(TreeTableView treeTableView){
        this.treeTableView = treeTableView;
    }
    
    public TreeTableView getTreeTableView(){
        return treeTableView;
    }
}
