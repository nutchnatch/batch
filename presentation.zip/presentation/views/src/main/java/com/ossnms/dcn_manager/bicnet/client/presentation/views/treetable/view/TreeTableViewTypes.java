package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view;

import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
    
public enum TreeTableViewTypes {
    MEDIATOR(TreeTableLabels.MEDIATOR_VIEW_TITLE.toString()),
    CONTAINER(TreeTableLabels.CONTAINER_VIEW_TITLE.toString()),
    DOMAIN(TreeTableLabels.DOMAIN_VIEW_TITLE.toString());
    
    private final String description;
    
    TreeTableViewTypes(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }            
}
