package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.mediatorview;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobMoveNEs;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common.AbstractAcceptor;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.api.ObjectUtils.anyMatch;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isInactive;
import static com.ossnms.dcn_manager.bicnet.client.api.state.RequiredStateVerification.isDisable;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.MOVE_NE_SAN;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

public class NeToChannels extends AbstractAcceptor<INEId> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeToChannels.class);

    public NeToChannels(RepositoryManager repositoryManager, CommonServices commonServices) {
        super(repositoryManager, commonServices);
    }
    
    @Override public boolean canAccept(Collection<INEId> nes, @Nonnull final IManagedObject destination) {
        return isAChannel(destination)
                && areDeactivated(nes)
                && hasPermission(nes)
                && channelCanAcceptNes((IEM) destination, nes);
    }

    @Override public boolean perform(Collection<INEId> nes, IManagedObject destination) {
        IEMId channelId = (IEM) destination;
        queueJob(new JobMoveNEs(getPluginHelper().getSessionContext(), getFacade(), nes, channelId));
        return true;
    }

    private boolean isAChannel(@Nonnull IManagedObject destination) {
        return anyMatch(destination, IEM.class);
    }

    private boolean hasPermission(Collection<INEId> nes) {
        return checkPermission(MOVE_NE_SAN, nes);
    }

    private boolean channelCanAcceptNes(IEM channel, Collection<INEId> nes) {
        return supportedNeTypes(channel).containsAll(neTypes(nes));
    }

    private Collection<String> neTypes(Collection<INEId> nes) {
        return fetchNes(nes).stream()
                .map(ne -> ne.getNe().getNeProxyType())
                .collect(toList());
    }

    private Collection<FullNeData> fetchNes(Collection<INEId> nes) {
        Collection<Integer> neIds = nes.stream().map(INEId::getId).collect(toList());
        try {
            return getRepositoryManager().getNeRepository().get(neIds);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to access repository", e);
            return emptyList();
        }
    }

    private Collection<String> supportedNeTypes(IEMId channelId) {
        try {
            Optional<String> channelType = getRepositoryManager().getChannelRepository().get(channelId.getId())
                    .map(channel -> channel.getChannel().getEmType());
            return getRepositoryManager().getNeRepository().getRegisteredTypes(getPluginHelper().getSessionContext(), channelType);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to access repository", e);
            return emptyList();
        }
    }

    private boolean areDeactivated(Collection<INEId> nes) {
        return fetchNes(nes).stream()
                .allMatch(ne -> isDisable(ne.getNe()) && isInactive(ne.getInfo().getGuiActiveActualActivationState()));
    }
}
