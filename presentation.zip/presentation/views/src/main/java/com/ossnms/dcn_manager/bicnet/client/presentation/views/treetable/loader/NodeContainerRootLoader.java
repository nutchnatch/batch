package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeContainerMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeNeMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeSystemContainerMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.ContainerGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.SystemContainerGraphicalRepresentationBuilder;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static com.ossnms.dcn_manager.bicnet.client.api.Containers.ROOT_CONTAINER_ID;
import static java.util.stream.Collectors.toList;
import static javax.swing.SwingUtilities.invokeLater;

public class NodeContainerRootLoader extends NodeLoader {

    private final NodeContainerMutationApplier containerMutationApplier;
    private final SystemUnderContainerLoader systemLoader;
    private final NeUnderContainerLoader neLoader;

    public NodeContainerRootLoader(final RepositoryManager repositoryManager, final CommonServices commonServices,
                                   final Node parent) {
        super(repositoryManager, commonServices, parent);

        containerMutationApplier = new NodeContainerMutationApplier(repositoryManager, commonServices,
                new ContainerGraphicalRepresentationBuilder(getCommonServices().getIconManager())
        );

        systemLoader = new SystemUnderContainerLoader(repositoryManager, commonServices);

        neLoader = new NeUnderContainerLoader(repositoryManager, commonServices);
    }

    @Override public Node load() throws RepositoryException {

        final Collection<IGenericContainer> containers = getRepositoryManager().getContainerRepository()
                .queries()
                .findByParentId(ROOT_CONTAINER_ID)
                .stream().filter(c -> c.getId() != ROOT_CONTAINER_ID)
                .collect(Collectors.toSet());

        invokeLater(() -> {
            try {
                for (final IGenericContainer container : containers) {
                    final NodeContainer nodeContainer = new NodeContainer(container.getId(), getRootNode());

                    containerMutationApplier.applyMutation(container, nodeContainer);

                    containerMutationApplier.loadChildrenNodes(nodeContainer);

                    getRootNode().addChild(nodeContainer);
                }
                systemLoader.loadChildrenSystems(getRootNode());
                neLoader.loadChildrenNes(getRootNode());
            } catch (RepositoryException e) {
                Throwables.propagate(e);
            }
        });

        return getRootNode();
    }

    public static class SystemUnderContainerLoader {
        private final RepositoryManager repositoryManager;
        private final NodeSystemContainerMutationApplier systemContainerMutationApplier;

        public SystemUnderContainerLoader(RepositoryManager repositoryManager, final CommonServices commonServices) {
            systemContainerMutationApplier = new NodeSystemContainerMutationApplier(repositoryManager, commonServices,
                    new SystemContainerGraphicalRepresentationBuilder(commonServices.getIconManager()));
            this.repositoryManager = repositoryManager;
        }

        public void loadChildrenSystems(Node parentContainer) throws RepositoryException {
            List<Integer> systemIds = repositoryManager.getSystemContainerAssignmentRepository().queries()
                    .findByContainerId(parentContainer.getId()).stream()
                    .map(ISystemGenericContainerAssignmentId::getSystemContainerId)
                    .collect(toList());

            for (ISystemContainer system : repositoryManager.getSystemContainerRepository().get(systemIds)) {
                NodeSystemContainer nodeSystemContainer = new NodeSystemContainer(system.getId(), parentContainer);
                systemContainerMutationApplier.applyMutation(system, nodeSystemContainer);
                systemContainerMutationApplier.loadChildrenNodes(nodeSystemContainer);
                parentContainer.addChild(nodeSystemContainer);
            }
        }
    }

    public static class NeUnderContainerLoader {
        private final RepositoryManager repositoryManager;
        private final NodeNeMutationApplier neMutationApplier;

        public NeUnderContainerLoader(RepositoryManager repositoryManager, final CommonServices commonServices) {
            neMutationApplier = new NodeNeMutationApplier(repositoryManager, commonServices,
                    new NeGraphicalRepresentationBuilder(commonServices.getIconManager()));
            this.repositoryManager = repositoryManager;
        }

        public void loadChildrenNes(Node parentContainer) throws RepositoryException {
            List<Integer> neIds = repositoryManager.getNEContainerAssignmentRepository().queries()
                    .findByContainerId(parentContainer.getId()).stream()
                    .map(INeGenericContainerAssignmentId::getNetworkElementId)
                    .collect(toList());

            repositoryManager.getNeRepository().get(neIds).forEach(ne -> {
                NodeNe nodeNe = new NodeNe(ne.getNe().getId(), parentContainer);
                neMutationApplier.applyMutation(ne, nodeNe);
                parentContainer.addChild(nodeNe);
            });
        }
    }
}