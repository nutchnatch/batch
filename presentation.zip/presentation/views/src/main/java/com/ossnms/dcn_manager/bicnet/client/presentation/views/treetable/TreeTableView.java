package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.ossnms.bicnet.resources.ResourcesIconFactory.ICON_TOOL_TREE_VIEW_16;
import static com.ossnms.tools.jfx.components.EToolBarButtonStyle.SMALL;
import static java.util.Arrays.asList;
import static java.util.Arrays.stream;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Stream.concat;
import static java.util.stream.Stream.of;
import static javax.swing.SwingUtilities.invokeLater;

import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.stream.Stream;

import javax.annotation.Nonnull;
import javax.swing.ActionMap;
import javax.swing.Icon;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.coriant.widgets.togglebuttontree.ToggleButtonTree;
import com.coriant.widgets.treetable.TreeTable;
import com.google.common.base.Joiner;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPrintData;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandManager;
import com.ossnms.bicnet.framework.client.helpers.feedback.FrameworkActivityIndicator;
import com.ossnms.bicnet.framework.client.jfx.FrameworkDialogApp;
import com.ossnms.bicnet.framework.client.jfx.FrameworkPrintData;
import com.ossnms.bicnet.framework.client.persistence.FrameworkPersistentView;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.api.action.Action;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.ContextAction;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.delegate.ActionDeleteDelegate;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.delegate.ActionDuplicateDelegate;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionFindNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionOpenTable;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionTreeTableMenuDelete;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionTreeTableMenuDuplicate;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionTreeTableMenuNew;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionTreeTableMenuProperties;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.NewElementDialogHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listtable.DcnListTableCommand;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableModelUpdater.BufferedUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainerRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediatorRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.builder.TransferHandlers;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.CurrentViewSingleton;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.TreeTableCommand;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.TreeTableViewTypes;
import com.ossnms.dcn_manager.bicnet.client.service.help.DefaultHelpIds;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.JfxActionPerformed;
import com.ossnms.tools.jfx.JfxOptionsData;
import com.ossnms.tools.jfx.JfxProperties;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxDropDownToolBarButton;
import com.ossnms.tools.jfx.components.JfxPersistentProperties;
import com.ossnms.tools.jfx.components.JfxPopupMenu;
import com.ossnms.tools.jfx.components.JfxRadioButtonMenuItem;
import com.ossnms.tools.jfx.components.JfxTreeProperties;
import com.ossnms.tools.jfx.print.JfxPrintData;
import com.ossnms.tools.jfx.table.JfxTableProperties;

/**
 * Abstraction for the DCN Views.
 */
public abstract class TreeTableView extends FrameworkPersistentView implements ListSelectionListener, ToolbarActionButtonsListener {
    private static final long serialVersionUID = 9206573062621912213L;
    private static final Logger LOGGER = LoggerFactory.getLogger(TreeTableView.class);
    private static final String ID = TreeTableView.class.getName();
    
    private static final boolean RESIZABLE = true;
    private static final KeyStroke KEY_DELETE = KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0);
    private static final KeyStroke KEY_ENTER = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);

    protected static final String DEFAULT_NODE_ROOT_NAME = TreeTableLabels.DEFAULT_NODE_ROOT_NAME.toString();
    public static final String DCN_TABLE_PROPERTY_ID = "DCNTable";
    public static final String DCN_TREE_PROPERTY_ID = "DCNTree";

    private TreeOptionsData treeOptionsData;
    private final FrameworkActivityIndicator activityIndicator;
    private final DcnTreeTable dcnTreeTable;
    private final ContextAction contextAction;

    /* Toolbar */
    private JfxAction actionAdd;
    private JfxAction actionDuplicate;
    private JfxAction actionDelete;
    private JfxAction actionProperties;
    private final JfxAction actionFindNe;
    private final JfxAction openTable;
    private JfxRadioButtonMenuItem menuMediator;
    private JfxRadioButtonMenuItem menuDomain;
    private JfxRadioButtonMenuItem menuContainer;
    private JfxDropDownToolBarButton menuSelectView;

    protected TreeTableView(@Nonnull final String title, @Nonnull final TreeTableDocument document,
                            @Nonnull final TreeTableViewModel model, @Nonnull final NodeHandler nodeHandler, 
                            @Nonnull final ContextAction contextAction, TransferHandlers transferHandlers) {
        super(ID, title, document, RESIZABLE, DefaultHelpIds.DCN_MANAGEMENT_MAIN_VIEW.getValue());
        
        checkNotNull(title);
        checkNotNull(document);
        checkNotNull(model);

        model.addToolbarActionButtonsListener(this);

        final NewElementDialogHandler actionsHandler = new NewElementDialogHandler(this, document.getRepositoryManager(),
                document.getCommonServices());

        dcnTreeTable = new DcnTreeTable(model, nodeHandler, actionsHandler, contextAction, document.getRepositoryManager(),
                document.getCommonServices(), transferHandlers);
        dcnTreeTable.getSelectionModel().addListSelectionListener(this);
        dcnTreeTable.getColumnModel().getColumn(ColumnId.TREE_MODEL.position())
                .setPreferredWidth(model.getPreferredColumnWidth(ColumnId.TREE_MODEL.position()));
        dcnTreeTable.getColumnModel().getColumn(ColumnId.INFO.position())
                .setPreferredWidth(model.getPreferredColumnWidth(ColumnId.INFO.position()));

        actionFindNe = new ActionFindNe(this, dcnTreeTable, document.getCommonServices(), document.getRepositoryManager());
        CurrentViewSingleton.getInstance().setTreeTable(dcnTreeTable);
        CurrentViewSingleton.getInstance().setTreeTableView(this);
        openTable = new ActionOpenTable(dcnTreeTable, new DcnListTableCommand(document.getRepositoryManager(), document.getCommonServices(), document.getChangeListenersManager()), nodeHandler, document.getCommonServices());
        this.contextAction = contextAction;

        activityIndicator = buildActivityIndicator();

        createMainMenuActions();
        updateToolbarActions();

        initButtons();
        initGuiNames();
    }

    protected abstract void addExtraPropertiesToSave(Properties properties);

    private FrameworkActivityIndicator buildActivityIndicator() {
        final JPanel mainComponentPanel = new JPanel();
        mainComponentPanel.setLayout(new BorderLayout(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD,
                JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS));
        mainComponentPanel.add(new JScrollPane(dcnTreeTable), BorderLayout.CENTER);

        final FrameworkActivityIndicator indicator = new FrameworkActivityIndicator(mainComponentPanel);
        indicator.setActivityIndicatorVisible(true);

        return indicator;
    }

    /**
     * Updates the TreeTable Model through the Root tree node.
     *
     * @see com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader.job.FetchTreeNodes
     */
    @Override
    public final void updateData(final Object key) {
        if (!SwingUtilities.isEventDispatchThread()) {
            throw new UnsupportedOperationException("Should be called in the EDT");
        }

        dcnTreeTable.setToggleSelectedNodes(getActivatedNodes((Node) getTreeTableModel().getRoot()), true, true, true);

        getFrameworkDocument().addChangeListeners(new BufferedUpdater(new TreeTableModelUpdater(getTreeTableModel(), getTreeTable())));

        activityIndicator.setActivityIndicatorVisible(false);
    }

    @Override
    public JComponent getMainComponent() {
        return activityIndicator;
    }

    @Override
    public TreeTableDocument getFrameworkDocument() {
        return (TreeTableDocument) super.getFrameworkDocument();
    }

    @Override
    protected boolean supportsPersistance() {
        return true;
    }

    @Override
    protected void loadFilter(JfxOptionsData aProfile) {
        
    }

    @Override
    protected void saveFilter(JfxOptionsData aProfile) {
        
    }
    
    @Override
    protected void loadSettings(final JfxOptionsData data) {
        if (data instanceof TreeOptionsData) {
            try {
                final ISecureClientSession propHolder = getSecureClientSession();

                if (propHolder != null && dcnTreeTable != null) {
                    final TreeOptionsData optionsData = (TreeOptionsData) data;
                    final JfxProperties props = optionsData.getLdapProperties();

                    final JfxTableProperties tablePropHolder = new JfxTableProperties(getID(), 1);
                    tablePropHolder.loadProperties(props, DCN_TABLE_PROPERTY_ID );
                    dcnTreeTable.setPersistentProperties(tablePropHolder);

                    final JfxTreeProperties treePropHolder = new JfxTreeProperties(getID(), 2);
                    treePropHolder.loadProperties(props, DCN_TREE_PROPERTY_ID );
                    setTreeProperties(dcnTreeTable, treePropHolder);
                }
            } catch (BiCNetPluginException ex) {
                LOGGER.error("Tried to get NE Object Man Client window, table and tree settings", ex);
            }
        }
    }

    @Override
    protected void saveSettings(final JfxOptionsData data) {
        if (data instanceof TreeOptionsData) {

            try {
                final ISecureClientSession clientSession = getSecureClientSession();

                if (null != clientSession) {
                    Properties currentProperties = Optional.ofNullable(clientSession.getUserProfile(getFrameworkDocument().getCommonServices()
                            .getDcnPluginHelper().getPluginId())).orElse(new Properties());

                    final TreeOptionsData optionsData = (TreeOptionsData) data;
                    final JfxPersistentProperties tablePropHolder = dcnTreeTable.getPersistentProperties(getID(), 1);
                    final JfxTreeProperties treePropHolder = new JfxTreeProperties(getID(), 2);
                    final JfxProperties newTableProperties = new JfxProperties();

                    tablePropHolder.saveProperties(newTableProperties, DCN_TABLE_PROPERTY_ID);
                    optionsData.setTableProperties(newTableProperties);

                    final ToggleButtonTree<Node> tree = dcnTreeTable.getTree();
                    if (tree != null) {
                        treePropHolder.loadPropsFrom(tree);
                    }
                    treePropHolder.saveProperties(newTableProperties, DCN_TREE_PROPERTY_ID);

                    currentProperties.putAll(newTableProperties);
                    addExtraPropertiesToSave(currentProperties);

                    clientSession.setUserProfile(getFrameworkDocument().getCommonServices()
                            .getDcnPluginHelper().getPluginId(), currentProperties);
                }
            } catch (final BiCNetPluginException e) {
                LOGGER.error("Error getting SecureClientSession : ", e);
            }
        }
    }

    @Override
    public void addClientLogEntry(final String message, final Exception exception) {
        getFrameworkDocument().getCommonServices().getLoggerManager()
                .error(message + ": " + exception.getMessage(), getTitle());
    }

    @Override
    protected List<?> getButtonActions() {
        return asList(
                actionAdd,
                actionDuplicate,
                actionDelete,
                new JSeparator(),
                actionProperties,
                menuSelectView,
                actionFindNe,
                openTable);
    }

    @Override
    public void valueChanged(final ListSelectionEvent e) {
        updateToolbarActions();
    }

    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_WINDOW_DCN_MANAGEMENT_16;
    }

    @Override
    public int getHelpID() {
        return DefaultHelpIds.DCN_MANAGEMENT_MAIN_VIEW.getValue();
    }

    @Override
    public boolean isPrintable() {
        return true;
    }

    @Override
    public BiCNetPluginPrintData getPrintData() {
        final JfxPrintData printData = new JfxPrintData(false);
        printData.setWindowName(Joiner.on(" - ").join(
                TreeTableLabels.MENU_SHORT_DESCRIPTION.toString(),
                CurrentViewSingleton.getInstance().getCurrentView().getDescription()));
        printData.addListItem(dcnTreeTable);
        return new FrameworkPrintData(printData);
    }

    @Override
    public final JfxOptionsData getOptionsData() {
        if ( null == treeOptionsData) {
            treeOptionsData = new TreeOptionsData();
        }
        return treeOptionsData;
    }

    @Override
    public void eventOpened() {
        super.eventOpened();
        setHelperDialog();
    }

    @Override
    public void eventClosing() {
        getFrameworkDocument().removeChangeListeners();
        CurrentViewSingleton.getInstance().setTreeTableView(null);
        super.eventClosing();
    }

    @Override
    protected IPluginSecurityProvider getSecurityProvider() throws BiCNetPluginException {
        return getFrameworkDocument().getCommonServices().getDcnPluginHelper().getSecurityProvider();
    }

    @Override
    protected ISecureClientSession getSecureClientSession() throws BiCNetPluginException {
        return getFrameworkDocument().getCommonServices().getDcnPluginHelper().getClientSession().orElse(null);
    }

    private void createMainMenuActions() {
        actionAdd = new ActionTreeTableMenuNew(dcnTreeTable, getFrameworkDocument().getCommonServices(),
                dcnTreeTable.getDialogHandler());

        actionDuplicate = new ActionTreeTableMenuDuplicate(dcnTreeTable, new ActionDuplicateDelegate(
                getFrameworkDocument().getRepositoryManager(), getFrameworkDocument().getCommonServices()));

        actionDelete = new ActionTreeTableMenuDelete(dcnTreeTable, new ActionDeleteDelegate(
                getFrameworkDocument().getRepositoryManager(), getFrameworkDocument().getCommonServices()));
        setAccel(dcnTreeTable, "delete", KEY_DELETE, (Action) actionDelete);

        actionProperties = new ActionTreeTableMenuProperties(dcnTreeTable, dcnTreeTable.getNodeHandler(),
                getFrameworkDocument().getCommonServices(), getFrameworkDocument().getRepositoryManager());

        dcnTreeTable.setDoubleClickAction(actionProperties);
        setAccel(dcnTreeTable, "enter", KEY_ENTER, (Action) actionProperties);
    }

    private void setHelperDialog() {
        dcnTreeTable.setDialogApp(new FrameworkDialogApp(getFrame()));
    }

    /**
     * Initializes toolbar button actions
     */
    private void initButtons() {
        menuMediator = newMenuItem(TreeTableLabels.MEDIATOR_VIEW, this::openMediatorView);
        menuDomain = newMenuItem(TreeTableLabels.DOMAIN_VIEW, this::openDomainView);
        menuContainer = newMenuItem(TreeTableLabels.CONTAINER_VIEW, this::openContainerView);
        menuSelectView = newMenu(TreeTableLabels.SELECT_VIEW, menuMediator, menuDomain, menuContainer);
    }

    private void initGuiNames() {
        setName("DcnManagement");
        dcnTreeTable.setName("DcnManagement");
        actionAdd.setComponentName("Add");
        actionDuplicate.setComponentName("Duplicate");
        actionDelete.setComponentName("Delete");
        actionProperties.setComponentName("Properties");
        actionFindNe.setComponentName("FindNe");
        openTable.setComponentName("OpenDcnTable");
        menuSelectView.setName("SelectView");
        menuMediator.setName("MediatorView");
        menuDomain.setName("DomainView");
        menuContainer.setName("ContainerView");
    }

    /**
     * Get list of active nodes
     *
     * @param node node to start the search
     * @return list with activated nodes to select checkboxes
     */
    private List<Node> getActivatedNodes(final Node node) {
        return allUnder(node)
                .filter(child -> child.getValue().isToogleButtonChecked())
                .collect(toList());
    }

    private Stream<Node> allUnder(Node node) {
        return concat(of(node), node.getAllChildren().stream().flatMap(this::allUnder));
    }

    protected JfxRadioButtonMenuItem getMenuMediator() {
        return menuMediator;
    }

    protected JfxRadioButtonMenuItem getMenuDomain() {
        return menuDomain;
    }

    protected JfxRadioButtonMenuItem getMenuContainer() {
        return menuContainer;
    }

    protected ContextAction getContextMenuActions() {
        return contextAction;
    }

    @Override
    public final void updateToolbarActions() {
        actionAdd.updateAction();
        actionDuplicate.updateAction();
        actionDelete.updateAction();
        actionProperties.updateAction();
        actionFindNe.updateAction();
        openTable.updateAction();
    }

    public boolean inMediatorView() {
        return getTreeTableModel().getRoot() instanceof NodeMediatorRoot;
    }

    private boolean inDomainView() {
        return getTreeTableModel().getRoot() instanceof NodeDomainRoot;
    }

    public boolean inContainerView() {
        return getTreeTableModel().getRoot() instanceof NodeContainerRoot;
    }

    public TreeTableViewModel getTreeTableModel() {
        return (TreeTableViewModel) dcnTreeTable.getTreeModel();
    }

    public DcnTreeTable getTreeTable() {
        return dcnTreeTable;
    }

    public JfxAction getActionDuplicate() {
        return actionDuplicate;
    }

    public JfxAction getActionDelete() {
        return actionDelete;
    }

    public JfxAction getActionProperties() {
        return actionProperties;
    }

    public JfxAction getActionFindNe() { return actionFindNe; }

    public JfxAction getActionOpenTable(){ return openTable; }

    public JfxButton getMenuSelectView() {
        return menuSelectView;
    }

    private JfxDropDownToolBarButton newMenu(TreeTableLabels label, JMenuItem... items) {
        final JfxPopupMenu popupMenu = new JfxPopupMenu();
        stream(items).forEach(popupMenu::add);
        return new JfxDropDownToolBarButton(label.guiName(), ICON_TOOL_TREE_VIEW_16, SMALL, popupMenu, true);
    }

    private JfxRadioButtonMenuItem newMenuItem(TreeTableLabels label, JfxActionPerformed whenPerformed) {
        return new JfxRadioButtonMenuItem(new JfxAction(label.guiName(), label.guiName(), "93365D0E110e2F81", whenPerformed, null, null));
    }

    public void openMediatorView(final JfxAction action) {
        CurrentViewSingleton.getInstance().changeCurrentView(TreeTableViewTypes.MEDIATOR);
        selectedView(menuMediator, inMediatorView());
    }

    public void openDomainView(final JfxAction action) {
        CurrentViewSingleton.getInstance().changeCurrentView(TreeTableViewTypes.DOMAIN);
        selectedView(menuDomain, inDomainView());
    }

    public void openContainerView(final JfxAction action) {
        CurrentViewSingleton.getInstance().changeCurrentView(TreeTableViewTypes.CONTAINER);
        selectedView(menuContainer, inContainerView());
    }

    private void selectedView(JfxRadioButtonMenuItem menuItem, boolean isCurrentView) {
        menuItem.setSelected(true);
        if (!isCurrentView) {
            getFrame().closeFrame();
            FrameworkCommandManager.getCommandMgr().executeCmd(TreeTableCommand.COMMAND_ID);
        }
    }

    private void setAccel(final JComponent comp, final String strInternalID, final KeyStroke keyAccel, final Action action) {
        if (keyAccel != null) {
            setAccelForComponent(comp, strInternalID, keyAccel, action);
        }
    }

    private static void setAccelForComponent(final JComponent comp, final String strInternalID, final KeyStroke keyAccel, final Action action) {
        if (comp != null) {
            final InputMap inpMap = comp.getInputMap(TreeTableView.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
            final ActionMap actMap = comp.getActionMap();
            if (inpMap != null && actMap != null) {
                inpMap.put(keyAccel, strInternalID);
                actMap.put(strInternalID, action);
            }
        }
    }

    public boolean checkPermission(SecureAction secureAction) {
        return dcnTreeTable.getSecureValidator().checkPermission(secureAction);
    }

    private void setTreeProperties(TreeTable<?> treeTable, final JfxTreeProperties treeProps) {
        invokeLater(() -> {
            try {
                ofNullable(treeTable)
                        .map(TreeTable::getTree)
                        .ifPresent(treeProps::delayedPutPropsIn);
                repaint();
            } catch (final RuntimeException ex) {
                LOGGER.error("Failed to set tree properties into {}", treeTable, ex);
            }
        });
    }

    public JfxAction getActionFind(){
        return actionFindNe;
    }
}
