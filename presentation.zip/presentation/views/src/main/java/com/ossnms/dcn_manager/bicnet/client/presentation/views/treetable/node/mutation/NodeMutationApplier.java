package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeValue;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;

import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;

import static com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager.addOverlay;

public abstract class NodeMutationApplier<ELEMENT, NODE extends Node> {

    private final RepositoryManager repositoryManager;
    private final CommonServices commonServices;
    private final GraphicalRepresentationBuilder<ELEMENT> graphicalRepresentation;

    NodeMutationApplier(RepositoryManager repositoryManager, CommonServices commonServices,
                        GraphicalRepresentationBuilder<ELEMENT> graphicalRepresentation) {
        this.repositoryManager = repositoryManager;
        this.commonServices = commonServices;
        this.graphicalRepresentation = graphicalRepresentation;
    }

    public abstract NodeMutationApplier<ELEMENT, NODE> loadChildrenNodes(NODE node) throws RepositoryException;

    public abstract NodeMutationApplier<ELEMENT, NODE> applyMutation(ELEMENT element, NODE node);

    public abstract boolean structureChanged(ELEMENT element, NODE node);

    public boolean visibilityChanged(ELEMENT element, NODE node) {
        return false;
    }

    public NodeMutationApplier<ELEMENT, NODE> applyParentUpdate(ELEMENT element, NODE node) {
        return this;
    }

    final void applyGraphicalRepresentationMutation(ELEMENT element, NODE node) {
        node.getValue().setGraphicalRepresentation(graphicalRepresentation.build(element));
    }

    <MO extends IManagedObjectId> void checkRequiredActivationPermission(MO manageObject, NODE node,
                                                                         SecureAction secureAction) {
        NodeValue value = node.getValue();
        value.setToogleButtonEnable(value.isToogleButtonEnable() && checkPermission(secureAction, manageObject));
    }

    boolean checkPermission(SecureAction secureAction, IManagedObjectId manageObject) {
        return commonServices.getSecureActionValidation().checkPermission(secureAction, manageObject);
    }

    protected RepositoryManager getRepositoryManager() {
        return repositoryManager;
    }

    protected CommonServices getCommonServices() {
        return commonServices;
    }

    Optional<Node> updateParentOf(Node node, Function<Node, Node> updateFunction) {
        return node.getParentNode().map(updateFunction);
    }

    /**
     * Updates overlay icon of Node
     * @param warningCondition if true then overlay is added, otherwise removed
     */
    <N extends Node> N updateWarningIcon(N node, Predicate<N> warningCondition) {
        IconManager iconManager = graphicalRepresentation.getIconManager();
        boolean hasWarning = warningCondition.test(node);
        node.getValue().updateOverlay(addOverlay(iconManager.getWarningOverlay(hasWarning)));
        return node;
    }
}
