package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.domain;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.transform.NodesTransformer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeHandler;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

import javax.annotation.Nonnull;

public class TreeTableDomainsNodeHandler implements NodeHandler {

    private final TreeTableDomainsDocument document;

    public TreeTableDomainsNodeHandler(@Nonnull final TreeTableDomainsDocument document) {
        this.document = document;
    }

    @Override
    public Iterable<IManagedObject> transformOnlyFirstMatchNodeType(Iterable<Node> nodes) throws RepositoryException {
        return NodesTransformer.from(nodes)
                .stopWhenFirstTransformationHasValues()
                .transform(document.getRepositoryManager().getDomainRepository(), NodeDomain.class)
                .transform(document.getRepositoryManager().getNeRepository()).iterable();
    }

    @Override
    public Iterable<IManagedObject> transformAllKnownNodeTypes(Iterable<Node> nodes) throws RepositoryException {
        return NodesTransformer.from(nodes)
                .transform(document.getRepositoryManager().getDomainRepository(), NodeDomain.class)
                .transform(document.getRepositoryManager().getNeRepository()).iterable();
    }
}
