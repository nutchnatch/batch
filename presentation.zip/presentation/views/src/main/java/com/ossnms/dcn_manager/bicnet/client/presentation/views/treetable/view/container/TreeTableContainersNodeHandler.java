package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.container;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainerRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.transform.NodesTransformer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeHandler;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;

import javax.annotation.Nonnull;

class TreeTableContainersNodeHandler implements NodeHandler {

    private final RepositoryManager repositoryManager;

    TreeTableContainersNodeHandler(@Nonnull final RepositoryManager repositoryManager) {
        this.repositoryManager = repositoryManager;
    }

    @Override
    public Iterable<IManagedObject> transformOnlyFirstMatchNodeType(Iterable<Node> nodes) throws RepositoryException {
        return configuration(NodesTransformer.from(nodes).stopWhenFirstTransformationHasValues()).iterable();
    }

    @Override
    public Iterable<IManagedObject> transformAllKnownNodeTypes(Iterable<Node> nodes) throws RepositoryException {
        return configuration(NodesTransformer.from(nodes)).iterable();
    }

    private NodesTransformer configuration(NodesTransformer nodesTransformer) throws RepositoryException {
        return nodesTransformer
                .transform(repositoryManager.getContainerRepository(), NodeContainerRoot.class)
                .transform(repositoryManager.getContainerRepository(), NodeContainer.class)
                .transform(repositoryManager.getSystemContainerRepository(), NodeSystemContainer.class)
                .transform(repositoryManager.getNeRepository());
    }
}
