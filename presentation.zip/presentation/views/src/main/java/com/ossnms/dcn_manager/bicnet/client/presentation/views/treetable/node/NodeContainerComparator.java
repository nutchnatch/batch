package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import javax.annotation.Nonnull;
import java.io.Serializable;
import java.util.Comparator;
import java.util.List;

import static com.google.common.base.Strings.nullToEmpty;
import static com.google.common.collect.ImmutableList.of;

/**
 * Used to order by Node name prioritized by Node type.
 */
class NodeContainerComparator implements Comparator<Node>, Serializable{

    private static final long serialVersionUID = 5649298109709345620L;

    @Override public int compare(@Nonnull final Node node1, @Nonnull final Node node2) {
        
        return byTypeOrder(of(NodeContainer.class, NodeSystemContainer.class, NodeNe.class))
                .thenComparing(byName())
                .compare(node1, node2);
    }

    /**
     * Comparator of nodes by predefined order of types
     */
    private Comparator<Node> byTypeOrder(List<Class<? extends Node>> typesOrder) {
        return Comparator.comparing(node -> typesOrder.indexOf(node.getClass()));
    }

    /**
     * Case insensitive comparator of nodes by name
     */
    private Comparator<Node> byName() {
        return Comparator.comparing(node -> nullToEmpty(node.getValue().getName()), 
                String.CASE_INSENSITIVE_ORDER);
    }
}
