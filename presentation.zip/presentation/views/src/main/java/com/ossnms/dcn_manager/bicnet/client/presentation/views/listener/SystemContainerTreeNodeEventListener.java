package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeSystemContainerMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.Utilities.toStream;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindAllSystemContainerNodes;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindContainerNode;
import static java.util.function.Function.identity;

public class SystemContainerTreeNodeEventListener extends TreeNodeEventListener<ISystemContainer, NodeSystemContainer> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SystemContainerTreeNodeEventListener.class);

    public SystemContainerTreeNodeEventListener(@Nonnull final ModelUpdater modelUpdater,
                                                final CommonServices commonServices, final RepositoryManager repositoryManager,
                                                final GraphicalRepresentationBuilder<ISystemContainer> graphicalRepresentation) {
        super(modelUpdater, commonServices, repositoryManager,
                new NodeSystemContainerMutationApplier(repositoryManager, commonServices, graphicalRepresentation));
    }

    @Override protected void remove(@Nonnull final ISystemContainer container) {
        tryFindAllSystemContainerNodes(getModelUpdater().getNodeRoot(), container.getId()).stream()
                .forEach(nodeSystemContainer -> {
                    getModelUpdater().removeNode(nodeSystemContainer);
                    nodeSystemContainer.getParentNode().ifPresent(parent -> parent.removeChild(nodeSystemContainer));
                    LOGGER.debug("System Container({}) removed.", container.getIdName());
                });
    }

    @Override protected void add(@Nonnull final ISystemContainer system) {
        try {
            getRepositoryManager().getSystemContainerAssignmentRepository().queries()
                    .findBySystemContainerId(system.getId()).stream()
                    .map(ISystemGenericContainerAssignmentId::getGenericContainerId)
                    .flatMap(this::findContainer)
                    .forEach(nodeContainer -> add(system, nodeContainer));
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch system container associations", e);
        }
    }

    private void add(@Nonnull ISystemContainer system, @Nonnull Node parentContainer) {
        final NodeSystemContainer nodeSystem = new NodeSystemContainer(system.getId(), parentContainer);
        getMutationApplier().applyMutation(system, nodeSystem);

        if (parentContainer.addChild(nodeSystem)) {
            getModelUpdater().insertNode(nodeSystem);
            LOGGER.debug("System Container({}) added.", system.getIdName());
        }
    }

    private Stream<Node> findContainer(int containerId) {
        return getModelUpdater().getNodeRoot().getId() == containerId
                ? Stream.of(getModelUpdater().getNodeRoot())
                : toStream(tryFindContainerNode(getModelUpdater().getNodeRoot(), containerId).map(identity()));
    }

    @Override protected void update(@Nonnull final ISystemContainer container) {
        tryFindAllSystemContainerNodes(getModelUpdater().getNodeRoot(), container.getId()).stream()
                .forEach(nodeSystemContainer -> {
                    if (getMutationApplier().structureChanged(container, nodeSystemContainer)) {
                        getMutationApplier().applyMutation(container, nodeSystemContainer);
                        getModelUpdater().applyStructureChanged(nodeSystemContainer);
                    } else {
                        getMutationApplier().applyMutation(container, nodeSystemContainer);
                        getModelUpdater().updateNode(nodeSystemContainer);
                    }

                    LOGGER.debug("System Container({}) updated. {}", container.getIdName(), container);
                });
    }
}
