package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.mediator;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.transform.NodesTransformer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeHandler;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

import javax.annotation.Nonnull;

import static com.google.common.base.Preconditions.checkNotNull;

public class TreeTableMediatorsNodeHandler implements NodeHandler {

    private final TreeTableMediatorsDocument document;

    public TreeTableMediatorsNodeHandler(@Nonnull final TreeTableMediatorsDocument document) {
        this.document = document;
    }

    @Override
    public Iterable<IManagedObject> transformOnlyFirstMatchNodeType(@Nonnull final Iterable<Node> nodes) throws RepositoryException {
        checkNotNull(nodes);
        
        return NodesTransformer.from(nodes)
                .stopWhenFirstTransformationHasValues()
                .transformMediator(document.getRepositoryManager().getMediatorRepository())
                .transformChannel(document.getRepositoryManager().getChannelRepository())
                .transform(document.getRepositoryManager().getNeRepository()).iterable();
    }

    @Override
    public Iterable<IManagedObject> transformAllKnownNodeTypes(@Nonnull final Iterable<Node> nodes) throws RepositoryException {
        checkNotNull(nodes);
        
        return NodesTransformer.from(nodes)
                .transformMediator(document.getRepositoryManager().getMediatorRepository())
                .transformChannel(document.getRepositoryManager().getChannelRepository())
                .transform(document.getRepositoryManager().getNeRepository()).iterable();
    }
}
