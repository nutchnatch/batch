package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.CacheInMemoryRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Function;

public class UpdateParentListener<CHILD, PARENT> implements EventChangeListener<CHILD> {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateParentListener.class);
    private final CacheInMemoryRepository<Integer, PARENT> parentRepo;
    private final EventChangeListener<PARENT> parentListener;
    private final Function<CHILD, Integer> toParentId;

    UpdateParentListener(EventChangeListener<PARENT> parentListener, CacheInMemoryRepository<Integer, PARENT> parentRepo,
                         Function<CHILD, Integer> toParentId) {
        this.parentRepo = parentRepo;
        this.parentListener = parentListener;
        this.toParentId = toParentId;
    }

    private void updateParent(CHILD child) {
        try {
            Integer parentId = toParentId.apply(child);
            parentRepo.get(parentId)
                    .ifPresent(parentListener::elementUpdated);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to query repository for parent of {}", child, e);
        }
    }

    @Override public void elementRemoved(CHILD element) {
        updateParent(element);
    }

    @Override public void elementAdded(CHILD element) {
        updateParent(element);
    }

    @Override public void elementUpdated(CHILD element) {
        updateParent(element);
    }

    @Override public void removeAll() {
        //ignore
    }

    public static UpdateParentListener<FullChannelData, FullMediatorData> forChannel(
            EventChangeListener<FullMediatorData> listener, RepositoryManager repositoryManager) {
        return new UpdateParentListener<>(listener, repositoryManager.getMediatorRepository(),
                channel -> channel.getChannel().getAssociatedMediatorId());
    }

    public static UpdateParentListener<FullNeData, FullChannelData> forNe(
            EventChangeListener<FullChannelData> listener, RepositoryManager repositoryManager) {
        return new UpdateParentListener<>(listener, repositoryManager.getChannelRepository(),
                ne -> ne.getNe().getAssociatedEmId());
    }
}
