package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable;

import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;

import javax.annotation.Nonnull;

/**
 * Provides the Data Manager for the Views.
 */
public abstract class TreeTableDocument extends FrameworkDocument {
    
    private final CommonServices commonServices;
    private final RepositoryManager repositoryManager;
    private final ListenersRegistrationManager changeListenersManager;

    public TreeTableDocument(final CommonServices commonServices, final RepositoryManager repositoryManager,
                             final ListenersRegistrationManager changeListenersManager) {
        super(commonServices.getFrameworkPluginHelper());
        this.commonServices = commonServices;
        this.repositoryManager = repositoryManager;
        this.changeListenersManager = changeListenersManager;
    }

    /**
     * Register the change listeners for the TreeTable Nodes.
     */
    protected abstract void addChangeListeners(final ModelUpdater modelUpdater);

    /**
     * Unregister the change listeners for the TreeTable Nodes.
     */
    protected abstract void removeChangeListeners();
    
    /** {@inheritDoc} */
    @Override
    public final void setResult(@Nonnull final IFrameworkJob job, final Object result) {
        updateData(result);
    }
    
    /**
     * Method not supported.
     * 
     * throws UnsupportedOperationException
     */
    @Override
    public Object getObject(final Object key) {
        throw new UnsupportedOperationException();
    }

    /**
     * @return The Client common services
     */
    public CommonServices getCommonServices() {
        return commonServices;
    }
     
    /**
     * @return The RepositoryManager
     */
    public RepositoryManager getRepositoryManager(){
        return repositoryManager;
    }

    /**
     * @return The change listener manager for tree table Nodes.
     */
    public ListenersRegistrationManager getChangeListenersManager() {
        return changeListenersManager;
    }
}
