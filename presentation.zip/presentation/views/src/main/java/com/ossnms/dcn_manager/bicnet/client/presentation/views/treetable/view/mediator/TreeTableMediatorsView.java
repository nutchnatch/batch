package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.mediator;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionTreeTableMenuNew;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableView;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediatorRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.builder.TransferHandlersBuilder;
import com.ossnms.tools.jfx.JfxAction;

import javax.swing.event.ListSelectionListener;
import java.util.Properties;

import static java.util.Arrays.asList;

public class TreeTableMediatorsView extends TreeTableView implements ListSelectionListener {
    private static final long serialVersionUID = -7912027547889578817L;
    private static final String ID = TreeTableMediatorsView.class.getName();
    
    public TreeTableMediatorsView(String title, TreeTableMediatorsDocument document) {
        super(title, document, new TreeTableViewModel(new NodeMediatorRoot(DEFAULT_NODE_ROOT_NAME)),
                new TreeTableMediatorsNodeHandler(document), new MediatorContextAction(), 
                TransferHandlersBuilder.mediatorView(document.getRepositoryManager(), document.getCommonServices()));

        initMediatorButtons();
        initMediatorGuiNames();
        
        initControls();
    }

    @Override
    protected String getProfileId() {
     // This method return this specific class name to store view collapse/expand tree status
        return ID;
    }
    
    /**
     * Initializes toolbar button actions
     */
    private void initMediatorButtons() {
        getMenuMediator().setSelected(true);

        addContainerActionsToContextMenu();
    }
    
    /**
     * This method sets the GUI Component Labels.
     */
    private void initMediatorGuiNames() {
        getTreeTable().setName("MediatorView");
    }

    private void addContainerActionsToContextMenu(){
        final JfxAction actionAddMediator =  new ActionTreeTableMenuNew(
                getTreeTable(), getFrameworkDocument().getCommonServices(), 
                getTreeTable().getDialogHandler());

        (getContextMenuActions()).addActions(asList(actionAddMediator));
    }

    @Override protected void addExtraPropertiesToSave(Properties properties){}
}