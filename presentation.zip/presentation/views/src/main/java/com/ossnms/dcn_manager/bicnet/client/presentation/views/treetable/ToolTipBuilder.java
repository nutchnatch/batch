package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ToolTipType;

import javax.annotation.Nonnull;
import javax.swing.tree.TreePath;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.Optional;

/**
 * Builds a ToolTip for #DcnTreeTable nodes.
 */
public class ToolTipBuilder {
    
    /**
     * Builds a ToolTip for tree nodes.
     * 
     * @see ToolTipType
     * 
     * @param event The MouseEvent identifies if the mouse cursor is over a check-box or the a node representation.
     * @return The message for node check-box or the node.
     */
    public Optional<String> build(@Nonnull final MouseEvent event) {
        if (event.getSource() instanceof DcnTreeTable) {
            
            final DcnTreeTable treeTable = (DcnTreeTable) event.getSource();            
            final Point point = event.getPoint();
            final int row = treeTable.rowAtPoint(point);
            final int column = treeTable.columnAtPoint(point);
            
            final Object cell = treeTable.getValueAt(row, column);
            
            if (cell instanceof Node) {
                final Node node = (Node) cell;
                final Optional<TreePath> treePath = Optional.ofNullable(treeTable.getTree().getPathForLocation(event.getX(), event.getY()));
                      
                if (treePath.isPresent() && treeTable.getTree().getHandler().isClickInToggleButton(event, treePath.get())) {
                    return Optional.of(node.getToolTip(ToolTipType.CHECKBOX));
                } else {
                    return Optional.of(node.getToolTip(ToolTipType.NODE));
                }
            }
        }
        
        return Optional.empty();
    }
}
