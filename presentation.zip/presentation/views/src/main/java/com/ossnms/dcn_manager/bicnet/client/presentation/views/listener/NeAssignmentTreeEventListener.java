package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NoOpsMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeNeMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.function.BiConsumer;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindContainerNode;
import static java.util.Optional.of;
import static java.util.function.Function.identity;

public class NeAssignmentTreeEventListener extends TreeNodeEventListener<INeGenericContainerAssignment, Node> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeAssignmentTreeEventListener.class);
    private final NodeNeMutationApplier neMutationApplier;

    public NeAssignmentTreeEventListener(ModelUpdater modelUpdater, CommonServices commonServices, RepositoryManager repositoryManager) {
        super(modelUpdater, commonServices, repositoryManager, new NoOpsMutationApplier<>(repositoryManager, commonServices));
        neMutationApplier = new NodeNeMutationApplier(
                repositoryManager, commonServices, new NeGraphicalRepresentationBuilder(commonServices.getIconManager()));
    }

    @Override protected void remove(@Nonnull INeGenericContainerAssignment assignment) {
        forNodesIn(assignment, (nodeContainer, nodeNe) -> {
            getModelUpdater().removeNode(nodeNe);
            nodeContainer.removeChild(nodeNe);
        });
    }

    @Override protected void add(@Nonnull INeGenericContainerAssignment assignment) {
        forContainerAndNeIn(assignment, (nodeContainer, ne) -> {
            NodeNe nodeNe = new NodeNe(ne.getInfo().getNeId(), nodeContainer);
            nodeNe.getValue().setName(ne.getIdName());

            if (nodeContainer.addChild(nodeNe)) {
                neMutationApplier.applyMutation(ne, nodeNe);
                getModelUpdater().insertNode(nodeNe);
                getModelUpdater().updateRequiredActivationState(nodeNe, nodeNe.getValue().isToogleButtonChecked());
            }
        });
    }

    @Override protected void update(@Nonnull INeGenericContainerAssignment assignment) {
        //no changes in tree
    }

    private void forContainerAndNeIn(INeGenericContainerAssignment assignment, BiConsumer<Node, FullNeData> consumer) {
        try {
            int neId = assignment.getNetworkElementId();
            int containerId = assignment.getGenericContainerId();
            getRepositoryManager().getNeRepository().get(neId).ifPresent(ne ->
                    findContainer(containerId).ifPresent(nodeContainer ->
                            consumer.accept(nodeContainer, ne)));
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch ne", e);
        }

    }

    private Optional<Node> findContainer(int containerId) {
        return getModelUpdater().getNodeRoot().getId() == containerId 
                ? of(getModelUpdater().getNodeRoot()) 
                : tryFindContainerNode(getModelUpdater().getNodeRoot(), containerId).map(identity());
    }

    private void forNodesIn(INeGenericContainerAssignment assignment, BiConsumer<Node, NodeNe> consumer) {
        int containerId = assignment.getGenericContainerId();
        int neId = assignment.getNetworkElementId();
        findContainer(containerId).ifPresent(nodeContainer ->
                nodeContainer.findChild(neId, NodeNe.class).ifPresent(nodeNe ->
                        consumer.accept(nodeContainer, nodeNe)));
    }

}
