package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainComparator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeDomainMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.SortByConnectivityUserPreferences;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.DomainGraphicalRepresentationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Optional;
import java.util.Properties;

import static javax.swing.SwingUtilities.invokeLater;

public class NodeDomainRootLoader extends NodeLoader {
    private static final Logger LOGGER = LoggerFactory.getLogger(NodeDomainRootLoader.class);

    private final NodeDomainMutationApplier mutationApplier;
    private final SortByConnectivityUserPreferences sortByConnectivityUserPreferences;

    public NodeDomainRootLoader(RepositoryManager repositoryManager, CommonServices commonServices,
            NodeRoot rootNode) {
        super(repositoryManager, commonServices, rootNode);

        mutationApplier = new NodeDomainMutationApplier(repositoryManager, commonServices,
                new DomainGraphicalRepresentationBuilder(getCommonServices().getIconManager()));

        sortByConnectivityUserPreferences = new SortByConnectivityUserPreferences(getCommonServices());
    }

    /**
     * @return The Root Node
     * @throws RepositoryException
     */
    @Override
    public Node load() throws RepositoryException {
        LOGGER.debug("NodeDomainRootLoader :: Get All Domains...");
        final Collection<IAS> elements = getRepositoryManager().getDomainRepository().getAll();
        final Optional<Properties> userPreferences = sortByConnectivityUserPreferences.loadUserPreferences();

        invokeLater(() -> {
            LOGGER.debug("NodeDomainRootLoader :: Loading Network Domains View Nodes...");
            try {
                for (final IAS domain : elements) {
                    final NodeDomain nodeDomain = new NodeDomain(domain.getId(), getRootNode(), new NodeDomainComparator(getRepositoryManager()));

                    mutationApplier.applyMutation(domain, nodeDomain);
                    userPreferences.ifPresent( properties ->
                            sortByConnectivityUserPreferences.loadSortByConnectivityPreferences(properties,nodeDomain));
                    mutationApplier.loadChildrenNodes(nodeDomain);

                    getRootNode().addChild(nodeDomain);
                }
            } catch (RepositoryException e) {
                Throwables.propagate(e);
            }
        });

        return getRootNode();
    }
}
