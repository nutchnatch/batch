package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;

public interface ModelUpdater {

    Node getNodeRoot();
    
    void insertNode(Node node);

    void updateNode(Node node);

    void removeNode(Node node);
    
    void updateRequiredActivationState(Node node, boolean selected);

    void applyStructureChanged(Node node);
}
