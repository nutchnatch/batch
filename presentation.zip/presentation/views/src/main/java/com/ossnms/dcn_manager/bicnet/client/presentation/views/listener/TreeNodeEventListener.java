package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;

import javax.annotation.Nonnull;

import static javax.swing.SwingUtilities.invokeLater;

/**
 * Abstraction to guarantee the execution on EDT.
 */
abstract class TreeNodeEventListener<ELEMENT, NODE extends Node> implements EventChangeListener<ELEMENT> {
    private final ModelUpdater modelUpdater;
    private final CommonServices commonServices;
    private final RepositoryManager repositoryManager;
    private final NodeMutationApplier<ELEMENT, NODE> mutationApplier;

    TreeNodeEventListener(final ModelUpdater modelUpdater, final CommonServices commonServices,
                          final RepositoryManager repositoryManager, NodeMutationApplier<ELEMENT, NODE> mutationApplier) {
        this.modelUpdater = modelUpdater;
        this.commonServices = commonServices;
        this.repositoryManager = repositoryManager;
        this.mutationApplier = mutationApplier;
    }

    protected abstract void remove(@Nonnull final ELEMENT element);

    protected abstract void add(@Nonnull final ELEMENT element);

    protected abstract void update(@Nonnull final ELEMENT element);

    /**
     * Invoked when element was removed.
     *
     * @param element Removed element.
     */
    @Override public final void elementRemoved(ELEMENT element) {
        invokeLater(() -> remove(element));
    }

    /**
     * Invoked when a new element was received.
     *
     * @param element Added element.
     */
    @Override public final void elementAdded(ELEMENT element) {
        invokeLater(() -> add(element));
    }

    /**
     * Invoked when a element was updated.
     *
     * @param element Updated element.
     */
    @Override public final void elementUpdated(ELEMENT element) {
        invokeLater(() -> update(element));
    }

    /**
     * Invoked when all element was removed.
     */
    @Override public final void removeAll() { // N.A.
    }

    public ModelUpdater getModelUpdater() {
        return modelUpdater;
    }

    public CommonServices getCommonServices() {
        return commonServices;
    }

    public RepositoryManager getRepositoryManager() {
        return repositoryManager;
    }

    NodeMutationApplier<ELEMENT, NODE> getMutationApplier() {
        return mutationApplier;
    }

    protected void moveNode(Node oldParent, Node node, Node newParent) {
        modelUpdater.removeNode(node);
        oldParent.removeChild(node);
        newParent.addChild(node);
        modelUpdater.insertNode(node);
    }
}
