package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables.TransferTransformer;

import java.awt.datatransfer.Transferable;
import java.util.Collection;
import java.util.function.BiPredicate;

public class TransferableAcceptor<T extends IManagedObjectId> implements TransferAcceptor<Transferable, IManagedObject> {
    private final TransferAcceptor<Collection<T>, IManagedObject> acceptor;
    private final TransferTransformer<T> transformer;

    public TransferableAcceptor(TransferTransformer<T> transformer, TransferAcceptor<Collection<T>, IManagedObject> acceptor) {
        this.acceptor = acceptor;
        this.transformer = transformer;
    }

    @Override public boolean perform(Transferable transferable, IManagedObject destination) {
        return transformed(acceptor::perform, transferable, destination);
    }

    @Override public boolean canAccept(Transferable transferable, IManagedObject destination) {
        return transformed(acceptor::canAccept, transferable, destination);
    }

    
    @Override public boolean matches(Transferable transferable, IManagedObject destination) {
        return transformed(acceptor::matches, transferable, destination);
    }

    private boolean transformed(BiPredicate<Collection<T>, IManagedObject> predicate, Transferable transferable, IManagedObject destination) {
        Collection<T> dragged = transformer.extract(transferable);
        return !dragged.isEmpty() && predicate.test(dragged, destination);
    }
}
