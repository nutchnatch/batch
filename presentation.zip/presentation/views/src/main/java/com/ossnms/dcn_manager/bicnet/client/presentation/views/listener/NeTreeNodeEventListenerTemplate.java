package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeNeMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

public abstract class NeTreeNodeEventListenerTemplate extends TreeNodeEventListener<FullNeData, NodeNe> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeTreeNodeEventListenerTemplate.class);

    public NeTreeNodeEventListenerTemplate(final ModelUpdater modelUpdater, final CommonServices commonServices,
            final RepositoryManager repositoryManager, final NeGraphicalRepresentationBuilder graphicalRepresentation) {
        super(modelUpdater, commonServices, repositoryManager,
                new NodeNeMutationApplier(repositoryManager, commonServices, graphicalRepresentation));
    }

    /**
     * Used in Cut and Paste to know if the NE parent changed.
     *
     * @param nodeNe  ne node
     * @param element updated ine element
     * @return old parent node if it was changed
     */
    protected abstract Optional<Node> getParentIfChanged(final Node nodeNe, final INE element);

    /**
     * Used in Cut and Paste when parent of NE changed to apply the change.
     *  @param nodeNe ne node
     * @param parent updated ine element
     */
    protected abstract void applyParentMutation(final Node oldParent, final Node nodeNe, final FullNeData parent);

    protected void removeNe(@Nonnull final FullNeData fullNeData, @Nonnull final NodeNe nodeNe) {
        final Node nodeParent = (Node) nodeNe.getParent();
        getModelUpdater().removeNode(nodeNe);
        nodeParent.removeChild(nodeNe);
        getMutationApplier().applyParentUpdate(fullNeData, nodeNe);
        LOGGER.debug("Ne({}) removed. {}", nodeNe);
    }

    protected void addNe(@Nonnull final FullNeData fullNeData, @Nonnull final Node nodeParent) {
        final NodeNe nodeNe = new NodeNe(fullNeData.getNe().getId(), nodeParent);
        getMutationApplier().applyMutation(fullNeData, nodeNe);

        if (nodeParent.addChild(nodeNe)) {
            getMutationApplier().applyParentUpdate(fullNeData, nodeNe);
            getModelUpdater().insertNode(nodeNe);
            getModelUpdater().updateRequiredActivationState(nodeNe, nodeNe.getValue().isToogleButtonChecked());
            LOGGER.debug("Ne({}) Added.", fullNeData.getNe().getIdName());
        }
    }

    protected void updateNe(@Nonnull final FullNeData fullNeData, @Nonnull final NodeNe nodeNe) {
        if (getMutationApplier().visibilityChanged(fullNeData, nodeNe)) {
            getModelUpdater().removeNode(nodeNe);
            getMutationApplier().applyMutation(fullNeData, nodeNe);
            nodeNe.getParentNode().ifPresent(parent -> parent.updateVisibility(nodeNe));
            getMutationApplier().applyParentUpdate(fullNeData, nodeNe);
            getModelUpdater().insertNode(nodeNe);
        } else if (getMutationApplier().structureChanged(fullNeData, nodeNe)) {
            getMutationApplier().applyMutation(fullNeData, nodeNe);
            getModelUpdater().applyStructureChanged(nodeNe);
        } else {
            getMutationApplier().applyMutation(fullNeData, nodeNe);

            Optional<Node> parentChanged = getParentIfChanged(nodeNe, fullNeData.getNe());
            parentChanged.ifPresent(oldParent -> applyParentMutation(oldParent, nodeNe, fullNeData));
            getMutationApplier().applyParentUpdate(fullNeData, nodeNe);
            getModelUpdater().updateNode(nodeNe);
        }

        getModelUpdater().updateRequiredActivationState(nodeNe, nodeNe.getValue().isToogleButtonChecked());

        LOGGER.debug("Ne({}) updated. {}", fullNeData.getNe().getIdName(), fullNeData);
    }
}
