package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.containerview;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobAssociateSystemsWithContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common.AbstractAcceptor;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.bicnet.client.api.ObjectUtils.anyMatch;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.MOVE_SYSTEM_SAN;
import static java.util.Arrays.asList;

public class SystemAcceptor extends AbstractAcceptor<ISystemContainerId> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SystemAcceptor.class);

    public SystemAcceptor(RepositoryManager repositoryManager, CommonServices commonServices) {
        super(repositoryManager, commonServices);
    }

    @Override public boolean canAccept(Collection<ISystemContainerId> transfer, IManagedObject destination) {
        return anyMatch(destination, IGenericContainer.class)
                && hasPermission()
                && withoutInvisibleNes(transfer);
    }

    @Override public boolean perform(Collection<ISystemContainerId> transfer, IManagedObject destination) {
        IGenericContainerId containerId = (IGenericContainer) destination;
        queueJob(new JobAssociateSystemsWithContainer(getPluginHelper().getSessionContext(), getFacade(),
                transfer, containerId, asList(containerId)));
        return true;
    }

    private boolean hasPermission() {
        return checkPermission(MOVE_SYSTEM_SAN);
    }

    /**
     * Operator should not be able to drop System with invisible NEs 
     */
    private boolean withoutInvisibleNes(Collection<ISystemContainerId> systems) {
        return systems.stream().flatMap(this::nesUnderSystem).noneMatch(this::isInvisible);
    }

    private Stream<INEId> nesUnderSystem(ISystemContainerId systemContainerId) {
        try {
            return getRepositoryManager().getNeRepository().queries()
                    .findBySystemContainerId(systemContainerId.getId()).stream()
                    .map(FullNeData::getNe);
        } catch (RepositoryException e) {
            LOGGER.error("Failure with NE Repository", e);
            return Stream.empty();
        }
    }

    private boolean isInvisible(INEId ne) {
        return !checkVisibility(ne);
    }
}
