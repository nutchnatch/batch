package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.Map;
import java.util.function.Supplier;

import static java.util.Collections.emptyMap;
import static java.util.Optional.ofNullable;
import static org.apache.commons.lang3.ArrayUtils.addAll;
import static org.apache.commons.lang3.ArrayUtils.isEmpty;

public class Transfers implements Transferable {

    public static final Transferable NO_TRANSFER = new Transfers(emptyMap());

    private final Map<DataFlavor, Supplier<Object>> transfers;

    Transfers(Map<DataFlavor, Supplier<Object>> transfers) {
        this.transfers = transfers;
    }

    @Override public DataFlavor[] getTransferDataFlavors() {
        return transfers.keySet().toArray(new DataFlavor[0]);
    }

    @Override public boolean isDataFlavorSupported(DataFlavor flavor) {
        return transfers.containsKey(flavor);
    }

    @Override public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
        return ofNullable(transfers.get(flavor))
                .map(Supplier::get)
                .orElseThrow(() -> new UnsupportedFlavorException(flavor));
    }

    /**
     * Joins two Transferable objects into one
     *
     * @return transferable object with joined DataFlavors
     */
    public static Transferable join(Transferable left, Transferable right) {
        if (isEmpty(left.getTransferDataFlavors())) {
            return right;
        }
        if (isEmpty(right.getTransferDataFlavors())) {
            return left;
        }
        return new Transferable() {
            @Override public DataFlavor[] getTransferDataFlavors() {
                return addAll(left.getTransferDataFlavors(), right.getTransferDataFlavors());
            }

            @Override public boolean isDataFlavorSupported(DataFlavor flavor) {
                return left.isDataFlavorSupported(flavor) || right.isDataFlavorSupported(flavor);
            }

            @Override public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
                return left.isDataFlavorSupported(flavor) ? left.getTransferData(flavor) : right.getTransferData(flavor);
            }
        };
    }
}
