package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;

import javax.annotation.Nonnull;
import javax.swing.Icon;

public class NoOpsMutationApplier<ELEMENT, NODE extends Node> extends NodeMutationApplier<ELEMENT, NODE> {

    public NoOpsMutationApplier(RepositoryManager repositoryManager, CommonServices commonServices) {
        super(repositoryManager, commonServices, new NoOpGraphicalRepresentationBuilder<>());
    }

    @Override public NodeMutationApplier<ELEMENT, NODE> loadChildrenNodes(NODE node) throws RepositoryException {
        return this;
    }

    @Override public NodeMutationApplier<ELEMENT, NODE> applyMutation(ELEMENT element, NODE node) {
        return this;
    }

    @Override public boolean structureChanged(ELEMENT element, NODE node) {
        return false;
    }

    private static class NoOpGraphicalRepresentationBuilder<ELEMENT> extends GraphicalRepresentationBuilder<ELEMENT> {

        public NoOpGraphicalRepresentationBuilder() {
            super(null);
        }

        @Override public Icon build(@Nonnull Object o) {
            return null;
        }
    }
}
