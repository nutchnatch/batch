package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import org.apache.commons.lang3.builder.EqualsBuilder;

import javax.annotation.Nonnull;
import java.util.Objects;

public class ColumnValue {
    private final ColumnId columnId;
    private String value;
    
    public ColumnValue(@Nonnull ColumnId columnId) {
        super();
        this.columnId = columnId;
    }

    public ColumnId getColumnId() {
        return columnId;
    }
    
    public ColumnValue value(String value) {
        this.value = value;
        return this;
    }

    public String getValue() {
        return value;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(columnId);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        
        if (obj == this) {
            return true;
        }
        
        if (obj.getClass() != getClass()) {
            return false;
        }
        
        final ColumnValue columnValue = (ColumnValue) obj;
        return new EqualsBuilder().appendSuper(super.equals(obj))
                .append(columnId, columnValue.columnId)
                .isEquals();
    }
}
