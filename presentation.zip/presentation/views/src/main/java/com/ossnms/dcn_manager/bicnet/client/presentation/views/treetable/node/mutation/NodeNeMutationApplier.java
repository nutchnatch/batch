package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.client.api.state.RequiredStateVerification;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.CurrentViewSingleton;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.TreeTableViewTypes;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeRouteInfo;

import javax.annotation.Nonnull;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Strings.nullToEmpty;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isActivating;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isDeactivating;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isInactive;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.SYNC_STATE_FAILED_MSG;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.SYNC_STATE_MSG;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.SYNC_STATE_SYNCHRONIZING_MSG;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_CHANNELS_SAN;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_NES_SAN;
import static org.apache.commons.lang3.StringUtils.EMPTY;

public class NodeNeMutationApplier extends NodeMutationApplier<FullNeData, NodeNe> {
    public NodeNeMutationApplier(RepositoryManager repositoryManager, CommonServices commonServices,
                                 GraphicalRepresentationBuilder<FullNeData> graphicalRepresentation) {
        super(repositoryManager, commonServices, graphicalRepresentation);
    }

    @Override public NodeMutationApplier<FullNeData, NodeNe> applyMutation(@Nonnull final FullNeData fullNeData,
                                                                           @Nonnull final NodeNe node) {
        checkNotNull(fullNeData);
        checkNotNull(node);

        INE ne = fullNeData.getNe();

        node.getValue().setVisible(isVisible(fullNeData));
        node.getValue().setName(ne.getIdName());
        Optional<String> scsSyncStateMessage = getFormattedSyncStateMessage(fullNeData);

        final Optional<GuiActualActivationState> actualActivationState = fullNeData.getInfo()
                .getGuiActiveActualActivationState();
        actualActivationState.ifPresent(activationState -> node.getValue().setActualActivationState(activationState));

        if (isInactive(actualActivationState) || isActivating(actualActivationState)) {
            node.setSynchState(ScsSyncState.OUT_OF_SYNC);
        } else {
            node.setSynchState(fullNeData.getSynchronizationState().getState());
        }

        node.setNeStatusInfo(fullNeData.getNeStatusInfo());
        node.setCommissioningStatus(ne.getCommissioningStatus());
        node.setAdditionalTypeInfo(fullNeData.getInfo().getAdditionalTypeInfo().orElse(""));

        fullNeData.getInfo().getNeRouteInfo().ifPresent(routes -> {
            if (routeChanged(fullNeData, node)) {
                node.getRoutes().clear();
                node.getRoutes().addAll(routes);
            }
        });

        node.getColumns().setValue(ColumnId.ADDRESS, ne.getDisplayAddress())
                .setValue(ColumnId.CONNECT_VIA, ne.getConnectedVia())
                .setValue(ColumnId.STATE, ne.getDisplayState())
                .setValue(ColumnId.NETWORK_NAME, ne.getRealNeName())
                .setValue(ColumnId.TYPE, Optional.ofNullable(ne.getNeSubType()).orElse(ne.getNeProxyType()))

                .setValue(ColumnId.INFO,
                        scsSyncStateMessage.orElse(nullToEmpty(ne.getAdditionalInfo())))
                .setValue(ColumnId.STANDBY_STATE, fullNeData.getInfo().getStandbyDisplayState().orElse(EMPTY))
                .setValue(ColumnId.USER_TEXT, fullNeData.getInfo().getUserText().orElse(EMPTY))
                .setValue(ColumnId.LOCATION, nullToEmpty(ne.getLocation()));

        applyGraphicalRepresentationMutation(fullNeData, node);
        applyToogleButtonChanges(fullNeData, node);

        return this;
    }

    private boolean isVisible(@Nonnull FullNeData fullNeData) {
        return getCommonServices().getSecureActionValidation().checkVisibility(fullNeData.getNe());
    }

    @Override public boolean structureChanged(final FullNeData fullNeData, final NodeNe node) {
        return nameChanged(fullNeData, node) || routeChanged(fullNeData, node);
    }

    @Override public NodeMutationApplier<FullNeData, NodeNe> applyParentUpdate(FullNeData fullNeData, NodeNe node) {
        Node parent = (Node) node.getParent();
        if (parent instanceof NodeChannel) {
            NodeChannel channel = (NodeChannel) parent;
            updateWarningIcon(channel, Node::hasNotActiveChild);
            updateParentOf(channel, mediator -> updateWarningIcon(mediator, Node::hasNotActiveChild));
        } else if (parent instanceof NodeSystemContainer) {
            NodeSystemContainer system = (NodeSystemContainer) parent;
            system.updateStateIcon();
            updateWarningIcon(system, NodeSystemContainer::hasChildrenWithDifferentActivations);
        }

        return this;
    }

    @Override public NodeMutationApplier<FullNeData, NodeNe> loadChildrenNodes(NodeNe node) throws RepositoryException {
        return this;
    }

    private boolean nameChanged(FullNeData fullNeData, NodeNe node) {
        return !Objects.equals(fullNeData.getNe().getIdName(), node.getValue().getName());
    }

    private boolean routeChanged(FullNeData fullNeData, NodeNe node) {
        final boolean onDomainView = CurrentViewSingleton.getInstance().getCurrentView() == TreeTableViewTypes.DOMAIN;
        final Optional<Set<NeRouteInfo>> neRouteInfo = fullNeData.getInfo().getNeRouteInfo();

        return onDomainView &&
                neRouteInfo.isPresent() &&
                (neRouteInfo.get().size() != node.getRoutes().size() || !neRouteInfo.get().containsAll(node.getRoutes()));
    }

    @Override public boolean visibilityChanged(FullNeData fullNeData, NodeNe node) {
        boolean newVisibility = isVisible(fullNeData);
        boolean oldVisibility = node.getValue().isVisible();
        return newVisibility != oldVisibility;
    }

    protected void applyToogleButtonChanges(FullNeData fullNeData, NodeNe node) {
        final Optional<GuiActualActivationState> actualActivationState = fullNeData.getInfo()
                .getGuiActiveActualActivationState();

        boolean isRequiredStateActive = RequiredStateVerification.isEnable(fullNeData.getNe());

        node.getValue().setToogleButtonChecked(isRequiredStateActive);

        actualActivationState.ifPresent(activationState -> node.getValue().setActualActivationState(activationState));

        if (isDeactivating(actualActivationState)) {
            node.getValue().setToogleButtonEnable(false);

        } else {
            node.getValue().setToogleButtonEnable(true);
        }

        checkRequiredActivationPermission(fullNeData.getNe(), node, OP_ACTIVATE_NES_SAN);

        node.tryUpdateNodeParentToggleButton(checkPermission(OP_ACTIVATE_CHANNELS_SAN, fullNeData.getNe().getAssociatedEm()));
    }

    protected Optional<String> getFormattedSyncStateMessage(FullNeData fullNeData) {
        Optional<GuiActualActivationState> actualActivationState = fullNeData.getInfo()
                .getGuiActiveActualActivationState();

        ScsSyncState scsSyncState = fullNeData.getSynchronizationState().getState();
        Optional<String> info = fullNeData.getSynchronizationState().getInfo();

        if (isInactive(actualActivationState) || ScsSyncState.SYNCHRONIZED == scsSyncState) {
            return Optional.empty();
        }

        if (ScsSyncState.SYNCHRONIZING == scsSyncState) {
            return Optional.of(SYNC_STATE_SYNCHRONIZING_MSG.guiName().getFormatedMessage(SYNC_STATE_MSG));
        }

        if (ScsSyncState.OUT_OF_SYNC == scsSyncState && info.isPresent()) {
            return Optional.of(SYNC_STATE_FAILED_MSG.guiName().getFormatedMessage(SYNC_STATE_MSG, info.get()));
        }

        return Optional.empty();
    }
}
