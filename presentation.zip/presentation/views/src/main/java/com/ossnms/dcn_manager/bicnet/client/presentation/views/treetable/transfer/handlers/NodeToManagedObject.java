package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.DcnTreeTable;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.google.common.collect.ImmutableList.copyOf;
import static java.util.Collections.emptyList;

public final class NodeToManagedObject {

    private static final Logger LOGGER = LoggerFactory.getLogger(NodeToManagedObject.class);

    private NodeToManagedObject() {
    }

    public static Collection<IManagedObject> resolveManagedObjects(DcnTreeTable treeTable, Collection<Node> nodes) {
        return copyOf(objects(treeTable, nodes));
    }

    private static Iterable<IManagedObject> objects(DcnTreeTable treeTable, Collection<Node> nodes) {
        try {
            return treeTable.getNodeHandler().transformAllKnownNodeTypes(nodes);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to access repository", e);
            return emptyList();
        }
    }
}
