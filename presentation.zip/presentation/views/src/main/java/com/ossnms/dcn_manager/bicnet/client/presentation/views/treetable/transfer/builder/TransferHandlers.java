package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.builder;

import java.awt.datatransfer.Transferable;
import java.awt.dnd.DropTargetListener;
import java.util.ArrayList;
import java.util.Collection;

import javax.swing.JComponent;
import javax.swing.TransferHandler;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listtable.DcnListTable;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listtable.transfer.handlers.ListTransferHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.DcnTreeTable;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common.TransferAcceptor;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common.TransferableAcceptor;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers.CommonTransferHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers.CutPasteHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers.TreeDropHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers.TreeTransferHandler;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables.TransferTransformer;

public class TransferHandlers {

    private final Collection<TransferTransformer<?>> transformers = new ArrayList<>();
    private final Collection<TransferAcceptor<Transferable, IManagedObject>> acceptors = new ArrayList<>();

    public <T extends IManagedObjectId> TransferHandlers with(TransferTransformer<T> transferable, TransferAcceptor<Collection<T>, IManagedObject> acceptor) {
        transformers.add(transferable);
        acceptors.add(new TransferableAcceptor<>(transferable, acceptor));
        return this;
    }

    public boolean hasDragHandlers() {
        return !acceptors.isEmpty();
    }

    public TransferHandler transferHandler(DcnTreeTable dcnTreeTable) {
        return new TreeTransferHandler(dcnTreeTable, new CommonTransferHandler(transformers, acceptors));
    }

    public TransferHandler transferHandler(DcnListTable dcnListTable) {
        return new ListTransferHandler(dcnListTable, new CommonTransferHandler(transformers, acceptors));
    }

    public DropTargetListener dropTargetListener(DcnTreeTable dcnTreeTable) {
        return new TreeDropHandler(dcnTreeTable, new CommonTransferHandler(transformers, acceptors));
    }
    
    public CutPasteHandler cutPasteHandler(JComponent component) {
        return new CutPasteHandler(component, new CommonTransferHandler(transformers, acceptors));
    }
}
