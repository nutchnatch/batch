package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils;

import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.Properties;
import java.util.stream.Collectors;

import static java.lang.String.valueOf;
import static org.apache.commons.lang3.StringUtils.join;
import static org.apache.commons.lang3.StringUtils.startsWith;
import static org.apache.commons.lang3.math.NumberUtils.toInt;

/**
 * Stores and load the Sort by Connectivity User preferences.
 */
public class SortByConnectivityUserPreferences {

    /* Sort by Connectivity Identifier. Used To identify the property stored in User Profile */
    private static final String SORT_BY_CONNECTIVITY_TOKEN = "SORT_CONN_";
    private static final int NOT_DEFINED = 0;

    private final CommonServices commonServices;

    public SortByConnectivityUserPreferences(CommonServices commonServices) {
        this.commonServices = commonServices;
    }


    public void setSortByConnectivityPreferences(@Nonnull final Node root, @Nonnull final Properties properties) {
        clearSortByConnectivityPreferences(properties);

        root.getAllChildren().stream()
                .filter(NodeDomain.class::isInstance)
                .map(NodeDomain.class::cast)
                .forEach(node -> properties.put(getSortByConnectivityId(node), valueOf(node.getSelectedGneId().orElse(NOT_DEFINED))));
    }

    public void loadSortByConnectivityPreferences(@Nonnull final Properties properties, @Nonnull final NodeDomain nodeDomain) {
        int value = toInt(properties.getProperty(getSortByConnectivityId(nodeDomain)), NOT_DEFINED);

        if (value == NOT_DEFINED) {
            nodeDomain.setSelectedGneId(Optional.empty());
        } else {
            nodeDomain.setSelectedGneId(Optional.of(value));
        }
    }

    @Nonnull
    public Optional<Properties> loadUserPreferences() {
        Optional<ISecureClientSession> clientSession = commonServices.getDcnPluginHelper().getClientSession();
        if (clientSession.isPresent()) {
            return Optional.ofNullable(clientSession.get().getUserProfile(commonServices.getDcnPluginHelper().getPluginId()));
        }
        return Optional.empty();
    }

    private void clearSortByConnectivityPreferences(Properties properties) {
        properties.entrySet().stream()
                .filter(entry -> startsWith(entry.getKey().toString(), SORT_BY_CONNECTIVITY_TOKEN))
                .map(entry -> entry.getKey().toString()).collect(Collectors.toList())
                .stream().forEach(properties::remove);
    }

    protected final String getSortByConnectivityId(NodeDomain nodeDomain) {
        return join(SORT_BY_CONNECTIVITY_TOKEN, nodeDomain.getValue().getName());
    }
}
