package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.container;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.ContextAction;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainerRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.components.JfxMenu;
import com.ossnms.tools.jfx.components.JfxMenuItem;

import javax.annotation.Nonnull;
import javax.swing.JMenuItem;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Nodes.isSingleSelection;

public class ContainerContextAction implements ContextAction{

    private final Collection<JfxAction> actions = new ArrayList<>();

    @Override
    public Collection<JMenuItem> createAction(@Nonnull final Collection<Node> selectedNodes, TreeTableViewModel model) {
        if (isSingleSelection(selectedNodes) && containsNodeContainer(selectedNodes)) {
            final JfxMenu menuNew = new JfxMenu(TreeTableLabels.NEW.guiName());
            actions.stream().map(JfxMenuItem::new).forEach(menuNew::add);
            return Collections.singletonList(menuNew);
        }

        return Collections.emptyList();
    }

    private boolean containsNodeContainer(final Collection<Node> selectedNodes) {
        return selectedNodes.stream()
                .filter(node -> NodeContainerRoot.class.isInstance(node) || NodeContainer.class.isInstance(node) )
                .findFirst().isPresent();
    }

    @Override
    public void addActions(final Collection<JfxAction> actions){
        this.actions.clear();
        this.actions.addAll(actions);
    }
}
