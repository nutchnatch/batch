package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.DcnTreeTable;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;

import javax.annotation.Nonnull;
import javax.swing.tree.TreePath;
import java.awt.Point;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.handlers.NodeToManagedObject.resolveManagedObjects;
import static java.awt.dnd.DnDConstants.ACTION_MOVE;
import static java.awt.dnd.DnDConstants.ACTION_NONE;
import static java.util.Collections.emptyList;
import static java.util.Optional.ofNullable;

public class TreeDropHandler extends DropTargetAdapter {
    private static final int DEFAULT_ACTION = ACTION_MOVE;
    private final DcnTreeTable treeTable;
    private final CommonTransferHandler commonTransferHandler;

    public TreeDropHandler(@Nonnull final DcnTreeTable treeTable, CommonTransferHandler commonTransferHandler) {
        this.treeTable = treeTable;
        this.commonTransferHandler = commonTransferHandler;
    }

    @Override
    public void dragEnter(DropTargetDragEvent event) {
        if (event != null) {
            int operation = canDrop(event) ? DEFAULT_ACTION : ACTION_NONE;
            event.acceptDrag(operation);
        }
    }

    @Override
    public void dragOver(DropTargetDragEvent event) {
        if (event != null) {
            if (canDrop(event)) {
                event.acceptDrag(event.getDropAction());
            } else {
                event.rejectDrag();
            }
        }
    }

    @Override
    public void drop(DropTargetDropEvent event) {
        event.acceptDrop(DEFAULT_ACTION);
        boolean dropped = commonTransferHandler.acceptTransfer(event.getTransferable(), objectsAt(event.getLocation()));
        if (dropped) {
            event.dropComplete(true);
        } else {
            event.rejectDrop();
        }
    }

    private boolean canDrop(DropTargetDragEvent event) {
        return commonTransferHandler.canAcceptTransfer(event.getTransferable(), objectsAt(event.getLocation()));
    }

    private Collection<IManagedObject> objectsAt(Point position) {
        Collection<Node> targetNodes = nodeAt(position).map(Arrays::asList).orElse(emptyList());
        return resolveManagedObjects(treeTable, targetNodes);
    }

    private Optional<Node> nodeAt(Point position) {
        return ofNullable(position)
                .map(point -> treeTable.getTree().getClosestRowForLocation(point.x, point.y))
                .map(row -> treeTable.getTree().getPathForRow(row))
                .map(TreePath::getLastPathComponent)
                .filter(Node.class::isInstance).map(Node.class::cast);
    }
}
