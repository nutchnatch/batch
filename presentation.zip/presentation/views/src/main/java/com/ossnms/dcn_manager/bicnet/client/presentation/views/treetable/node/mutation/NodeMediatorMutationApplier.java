package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.dcn_manager.bicnet.client.api.state.RequiredStateVerification;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.StaticConfiguration;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.ChannelGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;

import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isActive;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isDeactivating;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isActivating;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_ACTIVATE_MEDIATORS_SAN;
import static java.util.Comparator.comparing;
import static org.apache.commons.lang3.StringUtils.EMPTY;

public class NodeMediatorMutationApplier extends NodeMutationApplier<FullMediatorData, NodeMediator> {
    private final NodeChannelMutationApplier nodeChannelMutationApplier;
    private final StaticConfiguration staticConfiguration;

    public NodeMediatorMutationApplier(RepositoryManager repositoryManager,
                                       CommonServices commonServices, GraphicalRepresentationBuilder<FullMediatorData> graphicalRepresentation) {
        super(repositoryManager, commonServices, graphicalRepresentation);
        staticConfiguration = commonServices.getStaticConfiguration();
        nodeChannelMutationApplier = new NodeChannelMutationApplier(repositoryManager, commonServices,
                new ChannelGraphicalRepresentationBuilder(commonServices.getIconManager()));
    }

    @Override public NodeMediatorMutationApplier applyMutation(FullMediatorData fullMediatorData, NodeMediator node) {
        final IMediator mediator = fullMediatorData.getMediator();

        applyGraphicalRepresentationMutation(fullMediatorData, node);
        updateWarningIcon(node, Node::hasNotActiveChild);

        applyToogleButtonChanges(fullMediatorData, node);

        node.getValue().setName(mediator.getIdName());

        node.getColumns().setValue(ColumnId.ADDRESS, mediator.getDisplayAddress())
                .setValue(ColumnId.INFO, mediator.getAdditionalInfo())
                .setValue(ColumnId.STATE, mediator.getDisplayState())
                .setValue(ColumnId.STANDBY_STATE, fullMediatorData.getInfo().getStandbyDisplayState().orElse(EMPTY))
                .setValue(ColumnId.TYPE, typeLabel(mediator.getMediatorType()))
                .setValue(ColumnId.USER_TEXT, fullMediatorData.getInfo().getUserText().orElse(EMPTY));

        return this;
    }

    @Override public boolean structureChanged(FullMediatorData fullMediatorData, NodeMediator node) {
        return !Objects.equals(fullMediatorData.getMediator().getIdName(), node.getValue().getName());
    }

    private String typeLabel(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType type) {
        return staticConfiguration.findMediatorType(type.name())
                .flatMap(MediatorType::guiLabel)
                .orElse(type.guiLabel());
    }

    @Override
    public NodeMediatorMutationApplier loadChildrenNodes(NodeMediator nodeMediator) throws RepositoryException {
        final Collection<FullChannelData> channels = getRepositoryManager().getChannelRepository()
                .queries()
                .findByParentId(nodeMediator.getId())
                .stream()
                .sorted(comparing(FullChannelData::getIdName))
                .collect(Collectors.toList());

        channels.forEach(channel -> {
            NodeChannel nodeChannel = new NodeChannel(channel.getInfo().getChannelId(), nodeMediator);

            try {
                nodeChannelMutationApplier.loadChildrenNodes(nodeChannel);
            } catch (RepositoryException e) {
                Throwables.propagate(e);
            }

            nodeChannel.getValue().setName(channel.getIdName());
            nodeMediator.addChild(nodeChannel);
            nodeChannelMutationApplier.applyMutation(channel, nodeChannel);
        });

        return this;
    }

    protected void applyToogleButtonChanges(FullMediatorData fullMediatorData, NodeMediator node) {
        final Optional<GuiActualActivationState> actualActivationState = fullMediatorData.getInfo()
                .getGuiActiveActualActivationState();

        boolean isRequiredStateActive = RequiredStateVerification.isEnable(fullMediatorData.getMediator());

        node.getValue().setToogleButtonChecked(isRequiredStateActive);
        actualActivationState.ifPresent(activationState -> node.getValue().setActualActivationState(activationState));

        if (isRequiredStateActive && isActive(actualActivationState)) {
            node.getValue().setToogleButtonEnable(!node.hasChildrenActivated());

        } else if (isDeactivating(actualActivationState) || isActivating(actualActivationState)) {
            node.getValue().setToogleButtonEnable(false);

        } else {
            node.getValue().setToogleButtonEnable(true);
        }

        checkRequiredActivationPermission(fullMediatorData.getMediator(), node, OP_ACTIVATE_MEDIATORS_SAN);
    }
}
