package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeChannelMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

public class ChannelTreeNodeEventListener extends TreeNodeEventListener<FullChannelData, NodeChannel> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelTreeNodeEventListener.class);

    public ChannelTreeNodeEventListener(final ModelUpdater modelUpdater, final CommonServices commonServices,
            final RepositoryManager repositoryManager,
            final GraphicalRepresentationBuilder<FullChannelData> graphicalRepresentation) {
        super(modelUpdater, commonServices, repositoryManager,
                new NodeChannelMutationApplier(repositoryManager, commonServices, graphicalRepresentation));
    }

    @Override protected void remove(@Nonnull final FullChannelData fullChannelData) {
        final Optional<NodeChannel> nodeEm = NodeFinder
                .tryFindChannelNode(getModelUpdater().getNodeRoot(), fullChannelData.getChannel().getId());

        if (nodeEm.isPresent()) {
            final Node nodeMediator = (Node) nodeEm.get().getParent();
            getModelUpdater().removeNode(nodeEm.get());
            nodeMediator.removeChild(nodeEm.get());
            getMutationApplier().applyParentUpdate(fullChannelData, nodeEm.get());
            LOGGER.debug("Channel({}) removed.", fullChannelData.getChannel().getIdName());
        } else {
            LOGGER.error("EM({}) Node already removed.", fullChannelData.getChannel().getIdName());
        }
    }

    @Override protected void add(@Nonnull final FullChannelData fullChannelData) {
        final Optional<NodeMediator> nodeMediator = NodeFinder.tryFindMediatorNode(getModelUpdater().getNodeRoot(),
                fullChannelData.getChannel().getAssociatedMediatorId());

        if (nodeMediator.isPresent()) {
            final NodeChannel nodeChannel = new NodeChannel(fullChannelData.getChannel().getId(), nodeMediator.get());
            nodeChannel.getValue().setName(fullChannelData.getChannel().getIdName());

            if (nodeMediator.get().addChild(nodeChannel)) {
                getMutationApplier().applyMutation(fullChannelData, nodeChannel);

                getMutationApplier().applyParentUpdate(fullChannelData, nodeChannel);

                getModelUpdater().insertNode(nodeChannel);
                getModelUpdater()
                        .updateRequiredActivationState(nodeChannel, nodeChannel.getValue().isToogleButtonChecked());

                LOGGER.debug("Channel({}) added.", fullChannelData.getChannel().getIdName());
            }
        } else {
            LOGGER.error("Mediator({}) not present in tree.", fullChannelData.getChannel().getAssociatedMediator());
        }
    }

    @Override protected void update(@Nonnull final FullChannelData fullChannelData) {
        final Optional<NodeChannel> nodeChannel = NodeFinder
                .tryFindChannelNode(getModelUpdater().getNodeRoot(), fullChannelData.getChannel().getId());

        if (nodeChannel.isPresent()) {
            NodeChannel channelNode = nodeChannel.get();

            if (getMutationApplier().structureChanged(fullChannelData, channelNode)) {
                getMutationApplier().applyMutation(fullChannelData, channelNode);
                getModelUpdater().applyStructureChanged(channelNode);
            } else {
                getMutationApplier().applyMutation(fullChannelData, channelNode);
                getModelUpdater().updateNode(channelNode);
                updateChannel(fullChannelData, nodeChannel);
            }

            getMutationApplier().applyParentUpdate(fullChannelData, channelNode);
            getModelUpdater().updateRequiredActivationState(nodeChannel.get(),
                    nodeChannel.get().getValue().isToogleButtonChecked());
            LOGGER.debug("Channel({}) updated. {}", fullChannelData.getChannel().getIdName(), fullChannelData);
        } else {
            LOGGER.error("Channel({}) Node is not present on DcnTreeTable.", fullChannelData.getChannel().getIdName());
        }
    }

    private void updateChannel(@Nonnull FullChannelData fullChannelData, Optional<NodeChannel> nodeChannel) {
        final Node oldParent = getParentIfChanged(nodeChannel, fullChannelData.getChannel());
        if (null != oldParent) {
            applyParentMutation(oldParent, nodeChannel, fullChannelData.getChannel());
        }
    }

    private void applyParentMutation(Node oldParent, Optional<NodeChannel> nodeChannelOptional, IEM channel) {
        final Optional<NodeMediator> newParentMediator = NodeFinder
                .tryFindMediatorNode(getModelUpdater().getNodeRoot(), channel.getAssociatedMediatorId());

        newParentMediator.ifPresent(
                newParent -> nodeChannelOptional.ifPresent(nodeChannel -> moveNode(oldParent, nodeChannel, newParent)));
    }

    private Node getParentIfChanged(Optional<NodeChannel> nodeChannel, IEM channel) {
        if (nodeChannel.isPresent()) {
            final Node oldParent = nodeChannel.get().getParentNode().get();
            if (oldParent.getId() != channel.getAssociatedMediatorId()) {
                return oldParent;
            }
        }
        return null;
    }
}

