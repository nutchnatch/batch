package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.stream.Stream;

import static com.google.common.collect.ImmutableMap.of;
import static java.awt.datatransfer.DataFlavor.stringFlavor;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toSet;

public class TransferTransformer<T extends IManagedObjectId> {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransferTransformer.class);

    private final DataFlavor namesFlavor;
    private final DataFlavor bicnetFlavor;
    private final Class<T> supportedType;

    TransferTransformer(String mimeType, Class<T> supportedType) {
        namesFlavor = stringFlavor;
        bicnetFlavor = bicnetFlavor(mimeType);
        this.supportedType = supportedType;
    }

    public Transferable transferable(Collection<IManagedObject> selectedObjects) {
        Collection<T> supported = supported(selectedObjects).collect(toSet());
        return supported.isEmpty() ? Transfers.NO_TRANSFER : new Transfers(of(
                namesFlavor, () -> names(supported),
                bicnetFlavor, () -> writeStream(array(supported))));
    }

    private T[] array(Collection<T> supported) {
        return supported.stream().toArray(value -> (T[]) Array.newInstance(supportedType, value));
    }

    public Collection<T> extract(Transferable transferable) {
        try {
            if (transferable.isDataFlavorSupported(bicnetFlavor)) {
                return readStream((InputStream) transferable.getTransferData(bicnetFlavor));
            }
        } catch (UnsupportedFlavorException | IOException e) {
            LOGGER.error("Failed to extract from transferable {}", transferable, e);
        }
        return emptyList();
    }

    /**
     * Validated if this transformer supports provided objects
     */
    public boolean supports(Collection<IManagedObject> objects) {
        return supported(objects).findFirst().isPresent();
    }

    private Stream<T> supported(Collection<IManagedObject> objects) {
        return objects.stream().filter(supportedType::isInstance).map(supportedType::cast);
    }

    private static DataFlavor bicnetFlavor(String mimeType) {
        try {
            return new DataFlavor(mimeType, null, TransferTransformer.class.getClassLoader());
        } catch (ClassNotFoundException e) {
            LOGGER.error("Error creating DataFlavor.", e);
            return null;
        }
    }

    private String names(Collection<T> nodes) {
        return nodes.stream()
                .filter(IManagedObject.class::isInstance).map(IManagedObject.class::cast)
                .map(IManagedObject::getNativeName)
                .collect(joining(", "));
    }

    private InputStream writeStream(T[] data) {
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        try (ObjectOutputStream objectStream = new ObjectOutputStream(byteStream)) {
            objectStream.writeObject(data);
        } catch (IOException e) {
            LOGGER.error("Error writing objects to bytes {}", data, e);
        }
        return new ByteArrayInputStream(byteStream.toByteArray());
    }

    private Collection<T> readStream(InputStream stream) {
        try (ObjectInputStream inputStream = new ObjectInputStream(stream)) {
            return Optional.ofNullable(inputStream.readObject())
                    .map(obj -> (T[]) obj)
                    .map(Arrays::asList)
                    .orElseGet(Collections::emptyList);
        } catch (IOException | ClassNotFoundException e) {
            LOGGER.error("Failed to read transferable data", e);
        }
        return emptyList();
    }
}
