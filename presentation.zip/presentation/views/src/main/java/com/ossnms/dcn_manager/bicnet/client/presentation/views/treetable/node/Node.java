package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import javax.annotation.Nonnull;
import javax.swing.tree.TreeNode;
import java.util.List;
import java.util.Optional;

public interface Node extends TreeNode {

    int getId();

    NodeValue getValue();

    void sortChildrenNodes();

    Columns getColumns();

    Optional<Node> getParentNode();

    Object getColumnByPosition(int position);

    boolean addChild(Node node);
    
    boolean removeChild(Node node);

    Node updateVisibility(Node node);
    
    Optional<Node> findChild(final int childId);
    
    <E extends Node> Optional<E> findChild(final int childId, Class<E> clazz);
    
    void setParent(Node parent);

    boolean hasChildrenActivated();

    boolean hasNotActiveChild();
    
    void tryUpdateNodeParentToggleButton(boolean hasPermission);

    Node[] getParentPath();

    String getToolTip(@Nonnull ToolTipType toolTipType);

    /**
     * Returns all children nodes regardless of their visibility
     * <br/>
     * In contrast to {@link TreeNode#children()} that enumerates only visible nodes
     */
    List<Node> getAllChildren();
}
