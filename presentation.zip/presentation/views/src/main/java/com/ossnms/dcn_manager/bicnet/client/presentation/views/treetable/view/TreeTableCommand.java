package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view;

import com.google.common.base.Joiner;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginView;
import com.ossnms.bicnet.framework.client.command.FrameworkButtonCommand;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandHandler;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableView;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader.NodeContainerRootLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader.NodeDomainRootLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader.NodeMediatorRootLoader;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader.job.FetchTreeNodes;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.container.TreeTableContainersDocument;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.container.TreeTableContainersView;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.domain.TreeTableDomainsDocument;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.domain.TreeTableDomainsView;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.mediator.TreeTableMediatorsDocument;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.mediator.TreeTableMediatorsView;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.DcnPluginLabels;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

import static org.apache.commons.lang3.StringUtils.EMPTY;

/**
 * Manage the creation and execution of the Views and your dependencies.  
 */
public class TreeTableCommand extends FrameworkButtonCommand {
    private static final Logger LOGGER = LoggerFactory.getLogger(TreeTableCommand.class);
    private static final long serialVersionUID = -4659605306241101187L;

    public static final FrameworkCommandID COMMAND_ID = new FrameworkCommandID("DcnManager-TreeTableView");

    private static final String DCN_MENU_ID = "DcnManager-TreeTableView";
    private static final String FILTER = EMPTY;
    private static final String ACCELERATOR = EMPTY;
    private static final String GUI_NAME = "DcnManager";

    private final RepositoryManager repositoryManager;
    private final CommonServices commonServices;
    private final ListenersRegistrationManager changeListenersManager;

    /**
     * Used by BicNet Framework via reflection
     */
    public TreeTableCommand() {
        this(new RepositoryManager(), new CommonServices(), new CacheListenersRegistrationManager());
    }

    public TreeTableCommand(RepositoryManager repositoryManager, CommonServices commonServices,
            ListenersRegistrationManager changeListenersManager) {

        this.repositoryManager = repositoryManager;
        this.commonServices = commonServices;
        this.changeListenersManager = changeListenersManager;

        setCommandID(COMMAND_ID);

        setCmdDetails(
                TreeTableLabels.TITLE.toString(), 
                DCN_MENU_ID, 
                FILTER, 
                ACCELERATOR, 
                TreeTableLabels.MENU_SHORT_DESCRIPTION.toString(), 
                TreeTableLabels.MENU_LONG_DESCRIPTION.toString(), 
                ResourcesIconFactory.ICON_WINDOW_DCN_MANAGEMENT_16,
                
                // Set menu path
                DcnPluginLabels.DCN_MENU_NAME.toString(),
                TreeTableLabels.MENU_NAME.toString());

        setPluginHelper(commonServices.getFrameworkPluginHelper());
        setActionListener(new FrameworkCommandHandler(COMMAND_ID));
        setActionType(BiCNetPluginActionType.MANAGEMENT);
        setComponentName(GUI_NAME);
        setSecurityId(SecureAction.OPEN_MANAGEMENT_VIEW_SAN.getIdentifier());
        setVisibleOnMainToolbar(true);
    }

    private TreeTableView createMediatorView() throws FrameworkException {
        final String title = Joiner.on(" - ").join(TreeTableLabels.TITLE.toString(),
                TreeTableLabels.MEDIATOR_VIEW_TITLE.toString());

        final TreeTableMediatorsDocument document = new TreeTableMediatorsDocument(commonServices, repositoryManager,
                changeListenersManager);

        final TreeTableMediatorsView view = new TreeTableMediatorsView(title, document);

        document.executeJob(new FetchTreeNodes<>(
                new NodeMediatorRootLoader(repositoryManager, commonServices, view.getTreeTableModel().getNodeRoot()),
                document));

        return view;
    }

    private TreeTableView createDomainView() throws FrameworkException {
        final String title = Joiner.on(" - ").join(TreeTableLabels.TITLE.toString(), TreeTableLabels.DOMAIN_VIEW_TITLE.toString());

        final TreeTableDomainsDocument document = new TreeTableDomainsDocument(commonServices, repositoryManager,
                changeListenersManager);

        final TreeTableDomainsView view = new TreeTableDomainsView(title, document);

        document.executeJob(new FetchTreeNodes<>(
                new NodeDomainRootLoader(repositoryManager, commonServices, view.getTreeTableModel().getNodeRoot()),
                document));

        return view;
    }

    private TreeTableView createContainerView() throws FrameworkException {
        final String title = Joiner.on(" - ").join(TreeTableLabels.TITLE.toString(), TreeTableLabels.CONTAINER_VIEW_TITLE.toString());

        final TreeTableContainersDocument document = new TreeTableContainersDocument(commonServices, repositoryManager,
                changeListenersManager);

        final TreeTableContainersView view = new TreeTableContainersView(title, document);

        document.executeJob(new FetchTreeNodes<>(
                new NodeContainerRootLoader(repositoryManager, commonServices,
                        view.getTreeTableModel().getNodeRoot()),
                document));

        return view;
    }

    @Override
    public boolean execute(final IManagedObject[] selectedObjects) {
        try {
            TreeTableView view;

            switch (CurrentViewSingleton.getInstance().getCurrentView()) {
                case CONTAINER:
                    view = createContainerView();
                    break;
                case DOMAIN:
                    view = createDomainView();
                    break;
                case MEDIATOR:
                default:
                    view = createMediatorView();
            }

            setView(view);
            commonServices.getMessageBox().setComponent(view);

            view.setCommand(this);
            view.setFrame(getPluginHelper().createFrame(view, BiCNetPluginFrameType.INTERNAL));
            view.getFrame().showFrame();
        } catch (final Exception e) {
            LOGGER.error("Error creating DCN View", e);
            commonServices.getMessageBox().errorMessage("Critical error creating DCN Manager View.");
            return false;
        }

        return true;
    }

    @Override
    public void bringViewToFront(@Nonnull final BiCNetPluginView view) {
        if (null != view) {
            ((TreeTableView)view).bringToFront();
        }
    }

    @Override
    public IFrameworkCommand clone(final IManagedObject[] selectedObjects) {
        return this; //HAMMER - this is needed by FindDialogCommand to resolve TreeTableView. In other case getView returns null
    }

    @Override public TreeTableView getView() {
        return (TreeTableView) super.getView();
    }
}
