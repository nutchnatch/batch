package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import org.apache.commons.lang3.builder.EqualsBuilder;

import javax.annotation.Nonnull;
import java.util.Objects;

public class TableColumn {
    
    private static final int DEFAULT_WIDTH = 10;
    
    private final ColumnId id;
    private final String name;
    
    private int width;
    private boolean visible;
    private boolean removable;

    public TableColumn(@Nonnull final ColumnId id, @Nonnull final TreeTableLabels name) {
        super();
        
        this.id = id;
        this.name = name.toString();
        this.width = DEFAULT_WIDTH;
        this.visible = true;
        this.removable = true;
    }

    public ColumnId getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    
    public int getWidth() {
        return width;
    }

    public TableColumn width(int width) {
        this.width = width;
        return this;
    }
    
    public boolean isVisible() {
        return visible;
    }

    public TableColumn visible(boolean visible) {
        this.visible = visible;
        return this;
    }
    
    public boolean isRemovable() {
        return removable;
    }

    public TableColumn removable(boolean removable) {
        this.removable = removable;
        return this;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        
        if (obj == this) {
            return true;
        }
        
        if (obj.getClass() != getClass()) {
            return false;
        }
        
        final TableColumn rhs = (TableColumn) obj;
        return new EqualsBuilder().appendSuper(super.equals(obj))
                .append(id, rhs.id)
                .append(name, rhs.name)
                .isEquals();
    }
}
