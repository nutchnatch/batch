package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;

public class Nes extends TransferTransformer<INEId> {
    public Nes() {
        super(INEId.MIME_TYPE, INEId.class);
    }
}
