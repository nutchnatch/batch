package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.NeGraphicalRepresentationBuilder;

import java.util.Objects;

import static java.util.Comparator.comparing;
import static org.apache.commons.lang3.StringUtils.defaultString;

public class NodeSystemContainerMutationApplier extends NodeMutationApplier<ISystemContainer, NodeSystemContainer> {
    private final NodeNeMutationApplier nodeNeMutationApplier;

    public NodeSystemContainerMutationApplier(RepositoryManager repositoryManager, CommonServices commonServices,
                                              GraphicalRepresentationBuilder<ISystemContainer> graphicalRepresentation) {
        super(repositoryManager, commonServices, graphicalRepresentation);

        nodeNeMutationApplier = new NodeNeMutationApplier(repositoryManager, commonServices,
                new NeGraphicalRepresentationBuilder(commonServices.getIconManager()));

    }

    @Override
    public NodeMutationApplier<ISystemContainer, NodeSystemContainer> applyMutation(ISystemContainer container, NodeSystemContainer node) {
        applyGraphicalRepresentationMutation(container, node);
        updateWarningIcon(node, NodeSystemContainer::hasChildrenWithDifferentActivations);

        node.getValue().setName(container.getIdName());
        node.getColumns().setValue(ColumnId.USER_TEXT, defaultString(container.getUserLabel()));

        return this;
    }

    @Override public boolean structureChanged(ISystemContainer container, NodeSystemContainer node) {
        return !Objects.equals(container.getIdName(), node.getValue().getName());
    }

    @Override
    public NodeMutationApplier<ISystemContainer, NodeSystemContainer> loadChildrenNodes(NodeSystemContainer nodeSystemContainer) throws RepositoryException {
        getRepositoryManager().getNeRepository()
                .queries().findBySystemContainerId(nodeSystemContainer.getId()).stream()
                .sorted(comparing(fullNeData -> fullNeData.getNe().getIdName()))
                .forEach(ne -> {
                    NodeNe nodeNe = new NodeNe(ne.getNe().getId(), nodeSystemContainer);
                    nodeNeMutationApplier.applyMutation(ne, nodeNe);
                    nodeSystemContainer.addChild(nodeNe);
                    nodeNeMutationApplier.applyParentUpdate(ne, nodeNe);
                });

        return this;
    }
}
