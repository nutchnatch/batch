package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader;

import com.ossnms.dcn_manager.bicnet.client.api.exception.DcnClientException;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;

public abstract class NodeLoader {
    private final RepositoryManager repositoryManager;
    private final CommonServices commonServices;
    private final Node rootNode;

    NodeLoader(RepositoryManager repositoryManager, CommonServices commonServices, Node rootNode) {
        this.repositoryManager = repositoryManager;
        this.commonServices = commonServices;
        this.rootNode = rootNode;
    }

    public abstract Node load() throws DcnClientException;

    Node getRootNode() {
        return rootNode;
    }

    protected final RepositoryManager getRepositoryManager() {
        return repositoryManager;
    }

    protected final CommonServices getCommonServices() {
        return commonServices;
    }
}
