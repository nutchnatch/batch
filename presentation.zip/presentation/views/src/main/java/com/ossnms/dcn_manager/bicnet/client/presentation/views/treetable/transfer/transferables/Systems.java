package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.transferables;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;

public class Systems extends TransferTransformer<ISystemContainerId> {
    public Systems() {
        super(ISystemContainerId.MIME_TYPE, ISystemContainerId.class);
    }
}
