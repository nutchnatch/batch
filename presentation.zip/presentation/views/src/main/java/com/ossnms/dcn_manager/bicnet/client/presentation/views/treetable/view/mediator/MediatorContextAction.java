package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.mediator;

import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.ContextAction;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediatorRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.components.JfxMenuItem;

import javax.annotation.Nonnull;
import javax.swing.JMenuItem;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.stream.Collectors;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Nodes.isSingleSelection;

public class MediatorContextAction implements ContextAction {

    private final Collection<JfxAction> actions = new ArrayList<>();

    @Override public Collection<JMenuItem> createAction(@Nonnull final Collection<Node> selectedNodes, TreeTableViewModel model) {
        return isSingleSelection(selectedNodes) && containsNodeMediatorRoot(selectedNodes) ?
                actions.stream().map(JfxMenuItem::new).collect(Collectors.toList()) :
                Collections.emptyList();
    }

    private boolean containsNodeMediatorRoot(final Collection<Node> selectedNodes) {
        return selectedNodes.stream().filter(NodeMediatorRoot.class::isInstance).findFirst().isPresent();
    }

    @Override
    public void addActions(final Collection<JfxAction> actions) {
        this.actions.clear();
        this.actions.addAll(actions);
    }
}