package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.loader;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeMediatorMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.MediatorGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.stream.Collectors;

import static java.util.Comparator.comparing;
import static javax.swing.SwingUtilities.invokeLater;

public class NodeMediatorRootLoader extends NodeLoader {
    private static final Logger LOGGER = LoggerFactory.getLogger(NodeMediatorRootLoader.class);

    private final NodeMediatorMutationApplier mutationApplier;

    public NodeMediatorRootLoader(final RepositoryManager repositoryManager, final CommonServices commonServices,
            final Node parent) {
        super(repositoryManager, commonServices, parent);

        mutationApplier = new NodeMediatorMutationApplier(repositoryManager,commonServices,
                new MediatorGraphicalRepresentationBuilder(getCommonServices().getIconManager()));
    }

    @Override
    public Node load() throws RepositoryException {
        LOGGER.debug("NodeMediatorRootLoader :: Get All Mediators...");
        final Collection<FullMediatorData> mediators = getRepositoryManager().getMediatorRepository().getAll()
                .stream()
                .sorted(comparing(FullMediatorData::getIdName))
                .collect(Collectors.toList());

        invokeLater(() -> {
            LOGGER.debug("NodeMediatorRootLoader :: Loading Mediator View Nodes...");
            try {
                for (final FullMediatorData mediator : mediators) {
                    final NodeMediator nodeMediator = new NodeMediator(mediator.getMediator().getId(), getRootNode());

                    mutationApplier.applyMutation(mediator, nodeMediator);
                    mutationApplier.loadChildrenNodes(nodeMediator);

                    getRootNode().addChild(nodeMediator);
                }
            } catch (RepositoryException e) {
                Throwables.propagate(e);
            }
        });

        return getRootNode();
    }
}
