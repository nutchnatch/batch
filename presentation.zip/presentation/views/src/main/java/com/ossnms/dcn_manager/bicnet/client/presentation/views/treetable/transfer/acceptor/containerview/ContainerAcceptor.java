package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.containerview;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.dcn_manager.bicnet.client.api.Containers;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobAssociateContainerWithContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common.AbstractAcceptor;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.bicnet.client.api.ObjectUtils.anyMatch;
import static com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.Actions.getAllNEsInContainerAndSubContainers;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.MOVE_CONTAINER_SAN;

public class ContainerAcceptor extends AbstractAcceptor<IGenericContainerId> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContainerAcceptor.class);

    public ContainerAcceptor(RepositoryManager repositoryManager, CommonServices commonServices) {
        super(repositoryManager, commonServices);
    }

    @Override public boolean canAccept(Collection<IGenericContainerId> transfer, IManagedObject destination) {
        return anyMatch(destination, IGenericContainer.class)
                && hasPermission()
                && destinationIsNotAChild(transfer, (IGenericContainer) destination)
                && withoutInvisibleNes(transfer);
    }

    @Override public boolean perform(Collection<IGenericContainerId> transfer, IManagedObject destination) {
        IGenericContainerId containerId = (IGenericContainer) destination;
        queueJob(new JobAssociateContainerWithContainer(transfer, containerId,
                getPluginHelper().getSessionContext(), getFacade()));
        return true;
    }

    private boolean hasPermission() {
        return checkPermission(MOVE_CONTAINER_SAN);
    }

    /**
     * Operator should not be able to drop parent container to child container
     */
    private boolean destinationIsNotAChild(Collection<IGenericContainerId> dragged, IGenericContainer destination) {
        return pathToRootFrom(destination.getId()).stream()
                .allMatch(parentId -> !dragged.contains(parentId));
    }

    private Collection<IGenericContainerId> pathToRootFrom(int containerId) {
        Collection<IGenericContainerId> result = new ArrayList<>();
        result.add(new GenericContainerIdItem(containerId));

        if (containerId != Containers.ROOT_CONTAINER_ID) {
            fetchContainer(containerId).ifPresent(container -> result.addAll(pathToRootFrom(container.getParentId())));
        }
        return result;
    }

    private Optional<IGenericContainer> fetchContainer(int destinationId) {
        try {
            return getRepositoryManager().getContainerRepository().get(destinationId);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to access repository", e);
            return Optional.empty();
        }
    }

    /**
     * Operator should not be able to drop container with invisible NEs (in any nested level)
     */
    private boolean withoutInvisibleNes(Collection<IGenericContainerId> containers) {
        return nesUnder(containers)
                .map(NEIdItem::new)
                .noneMatch(this::isInvisible);
    }

    private Stream<Integer> nesUnder(Collection<IGenericContainerId> containers) {
        return containers.stream()
                .map(IGenericContainerId::getId)
                .flatMap(container -> getAllNEsInContainerAndSubContainers(container, getRepositoryManager()).stream());
    }

    private boolean isInvisible(INEId ne) {
        return !checkVisibility(ne);
    }
}
