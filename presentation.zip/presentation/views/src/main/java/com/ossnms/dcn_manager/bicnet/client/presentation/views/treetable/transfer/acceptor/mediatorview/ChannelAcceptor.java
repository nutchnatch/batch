package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.mediatorview;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobMoveChannels;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common.AbstractAcceptor;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.bicnet.client.api.ObjectUtils.anyMatch;
import static com.ossnms.dcn_manager.bicnet.client.api.state.ActualActivationStateVerification.isInactive;
import static com.ossnms.dcn_manager.bicnet.client.api.state.RequiredStateVerification.isDisable;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.MOVE_CHANNEL_SAN;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

public class ChannelAcceptor extends AbstractAcceptor<IEMId> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelAcceptor.class);

    public ChannelAcceptor(RepositoryManager repositoryManager, CommonServices commonServices) {
        super(repositoryManager, commonServices);
    }

    @Override
    public boolean canAccept(Collection<IEMId> channels, IManagedObject destination) {
        Collection<FullChannelData> validChannels = validChannels(channels);
        return isAMediator(destination)
                && hasPermission()
                && !validChannels.isEmpty()
                && mediatorCanAcceptChannels((IMediator) destination, validChannels);
    }

    @Override public boolean perform(Collection<IEMId> transfer, IManagedObject mediator) {
        Collection<IEMId> validChannels = validChannels(transfer).stream()
                .map(FullChannelData::getChannel)
                .collect(toList());
        queueJob(new JobMoveChannels(getPluginHelper().getSessionContext(), getFacade(), validChannels, (IMediator) mediator));
        return true;
    }

    private Collection<FullChannelData> validChannels(Collection<IEMId> channels) {
        return fetchChannels(channels).stream()
                .filter(this::isDeactivated)
                .filter(c -> nesAreDeactivated(c.getChannel()))
                .filter(c -> nesAreVisible(c.getChannel()))
                .collect(toList());
    }

    private boolean isAMediator(IManagedObject mediator) {
        return anyMatch(mediator, IMediator.class);
    }

    private boolean nesAreDeactivated(IEMId channel) {
        return childrenNes(channel.getId())
                .allMatch(ne -> isDisable(ne.getNe()));
    }

    private boolean nesAreVisible(IEMId c) {
        List<INE> nes = childrenNes(c.getId())
                .map(FullNeData::getNe).collect(toList());
        return getSecurity().checkVisibility(nes);
    }

    private Stream<FullNeData> childrenNes(Integer channelId) {
        try {
            return getRepositoryManager().getNeRepository().queries().findByParentId(channelId).stream();
        } catch (RepositoryException e) {
            LOGGER.error("Failed to access repository", e);
            return Stream.empty();
        }
    }

    private boolean hasPermission() {
        return checkPermission(MOVE_CHANNEL_SAN);
    }

    private boolean mediatorCanAcceptChannels(IMediator mediator, Collection<FullChannelData> channels) {
        return supportedChannels(mediator).containsAll(channelTypes(channels));
    }

    private Collection<String> channelTypes(Collection<FullChannelData> channels) {
        return channels.stream()
                .map(channel -> channel.getChannel().getEmType())
                .collect(toList());
    }

    private Collection<String> supportedChannels(IMediatorId mediatorId) {
        try {
            Optional<String> mediatorType = getRepositoryManager().getMediatorRepository().get(mediatorId.getId())
                    .map(mediator -> mediator.getMediator().getMediatorType().toString());
            return getRepositoryManager().getChannelRepository().
                    getRegisteredTypes(getPluginHelper().getSessionContext(), mediatorType);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to access repository", e);
            return emptyList();
        }

    }

    private Collection<FullChannelData> fetchChannels(Collection<IEMId> channels) {
        List<Integer> ids = channels.stream().map(IEMId::getId).collect(toList());
        try {
            return getRepositoryManager().getChannelRepository().get(ids);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to get channels", e);
            return emptyList();
        }
    }

    private boolean isDeactivated(FullChannelData channel) {
        return isDisable(channel.getChannel()) &&
                isInactive(channel.getInfo().getGuiActiveActualActivationState());
    }
}
