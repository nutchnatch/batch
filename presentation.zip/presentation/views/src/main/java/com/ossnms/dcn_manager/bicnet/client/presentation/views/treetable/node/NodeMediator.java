package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node;

import com.google.common.base.Objects;
import com.ossnms.dcn_manager.bicnet.client.api.html.HtmlGenerator;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import org.apache.commons.lang3.builder.EqualsBuilder;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NAME;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NUMBER_CHANNELS;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_NUMBER_NES;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_STATE;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels.COLUMN_TYPE;
import static java.util.Optional.of;
import static org.apache.commons.lang3.StringUtils.EMPTY;

/**
 * NodeMediator children nodes: NodeChannel.
 */
public class NodeMediator extends NodeTemplate {

    public NodeMediator(final int id, final Node parent) {
        super(id, new Columns(), parent);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId(), getParent());
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }

        if (obj == this) {
            return true;
        }

        if (obj.getClass() != getClass()) {
            return false;
        }

        final NodeMediator value = (NodeMediator) obj;
        return new EqualsBuilder()
                .append(getId(), value.getId())
                .append(getParent(), value.getParent())
                .isEquals();
    }

    @Override public String getToolTip(@Nonnull final ToolTipType toolTipType) {
        return of(toolTipType)
                .filter(t -> toolTipType == ToolTipType.CHECKBOX)
                .filter(t -> !getValue().isToogleButtonEnable())
                .filter(t -> getValue().isToogleButtonChecked())
                .map(t -> TreeTableLabels.MEDIATOR_CHECKBOX_TOOLTIP.toString())
                .orElse(generateNodeTooltip());
    }

    private String generateNodeTooltip() {
        return HtmlGenerator.start()
                .boldText(delimiter(COLUMN_NAME)).simpleHtmlText(getValue().getName())

                .newLineBold(delimiter(COLUMN_TYPE))
                .simpleHtmlText(getColumns().valueOf(ColumnId.TYPE).map(ColumnValue::getValue).orElse(EMPTY))

                .newLineBold(delimiter(COLUMN_STATE))
                .simpleHtmlText(getColumns().valueOf(ColumnId.STATE).map(ColumnValue::getValue).orElse(EMPTY))

                .newLineBold(delimiter(COLUMN_NUMBER_CHANNELS)).simpleHtmlText(getChildCount())

                .newLineBold(delimiter(COLUMN_NUMBER_NES)).simpleHtmlText(totalNEsUnderMediator())
                .toHtml();
    }

    private long totalNEsUnderMediator() {
        return getAllChildren().stream().mapToInt(Node::getChildCount).sum();
    }
}
