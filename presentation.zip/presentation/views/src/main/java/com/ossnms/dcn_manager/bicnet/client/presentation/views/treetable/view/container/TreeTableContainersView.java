package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.container;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.api.action.Action;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionTreetableNewNeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionTreetableNewNeUnderContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.treetable.ActionTreetableNewSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableView;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainerRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.builder.TransferHandlersBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.components.EToolBarButtonStyle;
import com.ossnms.tools.jfx.components.JfxDropDownToolBarButton;
import com.ossnms.tools.jfx.components.JfxMenuItem;
import com.ossnms.tools.jfx.components.JfxPopupMenu;
import com.ossnms.tools.jfx.components.JfxToolBarSeparator;

import javax.swing.event.ListSelectionEvent;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import static com.ossnms.dcn_manager.bicnet.client.api.ObjectUtils.anyMatch;
import static java.util.Arrays.asList;

public class TreeTableContainersView extends TreeTableView {
    private static final long serialVersionUID = 522222482732448212L;
    private static final String ID = TreeTableContainersView.class.getName();
    private static final boolean PUT_ARROW = true;

    private final JfxDropDownToolBarButton addButtonRoot;
    private final JfxAction actionAddSystemContainer;
    private final JfxAction actionAddNeContainer;
    private final JfxAction actionShowAdd;
    private final JfxAction actionAddNe;

    public TreeTableContainersView(final String title, final TreeTableContainersDocument document) {
        super(title, document,
                new TreeTableViewModel(new NodeContainerRoot(TreeTableLabels.ROOT_CONTAINER_NODE.toString())),
                new TreeTableContainersNodeHandler(document.getRepositoryManager()), new ContainerContextAction(), 
                TransferHandlersBuilder.containerView(document.getRepositoryManager(), document.getCommonServices()));

        final JfxPopupMenu addButtonRootMenu = new JfxPopupMenu();

        actionAddSystemContainer = new ActionTreetableNewSystemContainer(getTreeTable(),getTreeTable().getDialogHandler(), document.getCommonServices());
        actionAddNeContainer = new ActionTreetableNewNeContainer(getTreeTable(), getTreeTable().getDialogHandler(), document.getCommonServices());
        actionShowAdd = new ActionShowAddButton(TreeTableLabels.NEW.guiName());
        addButtonRoot = new JfxDropDownToolBarButton(actionShowAdd, ResourcesIconFactory.ICON_TOOL_NEW_16,
                EToolBarButtonStyle.SMALL, addButtonRootMenu, PUT_ARROW);
        actionAddNe = new ActionTreetableNewNeUnderContainer(getTreeTable(), getTreeTable().getDialogHandler(), document.getCommonServices());

        addButtonRootMenu.add(new JfxMenuItem(actionAddSystemContainer));
        addButtonRootMenu.add(new JfxMenuItem(actionAddNeContainer));
        addButtonRootMenu.add(new JfxMenuItem(actionAddNe));

        addContainerActionsToContextMenu();
        updateContainerActions();

        initContainersGuiNames();
        initControls();
    }

    @Override protected List<?> getButtonActions() {
        return asList(addButtonRoot, getActionDuplicate(), getActionDelete(), new JfxToolBarSeparator(),
                getActionProperties(), getMenuSelectView(), getActionFindNe(), getActionOpenTable());
    }

    @Override protected String getProfileId() {
        // This method return this specific class name to store view collapse/expand tree status
        return ID;
    }

    @Override public void valueChanged(final ListSelectionEvent e) {
        updateContainerActions();
        updateToolbarActions();
    }

    @Override protected void addExtraPropertiesToSave(Properties properties) {
        // nothing
    }

    private void initContainersGuiNames() {
        getTreeTable().setName("ContainerView");
        addButtonRoot.setName("Add");
        actionAddSystemContainer.setComponentName("AddSystemContainer");
        actionAddNeContainer.setComponentName("AddNeContainer");
        actionAddNe.setComponentName("AddNe");
    }

    private void updateContainerActions() {
        actionAddSystemContainer.updateAction();
        actionAddNeContainer.updateAction();
        actionAddNe.updateAction();
        actionShowAdd.updateAction();
    }

    private void addContainerActionsToContextMenu() {
        getMenuContainer().setSelected(true);
        getContextMenuActions().addActions(asList(actionAddNeContainer, actionAddSystemContainer, actionAddNe));
    }

    private final class ActionShowAddButton extends Action {

        private static final long serialVersionUID = 1L;
        private static final int MIN_ALLOWED = 1;

        private ActionShowAddButton(final JfxText textName) {
            super(textName, textName);
            addIcon(ResourcesIconFactory.ICON_TOOL_NEW_16);
            addButtonToolTip(textName);
        }

        @Override public boolean fulfilled(final JfxAction action) {
            Collection<Node> selectedNodes = getTreeTable().getSelectedNodes();
            return hasAllowedSize(selectedNodes) && isRootOrContainer(selectedNodes);
        }

        private boolean isRootOrContainer(Collection<Node> selectedNodes) {
            return selectedNodes.stream()
                    .allMatch(node -> anyMatch(node, NodeContainerRoot.class, NodeContainer.class, NodeSystemContainer.class));
        }

        private boolean hasAllowedSize(Collection<Node> selectedNodes) {
            return selectedNodes.size() == MIN_ALLOWED;
        }

        @Override public void actionPerformed(final JfxAction action) {
        }
    }
}
