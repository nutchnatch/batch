package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.transfer.acceptor.common;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.Job;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.JOptionPane;
import java.io.Serializable;
import java.util.Collection;

public abstract class AbstractAcceptor<T extends Serializable> implements TransferAcceptor<Collection<T>, IManagedObject> {
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractAcceptor.class);
    private final RepositoryManager repositoryManager;
    private final SecureActionValidation security;
    private final BicnetServerFacade facade;
    private final DcnPluginHelper pluginHelper;

    protected AbstractAcceptor(RepositoryManager repositoryManager, CommonServices commonServices) {
        this.repositoryManager = repositoryManager;
        security = commonServices.getSecureActionValidation();
        facade = commonServices.getBicnetServerFacade();
        pluginHelper = commonServices.getDcnPluginHelper();
    }

    protected boolean checkPermission(SecureAction action) {
        return security.checkPermission(action);
    }
    
    protected boolean checkPermission(SecureAction action, IManagedObjectId... objectsToCheck) {
        return security.checkPermission(action, objectsToCheck);
    }

    protected boolean checkPermission(SecureAction action, Collection<? extends IManagedObjectId> objectsToCheck) {
        return checkPermission(action, objectsToCheck.toArray(new IManagedObjectId[0]));
    }

    protected boolean checkVisibility(INEId ne) {
        return security.checkVisibility(ne);
    }

    protected DcnPluginHelper getPluginHelper() {
        return pluginHelper;
    }

    protected BicnetServerFacade getFacade() {
        return facade;
    }

    protected void queueJob(Job<?> job) {
        try {
            pluginHelper.queueJob(job);
        } catch (BiCNetPluginException e) {
            LOGGER.error("An error occurred while moving Nodes", e);
            JfxOptionPane.showMessageBox(null, JfxStringTable.IDS_UNKNOWN_ERROR.toString(),
                    JfxStringTable.IDS_UNKNOWN_ERROR_DESCRIPTION.toString(), JOptionPane.CLOSED_OPTION,
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    protected RepositoryManager getRepositoryManager() {
        return repositoryManager;
    }

    protected SecureActionValidation getSecurity() {
        return security;
    }
}
