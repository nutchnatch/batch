package com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

public interface NodeHandler {

    /**
     * Transform only the first match of the Node class type in the Tree hierarchy.
     *   
     * @param nodes Only the first match class type
     * @return
     */
    Iterable<IManagedObject> transformOnlyFirstMatchNodeType(Iterable<Node> nodes) throws RepositoryException;
    
    /**
     * 
     * @param nodes
     * @return
     */
    Iterable<IManagedObject> transformAllKnownNodeTypes(Iterable<Node> nodes)  throws RepositoryException;
}
