package com.ossnms.dcn_manager.bicnet.client.presentation.views.listener;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.mutation.NodeContainerMutationApplier;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.GraphicalRepresentationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.utils.NodeFinder.tryFindContainerNode;
import static java.util.function.Function.identity;

public class ContainerTreeNodeEventListener extends TreeNodeEventListener<IGenericContainer, NodeContainer> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContainerTreeNodeEventListener.class);

    public ContainerTreeNodeEventListener(@Nonnull final ModelUpdater modelUpdater, final CommonServices commonServices,
                                          final RepositoryManager repositoryManager,
                                          final GraphicalRepresentationBuilder<IGenericContainer> graphicalRepresentation) {
        super(modelUpdater, commonServices, repositoryManager,
                new NodeContainerMutationApplier(repositoryManager, commonServices, graphicalRepresentation));
    }

    @Override protected void remove(@Nonnull IGenericContainer container) {

        tryFindContainerNode(getModelUpdater().getNodeRoot(), container.getId()).ifPresent(nodeContainer -> {
            getModelUpdater().removeNode(nodeContainer);
            nodeContainer.getParentNode().ifPresent(parent -> parent.removeChild(nodeContainer));
            LOGGER.debug("Container({}) removed.", container.getIdName());
        });
    }

    @Override protected void add(@Nonnull IGenericContainer container) {
        findParentNode(container.getParentId()).ifPresent(nodeParent ->
                addContainer(container, nodeParent));
    }

    private void addContainer(@Nonnull IGenericContainer container, @Nonnull final Node parentContainer) {
        final NodeContainer nodeContainer = new NodeContainer(container.getId(), parentContainer);
        getMutationApplier().applyMutation(container, nodeContainer);

        if (parentContainer.addChild(nodeContainer)) {
            getModelUpdater().insertNode(nodeContainer);
            LOGGER.debug("Container({}) added.", container.getIdName());
        }
    }

    @Override protected void update(@Nonnull IGenericContainer container) {
        tryFindContainerNode(getModelUpdater().getNodeRoot(), container.getId()).ifPresent(nodeContainer -> {
            if (getMutationApplier().structureChanged(container, nodeContainer)) {
                getMutationApplier().applyMutation(container, nodeContainer);
                getModelUpdater().applyStructureChanged(nodeContainer);
            } else {
                getMutationApplier().applyMutation(container, nodeContainer);
                getModelUpdater().updateNode(nodeContainer);
            }

            Node currentParent = (Node) nodeContainer.getParent();
            if (currentParent.getId() != container.getParentId()) {
                findParentNode(container.getParentId()).ifPresent(newParent -> {
                    moveNode(currentParent, nodeContainer, newParent);
                    updateChildrenToggles(nodeContainer);
                });
            }

            LOGGER.debug("Container({}) updated. {}", container.getIdName(), container);
        });
    }

    private void updateChildrenToggles(Node nodeParent) {
        nodeParent.getAllChildren().forEach(node -> {
            getModelUpdater().updateRequiredActivationState(node, node.getValue().isToogleButtonChecked());
            updateChildrenToggles(node);
        });
    }

    private Optional<Node> findParentNode(int parentId) {
        if (parentId == getModelUpdater().getNodeRoot().getId()) {
            return Optional.of(getModelUpdater().getNodeRoot());
        } else {
            return tryFindContainerNode(getModelUpdater().getNodeRoot(), parentId).map(identity());
        }
    }
}
