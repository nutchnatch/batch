package com.ossnms.dcn_manager.bicnet.client.propertypage.model;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;

public class ElementsSelection<K> {

    private final K primaryId;
    private Optional<Map<String, String>> primaryProperties;

    private Optional<Iterable<K>> secondariesId;
    private Optional<Iterable<Map<String, String>>> secondariesTemplates;
    private Optional<Iterable<Map<String, String>>> secondariesProperties;

    public ElementsSelection(@Nonnull final K primary) {
        primaryId = primary;

        primaryProperties = Optional.empty();
        secondariesTemplates = Optional.empty();
        secondariesProperties = Optional.empty();
        secondariesId = Optional.empty();
    }

    public ElementsSelection<K> primaryProperties(@Nonnull final Map<String, String> primaryProperties) {
        this.primaryProperties = Optional.of(primaryProperties);
        return this;
    }

    public ElementsSelection<K> secondariesId(@Nonnull final Iterable<K> secondariesId) {
        this.secondariesId = Optional.of(secondariesId);
        return this;
    }

    public ElementsSelection<K> secondariesTemplates(@Nonnull final Iterable<Map<String, String>> secondariesTemplates) {
        this.secondariesTemplates = Optional.of(secondariesTemplates);
        return this;
    }

    public ElementsSelection<K> secondariesProperties(@Nonnull final Iterable<Map<String, String>> secondariesProperties) {
        this.secondariesProperties = Optional.of(secondariesProperties);
        return this;
    }

    public Optional<Iterable<Map<String, String>>> getSecondariesProperties() {
        return secondariesProperties;
    }

    public Optional<Map<String, String>> getPrimaryProperties() {
        return primaryProperties;
    }

    public Optional<Iterable<K>> getSecondariesId() {
        return secondariesId;
    }

    public Optional<Iterable<Map<String, String>>> getSecondariesTemplates() {
        return secondariesTemplates;
    }

    public K getPrimaryId() {
        return primaryId;
    }
}
