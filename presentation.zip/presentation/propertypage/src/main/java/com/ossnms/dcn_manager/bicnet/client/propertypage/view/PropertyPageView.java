package com.ossnms.dcn_manager.bicnet.client.propertypage.view;

import com.google.common.collect.Lists;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.framework.client.command.FrameworkCommitButton;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.FrameworkView;
import com.ossnms.bicnet.framework.client.helpers.feedback.FrameworkActivityIndicator;
import com.ossnms.bicnet.framework.client.utils.FrameworkCancelCommand;
import com.ossnms.bicnet.framework.client.utils.FrameworkCloseCommand;
import com.ossnms.bicnet.framework.client.utils.FrameworkOkCommand;
import com.ossnms.dcn_manager.bicnet.client.api.view.MessageBox;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.page.PageBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.ValidatorException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.PropertyPageLabels;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * PropertyPage Dynamic view.
 * <p>
 * Builds the {@link #getMainComponent()} using the {@link PageBuilder}.
 */
public class PropertyPageView<M> extends FrameworkView {

    private static final Logger LOGGER = LoggerFactory.getLogger(PropertyPageView.class);

    private static final long serialVersionUID = 7343028228401339289L;

    private static final String ID = PropertyPageView.class.getName();
    private static final boolean RESIZABLE = true;

    private final FrameworkActivityIndicator activityIndicator;
    private final FrameworkCancelCommand cancelCommand;
    private final FrameworkCloseCommand closeCommand;
    private final FrameworkOkCommand okCommand;
    private final MessageBox messageBox;

    public PropertyPageView(@Nonnull final PageDocument<M> document) throws PropertyValueBuilderException {
        super(ID, document.getPropertyPage().getTitle(), (FrameworkDocument) document, RESIZABLE, document.getPropertyPage().getHelpId());

        final JScrollPane propertyPagePanel = new PageBuilder(document.getPropertyPage().getPage(), getDocument().getValueRepository()).build();

        messageBox = new MessageBox(this);
        closeCommand = new FrameworkCloseCommand(this);
        cancelCommand = new FrameworkCancelCommand(this);
        okCommand = new FrameworkOkCommandImpl();
        okCommand.setEnabled(false);
        activityIndicator = buildActivityIndicator(propertyPagePanel);

        initControls();

        registerOkActionOnPropertyValues();
    }

    private FrameworkActivityIndicator buildActivityIndicator(@Nonnull final JScrollPane propertyPagePanel) {
        final FrameworkActivityIndicator indicator = new FrameworkActivityIndicator(propertyPagePanel);
        indicator.setActivityIndicatorVisible(true);
        return indicator;
    }

    @Override public void updateData(@Nullable Object errorMessage) {
        if (errorMessage != null) {
            messageBox.errorMessage(PropertyPageLabels.ERROR_LOAD_PROPERTIES);
            cancelCommand.execute(null);
        }

        if (!getDocument().getPropertyPage().applyCommand().isPresent()) {
            getDocument().getValueRepository().allToReadOnly();
        }

        activityIndicator.setActivityIndicatorVisible(false);
        
        fireStateChanged();
    }

    @Override @Nonnull public JComponent getMainComponent() {
        return activityIndicator;
    }

    @Override @Nonnull protected List<FrameworkCommitButton> getCommitActions() {
        getComponent().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "Esc");

        if (getDocument().getPropertyPage().applyCommand().isPresent()) {
            getComponent().getActionMap().put(KeyEvent.VK_ESCAPE, cancelCommand);
            return Lists.newArrayList(cancelCommand, okCommand);
        } else {
            getComponent().getActionMap().put(KeyEvent.VK_ESCAPE, closeCommand);
            return Lists.newArrayList(closeCommand);
        }
    }

    /**
     * Overrides the persisted window size by Common Framework with the current #getMainComponent size.
     */
    protected void repack() {
        SwingUtilities.invokeLater(() -> {
            if (getFrame() != null) {
                getFrame().pack();
            }
        });
    }

    private void registerOkActionOnPropertyValues() {
        for (final PropertyValue value : getDocument().getValueRepository().allValues()) {
            value.addConditionListener((ChangeListener) okCommand);
        }
    }

    private PageDocument<?> getDocument() {
        return (PageDocument<?>) getFrameworkDocument();
    }

    private void fireStateChanged() {
        boolean documentHasChanges = getDocument().getValueRepository().enableButtonOk();
        boolean withoutOverlay = !activityIndicator.isLayerVisible();
        cancelCommand.setEnabled(withoutOverlay);
        closeCommand.setEnabled(withoutOverlay);
        okCommand.setEnabled(documentHasChanges && withoutOverlay);
    }

    /*
     * Executes the action OK.
     */
    private class FrameworkOkCommandImpl extends FrameworkOkCommand implements DocumentListener, FocusListener, ChangeListener, ItemListener {
        private static final long serialVersionUID = -1362382361629077907L;

        @Override public boolean execute(@Nullable IManagedObject[] selectedObjects) {
            activityIndicator.setMessage("Saving...");
            activityIndicator.setActivityIndicatorVisible(true);
            fireStateChanged();

            new DoInBackground<>(this::applyChange, succesfully -> onDone(selectedObjects, succesfully)).execute();

            return true;
        }

        private Boolean applyChange() {
            try {
                getDocument().getValueRepository().validateValues();

                if (getDocument().getPropertyPage().applyCommand().isPresent()) {
                    getDocument().getPropertyPage().applyCommand().get()
                            .call(getDocument().getValueRepository());
                }

                return true;
            } catch (final ValidatorException e) {
                LOGGER.error("Error on property validation", e);
                messageBox.errorMessage(e.getMessage());
            } catch (final RepositoryException e) {
                LOGGER.error("Error to execute PropertyPage Apply Command", e);
                messageBox.errorMessage(e);
            } catch (final Exception e) {
                LOGGER.error("Critical Error to execute PropertyPage Apply Command", e);
                messageBox.errorMessage(PropertyPageLabels.ERROR);
            }
            return false;
        }

        private void onDone(@Nullable IManagedObject[] selectedObjects, Boolean succesfully) {
            activityIndicator.setActivityIndicatorVisible(false);
            fireStateChanged();
            if (succesfully) {
                cancelCommand.execute(selectedObjects);
            }
        }

        @Override public void stateChanged(ChangeEvent e) {
            fireStateChanged();
        }

        @Override public void itemStateChanged(ItemEvent e) {
            fireStateChanged();
        }

        @Override public void focusGained(FocusEvent e) {
            fireStateChanged();
        }

        @Override public void focusLost(FocusEvent e) {
            fireStateChanged();
        }

        @Override public void insertUpdate(DocumentEvent e) {
            fireStateChanged();
        }

        @Override public void removeUpdate(DocumentEvent e) {
            fireStateChanged();
        }

        @Override public void changedUpdate(DocumentEvent e) {
            fireStateChanged();
        }
    }

    private static class DoInBackground<T> extends SwingWorker<Void, Void> {

        private T result;
        private final Supplier<T> inBackground;
        private final Consumer<T> whenDone;

        DoInBackground(Supplier<T> inBackground, Consumer<T> whenDone) {
            this.inBackground = inBackground;
            this.whenDone = whenDone;
        }

        @Override protected Void doInBackground() {
            result = inBackground.get();
            return null;
        }

        @Override protected void done() {
            whenDone.accept(result);
        }
    }
}
