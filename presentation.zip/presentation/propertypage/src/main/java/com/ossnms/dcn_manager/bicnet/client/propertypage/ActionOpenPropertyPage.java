package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.api.action.PluginAction;
import com.ossnms.dcn_manager.bicnet.client.api.chain.Chain;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainProcessException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepositorySingleton;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.PropertyPageLabels;

import javax.annotation.Nonnull;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.util.Objects;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.bicnet.client.api.Containers.ROOT_CONTAINER_ID;

/**
 * Action listener for BiCNet GUI Plug-ins.
 * 
 * The chain of responsibility will decides dynamically how to open the PropertyPage (in update context) for each Manage
 * Object type.
 * 
 * In a multi-selection context will be opened the PropertyPage for the high level ManageObject.
 * 
 * <b>Example</b>: For the MediatorView the high level object is the Mediator Node. Therefore, if the selection contains
 * Mediators, Channels and NEs; the property page will be opened the in multi-selection context for the Mediator objects
 */
public class ActionOpenPropertyPage extends PluginAction {
    private static final String UI_ID = ActionOpenPropertyPage.class.getName();

    private final Chain<IManagedObject[]> chain;
    private final OpenPropertyPagePermissionChecker permissionChecker;

    /**
     * Initialize the command.
     */
    public ActionOpenPropertyPage(RepositoryManager repositoryManager, CommonServices commonServices) {
        this(commonServices, repositoryManager, PropertyPagesRepositorySingleton.getInstance());
    }

    private ActionOpenPropertyPage(CommonServices commonServices, RepositoryManager repositoryManager,
            PropertyPagesRepository propertyPagesRepository) {
        super(UI_ID, PropertyPageLabels.MENU_PROPERTIES, PropertyPageLabels.MENU_PROPERTIES_DESCRIPTION,
                KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), ResourcesIconFactory.ICON_TOOL_PROPERTIES_16);

        this.permissionChecker = new OpenPropertyPagePermissionChecker(commonServices);

        chain = new CommandOpenMediatorProperties(repositoryManager, commonServices, propertyPagesRepository)
                .setNext(new CommandOpenChannelProperties(repositoryManager, commonServices, propertyPagesRepository)
                .setNext(new CommandOpenContainerProperties(repositoryManager, commonServices, propertyPagesRepository)
                .setNext(new CommandOpenSystemContainerProperties(repositoryManager, commonServices, propertyPagesRepository)
                .setNext(new CommandOpenNeProperties(repositoryManager, commonServices, propertyPagesRepository)))));
    }

    /**
     * Call the first Dispatcher of the chain flow.
     * 
     * @throws ChainProcessException
     */
    public void execute(final IManagedObject[] managedObjects) throws ChainProcessException {
        chain.handleRequest(managedObjects);
    }

    /**
     * Call the first Dispatcher of the chain flow.
     */
    @Override
    public void eventPluginActionPerformed(final IManagedObject[] managedObjects) throws BiCNetPluginException {
        try {
            chain.handleRequest(managedObjects);
        } catch (final ChainProcessException e) {
            throw new BiCNetPluginException(e);
        }
    }

    @Override
    public boolean isPluginActionAllowed(@Nonnull final IManagedObject[] elements) {
        return hasPermission(elements) && notRoot(elements);
    }

    private boolean notRoot(IManagedObject[] elements) {
        return !Stream.of(elements)
                .anyMatch(this::isRootContainer);
    }

    private boolean isRootContainer(IManagedObject managedObject) {
        return Objects.equals(managedObject, new GenericContainerIdItem(ROOT_CONTAINER_ID));
    }

    private boolean hasPermission(@Nonnull IManagedObject[] elements) {
        if (Stream.of(elements).findFirst().filter(IMediator.class::isInstance).isPresent()) {
            return permissionChecker.hasPermissionToOpenMediator(elements);
        }
        if (Stream.of(elements).findFirst().filter(IEM.class::isInstance).isPresent()) {
            return permissionChecker.hasPermissionToOpenChannel(elements);
        }
        if (Stream.of(elements).findFirst().filter(IGenericContainer.class::isInstance).isPresent()) {
            return permissionChecker.hasPermissionToOpenContainer(elements);
        }
        if (Stream.of(elements).findFirst().filter(ISystemContainer.class::isInstance).isPresent()) {
            return permissionChecker.hasPermissionToOpenContainer(elements);
        }
        return permissionChecker.hasPermissionToOpenNE(elements);
    }
}
