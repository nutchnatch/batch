package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownMediatorPropertyNames;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepositorySingleton;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForNewObject;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PageGlobalVariable;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DefaultManageObjectValues;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DynamicIdNameFactory;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.apache.commons.lang3.tuple.ImmutablePair;

import javax.annotation.Nullable;

/**
 * Start point to call the New Mediator flow.
 */
public class CommandNewMediator implements Command<Void> {
    private final RepositoryManager repository;
    private final PropertyPagesRepository pagesRepository;
    private final CommonServices commonServices;
    private final String type;

    public CommandNewMediator(final RepositoryManager repository, final CommonServices commonServices, final String type) {
        this(repository, commonServices, PropertyPagesRepositorySingleton.getInstance(), type);
    }

    protected CommandNewMediator(final RepositoryManager repository, final CommonServices commonServices,
            final PropertyPagesRepository pagesRepository, final String type) {
        this.repository = repository;
        this.commonServices = commonServices;
        this.pagesRepository = pagesRepository;
        this.type = type;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void call(@Nullable final Void parent) throws CommandException {
        try {
            MediatorType mediatorType = commonServices.getStaticConfiguration().findMediatorType(type)
                    .orElseThrow(() -> new CommandException("Mediator type=''{}'' not supported", type));
            
            final String name = DynamicIdNameFactory.build(repository.getMediatorRepository(), mediatorType.guiLabel().orElse(type));
            final IMediator mediatorItem = DefaultManageObjectValues.newBasicMediatorItem(type, name);
            final PageDocument<FullMediatorData> document = new PageDocumentForNewObject<FullMediatorData>()
                    .addOrModify(valueRepository -> valueRepository.modifyOrAdd(WellKnownMediatorPropertyNames.ID_NAME, name));

            buildConfiguration(document.getValueRepository());

            // Parsed propertyPage for the corresponding MediatorType
            final Page page = pagesRepository.getPropertyPage(mediatorType);

            FullMediatorData fullMediatorData = new FullMediatorData(mediatorItem, new MediatorInfo(mediatorItem.getId()));
            // Delegates the execution
            new OpenPropertyPageForNew<>(ImmutablePair.of(fullMediatorData, name), commonServices, mediatorType,
                    document, repository.getMediatorRepository(), page).call();
        } catch (final RepositoryException | PropertyValueBuilderException e) {
            throw new CommandException(e);
        }
    }

    private void buildConfiguration(PropertyValueRepository valueRepository) {
        boolean nodeManagerSelected = repository.getConfigurationRepository().isNodeManagerSelected();
        PageGlobalVariable pageGlobalVariable = new PageGlobalVariable(
                WellKnownMediatorPropertyNames.NODE_MANAGER_SELECTED,
                Boolean.toString(nodeManagerSelected));
        valueRepository.add(pageGlobalVariable);
    }
}
