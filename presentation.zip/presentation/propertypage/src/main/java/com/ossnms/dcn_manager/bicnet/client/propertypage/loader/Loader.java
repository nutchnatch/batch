package com.ossnms.dcn_manager.bicnet.client.propertypage.loader;

import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

public interface Loader<ITEM> {

    ITEM load() throws RepositoryException;
}
