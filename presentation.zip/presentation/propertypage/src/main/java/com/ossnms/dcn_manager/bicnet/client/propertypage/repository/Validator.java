package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;


/**
 * Validator for property page components.
 */
public interface Validator {
    
    /**
     * Validates the Property Page Component.
     * 
     * The component validator is defined putting the class name on property page item definition, like:
     * 
     * <code> <table-model validator="<VALIDATOR_CLASS_NAME>" /> </code>
     * 
     * @return true when the component is valid
     * @throws ValidatorException if the component is not valid
     */
    boolean validate() throws ValidatorException;
}
