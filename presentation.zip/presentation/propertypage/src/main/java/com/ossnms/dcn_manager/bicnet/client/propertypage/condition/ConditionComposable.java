package com.ossnms.dcn_manager.bicnet.client.propertypage.condition;

import javax.annotation.Nonnull;

/**
 * The condition composable has associated two conditions(simple or composable) with a logic operator.
 */
public class ConditionComposable implements ConditionState {

    private final ConditionState conditionLeft;
    private final ConditionLogical logical;
    private final ConditionState conditionRight;

    public ConditionComposable(@Nonnull ConditionState conditionLeft, @Nonnull ConditionLogical logical, @Nonnull ConditionState conditionRight) {
        this.conditionLeft = conditionLeft;
        this.logical = logical;
        this.conditionRight = conditionRight;
    }

    /**
     * Verifies recursively the associated conditions.
     */
    @Override
    public boolean verify() {
        return logical.verify(conditionLeft.verify(), conditionRight.verify());
    }
}
