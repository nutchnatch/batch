package com.ossnms.dcn_manager.bicnet.client.propertypage.page;

/**
 * PropertyPage group align type.
 * 
 * @see com.ossnms.dcn_manager.core.jaxb.propertypage.PropertyGroup
 */
public enum PropertyGroupAlignType {
    adjacent, below;
}
