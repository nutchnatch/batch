package com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor;

import java.awt.Color;

public enum CellColor {

    ERROR(Color.RED),
    DEFAULT(Color.WHITE),
    TEXT(Color.BLACK);
    
    private Color color;

    CellColor(Color color) {
        this.color = color;
    }
    
    public Color color() {
        return this.color;
    }
}
