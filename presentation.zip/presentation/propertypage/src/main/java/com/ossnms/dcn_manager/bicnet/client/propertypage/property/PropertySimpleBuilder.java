package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueButtonBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueTypeFactory;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Button;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Label;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.RangeLabel;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxLabel;

import javax.annotation.Nonnull;
import javax.swing.Box;
import javax.swing.JPanel;
import java.awt.Component;
import java.util.Optional;

/**
 * Builder for #Property type #PropertyTypeFactory.simple.
 */
public class PropertySimpleBuilder extends PropertyBuilder<JPanel> {

    /**
     * @param panelForm The form to add the components
     * @param property The Property to build.
     * @param valueRepository The repository to add the #Property #Value.
     */
    public PropertySimpleBuilder(@Nonnull final DynamicPanelForm panelForm, @Nonnull final Property property, @Nonnull final PropertyValueRepository valueRepository) {
        super(panelForm, property, valueRepository);
    }

    /**
     * Builds a JPanel with: #Label, #Value and #Range/#Button.
     */
    @Override
    @Nonnull
    public JPanel build()  throws PropertyValueBuilderException {
        final Optional<Label> label = Optional.ofNullable(getProperty().getLabel());
        final Optional<RangeLabel> rangeLabel = Optional.ofNullable(getProperty().getRangeLabel());
        final Optional<Button> button = Optional.ofNullable(getProperty().getValue().getButton());
        
        Optional<JfxLabel> labelComponent = Optional.empty();

        final Component component = ValueTypeFactory.createOf(getProperty().getValue(), getValueRepository());

        if (label.isPresent()) {
            labelComponent = Optional.of(new LabelBuilder(label.get()).build());
            getPanelForm().addLabel(labelComponent.get());
        }

        if (rangeLabel.isPresent()) {
            addMnemonic(labelComponent, component);
            getPanelForm().addComponentWithRange(new RangeLabelBuilder(rangeLabel.get()).build(), component);
            
        } else if (button.isPresent()) {
            final JfxButton jfxButton = new ValueButtonBuilder((PropertyValue) component, button.get(), getValueRepository()).build();
            getPanelForm().addValueButton(component, jfxButton);

        } else {
            addMnemonic(labelComponent, component);
            getPanelForm().addValue(component);
        }
        
        getPanelForm().add(Box.createGlue());
        
        return getPanelForm();
    }

    private void addMnemonic(Optional<JfxLabel> labelComponent, final Component component) {
        if (labelComponent.isPresent()) {
            labelComponent.get().setLabelAndMnemonicFor(component);
        }
    }
}