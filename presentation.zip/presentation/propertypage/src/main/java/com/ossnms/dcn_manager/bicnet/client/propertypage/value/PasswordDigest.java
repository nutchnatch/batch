package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.bicnet.util.crypt.IEncrypterDecrypter;
import com.ossnms.tools.jfx.JfxMessageDigest;

import javax.annotation.Nonnull;
import javax.xml.bind.DatatypeConverter;

public enum PasswordDigest {
    
    MD5 {
        @Override
        protected String of(@Nonnull final IEncrypterDecrypter encripter, @Nonnull final String pwd) {
            return DatatypeConverter.printHexBinary(encripter.encryptData(JfxMessageDigest.calcMD5(pwd)));
        }
    },
    
    NONE {
        @Override
        protected String of(@Nonnull final IEncrypterDecrypter encripter, @Nonnull final String pwd) {
            return encripter.encryptData(pwd);
        }
    };

    abstract String of(@Nonnull final IEncrypterDecrypter encripter, @Nonnull final String pwd);
    
    public static String createOf(@Nonnull final IEncrypterDecrypter encripter, @Nonnull final String coding, @Nonnull final String pwd) {
        final PasswordDigest create = PasswordDigest.valueOf(coding.toUpperCase());
        return create.of(encripter, pwd);
    }
}
