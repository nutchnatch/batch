package com.ossnms.dcn_manager.bicnet.client.propertypage.validator;

import com.google.common.base.Joiner;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.Validator;

import javax.annotation.Nonnull;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * Dynamic Proxy for Validators.
 * 
 * The Validators classes must be at the same package then the ValidatorProxy.
 */
public final class ValidatorProxy {
    
    private static final String PACKAGE = ValidatorProxy.class.getPackage().getName();
       
    private ValidatorProxy() {
    }
    
    /**
     *  * Constructs a new instance for {@link #Validator} interface implementations.
     * 
     * @param className classes must be at the same package then the ValidatorProxy.
     * @param argumentClass
     * @param argument
     * @return
     */
    @Nonnull
    public static <ARGUMENT> Validator newInstanceOf(@Nonnull final String className, Class<?> argumentClass, ARGUMENT argument) {
        try {
            final Class<?> clazz = Class.forName(Joiner.on('.').join(PACKAGE, className));
            final Constructor<?> constructor = clazz.getDeclaredConstructor(argumentClass);
            
            return (Validator) constructor.newInstance(argument);
        } catch (ClassNotFoundException | NoSuchMethodException | SecurityException | InstantiationException
                | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            throw new UnsupportedOperationException(e);
        }
    }
}
