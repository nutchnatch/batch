/**
 * Components Model for the Property Page.
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.value;