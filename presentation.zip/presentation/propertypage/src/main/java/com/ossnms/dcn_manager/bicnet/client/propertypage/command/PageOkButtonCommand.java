package com.ossnms.dcn_manager.bicnet.client.propertypage.command;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

import javax.annotation.Nonnull;

/**
 * Command to be executed by PropertyPage button OK. 
 */
public interface PageOkButtonCommand {

    /**
     * Call the action to create or update the ManageObject.
     * 
     * @param repository
     * @throws RepositoryException
     */
    void call(@Nonnull final PropertyValueRepository repository) throws RepositoryException;
}
