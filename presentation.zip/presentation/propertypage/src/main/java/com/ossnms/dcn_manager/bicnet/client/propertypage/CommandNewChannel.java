package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownEmPropertyNames;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepositorySingleton;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForNewObject;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ChannelRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DefaultManageObjectValues;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DynamicIdNameFactory;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.apache.commons.lang3.tuple.ImmutablePair;

import javax.annotation.Nonnull;

/**
 * Start point to call the New Channel flow.
 */
public class CommandNewChannel implements Command<Integer> {
    private final ChannelRepository repository;
    private final CommonServices commonServices;
    private final PropertyPagesRepository pagesRepository;
    private final String type;

    public CommandNewChannel(ChannelRepository repository, CommonServices commonServices, String type) {
        this(repository, commonServices, PropertyPagesRepositorySingleton.getInstance(), type);
    }

    protected CommandNewChannel(ChannelRepository repository, CommonServices commonServices,
            PropertyPagesRepository pagesRepository, String type) {
        this.repository = repository;
        this.commonServices = commonServices;
        this.pagesRepository = pagesRepository;
        this.type = type;
    }

    @Override
    public void call(@Nonnull final Integer parentId) throws CommandException {
        try {
            final ChannelType channelType = commonServices.getStaticConfiguration().findChannelType(type).get();
            final String name = DynamicIdNameFactory.build(repository, channelType.guiLabel().orElse(type));
            final IEM emItem = DefaultManageObjectValues.newBasicEmItem(type, name, new MediatorIdItem(parentId));
            final PageDocument<FullChannelData> document = new PageDocumentForNewObject<FullChannelData>()
                    .addOrModify(valueRepository -> valueRepository.modifyOrAdd(WellKnownEmPropertyNames.ID_NAME, name));

            // Parsed propertyPage for the corresponding ChannelType
            final Page page = pagesRepository.getPropertyPage(channelType);

            // Delegates the execution
            new OpenPropertyPageForNew<>(ImmutablePair.of(new FullChannelData(emItem,
                    new ChannelInfo(emItem.getId())), name), commonServices, channelType, document, repository, page)
                    .call();
        } catch (final RepositoryException | PropertyValueBuilderException e) {
            throw new CommandException(e);
        }
    }
}
