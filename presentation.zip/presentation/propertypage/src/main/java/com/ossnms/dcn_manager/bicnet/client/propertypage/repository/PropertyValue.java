package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Action;

import javax.swing.event.ChangeListener;

/**
 * The generalization of the GUI Components.
 * 
 * @see com.ossnms.dcn_manager.bicnet.client.propertypage.value package.
 */
public interface PropertyValue extends ActionStateListener {

    /**
     * The component #ValueId
     */
    String getId();

    /**
     * The component value as String.
     */
    String getContent();

    /**
     * Set the component value from a String.
     */
    void setContent(String content);

    /**
     * Update the component value from a String setting modification flag 
     */
    void modifyContent(String content);

    /**
     * Verifies if the component was changed.
     */
    boolean isChanged();
    
    /**
     * Verifies if the component can be moved.
     */
    boolean isMovable();
    
    /**
     * Verifies if the component is not valid.
     */
    boolean isInvalidEntry();
    
    /**
     * Verifies if is mandatory value is empty.
     */
    boolean isMandatoryValueBlank();
    
    /**
     * Verifies if is the field is enabled.
     */
    boolean isEnabled();

    /**
     * Register the Conditions to execute action on this {@link PropertyValue}.
     * 
     * @see com.ossnms.dcn_manager.bicnet.client.propertypage.condition.ConditionState
     */
    void addConditionListener(ChangeListener listener);

    /**
     * @return Gets all actions that will be executed on this {@link PropertyValue}.
     */
    ImmutableList<Action> getValueActions();
    
    /**
     * @return True, when this value must be send on update use case even without changes.
     */
    boolean forceSendOnUpdate();
    
    /**
     * Force to send the propertyValue on update use case even without changes. 
     */
    void setForceSendOnUpdate(boolean sendOnUpdate);
    
    /**
     * Send change state for Condition Listeners.
     */
    void fireStateChange();
    
    /**
     * @return True if the field supports multiselection.
     */
    boolean supportMultiselection();
    
    /**
     * @return True if the value was not changed in a multiselection flow.
     */
    boolean isUndefined();

    /**
     * @return The GUI identification
     */
    String getName();

    /**
     * Clean all listeners.
     *
     * If we not clear the conditions; the conditions will continue check states and enable/disable fields.
     *
     * See 7300 property page condition checker on field
     * "30A800AC-70A6-424D-B776-DB23E919C34D/USERCLASS_TNMS_REMOTE_LOGIN" - GCTUser-NE-RemoteLogin.xml
     *
     */
    void clearConditions();
}
