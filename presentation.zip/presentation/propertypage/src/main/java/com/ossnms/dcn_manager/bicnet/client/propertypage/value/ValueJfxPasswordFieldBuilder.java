package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.bicnet.util.crypt.DESEncrypterDecrypter;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;

public class ValueJfxPasswordFieldBuilder extends ValueBuilder<ValueJfxPasswordField> {

    public ValueJfxPasswordFieldBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        super(value, valueRepository);
    }
    
    @Override
    @Nonnull
    public ValueJfxPasswordField buildComponent() throws PropertyValueBuilderException {
        final ValueJfxPasswordField jfxPasswordField = new ValueJfxPasswordField(
                new ValueDescriptor(getValue().getId(), getValue().getAction(), getValue().getMultiselection(), getValueRepository().isDynamicEnableFieldPermitted()), 
                getValue().getCoding(), getEncrypter());

        setBasicComponentValues(jfxPasswordField);
        
        jfxPasswordField.setMandatoryEntry(Boolean.valueOf(getValue().getMandatory()));
        jfxPasswordField.setColumns(NumberUtils.toInt(getValue().getColumns()));

        jfxPasswordField.limitText(buildMaxLength());
        jfxPasswordField.setValidCharacters(buildAllowedContent());
        jfxPasswordField.setProhibitedCharacters(buildForbiddenContent());
        jfxPasswordField.setContent(buildDefaultValue());
        
        return jfxPasswordField;
    }
    
    private DESEncrypterDecrypter getEncrypter() throws PropertyValueBuilderException {
        try {
            return new DESEncrypterDecrypter();
        } catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
            throw new PropertyValueBuilderException(e);
        }
    }
}
