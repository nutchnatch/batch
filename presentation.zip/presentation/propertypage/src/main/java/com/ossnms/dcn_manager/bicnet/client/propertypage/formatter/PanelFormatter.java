package com.ossnms.dcn_manager.bicnet.client.propertypage.formatter;

import javax.annotation.Nonnull;
import javax.swing.Box;
import javax.swing.JPanel;
import java.awt.Dimension;

/**
 * Common formatter util for JPanel.
 */
public class PanelFormatter {

    /**
     * Fix the height of the panel with a dynamic resizable width.
     * @param panel
     */
    public void fixedHeightAndDynamicWith(@Nonnull final JPanel panel) {
        final Dimension dim = panel.getPreferredSize();
        final Dimension max = panel.getMaximumSize();

        max.height = Math.min(dim.height, max.height);
        panel.setMaximumSize(max);
    }
    
    /**
     * Creates an invisible "glue" component to fill the space between its neighboring components.
     * @param panel
     */
    public void addGlue(@Nonnull final JPanel panel) {
        panel.add(Box.createGlue());
    }
}
