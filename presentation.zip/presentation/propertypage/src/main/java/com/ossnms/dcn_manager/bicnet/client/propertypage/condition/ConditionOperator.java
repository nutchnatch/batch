package com.ossnms.dcn_manager.bicnet.client.propertypage.condition;

/**
 * Logic Operators to be used on {@link ConditionSimple}.
 */
enum ConditionOperator {
    eq, lt, gt, le, ge;

    public boolean verify(String left, String right) {
        boolean condition = false;

        switch (this) {
            case eq:
                condition = left.equals(right);
                break;
            case lt:
                condition = left.compareTo(right) < 0;
                break;
            case gt:
                condition = left.compareTo(right) > 0;
                break;
            case le:
                condition = left.compareTo(right) <= 0;
                break;
            case ge:
                condition = left.compareTo(right) >= 0;
                break;
            default:
                throw new UnsupportedOperationException("Unsupported operator");
        }

        return condition;
    }

}
