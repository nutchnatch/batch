package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.validator.NsapValidator;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;

public final class ValueAddressNsapBuilder extends ValueBuilder<ValueAddressNsap> {

    public ValueAddressNsapBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        super(value, valueRepository);
    }

    @Override
    @Nonnull
    public ValueAddressNsap buildComponent() {
        
        final ValueAddressNsap nsap = new ValueAddressNsap(
                new ValueDescriptor(getValue().getId(), getValue().getAction(), getValue().getMultiselection(), getValueRepository().isDynamicEnableFieldPermitted()));
        
        setBasicComponentValues(nsap);

        nsap.addValidationListener(new NsapValidator());
        nsap.setMandatoryEntry(Boolean.valueOf(getValue().getMandatory()));
        nsap.setColumns(NumberUtils.toInt(getValue().getColumns()));

        nsap.setContent(buildDefaultValue());

        nsap.limitText(buildMaxLength());
        nsap.setValidCharacters(buildAllowedContent());
        nsap.setProhibitedCharacters(buildForbiddenContent());
        
        return nsap;
    }
}
