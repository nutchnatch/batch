package com.ossnms.dcn_manager.bicnet.client.propertypage.condition;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Condition;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Literal;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Logical;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Operator;
import com.ossnms.dcn_manager.core.jaxb.propertypage.ValueId;
import org.apache.commons.lang3.tuple.ImmutableTriple;
import org.apache.commons.lang3.tuple.Triple;

import javax.annotation.Nonnull;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Builds the Condition chain.
 * 
 * The Conditions can be {@link ConditionComposable} or {@link ConditionSimple}.
 */
public class ConditionChainBuilder {

    private static final int CONDITION_LEFT = 0;
    private static final int CONDITION_RIGHT = 1;
    
    private final Condition parentCondition;
    private final PropertyValueRepository valueRepository;
    
    /**
     * 
     * @param condition The root condition of the chain.
     * @param valueRepository The repository to associate the relative ValueId from #ConditionSimple.
     */
    public ConditionChainBuilder(@Nonnull Condition condition, @Nonnull PropertyValueRepository valueRepository) {
        this.parentCondition = condition;
        this.valueRepository = valueRepository;
    }

    /**
     * Builds the condition chain recursively.
     * @throws PropertyValueBuilderException 
     */
    @Nonnull
    public ConditionChain build() throws PropertyValueBuilderException {
        final ConditionChain conditionChain = new ConditionChain();
        final ConditionState conditionVerify = startComposableChain(parentCondition, conditionChain);

        return conditionChain.setCondition(conditionVerify);
    }
    
    /*
     * Starts the condition chain creation.
     */
    @Nonnull
    private ConditionState startComposableChain(@Nonnull final Condition condition, @Nonnull  final ConditionChain conditionChain) throws PropertyValueBuilderException {
        final ConditionType conditionType = ConditionType.valueOf(condition.getType());
        final ConditionState conditionVerify;
        
        switch (conditionType) {
            case simple:
                conditionVerify = buildSimple(condition, conditionChain);
                break;
            case composable:
                conditionVerify = buildComposable(condition, conditionChain);
                break;
            default:
                throw new UnsupportedOperationException(String.format("Unsupported ConditionType=%s", conditionType)) ;
        }    
        
        return conditionVerify;
    }    

    /*
     * Builds a #ConditionSimple.
     */
    @Nonnull
    private ConditionSimple buildSimple(@Nonnull final Condition condition, @Nonnull final ConditionChain conditionChain) throws PropertyValueBuilderException {
        final List<Serializable> content = condition.getContent();

        final Optional<String> valueId = getValueId(content);
        
        if (!valueId.isPresent()) {
            throw new PropertyValueBuilderException("ValueID not present. Verify if must be a Condition Composable.");
        }

        final Optional<PropertyValue> value = valueRepository.find(getValueId(content).get());
   
        if (!value.isPresent()) {
            throw new PropertyValueBuilderException("PropertyValue not present. The associated valueId({}) is not defined.", valueId.get());
        }
        
        final Triple<PropertyValue, ConditionOperator, String> conditionSimple = 
                ImmutableTriple.of(
                        value.get(),
                        getOperator(content).get(),
                        getLiteral(content).get());

        return new ConditionSimple(conditionSimple, conditionChain);
    }

    /*
     * Builds a #ConditionComposable recursively.
     */
    @Nonnull
    private ConditionState buildComposable(@Nonnull final Condition condition, @Nonnull final ConditionChain conditionChain) throws PropertyValueBuilderException {
        final ImmutableList<Serializable> content = ImmutableList.copyOf(condition.getContent());

        final List<Condition> conditions = getConditions(content);

        final Condition conditionLeft = conditions.get(CONDITION_LEFT);
        final Condition conditionRight = conditions.get(CONDITION_RIGHT);
             
        return new ConditionComposable(
                startComposableChain(conditionLeft, conditionChain), 
                getLogical(content).get(), 
                startComposableChain(conditionRight, conditionChain));        
    }
     
    /*
     * Gets the #Condition from the content list. 
     */
    @Nonnull
    private List<Condition> getConditions(@Nonnull final List<Serializable> content) {
        return content.stream()
                .filter(input -> input instanceof Condition)
                .map(input -> (Condition) input)
                .collect(Collectors.toList());
    }
     
    /*
     * Gets the #ValueId from the content list. 
     */
    @Nonnull
    private Optional<String> getValueId(@Nonnull final List<Serializable> content) {
        return content.stream()
                .filter(input -> input instanceof ValueId)
                .findFirst()
                .map(input -> ((ValueId) input).getContent());
    }
    
    /*
     * Gets the #ConditionOperator from the content list. 
     */
    @Nonnull
    private Optional<ConditionOperator> getOperator(@Nonnull final List<Serializable> content) {
        return content.stream()
                .filter(input -> input instanceof Operator)
                .findFirst()
                .map(input -> {
                    final String operator = ((Operator) input).getType();
                    return ConditionOperator.valueOf(operator);
                });
    }
    
    /*
     * Gets the #ConditionLogical from the content list. 
     */
    @Nonnull
    private Optional<ConditionLogical> getLogical(@Nonnull final List<Serializable> content) {
        return content.stream()
                .filter(input -> input instanceof Logical)
                .findFirst()
                .map(input -> {
                    final String logical = ((Logical) input).getType();
                    return ConditionLogical.valueOf(logical);
                });
    }
    
    /*
     * Gets the #Literal value  from the content list. 
     */
    @Nonnull
    private Optional<String> getLiteral(@Nonnull final List<Serializable> content) {
        return content.stream()
                .filter(input -> input instanceof Literal)
                .findFirst()
                .map(input -> ((Literal) input).getContent());
    }
}
