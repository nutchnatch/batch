package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import com.google.common.base.Function;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.TableButtonBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.JScrollPaneBuilder;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Button;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.table.JfxTable;

import javax.annotation.Nonnull;
import javax.swing.JPanel;
import java.awt.Component;

/**
 * Builder for #Property type #PropertyTypeFactory.table.
 */
public class PropertyTableBuilder extends PropertyBuilder<JPanel> {
    
    /**
     * @param panelForm The form to add the components
     * @param property The Property to build.
     * @param valueRepository The repository to add the #Property #Value.
     */
    public PropertyTableBuilder(@Nonnull final DynamicPanelForm panelForm, @Nonnull final Property property, @Nonnull final PropertyValueRepository valueRepository) {
        super(panelForm, property, valueRepository);
    }

    /**
     * Builds a JPanel with #Table and #Button 
     */
    @Override
    public JPanel build() {
        final JfxLabel label = new LabelBuilder(getProperty().getLabel()).build();
        final JfxTable table = new RouteTableBuilder(getProperty().getTableModel(), getValueRepository()).build();
        
        label.setLabelAndMnemonicFor(table);
        getPanelForm().addTable(label, new JScrollPaneBuilder(table).build(), buildButtons(table));
        
        return getPanelForm();
    }
    
    /**
     * Builds buttons to control the JfxTable.
     * @param table
     * @return
     */
    private ImmutableList<Component> buildButtons(@Nonnull final JfxTable table) {
        return FluentIterable.from(getProperty().getTableModel().getButton())
                .transform(new Function<Button, Component>() {
                    @Override
                    public Component apply(@Nonnull final Button input) {
                        return new TableButtonBuilder(table, input, getValueRepository()).build();
                    }
                }).toList();
    }
}