/**
 * Contains the GUI formatter definitions to build a PropertyPage.
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.formatter;