package com.ossnms.dcn_manager.bicnet.client.propertypage.validator;

import com.coriant.widgets.text.PValidationEvent;
import com.coriant.widgets.text.PValidationException;
import com.coriant.widgets.text.PValidationListener;
import com.ossnms.tools.jfx.JfxAddress;
import org.apache.commons.lang3.StringUtils;

public class NsapValidator implements PValidationListener {

    @Override
    public void validate(PValidationEvent event) throws PValidationException {
        try {
            final String text = event.getDocument().getText(0, event.getDocument().getLength());
            
            if (StringUtils.isNotEmpty(text)) {
                if (JfxAddress.isValidNSAP(text)) {
                    return;
                }
                throw new PValidationException("Invalid NSAP format");
            }
        } catch (final Exception e) {
            throw new PValidationException(e);
        }
    }
}