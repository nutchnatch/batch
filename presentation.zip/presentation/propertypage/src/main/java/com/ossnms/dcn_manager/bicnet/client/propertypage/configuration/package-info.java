/**
 * Contains the utilities classes to handler the property page configuration.
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.configuration;