package com.ossnms.dcn_manager.bicnet.client.propertypage.validator;

import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import com.google.common.collect.Table;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.Validator;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.ValidatorException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.Column;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.PropertyPageLabels;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nonnull;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

/**
 *  Validates the Route table model values.  
 */
public class RouteTableValidator implements Validator {

    private final Table<Integer, Column, PropertyValue> table;
    private final PropertyValue routeRowCount;

    public RouteTableValidator(@Nonnull final Pair<Table<Integer, Column, PropertyValue>, PropertyValue> component) {
        table = component.getLeft();
        routeRowCount = component.getRight();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean validate() throws ValidatorException {
        if (hasUndefinedValue()) {
            return true;
        }

        final Map<Integer, Map<Column, PropertyValue>> notEmptyRows = filterNotEmptyRows(table.rowMap());

        notEmptyValuesForGNE(notEmptyRows)
            .allRequiredValuesFilled(notEmptyRows)
            .verifyAddressDuplication(notEmptyRows)
            .addNotEmptyRowsToUpdate(notEmptyRows)
            .clearEmptyRows();

        routeRowCount.setContent(String.valueOf(notEmptyRows.size()));
        
        return true;
    }

    private boolean hasUndefinedValue() {
        return table.values()
                .stream()
                .filter(PropertyValue::isUndefined)
                .findFirst()
                .isPresent();
    }

    /**
     * When the NE is a GNE, the table must be at least one valid row.
     * 
     * @return
     * @throws ValidatorException
     */
    private RouteTableValidator notEmptyValuesForGNE(@Nonnull final Map<Integer, Map<Column, PropertyValue>> notEmptyRows)
            throws ValidatorException {
        if (notEmptyRows.values().isEmpty() && isTableEnable()) {
            throw new ValidatorException(PropertyPageLabels.ERROR_TABLE_CANNOT_BE_EMPTY.toString());
        }

        return this;
    }

    /*
     * All required value defined in property page must be not empty.
     */
    private RouteTableValidator allRequiredValuesFilled(@Nonnull final Map<Integer, Map<Column, PropertyValue>> notEmptyRows) throws ValidatorException {
        for (final Entry<Integer, Map<Column, PropertyValue>> rows : notEmptyRows.entrySet()) {
            for (final Entry<Column, PropertyValue> row : rows.getValue().entrySet()) {
                if (row.getKey().isRequired() && row.getValue().getContent().trim().isEmpty()) {
                    throw new ValidatorException(
                            PropertyPageLabels.ERROR_REQUIRED_VALUE_EMPTY.guiName().getFormatedMessage(row.getKey().getName()));
                }
            }
        }

        return this;
    }

    /*
     * Duplicated addresses are not allowed.
     */
    private RouteTableValidator verifyAddressDuplication(@Nonnull final Map<Integer, Map<Column, PropertyValue>> notEmptyRows) throws ValidatorException {
        final Set<String> addresses = new HashSet<>();

        final Optional<Column> addressColumn = getAddressColumn();
        final Optional<Column> portColumn = getPortColumn();

        for (final Entry<Integer, Map<Column, PropertyValue>> rows : notEmptyRows.entrySet()) {
            String addressValue = rows.getValue().get(addressColumn.get()).getContent();

            if (portColumn.isPresent()) {
                final String portValue = rows.getValue().get(portColumn.get()).getContent();
                addressValue = Joiner.on(":").join(addressValue, portValue);
            }

            if (!addresses.add(addressValue)) {
                throw new ValidatorException(PropertyPageLabels.ERROR_DUPLICATED_ROUTES.toString());
            }
        }
        
        addresses.clear();
        
        return this;
    }

    /*
     * Sets the row values to be include on update list.
     */
    private RouteTableValidator addNotEmptyRowsToUpdate(@Nonnull final Map<Integer, Map<Column, PropertyValue>> notEmptyRows) {
        for (final Entry<Integer, Map<Column, PropertyValue>> rows : notEmptyRows.entrySet()) {
            for (final Entry<Column, PropertyValue> row : rows.getValue().entrySet()) {
                row.getValue().setForceSendOnUpdate(true);
            }
        }
        
        return this;
    }
    
    /*
     * Clear empty rows to be not included on update list.
     */
    private void clearEmptyRows() {
        for (final Entry<Integer, Map<Column, PropertyValue>> rows : filterEmptyRows(table.rowMap()).entrySet()) {
            for (final Entry<Column, PropertyValue> row : rows.getValue().entrySet()) {
                if(ColumnId.PRIORITY != row.getKey().getId()) {
                    row.getValue().setContent("");
                    row.getValue().setForceSendOnUpdate(false);
                }
            }
        }
    }

    /*
     * The row is not empty when at least one column is not empty
     */
    private Map<Integer, Map<Column, PropertyValue>> filterNotEmptyRows(
            @Nonnull final Map<Integer, Map<Column, PropertyValue>> rowMap) {

        return Maps.filterEntries(rowMap, input -> {
            return isRowNotEmpty(input.getValue().entrySet());
        });
    }
        
    /*
     * Empty row is when required fields are empty.
     */
    private Map<Integer, Map<Column, PropertyValue>> filterEmptyRows(
            @Nonnull final Map<Integer, Map<Column, PropertyValue>> rowMap) {

        return Maps.filterEntries(rowMap, input -> !isRowNotEmpty(input.getValue().entrySet()));
    }

    /*
     * Find a Port column on table.
     */
    private Optional<Column> getPortColumn() {
        return table.columnKeySet().stream().filter(input -> input.getId() == ColumnId.PORT).findFirst();
    }

    /*
     * Find a address column on table.
     */
    private Optional<Column> getAddressColumn() {
        return table.columnKeySet().stream().filter(input -> input.getId() == ColumnId.ADDRESS).findFirst();
    }
    
    /*
     * The row is empty when at least one enable column is not empty, not is a Priority column or
     * not is a multi-selection value.
     */
    private boolean isRowNotEmpty(Set<Entry<Column, PropertyValue>> rows) {
        return rows.stream().filter(input -> input.getKey().getId() != ColumnId.PRIORITY &&
                isNotBlank(input.getValue().getContent())).findFirst().isPresent();
    }

    /*
     * The Route table is enabled When at least one row value is enabled.
     */
    private boolean isTableEnable() {
        return table.values().stream().filter(PropertyValue::isEnabled).findFirst().isPresent();
    }
}
