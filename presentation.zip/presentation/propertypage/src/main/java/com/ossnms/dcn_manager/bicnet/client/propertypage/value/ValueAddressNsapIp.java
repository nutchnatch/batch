package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.value.transform.TransformIpToNsap;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.transform.TransformNsapToIp;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.EMPTY;

public class ValueAddressNsapIp extends ValueJfxTextField {

    private static final long serialVersionUID = -2519929651748068677L;

    public ValueAddressNsapIp(@Nonnull final ValueDescriptor descriptor) {
        super(descriptor);
    }

    @Override
    @Nonnull
    public String getContent() {
        final Optional<String> nsap = TransformIpToNsap.tryTransform(getText());

        if (nsap.isPresent()) {
            return nsap.get();
        }

        return getText();
    }

    @Override
    public void setContent(@Nullable String content) {
        modifyContent(content);
        if(!isUndefined()){
            setUnmodifiedValue(getText());
        }
    }

    @Override public void modifyContent(String content) {
        if (getDescriptor().isMultipleValue(content)) {
            setUndefined(true);
        } else {
            final String address = content == null ? EMPTY : content;
            final String ipOrNsap = TransformNsapToIp.tryTransform(address).orElse(address);
            setText(ipOrNsap);
        }
    }
}
