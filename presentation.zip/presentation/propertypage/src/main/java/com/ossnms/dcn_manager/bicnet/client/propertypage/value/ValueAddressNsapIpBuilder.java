package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.validator.NsapIpValidator;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;

public final class ValueAddressNsapIpBuilder extends ValueBuilder<ValueAddressNsapIp> {
    
    public ValueAddressNsapIpBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        super(value, valueRepository);
    }

    @Override
    @Nonnull
    public ValueAddressNsapIp buildComponent() {
        final ValueAddressNsapIp nsapIp = new ValueAddressNsapIp(
                new ValueDescriptor(getValue().getId(), getValue().getAction(), getValue().getMultiselection(), getValueRepository().isDynamicEnableFieldPermitted()));
        
        setBasicComponentValues(nsapIp);

        nsapIp.addValidationListener(new NsapIpValidator());
        nsapIp.setMandatoryEntry(Boolean.valueOf(getValue().getMandatory()));
        nsapIp.setColumns(NumberUtils.toInt(getValue().getColumns()));
        
        nsapIp.setContent(buildDefaultValue());
        
        nsapIp.limitText(buildMaxLength());
        nsapIp.setValidCharacters(buildAllowedContent());
        nsapIp.setProhibitedCharacters(buildForbiddenContent());
        
        return nsapIp;
    }
}
