package com.ossnms.dcn_manager.bicnet.client.propertypage.view;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginView;
import com.ossnms.bicnet.framework.client.command.FrameworkCommand;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandHandler;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.api.view.MessageBox;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.PropertyPageLabels;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

/**
 * Command for the PropertyPage.
 */
public class PropertyPageCommand<M> extends FrameworkCommand {

    private static final Logger LOGGER = LoggerFactory.getLogger(PropertyPageView.class);
    private static final long serialVersionUID = -2677633049246273451L;
    private static final FrameworkCommandID UI_ID = new FrameworkCommandID(PropertyPageCommand.class.getName());

    private final PageDocument<M> document;
    
    private MessageBox messageBox;

    /**
     * Initialize the command.
     */
    public PropertyPageCommand(@Nonnull final PageDocument<M> document) {
        this(document, new MessageBox());
    }

    public PropertyPageCommand(@Nonnull final PageDocument<M> document, @Nonnull final MessageBox messageBox) {
        this.setCommandID(UI_ID);
        this.setPluginHelper(DcnPluginHelperSingleton.getInstance());
        this.setActionListener(new FrameworkCommandHandler(UI_ID));
        this.setComponentName(document.getPropertyPage().getTitle());

        this.document = document;
        this.messageBox = messageBox;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean execute(IManagedObject[] selectedObjects) {
        createView();
        return true;
    }

    private void createView() {
        try {
            final PropertyPageView<M> view = new PropertyPageView<>(document);

            view.setCommand(this);
            this.setView(view);

            view.setFrame(DcnPluginHelperSingleton.getInstance().createFrame(view, BiCNetPluginFrameType.MODAL));
            document.execute();
            view.repack();
            view.getFrame().showFrame();
        } catch (final PropertyValueBuilderException e) {
            LOGGER.error("Error on Property Page view builder.", e);
            messageBox.errorMessage(PropertyPageLabels.ERROR_BUILD_PROPERTIES);
            
        } catch (final Exception e) {
            LOGGER.error("Error on Property Page view builder.", e);
            messageBox.errorMessage(PropertyPageLabels.ERROR_CRITICAL);
        }
    }

    /**
     * Method Not supported, will throw UnsupportedOperationException.
     */
    @Override
    public IFrameworkCommand clone(IManagedObject[] selectedObjects) {
        throw new UnsupportedOperationException();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void bringViewToFront(@Nonnull BiCNetPluginView view) {
        ((PropertyPageView<?>) view).bringToFront();
    }
}
