package com.ossnms.dcn_manager.bicnet.client.propertypage.controller;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueFlow;

import static com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow.isInMultiselectionFlow;

public class PropertyValueFlowFactory {

    public PropertyValueFlow create(final WellKnownPropertiesAddOrModify replacer, final int totalElements) {
        if (isInMultiselectionFlow(totalElements)) {
            return new MultiSelectionPropertyValueFlow(replacer);
        }

        return new SingleSelectionPropertyValueFlow(replacer);
    }
}
