package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.google.common.collect.Iterables;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.dcn_manager.bicnet.client.api.ObjectUtils;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainProcessException;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainStatus;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainTemplate;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownPropertyNames;
import com.ossnms.dcn_manager.bicnet.client.api.state.ChannelActualStateVerification;
import com.ossnms.dcn_manager.bicnet.client.propertypage.command.PageOkButtonCommand;
import com.ossnms.dcn_manager.bicnet.client.propertypage.command.UpdatePropertyPageOkButtonCommand;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForUpdate;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PropertyValueFlowFactory;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.WellKnownPropertiesAddOrModify;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.page.PageBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.stream.StreamSupport;

import static com.google.common.collect.Iterables.toArray;
import static java.util.stream.Collectors.toList;

/**
 * Open EMs property page for Update.
 */
class CommandOpenChannelProperties extends ChainTemplate<IManagedObject[]> implements Command<Iterable<IEM>> {

    private final RepositoryManager repositoryManager;
    private final CommonServices commonServices;
    private final PropertyPagesRepository propertyPagesRepository;
    private final OpenPropertyPagePermissionChecker permissionChecker;

    CommandOpenChannelProperties(RepositoryManager repositoryManager, CommonServices commonServices,
            PropertyPagesRepository propertyPagesRepository) {
        this.repositoryManager = repositoryManager;
        this.commonServices = commonServices;
        this.propertyPagesRepository = propertyPagesRepository;
        this.permissionChecker = new OpenPropertyPagePermissionChecker(commonServices);
    }

    @Override protected ChainStatus process(@Nonnull final IManagedObject[] elements) throws ChainProcessException {
        try {
            final Iterable<IEM> ems = ObjectUtils.filterBy(elements, IEM.class);

            if (!Iterables.isEmpty(ems)) {
                this.call(ems);
                return ChainStatus.STOP;
            }

            return ChainStatus.CONTINUE;
        } catch (final Exception e) {
            throw new ChainProcessException(e);
        }
    }

    @Override public void call(@Nonnull final Iterable<IEM> elements) throws CommandException {
        final IEM emPrimary = Iterables.getFirst(elements, new EMItem());

        ChannelType channelType = commonServices.getStaticConfiguration().findChannelType(emPrimary.getEmType())
                .orElseThrow(() -> new CommandException("Channel type='{}' not supported", emPrimary.getEmType()));

        final Iterable<FullChannelData> fullChannels = StreamSupport.stream(elements.spliterator(), false)
                .map(input -> new FullChannelData(input, new ChannelInfo(input.getId()))).collect(toList());

        final PropertyValueFlow propertyValueHelper = new PropertyValueFlowFactory()
                .create(buildPropertiesReplacer(elements), Iterables.size(elements));

        try {
            final PageDocument<FullChannelData> document = new PageDocumentForUpdate<>(
                    buildSelection(elements, emPrimary), repositoryManager.getChannelRepository(), propertyValueHelper,
                    commonServices.getDcnPluginHelper().getSessionContext());

            final OpenPropertyPage<FullChannelData> delegate = new OpenPropertyPage<>(
                    ObjectUtils.join(" and ", elements), commonServices, channelType, document,
                    propertyPagesRepository);

            if (!permissionChecker.isChannelPropertiesReadOnly(toArray(elements, IEM.class))) {
                final PageOkButtonCommand command = new UpdatePropertyPageOkButtonCommand<>(fullChannels,
                        repositoryManager.getChannelRepository(), commonServices.getDcnPluginHelper().getSessionContext());
                delegate.setCommand(command);
            }

            delegate.call();
        } catch (final PropertyValueBuilderException e) {
            throw new CommandException(e);
        }
    }

    private ElementsSelection<Integer> buildSelection(final Iterable<IEM> elements, final IEM primary)
            throws CommandException, PropertyValueBuilderException {
        final Collection<IEM> secondaries = StreamSupport.stream(elements.spliterator(), false)
                .filter(input -> input.getId() != primary.getId()).collect(toList());

        final Iterable<Integer> secondariesID = secondaries.stream()
                .map(IEMId::getId)
                .collect(toList());

        Collection<ChannelType> types = new HashSet<>();
        for (final IEM em : secondaries) {
            ChannelType channelType = commonServices.getStaticConfiguration().findChannelType(em.getEmType())
                    .orElseThrow(() -> new CommandException("Channel type='{}' not supported", em.getEmType()));
            types.add(channelType);
        }

        final Collection<Map<String, String>> secondariesTemplates = new ArrayList<>(types.size());
        for (final ChannelType channelType: types) {
            final PropertyValueRepository repository = new PropertyValueRepositoryImpl(
                    new SingleSelectionPropertyValueFlow());
            new PageBuilder(propertyPagesRepository.getPropertyPage(channelType), repository).build();

            secondariesTemplates.add(repository.allSavableValues());
        }

        return new ElementsSelection<>(primary.getId()).secondariesTemplates(secondariesTemplates)
                .secondariesId(secondariesID);
    }

    private WellKnownPropertiesAddOrModify buildPropertiesReplacer(@Nonnull final Iterable<IEM> elements) {
        return result -> {
            final String active = String.valueOf(
                    StreamSupport.stream(elements.spliterator(), false).filter(ChannelActualStateVerification::isActive)
                            .findFirst().isPresent());

            result.modifyOrAdd(WellKnownPropertyNames.ACTIVE, active);
        };
    }
}