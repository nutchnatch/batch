package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Action;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class ValueDescriptor implements Serializable {

    private static final long serialVersionUID = -1041867378509148255L;    
    
    private final String id;
    private boolean forceSendOnUpdate;
    private final boolean supportMultiselection;
    private final AtomicBoolean movable;
    private final ValueChangeListener conditionListener; 
    private transient ImmutableList<Action> action;
    private final boolean supportDynamicEnableField;

    public ValueDescriptor(@Nonnull final String id, @Nonnull final List<Action> action, final String supportMultiselection, final boolean supportDynamicEnableField) {
        super();
        this.id = id;
        this.action = ImmutableList.copyOf(action);
        this.supportMultiselection = Boolean.valueOf(supportMultiselection);
        this.conditionListener = new ValueChangeListener();
        this.supportDynamicEnableField = supportDynamicEnableField;
        this.movable = new AtomicBoolean();
        this.forceSendOnUpdate = false;
    }

    /**
     * @return The Value identifier.
     */
    @Nonnull
    public String getId() {
        return id;
    }
    
    /**
     * @return True if the value must be always send on properties change use case.
     */
    @Nonnull
    public boolean forceSendOnUpdate() {
        return forceSendOnUpdate;
    }
        
    public void setForceSendOnUpdate(final boolean forceSendOnUpdate) {
        this.forceSendOnUpdate = forceSendOnUpdate;
    }

    /**
     * Verifies if the text is a multiple value.
     * 
     * @param text
     * @return
     */
    @Nonnull
    public boolean isMultipleValue(@Nullable final String text) {
        return MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN.equals(text);
    }
    
    /**
     * Verify if the required value is empty.
     * @param component
     * @param mandatory
     * @return
     */
    @Nonnull
    public boolean isMandatoryValueEmpty(@Nonnull final PropertyValue component, final boolean mandatory) {
        if (mandatory) {
            return StringUtils.isBlank(component.getContent());
        }
        
        return false;
    }
    
    /**
     * @return True if the value can be moved.
     */
    @Nonnull
    public AtomicBoolean getMovable() {
        return movable;
    }
    
    public void setMovable(final boolean movable) {
        this.movable.set(movable);
    }

    /**
     * @return All condition listeners created based on {@link #getActions()}
     */
    @Nonnull
    public ValueChangeListener getConditionListener() {
        return conditionListener;
    }
       
    /**
     * @return Get all registered actions.
     */
    @Nonnull
    public ImmutableList<Action> getActions() {
        return action;
    }
    
    public boolean supportMultiselection() {
        return supportMultiselection;
    }
    
    public boolean enabledVerify(final boolean enabled) {
        if (supportDynamicEnableField) {
            return enabled;
            
        } else if(!supportDynamicEnableField && supportMultiselection) {
            return enabled;
            
        } else {
            return false;            
        }        
    }

    private  void readObject(final ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        action = ImmutableList.of();
    }
}
