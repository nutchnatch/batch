package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Action;
import com.ossnms.tools.jfx.components.JfxIPField;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.event.ChangeListener;

public class ValueAddress extends JfxIPField implements PropertyValue {

    private static final long serialVersionUID = -2519929651748068696L;

    private final ValueDescriptor descriptor;

    public ValueAddress(@Nonnull final ValueDescriptor descriptor, final int addressType) {
        super(addressType);
        this.descriptor = descriptor;
        addDocumentListener(descriptor.getConditionListener());
    }

    @Override
    @Nonnull
    public String getId() {
        return descriptor.getId();
    }

    @Override
    @Nonnull
    public String getContent() {
        return getText();
    }

    @Override
    public void setContent(@Nullable final String content) {
        modifyContent(content);
        
        if(!isUndefined()){
            setUnmodifiedValue(getText());
        }
    }

    @Override public void modifyContent(String content) {
        if (descriptor.isMultipleValue(content)) {
            setUndefined(true);
        } else {
            setText(content);
        }
    }

    @Override
    @Nonnull
    public boolean isChanged() {
        return isValueModified();
    }

    @Override
    public void addConditionListener(@Nonnull final ChangeListener listener) {
        descriptor.getConditionListener().listening(listener);
    }

    @Override
    @Nonnull
    public ImmutableList<Action> getValueActions() {
        return descriptor.getActions();
    }

    @Override
    public void onWritable(final boolean enabled) {
        setEnabled(descriptor.enabledVerify(enabled));
    }

    @Override
    public void onCleanOnDisable(final boolean clear) {
        setText(clear ? "" : getContent());

    }

    @Override
    public void onValueFromConditionResult(final boolean conditionResult) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void onMovable(final boolean input) {
        descriptor.setMovable(input);
    }

    @Override
    public boolean isMovable() {
        return descriptor.getMovable().get();
    }

    @Override
    public boolean isMandatoryValueBlank() {
        return descriptor.isMandatoryValueEmpty(this, isMandatoryEntry());
    }

    @Override
    public boolean forceSendOnUpdate() {
        return descriptor.forceSendOnUpdate();
    }

    @Override
    public void setForceSendOnUpdate(final boolean alwaysSendOnUpdate) {
        descriptor.setForceSendOnUpdate(alwaysSendOnUpdate);
    }

    @Override
    public void fireStateChange() {
        descriptor.getConditionListener().fireStateChanged();
    }

    @Override
    public boolean supportMultiselection() {
        return descriptor.supportMultiselection();
    }

    @Override public void clearConditions() {
        descriptor.getConditionListener().clear();
    }
}