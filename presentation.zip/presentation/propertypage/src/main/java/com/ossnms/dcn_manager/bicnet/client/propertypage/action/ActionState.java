package com.ossnms.dcn_manager.bicnet.client.propertypage.action;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.ActionStateListener;

/**
 * Notifies the listeners when the Action State changes.
 */
public enum ActionState {

    /** Enable/disable the component */
    writable {
        @Override
        public void notifyChanges(ActionStateListener listener, boolean enable) {
            listener.onWritable(enable);
        }
    },

    /** Permit/Denied the value to be moved. Common used when the value is a table row item */
    movable {
        @Override
        public void notifyChanges(ActionStateListener listener, boolean move) {
            listener.onMovable(move);
        }
    },

    /** Change the value with the condition verify result */
    valueFromConditionResult {
        @Override
        public void notifyChanges(ActionStateListener listener, boolean conditionResult) {
            listener.onValueFromConditionResult(conditionResult);
        }
    },

    /** Clear the component value after change it to disable*/
    clearOnDisable {
        @Override
        public void notifyChanges(ActionStateListener listener, boolean clearValue) {
            listener.onCleanOnDisable(clearValue);
        }
    };
    
    /**
     * Notify changes to listeners.
     * @param notify
     * @param conditionResult
     */
    public abstract void notifyChanges(ActionStateListener listener, boolean conditionResult);
}
