package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.swing.SwingUtilities;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.Function;

import static com.google.common.collect.Maps.filterValues;
import static com.google.common.collect.Maps.transformValues;
import static com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN;
import static java.util.stream.Collectors.toList;

/**
 * Temporary repository to store the values of the current property page.
 * <p>
 * The life cycle begins when the propertyPage is opened and ends when the propertyPage is closed.
 */
public class PropertyValueRepositoryImpl implements PropertyValueRepository {
    private static final Logger LOGGER = LoggerFactory.getLogger(PropertyValueRepositoryImpl.class);

    private final ConcurrentMap<String, PropertyValue> values;
    private final Collection<Validator> validators;
    private final PropertyValueFlow propertyValueFlow;

    public PropertyValueRepositoryImpl(@Nonnull final PropertyValueFlow propertyValueFlow) {
        this.propertyValueFlow = propertyValueFlow;
        values = new ConcurrentHashMap<>();
        validators = new ArrayList<>();
    }

    @Override public void add(@Nonnull final PropertyValue value) {
        values.put(value.getId(), value);
    }

    @Override public void modifyOrAdd(final String key, final String value) {
        final Optional<PropertyValue> propertyValue = find(key);

        if (propertyValue.isPresent()) {
            propertyValue.get().modifyContent(value);
        } else {
            LOGGER.debug("PropertyValue not present key:{} value:{} ", key, value);
            add(new PageGlobalVariable(key, value));
        }
    }

    @Override public void addAll(final Map<String, String> properties) {
        SwingUtilities.invokeLater(() -> {
            for (final Entry<String, String> entry : properties.entrySet()) {
                final Optional<PropertyValue> propertyValue = find(entry.getKey());

                if (propertyValue.isPresent()) {
                    propertyValue.get().setContent(entry.getValue());
                    propertyValue.get().fireStateChange();
                } else {
                    add(new PageGlobalVariable(entry.getKey(), entry.getValue()));
                    LOGGER.debug("PropertyValue not present in repository key:{} value:{} ", entry.getKey(), entry.getValue());
                }
            }
        });
    }

    @Override @Nonnull public Optional<PropertyValue> find(@Nonnull final String key) {
        return Optional.ofNullable(values.get(key));
    }

    @Override @Nonnull public Collection<PropertyValue> allValues() {
        return values.values();
    }

    @Override @Nonnull public Map<String, String> allSavableValues() {
        return propertyValuesThat(value -> !(value instanceof PageGlobalVariable));
    }

    @Override public void clear() {
        values.clear();
    }

    @Override @Nonnull public Map<String, String> allChangedValuesMap() {
        return propertyValuesThat(propertyValueFlow.buildFilterForChangedValues());
    }

    @Override @Nonnull public Collection<PropertyValue> allChangedValues() {
        return values.values().stream()
                .filter(propertyValueFlow.buildFilterForChangedValues()::apply)
                .collect(toList());
    }

    @Override public boolean enableButtonOk() {
        boolean hasErrors = hasInvalidValue() || hasEmptyMandatoryValue();
        return !hasErrors && hasChangedValue();
    }

    @Override public void addValidator(final Validator validator) {
        validators.add(validator);
    }

    @Override public void validateValues() throws ValidatorException {
        for (final Validator validator : validators) {
            validator.validate();
        }
    }

    /**
     * Put all fields to read-only.
     */
    @Override public void allToReadOnly() {
        values.values().forEach(value -> {
            value.clearConditions();
            value.onWritable(false);
        });
    }

    @Override public <K> void updateRepository(final ElementsSelection<K> selection) {
        propertyValueFlow.updatePropertyValueRepository(this, selection);
    }

    @Override public boolean isDynamicEnableFieldPermitted() {
        return propertyValueFlow.isDynamicEnableFieldPermitted();
    }

    private Map<String, String> propertyValuesThat(@Nonnull final Predicate<PropertyValue> predicate) {
        return Function.<Map<String, PropertyValue>>identity()
                .andThen(map -> filterValues(map, predicate))
                .andThen(map -> transformValues(map, PropertyValue::getContent))
                .andThen(ImmutableMap::copyOf)
                .apply(values);
    }

    /**
     * Verify if the repository has invalid values.
     */
    private boolean hasInvalidValue() {
        return isPresentSuch(value -> value.isInvalidEntry() && value.isEnabled());
    }

    /**
     * Verify if the repository has empty mandatory values
     */
    private boolean hasEmptyMandatoryValue() {
        return isPresentSuch(value -> value.isMandatoryValueBlank() && value.isEnabled());
    }

    /**
     * Verify if the repository has changed values.
     */
    private boolean hasChangedValue() {
        return isPresentSuch(value ->
                value.isChanged() &&
                !value.isUndefined() &&
                !MULTIPLE_VALUES_TOKEN.equals(value.getContent()));
    }

    private boolean isPresentSuch(Predicate<PropertyValue> predicate) {
        return values.values().stream()
                .filter(predicate::apply)
                .findAny()
                .isPresent();
    }
}
