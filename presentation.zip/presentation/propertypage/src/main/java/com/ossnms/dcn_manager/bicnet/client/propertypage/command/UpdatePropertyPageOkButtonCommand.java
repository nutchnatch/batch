package com.ossnms.dcn_manager.bicnet.client.propertypage.command;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Map;

public class UpdatePropertyPageOkButtonCommand<K, V, REPO extends Repository<K, V>> implements PageOkButtonCommand {

    private final Iterable<V> elements;
    private final REPO repository;
    private final ISessionContext context;

    public UpdatePropertyPageOkButtonCommand(@Nonnull final Iterable<V> elements, @Nonnull final REPO repository, @Nonnull final ISessionContext context) {
        this.elements = elements;
        this.repository = repository;
        this.context = context;
    }

    @Override
    public void call(@Nonnull final PropertyValueRepository pageRepository) throws RepositoryException {
        final Map<String, String> properties = pageRepository.allChangedValuesMap();
        
        for (final V element : elements) {
            repository.update(context, element, properties);
        }

    }
}
