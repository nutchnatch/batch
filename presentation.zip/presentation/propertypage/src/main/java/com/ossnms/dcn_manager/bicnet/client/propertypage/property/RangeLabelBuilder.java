package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import com.ossnms.dcn_manager.core.jaxb.propertypage.RangeLabel;
import com.ossnms.tools.jfx.components.JfxLabel;
import org.apache.commons.lang3.builder.Builder;

import javax.annotation.Nonnull;
import java.awt.Dimension;

/**
 * Builder for #Property #Range.
 */
public class RangeLabelBuilder implements Builder<JfxLabel> {

    private final RangeLabel rangeLabel;

    /**
     * @param rangeLabel The #Property #Range to Build.
     */
    public RangeLabelBuilder(@Nonnull final RangeLabel rangeLabel) {
        this.rangeLabel = rangeLabel;
    }

    /**
     * Builds the JfxLabel from a PropertyPage {@link #rangeLabel}.
     */
    @Override
    @Nonnull
    public JfxLabel build() {
        final String text = rangeLabel.getContent();
        final JfxLabel jfxLabel = new JfxLabel(text);

        jfxLabel.setToolTipText(text);

        final Dimension dim = jfxLabel.getPreferredSize();
        final Dimension max = jfxLabel.getMaximumSize();

        max.height = Math.min(dim.height, max.height);
        jfxLabel.setMaximumSize(max);

        return jfxLabel;
    }
}
