/**
 * Contains Route Table column classes.
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.table.column;