package com.ossnms.dcn_manager.bicnet.client.propertypage.condition;

/**
 * Logical operator to be used on Conditions.
 */
enum ConditionLogical {
    and, or, xor;
        
    public boolean verify(boolean left, boolean right) {
        boolean condition = false;
        
        switch (this) {
            case and:
                condition = left && right;
                break;
            case or:
                condition = left || right;
                break;
            case xor:
                condition = left ^ right;
                break;
            default:
                throw new UnsupportedOperationException("Unsupported logical operator");
        }
        
        return condition;
    }
}
