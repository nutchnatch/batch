package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownEmPropertyNames;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepositorySingleton;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForUpdate;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.WellKnownPropertiesAddOrModify;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ChannelRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DefaultManageObjectValues;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DynamicIdNameFactory;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.apache.commons.lang3.tuple.ImmutablePair;

import javax.annotation.Nonnull;

/**
 * Start point to call the Duplicate EM flow.
 */
public class CommandDuplicateChannel implements Command<IManagedObject> {
    private final ChannelRepository repository;
    private final CommonServices commonServices;
    private final PropertyPagesRepository pagesRepository;

    public CommandDuplicateChannel(final ChannelRepository repository, final CommonServices commonServices) {
        this(repository, commonServices, PropertyPagesRepositorySingleton.getInstance());
    }

    protected CommandDuplicateChannel(final ChannelRepository repository, final CommonServices commonServices,
            final PropertyPagesRepository pagesRepository) {
        this.repository = repository;
        this.commonServices = commonServices;
        this.pagesRepository = pagesRepository;
    }

    @Override public void call(@Nonnull final IManagedObject channel) throws CommandException {
        try {
            int id = ((IEM) channel).getId();
            final FullChannelData modelEm = repository.get(id).get();

            ChannelType channelType = commonServices.getStaticConfiguration().findChannelType(modelEm.getChannel().getEmType())
                    .orElseThrow(() -> new CommandException("Channel type=''{}'' not supported", modelEm.getChannel().getEmType()));

            final String name = DynamicIdNameFactory.build(repository, channelType.guiLabel().orElse(channelType.getName()));
            final IEM emItem = DefaultManageObjectValues.newBasicEmItem(modelEm.getChannel().getEmType(), name,
                    modelEm.getChannel().getAssociatedMediator());

            // Helper for SingleSelection flow
            final PropertyValueFlow propertyValueHelper = new SingleSelectionPropertyValueFlow(
                    buildPropertiesReplacer(name));

            final PageDocument<FullChannelData> document = new PageDocumentForUpdate<>(
                    new ElementsSelection<>(id), repository, propertyValueHelper,
                    commonServices.getDcnPluginHelper().getSessionContext());

            // Parsed propertyPage for the corresponding ChannelType
            final Page page = pagesRepository.getPropertyPage(channelType);

            // Delegates the execution
            new OpenPropertyPageForNew<>(
                    ImmutablePair.of(new FullChannelData(emItem, new ChannelInfo(emItem.getId())), name),
                    commonServices, channelType, document, repository, page).call();
        } catch (final RepositoryException | PropertyValueBuilderException e) {
            throw new CommandException(e);
        }
    }

    private WellKnownPropertiesAddOrModify buildPropertiesReplacer(@Nonnull final String name) {
        return result -> result.modifyOrAdd(WellKnownEmPropertyNames.ID_NAME, name);
    }
}
