package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.coriant.widgets.ipfield.PIpAddressField;

import javax.annotation.Nonnull;

public enum ValueAddressType {
    IPv4(PIpAddressField.SUPPORT_IPV4), 
    IPv4Port(PIpAddressField.SUPPORT_IPV4_WITH_PORT), 
    
    IPv6(PIpAddressField.SUPPORT_IPV6),
    IPv6Port(PIpAddressField.SUPPORT_IPV6_WITH_MANDATORY_PORT),
    
    IPv6OrV4(PIpAddressField.SUPPORT_IPV4_AND_IPV6),    
    IPv6Orv4Port(PIpAddressField.SUPPORT_IPV4_AND_IPV6_WITH_MANDATORY_PORT);
    
    private final int type;
    
    private ValueAddressType(@Nonnull final int type) {
        this.type = type;
    }

    @Nonnull
    public int get() {
        return type;
    }       
}
