/**
 * Contains the condition processor to be verified by Actions.
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.condition;