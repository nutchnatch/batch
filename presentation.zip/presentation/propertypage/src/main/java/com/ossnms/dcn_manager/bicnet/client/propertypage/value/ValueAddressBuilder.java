package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;

public class ValueAddressBuilder extends ValueBuilder<ValueAddress> {

    public ValueAddressBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        super(value, valueRepository);
    }

    @Override
    @Nonnull
    public ValueAddress buildComponent() {
        final ValueAddressType addressType = ValueAddressType.valueOf(getValue().getAddressType());

        final ValueAddress jfxIPField = new ValueAddress(
                new ValueDescriptor(getValue().getId(), getValue().getAction(), getValue().getMultiselection(), getValueRepository().isDynamicEnableFieldPermitted()),
                addressType.get());

        setBasicComponentValues(jfxIPField);

        jfxIPField.setMandatoryEntry(Boolean.valueOf(getValue().getMandatory()));
        jfxIPField.setColumns((NumberUtils.toInt(getValue().getColumns())));        
        jfxIPField.setContent(buildDefaultValue());
                
        return jfxIPField;
    }
}
