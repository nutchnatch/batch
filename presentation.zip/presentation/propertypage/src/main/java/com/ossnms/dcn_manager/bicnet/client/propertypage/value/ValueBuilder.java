package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.AllowedContent;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Default;
import com.ossnms.dcn_manager.core.jaxb.propertypage.ForbiddenContent;
import com.ossnms.dcn_manager.core.jaxb.propertypage.MaxLenght;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Range;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.awt.Component;
import java.util.Collection;
import java.util.List;

import static java.lang.String.join;
import static java.lang.String.valueOf;
import static java.util.Collections.singletonList;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;
import static org.apache.commons.lang3.math.NumberUtils.toInt;

/**
 * Template to build GUI Components from a Property Value.
 *
 * @param <V> Component to build.
 */
abstract class ValueBuilder<V extends PropertyValue> {

    private static final int DEFAULT_MAX_LENGTH = 254;
    private static final int DEFAULT_HIGH = Integer.MAX_VALUE;
    private static final int DEFAULT_LOW = 0;

    private final Value value;
    private final PropertyValueRepository valueRepository;

    /**
     * @param value The Property Value.
     */
    protected ValueBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        this.value = value;
        this.valueRepository = valueRepository;
    }

    @Nonnull
    public final V build() throws PropertyValueBuilderException {
        final V component = buildComponent();
        valueRepository.add(component);
        return component;
    }

    /**
     * Template to build the PropertyValue.
     *
     * @return The PropertyValue
     */
    protected abstract V buildComponent() throws PropertyValueBuilderException;

    /**
     * @return The PropertyPage Value
     */
    @Nonnull
    public Value getValue() {
        return value;
    }


    /**
     * @return The PropertyValue Repository
     */
    @Nonnull
    public PropertyValueRepository getValueRepository() {
        return valueRepository;
    }

    /**
     * Sets the Component attributes.
     *
     * @param component GUI Component.
     * @see Component
     */
    protected void setBasicComponentValues(@Nonnull Component component) {
        component.setName(value.getGuiName());
        component.setEnabled(!Boolean.valueOf(value.getReadOnly()));
    }

    /**
     * Builds the text value based on default/current value.
     */
    @Nullable
    protected final String buildDefaultValue() {
        return ofNullable(value.getDefault())
                .map(Default::getContent)
                .orElse(null);
    }

    /**
     * Builds a Pair of Low and high values.
     */
    @Nonnull
    protected final List<Pair<Integer, Integer>> buildRanges() {
        List<Range> range = value.getRange();
        if (range.isEmpty()) {
            return singletonList(Pair.of(DEFAULT_LOW, DEFAULT_HIGH));
        }

        return range.stream()
                .map(this::buildRange)
                .collect(toList());
    }

    private Pair<Integer, Integer> buildRange(Range range) {
        return Pair.of(
                toInt(range.getLow(), DEFAULT_LOW),
                toInt(range.getHigh(), DEFAULT_HIGH));
    }


    /**
     * Sets the max text limit.
     */
    protected final int buildMaxLength() {
        return toInt(ofNullable(value.getMaxLenght())
                        .map(MaxLenght::getContent)
                        .orElse(null),
                DEFAULT_MAX_LENGTH);
    }

    /**
     * Builds the valid Characters constant.
     */
    @Nullable
    protected final String buildAllowedContent() {
        return ofNullable(value.getAllowedContent())
                .map(AllowedContent::getContent)
                .orElse(null);
    }

    /**
     * Builds the Prohibited Characters constant.
     */
    @Nullable
    protected final String buildForbiddenContent() {
        return ofNullable(value.getForbiddenContent())
                .map(ForbiddenContent::getContent)
                .orElse(null);
    }

    /**
     * Builds a tooltip based on ranges values.
     * <p>
     * Example: "1...10, 100...1000"
     */
    @Nonnull protected final String buildToolTip(Collection<Pair<Integer, Integer>> ranges) {
        return ranges.stream()
                .filter(range -> DEFAULT_HIGH != range.getRight())
                .map(range -> join("...", valueOf(range.getLeft()), valueOf(range.getRight())))
                .collect(joining(", "));
    }
}
