/**
 * Contains the FrameworkView. 
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.view;