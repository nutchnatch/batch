package com.ossnms.dcn_manager.bicnet.client.propertypage.formatter;

import com.google.common.collect.ImmutableList;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxSpinner;

import javax.annotation.Nonnull;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Build a Dynamic form for a GUI Components. 
 */
public class DynamicPanelForm extends JPanel {

    private static final long serialVersionUID = 4598244555095895169L;

    /** Spaces between row items */
    private static final int SEPARATOR = 5;
    
    private static final int ROOT_ROW = 0;
    private static final int ROOT_COLUMN = 0;
    
    /** Default value to insert Values(JfxTextField, JfxSpinner, ...) */
    private static final int VALUE_COLUMN = 1;

    /** Define the current row of the Form Panel. */
    private final AtomicInteger row = new AtomicInteger(0);
    
    private final PanelFormatter formatter = new PanelFormatter();
    
    /**
     * Initialize the GridBagLayout with dynamic size.
     */
    public DynamicPanelForm() {
        super(new GridBagLayout());
        formatter.fixedHeightAndDynamicWith(this);      
    }

    /**
     * @return Increment and get the row.
     */
    public int incrementAndGetRow() {
        return row.incrementAndGet();
    }

    /**
     * Adds the Label component to Panel.
     * @param component 
     */
    public void addLabel(@Nonnull Component component) {
        this.add(component, GridBagFormatter.labelConstraints(row.get(), ROOT_COLUMN));
    }
    
    /**
     * Adds the Table component to Panel.
     * @param label
     * @param table
     * @param buttons
     */
    public void addTable(@Nonnull Component label, @Nonnull Component table, @Nonnull ImmutableList<Component> buttons) {
        this.add(label, GridBagFormatter.labelConstraints(row.get(), ROOT_COLUMN));
        this.add(table, GridBagFormatter.tableConstraints(row.incrementAndGet(), ROOT_COLUMN));
        this.add(addButtonBox(buttons), GridBagFormatter.tableButtonConstraints(row.incrementAndGet(), ROOT_COLUMN));
        formatter.addGlue(this);
    }
    
    /**
     * Adds the TextArea to Panel.
     * @param label
     * @param area
     */
    public void addArea(@Nonnull Component label, @Nonnull Component area) {
        this.add(label, GridBagFormatter.labelConstraints(row.get(), ROOT_COLUMN));
        this.add(area, GridBagFormatter.tableConstraints(row.incrementAndGet(), ROOT_COLUMN));
        formatter.addGlue(this);
    }

    /**
     * Adds the Check box component to Panel
     * @param component
     */
    public JPanel addToggleValue(@Nonnull Component component) {
        this.add(component, GridBagFormatter.toggleConstraints(row.incrementAndGet(), ROOT_COLUMN));
        return this;
    }
    
    /**
     * Invisible separator
     * @param component
     */
    public void addSeparator() {
        this.add(Box.createHorizontalBox(), GridBagFormatter.toggleConstraints(row.incrementAndGet(), ROOT_COLUMN));
    }

    /**
     * Adds a generic Component to Panel.
     * @param component
     */
    public void addValue(@Nonnull Component component) {
        this.add(component, resolveGridBagConstraints(component));
    }

    /**
     * Adds a Component with Button to Panel.
     * @param component
     * @param button
     */
    public void addValueButton(@Nonnull Component component, @Nonnull JfxButton button) {
        final JPanel panel = new JPanel(new GridBagLayout());
        panel.add(component, GridBagFormatter.horizontalFillConstraints(ROOT_ROW, ROOT_COLUMN));
        panel.add(button, GridBagFormatter.basicConstraints(ROOT_ROW, VALUE_COLUMN));
        formatter.addGlue(panel);

        this.add(panel, GridBagFormatter.horizontalFillConstraints(row.get(), VALUE_COLUMN));
    }

    /**
     * Creates a new Horizontal Panel with a collections of Buttons.
     * 
     * The spaces between buttons are defined by {@link #SEPARATOR} constant.
     * 
     * @param buttons
     * @return
     */
    @Nonnull
    private JPanel addButtonBox(@Nonnull ImmutableList<Component> buttons) {
        final JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.LINE_AXIS));

        int column = ROOT_COLUMN;
        for (final Component component : buttons) {
            panel.add(component, GridBagFormatter.basicConstraints(ROOT_ROW, column++));
            panel.add(Box.createRigidArea(new Dimension(SEPARATOR, ROOT_ROW)), GridBagFormatter.basicConstraints(ROOT_ROW, column++));
        }

        return panel;
    }
    
    /**
     * Adds a Component with a description text to Panel.
     * 
     * Common used to add a JfxSpinner and the value Range description.
     * 
     * @param description
     * @param component
     */
    public void addComponentWithRange(@Nonnull final JfxLabel description, @Nonnull final Component component) {
        final JPanel panel = new JPanel(new GridBagLayout());
        int column = ROOT_ROW;
        
        panel.add(component, GridBagFormatter.numberConstraints(ROOT_ROW, column++));
        panel.add(Box.createRigidArea(new Dimension(SEPARATOR, ROOT_ROW)), GridBagFormatter.basicConstraints(ROOT_ROW, column++));
        panel.add(description, GridBagFormatter.basicConstraints(ROOT_ROW, column++));        
        formatter.addGlue(panel);

        this.add(panel, GridBagFormatter.numberConstraints(row.get(), VALUE_COLUMN));
    }

    /**
     * Generic formatter for Components. 
     * @param component
     * @return
     */
    @Nonnull
    private GridBagConstraints resolveGridBagConstraints(@Nonnull Component component) {
        return component instanceof JfxSpinner ? GridBagFormatter.numberConstraints(row.get(), VALUE_COLUMN)
                : GridBagFormatter.horizontalFillConstraints(row.get(), VALUE_COLUMN);
    }
}
