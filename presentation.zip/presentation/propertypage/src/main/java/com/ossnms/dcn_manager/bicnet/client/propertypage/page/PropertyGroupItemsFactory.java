package com.ossnms.dcn_manager.bicnet.client.propertypage.page;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.PanelFormatter;
import com.ossnms.dcn_manager.bicnet.client.propertypage.property.PropertyTypeFactory;
import com.ossnms.dcn_manager.bicnet.client.propertypage.radio.RadioButtonGroupBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.PropertyGroup;
import com.ossnms.dcn_manager.core.jaxb.propertypage.RadioGroup;

import javax.annotation.Nonnull;
import javax.swing.Box;
import javax.swing.JPanel;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

/**
 * Creates a property group items.
 */
public class PropertyGroupItemsFactory {

    private final PropertyGroup propertyGroup;
    private final PropertyValueRepository valueRepository;

    public PropertyGroupItemsFactory(@Nonnull final PropertyGroup propertyGroup, @Nonnull final PropertyValueRepository valueRepository) {
        super();
        this.propertyGroup = propertyGroup;
        this.valueRepository = valueRepository;
    }

    /**
     * Create all PropertyGroup items.
     * 
     * @param mainPanel The root panel of the PropertyGroup.
     * @return
     */
    public JPanel create(@Nonnull final JPanel mainPanel) throws PropertyValueBuilderException {
        
        final DynamicPanelForm formPanel = new DynamicPanelForm();
        
        mainPanel.add(formPanel);

        for (final Object object : propertyGroup.getPropertyGroupOrPropertyOrRadioGroup()) {
            if (object instanceof Property) {
                createProperty(formPanel, object);

            } else if (object instanceof PropertyGroup) {
                createInnerPropertyGroup(mainPanel, object);

            } else if (object instanceof RadioGroup) {
                createRadioButtonGroup(formPanel, object);
            }
        }

        fixPanelSize(mainPanel);

        return mainPanel;
    }

    /*
     * Fixed height with dynamic width size.
     */
    private void fixPanelSize(@Nonnull final JPanel mainPanel) {
        final PanelFormatter panelFormatter = new PanelFormatter();
        mainPanel.add(Box.createGlue());

        mainPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                panelFormatter.fixedHeightAndDynamicWith(mainPanel);
            }
        });
    }

    private void createRadioButtonGroup(@Nonnull final DynamicPanelForm formPanel, @Nonnull final Object object)  throws PropertyValueBuilderException {
        new RadioButtonGroupBuilder(formPanel, (RadioGroup) object, valueRepository).build();
    }

    private void createInnerPropertyGroup(@Nonnull final JPanel mainPanel, @Nonnull final Object object) throws PropertyValueBuilderException {
        mainPanel.add(new PropertyGroupPanelBuilder((PropertyGroup) object, valueRepository).build());
    }

    private void createProperty(@Nonnull final DynamicPanelForm formPanel, @Nonnull final Object object) throws PropertyValueBuilderException {
        PropertyTypeFactory.createOf(formPanel, (Property) object, valueRepository);
    }
}
