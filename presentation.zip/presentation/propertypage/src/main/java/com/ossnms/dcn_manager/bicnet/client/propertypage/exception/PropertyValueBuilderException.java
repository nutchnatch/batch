package com.ossnms.dcn_manager.bicnet.client.propertypage.exception;

import com.ossnms.dcn_manager.bicnet.client.api.exception.DcnClientException;

public class PropertyValueBuilderException extends DcnClientException {

    private static final long serialVersionUID = 4680913942034356572L;

    /** @see DcnClientException#Exception() */
    public PropertyValueBuilderException() {

    }

    /** @see DcnClientException#Exception(String) */
    public PropertyValueBuilderException(String message) {
        super(message);
    }

    /** @see DcnClientException#Exception(Throwable) */
    public PropertyValueBuilderException(Throwable cause) {
        super(cause);
    }

    /** @see DcnClientException#Exception(String,Throwable) */
    public PropertyValueBuilderException(String message, Throwable cause) {
        super(message, cause);
    }
    
    /**
     * @see DcnClientException
     */
    public PropertyValueBuilderException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    /** @see Exception#Exception(String,Throwable,boolean,boolean) */
    public PropertyValueBuilderException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
