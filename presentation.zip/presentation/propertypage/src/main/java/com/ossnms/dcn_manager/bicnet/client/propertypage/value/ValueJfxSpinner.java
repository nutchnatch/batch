package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Action;
import com.ossnms.tools.jfx.components.JfxSpinner;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.JComponent;
import javax.swing.SpinnerModel;
import javax.swing.event.ChangeListener;
import java.util.Objects;

import static com.coriant.widgets.ClientProperties.INVALID;
import static com.coriant.widgets.util.ClientPropertyUtil.booleanValue;

class ValueJfxSpinner extends JfxSpinner implements PropertyValue {

    private static final long serialVersionUID = -6945188980505806557L;

    private final ValueDescriptor descriptor;

    ValueJfxSpinner(@Nonnull final ValueDescriptor descriptor, @Nonnull final SpinnerModel model) {
        super(model);

        this.descriptor = descriptor;
        addFocusListener(descriptor.getConditionListener());
        addChangeListener(descriptor.getConditionListener());
    }

    @Override @Nonnull public String getId() {
        return descriptor.getId();
    }

    @Override @Nonnull public String getContent() {
        return Objects.toString(getValue(), "");
    }

    @Override public void setContent(@Nullable final String content) {
        modifyContent(content);
        setUnmodifiedValue(isUndefined() ? content : getValue());
    }

    @Override public void modifyContent(String content) {
        if (descriptor.isMultipleValue(content)) {
            setUndefined(true);
        } else {
            setValue(content != null ? NumberUtils.toInt(content) : getValue());
        }
    }

    @Override public boolean isChanged() {
        return isValueModified();
    }

    @Override public void addConditionListener(@Nonnull final ChangeListener listener) {
        descriptor.getConditionListener().listening(listener);
    }

    @Override @Nonnull public ImmutableList<Action> getValueActions() {
        return descriptor.getActions();
    }

    @Override public void onWritable(final boolean enabled) {
        setEnabled(descriptor.enabledVerify(enabled));
    }

    @Override public void onCleanOnDisable(final boolean clear) {
        throw new UnsupportedOperationException();
    }

    @Override public void onValueFromConditionResult(final boolean conditionResult) {
        throw new UnsupportedOperationException();
    }

    @Override public void onMovable(final boolean input) {
        descriptor.setMovable(input);
    }

    @Override public boolean isMovable() {
        return descriptor.getMovable().get();
    }

    @Override public boolean isMandatoryValueBlank() {
        return descriptor.isMandatoryValueEmpty(this, isMandatoryEntry() && !isUndefined());
    }

    @Override public boolean forceSendOnUpdate() {
        return descriptor.forceSendOnUpdate();
    }

    @Override public void setForceSendOnUpdate(final boolean alwaysSendOnUpdate) {
        descriptor.setForceSendOnUpdate(alwaysSendOnUpdate);
    }

    @Override public boolean isInvalidEntry() {
        return booleanValue((JComponent) getTextComponent(), INVALID);
    }

    @Override public void fireStateChange() {
        descriptor.getConditionListener().fireStateChanged();
    }

    @Override public boolean supportMultiselection() {
        return descriptor.supportMultiselection();
    }

    /** {@inheritDoc} */
    @Override public void clearConditions() {
        descriptor.getConditionListener().clear();
    }
}
