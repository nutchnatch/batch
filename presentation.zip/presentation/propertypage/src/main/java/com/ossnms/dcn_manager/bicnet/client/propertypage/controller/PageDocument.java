package com.ossnms.dcn_manager.bicnet.client.propertypage.controller;

import com.ossnms.dcn_manager.bicnet.client.propertypage.model.PropertyPage;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;

/**
 * Handler to adapt the FrameworkDocument.  
 */
public interface PageDocument<M> {

    /**
     * Execute the Document Job.
     */
    void execute();

    /**
     * @return Gets the Value Repository.
     */
    PropertyValueRepository getValueRepository();
    
    /**
     * @return Gets the PropertyPage Model.
     */
    PropertyPage getPropertyPage();
    
    /**
     * @return Sets the PropertyPage Model.
     */
    PageDocument<M> propertyPage(PropertyPage propertyPage);
}
