package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepositorySingleton;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForNewObject;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.StaticConfigurationValue;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeType;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DefaultManageObjectValues;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DynamicIdNameFactory;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.CONTAINER_ID;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.ID_NAME;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.NE_SYSTEM_ASSIGNMENT_NAME;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.NE_TYPE_LABEL;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.PropertyPageLabels.NO_ASSOCIATION;

/**
 * Start point to call the New NE flow.
 */
public class CommandNewNe implements Command<Integer> {
    private static final Logger LOGGER = LoggerFactory.getLogger(CommandNewNe.class);

    private final RepositoryManager repository;
    private final CommonServices commonServices;
    private final PropertyPagesRepository pagesRepository;
    private final String type;
    private final Optional<Integer> systemId;
    private final Optional<Integer> containerId;

    public CommandNewNe(final RepositoryManager repository, final CommonServices commonServices, final String type,
                        Optional<Integer> systemId, Optional<Integer> containerId) {
        this(repository, commonServices, PropertyPagesRepositorySingleton.getInstance(), type, systemId, containerId);
    }

    protected CommandNewNe(final RepositoryManager repository, final CommonServices commonServices,
                           final PropertyPagesRepository pagesRepository, final String type, 
                           final Optional<Integer> systemId, final Optional<Integer> containerId) {
        this.repository = repository;
        this.commonServices = commonServices;
        this.pagesRepository = pagesRepository;
        this.type = type;
        this.systemId = systemId;
        this.containerId = containerId;
    }

    @Override
    public void call(@Nonnull final Integer channelId) throws CommandException {
        try {
            NeType neType = commonServices.getStaticConfiguration().findNeType(type)
                    .orElseThrow(() -> new CommandException("Ne type=''{}'' not supported", type));

            final FullNeData dummyFullNeData = newDummyFullNeData(channelId);
            final PageDocument<FullNeData> document = buildFrameworkDocument(dummyFullNeData);
            final Page unmarshalledPropertyPage = pagesRepository.getPropertyPage(neType);

            // Delegates the execution
            new OpenPropertyPageForNew<>(
                    Pair.of(dummyFullNeData, dummyFullNeData.getNe().getIdName()),
                    commonServices,
                    neType,
                    document, repository.getNeRepository(), unmarshalledPropertyPage).call();
        } catch (final RepositoryException | PropertyValueBuilderException e) {
            throw new CommandException(e);
        }
    }

    PageDocument<FullNeData> buildFrameworkDocument(final FullNeData dummyFullNeData) {
        return new PageDocumentForNewObject<FullNeData>().addOrModify(valueRepository -> {
            valueRepository.modifyOrAdd(ID_NAME, dummyFullNeData.getNe().getIdName());
            valueRepository.modifyOrAdd(NE_TYPE_LABEL, type);

            systemId.ifPresent(id -> valueRepository.modifyOrAdd(NE_SYSTEM_ASSIGNMENT_NAME, fetchSystemName(id)));

            containerId.map(String::valueOf).ifPresent(id ->
                valueRepository.add(new StaticConfigurationValue(CONTAINER_ID, id))
            );
        });
    }

    private FullNeData newDummyFullNeData(final int channelId) throws RepositoryException {
        final String dummyName = DynamicIdNameFactory.build(repository.getNeRepository(), type);
        return DefaultManageObjectValues.newDummyFullNeData(type, dummyName, channelId, systemId);
    }

    private String fetchSystemName(final int systemId) {
        try {
            return repository.getSystemContainerRepository()
                    .get(systemId).map(ISystemContainer::getIdName)
                    .orElse(NO_ASSOCIATION.toString());
        } catch (RepositoryException e) {
            LOGGER.error("Error to fetch System container=" + systemId, e);
        }
        return NO_ASSOCIATION.toString();
    }
}
