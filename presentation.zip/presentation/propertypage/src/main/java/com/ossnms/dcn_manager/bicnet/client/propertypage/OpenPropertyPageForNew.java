package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.dcn_manager.bicnet.client.propertypage.command.SaveNewPropertyPageOkButtonCommand;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.PropertyPage;
import com.ossnms.dcn_manager.bicnet.client.propertypage.view.PropertyPageCommand;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.Type;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.help.DefaultHelpIds;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.PropertyPageLabels;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nonnull;

/**
 * Start point to call the "Open property page for creation" flow.
 */
class OpenPropertyPageForNew<KEY, ELEMENT> {

    private final Repository<KEY, ELEMENT> repository;
    private final ELEMENT element;
    private final Type type;
    private final PageDocument<ELEMENT> document;
    private final Page page;
    private final String name;
    private final CommonServices commonServices;

    public OpenPropertyPageForNew(@Nonnull final Pair<ELEMENT, String> element, final CommonServices commonServices,
            final Type type, final PageDocument<ELEMENT> document, final Repository<KEY, ELEMENT> repository,
            final Page page) {
        this.element = element.getLeft();
        this.name = element.getRight();
        this.commonServices = commonServices;
        this.type = type;
        this.document = document;
        this.repository = repository;
        this.page = page;
    }
    
    /**
     * Delegate the execution for the {@link PropertyPageCommand} command.
     *  
     * The result of the {@link PropertyPageCommand} execution will be the creation of the Property Page View.
     */
    public void call() {
        final PropertyPage propertyPage = new PropertyPage(
                name,
                NumberUtils.toInt(type.getHelpID(),
                DefaultHelpIds.GENERAL_PROPERTY_PAGE.getValue()),
                new SaveNewPropertyPageOkButtonCommand<>(element, repository,
                        commonServices.getDcnPluginHelper().getSessionContext()),
                page);

        document.propertyPage(propertyPage);

        new PropertyPageCommand<>(document).execute(null);
    }
}
