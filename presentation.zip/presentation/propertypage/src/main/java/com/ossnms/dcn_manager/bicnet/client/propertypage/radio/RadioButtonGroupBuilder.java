package com.ossnms.dcn_manager.bicnet.client.propertypage.radio;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueTypeFactory;
import com.ossnms.dcn_manager.core.jaxb.propertypage.RadioGroup;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import com.ossnms.tools.jfx.components.JfxRadioButton;

import javax.annotation.Nonnull;
import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import java.awt.Component;

/**
 * Builds the Radio button group panel. 
 */
public class RadioButtonGroupBuilder {

    private final RadioGroup radioGroup;
    private final DynamicPanelForm panelForm;
    private final PropertyValueRepository valueRepository;

    public RadioButtonGroupBuilder(@Nonnull final DynamicPanelForm panelForm,  @Nonnull final RadioGroup radioGroup, @Nonnull final PropertyValueRepository valueRepository) {
        super();
        this.radioGroup = radioGroup;
        this.panelForm = panelForm;
        this.valueRepository = valueRepository;
    }

    /**
     * Builds a JPanel with a collection of radio buttons.
     */
    public JPanel build() throws PropertyValueBuilderException {
        final ButtonGroup buttonGroup = new ButtonGroup();
        
        for (final Value value : radioGroup.getValue()) {
            final Component radioButton = ValueTypeFactory.createOf(value, valueRepository);
            
            buttonGroup.add((JfxRadioButton)radioButton);
            panelForm.addToggleValue(radioButton);
        }
                
        panelForm.addSeparator();
                
        return panelForm;
    }
}
