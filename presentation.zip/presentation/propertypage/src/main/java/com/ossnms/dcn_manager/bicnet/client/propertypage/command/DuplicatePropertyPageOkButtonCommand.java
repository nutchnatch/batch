package com.ossnms.dcn_manager.bicnet.client.propertypage.command;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

import javax.annotation.Nonnull;

public class DuplicatePropertyPageOkButtonCommand<K, V, REPO extends Repository<K, V>> implements PageOkButtonCommand {

    private final V element;
    private final REPO repository;
    private final ISessionContext context;

    public DuplicatePropertyPageOkButtonCommand(@Nonnull final V element, @Nonnull final REPO repository, @Nonnull final ISessionContext context) {
        this.element = element;
        this.repository = repository;
        this.context = context;
    }
    
    @Override
    public void call(@Nonnull PropertyValueRepository pageRepository) throws RepositoryException {
        repository.duplicate(context, element, pageRepository.allSavableValues());
    }
}
