package com.ossnms.dcn_manager.bicnet.client.propertypage.loader;

import com.google.common.base.Joiner;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.lang.reflect.Constructor;

/**
 * Dynamic Proxy for Loaders.
 */
public final class LoaderProxy {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(LoaderProxy.class);
    private static final String PACKAGE = LoaderProxy.class.getPackage().getName();
       
    private LoaderProxy() {
    }
    
    /**
     *  * Constructs a new instance for {@link Loader} interface implementations.
     * 
     * @param className classes must be at the same package then the ValidatorProxy.
     * @return
     */
    @Nonnull
    public static <E> E newInstanceOf(@Nonnull final String className) throws PropertyValueBuilderException {
        try {
            @SuppressWarnings("unchecked")
            final Class<E> clazz = (Class<E>) Class.forName(Joiner.on('.').join(PACKAGE, className));
            final Constructor<E> constructor = clazz.getDeclaredConstructor();
            return constructor.newInstance();
        } catch (final Exception e) {
            LOGGER.error("Error to create new instance for class={}", className);
            throw new PropertyValueBuilderException(e);
        }
    }
}
