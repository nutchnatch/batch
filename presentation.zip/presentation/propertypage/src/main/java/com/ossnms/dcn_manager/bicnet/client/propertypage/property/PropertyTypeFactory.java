package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import org.apache.commons.lang3.tuple.ImmutableTriple;
import org.apache.commons.lang3.tuple.Triple;

import javax.annotation.Nonnull;
import java.awt.Component;

/**
 * Creates a Property regarding a PropertyType.
 */
public enum PropertyTypeFactory {
    
    /** Creates a Panel for "form" style components */
    simple {
        @Override
        Component of(@Nonnull final Triple<DynamicPanelForm, Property, PropertyValueRepository> property) throws PropertyValueBuilderException {
            return new PropertySimpleBuilder(property.getLeft(), property.getMiddle(), property.getRight()).build();
        }
    }, 
    
    /** Creates a Panel for Tables */
    table {
        @Override
        Component of(@Nonnull final Triple<DynamicPanelForm, Property, PropertyValueRepository> property) throws PropertyValueBuilderException {
            return new PropertyTableBuilder(property.getLeft(), property.getMiddle(), property.getRight()).build();
        }
    }, 
    
    /** Creates a Panel for TextArea */
    area {
        @Override
        Component of(@Nonnull final Triple<DynamicPanelForm, Property, PropertyValueRepository> property) throws PropertyValueBuilderException {
            return new PropertyAreaBuilder(property.getLeft(), property.getMiddle(), property.getRight()).build();
        }
    }, 
    
    /** Creates a Panel for Toggle components*/
    toggle {
        @Override
        Component of(@Nonnull final Triple<DynamicPanelForm, Property, PropertyValueRepository> property) throws PropertyValueBuilderException {
            return new PropertyToggleBuilder(property.getLeft(), property.getMiddle(), property.getRight()).build();
        }
    };
    
    /**
     * Template for Property Components creation.
     * @param property
     * @return
     */
    abstract Component of(@Nonnull final Triple<DynamicPanelForm, Property, PropertyValueRepository> property)  throws PropertyValueBuilderException;
    
    /**
     * Creates a Property Panel regarding a PropertyType.
     * 
     * @param panelForm
     * @param property
     * @param valueRepository
     * @return
     */
    public static Component createOf(@Nonnull final DynamicPanelForm panelForm, @Nonnull final Property property, @Nonnull final PropertyValueRepository valueRepository)  throws PropertyValueBuilderException {
        final PropertyTypeFactory create = PropertyTypeFactory.valueOf(property.getType());
        
        final Component component = create.of(ImmutableTriple.of(panelForm, property, valueRepository));
        panelForm.incrementAndGetRow();
        
        return component;
    }
}
