/**
 * Contains the Dynamic construction of the #Property component.
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.property;