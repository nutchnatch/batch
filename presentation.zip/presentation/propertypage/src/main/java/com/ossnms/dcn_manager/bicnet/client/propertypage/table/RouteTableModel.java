package com.ossnms.dcn_manager.bicnet.client.propertypage.table;

import com.coriant.widgets.text.PTextField;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Table;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.Column;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.table.AbstractTableModel;

public class RouteTableModel extends AbstractTableModel {

    private static final long serialVersionUID = 828028518669243257L;
    
    private final ImmutableList<Column> tableHeader;
    private final Table<Integer, Column, PropertyValue> tableData;

    public RouteTableModel(@Nonnull final Table<Integer, Column, PropertyValue> tableData, @Nonnull final ImmutableList<Column> tableHeader) {
        this.tableData = tableData;
        this.tableHeader = tableHeader;
    }

    @Override
    public void setValueAt(@Nullable Object value, int row, int column) {
        tableData.get(row, tableHeader.get(column)).setContent(value != null ? value.toString() : null);        
    }
    
    @Override
    public boolean isCellEditable(int row, int column) {
        return tableData.get(row, tableHeader.get(column)).isEnabled();
    }
    
    @Override
    public Object getValueAt(int row, int column) {
        return ((PTextField)tableData.get(row, tableHeader.get(column))).getText();
    }
    
    public PTextField getPropertyValueAt(int row, int column) {
        return (PTextField) tableData.get(row, tableHeader.get(column));
    }
    
    @Override
    public int getRowCount() {
        return tableData.rowKeySet().size();
    }

    @Override
    public int getColumnCount() {
        return tableHeader.size();
    }

    @Override
    @Nonnull
    public String getColumnName(int column) {
        return tableHeader.get(column).getName();
    }
        
    public int getColumnsLenght() {
        int lenght = 0;
        for(final Column column : tableHeader) {
            lenght += column.getWidth();
        }        
        return lenght;
    }

    public ImmutableList<Column> getTableHeader() {
        return tableHeader;
    }

    public Table<Integer, Column, PropertyValue> getTableData() {
        return tableData;
    }
}
