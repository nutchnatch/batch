package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.google.common.collect.Iterables;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.dcn_manager.bicnet.client.api.ObjectUtils;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainProcessException;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainStatus;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainTemplate;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownMediatorPropertyNames;
import com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownPropertyNames;
import com.ossnms.dcn_manager.bicnet.client.api.state.MediatorActualStateVerification;
import com.ossnms.dcn_manager.bicnet.client.propertypage.command.PageOkButtonCommand;
import com.ossnms.dcn_manager.bicnet.client.propertypage.command.UpdatePropertyPageOkButtonCommand;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForUpdate;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PropertyValueFlowFactory;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.WellKnownPropertiesAddOrModify;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.page.PageBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PageGlobalVariable;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.google.common.collect.Iterables.toArray;

/**
 * Open Mediators property page for Update.
 */
class CommandOpenMediatorProperties extends ChainTemplate<IManagedObject[]> implements Command<Iterable<IMediator>> {

    private final RepositoryManager repositoryManager;
    private final CommonServices commonServices;
    private final PropertyPagesRepository propertyPagesRepository;
    private final OpenPropertyPagePermissionChecker permissionChecker;

    CommandOpenMediatorProperties(RepositoryManager repositoryManager, CommonServices commonServices,
            PropertyPagesRepository propertyPagesRepository) {
        this.repositoryManager = repositoryManager;
        this.commonServices = commonServices;
        this.propertyPagesRepository = propertyPagesRepository;
        this.permissionChecker = new OpenPropertyPagePermissionChecker(commonServices);
    }

    @Override protected ChainStatus process(@Nonnull final IManagedObject[] elements) throws ChainProcessException {
        try {
            final Iterable<IMediator> mediators = ObjectUtils.filterBy(elements, IMediator.class);

            if (!Iterables.isEmpty(mediators)) {
                call(mediators);
                return ChainStatus.STOP;
            }

            return ChainStatus.CONTINUE;
        } catch (final Exception e) {
            throw new ChainProcessException(e);
        }
    }

    @Override public void call(final Iterable<IMediator> mediators) throws CommandException {
        final IMediator mediatorPrimary = Iterables.getFirst(mediators, new MediatorItem());

        MediatorType mediatorType = commonServices.getStaticConfiguration().findMediatorType(mediatorPrimary.getMediatorType().name())
                .orElseThrow(() -> new CommandException("Mediator type='{}' not supported", mediatorPrimary.getMediatorType().name()));

        final Iterable<FullMediatorData> fullMediators = StreamSupport.stream(mediators.spliterator(), false)
                .map(input -> new FullMediatorData(input, new MediatorInfo(input.getId())))
                .collect(Collectors.toList());


        final PropertyValueFlow propertyValueFlow = new PropertyValueFlowFactory()
                .create(buildPropertiesReplacer(mediators), Iterables.size(mediators));

        try {
            final PageDocument<FullMediatorData> document = new PageDocumentForUpdate<>(
                    buildSelection(mediators, mediatorPrimary), repositoryManager.getMediatorRepository(),
                    propertyValueFlow, commonServices.getDcnPluginHelper().getSessionContext());

            buildConfiguration(document.getValueRepository());

            final OpenPropertyPage<FullMediatorData> delegate = new OpenPropertyPage<>(
                    ObjectUtils.join(" and ", mediators), commonServices, mediatorType, document,
                    propertyPagesRepository);

            if (!permissionChecker.isMediatorPropertiesReadOnly(toArray(mediators, IMediator.class))) {
                final PageOkButtonCommand command = new UpdatePropertyPageOkButtonCommand<>(
                        fullMediators, repositoryManager.getMediatorRepository(), commonServices.getDcnPluginHelper().getSessionContext());
                delegate.setCommand(command);
            }

            delegate.call();

        } catch (final PropertyValueBuilderException e) {
            throw new CommandException(e);
        }
    }

    private ElementsSelection<Integer> buildSelection(final Iterable<IMediator> elements, final IMediator primary)
            throws CommandException, PropertyValueBuilderException {
        final Collection<IMediator> secondaries = StreamSupport.stream(elements.spliterator(), false)
                .filter(input -> input.getId() != primary.getId()).collect(Collectors.toList());

        final Iterable<Integer> secondariesID = secondaries.stream()
                .map(IMediatorId::getId).collect(Collectors.toList());

        final Collection<MediatorType> types = new HashSet<>();
        for (final IMediator mediator : secondaries) {
            MediatorType mediatorType = commonServices.getStaticConfiguration().findMediatorType(mediator.getMediatorType().name())
                    .orElseThrow(() -> new CommandException("Mediator type='{}' not supported", mediator.getMediatorType()));
            types.add(mediatorType);
        }
        
        final Collection<Map<String, String>> secondariesTemplates = new ArrayList<>(types.size());
        for (final MediatorType mediatorType : types) {
            final PropertyValueRepository repository = new PropertyValueRepositoryImpl(
                    new SingleSelectionPropertyValueFlow());
            new PageBuilder(propertyPagesRepository.getPropertyPage(mediatorType), repository).build();

            secondariesTemplates.add(repository.allSavableValues());
        }

        return new ElementsSelection<>(primary.getId()).secondariesTemplates(secondariesTemplates)
                .secondariesId(secondariesID);
    }

    private PropertyValueRepository buildConfiguration(PropertyValueRepository valueRepository) {
        boolean nodeManagerSelected = repositoryManager.getConfigurationRepository().isNodeManagerSelected();
        PageGlobalVariable pageGlobalVariable = new PageGlobalVariable(
                WellKnownMediatorPropertyNames.NODE_MANAGER_SELECTED, Boolean.toString(nodeManagerSelected));

        valueRepository.add(pageGlobalVariable);

        return valueRepository;
    }

    private WellKnownPropertiesAddOrModify buildPropertiesReplacer(@Nonnull final Iterable<IMediator> elements) {
        return result -> {
            final String active = String
                    .valueOf(StreamSupport.stream(elements.spliterator(), false)
                            .filter(MediatorActualStateVerification::isActive).findFirst()
                            .isPresent());
            result.modifyOrAdd(WellKnownPropertyNames.ACTIVE, active);
        };
    }
}