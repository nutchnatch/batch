package com.ossnms.dcn_manager.bicnet.client.propertypage.controller;


import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.PropertyPage;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;

import javax.annotation.Nonnull;
import javax.swing.SwingUtilities;

import static com.ossnms.dcn_manager.bicnet.client.propertypage.controller.WellKnownPropertiesAddOrModify.EMPTY;

/**
 * Document to manage the PropertyPage model.
 */
public class PageDocumentForNewObject<M> extends FrameworkDocument implements PageDocument<M> {

    private PropertyPage propertyPage;
    private final PropertyValueRepository repository;
    
    private WellKnownPropertiesAddOrModify addOrModifyValues = EMPTY;

    public PageDocumentForNewObject() {
        super(DcnPluginHelperSingleton.getInstance());

        repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
    }

    public PageDocumentForNewObject<M> addOrModify(@Nonnull final WellKnownPropertiesAddOrModify repositoryConsumer) {
        addOrModifyValues = repositoryConsumer;
        return this;
    }

    @Override
    public void execute() {
        SwingUtilities.invokeLater(() -> {
            addOrModifyValues.accept(repository);
            fireUpdateData();
        });
    }

    @Override
    public PageDocument<M> propertyPage(@Nonnull final PropertyPage propertyPage) {
        this.propertyPage = propertyPage;
        return this;
    }
    
    @Override
    public void setResult(final IFrameworkJob job, final Object result) {
    }
   
    @Override
    public final Object getObject(final Object key) {
        return repository;
    }

    @Override
    public PropertyValueRepository getValueRepository() {
        return repository;
    }

    @Override
    public PropertyPage getPropertyPage() {
        return propertyPage;
    }
    
    private void fireUpdateData() {
        updateData(null);
    }
}
