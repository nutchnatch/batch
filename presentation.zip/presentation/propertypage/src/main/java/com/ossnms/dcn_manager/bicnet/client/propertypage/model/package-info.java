/**
 * Contains the PropertyPage Model.
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.model;