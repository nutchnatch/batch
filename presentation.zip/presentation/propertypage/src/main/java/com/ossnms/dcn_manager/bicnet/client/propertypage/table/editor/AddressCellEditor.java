package com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor;

import com.coriant.widgets.ClientProperties;
import com.coriant.widgets.text.PTextField;

import javax.annotation.Nonnull;
import javax.swing.DefaultCellEditor;
import javax.swing.InputVerifier;
import javax.swing.JComponent;
import java.io.IOException;
import java.io.ObjectInputStream;

public class AddressCellEditor extends DefaultCellEditor {
    private static final long serialVersionUID = 8514868542057948483L;

    private transient InputVerifier verifier;

    public AddressCellEditor(@Nonnull PTextField component) {
        super(component);
        this.verifier = new AddressInputVerifier();
        getComponent().setInputVerifier(verifier);
    }

    @Override
    public boolean stopCellEditing() {
        if (!verifier.shouldYieldFocus(getComponent())) {
            return false;
        }
        return super.stopCellEditing();
    }

    @Override
    public PTextField getComponent() {
        return (PTextField) super.getComponent();
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        this.verifier = new AddressInputVerifier();
        getComponent().setInputVerifier(verifier);
    }
    
    private static class AddressInputVerifier extends InputVerifier {
        @Override
        public boolean verify(@Nonnull final JComponent input) {
            final PTextField field = (PTextField) input;
            final String text = field.getText();
            
            return text.isEmpty() || !field.isInvalidEntry();
        }

        /**
         * @return Always return true for not lock field edition
         */
        @Override
        public boolean shouldYieldFocus(@Nonnull final JComponent input) {
            final PTextField field = (PTextField) input;
            
            final boolean valid = verify(field);

            if (!valid) {
                field.setBackground(CellColor.ERROR.color());
                field.setForeground(CellColor.TEXT.color());
                field.putClientProperty(ClientProperties.INVALID, true);
            } else {
                field.setBackground(CellColor.DEFAULT.color());
                field.setForeground(CellColor.TEXT.color());
                field.putClientProperty(ClientProperties.INVALID, false);
            }

            return true;
        }
    }
}