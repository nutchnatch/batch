package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import static org.apache.commons.lang3.math.NumberUtils.toInt;

import java.util.List;

import javax.annotation.Nonnull;
import javax.swing.SpinnerModel;

import org.apache.commons.lang3.tuple.Pair;

import com.coriant.widgets.spinner.SpinnerIntegerRangesModel;
import com.ossnms.bicnet.util.ApplicationProperties;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;

public class ValueStartupLimitBuilder extends ValueBuilder<ValueJfxSpinner> {

    private static final int DEFAULT_STEP_SIZE = 1;
    private static final String PROPERTY_HW_CONFIGURATION = "configuration.type";
    private static final String PROPERTIES_FILE_NAME = "/dcnManager.properties";
    private static final String SMALL_CONFIGURATION = "SMALL";
    private static final String DEFAULT_VALUE_FOR_SMALL_CONFIGURATION = "5";
    
    private final ApplicationProperties applicationProperties;

    public ValueStartupLimitBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        super(value, valueRepository);
        applicationProperties = ApplicationProperties.getInstance(PROPERTIES_FILE_NAME);
    }

    @Override @Nonnull protected ValueJfxSpinner buildComponent() {
        final List<Pair<Integer, Integer>> ranges = buildRanges();
        final String defaultValue = getDefaultValue();
        int min = ranges.isEmpty() ? 0 : ranges.get(0).getLeft();
        final int valueInt = toInt(defaultValue, min);

        final ValueJfxSpinner jfxSpinner = new ValueJfxSpinner(
                new ValueDescriptor(
                        getValue().getId(), getValue().getAction(), getValue().getMultiselection(),
                        getValueRepository().isDynamicEnableFieldPermitted()),
                buildSpinnerModel(valueInt, ranges));

        setBasicComponentValues(jfxSpinner);

        jfxSpinner.setToolTipText(buildToolTip(ranges));
        jfxSpinner.setMandatoryEntry(true);
        jfxSpinner.setContent(defaultValue);

        return jfxSpinner;
    }

    /**
     * Build model from LAF API.
     */
    private SpinnerModel buildSpinnerModel(final int value, @Nonnull final List<Pair<Integer, Integer>> rangesList) {
        int[][] ranges = rangesList.stream()
                .map(pair -> new int[]{pair.getLeft(), pair.getRight()})
                .toArray(int[][]::new);
        
        return new SpinnerIntegerRangesModel(value, ranges, DEFAULT_STEP_SIZE);
    }
    
    /**
     * Get hardware configuration from dcnManager.properties file
     * @return Hardware configuration installed
     */
    private String getHwConfiguration(){
        return applicationProperties.getProperty(PROPERTY_HW_CONFIGURATION);
    }
    
    /**
     * Set default value to 5 if SMALL configuration is installed
     * @return default value for scaled startup limit
     */
    private String getDefaultValue(){
        if(getHwConfiguration().equals(SMALL_CONFIGURATION)){
            return DEFAULT_VALUE_FOR_SMALL_CONFIGURATION;
        }
        return buildDefaultValue();
    }
}
