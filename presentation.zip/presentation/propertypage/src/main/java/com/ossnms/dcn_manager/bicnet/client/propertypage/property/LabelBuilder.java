package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import com.ossnms.dcn_manager.core.jaxb.propertypage.Label;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.components.JfxLabel;
import org.apache.commons.lang3.builder.Builder;

import javax.annotation.Nonnull;
import java.awt.Dimension;

/**
 * Builder for #Property #Label.
 */
public class LabelBuilder implements Builder<JfxLabel>{
    
    private final Label label;
    
    /**
     * @param label The PropertyLabel to Build.
     */
    public LabelBuilder(@Nonnull final Label label) {
        this.label = label;
    }

    /**
     * Builds the JfxLabel from a PropertyPage {@link #label}.
     */
    @Override
    @Nonnull
    public JfxLabel build() {
        final JfxText labelText = new JfxText(label.getContent());
        final JfxLabel jfxLabel = new JfxLabel(labelText);

        jfxLabel.setToolTipText(labelText.toString());

        final Dimension dim = jfxLabel.getPreferredSize();
        final Dimension max = jfxLabel.getMaximumSize();

        max.height = Math.min(dim.height, max.height);
        jfxLabel.setMaximumSize(max);

        return jfxLabel;
    }
}