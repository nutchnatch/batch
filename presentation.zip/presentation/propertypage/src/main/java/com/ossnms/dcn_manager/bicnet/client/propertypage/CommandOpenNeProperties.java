package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.google.common.base.Strings;
import com.google.common.collect.Iterables;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.api.ObjectUtils;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainProcessException;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainStatus;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainTemplate;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.command.PageOkButtonCommand;
import com.ossnms.dcn_manager.bicnet.client.propertypage.command.UpdatePropertyPageOkButtonCommand;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForUpdate;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PropertyValueFlowFactory;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.WellKnownPropertiesAddOrModify;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.page.PageBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeType;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.google.common.collect.Iterables.getFirst;
import static com.google.common.collect.Iterables.toArray;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.NE_LOCATION;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.NE_SYSTEM_ASSIGNMENT_NAME;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.NE_TYPE_LABEL;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownPropertyNames.ACTIVE;
import static com.ossnms.dcn_manager.bicnet.client.api.state.NeActualStateVerification.isInactive;
import static com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.PropertyPageLabels.NO_ASSOCIATION;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;
import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * Open NEs property page for Update.
 */
public class CommandOpenNeProperties extends ChainTemplate<IManagedObject[]> implements Command<Iterable<INE>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(CommandOpenNeProperties.class);
    private static final String EMPTY_LOCATION = "";
    private static final String EMPTY_TYPE = "";

    private final RepositoryManager repositoryManager;
    private final CommonServices commonServices;
    private final PropertyPagesRepository propertyPagesRepository;
    private final OpenPropertyPagePermissionChecker permissionChecker;

    public CommandOpenNeProperties(RepositoryManager repositoryManager, CommonServices commonServices,
                                   PropertyPagesRepository propertyPagesRepository) {
        this.repositoryManager = repositoryManager;
        this.commonServices = commonServices;
        this.propertyPagesRepository = propertyPagesRepository;
        this.permissionChecker = new OpenPropertyPagePermissionChecker(commonServices);
    }

    @Override protected ChainStatus process(final IManagedObject[] elements) throws ChainProcessException {
        try {
            final Iterable<INE> nes = ObjectUtils.filterBy(elements, INE.class);

            if (!Iterables.isEmpty(nes)) {
                this.call(nes);
                return ChainStatus.STOP;
            }

            return ChainStatus.CONTINUE;
        } catch (final Exception e) {
            throw new ChainProcessException(e);
        }
    }

    @Override public void call(final Iterable<INE> nes) throws CommandException {
        final INE nePrimary = stream(nes).findFirst()
                .orElseThrow(() -> new CommandException("NE not found"));

        final NeType neType = commonServices.getStaticConfiguration()
                .findNeType(nePrimary.getNeProxyType())
                .orElseThrow(() -> new CommandException("Ne type={} not found", nePrimary.getNeProxyType()));

        final Iterable<FullNeData> networkElements = stream(nes).flatMap(this::fetchNE)
                .collect(toList());

        final PropertyValueFlow propertyValueHelper = new PropertyValueFlowFactory()
                .create(buildPropertiesReplacer(networkElements), Iterables.size(nes));

        try {
            final PageDocument<FullNeData> document = new PageDocumentForUpdate<>(buildSelection(nes, nePrimary),
                    repositoryManager.getNeRepository(), propertyValueHelper,
                    commonServices.getDcnPluginHelper().getSessionContext());

            final OpenPropertyPage<FullNeData> delegate = new OpenPropertyPage<>(
                    ObjectUtils.join(" and ", nes), commonServices, neType, document,
                    propertyPagesRepository);

            if (!permissionChecker.isNePropertiesReadOnly(toArray(nes, INE.class))) {
                final PageOkButtonCommand command = new UpdatePropertyPageOkButtonCommand<>(networkElements,
                        repositoryManager.getNeRepository(), commonServices.getDcnPluginHelper().getSessionContext());
                delegate.setCommand(command);
            }

            delegate.call();
        } catch (final PropertyValueBuilderException e) {
            throw new CommandException(e);
        }
    }

    private ElementsSelection<Integer> buildSelection(final Iterable<INE> elements, final INE primary)
            throws CommandException, PropertyValueBuilderException {
        final Collection<INE> secondaries = stream(elements)
                .filter(input -> input.getId() != primary.getId()).collect(toList());

        final Iterable<Integer> secondariesID = secondaries.stream().map(INEId::getId).collect(toList());

        Collection<NeType> types = new HashSet<>();
        for (final INE ne : secondaries) {
            NeType neType = commonServices.getStaticConfiguration().findNeType(ne.getNeProxyType())
                    .orElseThrow(() -> new CommandException("NE type='{}' not supported", ne.getNeProxyType()));
            types.add(neType);
        }

        final Collection<Map<String, String>> secondariesTemplates = new ArrayList<>(types.size());
        for (final NeType neType : types) {
            final PropertyValueRepository repository = new PropertyValueRepositoryImpl(
                    new SingleSelectionPropertyValueFlow());
            new PageBuilder(propertyPagesRepository.getPropertyPage(neType), repository).build();

            secondariesTemplates.add(repository.allSavableValues());
        }

        return new ElementsSelection<>(primary.getId()).secondariesTemplates(secondariesTemplates)
                .secondariesId(secondariesID);
    }

    private WellKnownPropertiesAddOrModify buildPropertiesReplacer(@Nonnull final Iterable<FullNeData> elements) {
        return result -> {
            final String active = String.valueOf(stream(elements).map(FullNeData::getNe).anyMatch(ne -> !isInactive(ne)));

            result.modifyOrAdd(ACTIVE, active);
            result.modifyOrAdd(NE_SYSTEM_ASSIGNMENT_NAME, loadSystemName(elements));
            result.modifyOrAdd(NE_LOCATION, loadLocation(elements));
            result.modifyOrAdd(NE_TYPE_LABEL, loadTypeLabel(elements));
        };
    }

    String loadTypeLabel(Iterable<FullNeData> elements) {
        Set<String> types = stream(elements)
                .map(FullNeData::getNe)
                .map(ne -> typeLabel(ne.getNeProxyType(), ne.getNeSubType()))
                .collect(toSet());

        return types.size() <= 1
                ? getFirst(types, EMPTY_TYPE)
                : MULTIPLE_VALUES_TOKEN;
    }

    private String typeLabel(String type, String subType) {
        if (isEmpty(type)) {
            return EMPTY_TYPE;
        } else if (isEmpty(subType)) {
            return type;
        } else {
            return String.format("%s (%s)", subType, type);
        }
    }


    String loadLocation(Iterable<FullNeData> elements) {
        Set<String> locations = stream(elements)
                .map(FullNeData::getNe)
                .map(INE::getLocation)
                .map(Strings::nullToEmpty)
                .collect(toSet());

        return locations.size() <= 1
                ? getFirst(locations, EMPTY_LOCATION)
                : MULTIPLE_VALUES_TOKEN;
    }

    String loadSystemName(Iterable<FullNeData> elements) {
        final Optional<INE> firstNE = stream(elements).map(FullNeData::getNe).findFirst();
        if (firstNE.isPresent()) {
            final int firstSystemId = firstNE.get().getAssociatedSystemContainerId();

            final boolean allMatch = stream(elements)
                    .map(FullNeData::getNe)
                    .map(INE::getAssociatedSystemContainerId)
                    .allMatch(system -> system == firstSystemId);
            if (allMatch) {
                return fetchSystemName(firstSystemId);
            } else {
                return MULTIPLE_VALUES_TOKEN;
            }
        }

        return NO_ASSOCIATION.toString();
    }

    private Stream<FullNeData> fetchNE(INE ne) {
        try {
            return repositoryManager.getNeRepository().get(ne.getId())
                    .map(Stream::of).orElseGet(Stream::empty);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch ne {}", ne, e);
            return Stream.empty();
        }
    }

    private String fetchSystemName(final int systemId) {
        try {
            return repositoryManager.getSystemContainerRepository().get(systemId)
                    .map(ISystemContainer::getIdName)
                    .orElse(NO_ASSOCIATION.toString());
        } catch (RepositoryException e) {
            LOGGER.error("Error to fetch System container {}", systemId, e);
        }
        return NO_ASSOCIATION.toString();
    }

    private <T> Stream<T> stream(Iterable<T> iterable) {
        return StreamSupport.stream(iterable.spliterator(), false);
    }
}