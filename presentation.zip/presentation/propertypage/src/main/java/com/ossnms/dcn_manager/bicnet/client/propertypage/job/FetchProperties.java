package com.ossnms.dcn_manager.bicnet.client.propertypage.job;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Map;

/**
 * Job to fetch the Object properties.
 */
public class FetchProperties<K, V> extends FrameworkFetchJob {

    private static final String JOB_ID = FetchProperties.class.getName();
    private static final String JOB_NAME = "Fetch PropertyPage Properties";
    private static final String JOB_ADDITIONAL_INFO = "";

    private final Repository<K, V> repository;
    private final ISessionContext context;
    private final ElementsSelection<K> selection;

    public FetchProperties(@Nonnull final ElementsSelection<K> selection, @Nonnull final FrameworkDocument document, @Nonnull final Repository<K, V> repository,
            @Nonnull final ISessionContext context) {
        super(JOB_ID, JOB_NAME, JOB_ADDITIONAL_INFO, document);
        this.selection = selection;
        this.repository = repository;
        this.context = context;
    }

    @Override
    public ElementsSelection<K> execute(final Object object) throws FrameworkException {
        try {
            selection.primaryProperties(repository.getProperties(context, selection.getPrimaryId()));
            
            if (selection.getSecondariesId().isPresent()) {
                final Builder<Map<String, String>> builder =  ImmutableList.builder();
                
                for(final K id : selection.getSecondariesId().get()) {
                    builder.add(repository.getProperties(context, id));
                }
                
                selection.secondariesProperties(builder.build());
            }
            
            return selection;            
        } catch (final RepositoryException e) {
            throw new FrameworkException(e);
        }
    }
}