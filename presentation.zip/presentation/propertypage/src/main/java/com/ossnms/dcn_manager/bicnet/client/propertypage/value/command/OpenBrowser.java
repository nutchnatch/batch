package com.ossnms.dcn_manager.bicnet.client.propertypage.value.command;

import com.ossnms.tools.jfx.components.JfxFileChooser;

import javax.swing.JFileChooser;
import java.io.File;
import java.util.Optional;

/**
 * Open the JfxFileChooser dialog.
 */ 
public class OpenBrowser {
     
    /**
     * @return The string that contains the path for the execution command.
     */
    public String getCommandLine() {
        final JfxFileChooser fileChooser = new JfxFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setMultiSelectionEnabled(false);
        fileChooser.addChoosableFileFilter("executable", "exe");
        fileChooser.setAcceptAllFileFilterUsed(true);
        
        final int result = fileChooser.showOpenDialog(null);
        final Optional<File> selectedFile = Optional.ofNullable(fileChooser.getSelectedFile());
        
        if (selectedFile.isPresent() && result == JFileChooser.APPROVE_OPTION) {
            return selectedFile.get().toString();
        }
        
        return null;
    }
}
