package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.coriant.widgets.ClientProperties;
import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Action;
import com.ossnms.tools.jfx.components.JfxTextArea;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.event.ChangeListener;

import static org.apache.commons.lang3.StringUtils.strip;
import static org.apache.commons.lang3.StringUtils.stripToEmpty;

public class ValueJfxTextArea extends JfxTextArea implements PropertyValue {

    private static final long serialVersionUID = 3779193131992115065L;

    private final ValueDescriptor descriptor;

    public ValueJfxTextArea(@Nonnull final ValueDescriptor descriptor) {
        this.descriptor = descriptor;
        addDocumentListener(descriptor.getConditionListener());
    }

    @Override
    @Nonnull
    public String getId() {
        return descriptor.getId();
    }

    @Override
    @Nonnull
    public String getContent() {
        return strip(getText());
    }

    @Override
    public void setContent(@Nullable final String content) {
        modifyContent(content);
        setUnmodifiedValue(stripToEmpty(content));
    }

    @Override public void modifyContent(String content) {
        if (descriptor.isMultipleValue(content)) {
            setUndefined(true);
        } else {
            setText(strip(content));
        }
    }

    @Override
    @Nonnull
    public boolean isChanged() {
        return isValueModified();
    }

    @Override
    public void addConditionListener(@Nonnull final ChangeListener listener) {
        descriptor.getConditionListener().listening(listener);
    }

    @Override
    @Nonnull
    public ImmutableList<Action> getValueActions() {
        return descriptor.getActions();
    }

    @Override
    public void onWritable(final boolean enabled) {
        setEnabled(descriptor.enabledVerify(enabled));
    }

    @Override
    public void onCleanOnDisable(final boolean clear) {
        setText(clear ? "" : getContent());
    }

    @Override
    public void onValueFromConditionResult(final boolean conditionResult) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void onMovable(final boolean input) {
        descriptor.setMovable(input);
    }

    @Override
    public boolean isMovable() {
        return descriptor.getMovable().get();
    }

    @Override
    public boolean isMandatoryValueBlank() {
        return descriptor.isMandatoryValueEmpty(this, isMandatoryEntry());
    }

    @Override
    public boolean forceSendOnUpdate() {
        return descriptor.forceSendOnUpdate();
    }

    @Override
    public void setForceSendOnUpdate(final boolean alwaysSendOnUpdate) {
        descriptor.setForceSendOnUpdate(alwaysSendOnUpdate);
    }

    @Override
    public boolean isInvalidEntry() {
        return Boolean.TRUE.equals(getClientProperty(ClientProperties.INVALID));
    }

    @Override
    public void fireStateChange() {
        descriptor.getConditionListener().fireStateChanged();
    }


    @Override
    public boolean supportMultiselection() {
        return descriptor.supportMultiselection();
    }

    /** {@inheritDoc} */
    @Override public void clearConditions() {
        descriptor.getConditionListener().clear();
    }
}
