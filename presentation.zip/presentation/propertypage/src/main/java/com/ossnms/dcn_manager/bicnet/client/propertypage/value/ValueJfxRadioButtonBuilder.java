package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;

import javax.annotation.Nonnull;

public class ValueJfxRadioButtonBuilder extends ValueBuilder<ValueJfxRadioButton> {

    public ValueJfxRadioButtonBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        super(value, valueRepository);
    }

    @Override
    @Nonnull
    protected ValueJfxRadioButton buildComponent() {

        final ValueJfxRadioButton jfxRadioButton = new ValueJfxRadioButton(
                new ValueDescriptor(getValue().getId(), getValue().getAction(), getValue().getMultiselection(), getValueRepository().isDynamicEnableFieldPermitted()));

        setBasicComponentValues(jfxRadioButton);
                
        jfxRadioButton.setText(getValue().getBooleanText().getContent());        
        jfxRadioButton.setContent(buildDefaultValue());

        return jfxRadioButton;
    }
}
