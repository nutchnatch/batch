package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.ActionStateListener;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.tools.jfx.components.JfxButton;

import javax.annotation.Nonnull;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ValueButton extends JfxButton implements ActionStateListener, ActionListener {

    private static final long serialVersionUID = -7755525507695666579L;

    private final PropertyValue propertyValue;

    public ValueButton(@Nonnull PropertyValue propertyValue) {
        super();
        this.propertyValue = propertyValue;
        addActionListener(this);
    }

    @Override
    public void onWritable(boolean writable) {
        this.setEnabled(writable);
    }

    @Override
    public void onValueFromConditionResult(boolean conditionResult) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void onCleanOnDisable(boolean clear) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void onMovable(boolean move) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void actionPerformed(@Nonnull ActionEvent event) {
        final String action = ((JfxButton) event.getSource()).getActionCommand();
        ValueButtonAction.valueOf(action).executeCommand(propertyValue);
    }
}
