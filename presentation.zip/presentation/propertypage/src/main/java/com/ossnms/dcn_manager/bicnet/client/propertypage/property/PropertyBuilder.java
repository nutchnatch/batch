package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;

import javax.annotation.Nonnull;
import java.awt.Component;

/**
 * Template to build PropertyPage {@link #property}.
 *   
 * @param <P> The JfxComponent to build.
 */
abstract class PropertyBuilder<P extends Component> {

    private final DynamicPanelForm panelForm;
    private final Property property;
    private final PropertyValueRepository valueRepository;
   
    /**
     * @param panelForm The form to add the components
     * @param property The Property to build.
     * @param valueRepository The repository to add the #Property #Value.
     */
    protected PropertyBuilder(@Nonnull final DynamicPanelForm panelForm, @Nonnull final Property property, @Nonnull final PropertyValueRepository valueRepository) {
        super();
        this.panelForm = panelForm;
        this.property = property;
        this.valueRepository = valueRepository;
    }
    
    public abstract P build() throws PropertyValueBuilderException;
    
    /**
     * @return The JPanel with added components.
     */
    @Nonnull
    public DynamicPanelForm getPanelForm() {
        return panelForm;
    }

    /**
     * @return The PropertyPage #Property
     */
    @Nonnull
    protected Property getProperty() {
        return property;
    }
    
    /**
     * @return the Repository with #Property #Value.
     */
    @Nonnull
    protected PropertyValueRepository getValueRepository() {
        return valueRepository;
    }   
}
