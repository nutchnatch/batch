package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.JScrollPaneBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueTypeFactory;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.tools.jfx.components.JfxLabel;

import javax.annotation.Nonnull;
import javax.swing.JPanel;
import java.awt.Component;

/**
 * Builder for #Property type #PropertyTypeFactory.area.
 */
public class PropertyAreaBuilder extends PropertyBuilder<JPanel> {

    /**
     * @param panelForm The form to add the components
     * @param property The Property to build.
     * @param valueRepository The repository to add the #Property #Value.
     */
    public PropertyAreaBuilder(@Nonnull final DynamicPanelForm panelForm, @Nonnull final Property property,
            @Nonnull final PropertyValueRepository valueRepository) {
        super(panelForm, property, valueRepository);
    }

    /**
     * Builds the JPanel with a TextAre GUI style.
     */
    @Override
    @Nonnull
    public JPanel build()  throws PropertyValueBuilderException {
        final JfxLabel label = new LabelBuilder(getProperty().getLabel()).build();
        final Component textArea = new JScrollPaneBuilder(ValueTypeFactory.createOf(getProperty().getValue(), getValueRepository())).build();
        
        label.setLabelAndMnemonicFor(textArea);
        getPanelForm().addArea(label, textArea);
        
        return getPanelForm();
    }
}