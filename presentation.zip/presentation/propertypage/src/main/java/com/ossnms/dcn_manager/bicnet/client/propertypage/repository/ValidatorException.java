package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

public class ValidatorException extends Exception {

    private static final long serialVersionUID = 5549667429299256772L;

    public ValidatorException(String message) {
        super(message);
    }
}
