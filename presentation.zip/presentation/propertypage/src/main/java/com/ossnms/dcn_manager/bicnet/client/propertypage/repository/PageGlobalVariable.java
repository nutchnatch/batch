package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

import com.ossnms.dcn_manager.core.jaxb.propertypage.GlobalVariable;

import javax.annotation.Nonnull;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.EMPTY;

/**
 * Global variables to be used internally on Property Page conditions.
 * 
 * @see com.ossnms.dcn_manager.bicnet.client.propertypage.condition.ConditionChain
 */
public class PageGlobalVariable extends AbstractPropertyValue implements ChangeListener, Serializable {

    private static final long serialVersionUID = -6247218428745035069L;
    
    private final String id;
    private String content;
    
    private final List<ChangeListener> listeners;
    
    public PageGlobalVariable(@Nonnull final String id, @Nonnull final String content) {
        this.id = id;
        this.content = Optional.ofNullable(content).orElse(EMPTY);
        this.listeners = new ArrayList<>();
    }

    public PageGlobalVariable(@Nonnull final GlobalVariable globalVariable) {
        this(globalVariable.getId(), globalVariable.getValue());
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public void addConditionListener(final ChangeListener listener) {
        listeners.add(listener);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getId() {
        return id;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getContent() {
        return content;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setContent(final String content) {
        this.content = content;
        stateChanged(new ChangeEvent(content));
    }

    @Override public void modifyContent(String content) {
        setContent(content);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean forceSendOnUpdate() {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stateChanged(final ChangeEvent e) {
        for (final ChangeListener listener : listeners) {
            listener.stateChanged(e);
        }
    }
}
