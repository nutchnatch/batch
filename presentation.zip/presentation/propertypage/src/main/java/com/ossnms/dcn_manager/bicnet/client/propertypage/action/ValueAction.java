package com.ossnms.dcn_manager.bicnet.client.propertypage.action;

import com.ossnms.dcn_manager.bicnet.client.propertypage.condition.ConditionChain;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.ActionStateListener;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Responsible to fire the #ActionState event after the associated #ActionStateListener component change.
 * 
 * The result of condition will be send with the #ActionState notification.
 * 
 * @see ConditionChain
 */
public class ValueAction implements ChangeListener {

    private final ActionStateListener listener;
    private final ActionState actionState;
    private final ConditionChain condition;

    /**
     * @param listener The associate listener
     * @param actionState The action state processor
     * @param condition The condition chain
     */
    public ValueAction(@Nonnull final ActionStateListener listener, @Nonnull final ActionState actionState, @Nonnull final ConditionChain condition) {
        super();
        this.listener = listener;
        this.actionState = actionState;
        this.condition = condition;
        
        condition.listening(this);
    }

    /**
     * @see javax.swing.event.ChangeListener#stateChanged(ChangeEvent)
     */
    @Override
    public void stateChanged(@Nullable ChangeEvent e) {
        actionState.notifyChanges(listener, condition.verify());
    }

    /**
     * @return return The Listener
     */
    @Nonnull
    public ActionStateListener getListener() {
        return listener;
    }

    /**
     * @return The Action state processor
     */
    @Nonnull
    public ActionState getActionState() {
        return actionState;
    }

    /**
     * @return The condition chain
     */
    @Nonnull
    public ConditionChain getCondition() {
        return condition;
    }
}
