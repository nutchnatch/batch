package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueTypeFactory;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;

import javax.annotation.Nonnull;
import javax.swing.JPanel;
import java.awt.Component;

/**
 * Builder for #Property type #PropertyTypeFactory.toggle
 */
public class PropertyToggleBuilder extends PropertyBuilder<JPanel> {

    /**
     * @param panelForm The form to add the components
     * @param property The Property to build.
     * @param valueRepository The repository to add the #Property #Value.
     */
    public PropertyToggleBuilder(@Nonnull final DynamicPanelForm panelForm, @Nonnull final Property property, @Nonnull final PropertyValueRepository valueRepository) {
        super(panelForm, property, valueRepository);
    }
    
    /**
     * Builds a JPanel with JfxCheckBox.
     */
    @Override
    public JPanel build() throws PropertyValueBuilderException {
        final Component component = ValueTypeFactory.createOf(getProperty().getValue(), getValueRepository());
        return getPanelForm().addToggleValue(component);
    }
}
