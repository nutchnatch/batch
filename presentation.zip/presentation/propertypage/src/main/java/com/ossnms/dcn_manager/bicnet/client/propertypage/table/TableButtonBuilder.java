package com.ossnms.dcn_manager.bicnet.client.propertypage.table;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.propertypage.action.ValueActionObserver;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Button;
import com.ossnms.tools.jfx.JfxIconImpl;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.table.JfxTable;
import org.apache.commons.lang3.builder.Builder;

import javax.annotation.Nonnull;
import java.awt.Dimension;
import java.util.Optional;

public class TableButtonBuilder implements Builder<JfxButton> {

    private final JfxTable table;
    private final Button button;
    private final PropertyValueRepository valueRepository;

    public TableButtonBuilder(@Nonnull final JfxTable table, @Nonnull Button button, @Nonnull final PropertyValueRepository valueRepository) {
        this.table = table;
        this.button = button;
        this.valueRepository = valueRepository;
    }

    @Override
    public JfxButton build() {
        final TableButton jfxButton = new TableButton(table);

        setIcon(jfxButton);

        jfxButton.setToolTipText(button.getTooltip());
        jfxButton.setName(button.getGuiName());
        jfxButton.setActionCommand(button.getType());
                
        ValueActionObserver.newInstance(valueRepository, button.getAction(), jfxButton).registerActionListener();
        
        return jfxButton;
    }

    private void setIcon(@Nonnull final JfxButton jfxButton) {
        try {
            final Optional<String> iconName = Optional.ofNullable(button.getIcon());

            if (iconName.isPresent()) {
                jfxButton.setIcon((JfxIconImpl) ResourcesIconFactory.class.getDeclaredField(iconName.get())
                        .get(ResourcesIconFactory.getInstance()));

                final Dimension dimension = new Dimension(JfxUtils.IMAGE_BUTTON_SIZE, JfxUtils.IMAGE_BUTTON_SIZE);
                jfxButton.setPreferredSize(dimension);
                jfxButton.setMaximumSize(dimension);
                jfxButton.setMinimumSize(dimension);
            }
        } catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException e) {
            throw new UnsupportedOperationException(e);
        }
    }
}
