package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.action.ValueActionObserver;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Button;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.components.JfxButton;
import org.apache.commons.lang3.builder.Builder;

import javax.annotation.Nonnull;
import java.util.Optional;

public class ValueButtonBuilder implements Builder<JfxButton> {

    private final PropertyValue propertyValue;
    private final Button button;
    private final PropertyValueRepository valueRepository;

    public ValueButtonBuilder(@Nonnull final PropertyValue propertyValue, @Nonnull Button button, @Nonnull final PropertyValueRepository valueRepository) {
        this.propertyValue = propertyValue;
        this.button = button;
        this.valueRepository = valueRepository;
    }

    @Override
    public JfxButton build() {
        final ValueButton jfxButton = new ValueButton(propertyValue);
        Optional<String> text = Optional.ofNullable(button.getText());
        
        jfxButton.setToolTipText(button.getTooltip());
        jfxButton.setName(button.getGuiName());
        jfxButton.setActionCommand(button.getType());
        if(text.isPresent()) {
            JfxText buttonText = new JfxText(text.get());
            jfxButton.setText(buttonText);
            jfxButton.setMnemonic(buttonText.getMnemonic());
        }
        
        ValueActionObserver.newInstance(valueRepository, button.getAction(), jfxButton).registerActionListener();
        
        return jfxButton;
    }
}