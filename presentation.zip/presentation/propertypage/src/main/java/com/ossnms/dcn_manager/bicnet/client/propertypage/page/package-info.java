/**
 * Contains the high level GUI components builders.
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.page;