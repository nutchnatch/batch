package com.ossnms.dcn_manager.bicnet.client.propertypage.controller;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;

import java.util.function.Consumer;

/**
 * Add when not present or modify the well known property pages values before open the propertyPage for new objects.
 */
@FunctionalInterface public interface WellKnownPropertiesAddOrModify extends Consumer<PropertyValueRepository> {
    WellKnownPropertiesAddOrModify EMPTY = repo -> {};
}
