package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

import com.ossnms.dcn_manager.core.jaxb.propertypage.Static;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.EMPTY;

/**
 * Static properties to define the default configuration values. 
 */
public class StaticConfigurationValue extends AbstractPropertyValue {
    private static final Logger LOGGER = LoggerFactory.getLogger(StaticConfigurationValue.class);
    
    private final String id;
    private final String content;
    
    public StaticConfigurationValue(@Nonnull String id, @Nonnull String content) {
        this.id = id;
        this.content = Optional.ofNullable(content).orElse(EMPTY);
    }

    public StaticConfigurationValue(@Nonnull Static staticValue) {
        this(staticValue.getId(), staticValue.getValue());
    }
        
    /**
     * {@inheritDoc}
     */
    @Override
    public String getId() {
        return id;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getContent() {
        return content;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setContent(String content) {
        LOGGER.debug("Static Configuration Value is final");
    }

    @Override public void modifyContent(String content) {
        setContent(content);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean forceSendOnUpdate() {
        return false;
    }
}
