package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.coriant.widgets.spinner.SpinnerIntegerRangesModel;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nonnull;
import javax.swing.SpinnerModel;
import java.util.List;

import static org.apache.commons.lang3.math.NumberUtils.toInt;

public class ValueJfxSpinnerBuilder extends ValueBuilder<ValueJfxSpinner> {

    private static final int DEFAULT_STEP_SIZE = 1;

    public ValueJfxSpinnerBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        super(value, valueRepository);
    }

    @Override @Nonnull protected ValueJfxSpinner buildComponent() {
        final List<Pair<Integer, Integer>> ranges = buildRanges();
        final String defaultValue = buildDefaultValue();
        int min = ranges.isEmpty() ? 0 : ranges.get(0).getLeft();
        final int valueInt = toInt(defaultValue, min);

        final ValueJfxSpinner jfxSpinner = new ValueJfxSpinner(
                new ValueDescriptor(
                        getValue().getId(), getValue().getAction(), getValue().getMultiselection(),
                        getValueRepository().isDynamicEnableFieldPermitted()),
                buildSpinnerModel(valueInt, ranges));

        setBasicComponentValues(jfxSpinner);

        jfxSpinner.setToolTipText(buildToolTip(ranges));
        jfxSpinner.setMandatoryEntry(true);
        jfxSpinner.setContent(defaultValue);

        return jfxSpinner;
    }

    /**
     * Build model from LAF API.
     */
    private SpinnerModel buildSpinnerModel(final int value, @Nonnull final List<Pair<Integer, Integer>> rangesList) {
        int[][] ranges = rangesList.stream()
                .map(pair -> new int[]{pair.getLeft(), pair.getRight()})
                .toArray(int[][]::new);
        
        return new SpinnerIntegerRangesModel(value, ranges, DEFAULT_STEP_SIZE);
    }
}
