package com.ossnms.dcn_manager.bicnet.client.propertypage.table;

import com.coriant.widgets.text.PTextField;
import com.ossnms.tools.jfx.table.JfxTable;

import javax.annotation.Nonnull;

import static org.apache.commons.lang3.StringUtils.EMPTY;

public enum TableButtonAction {
    MOVEUP {
        @Override
        public void executeCommand(JfxTable table) {
            moveUpAction(table);
        }
    },

    MOVEDOWN {
        @Override
        public void executeCommand(JfxTable table) {
            moveDownAction(table);
        }
    },

    CLEAR {
        @Override
        public void executeCommand(JfxTable table) {
            clearRowValues(table);
        }
    };

    public abstract void executeCommand(@Nonnull JfxTable table);

    private static void moveUpAction(@Nonnull JfxTable table) {
        final int selectedRow = table.getSelectedRow();

        if (selectedRow > 0) {
            final int newRow = selectedRow - 1;
            for (int i = 1; i < table.getBaseModel().getColumnCount(); i++) {
                final PTextField columnValue = ((RouteTableModel) table.getBaseModel()).getPropertyValueAt(selectedRow, i);
                
                final String tmp = columnValue.getText();
                
                final PTextField columnValue2 = ((RouteTableModel) table.getBaseModel()).getPropertyValueAt(newRow, i);

                columnValue.setText(columnValue2.getText());
                columnValue2.setText(tmp);
            }

            table.setRowSelectionInterval(newRow, newRow);
        }
    }

    private static void moveDownAction(@Nonnull JfxTable table) {
        final int selectedRow = table.getSelectedRow();

        if (selectedRow >= 0) {
            final int newRow = selectedRow + 1;
            for (int i = 1; i < table.getBaseModel().getColumnCount(); i++) {
                final PTextField columnValue = ((RouteTableModel) table.getBaseModel()).getPropertyValueAt(selectedRow, i);
                final PTextField columnValue2 = ((RouteTableModel) table.getBaseModel()).getPropertyValueAt(newRow, i);
                
                final String tmp = columnValue.getText();                

                columnValue.setText(columnValue2.getText());
                columnValue2.setText(tmp);
            }
            table.setRowSelectionInterval(newRow, newRow);
        }
        
        table.repaint();
    }

    private static void clearRowValues(@Nonnull JfxTable table) {
        final int[] selectedRows = table.getSelectedRows();
        final int startInColumn = 1;

        for (final int selectedRow : selectedRows) {
            for (int i = startInColumn; i < table.getBaseModel().getColumnCount(); i++) {
                final PTextField columnValue = ((RouteTableModel) table.getBaseModel()).getPropertyValueAt(selectedRow, i);
                columnValue.setText(EMPTY);
            }
        }
        
        table.repaint();
    }
}
