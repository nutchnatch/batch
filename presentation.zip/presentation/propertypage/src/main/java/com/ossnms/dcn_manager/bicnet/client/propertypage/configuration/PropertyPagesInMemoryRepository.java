package com.ossnms.dcn_manager.bicnet.client.propertypage.configuration;

import com.google.common.base.Joiner;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.Type;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFile;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;

/**
 * Memory based Property Pages Repository.
 * 
 * @see #MAX_ELEMENTS
 */
class PropertyPagesInMemoryRepository implements PropertyPagesRepository {
   
    /** Elements are evicted before this limit was exceeded */
    private static final int MAX_ELEMENTS = 24;
        
    private final PropertyPageFileLoader loader;
    private final Cache<String, Page> pages;
    
    public PropertyPagesInMemoryRepository() {
        pages = CacheBuilder.newBuilder()
                            .maximumSize(MAX_ELEMENTS)
                            .build();
        
        loader = new PropertyPageFileLoader();
    }

    /**
     * {@inheritDoc}
     * @throws PropertyValueBuilderException 
     */
    @Override
    public Page getPropertyPage(@Nonnull final Type type) throws PropertyValueBuilderException {
        final Collection<PropertyPageFile> pageFiles = type.getSupportedPropertyPageFiles().getPropertyPageFile();
        final Page pageJoined = new Page();
        
        try {
            for (final PropertyPageFile pageFile : pageFiles) {
                Page page = get(pageFile.getName());
                joinPages(pageJoined, page);
            }
        } catch (final ExecutionException e) {
            throw new PropertyValueBuilderException(e);
        }     
                        
        return pageJoined;
    }
    
    private Page get(@Nonnull final String key) throws ExecutionException {
        return pages.get(key, new Callable<Page>() {
            @Override
            public Page call() throws ExecutionException {
                return loader.loadConfiguration(key);
            }
        });
    }
    
    private void joinPages(final Page pageJoined, final Page nextPage) {
        pageJoined.getGlobalVariable().addAll(nextPage.getGlobalVariable());
        pageJoined.getStatic().addAll(nextPage.getStatic());
        pageJoined.getTabbedPane().addAll(nextPage.getTabbedPane());
        
        pageJoined.setTitle(Joiner.on(';').skipNulls().join(pageJoined.getTitle(),nextPage.getTitle()));
        pageJoined.setVersion(nextPage.getVersion());
    }
}
