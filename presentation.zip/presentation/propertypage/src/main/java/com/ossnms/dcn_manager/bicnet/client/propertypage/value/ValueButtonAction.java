package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.command.OpenBrowser;

public enum ValueButtonAction {
    
    BROWSE {
        @Override
        public void executeCommand(@Nonnull PropertyValue value) {
            value.setContent(new OpenBrowser().getCommandLine());
            value.setForceSendOnUpdate(true);
        }
    };
    
    public abstract void executeCommand(@Nonnull PropertyValue value);
}
