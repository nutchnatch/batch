package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import static org.apache.commons.lang3.math.NumberUtils.isNumber;
import static org.apache.commons.lang3.math.NumberUtils.toInt;

/**
 * The Dynamic Combo-box is based on Item Key to process and compare the data.
 */
public class ValueDynamicComboBox extends ValueJfxComboBox {

    private static final long serialVersionUID = -1940927885023849036L;

    public ValueDynamicComboBox(@Nonnull final ValueDescriptor descriptor) {
        super(descriptor);
    }

    @Override
    @Nonnull
    public String getContent() {
        final Object selectedKey = getSelectedKey();
        return null != selectedKey ? String.valueOf(selectedKey) : "";
    }

    @Override
    public void setContent(@Nullable final String content) {
        modifyContent(content);
        setUnmodifiedValue(getSelectedItem());
    }

    @Override public void modifyContent(String content) {
        if (getDescriptor().isMultipleValue(content)) {
            addItem(content, content);
            setSelectedItemByKey(content);
        } else if (isNumber(content)) {
            setSelectedItem(toInt(content, getSelectedIntValue()));
        } else {
            setSelectedItemByKey(content);
        }
    }
}
