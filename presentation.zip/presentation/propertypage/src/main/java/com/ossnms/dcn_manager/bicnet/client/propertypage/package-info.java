/**
 * Contains the classes to start the flow of the dynamic property page construction. 
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage;