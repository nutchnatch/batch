package com.ossnms.dcn_manager.bicnet.client.propertypage.controller;

import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.ossnms.dcn_manager.bicnet.client.api.ObjectUtils;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PageGlobalVariable;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.StaticConfigurationValue;
import com.ossnms.tools.jfx.JfxStringTable;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.swing.SwingUtilities;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.nullToEmpty;

/**
 * The <b>Multiselection flow</b> contains the <b>PropertyPage</b> properties of more than one element of the same type.
 * 
 * The <b>Primary properties</b> is the properties that match with the PropertyPage configuration opened.~
 * The <b>Secondaries properties</b> is the properties of the others elements excluding the <b>Primary properties</b>.
 * 
 * <p>
 * <b>Result:</b>
 * </p>
 * The result of the {@link #updatePropertyValueRepository} method will be the </b>Primary properties</b> values populated in the
 * {@link PropertyValueRepository} with the <b>Common Element Keys</b> between the <b>Primary properties</b> and
 * <b>Secondaries properties</b> joined.
 * 
 * <p>
 * <b>Replace with Multiple Value Token:</b>
 * </p>
 * When the <b>Common Element keys</b> has any value different between the </b>Primary properties</b> and
 * <b>Secondaries properties</b>, the value will be replaced with the multiple value token(
 * {@link #MULTIPLE_VALUES_TOKEN}) for the correct GUI identification and process.
 */
public class MultiSelectionPropertyValueFlow implements PropertyValueFlow {
    private static final Logger LOGGER = LoggerFactory.getLogger(MultiSelectionPropertyValueFlow.class);
    private static final String INVALID_MULTISELECTION_FLOW = "Invalid multiselection flow.";

    public static final String MULTIPLE_VALUES_TOKEN = JfxStringTable.IDS_MULTIPLE_VALUES_TOKEN.getText();

    private final WellKnownPropertiesAddOrModify replacer;

    public MultiSelectionPropertyValueFlow(@Nonnull final WellKnownPropertiesAddOrModify replacer) {
        this.replacer = replacer;
    }
    
    /**
     * It is a multiselection flow when the total elements is greater than 1.
     */
    public static boolean isInMultiselectionFlow(final int totalElements) {
        return totalElements > 1;
    }

    /**
     * Update the elements values for a single multiselection flow.
     */
    @Override
    public <K> void updatePropertyValueRepository(@Nonnull final PropertyValueRepository valueRepository,
            @Nonnull final ElementsSelection<K> selection) {

        checkArgument(selection.getPrimaryProperties().isPresent(), INVALID_MULTISELECTION_FLOW);
        checkArgument(selection.getSecondariesId().isPresent(), INVALID_MULTISELECTION_FLOW);
        checkArgument(selection.getSecondariesProperties().isPresent(), INVALID_MULTISELECTION_FLOW);
        checkArgument(selection.getSecondariesTemplates().isPresent(), INVALID_MULTISELECTION_FLOW);

        final Collection<Entry<String, String>> commonPropertiesInTemplate = filterByCommonElement(
                valueRepository.allSavableValues(), selection.getSecondariesTemplates().get());

        updateValueRepository(valueRepository, selection.getPrimaryProperties().get(),
                selection.getSecondariesProperties().get(), commonPropertiesInTemplate);
    }

    /** {@inheritDoc} */
    @Override
    public Predicate<PropertyValue> buildFilterForChangedValues() {
        return input -> input.isEnabled()
                && input.isChanged()
                && input.supportMultiselection()
                && !input.isUndefined()
                && !MULTIPLE_VALUES_TOKEN.equals(input.getContent());
    }
    
    /** {@inheritDoc} */
    @Override
    public boolean isDynamicEnableFieldPermitted() {
        return false;
    }

    /*
     * Updates all GUI elements using the EDT context.
     */
    private void updateValueRepository(@Nonnull final PropertyValueRepository valueRepository, final Map<String, String> primaryPropertiesValues,
            final Iterable<Map<String, String>> secondariesProperties, final Collection<Entry<String, String>> commonProperties) {
        SwingUtilities.invokeLater(() -> {
            setPrimaryProperties(valueRepository, primaryPropertiesValues);
            setMultiSelectionConstant(valueRepository, secondariesProperties, commonProperties);
            replacer.accept(valueRepository);
            fireStateChangeForAllValues(valueRepository);
        });
    }
    
    /**
     * The elements that were selected with different values between the Primary and secondaries properties, must have
     * a identification constant for the GUI process the elements correctly in a multiselection flow.
     * 
     * @see #MULTIPLE_VALUES_TOKEN for Identification constant.
     *
     * Example for GUI element:
     * @see com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextField#setContent(String)
     * @see com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueDescriptor#isMultipleValue(String)
     */
    private void setMultiSelectionConstant(@Nonnull final PropertyValueRepository valueRepository,
            final Iterable<Map<String, String>> secondariesProperties,
            final Collection<Entry<String, String>> commonProperties) {

        for (final PropertyValue value : valueRepository.allValues()) {
            final boolean isMultiSelectionAllowed =
                    value.supportMultiselection() && isValueInCommonEntries(commonProperties, value.getId());

            if (!isMultiSelectionAllowed) {
                LOGGER.debug("setMultiSelectionConstant() :: Disabling not supported property id='{}'", value.getId());
                value.onWritable(false);
            }

            LOGGER.debug("setMultiSelectionConstant() :: For property id='{}', isMultiSelectionAllowed='{}'",
                    value.getId(), isMultiSelectionAllowed);

            final boolean valuesIsDifferent = FluentIterable.from(secondariesProperties)
                    .firstMatch(input -> !StringUtils.equalsIgnoreCase(nullToEmpty(input.get(value.getId())),
                            nullToEmpty(value.getContent()))).isPresent();

            if (valuesIsDifferent && isPropertyValue(value)) {
                LOGGER.debug("setMultiSelectionConstant() :: Setting multiplevalue for property id='{}', value='{}'",
                        value.getId(), value.getContent());
                value.setContent(MULTIPLE_VALUES_TOKEN);
            }
        }
    }

    private boolean isPropertyValue(@Nonnull final PropertyValue value) {
        return !ObjectUtils.anyMatch(value, PageGlobalVariable.class, StaticConfigurationValue.class);
    }

    /*
     * Filter by the Primary Properties key entries which are present in all secondaries maps.
     */
    private Collection<Entry<String, String>> filterByCommonElement(final Map<String, String> primaryTemplate,
            final Iterable<Map<String, String>> secondariesTemplate) {

        final Collection<Entry<String, String>> commonProperties = new HashSet<>();

        for (final Entry<String, String> entry : primaryTemplate.entrySet()) {
            final boolean contains = !(FluentIterable.from(secondariesTemplate).firstMatch(input -> !input.containsKey(entry.getKey())).isPresent());

            if (contains) {
                commonProperties.add(entry);
            }
        }

        return commonProperties;
    }

    /*
     * Verifies if the entries contains the commonEntryId.
     */
    private boolean isValueInCommonEntries(@Nonnull final Collection<Entry<String, String>> entries, @Nonnull final String valueId) {
        return FluentIterable.from(entries).firstMatch(input -> input.getKey().equalsIgnoreCase(valueId)).isPresent();
    }

    /*
     * Update the ValueRepository with the master properties
     */
    private void setPrimaryProperties(@Nonnull final PropertyValueRepository valueRepository, final Map<String, String> properties) {
        for (final Entry<String, String> entry : properties.entrySet()) {
            final Optional<PropertyValue> propertyValue = valueRepository.find(entry.getKey());

            if (propertyValue.isPresent()) {
                propertyValue.get().setContent(entry.getValue());
            }
        }
    }

    /*
     * Updates the elements state.
     */
    private void fireStateChangeForAllValues(@Nonnull final PropertyValueRepository valueRepository) {
        for (final PropertyValue value : valueRepository.allValues()) {
            value.fireStateChange();
        }
    }
}
