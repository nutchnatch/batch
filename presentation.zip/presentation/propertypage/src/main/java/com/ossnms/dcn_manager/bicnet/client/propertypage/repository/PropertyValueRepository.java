package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;

/**
 * Repository to temporally store the PropertyPage components value(#PropertyValue).
 * 
 * NOTE: All #PropertyValue will be discarded after the PropertyPage was closed.
 * 
 * @see PropertyValue
 */
public interface PropertyValueRepository {
    /**
     * @param value Add a {@link PropertyValue}.
     */
    void add(PropertyValue value);
    
    /**
     * Modify a propertyValue or add a new when is not present.
     * 
     * @param key
     * @param value
     */
    void modifyOrAdd(String key, String value);
    
    /**
     * @param properties Add all properties to repository.
     */
    void addAll(Map<String, String> properties);

    /**
     * @param key The {@link PropertyValue#getId()} to find.
     * @return The {@link PropertyValue} when present.
     */
    Optional<PropertyValue> find(String key);

    /**
     * @return Gets all {@link PropertyValue} from the Repository.
     */
    Collection<PropertyValue> allValues();
  
    /**
     * @return Gets all values that must be saved on Server Repository.
     */
    Map<String, String> allSavableValues();
    
    /**
     * Clear all values from the repository.
     */
    void clear();

    /**
     * @return Gets all changed values from the repository.
     */
    Collection<PropertyValue> allChangedValues();
    
    /**
     * @return Gets all changed values from the repository, in Map<K,V> format.
     */
    Map<String, String> allChangedValuesMap();
     
    /**
     * @return Verify if the itens of repository is marked to enable the OK command button.
     */
    boolean enableButtonOk();
    
    /**
     * Register a Value Validator.
     * @param validator
     */
    void addValidator(Validator validator);
    
    /**
     * Call the all registered validators to verify if the associated element are valid. 
     * 
     * @throws ValidatorException when values are not valid.
     */
    void validateValues() throws ValidatorException;

    /**
     * Put all fields to read-only.
     */
    void allToReadOnly();

    /**
     * Updates the PropertyValue repository from a properties map.
     * @param selection
     */
    <K> void updateRepository(ElementsSelection<K> selection);
    
    /**
     * @return true if the PropertyValue can be enable/disable dynamically.
     */
    boolean isDynamicEnableFieldPermitted();
}
