package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import javax.annotation.Nonnull;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ValueChangeListener implements DocumentListener, FocusListener, ChangeListener, ItemListener,
        Serializable {

    private static final long serialVersionUID = -6747306743419881615L;

    private final List<ChangeListener> listeners = new ArrayList<>();
    private final ChangeEvent changeEvent = new ChangeEvent(this);

    public void listening(@Nonnull ChangeListener listener) {
        listeners.add(listener);
    }

    public void fireStateChanged() {
        for (final ChangeListener listener : listeners) {
            listener.stateChanged(changeEvent);
        }
    }

    public void clear() {
        listeners.clear();
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        fireStateChanged();
    }

    @Override
    public void insertUpdate(DocumentEvent e) {
        fireStateChanged();

    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        fireStateChanged();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        fireStateChanged();
    }

    @Override
    public void focusGained(FocusEvent e) {
        fireStateChanged();
    }

    @Override
    public void focusLost(FocusEvent e) {
        fireStateChanged();
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        fireStateChanged();
    }
}
