package com.ossnms.dcn_manager.bicnet.client.propertypage.table;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.DynamicValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.Column;
import com.ossnms.dcn_manager.bicnet.client.propertypage.validator.ValidatorProxy;
import com.ossnms.dcn_manager.core.jaxb.propertypage.TableModel;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.table.JfxTable;
import org.apache.commons.lang3.builder.Builder;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nonnull;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableColumn;
import java.awt.Dimension;
import java.util.Optional;

public class RouteTableBuilder implements Builder<RouteTable> {
    
    private static final String TERMINATE_EDIT_ON_FOCUS_LOST = "terminateEditOnFocusLost";

    private final TableModel tableModel;
    private final PropertyValueRepository valueRepository;

    public RouteTableBuilder(@Nonnull final TableModel tableModel, @Nonnull final PropertyValueRepository valueRepository) {
        this.tableModel = tableModel;
        this.valueRepository = valueRepository;
    }

    @Override
    public RouteTable build() {
        final RouteTableModel routeTableModel = new RouteTableModelBuilder(tableModel, valueRepository).build();
        
        final RouteTable routeTable = new RouteTable(routeTableModel);

        routeTable.setEnabled(true);
        routeTable.setRowSelectionAllowed(true);
        routeTable.getColumnModel().setColumnSelectionAllowed(false);
        
        routeTable.putClientProperty(TERMINATE_EDIT_ON_FOCUS_LOST, Boolean.TRUE);
        routeTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        routeTable.setPreferredScrollableViewportSize(tablePreferredSize(routeTableModel));        
        routeTable.setFillsViewportHeight(true);
        
                
        routeTable.setSortable(Boolean.valueOf(tableModel.getSortable()));
        routeTable.setName(tableModel.getGuiName());
        
        setPreferredColumnsWidth(routeTableModel, routeTable);
        
        buildValidator(routeTableModel);

        return routeTable;
    }

    private void buildValidator(final RouteTableModel routeTableModel) {
        final PropertyValue routeCount = new DynamicValue(tableModel.getRouteRowCount().getId(), Optional.empty());        
        valueRepository.add(routeCount);
        valueRepository.addValidator(
                ValidatorProxy.newInstanceOf(tableModel.getValidator(),
                                             Pair.class,
                                             ImmutablePair.of(routeTableModel.getTableData(), routeCount)));
    }

    private void setPreferredColumnsWidth(final RouteTableModel model, final JfxTable jfxTable) {
        final ImmutableList<Column> tableHeader = model.getTableHeader();

        int i = 0;
        for (final Column column : tableHeader) {
            final TableColumn c = jfxTable.getColumnModel().getColumn(i++);
            c.setPreferredWidth(column.getWidth());
        }
    }

    private Dimension tablePreferredSize(RouteTableModel model) {
        final int height = JfxUtils.getHeightForLines(NumberUtils.toInt(tableModel.getVisibleRows()));
        final int width = model.getColumnsLenght();

        return new Dimension(width, height);
    }
    
    
}
