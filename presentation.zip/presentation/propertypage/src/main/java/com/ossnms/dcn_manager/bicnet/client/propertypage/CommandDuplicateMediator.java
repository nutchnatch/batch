package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownMediatorPropertyNames;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepositorySingleton;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForUpdate;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.WellKnownPropertiesAddOrModify;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.MediatorRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DefaultManageObjectValues;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DynamicIdNameFactory;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.apache.commons.lang3.tuple.ImmutablePair;

import javax.annotation.Nonnull;

/**
 * Start point to call the Duplicate Mediator flow.
 */
public class CommandDuplicateMediator implements Command<IManagedObject> {
    private final MediatorRepository repository;
    private final CommonServices commonServices;
    private final PropertyPagesRepository pagesRepository;

    public CommandDuplicateMediator(final MediatorRepository repository, final CommonServices commonServices) {
        this(repository, commonServices, PropertyPagesRepositorySingleton.getInstance());
    }

    protected CommandDuplicateMediator(final MediatorRepository repository, final CommonServices commonServices,
            final PropertyPagesRepository pagesRepository) {
        this.repository = repository;
        this.commonServices = commonServices;
        this.pagesRepository = pagesRepository;
    }

    @Override
    public void call(@Nonnull final IManagedObject mediator) throws CommandException {
        try {
            int id = ((IMediator) mediator).getId();
            final FullMediatorData model = repository.get(id).get();

            String type = model.getMediator().getMediatorType().name();
            MediatorType mediatorType = commonServices.getStaticConfiguration().findMediatorType(type)
                    .orElseThrow(() -> new CommandException("Mediator type=''{}'' not supported", type));

            final String name = DynamicIdNameFactory.build(repository, mediatorType.guiLabel().orElse(mediatorType.getName()));
            final IMediator mediatorItem = DefaultManageObjectValues.newBasicMediatorItem(mediatorType.getName(), name);

            // Helper for SingleSelection flow
            final PropertyValueFlow propertyValueHelper = new SingleSelectionPropertyValueFlow(buildPropertiesReplacer(name));
            
            final PageDocument<FullMediatorData> document = new PageDocumentForUpdate<>(new ElementsSelection<>(id),
                    repository, propertyValueHelper, commonServices.getDcnPluginHelper().getSessionContext());

            // Parsed propertyPage for the corresponding MediatorType
            final Page page = pagesRepository.getPropertyPage(mediatorType);

            FullMediatorData fullMediatorData = new FullMediatorData(mediatorItem, new MediatorInfo(mediatorItem.getId()));
            // Delegates the execution
            new OpenPropertyPageForNew<>(ImmutablePair.of(fullMediatorData, name), commonServices, mediatorType,
                    document, repository, page).call();
        } catch (final RepositoryException | PropertyValueBuilderException e) {
            throw new CommandException(e);
        }
    }

    private WellKnownPropertiesAddOrModify buildPropertiesReplacer(@Nonnull final String name) {
        return result -> result.modifyOrAdd(WellKnownMediatorPropertyNames.ID_NAME, name);
    }

}
