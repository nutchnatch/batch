package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepositorySingleton;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForUpdate;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.WellKnownPropertiesAddOrModify;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeType;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DefaultManageObjectValues;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DynamicIdNameFactory;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.apache.commons.lang3.tuple.ImmutablePair;

import javax.annotation.Nonnull;

/**
 * Start point to call the Duplicate NE flow.
 */
public class CommandDuplicateNe implements Command<IManagedObject> {
    private final NeRepository repository;
    private final CommonServices commonServices;
    private final PropertyPagesRepository pagesRepository;

    public CommandDuplicateNe(final NeRepository repository, final CommonServices commonServices) {
        this(repository, commonServices, PropertyPagesRepositorySingleton.getInstance());
    }

    protected CommandDuplicateNe(final NeRepository repository, final CommonServices commonServices,
            final PropertyPagesRepository pagesRepository) {
        this.repository = repository;
        this.commonServices = commonServices;
        this.pagesRepository = pagesRepository;
    }

    @Override
    public void call(@Nonnull final IManagedObject ne) throws CommandException {
        try {
            int id = ((INE) ne).getId();
            final FullNeData dummyNe = newDummyNe(id);
            dummyNe.getNe().setId(id);

            final NeType neType = getNeType(dummyNe.getNe().getNeProxyType());

            final PageDocument<FullNeData> document = buildFrameworkDocument(id, dummyNe.getNe().getIdName());

            // Parsed propertyPage for the corresponding NeType
            final Page unmarshalledPropertyPage = pagesRepository.getPropertyPage(neType);

            // Delegates the execution
            new OpenPropertyPageForDuplication<>(
                    ImmutablePair.of(dummyNe, dummyNe.getNe().getIdName()),
                    commonServices, neType,
                    document, repository, unmarshalledPropertyPage).call();
        } catch (final RepositoryException | PropertyValueBuilderException e) {
            throw new CommandException(e);
        }
    }

    private PageDocument<FullNeData> buildFrameworkDocument(@Nonnull Integer id, String dummyName) {
        // Helper for SingleSelection flow
        final PropertyValueFlow propertyValueHelper = new SingleSelectionPropertyValueFlow(buildPropertiesReplacer(dummyName));

        return new PageDocumentForUpdate<>(
                new ElementsSelection<>(id), repository, propertyValueHelper, commonServices.getDcnPluginHelper().getSessionContext());
    }

    private NeType getNeType(String type) throws CommandException {
        return commonServices.getStaticConfiguration().findNeType(type)
                .orElseThrow(() -> new CommandException("Ne type=''{}'' not supported", type));
    }

    private FullNeData newDummyNe(@Nonnull Integer id) throws RepositoryException {
        FullNeData fullNe = repository.get(id)
                .orElseThrow(() -> new RepositoryException("The NE={} is not present in repository", id));

        final String dummyName = DynamicIdNameFactory.build(repository, fullNe.getNe().getNeProxyType());

        return DefaultManageObjectValues.newDummyFullNeData(fullNe, dummyName);
    }

    private WellKnownPropertiesAddOrModify buildPropertiesReplacer(@Nonnull final String name) {
        return result -> result.modifyOrAdd(WellKnownNePropertyNames.ID_NAME, name);
    }
}
