package com.ossnms.dcn_manager.bicnet.client.propertypage;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.math.NumberUtils;

import com.ossnms.dcn_manager.bicnet.client.api.view.MessageBox;
import com.ossnms.dcn_manager.bicnet.client.propertypage.command.PageOkButtonCommand;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.PropertyPage;
import com.ossnms.dcn_manager.bicnet.client.propertypage.view.PropertyPageCommand;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.Type;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.help.DefaultHelpIds;

/**
 * Start point to call the "Open property page for update" flow.
 */
class OpenPropertyPage<ELEMENT> {

    private final MessageBox messageBox;
    private final Type type;
    private final PageDocument<ELEMENT> document;
    private final PropertyPagesRepository repository;
    private final String name;

    private PageOkButtonCommand command;

    OpenPropertyPage(@Nonnull final String name, @Nonnull final CommonServices commonServices,
            @Nonnull final Type type, @Nonnull final PageDocument<ELEMENT> document,
            @Nonnull final PropertyPagesRepository repository) {
        this.name = name;
        this.messageBox = commonServices.getMessageBox();
        this.type = type;
        this.document = document;
        this.repository = repository;
    }

    /**
     * Delegate the execution for the {@link PropertyPageCommand} command.
     * <p>
     * The result of the {@link PropertyPageCommand} execution will be the creation of the Property Page View.
     */
    public void call() throws PropertyValueBuilderException {
        final PropertyPage propertyPage = new PropertyPage(name,
                NumberUtils.toInt(type.getHelpID(), DefaultHelpIds.GENERAL_PROPERTY_PAGE.getValue()), command,
                repository.getPropertyPage(type));

        document.propertyPage(propertyPage);

        new PropertyPageCommand<>(document, messageBox).execute(null);
    }

    public void setCommand(@Nonnull final PageOkButtonCommand command) {
        this.command = command;
    }
}
