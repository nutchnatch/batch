package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

/**
 * Listener to be register on #ValueAction.
 * 
 * @see com.ossnms.dcn_manager.bicnet.client.propertypage.action.ValueActionObserver
 */
public interface ActionStateListener {

    /**
     * Action to enable/disable the listeners.
     * @param writable
     */
    void onWritable(boolean writable);

    /**
     * Action to gets the result of the associated condition chain.
     * 
     * @see com.ossnms.dcn_manager.bicnet.client.propertypage.condition.ConditionChain
     * @param conditionResult
     */
    void onValueFromConditionResult(boolean conditionResult);

    /**
     * Action to clean the component when change it to disable.
     * @param clear
     */
    void onCleanOnDisable(boolean clear);
    
    /**
     * Action to execute a business logic after move a component.
     * @param move
     */
    void onMovable(boolean move);
}
