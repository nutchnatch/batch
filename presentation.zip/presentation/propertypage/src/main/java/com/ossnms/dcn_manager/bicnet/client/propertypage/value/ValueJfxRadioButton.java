package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.coriant.widgets.ClientProperties;
import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Action;
import com.ossnms.tools.jfx.components.JfxRadioButton;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.event.ChangeListener;

public class ValueJfxRadioButton extends JfxRadioButton implements PropertyValue {

 private static final long serialVersionUID = 1057131037778373839L;
    
    private final ValueDescriptor descriptor;

    public ValueJfxRadioButton(@Nonnull final ValueDescriptor descriptor) {
        this.descriptor = descriptor;
        addItemListener(descriptor.getConditionListener());
    }

    @Override
    @Nonnull
    public String getId() {
        return descriptor.getId();
    }

    @Override
    @Nonnull
    public String getContent() {
        return Boolean.valueOf(isSelected()).toString();
    }
    
    @Override
    public void setContent(@Nullable final String content) {
        modifyContent(content);
        setUnmodifiedValue(isSelected());
    }

    @Override public void modifyContent(String content) {
        setSelected(Boolean.valueOf(content));
    }

    @Override
    @Nonnull
    public boolean isChanged() {
        return isValueModified();
    }

    @Override
    public void addConditionListener(final ChangeListener listener) {
        descriptor.getConditionListener().listening(listener);
    }

    @Override
    @Nonnull
    public ImmutableList<Action> getValueActions() {
        return descriptor.getActions();
    }
    
    @Override
    public void onWritable(final boolean enabled) {
        setEnabled(descriptor.enabledVerify(enabled));
    }

    @Override
    public void onValueFromConditionResult(final boolean conditionResult) {
        setSelected(conditionResult);
    }

    @Override
    public void onCleanOnDisable(final boolean clear) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void onMovable(final boolean input) {
        descriptor.setMovable(input);
    }

    @Override
    public boolean isMovable() {
        return descriptor.getMovable().get();
    }
    
    @Override
    public boolean isMandatoryValueBlank() {
        return false;
    }
    
    @Override
    public boolean forceSendOnUpdate() {
        return descriptor.forceSendOnUpdate();
    }
    
    @Override
    public void setForceSendOnUpdate(final boolean alwaysSendOnUpdate) {
        descriptor.setForceSendOnUpdate(alwaysSendOnUpdate);
    }
    
    @Override
    public boolean isInvalidEntry() {
        return Boolean.TRUE.equals(getClientProperty(ClientProperties.INVALID));
    }
    
    @Override
    public void fireStateChange() {
        descriptor.getConditionListener().fireStateChanged();
    }

    @Override
    public boolean supportMultiselection() {
        return descriptor.supportMultiselection();
    }
    
    @Override
    public boolean isUndefined() {
        return !isChanged();
    }

    @Override public void clearConditions() {
        descriptor.getConditionListener().clear();
    }
}
