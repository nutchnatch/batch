package com.ossnms.dcn_manager.bicnet.client.propertypage.controller;

import com.google.common.base.Predicate;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;

import javax.annotation.Nonnull;
import javax.swing.SwingUtilities;

import static com.google.common.base.Preconditions.checkArgument;
import static com.ossnms.dcn_manager.bicnet.client.propertypage.controller.WellKnownPropertiesAddOrModify.EMPTY;

/**
 * Single selection flow occurs when is selected just 1 Element to be opened the PropertyPage.
 */
public class SingleSelectionPropertyValueFlow implements PropertyValueFlow {

    private final WellKnownPropertiesAddOrModify replacer;

    public SingleSelectionPropertyValueFlow(@Nonnull final WellKnownPropertiesAddOrModify replacer) {
        this.replacer = replacer;
    }

    /** Constructor when the #replacer is absent */
    public SingleSelectionPropertyValueFlow() {
        replacer = EMPTY;
    }

    @Override
    public Predicate<PropertyValue> buildFilterForChangedValues() {
        return input -> input.isChanged() || input.forceSendOnUpdate();
    }

    /**
     * Update the elements values for a single selection flow.
     */
    @Override
    public <K> void updatePropertyValueRepository(@Nonnull final PropertyValueRepository valueRepository,
            @Nonnull final ElementsSelection<K> selection) {
        
        checkArgument(selection.getPrimaryProperties().isPresent(), "Invalid singleSelection flow");

        valueRepository.addAll(selection.getPrimaryProperties().get());
        SwingUtilities.invokeLater(() -> replacer.accept(valueRepository));
    }
    
    @Override
    public boolean isDynamicEnableFieldPermitted() {
        return true;
    }
}
