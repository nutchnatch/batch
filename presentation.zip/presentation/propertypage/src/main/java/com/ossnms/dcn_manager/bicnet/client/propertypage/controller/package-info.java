/**
 * Contains the business logic to control the PropertyPage view.
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.controller;