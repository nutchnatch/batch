package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.google.common.collect.Iterables;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.dcn_manager.bicnet.client.api.ObjectUtils;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainProcessException;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainStatus;
import com.ossnms.dcn_manager.bicnet.client.api.chain.ChainTemplate;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.command.PageOkButtonCommand;
import com.ossnms.dcn_manager.bicnet.client.propertypage.command.UpdatePropertyPageOkButtonCommand;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForUpdate;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PropertyValueFlowFactory;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.page.PageBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ContainerType;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.google.common.collect.Iterables.toArray;
import static com.ossnms.dcn_manager.bicnet.client.api.Containers.TYPE_NE_CONTAINER;
import static com.ossnms.dcn_manager.bicnet.client.propertypage.controller.WellKnownPropertiesAddOrModify.EMPTY;
import static java.util.Collections.singletonList;

/**
 * Open NE Containers property page for Update.
 */
public class CommandOpenContainerProperties extends ChainTemplate<IManagedObject[]>
        implements Command<Iterable<IGenericContainer>> {

    private final RepositoryManager repositoryManager;
    private final CommonServices commonServices;
    private final PropertyPagesRepository propertyPagesRepository;
    private final OpenPropertyPagePermissionChecker permissionChecker;

    public CommandOpenContainerProperties(RepositoryManager repositoryManager, CommonServices commonServices,
            PropertyPagesRepository propertyPagesRepository) {
        this.repositoryManager = repositoryManager;
        this.commonServices = commonServices;
        this.propertyPagesRepository = propertyPagesRepository;
        this.permissionChecker = new OpenPropertyPagePermissionChecker(commonServices);
    }

    @Override protected ChainStatus process(@Nonnull final IManagedObject[] elements) throws ChainProcessException {
        try {
            final Iterable<IGenericContainer> containers = ObjectUtils.filterBy(elements, IGenericContainer.class);

            if (!Iterables.isEmpty(containers)) {
                call(containers);

                return ChainStatus.STOP;
            }

            return ChainStatus.CONTINUE;
        } catch (final Exception e) {
            throw new ChainProcessException(e);
        }
    }

    @Override public void call(final Iterable<IGenericContainer> containers) throws CommandException {
        final IGenericContainer containerPrimary = Iterables.getFirst(containers, new GenericContainerItem());

        ContainerType containerType = commonServices.getStaticConfiguration().findContainerType(TYPE_NE_CONTAINER)
                .orElseThrow(() -> new CommandException("Container type=''{}'' not supported", TYPE_NE_CONTAINER));

        final PropertyValueFlow propertyValueHelper = new PropertyValueFlowFactory()
                .create(EMPTY, Iterables.size(containers));

        try {
            final PageDocument<IGenericContainer> document = new PageDocumentForUpdate<>(
                    buildSelection(containers, containerPrimary), repositoryManager.getContainerRepository(),
                    propertyValueHelper, commonServices.getDcnPluginHelper().getSessionContext());

            final OpenPropertyPage<IGenericContainer> delegate = new OpenPropertyPage<>(
                    containerPrimary.getIdName(), commonServices, containerType, document,
                    propertyPagesRepository);

            if (!permissionChecker.isChannelPropertiesReadOnly(toArray(containers, IGenericContainer.class))) {
                final PageOkButtonCommand command = new UpdatePropertyPageOkButtonCommand<>(containers,
                        repositoryManager.getContainerRepository(), commonServices.getDcnPluginHelper().getSessionContext());
                delegate.setCommand(command);
            }

            delegate.call();
        } catch (final PropertyValueBuilderException e) {
            throw new CommandException(e);
        }
    }

    private ElementsSelection<Integer> buildSelection(final Iterable<IGenericContainer> elements,
            final IGenericContainer primary) throws CommandException, PropertyValueBuilderException {

        final Iterable<Integer> secondariesID = StreamSupport.stream(elements.spliterator(), false)
                .filter(input -> input.getId() != primary.getId()).map(IGenericContainerId::getId)
                .collect(Collectors.toList());

        ContainerType containerType = commonServices.getStaticConfiguration().findContainerType(TYPE_NE_CONTAINER)
                .orElseThrow(() -> new CommandException("Container type='{}' not supported", TYPE_NE_CONTAINER));
        final PropertyValueRepository repository = new PropertyValueRepositoryImpl(
                new SingleSelectionPropertyValueFlow());
        new PageBuilder(propertyPagesRepository.getPropertyPage(containerType), repository).build();
        final Collection<Map<String, String>> secondariesTemplates = singletonList(repository.allSavableValues());

        return new ElementsSelection<>(primary.getId()).secondariesTemplates(secondariesTemplates)
                .secondariesId(secondariesID);
    }
}