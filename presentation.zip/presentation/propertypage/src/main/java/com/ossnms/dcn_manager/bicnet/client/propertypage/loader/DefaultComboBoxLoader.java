package com.ossnms.dcn_manager.bicnet.client.propertypage.loader;

import com.google.common.base.Function;
import com.google.common.collect.FluentIterable;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Choice;
import com.ossnms.tools.jfx.components.JfxComboBox.ItemData;

import javax.annotation.Nonnull;

public class DefaultComboBoxLoader implements Loader<Iterable<ItemData>> {

    private final Iterable<Choice> choices;
    
    public DefaultComboBoxLoader(Iterable<Choice> choices) {
        this.choices = choices;
    }

    @Override
    public Iterable<ItemData> load() {
        return FluentIterable.from(choices).transform(new Function<Choice, ItemData>() {
            @Override
            public ItemData apply(@Nonnull final Choice input) {
                return new ItemData(input.getContent(), input.getChoiceId());
            }
        });
    }
}
