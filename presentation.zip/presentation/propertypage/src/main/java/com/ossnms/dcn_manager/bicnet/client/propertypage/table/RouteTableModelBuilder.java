package com.ossnms.dcn_manager.bicnet.client.propertypage.table;

import com.google.common.base.Function;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Table;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.Column;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueTypeFactory;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Default;
import com.ossnms.dcn_manager.core.jaxb.propertypage.TableData;
import com.ossnms.dcn_manager.core.jaxb.propertypage.TableHeader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.TableModel;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.Builder;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;
import java.util.Iterator;

import static org.apache.commons.lang3.ArrayUtils.isNotEmpty;
import static org.apache.commons.lang3.math.NumberUtils.toInt;

public class RouteTableModelBuilder implements Builder<RouteTableModel> {

    private final TableModel tableModel;
    private final PropertyValueRepository valueRepository;

    public RouteTableModelBuilder(@Nonnull final TableModel tableModel, @Nonnull final PropertyValueRepository valueRepository) {
        this.tableModel = tableModel;
        this.valueRepository = valueRepository;
    }

    @Override
    @Nonnull
    public RouteTableModel build() {
        final ImmutableList<Column> tableHeader = buildTableHeader();
        final Table<Integer, Column, PropertyValue> tableData = buildTableData(tableHeader);

        return new RouteTableModel(tableData, tableHeader);
    }

    @Nonnull
    private ImmutableList<Column> buildTableHeader() {
        return FluentIterable.from(tableModel.getTableHeader())
                .transform(new Function<TableHeader, Column>() {
                    @Override
                    public Column apply(@Nonnull final TableHeader input) {
                        return new Column(ColumnId.valueOf(input.getId()), 
                                          input.getName(), 
                                          toInt(input.getColumnWidth()), 
                                          Boolean.valueOf(input.getRequired()));
                    }
                }).toList();
    }
    
    private Table<Integer, Column, PropertyValue> buildTableData(@Nonnull final ImmutableList<Column> tableHeader) {
        final Table<Integer, Column, PropertyValue> tableData = HashBasedTable.create();
        final int maxRows = NumberUtils.toInt(tableModel.getAutogenerateRows(), 1);
        
        for (int row = 0; row < maxRows; row++) {
            final Iterator<Column> tableHeaderIterator = tableHeader.iterator();
            for (final PropertyValue propertyValue : getTableData(row)) {
                tableData.put(row, tableHeaderIterator.next(), propertyValue);
            }
        }
        
        return tableData;
    }

    @Nonnull
    private ImmutableList<PropertyValue> getTableData(final int row) {
        return FluentIterable.from(tableModel.getTableData())
                .transform(new Function<TableData, PropertyValue>() {
                    @Override
                    public PropertyValue apply(final TableData input) {
                        try {
                            return (PropertyValue) ValueTypeFactory.createOf(generateRowDynamicValues(input.getValue(), row), valueRepository);
                        } catch (final PropertyValueBuilderException e) {
                            throw new IllegalStateException(e);
                        }
                    }
                }).toList();
    }

    @Nonnull
    private Value generateRowDynamicValues(@Nonnull final Value input, final int row) {
        final Value value = cloneValue(input);
        
        final String name = createRowName(value.getId(), row);

        value.setId(name);
        value.setGuiName(name);

        if (Boolean.valueOf(value.getIncrement())) {
            final Default defaultValue = new Default();
            defaultValue.setContent((String.valueOf(row + 1)));
            value.setDefault(defaultValue);
        }

        return value;
    }

    @Nonnull
    private String createRowName(@Nonnull final String name, final int row) {
        final String[] pattern = StringUtils.split(name, "_");
        
        if (isNotEmpty(pattern)) {
            final int lastIndex = pattern.length - 1;
            final int numberOfZeros = StringUtils.countMatches(pattern[lastIndex], "0");
            final String regex = StringUtils.repeat("0", numberOfZeros);

            final int repeatZeros = (numberOfZeros - String.valueOf(row).length());

            final String zeros = StringUtils.repeat("0", repeatZeros < 0 ? 0 : repeatZeros);

            return name.replaceFirst(regex, zeros + row);
        }
        
        return name;
    }
    
    @Nonnull
    private Value cloneValue(@Nonnull final Value input) {
        final Value value = new Value();
        
        value.setId(input.getId());
        value.setIncrement(input.getIncrement());
        value.setDefault(input.getDefault());
        value.setAddressType(input.getAddressType());
        value.setMultiselection(input.getMultiselection());
        value.setValidator(input.getValidator());
        value.setIncrement(input.getIncrement());
        value.setReadOnly(input.getReadOnly());
        value.setAllowedContent(input.getAllowedContent());
        value.setMaxLenght(input.getMaxLenght());
        value.setType(input.getType());
        value.getAction().addAll(ImmutableList.copyOf(input.getAction()));
        
        return value;        
    }
}
