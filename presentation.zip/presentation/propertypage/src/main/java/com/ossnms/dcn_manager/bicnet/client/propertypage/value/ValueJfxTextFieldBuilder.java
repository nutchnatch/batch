package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;

import static java.util.Optional.ofNullable;

public final class ValueJfxTextFieldBuilder extends ValueBuilder<ValueJfxTextField> {

    public ValueJfxTextFieldBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        super(value, valueRepository);
    }

    @Override
    @Nonnull
    public ValueJfxTextField buildComponent() {
        
        final ValueJfxTextField jfxTextField = new ValueJfxTextField(
                new ValueDescriptor(getValue().getId(), getValue().getAction(), getValue().getMultiselection(), getValueRepository().isDynamicEnableFieldPermitted()));
        
        setBasicComponentValues(jfxTextField);

        jfxTextField.setMandatoryEntry(Boolean.valueOf(getValue().getMandatory()));
        jfxTextField.setColumns(NumberUtils.toInt(getValue().getColumns()));
        
        jfxTextField.setContent(buildDefaultValue());

        ofNullable(getValue().getPrompt()).ifPresent(jfxTextField::setPrompt);

        jfxTextField.limitText(buildMaxLength());
        jfxTextField.setValidCharacters(buildAllowedContent());
        jfxTextField.setProhibitedCharacters(buildForbiddenContent());
        
        return jfxTextField;
    }
}
