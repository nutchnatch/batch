package com.ossnms.dcn_manager.bicnet.client.propertypage.condition;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Chain o conditions to be verifiable.
 */
public class ConditionChain implements ChangeListener, ConditionState {

    private Optional<ConditionState> condition = Optional.empty();
    private final List<ChangeListener> listeners;

    public ConditionChain() {
        this.listeners = new ArrayList<>();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean verify() {
        return condition.map(ConditionState::verify).orElse(false);
    }

    /**
     * @see ChangeListener#stateChanged(ChangeEvent)
     */
    @Override
    public void stateChanged(@Nullable final ChangeEvent e) {
        for (final ChangeListener listener : listeners) {
            listener.stateChanged(e);
        }
    }

    /**
     * Add listener to be observer.
     * 
     * @param valueActionListener
     */
    public void listening(@Nonnull final ChangeListener valueActionListener) {
        listeners.add(valueActionListener);
    }

    /**
     * Set the root Condition of the chain.
     * 
     * @param condition
     * @return
     */
    @Nonnull
    public ConditionChain setCondition(@Nonnull final ConditionState condition) {
        this.condition = Optional.of(condition);
        return this;
    }
}
