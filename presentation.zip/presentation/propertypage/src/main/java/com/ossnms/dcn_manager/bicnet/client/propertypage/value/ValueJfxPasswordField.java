package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.util.crypt.IEncrypterDecrypter;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Action;
import com.ossnms.tools.jfx.components.JfxPasswordField;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.event.ChangeListener;

import static org.apache.commons.lang3.ArrayUtils.isNotEmpty;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

/**
 * Property value for Passwords fields.
 */
public class ValueJfxPasswordField extends JfxPasswordField implements PropertyValue {

    private static final long serialVersionUID = -4791600353641221245L;

    private final ValueDescriptor descriptor;
    private final String coding;
    private final IEncrypterDecrypter encrypterDES;

    public ValueJfxPasswordField(@Nonnull final ValueDescriptor descriptor, @Nonnull final String coding, @Nonnull final IEncrypterDecrypter encrypterDES) {
        this.descriptor = descriptor;
        this.coding = coding;
        this.encrypterDES = encrypterDES;
        addDocumentListener(descriptor.getConditionListener());
    }

    @Override
    @Nonnull
    public String getId() {
        return descriptor.getId();
    }

    /**
     * Returns a encrypted password, following the rules:
     * 1. Encoding the password when the encoding type is present ({@link #coding}).
     * 2. Encrypt in DES Encryption format.
     *
     * @return A encrypted password or empty for null value.
     * @see PasswordDigest
     */
    @Override
    @Nonnull
    public String getContent() {
        final char[] pwdCharArray = getPassword();

        if (isNotEmpty(pwdCharArray)) {
            final String pwd = String.valueOf(pwdCharArray);
            if (isChanged()) {
                return PasswordDigest.createOf(encrypterDES, coding, pwd);
            }
            return pwd;
        }

        return EMPTY;
    }

    @Override
    public void setContent(@Nullable final String input) {
        modifyContent(input);
        if (!isUndefined()) {
            setUnmodifiedValue(isNotEmpty(input) ? input : EMPTY);
        }
    }

    @Override public void modifyContent(String input) {
        if (descriptor.isMultipleValue(input)) {
            setUndefined(true);
        } else {
            setText(input);
        }
    }

    @Override
    @Nonnull
    public boolean isChanged() {
        return isValueModified();
    }

    @Override
    public void addConditionListener(@Nonnull final ChangeListener listener) {
        descriptor.getConditionListener().listening(listener);
    }

    @Override
    @Nonnull
    public ImmutableList<Action> getValueActions() {
        return descriptor.getActions();
    }

    @Override
    public void onWritable(final boolean enabled) {
        setEnabled(descriptor.enabledVerify(enabled));
    }

    @Override
    public void onCleanOnDisable(final boolean clear) {
        setText(clear ? null : getContent());
    }

    @Override
    public void onValueFromConditionResult(final boolean conditionResult) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void onMovable(final boolean input) {
        descriptor.setMovable(input);
    }

    @Override
    public boolean isMovable() {
        return descriptor.getMovable().get();
    }

    @Override
    @Nonnull
    public String toString() {
        return MoreObjects.toStringHelper(this).add("Id", descriptor.getId()).toString();
    }

    @Override
    public boolean isMandatoryValueBlank() {
        if (isMandatoryEntry()) {
            return isEmpty(getContent());
        }
        return false;
    }

    @Override
    public boolean forceSendOnUpdate() {
        return descriptor.forceSendOnUpdate();
    }

    @Override
    public void setForceSendOnUpdate(final boolean alwaysSendOnUpdate) {
        descriptor.setForceSendOnUpdate(alwaysSendOnUpdate);
    }

    @Override
    public void fireStateChange() {
        descriptor.getConditionListener().fireStateChanged();
    }

    @Override
    public boolean supportMultiselection() {
        return descriptor.supportMultiselection();
    }

    @Override public void clearConditions() {
        descriptor.getConditionListener().clear();
    }
}
