package com.ossnms.dcn_manager.bicnet.client.propertypage.table;

import com.coriant.widgets.text.PTextField;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.Column;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor.AddressCellEditor;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor.PortCellEditor;
import com.ossnms.tools.jfx.table.JfxTable;

import javax.annotation.Nonnull;
import javax.swing.DefaultCellEditor;
import javax.swing.table.TableCellEditor;
import java.awt.GridLayout;

public class RouteTable extends JfxTable {

    private static final long serialVersionUID = 6968228625565225465L;

    public RouteTable(@Nonnull final RouteTableModel model) {
        super(model);
        this.setLayout(new GridLayout());
        this.setDefaultRenderer(Object.class, new RouteTableCellRenderer());
    }

    public RouteTableModel getRouteTableModel() {
        return (RouteTableModel) getModel();
    }

    @Override
    public TableCellEditor getCellEditor(int row, int column) {
        final TableCellEditor editor;

        final int modelColumn = convertColumnIndexToModel(column);
        final Object value = getRouteTableModel().getPropertyValueAt(row, modelColumn);
        final Column header = getRouteTableModel().getTableHeader().get(modelColumn);

        switch (header.getId()) {
            case ADDRESS:
                editor = new AddressCellEditor((PTextField) value);
                break;
    
            case PORT:
                editor = new PortCellEditor((PTextField) value);
                break;
    
            default:
                editor = new DefaultCellEditor((PTextField) value);
                break;
        }

        return editor;
    }

   
}
