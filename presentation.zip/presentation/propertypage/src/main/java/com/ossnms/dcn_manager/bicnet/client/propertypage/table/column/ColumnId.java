package com.ossnms.dcn_manager.bicnet.client.propertypage.table.column;

public enum ColumnId {
    PRIORITY,
    USED,
    COST,
    ADDRESS,
    PORT,
    TID,
    GNE_NAME,
    GNE_TID,
    GNE_TYPE,
    DOMAIN_NAME,
    SYSNAME,
    SFTP_GATEWAY;
}
