package com.ossnms.dcn_manager.bicnet.client.propertypage.validator;

import com.coriant.widgets.text.PValidationEvent;
import com.coriant.widgets.text.PValidationException;
import com.coriant.widgets.text.PValidationListener;
import com.ossnms.tools.jfx.JfxAddress;
import org.apache.commons.lang3.StringUtils;

public class NsapIpValidator implements PValidationListener {

    private static final boolean PORT_REQUIRED = true;
    private static final String PORT_SEPARATOR = ":";

    @Override
    public void validate(PValidationEvent event) throws PValidationException {
        try {
            final String text = event.getDocument().getText(0, event.getDocument().getLength());
            
            if (StringUtils.isNotEmpty(text)) {
                if (text.contains(PORT_SEPARATOR) && JfxAddress.isValidIPandPort(text, PORT_REQUIRED)) {
                    return;

                } else if (JfxAddress.isValidIP(text)) {
                    return;

                } else if (JfxAddress.isValidNSAP(text)) {
                    return;
                }
                
                throw new PValidationException("Invalid Address format");
            }
        } catch (final Exception e) {
            throw new PValidationException(e);
        }
    }
}