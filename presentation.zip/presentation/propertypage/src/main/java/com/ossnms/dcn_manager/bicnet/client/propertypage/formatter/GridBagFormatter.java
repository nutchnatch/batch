package com.ossnms.dcn_manager.bicnet.client.propertypage.formatter;

import com.ossnms.tools.jfx.JfxUtils;

import javax.annotation.Nonnull;
import java.awt.GridBagConstraints;
import java.awt.Insets;

/**
 * #GridBagConstraints factory for construction of the Dynamic Form Panel.
 */
final class GridBagFormatter {

    /** Specifies the number of cells in a row for the component's display area */
    private static final int TEXT_CELL_DISPLAY_AREA = 1;

    /**
     * Must be greater than #TEXT_CELL_DISPLAY_AREA, because must resize the component both horizontally and
     * vertically
     */
    private static final int AREA_CELL_DISPLAY_AREA = TEXT_CELL_DISPLAY_AREA + 1;

    private GridBagFormatter() {
    }

    /**
     * Constraints to build a JfxTable component.
     * 
     * @param row Sets the gridy
     * @param column Sets the gridx
     * @return
     */
    @Nonnull
    public static GridBagConstraints tableConstraints(int row, int column) {
        final GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.BASELINE_LEADING;
        constraints.fill = GridBagConstraints.BOTH;
        constraints.gridwidth = AREA_CELL_DISPLAY_AREA;
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.insets = new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0);

        return constraints;
    }

    /**
     * Constraints to build a JfxButton for a JfxTable component.
     * 
     * @param row Sets the gridy
     * @param column Sets the gridx
     * @return
     */
    @Nonnull
    public static GridBagConstraints tableButtonConstraints(int row, int column) {
        final GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.BASELINE_LEADING;
        constraints.fill = GridBagConstraints.NONE;
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.gridwidth = AREA_CELL_DISPLAY_AREA;
        constraints.insets = new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0);

        return constraints;
    }

    /**
     * Constraints to build a JfxCheckBox component.
     * 
     * @param row Sets the gridy
     * @param column Sets the gridx
     * @return
     */
    @Nonnull
    public static GridBagConstraints toggleConstraints(int row, int column) {
        final GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.BASELINE_LEADING;
        constraints.fill = GridBagConstraints.NONE;
        constraints.gridwidth = AREA_CELL_DISPLAY_AREA;
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.insets = new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0);

        return constraints;
    }

    /**
     * Constraints to build a JfxLabel component.
     * 
     * @param row Sets the gridy
     * @param column Sets the gridx
     * @return
     */
    @Nonnull
    public static GridBagConstraints labelConstraints(int row, int column) {
        final GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.BASELINE_LEADING;
        constraints.fill = GridBagConstraints.NONE;
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.insets = new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS,
                JfxUtils.MARGIN_BETWEEN_CAPTION_AND_MANDATORY_FIELD);

        return constraints;
    }

    /**
     * Constraints to build a JfxText component.
     * 
     * @param row Sets the gridy
     * @param column Sets the gridx
     * @return
     */
    @Nonnull
    public static GridBagConstraints horizontalFillConstraints(int row, int column) {
        final GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.BASELINE_LEADING;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.gridwidth = TEXT_CELL_DISPLAY_AREA;
        constraints.weightx = 1.0;
        constraints.weighty = 1.0;
        constraints.insets = new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0);

        return constraints;
    }

    /**
     * Constraints to build a JfxSpinner component.
     * 
     * @param row Sets the gridy
     * @param column Sets the gridx
     * @return
     */
    @Nonnull
    public static GridBagConstraints numberConstraints(int row, int column) {
        final GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.BASELINE_LEADING;
        constraints.fill = GridBagConstraints.NONE;
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.gridwidth = 1;
        constraints.weightx = 1.0;
        constraints.weighty = 1.0;
        constraints.insets = new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0);

        return constraints;
    }

    /**
     * Constraints to build a Composable component.
     * 
     * @param row Sets the gridy
     * @param column Sets the gridx
     * @return
     */
    @Nonnull
    public static GridBagConstraints basicConstraints(int row, int column) {
        final GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.BASELINE_LEADING;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.insets = new Insets(0, 0, 0, 0);

        return constraints;
    }
}
