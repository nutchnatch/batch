package com.ossnms.dcn_manager.bicnet.client.propertypage.condition;

/**
 * The conditions type from a JAX-B entity {@link com.ossnms.dcn_manager.core.jaxb.propertypage.Condition}.
 * 
 * @see com.ossnms.dcn_manager.core.jaxb.propertypage.Condition#getType()
 */
public enum ConditionType {
   simple, composable;
}
