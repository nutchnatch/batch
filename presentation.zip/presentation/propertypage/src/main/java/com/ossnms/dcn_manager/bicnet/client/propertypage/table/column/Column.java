package com.ossnms.dcn_manager.bicnet.client.propertypage.table.column;

import javax.annotation.Nonnull;

public class Column {

    private final ColumnId id;
    private final String name;
    private final int width;
    private final boolean required;
    
    public Column(@Nonnull final ColumnId id, @Nonnull final String name, @Nonnull final int width, boolean required) {
        super();
        this.id = id;
        this.name = name;
        this.width = width;
        this.required = required;
    }
    
    public ColumnId getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getWidth() {
        return width;
    }

    public boolean isRequired() {
        return required;
    }
}
