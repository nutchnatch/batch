package com.ossnms.dcn_manager.bicnet.client.propertypage.page;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.PropertyGroup;
import com.ossnms.tools.jfx.components.JfxTitledBorder;

import javax.annotation.Nonnull;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.border.CompoundBorder;
import java.util.Optional;

/**
 * The component that have a list of #Property and/or a list of others #PropertyGroup.
 */
public class PropertyGroupPanelBuilder {

    private static final int BORDER_SIZE = 6;

    private final PropertyGroup propertyGroup;
    private final PropertyValueRepository valueRepository;

    /**
     * @param propertyGroup The propertyGroup that contains a list of #PropertyGroup / #Property.
     * @param valueRepository The repository to store #PropertyValue
     */
    public PropertyGroupPanelBuilder(@Nonnull PropertyGroup propertyGroup,  @Nonnull PropertyValueRepository valueRepository) {
        this.propertyGroup = propertyGroup;
        this.valueRepository = valueRepository;
    }

    /**
     * Builds the JPanel(#PropertyGroup) with all #Property.
     */
    @Nonnull
    public JPanel build() throws PropertyValueBuilderException {
        final JPanel mainPanel = createMainPanel(PropertyGroupAlignType.valueOf(propertyGroup.getAlignNext()));

        return new PropertyGroupItemsFactory(propertyGroup, valueRepository).create(mainPanel);
    }
        
    /*
     * Creates the main panel with a GUI style, and setting the Title when present.
     */
    @Nonnull
    private JPanel createMainPanel(PropertyGroupAlignType alignType) {
        final Optional<String> title = Optional.ofNullable(propertyGroup.getTitle());

        final JPanel panel = new JPanel();
        
        panel.setLayout(new BoxLayout(panel, alignType == PropertyGroupAlignType.adjacent ? BoxLayout.X_AXIS : BoxLayout.Y_AXIS));

        if (title.isPresent()) {
            panel.setBorder(new CompoundBorder(new JfxTitledBorder(title.get()), BorderFactory.createEmptyBorder(0, BORDER_SIZE, 0, BORDER_SIZE)));
        }

        return panel;
    }
}
