package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.tools.jfx.JfxFormPanel;
import org.apache.commons.lang3.builder.Builder;

import javax.swing.JScrollPane;
import java.awt.Component;
import java.awt.Dimension;

public class JScrollPaneBuilder implements Builder<JScrollPane> {

    private final Component component;

    public JScrollPaneBuilder(Component component) {
        super();
        this.component = component;
    }

    @Override
    public JScrollPane build() {
        final JScrollPane scroll = new JScrollPane(component, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        final Dimension dim = scroll.getPreferredSize();
        dim.width += JfxFormPanel.DEFAULT_HORIZONTAL_GAP;
        dim.height += JfxFormPanel.DEFAULT_VERTICAL_GAP;

        scroll.setPreferredSize(dim);
        scroll.setMinimumSize(dim);

        return scroll;
    }
}
