package com.ossnms.dcn_manager.bicnet.client.propertypage.page;

import com.ossnms.dcn_manager.bicnet.client.propertypage.action.ValueAction;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PageGlobalVariable;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.StaticConfigurationValue;
import com.ossnms.dcn_manager.core.jaxb.propertypage.GlobalVariable;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Static;
import com.ossnms.dcn_manager.core.jaxb.propertypage.TabbedPane;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import java.awt.BorderLayout;
import java.util.Collection;
import java.util.stream.Collectors;

import static com.ossnms.dcn_manager.bicnet.client.propertypage.action.ValueActionObserver.newInstance;

/**
 * PropertyPage main builder.
 * 
 * Responsible to start the PropertyPage builder chain.
 */
public class PageBuilder {
    private static final Logger LOGGER = LoggerFactory.getLogger(PageBuilder.class);
    
    private final Page page;
    private final PropertyValueRepository valueRepository;

    /**
     * @param page Page that contains all components to build a PropertyPage.
     * @param valueRepository Repository that contains all Value objects of the PropertyPage.
     */
    public PageBuilder(@Nonnull final Page page, @Nonnull final PropertyValueRepository valueRepository) {
        this.page = page;
        this.valueRepository = valueRepository;
    }

    /**
     * Starts the PropertyPage builder chain.
     */
    @Nonnull
    public JScrollPane build() throws PropertyValueBuilderException {
        LOGGER.info("Building started for property pages name={}, version={}", page.getTitle(), page.getVersion());
        
        addAllGlobalVariablesToRepository();
        addAllStaticValuesToRepository();

        final JPanel rootPanel = addAllTabbedPaneToPage();

        registerGlobalVariablesListerners(registerAllActions());
        fireStateChangedForAllValues();

        return new JScrollPane(rootPanel);
    }

    /*
     * PageGlobalVariables must be register on PropetyValue listener, to be able to apply the PageGlobalVariable objects changes.
     */
    private void registerGlobalVariablesListerners(final Collection<ValueAction> actions) {
        valueRepository.allValues().stream()
                .filter(PageGlobalVariable.class::isInstance)
                .map(PageGlobalVariable.class::cast)
                .forEach(globalVariable ->
                    actions.stream()
                            .map(ValueAction::getListener)
                            .filter(PropertyValue.class::isInstance)
                            .map(PropertyValue.class::cast)
                            .forEach(value -> value.addConditionListener(globalVariable)));
    }
    
    /*
     * Add all #GlobalVariable to #ValueRepository.
     */
    private void addAllGlobalVariablesToRepository() {
        for (final GlobalVariable globalVariable : page.getGlobalVariable()) {
            valueRepository.add(new PageGlobalVariable(globalVariable));
        }
    }
    
    /*
     * Add all #Static configuration values to #ValueRepository.
     */
    private void addAllStaticValuesToRepository() {
        for (final Static staticConfigurationValue : page.getStatic()) {
            valueRepository.add(new StaticConfigurationValue(staticConfigurationValue));
        }
    }

    private JPanel addAllTabbedPaneToPage() throws PropertyValueBuilderException {
        final JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.add(buildAllTabbedPane(), BorderLayout.CENTER);
        
        return rootPanel;
    }

    /*
     * Updates the state between ValueAction and PropertyValue.
     */
    private void fireStateChangedForAllValues() {
        valueRepository.allValues().forEach(PropertyValue::fireStateChange);
    }
    
    /*
     * Build all actions associated with the #PropertyValue list.
     * 
     * @see com.ossnms.dcn_manager.bicnet.client.propertypage.action.ValueActionObserver
     */
    private Collection<ValueAction> registerAllActions() {
        return valueRepository.allValues().stream()
                .map(value -> newInstance(valueRepository, value.getValueActions(), value).registerActionListener())
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
    }

    /*
     * Build all #TabbedPane to be associated with a #Page.
     */
    @Nonnull
    private JTabbedPane buildAllTabbedPane() throws PropertyValueBuilderException {
        final JTabbedPane mainTabbedPane = new JTabbedPane();

        for (final TabbedPane tabbedPane : page.getTabbedPane()) {
            new TabbedPaneBuilder(tabbedPane, valueRepository).build()
                    .ifPresent(panel -> mainTabbedPane.addTab(tabbedPane.getTitle(), panel));
        }
        
        return mainTabbedPane;
    }
}
