package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

import com.google.common.base.Predicate;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;

/**
 * Abstraction for PropertyValue update and filters.
 * 
 * @param <K> PropertyValue Id
 */
public interface PropertyValueFlow {

    /**
     * @return Create a filter to verify if the values was changed.
     */
    Predicate<PropertyValue> buildFilterForChangedValues();
    
    /**
     * Apply the changed properties on Value Repository;
     */
    <K> void updatePropertyValueRepository(PropertyValueRepository valueRepository, ElementsSelection<K> selection);
    
    /**
     * @return true if the PropertyValue can be enable/disable dynamically.
     */
    boolean isDynamicEnableFieldPermitted();
}
