package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import com.ossnms.tools.jfx.JfxUtils;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;

public class ValueJfxTextAreaBuilder extends ValueBuilder<ValueJfxTextArea> {

    public ValueJfxTextAreaBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        super(value, valueRepository);
    }

    @Override
    @Nonnull
    public ValueJfxTextArea buildComponent() {
        
        final ValueJfxTextArea jfxTextArea = new ValueJfxTextArea(
                new ValueDescriptor(getValue().getId(), getValue().getAction(), getValue().getMultiselection(), getValueRepository().isDynamicEnableFieldPermitted()));

        setBasicComponentValues(jfxTextArea);
        
        jfxTextArea.setMandatoryEntry(Boolean.valueOf(getValue().getMandatory()));
        jfxTextArea.limitText(buildMaxLength());
        jfxTextArea.setValidCharacters(buildAllowedContent());
        jfxTextArea.setProhibitedCharacters(buildForbiddenContent());
        
        jfxTextArea.setContent(buildDefaultValue());

        jfxTextArea.setRows(NumberUtils.toInt(getValue().getRows()));
        jfxTextArea.setColumns(NumberUtils.toInt(getValue().getColumns()));
        jfxTextArea.setFont(JfxUtils.getFontForTextField());
        
        return jfxTextArea;
    }
}
