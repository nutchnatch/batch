package com.ossnms.dcn_manager.bicnet.client.propertypage.action;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.bicnet.client.propertypage.condition.ConditionChainBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.ActionStateListener;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Action;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Register all actions from a #ActionStateListener.
 */
public final class ValueActionObserver {

    private final List<Action> actions;
    private final ActionStateListener actionStateListener;
    private final PropertyValueRepository valueRepository;

    /**
     * @param valueRepository Repository that contains the #ActionStateListener instance to be associated.
     * @param actions Action to be associated with the #ActionStateListener
     * @param actionStateListener The listener of this #Action list.
     */
    private ValueActionObserver(@Nonnull final PropertyValueRepository valueRepository, @Nonnull final List<Action> actions, @Nonnull final ActionStateListener actionStateListener) {
        this.valueRepository = valueRepository;
        this.actions = actions;
        this.actionStateListener = actionStateListener;
    }
    
    /**
     * Creates the a new instance.
     * @param valueRepository
     * @param actions
     * @param actionNotification
     * @return
     */
    @Nonnull
    public static ValueActionObserver newInstance(@Nonnull final PropertyValueRepository valueRepository, @Nonnull final List<Action> actions, @Nonnull final ActionStateListener actionNotification) {
        return new ValueActionObserver(valueRepository, actions, actionNotification);        
    }

    /**
     * Register all actions with the #ActionStateListener.
     * @return The list of created #ValueAction
     */
    public Collection<ValueAction> registerActionListener() {
        return actions.stream()
                .map(input -> {
                    try {
                        return new ValueAction(actionStateListener, ActionState.valueOf(input.getType()),
                                new ConditionChainBuilder(input.getCondition(), valueRepository).build());
                    } catch (final PropertyValueBuilderException e) {
                        throw Throwables.propagate(e);
                    }
                })
                .collect(Collectors.toList());
    }
}
