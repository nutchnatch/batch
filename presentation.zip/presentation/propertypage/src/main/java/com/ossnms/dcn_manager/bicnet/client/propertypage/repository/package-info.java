/**
 * Repository to store temporally the #PropertyValue implementation.
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;