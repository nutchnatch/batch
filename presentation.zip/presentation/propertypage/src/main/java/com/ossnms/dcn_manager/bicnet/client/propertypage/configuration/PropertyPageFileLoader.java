package com.ossnms.dcn_manager.bicnet.client.propertypage.configuration;

import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;

class PropertyPageFileLoader {
    private static final ClassLoader LOADER = PropertyPageFileLoader.class.getClassLoader();
    private static final String FILE_EXTENTION = ".xml";
    private static final String RELATIVE_PATH = "dcn-manager/propertypages/";
    
    private final XmlFileLoader xmlFileLoader;
    
    public PropertyPageFileLoader() {
        xmlFileLoader = new XmlFileLoader();
    }
    
    @Nonnull
    public Page loadConfiguration(@Nonnull final String source) {
        final String fileName = StringUtils.join(RELATIVE_PATH, source, FILE_EXTENTION);
        return xmlFileLoader.loadConfiguration(Page.class, LOADER.getResource(fileName), new Page());
    }        
}
