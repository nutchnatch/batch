package com.ossnms.dcn_manager.bicnet.client.propertypage.configuration;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.Type;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;

import javax.annotation.Nonnull;

public interface PropertyPagesRepository {

    /**
     * Load the PropertyPages for a Object Type.
     * 
     * @param type That contains the PropertyPages file names.
     * @return The all propertyPages files joined in the Page object.
     * @throws PropertyValueBuilderException
     */
    Page getPropertyPage(@Nonnull final Type type) throws PropertyValueBuilderException;
}