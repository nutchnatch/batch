package com.ossnms.dcn_manager.bicnet.client.propertypage.table;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.ActionStateListener;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.table.JfxTable;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TableButton extends JfxButton implements ActionStateListener, ActionListener, ListSelectionListener {

    private static final long serialVersionUID = -7755525507695666579L;

    private final JfxTable table;

    public TableButton(@Nonnull JfxTable table) {
        super();
        this.table = table;
        this.table.getSelectionModel().addListSelectionListener(this);
        
        addActionListener(this);
    }

    @Override
    public void onWritable(boolean writable) {
        this.setEnabled(writable);
    }

    @Override
    public void onValueFromConditionResult(boolean conditionResult) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void onCleanOnDisable(boolean clear) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void onMovable(boolean move) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void actionPerformed(@Nonnull ActionEvent event) {
        final String action = ((JfxButton) event.getSource()).getActionCommand();
        TableButtonAction.valueOf(action).executeCommand(table);
    }

    @Override
    public void valueChanged(@Nullable ListSelectionEvent e) { }
 }
