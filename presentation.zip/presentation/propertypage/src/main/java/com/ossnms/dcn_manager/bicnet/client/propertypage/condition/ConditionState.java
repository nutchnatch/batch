package com.ossnms.dcn_manager.bicnet.client.propertypage.condition;

/**
 * Verifies the condition state.
 */
public interface ConditionState {
    
    /**
     * Verify the condition chain state. 
     * 
     * @return
     */
    boolean verify();
}
