package com.ossnms.dcn_manager.bicnet.client.propertypage.model;

import com.ossnms.dcn_manager.bicnet.client.propertypage.command.PageOkButtonCommand;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Object Model for property page view.
 */
public class PropertyPage {

    private final String title;
    private final int helpId;
    private final Page page;
    private PageOkButtonCommand applyCommand;

    public PropertyPage(@Nonnull final String title, final int helpId, @Nonnull final Page page) {
        super();
        this.title = title;
        this.helpId = helpId;
        this.page = page;
    }

    public PropertyPage(@Nonnull final String title, final int helpId, @Nonnull final PageOkButtonCommand applyCommand,
            @Nonnull final Page page) {
        this(title, helpId, page);
        this.applyCommand = applyCommand;
    }

    public int getHelpId() {
        return helpId;
    }

    @Nonnull public Optional<PageOkButtonCommand> applyCommand() {
        return Optional.ofNullable(applyCommand);
    }

    @Nonnull public Page getPage() {
        return page;
    }

    @Nonnull public String getTitle() {
        return String.format("%s Properties", title);
    }
}
