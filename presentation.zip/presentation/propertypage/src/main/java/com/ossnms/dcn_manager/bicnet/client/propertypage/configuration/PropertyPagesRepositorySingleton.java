package com.ossnms.dcn_manager.bicnet.client.propertypage.configuration;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.Type;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;

public final class PropertyPagesRepositorySingleton implements PropertyPagesRepository{

    private static final PropertyPagesRepositorySingleton INSTANCE = new PropertyPagesRepositorySingleton();    
    
    private final PropertyPagesRepository repository = new PropertyPagesInMemoryRepository();
    
    private PropertyPagesRepositorySingleton() {
    }
    
    public static PropertyPagesRepositorySingleton getInstance() {
        return INSTANCE;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Page getPropertyPage(Type type) throws PropertyValueBuilderException {
        return repository.getPropertyPage(type);
    }
}
