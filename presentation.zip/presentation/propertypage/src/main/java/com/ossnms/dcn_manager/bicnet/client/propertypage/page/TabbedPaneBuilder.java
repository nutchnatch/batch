package com.ossnms.dcn_manager.bicnet.client.propertypage.page;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.PropertyGroup;
import com.ossnms.dcn_manager.core.jaxb.propertypage.TabbedPane;
import com.ossnms.tools.jfx.JfxUtils;
import org.apache.commons.lang3.BooleanUtils;

import javax.annotation.Nonnull;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownMediatorPropertyNames.NODE_MANAGER_SELECTED;

/**
 * Main component that contains the one or more GroupPanel.
 */
public class TabbedPaneBuilder {

    private static final String COMPONENT_PREFIX = "TAB.";
    
    private final TabbedPane tabbedPane;
    private final PropertyValueRepository valueRepository;

    public TabbedPaneBuilder(@Nonnull TabbedPane tabbedPane, @Nonnull PropertyValueRepository valueRepository) {
        this.tabbedPane = tabbedPane;
        this.valueRepository = valueRepository;
    }

    /**
     * Builds all TabbedPanel in the property page.
     */
    public Optional<JPanel> build() throws PropertyValueBuilderException {
        if (NODE_MANAGER_SELECTED.equals(tabbedPane.getName()) && !isSupportNodeManagerConfiguration()) {
            return Optional.empty();
        }

        final JPanel mainPanel = createMainPanel();

        for (final PropertyGroup propertyGroup : tabbedPane.getPropertyGroup()) {
            mainPanel.add(new PropertyGroupPanelBuilder(propertyGroup, valueRepository).build());
        }
        
        mainPanel.add(Box.createGlue());
        
        return Optional.of(mainPanel);
    }

    private JPanel createMainPanel() {
        final JPanel mainPanel = new JPanel();

        mainPanel.setName(COMPONENT_PREFIX + JfxUtils.toCamelCase(tabbedPane.getTitle()));
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        return mainPanel;
    }

    private boolean isSupportNodeManagerConfiguration() {
        return valueRepository.find(NODE_MANAGER_SELECTED)
                .map(PropertyValue::getContent)
                .map(Boolean::valueOf)
                .filter(BooleanUtils::isTrue)
                .orElse(false);
    }
}
