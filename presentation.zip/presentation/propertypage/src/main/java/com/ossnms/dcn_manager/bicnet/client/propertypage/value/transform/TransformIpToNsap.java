package com.ossnms.dcn_manager.bicnet.client.propertypage.value.transform;

import com.google.common.base.Function;
import com.ossnms.tools.jfx.JfxAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.MalformedURLException;
import java.util.Optional;

import static com.ossnms.tools.jfx.JfxAddress.isValidIPandPort;
import static com.ossnms.tools.jfx.JfxUtils.convertByteArrayToHexString;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

public class TransformIpToNsap implements Function<String, Optional<String>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(TransformIpToNsap.class);
    private static final boolean PORT_REQUIRED = false;

    @Override
    public Optional<String> apply(String input) {
        return tryTransform(input);
    }
    
    public static Optional<String> tryTransform(String input) {
        if (isNotEmpty(input) && isValidIPandPort(input, PORT_REQUIRED)) {
            try {
                final JfxAddress address = new JfxAddress(input);
                return Optional.of(convertByteArrayToHexString(address.getNSAP()));
            } catch (final MalformedURLException e) {
                LOGGER.error(e.getMessage());
            }
        }

        return Optional.empty();
    }
}