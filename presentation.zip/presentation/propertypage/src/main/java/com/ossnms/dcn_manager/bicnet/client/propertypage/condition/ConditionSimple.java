package com.ossnms.dcn_manager.bicnet.client.propertypage.condition;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import org.apache.commons.lang3.tuple.Triple;

import javax.annotation.Nonnull;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Condition to verify the logic {@link #operator} result, between {@link #value} and {@link #literal}. 
 */
public class ConditionSimple implements ConditionState, ChangeListener {

    private final PropertyValue value;
    private final ConditionOperator operator;
    private final String literal;
    private final ConditionChain conditionChain;
    
    public ConditionSimple(@Nonnull Triple<PropertyValue, ConditionOperator, String> condition, @Nonnull ConditionChain conditionChain) {
        this.value = condition.getLeft();
        this.operator = condition.getMiddle();
        this.literal = condition.getRight();
        
        this.conditionChain = conditionChain;
        
        this.value.addConditionListener(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean verify() {
        return operator.verify(value.getContent(), literal);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stateChanged(ChangeEvent e) {
        conditionChain.stateChanged(e);
    }
}
