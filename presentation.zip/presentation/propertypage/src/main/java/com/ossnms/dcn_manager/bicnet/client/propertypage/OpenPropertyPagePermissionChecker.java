package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;

import javax.annotation.Nonnull;

/**
 * Helper to verify the Elements permission when tries to open properties pages for edit or view.
 */
public class OpenPropertyPagePermissionChecker {

    private final CommonServices commonServices;

    public OpenPropertyPagePermissionChecker(@Nonnull final CommonServices commonServices) {
        this.commonServices = commonServices;
    }

    boolean isChannelPropertiesReadOnly(@Nonnull final IManagedObject[] elements) {
        return !hasPermission(SecureAction.OP_PROPERTIES_CHANNEL_SAN, elements) &&
                hasPermission(SecureAction.OP_PROPERTIES_CHANNEL_RO_SAN);
    }

    public boolean hasPermissionToOpenChannel(@Nonnull final IManagedObject[] elements) {
        return hasPermission(SecureAction.OP_PROPERTIES_CHANNEL_SAN, elements) ||
                hasPermission(SecureAction.OP_PROPERTIES_CHANNEL_RO_SAN);
    }

    boolean isMediatorPropertiesReadOnly(@Nonnull final IManagedObject[] elements) {
        return !hasPermission(SecureAction.OP_PROPERTIES_MEDIATOR_SAN, elements) &&
                hasPermission(SecureAction.OP_PROPERTIES_MEDIATOR_RO_SAN);
    }

    public boolean hasPermissionToOpenMediator(@Nonnull final IManagedObject[] elements) {
        return hasPermission(SecureAction.OP_PROPERTIES_MEDIATOR_SAN, elements) ||
                hasPermission(SecureAction.OP_PROPERTIES_MEDIATOR_RO_SAN);
    }

    boolean isNePropertiesReadOnly(@Nonnull final IManagedObject[] elements) {
        return !hasPermission(SecureAction.OP_PROPERTIES_NE_SAN, elements) &&
                hasPermission(SecureAction.OP_PROPERTIES_NE_RO_SAN, elements);
    }

    public boolean hasPermissionToOpenNE(@Nonnull final IManagedObject[] elements) {
        return hasPermission(SecureAction.OP_PROPERTIES_NE_SAN, elements) ||
                hasPermission(SecureAction.OP_PROPERTIES_NE_RO_SAN, elements);
    }

    boolean isContainerPropertiesReadOnly(@Nonnull final IManagedObject[] elements) {
        return !hasPermission(SecureAction.OP_PROPERTIES_CONTAINER_SAN, elements) &&
                hasPermission(SecureAction.OP_PROPERTIES_CONTAINER_RO_SAN);
    }

    public boolean hasPermissionToOpenContainer(@Nonnull final IManagedObject[] elements) {
        return hasPermission(SecureAction.OP_PROPERTIES_CONTAINER_SAN, elements) ||
                hasPermission(SecureAction.OP_PROPERTIES_CONTAINER_RO_SAN);
    }

    private boolean hasPermission(@Nonnull final SecureAction action , @Nonnull final IManagedObject[] elements) {
        return commonServices.getSecureActionValidation().checkPermission(action, (IManagedObjectId[]) elements);
    }

    private boolean hasPermission(@Nonnull final SecureAction action) {
        return commonServices.getSecureActionValidation().checkPermission(action);
    }
}
