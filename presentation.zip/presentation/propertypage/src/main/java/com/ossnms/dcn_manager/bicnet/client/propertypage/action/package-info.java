/**
 * Responsible to observer and notify changes on GUI components.
 */
package com.ossnms.dcn_manager.bicnet.client.propertypage.action;