package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Action;

import javax.swing.event.ChangeListener;

public abstract class AbstractPropertyValue implements PropertyValue {

    /** {@inheritDoc} */
    @Override
    public void addConditionListener(final ChangeListener listener) {
    }

    /** {@inheritDoc} */
    @Override
    public ImmutableList<Action> getValueActions() {
        return ImmutableList.of();
    }

    /** {@inheritDoc} */
    @Override
    public void onWritable(final boolean writable) {
    }

    /** {@inheritDoc} */
    @Override
    public void onValueFromConditionResult(final boolean conditionResult) {
    }

    /** {@inheritDoc} */
    @Override
    public void onCleanOnDisable(final boolean clear) {
    }

    /** {@inheritDoc} */
    @Override
    public void onMovable(final boolean move) {
    }

    /** {@inheritDoc} */
    @Override
    public boolean isMandatoryValueBlank() {
        return false;
    }

    /** {@inheritDoc} */
    @Override
    public boolean isChanged() {
        return false;
    }

    /** {@inheritDoc} */
    @Override
    public boolean isEnabled() {
        return false;
    }

    /** {@inheritDoc} */
    @Override
    public boolean isInvalidEntry() {
        return false;
    }

    /** {@inheritDoc} */
    @Override
    public void fireStateChange() {
    }

    /** {@inheritDoc} */
    @Override
    public boolean isMovable() {
        return false;
    }

    /** {@inheritDoc} */
    @Override
    public void setForceSendOnUpdate(final boolean alwaysSendOnUpdate) {
    }

    /** {@inheritDoc} */
    @Override
    public boolean supportMultiselection() {
        return false;
    }

    /** {@inheritDoc} */
    @Override
    public boolean isUndefined() {
        return false;
    }

    /**
     * @return The GUI identification
     */
    @Override public String getName() {return "AbstractPropertyValue";}

    /** {@inheritDoc} */
    @Override public void clearConditions() {
    }
}
