package com.ossnms.dcn_manager.bicnet.client.propertypage.value.transform;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.ossnms.tools.jfx.JfxAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.MalformedURLException;
import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.isNotEmpty;

public class TransformNsapToIp implements Function<String, Optional<String>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(TransformIpToNsap.class);
    private static final String SEPARATOR = ":";

    @Override
    public Optional<String> apply(String input) {
        return tryTransform(input);
    }

    public static Optional<String> tryTransform(String input) {
        if (isNotEmpty(input) && JfxAddress.isRfc1277NSAP(input)) {
            try {
                final JfxAddress address = new JfxAddress(input);
                final Integer port = address.getPort() != -1 ? address.getPort() : null;

                return Optional.of(Joiner.on(SEPARATOR).skipNulls().join(address.getIP(), port));
            } catch (final MalformedURLException e) {
                LOGGER.error(e.getMessage());
            }
        }

        return Optional.empty();
    }
}