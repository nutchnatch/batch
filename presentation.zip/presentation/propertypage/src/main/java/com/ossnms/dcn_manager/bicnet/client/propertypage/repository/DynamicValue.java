package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

import javax.annotation.Nonnull;
import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.EMPTY;

/**
 * Dynamic property value to define mutable values for property page items. 
 */
public class DynamicValue extends AbstractPropertyValue {
    
    private final String id;
    private String content;
    
    public DynamicValue(@Nonnull String id, @Nonnull Optional<String> content) {
        super();
        this.id = id;
        this.content = content.orElse(EMPTY);
    }
        
    /** {@inheritDoc} */
    @Override
    public String getId() {
        return id;
    }

    /** {@inheritDoc} */
    @Override
    public String getContent() {
        return content;
    }

    /** {@inheritDoc} */
    @Override
    public void setContent(String content) {
        this.content = content;
    }

    @Override public void modifyContent(String content) {
        this.content = content;
    }

    /** {@inheritDoc} */
    @Override
    public boolean forceSendOnUpdate() {
        return true;
    }
}
