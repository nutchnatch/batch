package com.ossnms.dcn_manager.bicnet.client.propertypage.controller;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.propertypage.job.FetchProperties;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.PropertyPage;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.PropertyPageLabels;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

/**
 * Document to manage the PropertyPage model and the #IFrameworkJob.
 */
public class PageDocumentForUpdate<K, M> extends FrameworkDocument implements PageDocument<M> {

    private static final Logger LOGGER = LoggerFactory.getLogger(PageDocumentForUpdate.class);

    private final ElementsSelection<K> selection;
    private final Repository<K, M> repository;
    private final ISessionContext context;
    private final PropertyValueRepository valueRepository;
    
    private PropertyPage propertyPage;

    public PageDocumentForUpdate(@Nonnull final ElementsSelection<K> selection, @Nonnull final Repository<K, M> repository, @Nonnull final PropertyValueFlow propertyValueHelper, @Nonnull final ISessionContext context) {
        super(DcnPluginHelperSingleton.getInstance());
        this.selection = selection;
        this.repository = repository;
        this.context = context;
        this.valueRepository = new PropertyValueRepositoryImpl(propertyValueHelper);        
    }

    /** {@inheritDoc} */
    @Override
    public PageDocument<M> propertyPage(@Nonnull final PropertyPage propertyPage) {
        this.propertyPage = propertyPage;
        return this;
    }

    /** {@inheritDoc} */
    @Override
    public void execute() {
        addAndExecuteJob(new FetchProperties<>(selection, this, repository, context));
    }

    /** {@inheritDoc} */
    @Override
    public final void setResult(@Nonnull final IFrameworkJob job, final Object result) {
        if (result instanceof ElementsSelection<?>) {
            valueRepository.updateRepository((ElementsSelection<?>) result);
        }

        fireUpdateView(job);
    }

    /** {@inheritDoc} */
    @Override
    public final Object getObject(final Object key) {
        return repository;
    }

    @Override
    public PropertyValueRepository getValueRepository() {
        return valueRepository;
    }

    /** {@inheritDoc} */
    @Override
    public PropertyPage getPropertyPage() {
        return propertyPage;
    }

    /*
     * Must be executed in swing event thread
     */
    private void fireUpdateView(@Nonnull final IFrameworkJob job) {
        String errorMessage = null;

        if (job.hasExceptionOccured()) {
            LOGGER.error("Error on get properties", job.getException());
            errorMessage = PropertyPageLabels.ERROR_ON_OPEN.toString();
        }

        updateData(errorMessage);
    }
}