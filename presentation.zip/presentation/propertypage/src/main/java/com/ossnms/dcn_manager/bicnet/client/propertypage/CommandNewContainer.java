package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.api.command.Command;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownContainerPropertyNames;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepositorySingleton;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForNewObject;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ContainerRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ContainerType;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DefaultManageObjectValues;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DynamicIdNameFactory;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.apache.commons.lang3.tuple.ImmutablePair;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.bicnet.client.api.Containers.TYPE_NE_CONTAINER;

/**
 * Start point to call the New Container flow.
 */
public class CommandNewContainer implements Command<Integer> {
    private final ContainerRepository repository;
    private final CommonServices commonServices;
    private final PropertyPagesRepository pagesRepository;

    public CommandNewContainer(final ContainerRepository repository, final CommonServices commonServices) {
        this(repository, commonServices, PropertyPagesRepositorySingleton.getInstance());
    }

    protected CommandNewContainer(final ContainerRepository repository, final CommonServices commonServices,
            final PropertyPagesRepository pagesRepository) {
        this.repository = repository;
        this.commonServices = commonServices;
        this.pagesRepository = pagesRepository;
    }

    /**
     * {@inheritDoc}
     */
    @Override public void call(@Nonnull final Integer parentId) throws CommandException {
        try {
            ContainerType containerType = commonServices.getStaticConfiguration().findContainerType(TYPE_NE_CONTAINER)
                    .orElseThrow(() -> new CommandException("Container type=''{}'' not supported", TYPE_NE_CONTAINER));

            final String name = DynamicIdNameFactory.build(repository, TYPE_NE_CONTAINER);

            final IGenericContainer containerItem = DefaultManageObjectValues.newBasicNeContainerItem(name, parentId);

            final PageDocument<IGenericContainer> document = new PageDocumentForNewObject<IGenericContainer>()
                    .addOrModify(valueRepository -> valueRepository
                            .modifyOrAdd(WellKnownContainerPropertyNames.ID_NAME, name));

            // Parsed propertyPage for the corresponding ContainerType
            final Page page = pagesRepository.getPropertyPage(containerType);

            // Delegates the execution
            new OpenPropertyPageForNew<>(ImmutablePair.of(containerItem, name), commonServices, containerType, document,
                    repository, page).call();
        } catch (final RepositoryException | PropertyValueBuilderException e) {
            throw new CommandException(e);
        }
    }
}
