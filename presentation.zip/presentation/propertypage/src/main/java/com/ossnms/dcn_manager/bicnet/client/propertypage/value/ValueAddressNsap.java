package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import static org.apache.commons.lang3.StringUtils.EMPTY;

public class ValueAddressNsap extends ValueJfxTextField {

    private static final long serialVersionUID = -2519929651748068678L;

    public ValueAddressNsap(@Nonnull final ValueDescriptor descriptor) {
        super(descriptor);
    }

    @Override
    @Nonnull
    public String getContent() {
        return getText();
    }

    @Override
    public void setContent(@Nullable String content) {
        modifyContent(content);
        if(!isUndefined()){
            setUnmodifiedValue(getText());
        }
    }

    @Override public void modifyContent(String content) {
        if (getDescriptor().isMultipleValue(content)) {
            setUndefined(true);
        } else {
            final String address = content == null ? EMPTY : content;
            setText(address);
        }
    }
}
