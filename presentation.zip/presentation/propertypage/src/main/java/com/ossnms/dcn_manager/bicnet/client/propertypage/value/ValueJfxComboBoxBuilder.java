package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.loader.DefaultComboBoxLoader;
import com.ossnms.dcn_manager.bicnet.client.propertypage.loader.Loader;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import com.ossnms.tools.jfx.components.JfxComboBox.ItemData;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;

public class ValueJfxComboBoxBuilder extends ValueBuilder<ValueJfxComboBox> {

    public ValueJfxComboBoxBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        super(value, valueRepository);
    }

    @Override
    @Nonnull
    protected ValueJfxComboBox buildComponent() throws PropertyValueBuilderException {
        final ValueJfxComboBox jfxComboBox = new ValueJfxComboBox(
                new ValueDescriptor(getValue().getId(), getValue().getAction(), getValue().getMultiselection(), getValueRepository().isDynamicEnableFieldPermitted()));

        fetchValues(jfxComboBox);

        setBasicComponentValues(jfxComboBox);

        jfxComboBox.setMandatoryEntry(Boolean.valueOf(getValue().getMandatory()));
        jfxComboBox.setColumns(NumberUtils.toInt(getValue().getColumns()));
        jfxComboBox.setContent(buildDefaultValue());

        return jfxComboBox;
    }

    private void fetchValues(@Nonnull final ValueJfxComboBox jfxComboBox) throws PropertyValueBuilderException {        
        final Loader<Iterable<ItemData>> comboBoxloader = new DefaultComboBoxLoader(getValue().getChoice());
        
        try {
            for (final ItemData data : comboBoxloader.load()) {
                jfxComboBox.addItem(data);
            }
        } catch (final RepositoryException e) {
            throw new PropertyValueBuilderException(e);
        }
    }
}
