package com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor;

import com.coriant.widgets.ClientProperties;
import com.coriant.widgets.text.PTextField;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;
import javax.swing.DefaultCellEditor;
import javax.swing.InputVerifier;
import javax.swing.JComponent;
import java.io.IOException;
import java.io.ObjectInputStream;

public class PortCellEditor extends DefaultCellEditor {
    private static final long serialVersionUID = 8514868542057948483L;

    private transient InputVerifier verifier;

    public PortCellEditor(@Nonnull PTextField text) {
        super(text);
        this.verifier = new PortInputVerifier();
        getComponent().setInputVerifier(verifier);
    }

    @Override
    public boolean stopCellEditing() {
        if (!verifier.shouldYieldFocus(getComponent())) {
            return false;
        }
        return super.stopCellEditing();
    }

    @Override
    public PTextField getComponent() {
        return (PTextField) super.getComponent();
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        this.verifier = new PortInputVerifier();
        getComponent().setInputVerifier(verifier);
    }
    
    private static class PortInputVerifier extends InputVerifier {
        private static final int MIN_PORT_RANGE = 0;
        private static final int PORT_MAX_RANGE = 65535;

        @Override
        public boolean verify(@Nonnull final JComponent input) {
            final PTextField field = (PTextField) input;
            final String text = field.getText();
            
            return text.isEmpty() || isValidPort(NumberUtils.toInt(text));
        }

        /**
         * @return Always return true for not lock field edition
         */
        @Override
        public boolean shouldYieldFocus(@Nonnull final JComponent input) {
            final PTextField field = (PTextField) input;
            
            final boolean valid = verify(field);

            if (!valid) {
                field.setBackground(CellColor.ERROR.color());
                field.putClientProperty(ClientProperties.INVALID, true);
            } else {
                input.setBackground(CellColor.DEFAULT.color());
                field.putClientProperty(ClientProperties.INVALID, false);
            }

            return true;
        }
        
        private static boolean isValidPort(int port) {
            return port >= MIN_PORT_RANGE && port <= PORT_MAX_RANGE;
        }
    }
}