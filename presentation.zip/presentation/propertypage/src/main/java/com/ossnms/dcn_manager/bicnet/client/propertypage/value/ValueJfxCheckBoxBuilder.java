package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import com.ossnms.tools.jfx.JfxText;

import javax.annotation.Nonnull;

public class ValueJfxCheckBoxBuilder extends ValueBuilder<ValueJfxCheckBox> {

    public ValueJfxCheckBoxBuilder(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) {
        super(value, valueRepository);
    }

    @Override
    @Nonnull
    protected ValueJfxCheckBox buildComponent() {
        final ValueJfxCheckBox jfxCheckBox = new ValueJfxCheckBox(new ValueDescriptor(getValue().getId(), getValue().getAction(), getValue().getMultiselection(), getValueRepository().isDynamicEnableFieldPermitted()));
        final JfxText text = new JfxText(getValue().getBooleanText().getContent());
        
        setBasicComponentValues(jfxCheckBox);
                
        jfxCheckBox.setText(text);
        jfxCheckBox.setMnemonic(text.getMnemonic());
        jfxCheckBox.setContent(buildDefaultValue());

        return jfxCheckBox;
    }
}