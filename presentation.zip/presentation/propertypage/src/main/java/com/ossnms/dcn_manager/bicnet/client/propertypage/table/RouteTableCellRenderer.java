package com.ossnms.dcn_manager.bicnet.client.propertypage.table;

import com.coriant.widgets.text.PTextField;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.ColumnId;
import com.ossnms.tools.jfx.components.JfxLabel;

import javax.annotation.Nonnull;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.Component;
import java.util.Optional;

/**
 * Render the Route Table cells.
 */
public class RouteTableCellRenderer extends DefaultTableCellRenderer {

    private static final long serialVersionUID = -8212288809775018085L;
   
    /**
     * {@inheritDoc}
     */
    @Override
    public Component getTableCellRendererComponent(@Nonnull final JTable table, @Nonnull final Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        final Component component = new DefaultTableCellRenderer().getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        final RouteTableModel model = (RouteTableModel) table.getModel();
        final Optional<Component> usedRouteMarked = markUsedRoute(row, column, model);

        paintBackgroundForInvalidEntry(row, column, component, model);

        return usedRouteMarked.orElse(component);
    }

    /*
     * Paint the cell background with the default ERRO color {@link CellColor#ERROR}
     */
    private void paintBackgroundForInvalidEntry(final int row, final int column, @Nonnull final Component component, @Nonnull final RouteTableModel model) {
        final PTextField text = model.getPropertyValueAt(row, column);

        if (text.isInvalidEntry()) {
            component.setBackground(text.getBackground());
        }
    }

    /*
     * Shows the icon on USED column when the route is active, otherwise show empty cell.
     */
    private Optional<Component> markUsedRoute(final int row, final int column, @Nonnull final RouteTableModel model) {
        if (ColumnId.USED.name().equalsIgnoreCase(model.getColumnName(column))) {
            final PTextField value = model.getPropertyValueAt(row, column);
            final JfxLabel label = new JfxLabel();

            label.setIcon(Boolean.parseBoolean(value.getText()) ? ResourcesIconFactory.ICON_STATUS_TICKMARK : null);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setOpaque(true);

            return Optional.of(label);
        }

        return Optional.empty();
    }
}