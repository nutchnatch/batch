package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;

import javax.annotation.Nonnull;
import java.awt.Component;

public enum ValueTypeFactory {
    
    BOOLEAN {
        @Override
        protected Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
            return new ValueJfxCheckBoxBuilder(value, valueRepository).build();
        }
    },

    INTEGER {
        @Override
        protected Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
            return new ValueJfxSpinnerBuilder(value, valueRepository).build();
        }
    },

    STRING {
        @Override
        protected Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
            return new ValueJfxTextFieldBuilder(value, valueRepository).build();
        }
    },

    CHOICE {
        @Override
        Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {                        
            return new ValueJfxComboBoxBuilder(value, valueRepository).build();
        }
    },
    
    ADDRESS {
        @Override
        Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
            return new ValueAddressBuilder(value, valueRepository).build();
        }
    },

    PASSWORD {
        @Override
        Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
            return new ValueJfxPasswordFieldBuilder(value, valueRepository).build();
        }
    },

    TEXTAREA {
        @Override
        Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
            return new ValueJfxTextAreaBuilder(value, valueRepository).build();
        }
    },

    RADIO {
        @Override
        Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
            return new ValueJfxRadioButtonBuilder(value, valueRepository).build();
        }
    },
    
    DYNAMICCHOICE {
        @Override
        Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
            return new ValueDynamicComboBoxBuilder(value, valueRepository).build();
        }
    },
    
    NSAPIP {
        @Override
        Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
            return new ValueAddressNsapIpBuilder(value, valueRepository).build();
        }
    },
    
    NSAP {
        @Override
        Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
            return new ValueAddressNsapBuilder(value, valueRepository).build();
        }
    },

    DATE {
        @Override
        Component of(Value value, PropertyValueRepository valueRepository) {
            throw new UnsupportedOperationException("Not supported value: Date");
        }
    },

    DOUBLE {
        @Override
        Component of(Value value, PropertyValueRepository valueRepository) {
            throw new UnsupportedOperationException("Not supported value: Double");
        }
    },
    
    STARTUPLIMIT {
        @Override
        Component of(Value value, PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
            return new ValueStartupLimitBuilder(value, valueRepository).build();
        }
    };

    abstract Component of(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) throws PropertyValueBuilderException;
    
    public static Component createOf(@Nonnull final Value value, @Nonnull final PropertyValueRepository valueRepository) throws PropertyValueBuilderException {
        final ValueTypeFactory create = ValueTypeFactory.valueOf(value.getType().toUpperCase());
        return create.of(value, valueRepository);
    }
}
