package com.ossnms.dcn_manager.bicnet.client.propertypage.validator;

import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.DynamicValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.ValidatorException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableModel;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableModelBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableModelTest;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.Column;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueAddress;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextField;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.TableModel;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.net.URL;
import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class RouteTableValidatorTest {
    
    private static final URL XML_URL = RouteTableModelTest.class.getClassLoader().getResource("value-table-ip-and-port.xml");

    /* Total rows defined on attribute autogenerate-rows in value-table.xml*/
    private static final int TOTAL_ROWS = 10;
    
    private final XmlFileLoader loader = new XmlFileLoader();
    private final TableModel tableModel;
    private RouteTableModel routeTableModel;
    private PropertyValueRepository repository;
    private RouteTableValidator validator;
    private PropertyValue routeCount;
    
    public RouteTableValidatorTest() {
        tableModel = loader.loadConfiguration(Property.class, XML_URL, null).getTableModel();
    }
    
    @Before
    public void setup() {
        routeCount = new DynamicValue(tableModel.getRouteRowCount().getId(), Optional.empty());
        repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
        routeTableModel = new RouteTableModelBuilder(tableModel, repository).build();
        validator = new RouteTableValidator(ImmutablePair.of(routeTableModel.getTableData(),routeCount));
    }
    
    @After
    public void release() {
        repository = null;
        routeTableModel = null;
        validator = null;
    }
    
    @Test
    public void testEmptyValues_tableDisable() throws ValidatorException {
        disableValues();

        assertTrue(validator.validate());
        assertThat(routeCount.getContent(), CoreMatchers.is("0"));
    }
    
    @Test(expected=ValidatorException.class)
    public void testEmptyValues_tableEnable() throws ValidatorException {
        validator.validate();
    }
    
    @Test(expected = ValidatorException.class)
    public void testEmptyRequiredValue() throws ValidatorException {
        final ValueAddress address = FluentIterable.from(routeTableModel.getTableData().values())
                .filter(ValueAddress.class).first().get();

        address.setContent("127.0.0.1");

        validator.validate();
    }

    @Test
    public void testHasMultipleValueToken() throws ValidatorException {
        FluentIterable.from(routeTableModel.getTableData().values())
                .filter(ValueAddress.class)
                .first()
                .get()
                .setContent(MULTIPLE_VALUES_TOKEN);

        assertTrue(validator.validate());
    }

    @Test
    public void testRequiredValueOk() throws ValidatorException {
        fillRequiredValues(0);
        
        assertTrue(validator.validate());
        assertThat(routeCount.getContent(), CoreMatchers.is("1"));
    }
    
    @Test
    public void testNotEmptyRow_markedToUpdate() throws ValidatorException {
        fillRequiredValues(0);
        
        assertTrue(validator.validate());
        
        final Map<Column, PropertyValue> valuesMap = routeTableModel.getTableData().row(0);
        
        for (final PropertyValue propertyValue : valuesMap.values()) {
            assertTrue(propertyValue.forceSendOnUpdate());
        }
        
        assertThat(routeCount.getContent(), CoreMatchers.is("1"));
    }
    
    @Test
    public void testEmptyRow_removedToUpdate() throws ValidatorException {
        fillRequiredValues(0);
        
        assertTrue(validator.validate());
        
        for (int row = 1; row < TOTAL_ROWS; row++) {
            final Map<Column, PropertyValue> valuesMap = routeTableModel.getTableData().row(row);

            for (final PropertyValue propertyValue : valuesMap.values()) {
                assertFalse(propertyValue.forceSendOnUpdate());
                assertFalse(propertyValue.isChanged());
            }
        }
        
        assertThat(routeCount.getContent(), CoreMatchers.is("1"));
    }
    
    @Test(expected=ValidatorException.class)
    public void testDuplicatedRows() throws ValidatorException {
        fillRequiredValues(0);
        fillRequiredValues(1);
        
        assertTrue(validator.validate());        
    }

    private void fillRequiredValues(final int positon) {
        final ValueAddress address = FluentIterable.from(routeTableModel.getTableData().values())
                .filter(ValueAddress.class).firstMatch(new Predicate<ValueAddress>() {
                    @Override
                    public boolean apply(final ValueAddress input) {
                        return input.getId().equals("ADDRESS_00" + positon);
                    }
                }).get();
        
        final ValueJfxTextField port = FluentIterable.from(routeTableModel.getTableData().values())
                .filter(ValueJfxTextField.class).firstMatch(new Predicate<ValueJfxTextField>() {
                    @Override
                    public boolean apply(final ValueJfxTextField input) {
                        return input.getId().equals("PORT_00" + positon);
                    }
                }).get();

        address.setContent("127.0.0.1");
        port.setContent("55");
    }
            
    private void disableValues() {
        for (final PropertyValue value : routeTableModel.getTableData().values()) {
            value.onWritable(false);
        }
    }
}
