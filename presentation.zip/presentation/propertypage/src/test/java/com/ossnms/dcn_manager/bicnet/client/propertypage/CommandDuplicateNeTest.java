package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.logger.LoggerManager;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.view.PropertyPageView;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.StaticConfiguration;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static java.util.Optional.of;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CommandDuplicateNeTest {

    private NeRepository repository;
    private NeSearchable searchable;
    private StaticConfiguration staticConfiguration;
    private PropertyPagesRepository pagesRepository;
    private LoggerManager loggerManager;
    private DcnPluginHelper pluginHelper;
    private CommonServices commonServices;
    private INE neBcb;
    private FullNeData fullNeData;
    private NeType type;
    private BiCNetPluginSite site;
    private BiCNetPluginFrame frame;

    private CommandDuplicateNe callDuplicate;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() throws BiCNetPluginException, RepositoryException, PropertyValueBuilderException {
        commonServices = mock(CommonServices.class);
        repository = mock(NeRepository.class);
        searchable = mock(NeSearchable.class);
        staticConfiguration = mock(StaticConfiguration.class);
        pagesRepository = mock(PropertyPagesRepository.class);
        loggerManager = mock(LoggerManager.class);
        pluginHelper = mock(DcnPluginHelper.class);

        neBcb = new NEItem();
        neBcb.setId(1);
        neBcb.setNeProxyType("type");
        neBcb.setAssociatedEm(new EMIdItem(1));

        type = mock(NeType.class);
        site = mock(BiCNetPluginSite.class);
        frame = mock(BiCNetPluginFrame.class);

        callDuplicate = new CommandDuplicateNe(repository, commonServices, pagesRepository);
        fullNeData = new FullNeData(neBcb, new NeInfo(1), null);
        DcnPluginHelperSingleton.getInstance().setCfPluginSite(site);

        when(commonServices.getDcnPluginHelper()).thenReturn(pluginHelper);
        when(commonServices.getLoggerManager()).thenReturn(loggerManager);
        when(commonServices.getStaticConfiguration()).thenReturn(staticConfiguration);

        when(site.createFrame(any(PropertyPageView.class), any(BiCNetPluginFrameType.class))).thenReturn(frame);
        
        when(type.getName()).thenReturn("type_name");
        
        when(repository.get(1)).thenReturn(of(fullNeData));

        when(repository.queries()).thenReturn(searchable);
        when(searchable.findByIdName(anyString())).thenReturn(Optional.empty());

        when(pagesRepository.getPropertyPage(type)).thenReturn(new Page());
        when(staticConfiguration.findNeType(anyString())).thenReturn(of(type));
    }

    @Test
    public void testCall() throws CommandException, PropertyValueBuilderException {
        callDuplicate.call(neBcb);

        verify(pagesRepository, times(1)).getPropertyPage(type);
        verify(staticConfiguration, times(1)).findNeType("type");
        verify(type, times(1)).getHelpID();
        verify(frame, times(1)).showFrame();
    }
}
