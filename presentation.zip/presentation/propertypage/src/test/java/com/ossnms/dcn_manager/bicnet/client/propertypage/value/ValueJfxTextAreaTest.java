package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.net.URL;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class ValueJfxTextAreaTest {

    private static final URL XML_URL = ValueJfxTextAreaTest.class.getClassLoader().getResource("value-textarea.xml");
    
    private final XmlFileLoader loader = new XmlFileLoader();
    private final Value value;
    private ValueJfxTextArea textArea;
    
    public ValueJfxTextAreaTest() {
        value = loader.loadConfiguration(Property.class, XML_URL, null).getValue();
    }
    
    @Before
    public void setup() throws PropertyValueBuilderException {
        textArea = (ValueJfxTextArea) ValueTypeFactory.createOf(value, new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow()));
    }
    
    @After
    public void release() {
        textArea = null;
    }
    
    @Test
    public void testCreateObject() {
        assertNotNull(textArea);
        
        textArea.addConditionListener(new ChangeListener() {
            @Override
            public void stateChanged(final ChangeEvent e) {
            }
        });
        
        assertThat(textArea.getColumns(), is(50));
        assertThat(textArea.getRows(), is(5));
        assertThat(textArea.getId(), is("test-area"));
        assertThat(textArea.getName(), is("FIELD.Description"));
        assertThat(textArea.getContent().isEmpty(), is(true));
        assertThat(textArea.isMandatoryEntry(), is(false));
        assertThat(textArea.isChanged(), is(false));
        assertThat(textArea.getValueActions().isEmpty(), is(true));
        assertThat(textArea.isMandatoryValueBlank(), is(false));
    }
    
    @Test
    public void testChangeObject() {
        assertNotNull(textArea);
        
        textArea.setText("test");
        
        assertThat(textArea.getContent(), is("test"));
        assertThat(textArea.isMandatoryValueBlank(), is(false));
        assertThat(textArea.isChanged(), is(true));
    }

    @Test
    public void testChangeObject_with_empty_line_end() {
        assertNotNull(textArea);

        textArea.setText("test ");

        assertThat(textArea.getContent(), is("test"));
        assertThat(textArea.isMandatoryValueBlank(), is(false));
        assertThat(textArea.isChanged(), is(true));
    }
    
    @Test
    public void testSetContent() {
        assertNotNull(textArea);
        
        textArea.setContent("test");
        
        assertThat(textArea.getContent(), is("test"));
        assertThat(textArea.isMandatoryValueBlank(), is(false));
        assertThat(textArea.isChanged(), is(false));
    }
    
    @Test
    public void testSetEmptyContent() {
        assertNotNull(textArea);
        
        textArea.setContent(null);
        
        assertThat(textArea.getContent(), is(""));
        assertThat(textArea.isMandatoryValueBlank(), is(false));
        assertThat(textArea.isChanged(), is(false));
    }
    
    @Test
    public void testOnCleanOnDisable() {
        assertNotNull(textArea);
        
        textArea.onCleanOnDisable(true);
        
        assertThat(textArea.getText().isEmpty(), is(true));
        assertThat(textArea.isMandatoryValueBlank(), is(false));
        assertThat(textArea.isChanged(), is(false));
    }
    
    @Test
    public void testOnWritableFalse() {
        assertNotNull(textArea);
        
        textArea.onWritable(false);
        
        assertThat(textArea.isEnabled(), is(false));
    }
    
    @Test
    public void testOnWritableTrue() {
        assertNotNull(textArea);
        
        textArea.onWritable(true);
        
        assertThat(textArea.isEnabled(), is(true));
    }
    
    @Test(expected=UnsupportedOperationException.class)
    public void testOnValueFromConditionResult() {
        assertNotNull(textArea);
        
        textArea.onValueFromConditionResult(true);        
    }
    
    @Test
    public void testMultiselection() {
        assertNotNull(textArea);
        
        textArea.setContent(MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN);
        
        assertThat(textArea.isUndefined(), is(true));        
    }


    @Test public void shouldModifyValue() throws Exception {
        textArea.setContent("original text");

        textArea.modifyContent("updated text");

        assertThat(textArea.getContent(), is("updated text"));
    }

    @Test public void shouldMarkChangedOnModify() throws Exception {
        textArea.setContent("original text");

        textArea.modifyContent("updated text");

        assertThat(textArea.isChanged(), is(true));
    }
}
