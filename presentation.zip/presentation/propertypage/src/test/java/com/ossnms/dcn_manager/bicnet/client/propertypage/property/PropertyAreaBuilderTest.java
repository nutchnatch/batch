package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.net.URL;

import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.property.PropertyTypeFactory;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextAreaTest;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.tools.jfx.components.JfxLabel;

public class PropertyAreaBuilderTest {

    private static final URL XML_URL = ValueJfxTextAreaTest.class.getClassLoader().getResource("value-textarea.xml");

    private final XmlFileLoader loader = new XmlFileLoader();
    private final Property property;
    private DynamicPanelForm panelArea;
    private final PropertyValueRepository repository;

    public PropertyAreaBuilderTest() {
        this.property = loader.loadConfiguration(Property.class, XML_URL, null);
        this.repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
    }

    @Before
    public void setup() {
        panelArea = new DynamicPanelForm();

    }

    @After
    public void release() {
        this.panelArea = null;
    }

    @Test
    public void testCreateObject() throws PropertyValueBuilderException {
        final JPanel panel = (JPanel) PropertyTypeFactory.createOf(panelArea, property, repository);

        assertTrue(panel.getComponent(0) instanceof JfxLabel);
        assertTrue(panel.getComponent(1) instanceof JScrollPane);
        assertTrue(panel.getComponent(2) instanceof Box.Filler);

        assertThat(panel.getComponentCount(), is(3));
    }
}
