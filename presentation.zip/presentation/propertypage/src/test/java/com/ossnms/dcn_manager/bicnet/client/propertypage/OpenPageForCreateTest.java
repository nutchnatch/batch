package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.api.view.MessageBox;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForNewObject;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.PropertyPage;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.view.PropertyPageView;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.Type;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Optional;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OpenPageForCreateTest {

    @Mock private Repository<Integer, IMediator> repository;
    @Mock private PropertyValueRepository valueRepository;
    @Mock private IMediator element;
    @Mock private Type type;
    @Mock private PageDocumentForNewObject<IMediator> document;
    @Mock private DcnPluginHelper pluginHelper;
    @Mock private CommonServices commonServices;
    @Mock private Page page;
    @Mock private PropertyPage propertyPage;
    @Mock private BiCNetPluginSite site;
    @Mock private BiCNetPluginFrame frame;
    @Mock private MessageBox messageBox;
    
    private OpenPropertyPageForNew<Integer, IMediator> openPageForCreate;

    @Before
    public void setup() throws BiCNetPluginException {
        openPageForCreate = new OpenPropertyPageForNew<>(ImmutablePair.of(element, "nativeName"), commonServices, type, document, repository, page);
        DcnPluginHelperSingleton.getInstance().setCfPluginSite(site);

        when(commonServices.getDcnPluginHelper()).thenReturn(pluginHelper);
        when(commonServices.getMessageBox()).thenReturn(messageBox);

        when(site.createFrame(any(PropertyPageView.class), any(BiCNetPluginFrameType.class))).thenReturn(frame);
        
        when(element.getNativeName()).thenReturn("nativeName");
        
        when(document.getPropertyPage()).thenReturn(propertyPage);
        when(document.getValueRepository()).thenReturn(valueRepository);

        when(propertyPage.getTitle()).thenReturn("title");
        when(propertyPage.getHelpId()).thenReturn(1);
        when(propertyPage.getPage()).thenReturn(page);
        when(propertyPage.applyCommand()).thenReturn(Optional.empty());
        
        when(valueRepository.allValues()).thenReturn(new ArrayList<>());
        
        when(page.getGlobalVariable()).thenReturn(new ArrayList<>());
        when(page.getStatic()).thenReturn(new ArrayList<>());
        when(page.getTabbedPane()).thenReturn(new ArrayList<>());
        when(page.getTabbedPane()).thenReturn(new ArrayList<>());
    }

    @Test
    public void testCall() throws BiCNetPluginException {
        
        openPageForCreate.call();
        
        verify(document, times(1)).propertyPage(any(PropertyPage.class));
        verify(type, times(1)).getHelpID();
        verify(frame, times(1)).showFrame();
    }
}
