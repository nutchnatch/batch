package com.ossnms.dcn_manager.bicnet.client.propertypage.table;

import static org.junit.Assert.assertNotNull;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.net.URL;

import org.apache.commons.lang3.math.NumberUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.coriant.widgets.text.PTextField;
import com.google.common.collect.Iterables;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.TableModel;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableModel;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableModelBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.Column;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;

public class RouteTableModelTest {

    private static final int TOTAL_COLUMNS_IN_XML = 8;

    private static final URL XML_URL = RouteTableModelTest.class.getClassLoader().getResource("value-table-ip-and-port.xml");
    
    private final XmlFileLoader loader = new XmlFileLoader();
    private final TableModel tableModel;
    private RouteTableModel routeTableModel;
    private PropertyValueRepository repository;
    
    public RouteTableModelTest() {
        this.tableModel = loader.loadConfiguration(Property.class, XML_URL, null).getTableModel();
    }
    
    @Before
    public void setup() {
        this.repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
        this.routeTableModel = new RouteTableModelBuilder(tableModel, repository).build();
    }
    
    @After
    public void release() {
        this.repository = null;
        this.routeTableModel = null;
    }
    
    @Test
    public void testColumnsSize() {
        assertNotNull(routeTableModel);
        assertThat(routeTableModel.getColumnCount(), is(TOTAL_COLUMNS_IN_XML));
    }
    
    @Test
    public void testFirstColumnValue() {
        final Column column = Iterables.getFirst(routeTableModel.getTableHeader(), null);
        assertNotNull(column);
        assertThat(column.getName(), is("Priority"));
        assertThat(column.getWidth(), is(64));        
    }
    
    @Test
    public void testLastColumnValue() {
        final Column column = Iterables.getLast(routeTableModel.getTableHeader(), null);
        assertNotNull(column);
        assertThat(column.getName(), is("Domain Name"));
        assertThat(column.getWidth(), is(120));        
    }
    
    @Test
    public void testRowCount() {
        assertThat(routeTableModel.getTableData().rowKeySet().size(), is(NumberUtils.toInt(tableModel.getAutogenerateRows())));
    }
    
    @Test
    public void testFirstRowValue() {
        
        final PTextField firstValue = routeTableModel.getPropertyValueAt(0, 0);
        
        assertThat(firstValue.getName(), is("FIELD.PRIO_000"));
        assertThat(firstValue.getText(), is("1"));
        
        final int lastColumn = routeTableModel.getTableData().columnKeySet().size() -1;
        
        final PTextField lastValue = routeTableModel.getPropertyValueAt(0, lastColumn);
        
        assertThat(lastValue.getName(), is("FIELD.DOMAIN_NAME_FOR_NE_000"));
        assertThat(lastValue.getText(), is(""));
    }
    
    @Test
    public void testLastRowValue() {
        final int lastRow = NumberUtils.toInt(tableModel.getAutogenerateRows()) -1;
        final PTextField firstValue = routeTableModel.getPropertyValueAt(lastRow, 0);
        
        assertThat(firstValue.getName(), is("FIELD.PRIO_009"));
        assertThat(firstValue.getText(), is("10"));
        
        final int lastColumn = routeTableModel.getTableData().columnKeySet().size() -1;
        
        final PTextField lastValue = routeTableModel.getPropertyValueAt(lastRow, lastColumn);
        
        assertThat(lastValue.getName(), is("FIELD.DOMAIN_NAME_FOR_NE_009"));
        assertThat(lastValue.getText(), is(""));
    }
 }
