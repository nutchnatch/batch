package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.coriant.widgets.ClientProperties;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.net.URL;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class ValueJfxTextFieldTest {

    private static final URL XML_URL = ValueJfxTextFieldTest.class.getClassLoader().getResource("value-text.xml");

    private final XmlFileLoader loader = new XmlFileLoader();
    private final Value value;
    private ValueJfxTextField textField;

    public ValueJfxTextFieldTest() {
        this.value = loader.loadConfiguration(Property.class, XML_URL, null).getValue();
    }

    @Before
    public void setup() throws PropertyValueBuilderException {
        this.textField = (ValueJfxTextField) ValueTypeFactory.createOf(value, new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow()));
    }

    @After
    public void release() {
        this.textField = null;
    }

    @Test
    public void testCreateObject() {
        assertNotNull(textField);

        textField.addConditionListener(e -> {});

        assertThat(textField.getColumns(), is(20));
        assertThat(textField.getId(), is("test-text"));
        assertThat(textField.getName(), is("FIELD.UploadPath"));
        assertThat(textField.getContent().isEmpty(), is(true));
        assertThat(textField.isMandatoryEntry(), is(false));
        assertThat(textField.isChanged(), is(false));
        assertThat(textField.getValueActions().isEmpty(), is(true));
        assertThat(textField.isMandatoryValueBlank(), is(false));
        assertThat(textField.supportMultiselection(), is(true));
        assertThat(textField.getClientProperty(ClientProperties.PROMPT), is("text-example"));
    }

    @Test
    public void testChangeObject() {
        assertNotNull(textField);

        textField.setText("test");

        assertThat(textField.isMandatoryValueBlank(), is(false));
        assertThat(textField.isChanged(), is(true));
    }

    @Test
    public void testSetContent() {
        assertNotNull(textField);

        textField.setContent("test");

        assertThat(textField.getContent(), is("test"));
        assertThat(textField.isMandatoryValueBlank(), is(false));
        assertThat(textField.isChanged(), is(false));
    }

    @Test
    public void testSetEmptyContent() {
        assertNotNull(textField);

        textField.setContent("");

        assertThat(textField.getContent(), is(""));
        assertThat(textField.isMandatoryValueBlank(), is(false));
        assertThat(textField.isChanged(), is(false));
    }

    @Test
    public void testOnCleanOnDisable() {
        assertNotNull(textField);

        textField.onCleanOnDisable(true);

        assertThat(textField.getText().isEmpty(), is(true));
        assertThat(textField.isMandatoryValueBlank(), is(false));
        assertThat(textField.isChanged(), is(false));
    }

    @Test
    public void testOnWritableFalse() {
        assertNotNull(textField);

        textField.onWritable(false);

        assertThat(textField.isEnabled(), is(false));
    }

    @Test
    public void testOnWritableTrue() {
        assertNotNull(textField);

        textField.onWritable(true);

        assertThat(textField.isEnabled(), is(true));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testOnValueFromConditionResult() {
        assertNotNull(textField);

        textField.onValueFromConditionResult(true);
    }
    
    @Test
    public void testMultiselection() {
        assertNotNull(textField);
        
        textField.setContent(MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN);
        
        assertThat(textField.isUndefined(), is(true));        
    }

    @Test public void shouldModifyValue() throws Exception {
        textField.setContent("original text");

        textField.modifyContent("updated text");

        assertThat(textField.getContent(), is("updated text"));
    }

    @Test public void shouldMarkChangedOnModify() throws Exception {
        textField.setContent("original text");

        textField.modifyContent("updated text");

        assertThat(textField.isChanged(), is(true));
    }
}
