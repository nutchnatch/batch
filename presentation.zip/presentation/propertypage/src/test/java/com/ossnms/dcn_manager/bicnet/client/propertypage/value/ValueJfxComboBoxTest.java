package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.net.URL;

import static com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class ValueJfxComboBoxTest {

    private static final URL XML_URL = ValueJfxComboBoxTest.class.getClassLoader().getResource("value-combobox.xml");

    private final XmlFileLoader loader = new XmlFileLoader();
    private final Value value;
    private ValueJfxComboBox comboBox;

    public ValueJfxComboBoxTest() {
        this.value =  loader.loadConfiguration(Property.class, XML_URL, null).getValue();
    }

    @Before
    public void setup() throws PropertyValueBuilderException {
        this.comboBox = (ValueJfxComboBox) ValueTypeFactory.createOf(value, new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow()));
    }

    @After
    public void release() {
        this.comboBox = null;
    }

    @Test
    public void testCreateObject() {
        assertNotNull(comboBox);

        comboBox.addConditionListener(new ChangeListener() {
            @Override
            public void stateChanged(final ChangeEvent e) {
            }
        });

        assertThat(comboBox.getColumns(), is(20));
        assertThat(comboBox.getId(), is("test-combo"));
        assertThat(comboBox.getName(), is("FIELD.LogLevel"));
        assertThat(comboBox.getContent(), is("Off"));
        assertThat(comboBox.getSelectedStringValue(), is("Off"));
        assertThat(comboBox.getSelectedKey(), is((Object)"OFF"));
        assertThat(comboBox.isMandatoryEntry(), is(false));
        assertThat(comboBox.isChanged(), is(false));
        assertThat(comboBox.getValueActions().isEmpty(), is(true));
        assertThat(comboBox.isMandatoryValueBlank(), is(false));
    }

    @Test
    public void testChangeObject() {
        assertNotNull(comboBox);

        comboBox.setSelectedItem("Error");

        assertThat(comboBox.isMandatoryValueBlank(), is(false));
        assertThat(comboBox.isChanged(), is(true));
    }

    @Ignore
    public void testSetContent() {
        assertNotNull(comboBox);

        comboBox.setContent("ERROR");

        assertThat(comboBox.getContent(), is("ERROR"));
        assertThat(comboBox.getSelectedStringValue(), is("Error"));
        assertThat(comboBox.getSelectedKey(), is((Object)"ERROR"));
        assertThat(comboBox.isMandatoryValueBlank(), is(false));
        assertThat(comboBox.isChanged(), is(false));
    }

    @Test
    public void testOnCleanOnDisable() {
        assertNotNull(comboBox);

        comboBox.onCleanOnDisable(true);

        assertThat(comboBox.getContent(), is("Off"));
        assertThat(comboBox.getSelectedStringValue(), is("Off"));
        assertThat(comboBox.getSelectedKey(), is((Object)"OFF"));
        assertThat(comboBox.isMandatoryValueBlank(), is(false));
        assertThat(comboBox.isChanged(), is(false));
    }

    @Test
    public void testOnWritableFalse() {
        assertNotNull(comboBox);

        comboBox.onWritable(false);

        assertThat(comboBox.isEnabled(), is(false));
    }

    @Test
    public void testOnWritableTrue() {
        assertNotNull(comboBox);

        comboBox.onWritable(true);

        assertThat(comboBox.isEnabled(), is(true));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testOnValueFromConditionResult() {
        assertNotNull(comboBox);

        comboBox.onValueFromConditionResult(true);
    }
    
    @Test
    public void testMultiselection() {
        assertNotNull(comboBox);
        
        comboBox.setContent(MULTIPLE_VALUES_TOKEN);
        
        assertThat(comboBox.getSelectedItem().toString(), is(MULTIPLE_VALUES_TOKEN));
    }

    @Test public void shouldModifyValue() throws Exception {
        comboBox.setContent("Error");

        comboBox.modifyContent("Off");

        assertThat(comboBox.getSelectedKey(), is("OFF"));
    }

    @Test public void shouldMarkChangedOnModify() throws Exception {
        comboBox.setContent("Error");

        comboBox.modifyContent("Off");

        assertThat(comboBox.isChanged(), is(true));
    }
}
