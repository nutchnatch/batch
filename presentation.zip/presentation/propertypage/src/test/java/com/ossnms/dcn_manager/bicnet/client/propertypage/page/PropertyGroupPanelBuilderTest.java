package com.ossnms.dcn_manager.bicnet.client.propertypage.page;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.net.URL;

import javax.swing.JPanel;

import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.propertypage.PropertyGroup;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.page.PropertyGroupPanelBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;

public class PropertyGroupPanelBuilderTest {
    private static final URL XML_URL = PropertyGroupPanelBuilderTest.class.getClassLoader().getResource("property-group.xml");

    private final XmlFileLoader loader = new XmlFileLoader();
    private final PropertyGroup propertyGroup;

    public PropertyGroupPanelBuilderTest() {
        this.propertyGroup = loader.loadConfiguration(PropertyGroup.class, XML_URL, null);
    }
    
    @Test
    public void testCreateObject() throws PropertyValueBuilderException {
        final PropertyValueRepository repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
        final JPanel panel = new PropertyGroupPanelBuilder(propertyGroup, repository).build();
        
        assertNotNull(panel);
        assertFalse(repository.allSavableValues().isEmpty());
    }
}
