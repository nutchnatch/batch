package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.google.common.collect.Iterables;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.RadioGroup;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.net.URL;
import java.util.Collection;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class ValueJfxRadioButtonTest {

    private static final URL XML_URL = ValueJfxRadioButtonTest.class.getClassLoader().getResource("value-radio.xml");

    private final XmlFileLoader loader = new XmlFileLoader();
    private final Collection<Value> value;
    private ValueJfxRadioButton checkBox1;
    private ValueJfxRadioButton checkBox2;

    public ValueJfxRadioButtonTest() {
        this.value = loader.loadConfiguration(RadioGroup.class, XML_URL, null).getValue();
    }

    @Before
    public void setup() throws PropertyValueBuilderException {
        this.checkBox1 = (ValueJfxRadioButton) ValueTypeFactory.createOf(Iterables.getFirst(value, null), new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow()));
        this.checkBox2 = (ValueJfxRadioButton) ValueTypeFactory.createOf(Iterables.getLast(value, null), new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow()));
    }

    @After
    public void release() {
        this.checkBox1 = null;
        this.checkBox2 = null;
    }

    @Test
    public void testCreate1Object() {
        assertNotNull(checkBox1);


        assertThat(checkBox1.getId(), is("ftp"));
        assertThat(checkBox1.getText(), is("FTP"));
        assertThat(checkBox1.getName(), is("FIELD.Ftp"));
        assertThat(checkBox1.getContent(), is("true"));
        assertThat(checkBox1.isChanged(), is(false));
        assertThat(checkBox1.getValueActions().isEmpty(), is(true));
        assertThat(checkBox1.isMandatoryValueBlank(), is(false));
    }

    @Test
    public void testCreate2Object() {
        assertNotNull(checkBox2);


        assertThat(checkBox2.getId(), is("scp"));
        assertThat(checkBox2.getText(), is("SCP"));
        assertThat(checkBox2.getName(), is("FIELD.Scp"));
        assertThat(checkBox2.getContent(), is("false"));
        assertThat(checkBox2.isChanged(), is(false));
        assertThat(checkBox2.getValueActions().isEmpty(), is(true));
        assertThat(checkBox2.isMandatoryValueBlank(), is(false));
    }

    @Test
    public void testChangeObject() {
        assertNotNull(checkBox1);

        checkBox1.setSelected(false);

        assertThat(checkBox1.isMandatoryValueBlank(), is(false));
        assertThat(checkBox1.isChanged(), is(true));
    }

    @Test
    public void testSetContent() {
        assertNotNull(checkBox1);

        checkBox1.setContent("false");

        assertThat(checkBox1.isMandatoryValueBlank(), is(false));
        assertThat(checkBox1.isChanged(), is(false));
    }

    @Test
    public void testSetEmptyContent() {
        assertNotNull(checkBox1);

        checkBox1.setContent("");

        assertThat(checkBox1.getContent(), is("false"));
        assertThat(checkBox1.isMandatoryValueBlank(), is(false));
        assertThat(checkBox1.isChanged(), is(false));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testOnCleanOnDisable() {
        assertNotNull(checkBox1);

        checkBox1.onCleanOnDisable(true);
    }

    @Test
    public void testOnWritableFalse() {
        assertNotNull(checkBox1);

        checkBox1.onWritable(false);

        assertThat(checkBox1.isEnabled(), is(false));
        assertThat(checkBox1.getText().isEmpty(), is(false));
        assertThat(checkBox1.isMandatoryValueBlank(), is(false));
        assertThat(checkBox1.isChanged(), is(false));
    }

    @Test
    public void testOnWritableTrue() {
        assertNotNull(checkBox1);

        checkBox1.onWritable(true);

        assertThat(checkBox1.isEnabled(), is(true));
        assertThat(checkBox1.getText().isEmpty(), is(false));
        assertThat(checkBox1.isMandatoryValueBlank(), is(false));
        assertThat(checkBox1.isChanged(), is(false));
    }

    @Test
    public void testOnValueFromConditionResultTrue() {
        assertNotNull(checkBox1);

        checkBox1.onValueFromConditionResult(true);

        assertThat(checkBox1.isMandatoryValueBlank(), is(false));
        assertThat(checkBox1.isChanged(), is(false));
    }

    @Test
    public void testOnValueFromConditionResultFalse() {
        assertNotNull(checkBox1);

        checkBox1.onValueFromConditionResult(false);

        assertThat(checkBox1.isMandatoryValueBlank(), is(false));
        assertThat(checkBox1.isChanged(), is(true));
    }

    @Test public void shouldModifyValue() throws Exception {
        checkBox1.setContent("false");

        checkBox1.modifyContent("true");

        assertThat(checkBox1.getContent(), is("true"));
    }

    @Test public void shouldMarkChangedOnModify() throws Exception {
        checkBox1.setContent("false");

        checkBox1.modifyContent("true");

        assertThat(checkBox1.isChanged(), is(true));
    }
}
