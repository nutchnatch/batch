package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.net.URL;

import javax.swing.JPanel;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.property.PropertyTypeFactory;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxCheckBox;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextAreaTest;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;

public class PropertyToggleBuilderTest {

    private static final URL XML_URL = ValueJfxTextAreaTest.class.getClassLoader().getResource("value-checkbox.xml");

    private final XmlFileLoader loader = new XmlFileLoader();
    private final Property property;
    private JPanel panel;
    private final PropertyValueRepository repository;

    public PropertyToggleBuilderTest() {
        this.property = loader.loadConfiguration(Property.class, XML_URL, null);
        this.repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
    }

    @Before
    public void setup() throws PropertyValueBuilderException {
        this.panel = (JPanel) PropertyTypeFactory.createOf(new DynamicPanelForm(), property, repository);
    }

    @After
    public void release() {
        this.panel = null;
    }

    @Test
    public void testCreateObject() {
        assertTrue(panel.getComponent(0) instanceof ValueJfxCheckBox);

        assertThat(panel.getComponentCount(), is(1));
    }
}
