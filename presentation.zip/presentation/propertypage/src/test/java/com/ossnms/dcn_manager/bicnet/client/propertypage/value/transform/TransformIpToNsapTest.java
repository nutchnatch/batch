package com.ossnms.dcn_manager.bicnet.client.propertypage.value.transform;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;

public class TransformIpToNsapTest {
    
    @Test
    public void testTranform_onlyIp() {
        final Optional<String> nsap = TransformIpToNsap.tryTransform("127.0.0.1");
        
        assertTrue(nsap.isPresent());
        assertThat(nsap.get(), CoreMatchers.is("540072872203127000000001"));
    }
    
    @Test
    public void testTranform_onlyIpAndPort() {
        final Optional<String> nsap = TransformIpToNsap.tryTransform("127.0.0.1:8080");
        
        assertTrue(nsap.isPresent());
        assertThat(nsap.get(), CoreMatchers.is("5400728722031270000000010808000001"));
    }
    
    @Test
    public void testTranform_null_address() {
        final Optional<String> nsap = TransformIpToNsap.tryTransform(null);
        assertFalse(nsap.isPresent());
    }
    
    @Test
    public void testTranform_empty_address() {
        final Optional<String> nsap = TransformIpToNsap.tryTransform("");
        assertFalse(nsap.isPresent());
    }
    
    @Test
    public void testTranform_wrong_ip() {
        final Optional<String> nsap = TransformIpToNsap.tryTransform("127.0000");        
        assertFalse(nsap.isPresent());
    }    
}
