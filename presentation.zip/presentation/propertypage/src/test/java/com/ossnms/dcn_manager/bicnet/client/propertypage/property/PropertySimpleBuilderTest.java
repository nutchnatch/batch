package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.net.URL;

import javax.swing.Box;
import javax.swing.JPanel;

import org.junit.After;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.property.PropertyTypeFactory;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextAreaTest;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxSpinner;
import com.ossnms.tools.jfx.components.JfxTextField;

public class PropertySimpleBuilderTest {

    private static final URL XML_URL_SPINNER = ValueJfxTextAreaTest.class.getClassLoader().getResource("value-spinner.xml");
    private static final URL XML_URL_TEXT = ValueJfxTextAreaTest.class.getClassLoader().getResource("value-text.xml");
    private static final URL XML_URL_TEXT_BUTTON = ValueJfxTextAreaTest.class.getClassLoader().getResource("value-text-with-button.xml");
    
    private final XmlFileLoader loader = new XmlFileLoader();
    private Property property;
    private JPanel panelArea;
    private final PropertyValueRepository repository;
    
    public PropertySimpleBuilderTest() {
        this.repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
    }
        
    @After
    public void release() {
        this.property = null;
        this.panelArea = null;
        this.repository.clear();
    }
    
    @Test
    public void testCreateWithRange() throws PropertyValueBuilderException {
        this.property = loader.loadConfiguration(Property.class, XML_URL_SPINNER, null);
        this.panelArea = (JPanel) PropertyTypeFactory.createOf(new DynamicPanelForm(), property, repository);
        
        assertTrue(panelArea.getComponent(0) instanceof JfxLabel);
        assertTrue(panelArea.getComponent(1) instanceof JPanel);
        assertTrue(panelArea.getComponent(2) instanceof Box.Filler);
        
        assertThat(panelArea.getComponentCount(), is(3));
        
        final JPanel spinnerPanel = (JPanel) panelArea.getComponent(1);
        
        assertTrue(spinnerPanel.getComponent(0) instanceof JfxSpinner);
        assertTrue(spinnerPanel.getComponent(1) instanceof Box.Filler);
        assertTrue(spinnerPanel.getComponent(2) instanceof JfxLabel);
        assertTrue(spinnerPanel.getComponent(3) instanceof Box.Filler);
        
    }
    
    @Test
    public void testCreateWithText() throws PropertyValueBuilderException {
        this.property = loader.loadConfiguration(Property.class, XML_URL_TEXT, null);
        this.panelArea = (JPanel) PropertyTypeFactory.createOf(new DynamicPanelForm(), property, repository);
        
        assertTrue(panelArea.getComponent(0) instanceof JfxLabel);
        assertTrue(panelArea.getComponent(1) instanceof JfxTextField);
        assertTrue(panelArea.getComponent(2) instanceof Box.Filler);
        
        assertThat(panelArea.getComponentCount(), is(3));
    }
    
    @Test
    public void testCreateWithTextAndButton() throws PropertyValueBuilderException {
        this.property = loader.loadConfiguration(Property.class, XML_URL_TEXT_BUTTON, null);
        this.panelArea = (JPanel) PropertyTypeFactory.createOf(new DynamicPanelForm(), property, repository);
        
        assertTrue(panelArea.getComponent(0) instanceof JfxLabel);
        assertTrue(panelArea.getComponent(1) instanceof JPanel);
        assertTrue(panelArea.getComponent(2) instanceof Box.Filler);
        
        assertThat(panelArea.getComponentCount(), is(3));
        
        final JPanel spinnerPanel = (JPanel) panelArea.getComponent(1);
        
        assertTrue(spinnerPanel.getComponent(0) instanceof JfxTextField);
        assertTrue(spinnerPanel.getComponent(1) instanceof JfxButton);
        assertTrue(spinnerPanel.getComponent(2) instanceof Box.Filler);
    }
}
