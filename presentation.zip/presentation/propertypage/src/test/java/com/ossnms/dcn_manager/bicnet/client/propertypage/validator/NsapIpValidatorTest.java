package com.ossnms.dcn_manager.bicnet.client.propertypage.validator;

import static org.mockito.Mockito.when;

import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.coriant.widgets.text.PValidationEvent;
import com.coriant.widgets.text.PValidationException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.validator.NsapIpValidator;

public class NsapIpValidatorTest {
    
    private PValidationEvent event;
    private NsapIpValidator validator;
    private Document document;
    
    @Before
    public void setup() {
        document = Mockito.mock(Document.class);
        validator = new NsapIpValidator();
        event = new PValidationEvent(new Object(), document);
    }

    @Test
    public void testIsValid_ip() throws BadLocationException, PValidationException {
        final String text = "127.0.0.1";
        
        when(event.getDocument().getLength()).thenReturn(text.length());
        when(event.getDocument().getText(0, text.length())).thenReturn(text);
        
        validator.validate(event);
    }
    
    @Test
    public void testIsValid_ip_port() throws BadLocationException, PValidationException{
        final String text = "127.0.0.1:8080";
        
        when(event.getDocument().getLength()).thenReturn(text.length());
        when(event.getDocument().getText(0, text.length())).thenReturn(text);
        
        validator.validate(event);
    }
    
    @Test
    public void testIsValid_nsap_rfc1277() throws BadLocationException, PValidationException{
        final String text = "5400728722031270000000010808000001";
        
        when(event.getDocument().getLength()).thenReturn(text.length());
        when(event.getDocument().getText(0, text.length())).thenReturn(text);
        
        validator.validate(event);
    }
    
    @Test
    public void testIsValid_nsap() throws BadLocationException, PValidationException{
        final String text = "8909000211207422202100";
        
        when(event.getDocument().getLength()).thenReturn(text.length());
        when(event.getDocument().getText(0, text.length())).thenReturn(text);
        
        validator.validate(event);
    }
    
    @Test(expected=PValidationException.class)
    public void testIsNotValid_ip() throws BadLocationException, PValidationException{
        final String text = "127.0.0.352";
        
        when(event.getDocument().getLength()).thenReturn(text.length());
        when(event.getDocument().getText(0, text.length())).thenReturn(text);
        
        validator.validate(event);
    }
    
    @Test(expected=PValidationException.class)
    public void testIsNotValid_ip_port() throws BadLocationException, PValidationException{
        final String text = "127.0.0.1:-1";
        
        when(event.getDocument().getLength()).thenReturn(text.length());
        when(event.getDocument().getText(0, text.length())).thenReturn(text);
        
        validator.validate(event);
    }
    
    @Test(expected=PValidationException.class)
    public void testIsNotValid_nsap() throws BadLocationException, PValidationException{
        final String text = "AAAAAAAAAAAAAAAAAAAAA";
        
        when(event.getDocument().getLength()).thenReturn(text.length());
        when(event.getDocument().getText(0, text.length())).thenReturn(text);
        
        validator.validate(event);
    }    
}
