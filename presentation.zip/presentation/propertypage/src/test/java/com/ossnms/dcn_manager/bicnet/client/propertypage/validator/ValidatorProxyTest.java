package com.ossnms.dcn_manager.bicnet.client.propertypage.validator;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.DynamicValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.Validator;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.Column;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class ValidatorProxyTest {

    @Test
    public void testValidProxy() {
        final Table<Integer, Column, PropertyValue> tableData = HashBasedTable.create();
        final PropertyValue value = new DynamicValue("test", Optional.empty());
        final Validator validator = ValidatorProxy.newInstanceOf("RouteTableValidator", Pair.class, ImmutablePair.of(tableData, value));
                
        assertNotNull(validator);
        assertTrue(validator instanceof RouteTableValidator);
    }
    
    @Test(expected=UnsupportedOperationException.class)
    public void testProxyError() {
        final Validator validator = ValidatorProxy.newInstanceOf("ClassNotFound", Object.class, new Object());
        
        assertNotNull(validator);
        assertTrue(validator instanceof RouteTableValidator);
    }
}
