package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.core.jaxb.propertypage.Action;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertFalse;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class ValueAddressNsapTest {

    public static final String ADDRESS = "540072872203010046208101";
    private ValueDescriptor descriptor;
    private ValueAddressNsap valueNsap;

    @Before
    public void setup() {
        descriptor = new ValueDescriptor("1", new ArrayList<Action>(), "false", true);
        valueNsap = new ValueAddressNsap(descriptor);
    }

    @Test
    public void testSetContent() {
        valueNsap.setContent(ADDRESS);
        assertThat(valueNsap.getContent(), CoreMatchers.is(ADDRESS));
    }
    
    @Test
    public void testGetContent() {
        valueNsap.setContent("TEST");
        valueNsap.setText(ADDRESS);
        assertTrue(valueNsap.isChanged());
        assertThat(valueNsap.getContent(), CoreMatchers.is(ADDRESS));
    }

    @Test
    public void testGetContent_nochanges() {
        valueNsap.setContent("540072872203127000000001");
        assertFalse(valueNsap.isChanged());
        assertThat(valueNsap.getContent(), CoreMatchers.is("540072872203127000000001"));
    }

    @Test
    public void testGetContent_valid() {
        valueNsap.setContent("540072872203127000000001");

        assertFalse(valueNsap.isInvalidEntry());
    }

    @Test public void shouldModifyValue() throws Exception {
        valueNsap.setContent("540072872203127000000001");

        valueNsap.modifyContent("540072872203127000022222");

        assertThat(valueNsap.getContent(), is("540072872203127000022222"));
    }

    @Test public void shouldMarkChangedOnModify() throws Exception {
        valueNsap.setContent("540072872203127000000001");

        valueNsap.modifyContent("540072872203127000022222");

        assertThat(valueNsap.isChanged(), is(true));
    }
}
