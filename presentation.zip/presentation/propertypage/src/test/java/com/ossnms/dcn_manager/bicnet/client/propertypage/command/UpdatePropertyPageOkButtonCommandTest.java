package com.ossnms.dcn_manager.bicnet.client.propertypage.command;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

public class UpdatePropertyPageOkButtonCommandTest {

    private INE ne;
    private Repository<Integer, INE> repository;
    private ISessionContext context;
    private PropertyValueRepository valueRepository;
    private Map<String, String> properties;

    private UpdatePropertyPageOkButtonCommand<Integer, INE, Repository<Integer, INE>> updatePropertyPageOkButtonCommand;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        ne = mock(INE.class);
        repository = mock(Repository.class);
        context = mock(ISessionContext.class);
        valueRepository = mock(PropertyValueRepository.class);

        updatePropertyPageOkButtonCommand = new UpdatePropertyPageOkButtonCommand<>(ImmutableList.of(ne), repository, context);
        properties = ImmutableMap.of();
    }

    @Test
    public void testCall() throws RepositoryException {
        when(valueRepository.allChangedValuesMap()).thenReturn(properties);

        updatePropertyPageOkButtonCommand.call(valueRepository);

        verify(repository, times(1)).update(context, ne, properties);
        verify(valueRepository, times(1)).allChangedValuesMap();
    }
    
    @Test(expected=RepositoryException.class)
    public void testCallWithErrors() throws RepositoryException {
        doThrow(new RepositoryException()).when(repository).update(context, ne, properties);
        
        updatePropertyPageOkButtonCommand.call(valueRepository);
    }
}
