package com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import com.coriant.widgets.ClientProperties;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor.AddressCellEditor;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor.CellColor;
import com.ossnms.tools.jfx.components.JfxIPField;

public class AddressCellEditorTest {

    @Test
    public void testStopCellEditing() {
        final AddressCellEditor editor = new AddressCellEditor(new JfxIPField("127.0.0.1"));
        assertTrue(editor.stopCellEditing());
    }

    @Test
    public void testVerify_valid() {
        final AddressCellEditor editor = new AddressCellEditor(new JfxIPField("127.0.0.1"));

        assertTrue(editor.getComponent().getInputVerifier().verify(editor.getComponent()));

        assertTrue(editor.getComponent().getInputVerifier().shouldYieldFocus(editor.getComponent()));
        assertThat(editor.getComponent().getBackground(), CoreMatchers.is(CellColor.DEFAULT.color()));
        assertThat(Boolean.valueOf(editor.getComponent().getClientProperty(ClientProperties.INVALID).toString()), CoreMatchers.is(false));
    }

    @Test
    public void testVerify_not_valid() {
        final AddressCellEditor editor = new AddressCellEditor(new JfxIPField("127.0.0."));

        assertFalse(editor.getComponent().getInputVerifier().verify(editor.getComponent()));

        assertTrue(editor.getComponent().getInputVerifier().shouldYieldFocus(editor.getComponent()));
        assertThat(editor.getComponent().getBackground(), CoreMatchers.is(CellColor.ERROR.color()));
        assertThat(Boolean.valueOf(editor.getComponent().getClientProperty(ClientProperties.INVALID).toString()), CoreMatchers.is(true));
    }
    
    @Test
    public void testVerify_empty() {
        final AddressCellEditor editor = new AddressCellEditor(new JfxIPField(""));

        assertTrue(editor.getComponent().getInputVerifier().verify(editor.getComponent()));

        assertTrue(editor.getComponent().getInputVerifier().shouldYieldFocus(editor.getComponent()));
        assertThat(editor.getComponent().getBackground(), CoreMatchers.is(CellColor.DEFAULT.color()));
        assertThat(Boolean.valueOf(editor.getComponent().getClientProperty(ClientProperties.INVALID).toString()), CoreMatchers.is(false));
    }
}
