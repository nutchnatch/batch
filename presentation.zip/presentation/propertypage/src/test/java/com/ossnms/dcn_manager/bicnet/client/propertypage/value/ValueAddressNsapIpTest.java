package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.core.jaxb.propertypage.Action;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertFalse;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class ValueAddressNsapIpTest {

    private ValueDescriptor descriptor;
    private ValueAddressNsapIp valueNsapIp;

    @Before
    public void setup() {
        descriptor = new ValueDescriptor("1", new ArrayList<Action>(), "false", true);
        valueNsapIp = new ValueAddressNsapIp(descriptor);
    }

    @Test
    public void testSetContent_nsap_rfc1277() {
        valueNsapIp.setContent("540072872203127000000001");
        assertThat(valueNsapIp.getText(), CoreMatchers.is("127.0.0.1"));
    }
    
    @Test
    public void testSetContent_nsap_rfc1277_with_port() {
        valueNsapIp.setContent("5400728722031270000000010808000001");
        assertThat(valueNsapIp.getText(), CoreMatchers.is("127.0.0.1:8080"));
    }

    @Test
    public void testSetContent_nsap() {
        valueNsapIp.setContent("AAAAAAAAAAAAAAAAAAAAAAA");
        assertThat(valueNsapIp.getContent(), CoreMatchers.is("AAAAAAAAAAAAAAAAAAAAAAA"));
    }
    
    @Test
    public void testGetContent_nsap_rfc1277() {
        valueNsapIp.setContent("TEST");
        valueNsapIp.setText("540072872203127000000001");
        assertTrue(valueNsapIp.isChanged());
        assertThat(valueNsapIp.getContent(), CoreMatchers.is("540072872203127000000001"));
    }
    
    @Test
    public void testGetContent_nsap_rfc1277_with_port() {
        valueNsapIp.setContent("TEST");
        valueNsapIp.setText("5400728722031270000000010808000001");
        assertTrue(valueNsapIp.isChanged());
        assertThat(valueNsapIp.getContent(), CoreMatchers.is("5400728722031270000000010808000001"));
    }

    @Test
    public void testGetContent_nsap() {
        valueNsapIp.setContent("TEST");
        valueNsapIp.setText("AAAAAAAAAAAAAAAAAAAAAAA");
        assertTrue(valueNsapIp.isChanged());
        assertThat(valueNsapIp.getContent(), CoreMatchers.is("AAAAAAAAAAAAAAAAAAAAAAA"));
    }
    
    @Test
    public void testGetContent_nochanges_nsap_rfc1277() {
        valueNsapIp.setContent("540072872203127000000001");
        assertFalse(valueNsapIp.isChanged());
        assertThat(valueNsapIp.getContent(), CoreMatchers.is("540072872203127000000001"));
    }
    
    @Test
    public void testGetContent_nochanges_nsap_rfc1277_with_port() {
        valueNsapIp.setContent("5400728722031270000000010808000001");
        assertFalse(valueNsapIp.isChanged());
        assertThat(valueNsapIp.getContent(), CoreMatchers.is("5400728722031270000000010808000001"));
    }

    @Test
    public void testGetContent_nochanges_nsap() {
        valueNsapIp.setContent("AAAAAAAAAAAAAAAAAAAAAAA");
        assertFalse(valueNsapIp.isChanged());
        assertThat(valueNsapIp.getContent(), CoreMatchers.is("AAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void testGetContent_valid_nsap() {
        valueNsapIp.setContent("540072872203127000000001");

        assertFalse(valueNsapIp.isInvalidEntry());
    }

    @Test public void shouldModifyValue() throws Exception {
        valueNsapIp.setContent("540072872203127000000001");

        valueNsapIp.modifyContent("540072872203127000022222");

        assertThat(valueNsapIp.getContent(), is("540072872203127000022222"));
    }

    @Test public void shouldMarkChangedOnModify() throws Exception {
        valueNsapIp.setContent("540072872203127000000001");

        valueNsapIp.modifyContent("540072872203127000022222");

        assertThat(valueNsapIp.isChanged(), is(true));
    }
}
