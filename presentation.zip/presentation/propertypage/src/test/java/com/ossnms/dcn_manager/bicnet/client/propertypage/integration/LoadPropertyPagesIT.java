package com.ossnms.dcn_manager.bicnet.client.propertypage.integration;

import com.google.common.base.Strings;
import com.google.common.collect.Iterables;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepositorySingleton;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.page.PageBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ContainerCacheManager;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ContainerType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlStaticTypesConfiguration;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.JScrollPane;
import java.util.ArrayList;
import java.util.Optional;
import java.util.stream.StreamSupport;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.junit.Assert.fail;

/**
 * Integration test to verify all property pages construction.
 */
public class LoadPropertyPagesIT {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoadPropertyPagesIT.class);

    private PropertyPagesRepository repository;
    private XmlStaticTypesConfiguration configuration;
    private PropertyValueRepository valueRepository;

    public LoadPropertyPagesIT() {
        repository = PropertyPagesRepositorySingleton.getInstance();
        configuration = new XmlStaticTypesConfiguration();
    }

    @Before public void setUp() throws Exception {
        valueRepository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
    }

    @After public void tearDown() throws Exception {
        valueRepository.clear();
        valueRepository = null;
    }

    @Test public void testLoadChannelTypesPropertyPage() throws PropertyValueBuilderException {
        for (final ChannelType type : configuration.getChannelTypes().values()) {
            try {
                LOGGER.info("Building ChannelType={}", type.getName());
                final Page page = repository.getPropertyPage(type);

                assertFalse(Strings.isNullOrEmpty(type.getHelpID()));
                assertFalse(Strings.isNullOrEmpty(type.getName()));
                assertFalse(Strings.isNullOrEmpty(type.getDefaultIcon()));

                assertNotNull(page);
                assertFalse(page.getTabbedPane().isEmpty());
                assertFalse(Strings.isNullOrEmpty(page.getTitle()));
                assertFalse(Strings.isNullOrEmpty(page.getVersion()));

                final JScrollPane propertyPage = new PageBuilder(page, valueRepository).build();
                assertNotNull(propertyPage);
                assertFalse(Iterables.isEmpty(valueRepository.allValues()));

                verifyIfHasBlankGuiNames(type.getName());
            } catch (final Exception e) {
                LOGGER.error("Error to build the property pages for ChannelType={}", type.getName());
                fail(e.getMessage());
            }
        }
    }

    @Test public void testLoadMediatorTypesPropertyPage() throws PropertyValueBuilderException {
        for (final MediatorType type : configuration.getMediatorTypes().values()) {
            try {
                LOGGER.info("Building MediatorType={}", type.getName());
                final Page page = repository.getPropertyPage(type);

                assertFalse(Strings.isNullOrEmpty(type.getHelpID()));
                assertFalse(Strings.isNullOrEmpty(type.getName()));
                assertFalse(Strings.isNullOrEmpty(type.getDefaultIcon()));

                assertNotNull(page);
                assertFalse(page.getTabbedPane().isEmpty());
                assertFalse(Strings.isNullOrEmpty(page.getTitle()));
                assertFalse(Strings.isNullOrEmpty(page.getVersion()));

                final JScrollPane propertyPage = new PageBuilder(page, valueRepository).build();
                assertNotNull(propertyPage);
                assertFalse(Iterables.isEmpty(valueRepository.allValues()));

                verifyIfHasBlankGuiNames(type.getName());
            } catch (final Exception e) {
                LOGGER.error("Error to build the property pages for MediatorType={}", type.getName());
                fail(e.getMessage());
            }
        }
    }

    @Test public void testLoadNeTypesPropertyPage() {
        ContainerCacheManager.getInstance().cache().fetch(new ArrayList<>());

        for (final NeType type : configuration.getNeTypes().values()) {
            try {
                LOGGER.info("Building NeType={}", type.getName());
                final Page page = repository.getPropertyPage(type);

                assertFalse(Strings.isNullOrEmpty(type.getHelpID()));
                assertFalse(Strings.isNullOrEmpty(type.getName()));
                assertFalse(Strings.isNullOrEmpty(type.getDefaultIcon()));

                assertNotNull(page);
                assertFalse(page.getTabbedPane().isEmpty());
                assertFalse(Strings.isNullOrEmpty(page.getTitle()));
                assertFalse(Strings.isNullOrEmpty(page.getVersion()));

                final JScrollPane propertyPage = new PageBuilder(page, valueRepository).build();
                assertNotNull(propertyPage);
                assertFalse(Iterables.isEmpty(valueRepository.allValues()));

                verifyIfHasBlankGuiNames(type.getName());
            } catch (final Exception e) {
                LOGGER.error("Error to build the property pages for NeType=" + type.getName(), e);
                fail(e.getMessage());
            }
        }
    }

    @Test public void testLoadContainerTypesPropertyPage() throws PropertyValueBuilderException {
        for (final ContainerType type : configuration.getContainerTypes().values()) {
            try {
                LOGGER.info("Building ContainerType={}", type.getName());
                final Page page = repository.getPropertyPage(type);

                assertFalse(Strings.isNullOrEmpty(type.getHelpID()));
                assertFalse(Strings.isNullOrEmpty(type.getName()));
                assertFalse(Strings.isNullOrEmpty(type.getDefaultIcon()));

                assertNotNull(page);
                assertFalse(page.getTabbedPane().isEmpty());
                assertFalse(Strings.isNullOrEmpty(page.getTitle()));
                assertFalse(Strings.isNullOrEmpty(page.getVersion()));

                final JScrollPane propertyPage = new PageBuilder(page, valueRepository).build();
                assertNotNull(propertyPage);
                assertFalse(Iterables.isEmpty(valueRepository.allValues()));

                verifyIfHasBlankGuiNames(type.getName());
            } catch (final Exception e) {
                LOGGER.error("Error to build the property pages for ContainerType={}", type.getName());
                fail(e.getMessage());
            }
        }
    }

    private void verifyIfHasBlankGuiNames(String type) {
        Optional<PropertyValue> propertyValue = StreamSupport.stream(valueRepository.allValues().spliterator(), false)
                .filter(p -> isBlank(p.getName()) || p.getName().equals("FIELD.null")).findFirst();

        propertyValue
                .ifPresent(p -> fail("Type name=(" + type + "). The GuiName is blank for property id=" + p.getId()));
    }
}
