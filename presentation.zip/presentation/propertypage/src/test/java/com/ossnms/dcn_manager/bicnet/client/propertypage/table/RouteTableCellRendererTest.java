package com.ossnms.dcn_manager.bicnet.client.propertypage.table;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableCellRenderer;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableModel;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor.CellColor;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextField;
import com.ossnms.tools.jfx.components.JfxLabel;

public class RouteTableCellRendererTest {
        
    private static final int ROW = 0;
    private static final int COLUMN = 1;
    
    private final RouteTableCellRenderer renderer;
    private RouteTableModel model;
    private JTable table;
    private ValueJfxTextField value;
    
    public RouteTableCellRendererTest() {
        renderer = new RouteTableCellRenderer();
    }

    @Before
    public void setup() {
        this.model = mock(RouteTableModel.class);
        this.table = mock(JTable.class);
        this.value = mock(ValueJfxTextField.class);
                
        when(table.getModel()).thenReturn(model);
        when(model.getPropertyValueAt(ROW, COLUMN)).thenReturn(value); 
        when(model.getColumnName(COLUMN)).thenReturn("Other Column");
        when(table.getSelectionBackground()).thenReturn(Color.GRAY);
        when(value.getBackground()).thenReturn(CellColor.ERROR.color());
        
    }
    
    @Test
    public void testUnchangedComponent() {
        when(value.isInvalidEntry()).thenReturn(false);
        
        final Component component = renderer.getTableCellRendererComponent(table, "true", true, true, ROW, COLUMN);
        
        assertThat(component.getBackground(), is(Color.GRAY));
        assertFalse(component instanceof JfxLabel);
        
        verify(value, never()).getBackground();
        verify(model, times(1)).getPropertyValueAt(ROW, COLUMN);
        verify(model, times(1)).getColumnName(COLUMN);
    }
    
    @Test
    public void testInvalidComponent() {
        when(value.isInvalidEntry()).thenReturn(true);
        
        final Component component = renderer.getTableCellRendererComponent(table, "true", true, true, ROW, COLUMN);
        
        assertThat(component.getBackground(), is(CellColor.ERROR.color()));
        assertFalse(component instanceof JfxLabel);
        
        verify(value, times(1)).getBackground();
        verify(model, times(1)).getPropertyValueAt(ROW, COLUMN);
        verify(model, times(1)).getColumnName(COLUMN);
    }
    
    @Test
    public void testRouteUsed() {
        when(value.isInvalidEntry()).thenReturn(false);
        when(model.getColumnName(COLUMN)).thenReturn("Used");
        when(value.getContent()).thenReturn("true");
        
        final Component component = renderer.getTableCellRendererComponent(table, "true", true, true, ROW, COLUMN);
        
        assertTrue(component instanceof JfxLabel);
        
        verify(value, never()).getBackground();
        verify(model, times(2)).getPropertyValueAt(ROW, COLUMN);
        verify(model, times(1)).getColumnName(COLUMN);
    }
    
    @Test
    public void testNotRouteUsed() {
        when(value.isInvalidEntry()).thenReturn(false);
        when(model.getColumnName(COLUMN)).thenReturn("Used");
        when(value.getContent()).thenReturn("false");
        
        final Component component =  renderer.getTableCellRendererComponent(table, "true", true, true, ROW, COLUMN);
        
        assertTrue(component instanceof JfxLabel);
        assertNull(((JfxLabel)component).getIcon());
        
        verify(value, never()).getBackground();
        verify(model, times(2)).getPropertyValueAt(ROW, COLUMN);
        verify(model, times(1)).getColumnName(COLUMN);
    }
}
