package com.ossnms.dcn_manager.bicnet.client.propertypage.controller;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;
import java.util.Optional;

import static com.jayway.awaitility.Awaitility.await;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class SingleSelectionPropertyValueFlowTest {

    private PropertyValue value;
    private SingleSelectionPropertyValueFlow flow;
    private PropertyValueRepository repository;
    private Map<String, String> primaryProperties;
    private WellKnownPropertiesAddOrModify replacer;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        value = mock(PropertyValue.class);
        repository = mock(PropertyValueRepository.class);
        primaryProperties = mock(Map.class);
        replacer = mock(WellKnownPropertiesAddOrModify.class);
        flow = new SingleSelectionPropertyValueFlow();
    }

    @Test
    public void testBuildFilterForChangedValues_changed() {
        when(value.isChanged()).thenReturn(true);

        final Optional<PropertyValue> filtered = ImmutableList.of(value).stream().filter(flow.buildFilterForChangedValues()::apply).findFirst();

        assertThat(filtered.isPresent(), CoreMatchers.is(true));
        assertThat(filtered.get(), CoreMatchers.is(value));

        verify(value).isChanged();
        verify(value, never()).forceSendOnUpdate();
    }

    @Test
    public void testBuildFilterForChangedValues_forceSendOnUpdate() {
        when(value.isChanged()).thenReturn(false);
        when(value.forceSendOnUpdate()).thenReturn(true);

        final Optional<PropertyValue> filtered = ImmutableList.of(value).stream().filter(flow.buildFilterForChangedValues()::apply).findFirst();

        assertThat(filtered.isPresent(), CoreMatchers.is(true));
        assertThat(filtered.get(), CoreMatchers.is(value));

        verify(value).forceSendOnUpdate();
        verify(value).isChanged();
    }

    @Test
    public void testBuildFilterForChangedValues_false() {
        when(value.isChanged()).thenReturn(false);
        when(value.forceSendOnUpdate()).thenReturn(false);

        final Optional<PropertyValue> filtered = ImmutableList.of(value).stream().filter(flow.buildFilterForChangedValues()::apply).findFirst();

        assertThat(filtered.isPresent(), CoreMatchers.is(false));

        verify(value).forceSendOnUpdate();
        verify(value).isChanged();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdatePropertyValueRepository_error_flow() {
        flow.updatePropertyValueRepository(repository, new ElementsSelection<>(1));
    }

    @Test
    public void testUpdatePropertyValueRepository_with_replacer() {
        flow = new SingleSelectionPropertyValueFlow(replacer);
        flow.updatePropertyValueRepository(repository, new ElementsSelection<>(1).primaryProperties(primaryProperties));

        await().atMost(2, SECONDS).until(() -> 
                verify(replacer).accept(repository));
    }
}
