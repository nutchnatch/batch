package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.StaticConfigurationValue;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Static;

public class StaticConfigurationValueTest {
    
    @Test
    public void testCreate() {
        final StaticConfigurationValue staticVariable = new StaticConfigurationValue("id", "value");

        assertThat(staticVariable.getId(), is("id"));
        assertThat(staticVariable.getContent(), is("value"));

        assertFalse(staticVariable.isChanged());
        assertFalse(staticVariable.isMandatoryValueBlank());
        assertFalse(staticVariable.isEnabled());
        assertFalse(staticVariable.isInvalidEntry());
        assertFalse(staticVariable.isMovable());
        assertTrue(staticVariable.getValueActions().isEmpty());
    }

    @Test
    public void testCreateByStaticObject() {
        final Static staticValue = new Static();
        staticValue.setId("id");
        staticValue.setValue("value");

        final StaticConfigurationValue staticVariable = new StaticConfigurationValue(staticValue);

        assertThat(staticVariable.getId(), is("id"));
        assertThat(staticVariable.getContent(), is("value"));
    }

    @Test
    public void testChangeContent() {
        final StaticConfigurationValue staticVariable = new StaticConfigurationValue("id", "value");

        staticVariable.setContent("value2");
        
        assertThat(staticVariable.getContent(), is("value"));
    }
}
