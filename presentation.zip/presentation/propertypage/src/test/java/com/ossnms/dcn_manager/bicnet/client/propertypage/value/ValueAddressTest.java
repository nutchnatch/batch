package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.net.URL;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class ValueAddressTest {

    private static final URL XML_URL = ValueAddressTest.class.getClassLoader().getResource("value-address.xml");
    
    private final XmlFileLoader loader = new XmlFileLoader();
    private Value value;
    private ValueAddress address;
    
    @Before
    public void setup() throws PropertyValueBuilderException {
        value = loader.loadConfiguration(Property.class, XML_URL, null).getValue();
        address = (ValueAddress) ValueTypeFactory.createOf(value, new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow()));
    }
    
    @After
    public void release() {
        address = null;
    }
    
    @Test
    public void testCreateObject() {
        assertNotNull(address);
        
        address.addConditionListener(new ChangeListener() {
            @Override
            public void stateChanged(final ChangeEvent e) {
            }
        });
        
        assertThat(address.isMandatoryEntry(), is(true));
        assertThat(address.getColumns(), is(20));
        assertThat(address.getId(), is("test-address"));
        assertThat(address.getName(), is("FIELD.NetworkElementIp"));
        assertThat(address.getContent(), is("127.0.0.1"));
        assertThat(address.isMandatoryEntry(), is(true));
        assertThat(address.isChanged(), is(false));
        assertThat(address.getValueActions().isEmpty(), is(true));
        assertThat(address.isMandatoryValueBlank(), is(false));
    }
    
    @Test
    public void testChangeObject() {
        assertNotNull(address);
        
        address.setText("198.0.0.1");
        
        assertThat(address.isMandatoryValueBlank(), is(false));
        assertThat(address.isChanged(), is(true));
    }
    
    @Test
    public void testSetContent() {
        assertNotNull(address);
        
        address.setContent("198.0.0.1");
        
        assertThat(address.isMandatoryValueBlank(), is(false));
        assertThat(address.isChanged(), is(false));
    }
    
    @Test
    public void testSetEmptyContent() {
        assertNotNull(address);
        
        address.setContent("");
        
        assertThat(address.getContent(), is(""));        
        assertThat(address.isMandatoryValueBlank(), is(true));
        assertThat(address.isChanged(), is(false));
    }
    
    @Test
    public void testOnCleanOnDisable() {
        assertNotNull(address);
        
        address.onCleanOnDisable(true);
        
        assertThat(address.getText().isEmpty(), is(true));
        assertThat(address.isMandatoryValueBlank(), is(true));
        assertThat(address.isChanged(), is(true));
    }
    
    @Test
    public void testOnWritableFalse() {
        assertNotNull(address);
        
        address.onWritable(false);
        
        assertThat(address.isEnabled(), is(false));
        assertThat(address.getText().isEmpty(), is(false));
        assertThat(address.isMandatoryValueBlank(), is(false));
        assertThat(address.isChanged(), is(false));
    }
    
    @Test
    public void testOnWritableTrue() {
        assertNotNull(address);
        
        address.onWritable(true);
        
        assertThat(address.isEnabled(), is(true));
        assertThat(address.getText().isEmpty(), is(false));
        assertThat(address.isMandatoryValueBlank(), is(false));
        assertThat(address.isChanged(), is(false));
    }
    
    @Test(expected=UnsupportedOperationException.class)
    public void testOnValueFromConditionResult() {
        assertNotNull(address);
        
        address.onValueFromConditionResult(true);        
    }
    
    @Test
    public void testMultiselection() {
        assertNotNull(address);
        
        address.setContent(MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN);
        
        assertThat(address.isUndefined(), is(true));        
    }
    
    @Test public void shouldModifyValue() throws Exception {
        address.setContent("127.0.0.1");
        
        address.modifyContent("10.0.0.1");

        assertThat(address.getContent(), is("10.0.0.1"));
    }

    @Test public void shouldMarkChangedOnModify() throws Exception {
        address.setContent("127.0.0.1");

        address.modifyContent("10.0.0.1");

        assertThat(address.isChanged(), is(true));
    }
}
