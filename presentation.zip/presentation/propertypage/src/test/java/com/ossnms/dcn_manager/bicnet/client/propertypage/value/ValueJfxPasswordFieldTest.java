package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.bicnet.util.crypt.DESEncrypterDecrypter;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.net.URL;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;

import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class ValueJfxPasswordFieldTest {

    private static final URL XML_URL = ValueJfxPasswordFieldTest.class.getClassLoader().getResource("value-password.xml");
    
    private final XmlFileLoader loader = new XmlFileLoader();
    private final Value value;
    private ValueJfxPasswordField password;
    private final String pwd;
    
    private final DESEncrypterDecrypter encrypter;

    public ValueJfxPasswordFieldTest() {
        encrypter = getEncrypter();
        pwd = encrypter.encryptData("123456");
        value = loader.loadConfiguration(Property.class, XML_URL, null).getValue();
    }
        
    private DESEncrypterDecrypter getEncrypter() {
        try {
            return new DESEncrypterDecrypter();
        } catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
            throw new UnsupportedOperationException(e);
        }
    }
    
    @Before
    public void setup() throws PropertyValueBuilderException {
        password = (ValueJfxPasswordField) ValueTypeFactory.createOf(value, new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow()));
        password.setContent(pwd);
    }
    
    @After
    public void release() {
        password = null;
    }
    
    @Test
    public void testCreateObject() {
        assertNotNull(password);
        
        password.addConditionListener(e -> {
        });
        
        assertThat(password.isMandatoryEntry(), is(true));
        assertThat(password.getColumns(), is(20));
        assertThat(password.getId(), is("test-pwd"));
        assertThat(password.getName(), is("FIELD.Password"));
        assertThat(password.getContent(), is(pwd));
        assertThat(password.isMandatoryEntry(), is(true));
        assertThat(password.isChanged(), is(false));
        assertThat(password.getValueActions().isEmpty(), is(true));
        assertThat(password.isMandatoryValueBlank(), is(false));
    }
    
    @Test
    public void testChangeObject() {
        assertNotNull(password);
        
        password.setText("123456");
        
        assertThat(password.isMandatoryValueBlank(), is(false));
        assertThat(password.isChanged(), is(true));
        assertThat(password.getContent(), is(pwd));
    }
    
    @Test
    public void testSetContent() {
        assertNotNull(password);
        
        password.setContent(pwd);
        
        assertThat(password.isMandatoryValueBlank(), is(false));
        assertThat(password.isChanged(), is(false));
        assertThat(password.getContent(), is(pwd));
    }
    
    @Test
    public void testSetNullContent() {
        assertNotNull(password);
        
        password.setContent(null);
        
        assertTrue(password.getContent().isEmpty());        
        assertThat(password.isMandatoryValueBlank(), is(true));
        assertThat(password.isChanged(), is(false));
    }
    
    @Test
    public void testOnCleanOnDisable() {
        assertNotNull(password);
        
        password.onCleanOnDisable(true);
        
        assertThat(password.getContent().isEmpty(), is(true));
        assertThat(password.isMandatoryValueBlank(), is(true));
        assertThat(password.isChanged(), is(true));
    }
    
    @Test
    public void testOnWritableFalse() {
        assertNotNull(password);
        
        password.onWritable(false);
        
        assertThat(password.isEnabled(), is(false));
        assertThat(password.getContent().isEmpty(), is(false));
        assertThat(password.isMandatoryValueBlank(), is(false));
        assertThat(password.isChanged(), is(false));
    }
    
    @Test
    public void testOnWritableTrue() {
        assertNotNull(password);
        
        password.onWritable(true);
        
        assertThat(password.isEnabled(), is(true));
        assertThat(password.getContent().isEmpty(), is(false));
        assertThat(password.isMandatoryValueBlank(), is(false));
        assertThat(password.isChanged(), is(false));
    }
    
    @Test
    public void testToString() {
        assertNotNull(password);
        
        password.setText("123");
        
        assertThat(password.toString(), not(containsString("123")));
    }
    
    @Test(expected=UnsupportedOperationException.class)
    public void testOnValueFromConditionResult() {
        assertNotNull(password);
        
        password.onValueFromConditionResult(true);        
    }

    @Test public void shouldModifyValue() throws Exception {
        password.setContent("password");

        password.modifyContent("changed password");

        assertThat(password.getContent(), is(encrypted("changed password")));
    }

    @Test public void shouldMarkChangedOnModify() throws Exception {
        password.setContent("password");

        password.modifyContent("changed password");

        assertThat(password.isChanged(), is(true));
    }

    private String encrypted(String pwd) {
        return encrypter.encryptData(pwd);
    }
}
