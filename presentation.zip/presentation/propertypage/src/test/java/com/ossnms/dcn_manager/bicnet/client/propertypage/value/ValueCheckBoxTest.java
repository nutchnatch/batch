package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.net.URL;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class ValueCheckBoxTest {

    private static final URL XML_URL = ValueCheckBoxTest.class.getClassLoader().getResource("value-checkbox.xml");
    
    private final XmlFileLoader loader = new XmlFileLoader();
    private final Value value;
    private ValueJfxCheckBox checkBox;
    
    public ValueCheckBoxTest() {
        this.value = loader.loadConfiguration(Property.class, XML_URL, null).getValue();
    }
    
    @Before
    public void setup() throws PropertyValueBuilderException {
        this.checkBox = (ValueJfxCheckBox) ValueTypeFactory.createOf(value, new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow()));
    }
    
    @After
    public void release() {
        this.checkBox = null;
    }
    
    @Test
    public void testCreateObject() {
        assertNotNull(checkBox);
        
        checkBox.addConditionListener(new ChangeListener() {
            @Override
            public void stateChanged(final ChangeEvent e) {
            }
        });
        
        assertThat(checkBox.getId(), is("test-checkbox"));
        assertThat(checkBox.getText(), is("Auto priority"));
        assertThat(checkBox.getName(), is("FIELD.AutoPriority"));
        assertThat(checkBox.getContent(), is("true"));
        assertThat(checkBox.isChanged(), is(false));
        assertThat(checkBox.getValueActions().isEmpty(), is(true));
        assertThat(checkBox.isMandatoryValueBlank(), is(false));
    }
    
    @Test
    public void testChangeObject() {
        assertNotNull(checkBox);
        
        checkBox.setSelected(false);
        
        assertThat(checkBox.isMandatoryValueBlank(), is(false));
        assertThat(checkBox.isChanged(), is(true));
    }
    
    @Test
    public void testSetContent() {
        assertNotNull(checkBox);
        
        checkBox.setContent("false");
        
        assertThat(checkBox.isMandatoryValueBlank(), is(false));
        assertThat(checkBox.isChanged(), is(false));
    }
    
    @Test
    public void testSetEmptyContent() {
        assertNotNull(checkBox);
        
        checkBox.setContent("");
        
        assertThat(checkBox.getContent(), is("false"));
        assertThat(checkBox.isMandatoryValueBlank(), is(false));
        assertThat(checkBox.isChanged(), is(false));
    }
    
    @Test
    public void testOnCleanOnDisable() {
        assertNotNull(checkBox);
        
        checkBox.onCleanOnDisable(true);
        
        assertThat(checkBox.isPending(), is(true));
        assertThat(checkBox.isMandatoryValueBlank(), is(false));
        assertThat(checkBox.isChanged(), is(true));
    }
    
    @Test
    public void testOnWritableFalse() {
        assertNotNull(checkBox);
        
        checkBox.onWritable(false);
        
        assertThat(checkBox.isEnabled(), is(false));
        assertThat(checkBox.getText().isEmpty(), is(false));
        assertThat(checkBox.isMandatoryValueBlank(), is(false));
        assertThat(checkBox.isChanged(), is(false));
    }
    
    @Test
    public void testOnWritableTrue() {
        assertNotNull(checkBox);
        
        checkBox.onWritable(true);
        
        assertThat(checkBox.isEnabled(), is(true));
        assertThat(checkBox.getText().isEmpty(), is(false));
        assertThat(checkBox.isMandatoryValueBlank(), is(false));
        assertThat(checkBox.isChanged(), is(false));
    }
    
    @Test
    public void testOnValueFromConditionResultTrue() {
        assertNotNull(checkBox);
        
        checkBox.onValueFromConditionResult(true);
        
        assertThat(checkBox.isMandatoryValueBlank(), is(false));
        assertThat(checkBox.isChanged(), is(false));
    }
    
    @Test
    public void testOnValueFromConditionResultFalse() {
        assertNotNull(checkBox);
        
        checkBox.onValueFromConditionResult(false);
        
        assertThat(checkBox.isMandatoryValueBlank(), is(false));
        assertThat(checkBox.isChanged(), is(true));
    }
    
    @Test
    public void testMultiselection() {
        assertNotNull(checkBox);
        
        checkBox.setContent(MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN);
        
        assertThat(checkBox.isPending(), is(true));        
    }

    @Test public void shouldModifyValue() throws Exception {
        checkBox.setContent("false");

        checkBox.modifyContent("true");

        assertThat(checkBox.getContent(), is("true"));
    }

    @Test public void shouldMarkChangedOnModify() throws Exception {
        checkBox.setContent("false");

        checkBox.modifyContent("true");

        assertThat(checkBox.isChanged(), is(true));
    }
}
