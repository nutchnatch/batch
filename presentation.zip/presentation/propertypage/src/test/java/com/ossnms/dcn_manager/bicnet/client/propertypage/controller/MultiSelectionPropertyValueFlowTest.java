package com.ossnms.dcn_manager.bicnet.client.propertypage.controller;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.AbstractPropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import static com.jayway.awaitility.Awaitility.await;
import static com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MultiSelectionPropertyValueFlowTest {

    private Map<String, String> primaryProperties;
    private Map<String, String> secondaryOneProperties;
    private Map<String, String> secondaryTwoProperties;

    private Iterable<Map<String, String>> secondariesProperties;

    private PropertyValueRepository valueRepository;
    
    private PropertyValue value;
    private WellKnownPropertiesAddOrModify replacer;
    private MultiSelectionPropertyValueFlow flow;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        value = mock(PropertyValue.class);
        replacer = mock(WellKnownPropertiesAddOrModify.class);
        
        primaryProperties = new HashMap<>();
        primaryProperties.put("id1", "value1");
        primaryProperties.put("id2", "value2");
        primaryProperties.put("id3", "value3");
        primaryProperties.put("id4", "value4");
        primaryProperties.put("id7", "value7");
        primaryProperties.put("id8", "");
        primaryProperties.put("id9", "");

        secondaryOneProperties = new HashMap<>();
        secondaryOneProperties.put("id1", "value1");
        secondaryOneProperties.put("id2", "value2");
        secondaryOneProperties.put("id5", "value5");
        secondaryOneProperties.put("id7", "value7");
        secondaryOneProperties.put("id8", "");
        secondaryOneProperties.put("id9", "");

        secondaryTwoProperties = new HashMap<>();
        secondaryTwoProperties.put("id1", "value_diferent");
        secondaryTwoProperties.put("id2", "value2");
        secondaryTwoProperties.put("id4", "value4");
        secondaryTwoProperties.put("id5", "value5");
        secondaryTwoProperties.put("id6", "value6");
        secondaryTwoProperties.put("id7", "value7");
        secondaryTwoProperties.put("id8", "");
        secondaryTwoProperties.put("id9", null);

        secondariesProperties = ImmutableList.of(secondaryOneProperties, secondaryTwoProperties);
        
        flow = new MultiSelectionPropertyValueFlow(replacer);
        
        valueRepository = new PropertyValueRepositoryImpl(flow);

        for (final Entry<String, String> entry : primaryProperties.entrySet()) {
            valueRepository.add(new DummyValue(entry.getKey(), entry.getValue()));
        }

        ((DummyValue) valueRepository.find("id2").get()).setSupportMultiselection(false);
    }

    @After
    public void release() {
        valueRepository.clear();
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testProcessFlow() throws Exception {
        final ElementsSelection<Integer> selection = new ElementsSelection<>(1)
                .primaryProperties(primaryProperties)
                .secondariesId(ImmutableList.of(2,3))
                .secondariesProperties(secondariesProperties)
                .secondariesTemplates(secondariesProperties);
        
        flow.updatePropertyValueRepository(valueRepository, selection);

        await().atMost(5, SECONDS)
                .until(() -> valueRepository.find("id1").get().getContent().equals(MULTIPLE_VALUES_TOKEN));

        assertThat(valueRepository.find("id5").isPresent(), CoreMatchers.is(false));
        assertThat(valueRepository.find("id6").isPresent(), CoreMatchers.is(false));

        assertThat(valueRepository.find("id1").get().getContent(), CoreMatchers.is(MULTIPLE_VALUES_TOKEN));
        assertThat(valueRepository.find("id1").get().isEnabled(), CoreMatchers.is(true));

        assertThat(valueRepository.find("id2").get().getContent(), CoreMatchers.is("value2"));
        assertThat(valueRepository.find("id2").get().isEnabled(), CoreMatchers.is(false));

        assertThat(valueRepository.find("id3").get().getContent(), CoreMatchers.is(MULTIPLE_VALUES_TOKEN));
        assertThat(valueRepository.find("id3").get().isEnabled(), CoreMatchers.is(false));

        assertThat(valueRepository.find("id4").get().getContent(), CoreMatchers.is(MULTIPLE_VALUES_TOKEN));
        assertThat(valueRepository.find("id4").get().isEnabled(), CoreMatchers.is(false));
        
        assertThat(valueRepository.find("id7").get().getContent(), CoreMatchers.is("value7"));
        assertThat(valueRepository.find("id7").get().isEnabled(), CoreMatchers.is(true));
        
        assertThat(valueRepository.find("id8").get().getContent(), CoreMatchers.is(""));
        assertThat(valueRepository.find("id8").get().isEnabled(), CoreMatchers.is(true));
        
        assertThat(valueRepository.find("id9").get().getContent(), CoreMatchers.is(""));
        assertThat(valueRepository.find("id9").get().isEnabled(), CoreMatchers.is(true));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidFlow() {
        valueRepository.updateRepository(new ElementsSelection<>(1)
                .primaryProperties(primaryProperties));
    }
    
    @Test
    public void testBuildFilterForChangedValues_changed() {
        when(value.isChanged()).thenReturn(true);
        when(value.isEnabled()).thenReturn(true);
        when(value.supportMultiselection()).thenReturn(true);
        when(value.isUndefined()).thenReturn(false);

        final Optional<PropertyValue> filtered = ImmutableList.of(value).stream().filter(flow.buildFilterForChangedValues()::apply).findFirst();

        assertThat(filtered.isPresent(), CoreMatchers.is(true));
        assertThat(filtered.get(), CoreMatchers.is(value));

        verify(value).isChanged();
        verify(value).supportMultiselection();
        verify(value).isUndefined();
    }
    
    @Test
    public void testBuildFilterForChangedValues_no_changes() {
        when(value.isChanged()).thenReturn(false);
        when(value.isEnabled()).thenReturn(true);
        
        final Optional<PropertyValue> filtered = ImmutableList.of(value).stream().filter(flow.buildFilterForChangedValues()::apply).findFirst();

        assertThat(filtered.isPresent(), CoreMatchers.is(false));
        
        verify(value).isChanged();
        verify(value, never()).supportMultiselection();
        verify(value, never()).isUndefined();
    }
    
    @Test
    public void testBuildFilterForChangedValues_unsupportMultiselection() {
        when(value.isChanged()).thenReturn(true);
        when(value.isEnabled()).thenReturn(true);
        when(value.supportMultiselection()).thenReturn(false);
        when(value.isUndefined()).thenReturn(false);
        
        final Optional<PropertyValue> filtered = ImmutableList.of(value).stream().filter(flow.buildFilterForChangedValues()::apply).findFirst();

        assertThat(filtered.isPresent(), CoreMatchers.is(false));
        
        verify(value).isChanged();
        verify(value).supportMultiselection();
        verify(value, never()).isUndefined();
    }
    
    @Test
    public void testBuildFilterForChangedValues_undefined() {
        when(value.isChanged()).thenReturn(true);
        when(value.supportMultiselection()).thenReturn(true);
        when(value.isUndefined()).thenReturn(true);
        when(value.isEnabled()).thenReturn(true);
        
        final Optional<PropertyValue> filtered = ImmutableList.of(value).stream().filter(flow.buildFilterForChangedValues()::apply).findFirst();

        assertThat(filtered.isPresent(), CoreMatchers.is(false));
        
        verify(value).isChanged();
        verify(value).supportMultiselection();
        verify(value).isUndefined();
    }

    @Test
    public void testIsInMultiselectionFlow() {
        assertThat(MultiSelectionPropertyValueFlow.isInMultiselectionFlow(2), CoreMatchers.is(true));
    }

    @Test
    public void testIsInMultiselectionFlow_empty() {
        assertThat(MultiSelectionPropertyValueFlow.isInMultiselectionFlow(0), CoreMatchers.is(false));
    }

    @Test
    public void testisInMultiselectionFlow_one_element() {
        assertThat(MultiSelectionPropertyValueFlow.isInMultiselectionFlow(1), CoreMatchers.is(false));
    }

    private static class DummyValue extends AbstractPropertyValue {

        private final String id;
        private String content;
        
        private boolean supportMultiselection;
        private boolean enabled;

        public DummyValue(final String id, @Nonnull final String content) {
            this.id = id;
            this.content = Optional.ofNullable(content).orElse(EMPTY);

            supportMultiselection = true;
            enabled = true;
        }

        @Override
        public boolean supportMultiselection() {
            return supportMultiselection;
        }

        @Override
        public boolean isEnabled() {
            return enabled;
        }

        @Override
        public void onWritable(final boolean writable) {
            enabled = writable;
        }

        public void setSupportMultiselection(final boolean supportMultiselection) {
            this.supportMultiselection = supportMultiselection;
        }

        @Override
        public String getId() {
            return id;
        }

        @Override
        public String getContent() {
            return content;
        }

        @Override
        public void setContent(final String content) {
            this.content = Optional.ofNullable(content).orElse(EMPTY);
        }

        @Override public void modifyContent(String content) {
            setContent(content);
        }

        @Override
        public boolean forceSendOnUpdate() {
            return false;
        }
    }
}
