package com.ossnms.dcn_manager.bicnet.client.propertypage.integration;

import com.ossnms.bicnet.util.crypt.DESEncrypterDecrypter;
import com.ossnms.bicnet.util.crypt.IEncrypterDecrypter;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.page.PageBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.ValidatorException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableModelTest;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueAddress;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxCheckBox;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextField;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.net.URL;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

public class PropertyPageMTeraValidationIT {

    private static final URL XML_URL = RouteTableModelTest.class.getClassLoader().getResource("dcn-manager/propertypages/NE-MTERA-SSL-PropPage.xml");

    private final Page page;
    private PropertyValueRepository repository;
    private final IEncrypterDecrypter encrypterDES;

    public PropertyPageMTeraValidationIT() {
        final XmlFileLoader loader = new XmlFileLoader();
        this.page = loader.loadConfiguration(Page.class, XML_URL, null);
        this.encrypterDES = getEncrypter();
    }

    private DESEncrypterDecrypter getEncrypter() {
        try {
            return new DESEncrypterDecrypter();
        } catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    @Before
    public void setup() throws PropertyValueBuilderException {
        assertNotNull(page);

        this.repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
        new PageBuilder(page, repository).build();
    }

    @After
    public void release() {
        this.repository = null;
    }

    @Test
    public void testEmptyMandatoryValues() throws ValidatorException {
        assertFalse(repository.enableButtonOk());
    }

    @Test
    public void testMandatoryValuesFulfilled_no_changes() throws ValidatorException {
        fillMandatoryValues();

        assertFalse(repository.enableButtonOk());
    }

    @Test
    public void testMandatoryValuesFulfilled_invalid_field() throws ValidatorException {
        fillMandatoryValues();

        ((ValueJfxTextField) repository.find("TL1_NE_TARGET_ID").get()).setText("aaa");

        assertFalse(repository.enableButtonOk());
    }

    @Test(expected = ValidatorException.class)
    public void testUsedGNE_table_empty() throws ValidatorException {
        fillMandatoryValues();

        ((ValueJfxCheckBox) repository.find("BD4B7A2F-1406-4617-B163-39D1AF00EF03/USE_GNE").get()).setSelected(true);

        repository.validateValues();
    }

    @Test
    public void testUsedGNE_table_fullfilled_mandatory() throws ValidatorException {
        fillMandatoryValues();

        ((ValueJfxCheckBox) repository.find("BD4B7A2F-1406-4617-B163-39D1AF00EF03/USE_GNE").get()).setSelected(true);

        ((ValueAddress) repository.find("ADDRESS_000").get()).setText("127.0.0.1");
        ((ValueJfxTextField) repository.find("PORT_000").get()).setText("161");

        repository.validateValues();
        
        Assert.assertThat(repository.find("ROUTE_ROW_COUNT").get().getContent(), CoreMatchers.is("1"));
    }
    
    @Test(expected = ValidatorException.class)
    public void testUsedGNE_table_invalid_ip() throws ValidatorException {
        fillMandatoryValues();

        ((ValueJfxCheckBox) repository.find("BD4B7A2F-1406-4617-B163-39D1AF00EF03/USE_GNE").get()).setSelected(true);

        ((ValueAddress) repository.find("ADDRESS_000").get()).setText("555");
        ((ValueJfxTextField) repository.find("PORT_000").get()).setText("161");

        repository.validateValues();
    }
    
    @Test(expected = ValidatorException.class)
    public void testUsedGNE_table_empty_port() throws ValidatorException {
        fillMandatoryValues();

        ((ValueJfxCheckBox) repository.find("BD4B7A2F-1406-4617-B163-39D1AF00EF03/USE_GNE").get()).setSelected(true);

        ((ValueAddress) repository.find("ADDRESS_000").get()).setText("127.0.0.1");

        repository.validateValues();
    }

    private void fillMandatoryValues() {
        final Map<String, String> properties = new HashMap<>();
        properties.put("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "127.0.0.1");
        properties.put("TL1_DEFAULT_PORT", "161");
        properties.put("TL1_NE_TARGET_ID", "TARGET_1");
        properties.put("BD4B7A2F-1406-4617-B163-39D1AF00EF03/USER_ID", "usr");
        properties.put("ROUTE_ROW_COUNT", "");
        properties.put("BD4B7A2F-1406-4617-B163-39D1AF00EF03/AuthenticationPassword", encrypterDES.encryptData("pwd"));
        
        repository.addAll(properties);
    }
}
