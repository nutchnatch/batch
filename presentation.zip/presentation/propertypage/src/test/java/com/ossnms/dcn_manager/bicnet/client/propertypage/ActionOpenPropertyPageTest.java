package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Test;

import static com.ossnms.dcn_manager.bicnet.client.api.Containers.ROOT_CONTAINER_ID;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_PROPERTIES_CONTAINER_SAN;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ActionOpenPropertyPageTest {
    @Test public void shouldAllowForNeContainer() throws Exception {
        IManagedObject[] elements = {container(100)};
        SecureActionValidation actionValidation = validation(elements, OP_PROPERTIES_CONTAINER_SAN, true);
        ActionOpenPropertyPage action = new ActionOpenPropertyPage(repo(), commonServices(actionValidation));

        boolean pluginActionAllowed = action.isPluginActionAllowed(elements);

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void shouldNotAllowForRootContainer() throws Exception {
        IManagedObject[] elements = {container(ROOT_CONTAINER_ID)};
        SecureActionValidation actionValidation = validation(elements, OP_PROPERTIES_CONTAINER_SAN, true);
        ActionOpenPropertyPage action = new ActionOpenPropertyPage(repo(), commonServices(actionValidation));

        boolean pluginActionAllowed = action.isPluginActionAllowed(elements);

        assertThat(pluginActionAllowed, is(false));
    }

    private IGenericContainer container(int id) {
        GenericContainerItem genericContainerItem = new GenericContainerItem();
        genericContainerItem.setId(id);
        return genericContainerItem;
    }

    private SecureActionValidation validation(IManagedObjectId[] elements, SecureAction action, boolean actionAllowed) {
        SecureActionValidation actionValidation = mock(SecureActionValidation.class);
        when(actionValidation.checkPermission(action, elements)).thenReturn(actionAllowed);
        return actionValidation;
    }

    private SecureActionValidation validation(SecureAction action, boolean actionAllowed) {
        SecureActionValidation actionValidation = mock(SecureActionValidation.class);
        when(actionValidation.checkPermission(action)).thenReturn(actionAllowed);
        return actionValidation;
    }

    private RepositoryManager repo() {
        return mock(RepositoryManager.class);
    }

    private CommonServices commonServices(SecureActionValidation actionValidation) {
        CommonServices commonServices = mock(CommonServices.class);
        when(commonServices.getSecureActionValidation()).thenReturn(actionValidation);
        return commonServices;
    }
}