package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;

import static com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ValueDynamicComboBoxTest {

    private ValueDynamicComboBox comboBox;

    @Before
    public void setup() throws PropertyValueBuilderException {
        this.comboBox = new ValueDynamicComboBox(new ValueDescriptor("1", Collections.emptyList() , "true", true));
        comboBox.addItem("Value1", 1);
        comboBox.addItem("Value2", 2);
    }

    @After
    public void release() {
        this.comboBox = null;
    }

    @Test public void testSelectedValue() throws Exception {
        comboBox.setContent("2");

        assertThat(comboBox.getSelectedKey(), is(2));
        assertThat(comboBox.isValueModified(), is(false));
    }

    @Test public void testSelectedValue_not_exists() throws Exception {
        comboBox.setContent("3");

        assertThat(comboBox.getSelectedKey(), is(1));
    }

    @Test public void testSelectedValue_not_int() throws Exception {
        this.comboBox = new ValueDynamicComboBox(new ValueDescriptor("1", Collections.emptyList() , "true", true));
        comboBox.addItem("Value1", "v1");
        comboBox.addItem("Value2", "v2");

        comboBox.setContent("v2");

        assertThat(comboBox.getSelectedStringValue(), is("Value2"));
        assertThat(comboBox.isValueModified(), is(false));
    }

    @Test public void testSelectedValue_multiple_value_token() throws Exception {
        comboBox.setContent(MULTIPLE_VALUES_TOKEN);
        assertThat(comboBox.getSelectedKey(), is(MULTIPLE_VALUES_TOKEN));
        assertThat(comboBox.isValueModified(), is(false));
    }

    @Test public void shouldModifyValue() throws Exception {
        comboBox.setContent("1");

        comboBox.modifyContent("2");

        assertThat(comboBox.getSelectedKey(), is(2));
    }

    @Test public void shouldMarkChangedOnModify() throws Exception {
        comboBox.setContent("1");

        comboBox.modifyContent("2");

        assertThat(comboBox.isChanged(), is(true));
    }
}