package com.ossnms.dcn_manager.bicnet.client.propertypage.value;

import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import java.net.URL;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class ValueJfxSpinnerTest {

    private static final URL XML_URL = ValueJfxSpinnerTest.class.getClassLoader().getResource("value-spinner.xml");

    private ValueJfxSpinner spinner;

    @Before public void setup() throws PropertyValueBuilderException {
        spinner = (ValueJfxSpinner) ValueTypeFactory.createOf(
                new XmlFileLoader().loadConfiguration(Property.class, XML_URL, null).getValue(),
                new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow()));
    }

    @Test public void testCreateObject() {
        assertNotNull(spinner);

        spinner.addConditionListener(e -> {
        });

        assertThat(spinner.getId(), is("test-spinner"));
        assertThat(spinner.getName(), is("FIELD.TelegramRetries"));
        assertThat(spinner.getContent(), is("2"));
        assertThat(spinner.isMandatoryEntry(), is(true));
        assertThat(spinner.isChanged(), is(false));
        assertThat(spinner.getValueActions(), is(empty()));
        assertThat(spinner.isMandatoryValueBlank(), is(false));
        assertThat(spinner.getToolTipText(), is("0...10, 100...1000"));
    }

    @Test public void testChangeObject() {
        assertNotNull(spinner);

        spinner.setValue(5);

        assertThat(spinner.getContent(), is("5"));
        assertThat(spinner.isMandatoryValueBlank(), is(false));
        assertThat(spinner.isChanged(), is(true));
    }

    @Test public void testSetContent() {
        assertNotNull(spinner);

        spinner.setContent("10");

        assertThat(spinner.getContent(), is("10"));
        assertThat(spinner.isMandatoryValueBlank(), is(false));
        assertThat(spinner.isChanged(), is(false));
    }

    @Test public void testSetEmptyContent() {
        assertNotNull(spinner);

        spinner.setContent("");

        assertThat(spinner.getContent(), is("0"));
        assertThat(spinner.isMandatoryValueBlank(), is(false));
        assertThat(spinner.isChanged(), is(false));
    }

    @Test public void testOnWritableFalse() {
        assertNotNull(spinner);

        spinner.onWritable(false);

        assertThat(spinner.isEnabled(), is(false));
    }

    @Test public void testOnWritableTrue() {
        assertNotNull(spinner);

        spinner.onWritable(true);

        assertThat(spinner.isEnabled(), is(true));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testOnCleanOnDisable() {
        assertNotNull(spinner);

        spinner.onCleanOnDisable(true);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testOnValueFromConditionResult() {
        assertNotNull(spinner);

        spinner.onValueFromConditionResult(true);
    }

    @Test public void testMultiselection() {
        assertNotNull(spinner);

        spinner.setContent(MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN);

        assertThat(spinner.isUndefined(), is(true));
    }

    @Test public void valueOutOfRange_shouldBeInvalid() throws Exception {
        spinner.setValue(11);

        assertThat(spinner.isInvalidEntry(), is(true));
    }

    @Test public void emptyValue_shouldBeMandatoryBlank() throws Exception {
        spinner.setValue(null);

        assertThat(spinner.isMandatoryValueBlank(), is(true));
    }

    @Test public void shouldModifyValue() throws Exception {
        spinner.setContent("10");

        spinner.modifyContent("42");

        assertThat(spinner.getContent(), CoreMatchers.is("42"));
    }

    @Test public void shouldMarkChangedOnModify() throws Exception {
        spinner.setContent("10");

        spinner.modifyContent("42");

        assertThat(spinner.isChanged(), CoreMatchers.is(true));
    }
}
