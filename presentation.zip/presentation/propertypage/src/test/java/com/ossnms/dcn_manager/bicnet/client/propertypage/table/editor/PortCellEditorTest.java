package com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import com.coriant.widgets.ClientProperties;
import com.coriant.widgets.text.PTextField;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor.CellColor;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.editor.PortCellEditor;

public class PortCellEditorTest {

    @Test
    public void testStopCellEditing() {
        final PortCellEditor editor = new PortCellEditor(new PTextField("100"));
        assertTrue(editor.stopCellEditing());
    }

    @Test
    public void testVerify_valid_port_range() {
        final PortCellEditor editor = new PortCellEditor(new PTextField("0"));

        assertTrue(editor.getComponent().getInputVerifier().verify(editor.getComponent()));

        assertTrue(editor.getComponent().getInputVerifier().shouldYieldFocus(editor.getComponent()));
        assertThat(editor.getComponent().getBackground(), CoreMatchers.is(CellColor.DEFAULT.color()));
        assertThat(Boolean.valueOf(editor.getComponent().getClientProperty(ClientProperties.INVALID).toString()),
                CoreMatchers.is(false));
    }
    
    @Test
    public void testVerify_empty() {
        final PortCellEditor editor = new PortCellEditor(new PTextField(""));

        assertTrue(editor.getComponent().getInputVerifier().verify(editor.getComponent()));

        assertTrue(editor.getComponent().getInputVerifier().shouldYieldFocus(editor.getComponent()));
        assertThat(editor.getComponent().getBackground(), CoreMatchers.is(CellColor.DEFAULT.color()));
        assertThat(Boolean.valueOf(editor.getComponent().getClientProperty(ClientProperties.INVALID).toString()),
                CoreMatchers.is(false));
    }


    @Test
    public void testVerify_not_valid_port_range() {
        final PortCellEditor editor = new PortCellEditor(new PTextField("65537"));

        assertFalse(editor.getComponent().getInputVerifier().verify(editor.getComponent()));

        assertTrue(editor.getComponent().getInputVerifier().shouldYieldFocus(editor.getComponent()));
        assertThat(editor.getComponent().getBackground(), CoreMatchers.is(CellColor.ERROR.color()));
        assertThat(Boolean.valueOf(editor.getComponent().getClientProperty(ClientProperties.INVALID).toString()),
                CoreMatchers.is(true));
    }

    @Test
    public void testVerify_not_valid_port_range_lower() {
        final PortCellEditor editor = new PortCellEditor(new PTextField("-1"));

        assertFalse(editor.getComponent().getInputVerifier().verify(editor.getComponent()));

        assertTrue(editor.getComponent().getInputVerifier().shouldYieldFocus(editor.getComponent()));
        assertThat(editor.getComponent().getBackground(), CoreMatchers.is(CellColor.ERROR.color()));
        assertThat(Boolean.valueOf(editor.getComponent().getClientProperty(ClientProperties.INVALID).toString()),
                CoreMatchers.is(true));
    }
}
