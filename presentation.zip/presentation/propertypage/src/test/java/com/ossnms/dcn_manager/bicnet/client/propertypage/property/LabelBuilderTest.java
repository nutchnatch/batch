package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.net.URL;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.bicnet.client.propertypage.property.LabelBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextFieldTest;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.tools.jfx.components.JfxLabel;

public class LabelBuilderTest {
    
    private static final URL XML_URL = ValueJfxTextFieldTest.class.getClassLoader().getResource("value-text.xml");

    private final XmlFileLoader loader = new XmlFileLoader();
    private final Property property;
    private JfxLabel label;

    public LabelBuilderTest() {
        this.property = loader.loadConfiguration(Property.class, XML_URL, null);
    }

    @Before
    public void setup() {
        this.label = new LabelBuilder(property.getLabel()).build();
    }

    @After
    public void release() {
        this.label = null;
    }
    
    @Test
    public void testCreateObject() {
        assertThat(label.getText(), is("Upload path:"));
        assertThat(label.getToolTipText(), is("Upload path:"));
    }
}
