package com.ossnms.dcn_manager.bicnet.client.propertypage.value.transform;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;

public class TransformNsapToIpTest {
    
    @Test
    public void testTranform_onlyIp() {
        final Optional<String> nsap = TransformNsapToIp.tryTransform("540072872203127000000001");
        
        assertTrue(nsap.isPresent());
        assertThat(nsap.get(), CoreMatchers.is("127.0.0.1"));
    }
    
    @Test
    public void testTranform_onlyIpAndPort() {
        final Optional<String> nsap = TransformNsapToIp.tryTransform("5400728722031270000000010808000001");
        
        assertTrue(nsap.isPresent());
        assertThat(nsap.get(), CoreMatchers.is("127.0.0.1:8080"));
    }
    
    @Test
    public void testTranform_null_address() {
        final Optional<String> nsap = TransformNsapToIp.tryTransform(null);
        assertFalse(nsap.isPresent());
    }
    
    @Test
    public void testTranform_empty_address() {
        final Optional<String> nsap = TransformNsapToIp.tryTransform("");
        assertFalse(nsap.isPresent());
    }
    
    @Test
    public void testTranform_wrong_format() {
        final Optional<String> nsap = TransformNsapToIp.tryTransform("54WRONG");
        assertFalse(nsap.isPresent());
    }    
}
