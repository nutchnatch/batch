package com.ossnms.dcn_manager.bicnet.client.propertypage.job;

import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.job.FetchProperties;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.ElementsSelection;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

public class FetchPropertiesTest {
    
    private static final int KEY = 1;
    
    private Repository<Integer, INE> repository;
    private ISessionContext context;
    private FrameworkDocument document;
    private Map<String, String> properties;
    
    private FetchProperties<Integer, INE> job;
    
    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        repository = mock(Repository.class);
        context = mock(ISessionContext.class);
        document = mock(FrameworkDocument.class);
        
        job = new FetchProperties<>(new ElementsSelection<Integer>(KEY), document, repository, context);
        properties = ImmutableMap.of("key","value");
    }
    
    @Test
    public void testExecute() throws FrameworkException, RepositoryException {
        when(repository.getProperties(context, KEY)).thenReturn(properties);

        final ElementsSelection<Integer> selection = job.execute(null);

        assertThat(selection.getPrimaryId(), CoreMatchers.is(KEY));
        verify(repository, times(1)).getProperties(context, KEY);
    }
    
    @Test(expected=FrameworkException.class)
    public void testExecuteWithErrors() throws FrameworkException, RepositoryException {
        doThrow(new RepositoryException()).when(repository).getProperties(context, KEY);

        job.execute(null);
    }
}
