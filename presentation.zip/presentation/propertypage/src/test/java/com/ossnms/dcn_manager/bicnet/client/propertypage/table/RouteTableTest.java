package com.ossnms.dcn_manager.bicnet.client.propertypage.table;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.net.URL;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.TableModel;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTable;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableBuilder;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;

public class RouteTableTest {

    private static final URL XML_URL = RouteTableTest.class.getClassLoader().getResource("value-table-ip-and-port.xml");
    
    private final XmlFileLoader loader = new XmlFileLoader();
    private final TableModel tableModel;
    private RouteTable routeTable;
    private PropertyValueRepository repository;
    
    public RouteTableTest() {
        this.tableModel = loader.loadConfiguration(Property.class, XML_URL, null).getTableModel();
    }
    
    @Before
    public void setup() {
        this.repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
        this.routeTable = new RouteTableBuilder(tableModel, repository).build();
    }
    
    @After
    public void release() {
        this.repository = null;
        this.routeTable = null;
    }
    
    @Test
    public void testCreateObject() {
        assertNotNull(routeTable);
        assertTrue(repository.allValues().iterator().hasNext());
    }
 }
