package com.ossnms.dcn_manager.bicnet.client.propertypage.command;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

public class SaveNewPropertyPageOkButtonCommandTest {

    private INE ne;
    private Repository<Integer, INE> repository;
    private ISessionContext context;
    private PropertyValueRepository valueRepository;
    private Map<String, String> properties;

    private SaveNewPropertyPageOkButtonCommand<Integer, INE, Repository<Integer, INE>> saveNewPropertyPageOkButtonCommand;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        ne = mock(INE.class);
        repository = mock(Repository.class);
        context = mock(ISessionContext.class);
        valueRepository = mock(PropertyValueRepository.class);

        saveNewPropertyPageOkButtonCommand = new SaveNewPropertyPageOkButtonCommand<>(ne, repository, context);
        properties = ImmutableMap.of();
    }

    @Test
    public void testCall() throws RepositoryException {
        when(valueRepository.allSavableValues()).thenReturn(properties);

        saveNewPropertyPageOkButtonCommand.call(valueRepository);

        verify(repository, times(1)).create(context, ne, properties);
        verify(valueRepository, times(1)).allSavableValues();
    }
    
    @Test(expected=RepositoryException.class)
    public void testCallWithErrors() throws RepositoryException {
        doThrow(new RepositoryException()).when(repository).create(context, ne, properties);
        
        saveNewPropertyPageOkButtonCommand.call(valueRepository);
    }
}
