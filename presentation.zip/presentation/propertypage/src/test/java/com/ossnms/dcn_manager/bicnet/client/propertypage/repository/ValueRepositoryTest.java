package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

import com.coriant.widgets.ClientProperties;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.common.collect.Iterables;
import com.ossnms.bicnet.util.crypt.DESEncrypterDecrypter;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueCheckBoxTest;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxComboBoxTest;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxPasswordFieldTest;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxSpinnerTest;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextAreaTest;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextField;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextFieldTest;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueTypeFactory;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Value;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.net.URL;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.util.Map;

import static com.jayway.awaitility.Awaitility.await;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ValueRepositoryTest {

    private static final int TIMEOUT = 6;
    private static final URL XML_URL_1 = ValueJfxTextAreaTest.class.getClassLoader().getResource("value-textarea.xml");
    private static final URL XML_URL_2 = ValueJfxComboBoxTest.class.getClassLoader().getResource("value-combobox.xml");
    private static final URL XML_URL_3 = ValueJfxPasswordFieldTest.class.getClassLoader().getResource("value-password.xml");
    private static final URL XML_URL_4 = ValueJfxSpinnerTest.class.getClassLoader().getResource("value-spinner.xml");
    private static final URL XML_URL_5 = ValueJfxTextFieldTest.class.getClassLoader().getResource("value-text.xml");
    private static final URL XML_URL_6 = ValueCheckBoxTest.class.getClassLoader().getResource("value-checkbox.xml");
    private static final URL XML_URL_7 = ValueCheckBoxTest.class.getClassLoader().getResource("value-address.xml");

    private static final ImmutableList<URL> URLS = ImmutableList.of(XML_URL_1, XML_URL_2, XML_URL_3, XML_URL_4, XML_URL_5, XML_URL_6, XML_URL_7);

    private final XmlFileLoader loader = new XmlFileLoader();
    private final PropertyValueRepository repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
    private final DESEncrypterDecrypter encrypter;

    public ValueRepositoryTest() {
        encrypter = getEncrypter();
    }

    private DESEncrypterDecrypter getEncrypter() {
        try {
            return new DESEncrypterDecrypter();
        } catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    @Before
    public void setup() throws PropertyValueBuilderException {
        for (final URL url : URLS) {
            final Value value = loader.loadConfiguration(Property.class, url, null).getValue();
            repository.add((PropertyValue) ValueTypeFactory.createOf(value, repository));
        }

        repository.addAll(new Builder<String, String>()
                .put("test-area", "newAreaValue")
                .put("test-combo", "Error")
                .put("test-pwd", encrypter.encryptData("newPwd"))
                .put("test-spinner", "10")
                .put("test-text", "newTextValue")
                .put("test-checkbox", "false")
                .put("test-address", "198.0.0.1")
                .build());

        await("for values are set on AWT thread").atMost(TIMEOUT, SECONDS)
                .until(() -> repository.find("test-address").get().getContent(), is("198.0.0.1"));
    }

    @After
    public void release() {
        repository.clear();
    }

    @Test
    public void testModifyValues() {
        assertThat(repository.find("test-area").get().getContent(), is("newAreaValue"));
        assertThat(repository.find("test-combo").get().getContent(), is("Error"));
        assertThat(repository.find("test-pwd").get().getContent(), is(encrypter.encryptData("newPwd")));
        assertThat(repository.find("test-spinner").get().getContent(), is("10"));
        assertThat(repository.find("test-text").get().getContent(), is("newTextValue"));
        assertThat(repository.find("test-checkbox").get().getContent(), is("false"));
        assertThat(repository.find("test-address").get().getContent(), is("198.0.0.1"));
    }

    @Test
    public void testAddValue() {
        repository.add(new PageGlobalVariable("test-global-var", "globalValue"));

        assertThat(repository.find("test-global-var").get().getContent(), is("globalValue"));
    }

    @Test
    public void testAllChangedValuesNoChanges() {
        assertThat(repository.allChangedValues().size(), is(0));
    }

    @Test
    public void testAllChangedValues() {
        final ValueJfxTextField text = (ValueJfxTextField) repository.find("test-text").get();
        text.setText("modifiedValue");

        assertThat(repository.allChangedValues().size(), is(1));
    }

    @Test
    public void testSavableValues() {
        final StaticConfigurationValue staticValue = new StaticConfigurationValue("id_1", "test1");
        final PageGlobalVariable globalVariable = new PageGlobalVariable("id_2", "test2");

        repository.add(staticValue);
        repository.add(globalVariable);

        final Map<String, String> savableValues = repository.allSavableValues();

        assertNotNull(savableValues.get(staticValue.getId()));
        assertNull(savableValues.get(globalVariable.getId()));
    }

    @Test
    public void testAllValues() {
        final StaticConfigurationValue staticValue = new StaticConfigurationValue("id_1", "test1");
        final PageGlobalVariable globalVariable = new PageGlobalVariable("id_2", "test2");

        repository.add(staticValue);
        repository.add(globalVariable);

        final Iterable<PropertyValue> allValues = repository.allValues();

        assertNotNull(allValues);
        assertTrue(Iterables.contains(allValues, staticValue));
        assertTrue(Iterables.contains(allValues, globalVariable));
    }

    @Test
    public void testChangeValueToEmpty() {
        final ValueJfxTextField text = (ValueJfxTextField) repository.find("test-text").get();
        text.setContent("value");

        text.setText("");

        
        assertThat(text.getContent(), is(""));
        System.out.println(repository.allChangedValues());
        assertThat(repository.allChangedValues().size(), is(1));
    }

    @Test
    public void testEnableButtonOkTrue() {
        final ValueJfxTextField text = (ValueJfxTextField) repository.find("test-text").get();
        text.setText("modifiedValue");

        assertTrue(repository.enableButtonOk());
    }

    @Test
    public void testEnableButtonOkFalse_invalidField() {
        final ValueJfxTextField text = (ValueJfxTextField) repository.find("test-text").get();
        text.putClientProperty(ClientProperties.INVALID, true);

        assertFalse(repository.enableButtonOk());
    }

    @Test
    public void testEnableButtonOkFalse() {
        assertFalse(repository.enableButtonOk());
    }
}
