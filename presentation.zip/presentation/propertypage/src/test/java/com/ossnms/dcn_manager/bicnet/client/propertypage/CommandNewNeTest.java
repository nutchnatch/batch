package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.logger.LoggerManager;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocument;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.view.PropertyPageView;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.SystemContainerRepository;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.StaticConfiguration;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static com.jayway.awaitility.Awaitility.await;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.ID_NAME;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.NE_SYSTEM_ASSIGNMENT_NAME;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.NE_TYPE_LABEL;
import static com.ossnms.dcn_manager.bicnet.client.service.facade.DefaultManageObjectValues.newBasicSystemContainerItem;
import static com.ossnms.dcn_manager.bicnet.client.service.facade.DefaultManageObjectValues.newDummyFullNeData;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.PropertyPageLabels.NO_ASSOCIATION;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CommandNewNeTest {

    private static final int SYSTEM_ID = 6;
    private static final int TIMEOUT = 5;

    @Mock private RepositoryManager repositoryManager;
    @Mock private NeRepository repository;
    @Mock private SystemContainerRepository systemRepository;
    @Mock private NeSearchable searchable;
    @Mock private StaticConfiguration staticConfiguration;
    @Mock private PropertyPagesRepository pagesRepository;
    @Mock private LoggerManager loggerManager;
    @Mock private DcnPluginHelper pluginHelper;
    @Mock private CommonServices commonServices;
    @Mock private INEId id;
    @Mock private INE bcbNe;
    @Mock private NeType type;
    @Mock private BiCNetPluginSite site;
    @Mock private BiCNetPluginFrame frame;

    private CommandNewNe commandNewNe;

    @Before public void setup() throws BiCNetPluginException, RepositoryException, PropertyValueBuilderException {
        commandNewNe = new CommandNewNe(repositoryManager, commonServices, pagesRepository, "type_name",
                Optional.of(SYSTEM_ID), empty());

        final Optional<FullNeData> optional = Optional.empty();
        DcnPluginHelperSingleton.getInstance().setCfPluginSite(site);

        when(repositoryManager.getNeRepository()).thenReturn(repository);
        when(repositoryManager.getSystemContainerRepository()).thenReturn(systemRepository);
        when(commonServices.getDcnPluginHelper()).thenReturn(pluginHelper);
        when(pluginHelper.getCfPluginSite()).thenReturn(site);
        when(commonServices.getLoggerManager()).thenReturn(loggerManager);
        when(commonServices.getStaticConfiguration()).thenReturn(staticConfiguration);

        when(site.createFrame(any(PropertyPageView.class), any(BiCNetPluginFrameType.class))).thenReturn(frame);

        when(type.getName()).thenReturn("type_name");

        when(id.getId()).thenReturn(1);
        final FullNeData networkElement = new FullNeData(bcbNe, new NeInfo(1), null);
        when(repository.get(1)).thenReturn(of(networkElement));

        when(repository.queries()).thenReturn(searchable);
        when(searchable.findByIdName(anyString())).thenReturn(optional);

        when(systemRepository.get(SYSTEM_ID)).thenReturn(Optional.empty());

        when(bcbNe.getNeProxyType()).thenReturn("type");
        when(bcbNe.getId()).thenReturn(1);
        when(bcbNe.getAssociatedEm()).thenReturn(new EMIdItem(1));

        when(pagesRepository.getPropertyPage(type)).thenReturn(new Page());
        when(staticConfiguration.findNeType(anyString())).thenReturn(of(type));
    }

    @Test public void testCall() throws CommandException, PropertyValueBuilderException {
        commandNewNe.call(1);

        verify(pagesRepository, times(1)).getPropertyPage(type);
        verify(staticConfiguration, times(1)).findNeType("type_name");
        verify(type, times(1)).getHelpID();
        verify(frame, times(1)).showFrame();
    }

    @Test public void buildFrameworkDocument() throws Exception {
        final FullNeData fullNeData = newDummyFullNeData("type_name", "ne_name", 1, Optional.of(2));
        final ISystemContainer systemContainer = newBasicSystemContainerItem("system_name");
        systemContainer.setId(SYSTEM_ID);

        when(systemRepository.get(SYSTEM_ID)).thenReturn(Optional.of(systemContainer));

        final PageDocument<FullNeData> fullNeDataPageDocument = commandNewNe.buildFrameworkDocument(fullNeData);

        fullNeDataPageDocument.execute();

        final PropertyValueRepository valueRepository = fullNeDataPageDocument.getValueRepository();

        await().atMost(TIMEOUT, SECONDS)
                .until(() -> valueRepository.find(NE_SYSTEM_ASSIGNMENT_NAME).isPresent());

        final Optional<PropertyValue> systemName = valueRepository.find(NE_SYSTEM_ASSIGNMENT_NAME);
        final Optional<PropertyValue> neName = valueRepository.find(ID_NAME);
        final Optional<PropertyValue> neType = valueRepository.find(NE_TYPE_LABEL);

        assertTrue(systemName.isPresent());
        assertTrue(neName.isPresent());
        assertTrue(neType.isPresent());

        assertThat(systemName.get().getContent(), is("system_name"));
        assertThat(neName.get().getContent(), is("ne_name"));
        assertThat(neType.get().getContent(), is("type_name"));
    }

    @Test public void buildFrameworkDocument_container_not_found() throws Exception {
        final FullNeData fullNeData = newDummyFullNeData("type_name", "ne_name", 1, Optional.of(2));

        final PageDocument<FullNeData> fullNeDataPageDocument = commandNewNe.buildFrameworkDocument(fullNeData);

        fullNeDataPageDocument.execute();

        final PropertyValueRepository valueRepository = fullNeDataPageDocument.getValueRepository();

        await().atMost(TIMEOUT, SECONDS)
                .until(() -> valueRepository.find(NE_SYSTEM_ASSIGNMENT_NAME).isPresent());


        final Optional<PropertyValue> systemName = valueRepository.find(NE_SYSTEM_ASSIGNMENT_NAME);
        final Optional<PropertyValue> neName = valueRepository.find(ID_NAME);
        final Optional<PropertyValue> neType = valueRepository.find(NE_TYPE_LABEL);

        assertTrue(systemName.isPresent());
        assertTrue(neName.isPresent());
        assertTrue(neType.isPresent());

        assertThat(systemName.get().getContent(), is(NO_ASSOCIATION.toString()));
        assertThat(neName.get().getContent(), is("ne_name"));
        assertThat(neType.get().getContent(), is("type_name"));
    }
}
