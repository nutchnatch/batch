package com.ossnms.dcn_manager.bicnet.client.propertypage.validator;

import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.StaticConfigurationValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.ValidatorException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableModel;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableModelBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.RouteTableModelTest;
import com.ossnms.dcn_manager.bicnet.client.propertypage.table.column.Column;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueAddress;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextField;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.dcn_manager.core.jaxb.propertypage.TableModel;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.net.URL;
import java.util.Map;
import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class RouteTableValidatorOptionalPortTest {
    
    private static final URL XML_URL = RouteTableModelTest.class.getClassLoader().getResource("value-table-ip-optional-port.xml");

    /* Total rows defined on attribute autogenerate-rows in value-table.xml*/
    private static final int TOTAL_ROWS = 10;
    
    private final XmlFileLoader loader = new XmlFileLoader();
    private final TableModel tableModel;
    private RouteTableModel routeTableModel;
    private PropertyValueRepository repository;
    private RouteTableValidator validator;
    
    public RouteTableValidatorOptionalPortTest() {
        tableModel = loader.loadConfiguration(Property.class, XML_URL, null).getTableModel();
    }
    
    @Before
    public void setup() {
        repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
        routeTableModel = new RouteTableModelBuilder(tableModel, repository).build();
        validator = new RouteTableValidator(ImmutablePair.of(routeTableModel.getTableData(),(PropertyValue) new StaticConfigurationValue(tableModel.getRouteRowCount().getId(), null)));
    }
    
    @After
    public void release() {
        repository = null;
        routeTableModel = null;
        validator = null;
    }
    
    @Test
    public void testEmptyValues_tableDisable() throws ValidatorException {
        disableValues();

        assertTrue(validator.validate());
    }
    
    @Test(expected=ValidatorException.class)
    public void testEmptyValues_tableEnable() throws ValidatorException {
        validator.validate();
    }
    
    @Test(expected = ValidatorException.class)
    public void testEmptyRequiredValue() throws ValidatorException {
        final ValueAddress address = FluentIterable.from(routeTableModel.getTableData().values())
                .filter(ValueAddress.class).first().get();

        address.setContent("127.0.0.1:161");

        validator.validate();
    }
    
    @Test
    public void testRequiredValueOk() throws ValidatorException {
        fillRequiredValues(0);
        
        assertTrue(validator.validate());
    }
    
    @Test
    public void testNotEmptyRow_markedToUpdate() throws ValidatorException {
        fillRequiredValues(0);
        
        assertTrue(validator.validate());
        
        final Map<Column, PropertyValue> valuesMap = routeTableModel.getTableData().row(0);
        
        for (final PropertyValue propertyValue : valuesMap.values()) {
            assertTrue(propertyValue.forceSendOnUpdate());
        }        
    }
    
    @Test
    public void testEmptyRow_removedToUpdate() throws ValidatorException {
        fillRequiredValues(0);
        
        assertTrue(validator.validate());
        
        for (int row = 1; row < TOTAL_ROWS; row++) {
            final Map<Column, PropertyValue> valuesMap = routeTableModel.getTableData().row(row);

            for (final PropertyValue propertyValue : valuesMap.values()) {
                assertFalse(propertyValue.forceSendOnUpdate());
                assertFalse(propertyValue.isChanged());
            }
        }
    }
    
    @Test(expected=ValidatorException.class)
    public void testDuplicatedRows() throws ValidatorException {
        fillRequiredValues(0);
        fillRequiredValues(1);
        
        assertTrue(validator.validate());
    }

    private void fillRequiredValues(final int positon) {
        final Optional<ValueAddress> address = routeTableModel.getTableData().values().stream()
                .filter(ValueAddress.class::isInstance)
                .map(ValueAddress.class::cast)
                .filter(input -> input.getId().equals("369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_00" + positon))
                .findFirst();     
        assertTrue(address.isPresent());
        address.get().setContent("127.0.0.1:161");
        
        final ValueJfxTextField cost = FluentIterable.from(routeTableModel.getTableData().values())
                .filter(ValueJfxTextField.class).firstMatch(new Predicate<ValueJfxTextField>() {
                    @Override
                    public boolean apply(final ValueJfxTextField input) {
                        return input.getId().equals("369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_COST_00" + positon);
                    }
                }).get();

        cost.setContent("11");
    }
            
    private void disableValues() {
        for (final PropertyValue value : routeTableModel.getTableData().values()) {
            value.onWritable(false);
        }
    }
}
