package com.ossnms.dcn_manager.bicnet.client.propertypage.property;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.net.URL;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextFieldTest;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Property;
import com.ossnms.tools.jfx.components.JfxLabel;

public class RangeLabelBuilderTest {

    private static final URL XML_URL = ValueJfxTextFieldTest.class.getClassLoader().getResource("value-spinner.xml");

    private JfxLabel label;

    @Before public void setup() {
        Property property = new XmlFileLoader().loadConfiguration(Property.class, XML_URL, null);
        label = new RangeLabelBuilder(property.getRangeLabel()).build();
    }

    @Test public void testCreateObject() {
        assertThat(label.getText(), is("[0...10, 100...1000]"));
        assertThat(label.getToolTipText(), is("[0...10, 100...1000]"));
    }
}
