package com.ossnms.dcn_manager.bicnet.client.propertypage.condition;

import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PageGlobalVariable;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValue;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Condition;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.xml.bind.JAXBException;
import java.net.URL;
import java.util.Optional;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PropertyConditonTest {

    private static final URL XML_URL = PropertyConditonTest.class.getClassLoader().getResource("condition-composable.xml");
    
    private final XmlFileLoader loader = new XmlFileLoader();
    private PropertyValueRepository valueRepository;

    @Before
    public void setup() {
        valueRepository = mock(PropertyValueRepository.class);

        when(valueRepository.find("id-1")).thenReturn(getValue("id-1", "1"));
        when(valueRepository.find("id-2")).thenReturn(getValue("id-2", "2"));
    }
    
    @Test
    public void testCondition() throws JAXBException, PropertyValueBuilderException {
        final Condition condition = loader.loadConfiguration(Condition.class, XML_URL, null);

        final ConditionChain conditionChain = new ConditionChainBuilder(condition, valueRepository).build();

        Assert.assertTrue(conditionChain.verify());
    }
   
    private Optional<PropertyValue> getValue(final String id, final String value) {
        return Optional.of((PropertyValue) new PageGlobalVariable(id, value));
    }
}
