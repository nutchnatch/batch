package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.logger.LoggerManager;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.view.PropertyPageView;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.ChannelSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ChannelRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.StaticConfiguration;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static java.util.Optional.of;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CommandNewChannelTest {

    private ChannelRepository repository;
    private ChannelSearchable searchable;
    private StaticConfiguration staticConfiguration;
    private PropertyPagesRepository pagesRepository;
    private LoggerManager loggerManager;
    private DcnPluginHelper pluginHelper;
    private CommonServices commonServices;
    private IEMId emId;
    private IEM em;
    private FullChannelData fullChannelData;
    private ChannelType type;
    private BiCNetPluginSite site;
    private BiCNetPluginFrame frame;

    private CommandNewChannel commandNewChannel;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() throws BiCNetPluginException, RepositoryException, PropertyValueBuilderException {
        commonServices = mock(CommonServices.class);
        repository = mock(ChannelRepository.class);
        searchable = mock(ChannelSearchable.class);
        staticConfiguration = mock(StaticConfiguration.class);
        pagesRepository = mock(PropertyPagesRepository.class);
        loggerManager = mock(LoggerManager.class);
        pluginHelper = mock(DcnPluginHelper.class);
        emId = mock(IEMId.class);
        em = mock(IEM.class);
        type = mock(ChannelType.class);
        site = mock(BiCNetPluginSite.class);
        frame = mock(BiCNetPluginFrame.class);

        fullChannelData = new FullChannelData(em, new ChannelInfo(em.getId()));
        commandNewChannel = new CommandNewChannel(repository, commonServices, pagesRepository, "type_name");

        final Optional<FullChannelData> optional = Optional.empty();
        DcnPluginHelperSingleton.getInstance().setCfPluginSite(site);

        when(commonServices.getDcnPluginHelper()).thenReturn(pluginHelper);
        when(commonServices.getLoggerManager()).thenReturn(loggerManager);
        when(commonServices.getStaticConfiguration()).thenReturn(staticConfiguration);

        when(site.createFrame(any(PropertyPageView.class), any(BiCNetPluginFrameType.class))).thenReturn(frame);
        when(type.getName()).thenReturn("type_name");
        when(type.guiLabel()).thenReturn(of("type label"));
        
        when(emId.getId()).thenReturn(1);
        when(repository.get(1)).thenReturn(of(fullChannelData));

        when(repository.queries()).thenReturn(searchable);
        when(searchable.findByIdName(anyString())).thenReturn(optional);
        
        when(em.getEmType()).thenReturn("type");
        when(em.getAssociatedMediator()).thenReturn(new MediatorIdItem(1));
        when(em.getId()).thenReturn(1);
        
        when(pagesRepository.getPropertyPage(type)).thenReturn(new Page());
        
        when(staticConfiguration.findChannelType(anyString())).thenReturn(of(type));
    }

    @Test
    public void testCall() throws CommandException, PropertyValueBuilderException {
        commandNewChannel.call(1);
        
        verify(pagesRepository, times(1)).getPropertyPage(type);
        verify(staticConfiguration, times(1)).findChannelType("type_name");
        verify(type, times(1)).getHelpID();
        verify(frame, times(1)).showFrame();
    }
}
