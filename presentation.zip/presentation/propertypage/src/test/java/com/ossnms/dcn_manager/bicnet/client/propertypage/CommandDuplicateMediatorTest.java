package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.dcn_manager.bicnet.client.api.command.CommandException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.logger.LoggerManager;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.view.PropertyPageView;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.MediationSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.MediatorRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.StaticConfiguration;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.Optional;

import static java.util.Optional.of;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CommandDuplicateMediatorTest {

    private MediatorRepository repository;
    private MediationSearchable searchable;
    private StaticConfiguration staticConfiguration;
    private PropertyPagesRepository pagesRepository;
    private LoggerManager loggerManager;
    private DcnPluginHelper pluginHelper;
    private CommonServices commonServices;
    private IMediator mediator;
    private FullMediatorData fullMediatorData;
    private MediatorType type;
    private BiCNetPluginSite site;
    private BiCNetPluginFrame frame;

    private CommandDuplicateMediator callDuplicate;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() throws BiCNetPluginException, RepositoryException, PropertyValueBuilderException {
        commonServices = mock(CommonServices.class);
        repository = mock(MediatorRepository.class);
        searchable = mock(MediationSearchable.class);
        staticConfiguration = mock(StaticConfiguration.class);
        pagesRepository = mock(PropertyPagesRepository.class);
        loggerManager = mock(LoggerManager.class);
        pluginHelper = mock(DcnPluginHelper.class);

        mediator = new MediatorItem();
        mediator.setId(1);
        mediator.setMediatorType(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.BCB);

        fullMediatorData = new FullMediatorData(mediator, new MediatorInfo(mediator.getId()));
        type = mock(MediatorType.class);
        site = mock(BiCNetPluginSite.class);
        frame = mock(BiCNetPluginFrame.class);

        callDuplicate = new CommandDuplicateMediator(repository, commonServices, pagesRepository);
        final Optional<FullMediatorData> optional = Optional.empty();
        DcnPluginHelperSingleton.getInstance().setCfPluginSite(site);

        when(commonServices.getDcnPluginHelper()).thenReturn(pluginHelper);
        when(commonServices.getLoggerManager()).thenReturn(loggerManager);
        when(commonServices.getStaticConfiguration()).thenReturn(staticConfiguration);

        when(site.createFrame(any(PropertyPageView.class), any(BiCNetPluginFrameType.class))).thenReturn(frame);
        
        when(type.getName()).thenReturn("type_name");
        when(type.guiLabel()).thenReturn(of("type label"));
        
        when(repository.get(1)).thenReturn(of(fullMediatorData));

        when(repository.queries()).thenReturn(searchable);
        when(searchable.findByIdName(anyString())).thenReturn(optional);



        when(pagesRepository.getPropertyPage(type)).thenReturn(new Page());
        
        when(staticConfiguration.findMediatorType(anyString())).thenReturn(of(type));
    }

    @Test
    public void testCall() throws CommandException, PropertyValueBuilderException {
        callDuplicate.call(mediator);
        
        verify(type, Mockito.atLeastOnce()).getName();
        
        verify(pagesRepository, times(1)).getPropertyPage(type);
        verify(staticConfiguration, times(1)).findMediatorType("BCB");
        verify(type, times(1)).getHelpID();
        verify(frame, times(1)).showFrame();
    }
}
