package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.SystemContainerRepository;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.facade.DefaultManageObjectValues;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static com.ossnms.dcn_manager.bicnet.client.propertypage.controller.MultiSelectionPropertyValueFlow.MULTIPLE_VALUES_TOKEN;
import static com.ossnms.dcn_manager.bicnet.client.service.facade.DefaultManageObjectValues.newDummyFullNeData;
import static com.ossnms.dcn_manager.bicnet.client.service.i18n.PropertyPageLabels.NO_ASSOCIATION;
import static java.util.Arrays.asList;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.isEmptyString;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CommandOpenNePropertiesTest {

    private static final int SYSTEM_ID = 2;

    @Mock private RepositoryManager repositoryManager;
    @Mock private CommonServices commonServices;
    @Mock private PropertyPagesRepository propertyPagesRepository;
    @Mock private SystemContainerRepository systemContainerRepository;
    @Mock private NeRepository neRepository;

    private CommandOpenNeProperties commandOpenNeProperties;

    @Before public void setUp() throws Exception {
        when(repositoryManager.getSystemContainerRepository()).thenReturn(systemContainerRepository);
        when(repositoryManager.getNeRepository()).thenReturn(neRepository);

        commandOpenNeProperties = new CommandOpenNeProperties(repositoryManager, commonServices, propertyPagesRepository);

        final ISystemContainer systemContainer = DefaultManageObjectValues.newBasicSystemContainerItem("system_name");
        systemContainer.setId(SYSTEM_ID);

        when(systemContainerRepository.get(SYSTEM_ID)).thenReturn(of(systemContainer));
    }

    @Test public void testLoadSystemName_singleSelection() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, SYSTEM_ID));

        final String systemName = commandOpenNeProperties.loadSystemName(nes);

        assertThat(systemName, is("system_name"));
    }

    @Test public void testLoadSystemName_no_system_found() throws Exception {
        when(systemContainerRepository.get(SYSTEM_ID)).thenReturn(empty());
        Iterable<FullNeData> nes = asList(ne(1, SYSTEM_ID));

        final String systemName = commandOpenNeProperties.loadSystemName(nes);

        assertThat(systemName, is(NO_ASSOCIATION.toString()));
    }

    @Test public void testLoadSystemName_multi_selection_same_system() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, SYSTEM_ID), ne(2, SYSTEM_ID));

        final String systemName = commandOpenNeProperties.loadSystemName(nes);

        assertThat(systemName, is("system_name"));
    }

    @Test public void testLoadSystemName_multi_selection_diff_systems() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, SYSTEM_ID), ne(2, SYSTEM_ID + 1));

        final String systemName = commandOpenNeProperties.loadSystemName(nes);

        assertThat(systemName, is(MULTIPLE_VALUES_TOKEN));
    }

    @Test public void loadLocation_noLocation() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, null), ne(2, null));

        final String location = commandOpenNeProperties.loadLocation(nes);

        assertThat(location, isEmptyString());
    }

    @Test public void loadLocation_singleSelection() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, "Location"));

        final String location = commandOpenNeProperties.loadLocation(nes);

        assertThat(location, is("Location"));
    }

    @Test public void loadLocation_multiple_same() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, "Location"), ne(2, "Location"));

        final String location = commandOpenNeProperties.loadLocation(nes);

        assertThat(location, is("Location"));
    }

    @Test public void loadLocation_multiple_different() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, "Location"), ne(2, "Another"));

        final String location = commandOpenNeProperties.loadLocation(nes);

        assertThat(location, is(MULTIPLE_VALUES_TOKEN));
    }

    @Test public void loadLocation_multiple_withNull() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, null), ne(2, "Another"));

        final String location = commandOpenNeProperties.loadLocation(nes);

        assertThat(location, is(MULTIPLE_VALUES_TOKEN));
    }

    @Test public void typeLabels_onlyType() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, "type", null));

        final String location = commandOpenNeProperties.loadTypeLabel(nes);

        assertThat(location, is("type"));
    }

    @Test public void typeLabels_typeWithSubType() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, "type", "subType"));

        final String location = commandOpenNeProperties.loadTypeLabel(nes);

        assertThat(location, is("subType (type)"));
    }

    @Test public void typeLabels_multipleSame() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, "type", "subType"), ne(1, "type", "subType"));

        final String location = commandOpenNeProperties.loadTypeLabel(nes);

        assertThat(location, is("subType (type)"));
    }

    @Test public void typeLabels_multipleDifferent() throws Exception {
        Iterable<FullNeData> nes = asList(ne(1, "type", "subType"), ne(1, "type", null));

        final String location = commandOpenNeProperties.loadTypeLabel(nes);

        assertThat(location, is(MULTIPLE_VALUES_TOKEN));
    }

    private FullNeData ne(int id, String type, String subType) {
        FullNeData ne = ne(id, 0);
        ne.getNe().setNeProxyType(type);
        ne.getNe().setNeSubType(subType);
        return ne;
    }

    private FullNeData ne(int neId, int system) {
        final FullNeData ne = newDummyFullNeData("type", "ne_name", 4, of(system));
        ne.getNe().setId(neId);
        return ne;
    }

    private FullNeData ne(int neId, String location) {
        final FullNeData ne = ne(neId, 0);
        ne.getNe().setLocation(location);
        return ne;
    }

}
