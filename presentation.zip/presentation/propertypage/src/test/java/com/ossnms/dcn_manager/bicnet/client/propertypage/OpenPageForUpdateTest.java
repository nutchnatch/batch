package com.ossnms.dcn_manager.bicnet.client.propertypage;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.api.view.MessageBox;
import com.ossnms.dcn_manager.bicnet.client.propertypage.command.UpdatePropertyPageOkButtonCommand;
import com.ossnms.dcn_manager.bicnet.client.propertypage.configuration.PropertyPagesRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.PageDocumentForUpdate;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.model.PropertyPage;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.view.PropertyPageView;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.Type;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Optional;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OpenPageForUpdateTest {

    @Mock private PropertyValueRepository valueRepository;
    @Mock private IMediator element;
    @Mock private Type type;
    @Mock private PageDocumentForUpdate<Integer, IMediator> document;
    @Mock private UpdatePropertyPageOkButtonCommand<Integer, IMediator, Repository<Integer, IMediator>> command;
    @Mock private Page page;
    @Mock private DcnPluginHelper pluginHelper;
    @Mock private CommonServices commonServices;
    @Mock private MessageBox messageBox;
    @Mock private PropertyPage propertyPage;
    @Mock private BiCNetPluginSite site;
    @Mock private BiCNetPluginFrame frame;
    @Mock private PropertyPagesRepository pagesRepository;
    
    private OpenPropertyPage<IMediator> openPageForUpdate;

    @Before
    public void setup() throws BiCNetPluginException {
        DcnPluginHelperSingleton.getInstance().setCfPluginSite(site);

        when(commonServices.getDcnPluginHelper()).thenReturn(pluginHelper);
        when(commonServices.getMessageBox()).thenReturn(messageBox);

        when(site.createFrame(any(PropertyPageView.class), any(BiCNetPluginFrameType.class))).thenReturn(frame);
        
        when(element.getNativeName()).thenReturn("nativeName");
        
        when(document.getPropertyPage()).thenReturn(propertyPage);
        when(document.getValueRepository()).thenReturn(valueRepository);

        when(propertyPage.getTitle()).thenReturn("title");
        when(propertyPage.getHelpId()).thenReturn(1);
        when(propertyPage.getPage()).thenReturn(page);
        when(propertyPage.applyCommand()).thenReturn(Optional.empty());
        
        when(valueRepository.allValues()).thenReturn(new ArrayList<>());
        
        when(page.getGlobalVariable()).thenReturn(new ArrayList<>());
        when(page.getStatic()).thenReturn(new ArrayList<>());
        when(page.getTabbedPane()).thenReturn(new ArrayList<>());
        when(page.getTabbedPane()).thenReturn(new ArrayList<>());

        openPageForUpdate = new OpenPropertyPage<>("nativeName", commonServices, type, document, pagesRepository);
        openPageForUpdate.setCommand(command);
    }

    @Test
    public void testCall() throws PropertyValueBuilderException {
        
        openPageForUpdate.call();
        
        verify(document, times(1)).propertyPage(any(PropertyPage.class));
        verify(type, times(1)).getHelpID();
    }
}
