package com.ossnms.dcn_manager.bicnet.client.propertypage.repository;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.junit.Test;

import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PageGlobalVariable;
import com.ossnms.dcn_manager.core.jaxb.propertypage.GlobalVariable;

public class PageGlobalVariableTest {

    @Test
    public void testCreate() {
        final PageGlobalVariable globalVariable = new PageGlobalVariable("id", "value");

        assertThat(globalVariable.getId(), is("id"));
        assertThat(globalVariable.getContent(), is("value"));

        assertFalse(globalVariable.isChanged());
        assertFalse(globalVariable.isMandatoryValueBlank());
        assertFalse(globalVariable.isEnabled());
        assertFalse(globalVariable.isInvalidEntry());
        assertFalse(globalVariable.isMovable());
        assertTrue(globalVariable.getValueActions().isEmpty());
    }

    @Test
    public void testCreateByGlobalVariable() {
        final GlobalVariable global = new GlobalVariable();
        global.setId("id");
        global.setValue("value");

        final PageGlobalVariable globalVariable = new PageGlobalVariable(global);

        assertThat(globalVariable.getId(), is("id"));
        assertThat(globalVariable.getContent(), is("value"));
    }

    @Test
    public void testChangeContent() {
        final PageGlobalVariable globalVariable = new PageGlobalVariable("id", "value");

        globalVariable.setContent("value2");

        assertThat(globalVariable.getContent(), is("value2"));
        assertFalse(globalVariable.isChanged());
    }

    @Test
    public void testChangeEvent() {
        final ChangeListenerTest changeListenerTest = new ChangeListenerTest();

        final PageGlobalVariable globalVariable = new PageGlobalVariable("id", "value");
        globalVariable.addConditionListener(changeListenerTest);
        globalVariable.setContent("value2");

        assertThat(globalVariable.getContent(), is("value2"));
        assertTrue(changeListenerTest.isChanged());
    }

    private final static class ChangeListenerTest implements ChangeListener {
        private boolean changed = false;

        @Override
        public void stateChanged(ChangeEvent e) {
            changed = true;
        }

        public boolean isChanged() {
            return changed;
        }
    }
}
