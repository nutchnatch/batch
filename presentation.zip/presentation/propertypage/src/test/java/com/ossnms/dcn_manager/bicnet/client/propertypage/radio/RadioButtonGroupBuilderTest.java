package com.ossnms.dcn_manager.bicnet.client.propertypage.radio;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.net.URL;

import javax.swing.Box;
import javax.swing.JPanel;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.propertypage.RadioGroup;
import com.ossnms.dcn_manager.bicnet.client.propertypage.controller.SingleSelectionPropertyValueFlow;
import com.ossnms.dcn_manager.bicnet.client.propertypage.exception.PropertyValueBuilderException;
import com.ossnms.dcn_manager.bicnet.client.propertypage.formatter.DynamicPanelForm;
import com.ossnms.dcn_manager.bicnet.client.propertypage.radio.RadioButtonGroupBuilder;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepository;
import com.ossnms.dcn_manager.bicnet.client.propertypage.repository.PropertyValueRepositoryImpl;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxRadioButton;
import com.ossnms.dcn_manager.bicnet.client.propertypage.value.ValueJfxTextAreaTest;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;
import com.ossnms.tools.jfx.components.JfxRadioButton;

public class RadioButtonGroupBuilderTest {
    private static final URL XML_URL = ValueJfxTextAreaTest.class.getClassLoader().getResource("value-radio.xml");

    private final XmlFileLoader loader = new XmlFileLoader();
    private final RadioGroup radioGroup;
    private JPanel panel;
    private final PropertyValueRepository repository;

    public RadioButtonGroupBuilderTest() {
        this.radioGroup = loader.loadConfiguration(RadioGroup.class, XML_URL, null);
        this.repository = new PropertyValueRepositoryImpl(new SingleSelectionPropertyValueFlow());
    }

    @Before
    public void setup() throws PropertyValueBuilderException {
        this.panel = new RadioButtonGroupBuilder(new DynamicPanelForm(), radioGroup, repository).build();
    }

    @After
    public void release() {
        this.panel = null;
    }

    @Test
    public void testCreateObject() {
        assertTrue(panel.getComponent(0) instanceof ValueJfxRadioButton);
        assertTrue(panel.getComponent(1) instanceof ValueJfxRadioButton);
        assertTrue(panel.getComponent(2) instanceof Box);

        assertThat(panel.getComponentCount(), is(3));
    }

    @Test
    public void testToggleSelection() {

        final JfxRadioButton radio1 = (ValueJfxRadioButton) panel.getComponent(0);
        final JfxRadioButton radio2 = (ValueJfxRadioButton) panel.getComponent(1);
        
        radio1.setSelected(true);
        
        assertTrue(radio1.isSelected());
        assertFalse(radio2.isSelected());
        
        radio2.setSelected(true);
        
        assertFalse(radio1.isSelected());
        assertTrue(radio2.isSelected());
    }
}
