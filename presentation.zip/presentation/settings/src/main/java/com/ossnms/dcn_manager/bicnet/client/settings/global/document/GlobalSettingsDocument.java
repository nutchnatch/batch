package com.ossnms.dcn_manager.bicnet.client.settings.global.document;

import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ConfigurationRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.settings.global.jobs.LoadGlobalSettingsFetchJob;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;

/**
 * Global setting document for the {@link com.ossnms.dcn_manager.bicnet.client.settings.global.view.GlobalSettingsPageView} page. 
 */
public class GlobalSettingsDocument extends FrameworkDocument {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalSettingsDocument.class);
    
    private final ConfigurationRepository repository;

    public GlobalSettingsDocument(@Nonnull final FrameworkPluginHelper helper, @Nonnull final ConfigurationRepository repository) {
        super(helper);
        this.repository = repository;
    }

    /*
     * @see com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument#setResult(com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob, java.lang.Object)
     */
    @Override
    public void setResult(@Nonnull final IFrameworkJob job, @Nullable final Object result) {
        if (job.hasExceptionOccured()) {
            throw new IllegalStateException(job.getException());
        }
        updateData(result);
    }

    /*
     * @see com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDataSource#getObject(java.lang.Object)
     */
    @Override
    public Object getObject(Object key) {
        throw new UnsupportedOperationException();
    }

    /**
     * Load from Configuration Repository the Global Settings
     */
    public void loadSettings() {
        addAndExecuteJob(new LoadGlobalSettingsFetchJob(this, getPluginHelper().getLogonContext(), repository));
    }

    /**
     * Call the Configuration Repository to update the settings.
     * @param updatedProperties updated settings
     */
    public void updateSettings(@Nonnull final Map<String, String> updatedProperties) {
        try {
            repository.updateGlobalSettings(getPluginHelper().getLogonContext(), updatedProperties);
        } catch (final RepositoryException e) {
            LOGGER.error("Error on update Global Settings", e);
        }
    }
}
