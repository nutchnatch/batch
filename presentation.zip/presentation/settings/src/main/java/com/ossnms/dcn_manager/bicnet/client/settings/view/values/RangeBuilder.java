package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.google.common.base.Joiner;
import com.ossnms.tools.jfx.components.JfxLabel;
import org.apache.commons.lang3.StringUtils;

public class RangeBuilder {

    public JfxLabel build(SpinnerIntegerModel spinnerModel) {
        final String range = Joiner.on("...").join(spinnerModel.getMinimum(), spinnerModel.getMaximum());
        return new JfxLabel(StringUtils.join("[", range, "]"));
    }
    
    public JfxLabel buildWithUnit(String unit, SpinnerIntegerModel spinnerModel) {
        final String range = Joiner.on("...").join(spinnerModel.getMinimum(), spinnerModel.getMaximum());
        return new JfxLabel(StringUtils.join(unit, " [", range, "]"));
    }
}
