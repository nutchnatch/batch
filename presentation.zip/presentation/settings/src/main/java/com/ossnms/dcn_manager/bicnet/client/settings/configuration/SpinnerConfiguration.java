package com.ossnms.dcn_manager.bicnet.client.settings.configuration;

import javax.annotation.Nonnull;

public enum SpinnerConfiguration {

    SCALED_STARTUP_LIMIT(21, 1, 999),
    
    /** Values in minutes **/
    RETRY_INTERVAL(1, 1, 20),
    
    /** Default Value 0 means infinite retries **/
    RETRY_MEDIATOR(0, 0, 999),
    RETRY_CHANNEL(0, 0, 999),
    RETRY_NE(0, 0, 999);
    
    private final Integer defaultValue;
    private final Integer maximumValue;
    private final Integer minimumValue;
    
    SpinnerConfiguration(@Nonnull final Integer defaultValue, @Nonnull final Integer minimumValue, @Nonnull final Integer maximumValue) {
        this.defaultValue = defaultValue;
        this.minimumValue = minimumValue;
        this.maximumValue = maximumValue;
    }

    public Integer getDefaultValue() {
        return defaultValue;
    }
    
    public Integer getMinimumValue() {
        return minimumValue;
    }
    
    public Integer getMaximumValue() {
        return maximumValue;
    }
}
