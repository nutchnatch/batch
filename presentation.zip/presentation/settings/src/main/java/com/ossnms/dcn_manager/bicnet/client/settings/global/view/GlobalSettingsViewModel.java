package com.ossnms.dcn_manager.bicnet.client.settings.global.view;

import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPage;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.GlobalSettingsLabels;
import com.ossnms.dcn_manager.bicnet.client.settings.configuration.SpinnerConfiguration;
import com.ossnms.dcn_manager.bicnet.client.settings.configuration.StringConfiguration;
import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.DiscoveryPolicesLoader;
import com.ossnms.dcn_manager.bicnet.client.settings.view.values.CheckBoxValue;
import com.ossnms.dcn_manager.bicnet.client.settings.view.values.ComboBoxValue;
import com.ossnms.dcn_manager.bicnet.client.settings.view.values.Formatter;
import com.ossnms.dcn_manager.bicnet.client.settings.view.values.PropertyValues;
import com.ossnms.dcn_manager.bicnet.client.settings.view.values.RangeBuilder;
import com.ossnms.dcn_manager.bicnet.client.settings.view.values.SpinnerValue;
import com.ossnms.dcn_manager.bicnet.client.settings.view.values.StringValue;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxSpinner;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.JPanel;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.Component;
import java.awt.GridBagLayout;
import java.awt.event.ItemListener;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.settings.global.properties.DiscoveryPolicy.DISCOVERY_BY_DOMAIN;
import static com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames.DEFAULT_CONTAINER_NAME;
import static com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames.DISCOVERY_POLICY;
import static com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames.ENABLE_NATIVE_NE_NAMING;
import static com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames.ENABLE_SCHEDULED_STARTUP;
import static com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames.RETRY_CHANNEL;
import static com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames.RETRY_INTERVAL;
import static com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames.RETRY_MEDIATOR;
import static com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames.RETRY_NE;
import static com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames.SCALED_STARTUP_LIMIT;
import static javax.swing.SwingUtilities.invokeLater;

/**
 * Contains the GUI components for GlobalSettingsView.
 */
class GlobalSettingsViewModel {

    private static JfxLabel scaledStartupLabel;
    private static JfxLabel mediatorRetryLabel;
    private static JfxLabel channelRetryLabel;
    private static JfxLabel neRetryLabel;
    private static JfxLabel retryIntervalLabel;
    private static JfxLabel defaultContainerLabel;

    private static JfxLabel defaultPolicyLabel;
    private CheckBoxValue scaledStartupCheckbox;
    private SpinnerValue scaledStartupSpinner;

    private SpinnerValue retryNeSpinner;
    private SpinnerValue retryChannelSpinner;
    private SpinnerValue retryMediatorSpinner;
    private SpinnerValue retryIntervalSpinner;
    private StringValue defaultContainerString;

    private static JfxLabel scaledStartupRange;
    private static JfxLabel mediatorRetryRange;
    private static JfxLabel channelRetryRange;
    private static JfxLabel neRetryRange;
    private static JfxLabel retryIntervalRange;

    private CheckBoxValue nativeNameEnableCheckbox;
    private ComboBoxValue discoveryPolicyCombobox;
    private JfxButton defaultButton;

    private final DiscoveryPolicesLoader discoveryPolicesLoader;
    private final PropertyValues propertyValues;
    private final RangeBuilder rangeBuilder;
    private final Formatter formatter;

    private BiCNetPluginPropertyPageSite pluginListener;
    private final BiCNetPluginPropertyPage page;

    GlobalSettingsViewModel(@Nonnull final PropertyValues propertyValues,
            @Nonnull final BiCNetPluginPropertyPage page) {
        super();
        this.propertyValues = propertyValues;
        this.page = page;

        this.discoveryPolicesLoader = new DiscoveryPolicesLoader();
        this.rangeBuilder = new RangeBuilder();
        this.formatter = new Formatter();

        buildComponents();
    }

    void setPluginListener(@Nullable final BiCNetPluginPropertyPageSite pluginListener) {
        this.pluginListener = pluginListener;
    }

    protected Optional<BiCNetPluginPropertyPageSite> getPluginListener() {
        return Optional.ofNullable(this.pluginListener);
    }

    private void buildComponents() {
        scaledStartupLabel = new JfxLabel(GlobalSettingsLabels.SCALED_STARTUP.guiName());
        mediatorRetryLabel = new JfxLabel(GlobalSettingsLabels.MEDIATOR_RETRY.guiName());
        channelRetryLabel = new JfxLabel(GlobalSettingsLabels.CHANNEL_RETRY.guiName());
        neRetryLabel = new JfxLabel(GlobalSettingsLabels.NE_RETRY.guiName());
        retryIntervalLabel = new JfxLabel(GlobalSettingsLabels.RETRY_INTERVAL.guiName());
        defaultPolicyLabel = new JfxLabel(GlobalSettingsLabels.DISCOVER_POLICY_MODE.guiName());
        defaultContainerLabel = new JfxLabel(GlobalSettingsLabels.DEFAULT_CONTAINER_NAME.guiName());

        scaledStartupLabel.setLabelAndMnemonicFor(scaledStartupSpinner);
        mediatorRetryLabel.setLabelAndMnemonicFor(retryNeSpinner);
        channelRetryLabel.setLabelAndMnemonicFor(retryMediatorSpinner);
        neRetryLabel.setLabelAndMnemonicFor(retryChannelSpinner);
        retryIntervalLabel.setLabelAndMnemonicFor(retryIntervalSpinner);
        defaultPolicyLabel.setLabelAndMnemonicFor(discoveryPolicyCombobox);
        defaultContainerLabel.setLabelAndMnemonicFor(defaultContainerString);

        scaledStartupCheckbox = new CheckBoxValue(ENABLE_SCHEDULED_STARTUP, GlobalSettingsLabels.ENABLE_SCALED_STARTUP,
                true).addListener(e -> {
                    scaledStartupLabel.setEnabled(scaledStartupCheckbox.isSelected());
                    scaledStartupSpinner.setEnabled(scaledStartupCheckbox.isSelected());
                    scaledStartupRange.setEnabled(scaledStartupCheckbox.isSelected());
                    fireStateChanged();
                });
        scaledStartupCheckbox.setMnemonic(GlobalSettingsLabels.ENABLE_SCALED_STARTUP.guiName().getMnemonic());

        scaledStartupSpinner = new SpinnerValue(SCALED_STARTUP_LIMIT, SpinnerConfiguration.SCALED_STARTUP_LIMIT)
                .addListener(getChangeListener());
        retryMediatorSpinner = new SpinnerValue(RETRY_MEDIATOR, SpinnerConfiguration.RETRY_MEDIATOR)
                .addListener(getChangeListener());
        retryChannelSpinner = new SpinnerValue(RETRY_CHANNEL, SpinnerConfiguration.RETRY_CHANNEL)
                .addListener(getChangeListener());
        retryNeSpinner = new SpinnerValue(RETRY_NE, SpinnerConfiguration.RETRY_NE).addListener(getChangeListener());
        retryIntervalSpinner = new SpinnerValue(RETRY_INTERVAL, SpinnerConfiguration.RETRY_INTERVAL)
                .addListener(getChangeListener());

        scaledStartupRange = rangeBuilder.build((SpinnerIntegerModel) scaledStartupSpinner.getModel());
        mediatorRetryRange = rangeBuilder.build((SpinnerIntegerModel) retryNeSpinner.getModel());
        channelRetryRange = rangeBuilder.build((SpinnerIntegerModel) retryMediatorSpinner.getModel());
        neRetryRange = rangeBuilder.build((SpinnerIntegerModel) retryChannelSpinner.getModel());
        retryIntervalRange = rangeBuilder.buildWithUnit(GlobalSettingsLabels.UNIT.toString(),
                (SpinnerIntegerModel) retryIntervalSpinner.getModel());

        nativeNameEnableCheckbox = new CheckBoxValue(ENABLE_NATIVE_NE_NAMING,
                GlobalSettingsLabels.SHOW_NATIVE_NE_NAMING, false).addListener(getItemListener());
        nativeNameEnableCheckbox.setMnemonic(GlobalSettingsLabels.SHOW_NATIVE_NE_NAMING.guiName().getMnemonic());

        discoveryPolicyCombobox = new ComboBoxValue(DISCOVERY_POLICY, discoveryPolicesLoader.loadModel(),
                DISCOVERY_BY_DOMAIN.getName()).addListener(getItemListener());

        defaultContainerString = new StringValue(DEFAULT_CONTAINER_NAME, StringConfiguration.DEFAULT_CONTAINER_NAME)
                .addListener(new DocumentListener() {
                    @Override public void insertUpdate(DocumentEvent e) {
                        fireStateChanged();
                    }
                    @Override public void removeUpdate(DocumentEvent e) {
                        fireStateChanged();
                    }
                    @Override public void changedUpdate(DocumentEvent e) {
                        fireStateChanged();
                    }
                });

        defaultButton = new JfxButton(JfxStringTable.IDS_Default);
        defaultButton.setName(JfxStringTable.IDS_Default.getText());
        defaultButton.addActionListener(e -> {
            propertyValues.toDefaultValues();
            fireStateChanged();
        });

        propertyValues.add(scaledStartupCheckbox, scaledStartupSpinner, retryIntervalSpinner, retryNeSpinner,
                retryChannelSpinner, retryMediatorSpinner, nativeNameEnableCheckbox, discoveryPolicyCombobox,
                defaultContainerString);
    }

    void enableButtons(boolean isEnabled) {
        Iterable<Component> components = ImmutableList
                .of(scaledStartupCheckbox, scaledStartupSpinner, retryMediatorSpinner, retryChannelSpinner,
                        retryNeSpinner, retryIntervalSpinner, nativeNameEnableCheckbox, scaledStartupCheckbox,
                        discoveryPolicyCombobox, defaultButton, defaultContainerString);

        components.forEach(in -> {
            in.setEnabled(isEnabled);
        });
    }

    JPanel buildMainPanel() {
        final JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        int position = 0;

        mainPanel.add(buildSettingsPanel(), formatter.northwest(position++));
        mainPanel.add(defaultButton, formatter.southwestFixSize(position));

        return mainPanel;
    }

    private JPanel buildSettingsPanel() {
        final JPanel initializationPanel = new JPanel(new GridBagLayout());
        final JPanel scaledStartupPanel = new JPanel(new GridBagLayout());
        int row = Formatter.ROW_INITIAL_VALUE;
        final int fields = 3;

        initializationPanel.add(scaledStartupCheckbox, formatter.checkboxFormatter(row++, false));

        addSpinnerRow(scaledStartupPanel, scaledStartupLabel, scaledStartupSpinner, scaledStartupRange, 0);
        initializationPanel.add(scaledStartupPanel, formatter.indentedPanelFormatter(row++, fields));

        addSpinnerRow(initializationPanel, mediatorRetryLabel, retryMediatorSpinner, mediatorRetryRange, row++);
        addSpinnerRow(initializationPanel, channelRetryLabel, retryChannelSpinner, channelRetryRange, row++);
        addSpinnerRow(initializationPanel, neRetryLabel, retryNeSpinner, neRetryRange, row++);
        addSpinnerRow(initializationPanel, retryIntervalLabel, retryIntervalSpinner, retryIntervalRange, row++);

        initializationPanel.add(defaultPolicyLabel, formatter.labelFormatter(row));
        initializationPanel.add(discoveryPolicyCombobox, formatter.comboboxFormatter(row++));

        initializationPanel.add(defaultContainerLabel, formatter.labelFormatter(row));
        initializationPanel.add(defaultContainerString, formatter.comboboxFormatter(row++));

        initializationPanel.add(nativeNameEnableCheckbox, formatter.checkboxFormatter(row, true));

        return initializationPanel;
    }

    private void addSpinnerRow(JPanel spinnerPanel, JfxLabel label, JfxSpinner spinner, JfxLabel range, int row) {
        spinnerPanel.add(label, formatter.labelFormatter(row));
        spinnerPanel.add(spinner, formatter.spinnerFormatter(row));
        spinnerPanel.add(range, formatter.defaultFormatter(row, JfxUtils.UNIT_LEFT_MARGIN));
    }

    final void fireStateChanged() {
        if (getPluginListener().isPresent() && propertyValues.changed()) {
            invokeLater(() -> pluginListener.eventPageStatusChanged(page));
        }
    }

    private ChangeListener getChangeListener() {
        return e -> fireStateChanged();
    }

    private ItemListener getItemListener() {
        return e -> fireStateChanged();
    }
}