package com.ossnms.dcn_manager.bicnet.client.settings.global.properties;

import javax.annotation.Nonnull;


/**
 * Contains constants with the names of "well known" EM/NE property names
 * as mentioned in the user interface description files.
 */
public enum WellKnownGlobalSettingsPropertyNames {

    RETRY_MEDIATOR("RetryMediator"),
    RETRY_CHANNEL("RetryChannel"), 
    RETRY_NE("RetryNe"), 
    RETRY_INTERVAL("TimeIntervalForScheduler"), 
    
    ENABLE_SCHEDULED_STARTUP("ActiveScheduleStartup"), 
    SCALED_STARTUP_LIMIT("GlobalScheduleStartup"),

    DISCOVERY_POLICY("DiscoveryPolicy"),
    ENABLE_NATIVE_NE_NAMING("NativeNeNaming"),

    DEFAULT_CONTAINER_NAME("DefaultContainerName");

    private final String name;
    
    WellKnownGlobalSettingsPropertyNames(@Nonnull final String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
    
    @Override
    public String toString() {
        return name;
    }
}
