package com.ossnms.dcn_manager.bicnet.client.settings.global.view;

import com.google.common.base.Preconditions;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPage;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDataChangeListener;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.GlobalSettingsLabels;
import com.ossnms.dcn_manager.bicnet.client.settings.global.document.GlobalSettingsDocument;
import com.ossnms.dcn_manager.bicnet.client.settings.view.values.PropertyValues;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;

import javax.annotation.Nonnull;
import javax.swing.JComponent;
import javax.swing.JPanel;
import java.util.Map;

public class GlobalSettingsPageView extends JPanel implements BiCNetPluginPropertyPage, IFrameworkDataChangeListener {
    
    private static final long serialVersionUID = -3097420388498041356L;
    private static final String VIEW_ID  = GlobalSettingsPageView.class.getName();

    private final GlobalSettingsDocument document;
    private final PropertyValues properties;
    private final GlobalSettingsViewModel model;
    private final JPanel mainPanel;
    
    public GlobalSettingsPageView(@Nonnull final GlobalSettingsDocument document) {
        this.document = document;
        this.document.setDataChangeListener(this);

        this.properties = new PropertyValues();
        this.model = new GlobalSettingsViewModel(properties, this);
        this.mainPanel = model.buildMainPanel();
    }

    GlobalSettingsPageView(@Nonnull final GlobalSettingsDocument document,
            @Nonnull final PropertyValues properties, @Nonnull final GlobalSettingsViewModel model) {
        this.document = document;
        this.document.setDataChangeListener(this);

        this.properties = properties;
        this.model = model;
        this.mainPanel = model.buildMainPanel();
    }
    
    @Override
    public void actionApply() {
        document.updateSettings(properties.getChangedValues());
    }

    @Override
    public void eventOpened() {
        document.loadSettings();
    }

    @Override
    public JComponent getComponent() {
        return mainPanel;
    }

    @Override
    public String getID() {
        return VIEW_ID;
    }

    @Override
    public String getTitle() {
        return GlobalSettingsLabels.DCN_MANAGER.toString();
    }

    @Override
    public boolean isPageDirty() {
        return properties.changed();
    }

    @Override
    public void setPageSite(BiCNetPluginPropertyPageSite propertyPageSite) {
       this.model.setPluginListener(propertyPageSite);
    }

    @Override
    @SuppressWarnings("unchecked")
    public void updateData(@Nonnull final Object object) {
        Preconditions.checkNotNull(object, "Map of values cannot be null");
        properties.setValues((Map<String, String>) object );
        model.enableButtons(document.getPluginHelper().checkPermissions(SecureAction.SYSTEM_PREFERENCES.getIdentifier()));
        model.fireStateChanged();
    }

    @Override
    public void setReadOnly(boolean readOnly) {
        model.enableButtons(document.getPluginHelper().checkPermissions(SecureAction.SYSTEM_PREFERENCES.toString()));
    }

    @Override
    public void setObjects(IManagedObjectMarkable[] markables) {
    }
    
    @Override
    public void update() {
    }
    
    @Override
    public void validateInput() throws BiCNetPluginException {
    }
    
    @Override
    public void actionCancel() {
    }

    @Override
    public void eventClosing() {
    }
}
