package com.ossnms.dcn_manager.bicnet.client.settings.global.properties;

import com.ossnms.tools.jfx.components.JfxComboBox.ItemData;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;

public class DiscoveryPolicesLoader {
  
    public ComboBoxModel<ItemData> loadModel() {
        final ItemData[] items = DiscoveryPolicy.list().stream()
                .map(input -> new ItemData(input.getName(), input.getName())).toArray(ItemData[]::new);
        
        return new DefaultComboBoxModel<>(items);
    }
}
