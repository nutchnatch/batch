package com.ossnms.dcn_manager.bicnet.client.settings.global.jobs;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ConfigurationRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

import javax.annotation.Nonnull;

/**
 * Loads the DCN Management Plug-in Settings.
 */
public class LoadGlobalSettingsFetchJob extends FrameworkFetchJob {

    private static final String JOB_ID = LoadGlobalSettingsFetchJob.class.getName();
    private static final String JOB_NAME = "Load DCN management Global Settings";
    private static final String JOB_INFO = "";

    private final ConfigurationRepository repository;
    private final ISessionContext context;

    public LoadGlobalSettingsFetchJob(@Nonnull final IFrameworkDocument document, @Nonnull final ISessionContext context, @Nonnull final ConfigurationRepository repository) {
        super(JOB_ID, JOB_NAME, JOB_INFO, document);
        this.repository = repository;
        this.context = context;
    }

    /*
     * @see com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob#execute(java.lang.Object)
     */
    @Override
    public Object execute(Object object) throws FrameworkException {
        try {
            return repository.getGlobalSettings(context);
        } catch (final RepositoryException e) {
            throw new FrameworkException(e);
        }
    }
}
