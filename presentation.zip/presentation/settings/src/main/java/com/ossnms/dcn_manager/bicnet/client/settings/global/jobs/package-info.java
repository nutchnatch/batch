/**
 * Contains the Plug-in Jobs.
 */
package com.ossnms.dcn_manager.bicnet.client.settings.global.jobs;