package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.ossnms.tools.jfx.JfxUtils;

import java.awt.GridBagConstraints;
import java.awt.Insets;

public class Formatter {

    public static final int ROW_INITIAL_VALUE = 0;
    private static final int LEFT_MARGIN_DEFAULT = 0;
    
    public GridBagConstraints labelFormatter(final int row) {
        return new GridBagConstraints(GridBagConstraints.RELATIVE, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0);
    }
    
    public GridBagConstraints spinnerFormatter(final int row) {
        return new GridBagConstraints(GridBagConstraints.RELATIVE, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0);
    }

    public GridBagConstraints checkboxFormatter(final int row, boolean addTopMargin) {
        return new GridBagConstraints(0, row, 3, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(addTopMargin ? JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS : 0, 0, 0, 0), 0, 0);
    }
    
    public Object comboboxFormatter(int row) {
        return new GridBagConstraints(GridBagConstraints.RELATIVE, row, 2, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0);
    }
    
    public GridBagConstraints defaultFormatter(final int row) {
        return defaultFormatter(row, LEFT_MARGIN_DEFAULT);
    }
    
    public GridBagConstraints defaultFormatter(final int row, final int leftMargin) {
        return new GridBagConstraints(GridBagConstraints.RELATIVE, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, leftMargin, 0, 0), 0, 0);
    }
    
    public GridBagConstraints indentedPanelFormatter(final int row, int numberOfFields) {
        return new GridBagConstraints(GridBagConstraints.RELATIVE, row, numberOfFields, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, JfxUtils.FIELD_INDENTATION, 0, 0), 0, 0);
    }
    
    public GridBagConstraints northwest(final int row) {
        return new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.BOTH, defaultInsetsValue(), 0, 0);
    }

    public GridBagConstraints southwestFixSize(final int row) {
        return new GridBagConstraints(0, row, 1, 1, 1.0, 1.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, defaultInsetsValue(), 0, 0);
    }

    private Insets defaultInsetsValue() {
        return new Insets(0, 0, 0, 0);
    }
}