package com.ossnms.dcn_manager.bicnet.client.settings.configuration;

import javax.annotation.Nonnull;

public enum StringConfiguration {

    DEFAULT_CONTAINER_NAME("Default Ne Container");

    private final String defaultValue;

    StringConfiguration(@Nonnull final String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public String getDefaultValue() {
        return defaultValue;
    }
}
