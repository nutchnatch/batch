/**
 * Contains the configurations of Settings module. 
 */
package com.ossnms.dcn_manager.bicnet.client.settings.configuration;