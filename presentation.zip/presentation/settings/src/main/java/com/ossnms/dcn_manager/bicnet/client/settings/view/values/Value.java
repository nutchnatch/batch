package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.ossnms.bicnet.common.jfx.JfxModifiableField;
import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames;

public interface Value extends JfxModifiableField {
    
    WellKnownGlobalSettingsPropertyNames getKey();
    String getContent();
    void setContent(String value);
    void toDefaultValue();
}
