package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.ossnms.dcn_manager.bicnet.client.settings.configuration.SpinnerConfiguration;
import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames;
import com.ossnms.tools.jfx.components.JfxSpinner;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;
import javax.swing.event.ChangeListener;

public class SpinnerValue extends JfxSpinner implements Value {

    private static final long serialVersionUID = -2524587583355425043L;
    private static final int STEP_VALUE = 1;

    private final WellKnownGlobalSettingsPropertyNames key;
    private final Integer defaultValue;
    
    public SpinnerValue(@Nonnull final WellKnownGlobalSettingsPropertyNames key, @Nonnull final  SpinnerConfiguration configuration) {
        super(new SpinnerIntegerModel(configuration.getDefaultValue(), configuration.getMinimumValue(), configuration.getMaximumValue(), STEP_VALUE));
        this.key = key;
        this.defaultValue = configuration.getDefaultValue();

        this.setName(key.getName());
        this.setContent(String.valueOf(defaultValue));
    }
    
    public SpinnerValue addListener(ChangeListener listener) {
        this.addChangeListener(listener);
        return this;
    }
    
    @Override
    public WellKnownGlobalSettingsPropertyNames getKey() {
        return key;
    }

    @Override
    public String getContent() {
        return String.valueOf(getValue());
    }

    @Override
    public void toDefaultValue() {
        this.setValue(defaultValue);
    }
    
    @Override
    public void setContent(String value) {
        final Integer integerValue = NumberUtils.toInt(value, defaultValue);
        
        this.setValue(integerValue);
        this.setUnmodifiedValue(integerValue);
    }
}
