package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames;
import com.ossnms.tools.jfx.components.JfxComboBox;

import javax.annotation.Nonnull;
import javax.swing.ComboBoxModel;
import java.awt.event.ItemListener;

public class ComboBoxValue extends JfxComboBox implements Value {
    
    private static final long serialVersionUID = 247895554357231812L;
    
    private final WellKnownGlobalSettingsPropertyNames key;
    private final String defaultValue;
    
    public ComboBoxValue(@Nonnull final WellKnownGlobalSettingsPropertyNames key, @Nonnull final ComboBoxModel<ItemData> model, @Nonnull final String defaultValue) {
        super(model);
        this.key = key;
        this.defaultValue = defaultValue;
        
        this.setName(key.getName());
        this.setContent(defaultValue);
    }
    
    public ComboBoxValue addListener(ItemListener listener) {
        this.addItemListener(listener);
        return this;
    }
    
    @Override
    public WellKnownGlobalSettingsPropertyNames getKey() {
        return key;
    }

    @Override
    public String getContent() {
        return String.valueOf(this.getSelectedItem());
    }

    @Override
    public void toDefaultValue() {
        this.setSelectedItem(defaultValue);
    }
    
    @Override
    public void setContent(@Nonnull final String value) {
        this.setSelectedItem(value);
        this.setUnmodifiedValue(this.getSelectedItem());
    }
}
