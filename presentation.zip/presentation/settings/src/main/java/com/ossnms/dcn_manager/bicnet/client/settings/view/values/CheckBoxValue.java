package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.ossnms.dcn_manager.bicnet.client.service.i18n.GlobalSettingsLabels;
import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames;
import com.ossnms.tools.jfx.components.JfxCheckBox;

import javax.annotation.Nonnull;
import java.awt.event.ItemListener;

public class CheckBoxValue extends JfxCheckBox implements Value {

    private static final long serialVersionUID = -8716853442983789383L;
    
    private final WellKnownGlobalSettingsPropertyNames key;
    private final Boolean defaultValue;
    
    public CheckBoxValue(@Nonnull final WellKnownGlobalSettingsPropertyNames key, @Nonnull final GlobalSettingsLabels label, @Nonnull final Boolean defaultValue) {
        super(label.guiName());
        this.key = key;
        this.defaultValue = defaultValue;
        
        this.setName(key.getName());        
        this.setContent(String.valueOf(defaultValue));
    }
    
    public CheckBoxValue addListener(ItemListener listener) {
        this.addItemListener(listener);
        return this;
    }
    
    @Override
    public WellKnownGlobalSettingsPropertyNames getKey() {
        return key;
    }

    @Override
    public String getContent() {
        return String.valueOf(this.isSelected());
    }

    @Override
    public void toDefaultValue() {
        this.setSelected(defaultValue);
    }

    @Override
    public void setContent(@Nonnull final String value) {
        final boolean booleanValue = Boolean.valueOf(value);
        
        this.setSelected(booleanValue);
        this.setUnmodifiedValue(booleanValue);
        this.fireStateChanged();
    }
}
