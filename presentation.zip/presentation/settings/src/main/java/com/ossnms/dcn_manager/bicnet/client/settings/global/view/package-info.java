/**
 * 
 */
package com.ossnms.dcn_manager.bicnet.client.settings.global.view;