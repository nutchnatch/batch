package com.ossnms.dcn_manager.bicnet.client.settings.global.properties;

import com.google.common.collect.ImmutableList;

import java.util.Collection;


/**
 * An enumeration with all the possible discovery policy types. 
 */
public enum DiscoveryPolicy {
    DISCOVER_ALL_NETWORK("Discover All Network"),
    DISCOVERY_BY_DOMAIN("Discovery By Domain"),
    NO_DISCOVERY("No Discovery");
    
    private String name;
    
    DiscoveryPolicy(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    
    public static Collection<DiscoveryPolicy> list() {
        return ImmutableList.copyOf(DiscoveryPolicy.values());
    }
}
