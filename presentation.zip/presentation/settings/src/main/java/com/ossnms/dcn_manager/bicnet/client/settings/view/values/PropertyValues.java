package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.ossnms.bicnet.common.jfx.JfxModifiableField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.swing.SwingUtilities;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;

public class PropertyValues {

    private static final Logger LOGGER = LoggerFactory.getLogger(PropertyValues.class);
    
    private final Collection<Value> properties;

    public PropertyValues() {
        properties = new ArrayList<>();
    }

    public PropertyValues add(@Nonnull final Value... values) {
        Collections.addAll(properties, values);
        return this;
    }
    
    public Map<String, String> getChangedValues() {
       return  properties.stream()
                .filter(JfxModifiableField::isValueModified)
                .collect(Collectors.toMap(entry -> entry.getKey().getName(), Value::getContent));
    }
    
    public void setValues(@Nonnull final Map<String, String> input) {
        SwingUtilities.invokeLater(() -> {
            for (final Entry<String, String> entry : input.entrySet()) {
                final Optional<Value> value = find(entry.getKey());
                
                if (value.isPresent()) {
                    value.get().setContent(entry.getValue());
                    LOGGER.debug("Value setted for key={} ,value={}", value.get().getKey(), value.get().getContent());
                } else {
                    LOGGER.error("Value not present on Setttings key={}", entry.getKey());
                }
            }
        });
    }
    
    public Optional<Value> find(@Nonnull final String key) {
        return properties.stream().filter(input -> input.getKey().getName().equals(key)).findFirst();
    }

    public boolean changed() {
        return properties.stream().filter(JfxModifiableField::isValueModified).findFirst().isPresent();
    }

    public void toDefaultValues() {
        SwingUtilities.invokeLater(() -> properties.forEach(Value::toDefaultValue));
    }
    
    protected Collection<Value> getProperties() {
        return properties;
    }
}
