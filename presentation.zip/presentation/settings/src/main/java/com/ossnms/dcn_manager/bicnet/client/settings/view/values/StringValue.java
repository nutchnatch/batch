package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.ossnms.dcn_manager.bicnet.client.settings.configuration.StringConfiguration;
import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames;
import com.ossnms.tools.jfx.components.JfxTextField;

import javax.annotation.Nonnull;
import javax.swing.event.DocumentListener;

public class StringValue extends JfxTextField implements Value {

    private static final long serialVersionUID = -8361781328440729925L;
    private static final int SIZE = 15;
    private static final int LIMIT = 64;
    private final WellKnownGlobalSettingsPropertyNames key;
    private final String defaultValue;

    public StringValue(@Nonnull final WellKnownGlobalSettingsPropertyNames key, @Nonnull final StringConfiguration configuration) {
        super();
        this.key = key;
        this.defaultValue = configuration.getDefaultValue();

        this.setName(key.getName());
        this.setContent(defaultValue);
        this.setColumns(SIZE);
        this.limitText(LIMIT);
    }

    public StringValue addListener(@Nonnull final DocumentListener listener) {
        this.addDocumentListener(listener);
        return this;
    }

    @Override
    public WellKnownGlobalSettingsPropertyNames getKey() {
        return key;
    }

    @Override
    public String getContent() {
        return getText();
    }

    @Override
    public void toDefaultValue() {
        this.setText(defaultValue);
    }
    
    @Override
    public void setContent(String value) {
        this.setText(value);
        this.setUnmodifiedValue(value);
    }
}
