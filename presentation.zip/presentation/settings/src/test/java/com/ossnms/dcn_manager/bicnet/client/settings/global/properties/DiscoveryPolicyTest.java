package com.ossnms.dcn_manager.bicnet.client.settings.global.properties;

import org.junit.Test;

import java.util.Collection;
import java.util.stream.Collectors;

import static org.junit.Assert.assertTrue;

public class DiscoveryPolicyTest {

    @Test
    public void testList() {
        final Collection<String> names = DiscoveryPolicy.list().stream().map(DiscoveryPolicy::getName)
                .collect(Collectors.toList());
        
        assertTrue(names.contains("Discover All Network"));
        assertTrue(names.contains("Discovery By Domain"));
        assertTrue(names.contains("No Discovery"));
    }
}
