package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.ossnms.dcn_manager.bicnet.client.settings.configuration.SpinnerConfiguration;
import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.swing.event.ChangeListener;
import java.util.Arrays;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class SpinnerValueTest {
    @Mock private ChangeListener changeListener;
    private SpinnerValue value;

    @Before
    public void setup() {
        value = new SpinnerValue(WellKnownGlobalSettingsPropertyNames.RETRY_NE, SpinnerConfiguration.RETRY_NE);
    }

    @Test public void addListener() throws Exception {
        value.addListener(changeListener);
        assertThat(Arrays.stream(value.getChangeListeners()).anyMatch(n -> n.equals(changeListener)), is(true));
    }

    @Test
    public void testGetKey() {
        assertThat(value.getKey(), is(WellKnownGlobalSettingsPropertyNames.RETRY_NE));
    }

    @Test
    public void testContent() {
        assertThat(value.getContent(), is("0"));
    }
    
    @Test
    public void testRange() {
        final Integer min = (Integer)((SpinnerIntegerModel)value.getModel()).getMinimum();
        final Integer max = (Integer)((SpinnerIntegerModel)value.getModel()).getMaximum();
                
        assertThat(min, is(SpinnerConfiguration.RETRY_NE.getMinimumValue()));
        assertThat(max, is(SpinnerConfiguration.RETRY_NE.getMaximumValue()));
    }

    @Test
    public void testContent_changed() {
        value.setValue(2);

        assertThat(value.getContent(), is("2"));
        assertTrue(value.isValueModified());
    }

    @Test
    public void testToDefault() {
        value.setValue(2);
        value.toDefaultValue();

        assertThat(value.getContent(), is("0"));
    }
}
