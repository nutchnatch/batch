package com.ossnms.dcn_manager.bicnet.client.settings.configuration;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import static org.junit.Assert.assertThat;

public class StringConfigurationTest {

    @Test public void testDefaultContainerValue() {
        assertThat(StringConfiguration.DEFAULT_CONTAINER_NAME.getDefaultValue(),
                CoreMatchers.is("Default Ne Container"));
    }
}