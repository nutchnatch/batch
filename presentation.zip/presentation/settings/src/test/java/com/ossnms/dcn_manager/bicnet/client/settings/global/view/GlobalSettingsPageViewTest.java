package com.ossnms.dcn_manager.bicnet.client.settings.global.view;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.settings.global.document.GlobalSettingsDocument;
import com.ossnms.dcn_manager.bicnet.client.settings.view.values.PropertyValues;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.swing.JComponent;
import javax.swing.JPanel;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class) public class GlobalSettingsPageViewTest {

    @Mock private GlobalSettingsDocument document;
    @Mock private PropertyValues properties;
    @Mock private GlobalSettingsViewModel model;
    @Mock private JPanel mainPanel;
    @Mock private BiCNetPluginPropertyPageSite listener;
    @Mock private FrameworkPluginHelper frameworkPluginHelper;

    private GlobalSettingsPageView view;
    private Map<String, String> map;

    @Before public void setup() {
        map = new HashMap<>();
        when(document.getPluginHelper()).thenReturn(frameworkPluginHelper);
        when(frameworkPluginHelper.checkPermissions(any(String.class))).thenReturn(true);
        when(model.buildMainPanel()).thenReturn(mainPanel);
        when(properties.getChangedValues()).thenReturn(map);

        view = new GlobalSettingsPageView(document, properties, model);
    }

    @Test public void testConstructor() throws Exception {
        assertThat(new GlobalSettingsPageView(document), notNullValue());
    }

    @Test public void testActionApply() {
        view.actionApply();
        verify(document, times(1)).updateSettings(map);
    }

    @Test public void testEventOpened() {
        view.eventOpened();
        verify(document, times(1)).loadSettings();
    }

    @Test public void testGetComponent() {
        final JComponent component = view.getComponent();
        assertEquals(component, mainPanel);
    }

    @Test public void testGetID() {
        assertThat(GlobalSettingsPageView.class.getName(), CoreMatchers.is(view.getID()));
    }

    @Test public void testGetTitle() {
        assertThat("DCN Manager", CoreMatchers.is(view.getTitle()));
    }

    @Test public void testIsPageDirty() {
        when(properties.changed()).thenReturn(true);
        assertTrue(view.isPageDirty());
    }

    @Test public void testSetPageSite() {
        view.setPageSite(listener);
        verify(model, times(1)).setPluginListener(listener);
    }

    @Test public void testUpdateData() {
        when(model.getPluginListener()).thenReturn(Optional.empty());

        view.updateData(map);

        verify(properties, times(1)).setValues(map);
        verify(model, times(1)).getPluginListener();
    }

    @Test(expected = ClassCastException.class) public void testUpdateData_argumentInvalidType() {
        view.updateData(new Object());
    }

    @Test public void testReadOnly() throws Exception {
        view.setReadOnly(true);

        verify(document, atLeastOnce()).getPluginHelper();
    }

    @Test public void setObjects() {
        view.setObjects(null);
    }

    @Test public void update() {
        view.update();
    }

    @Test public void validateInput() throws Exception {
        view.validateInput();
    }

    @Test public void actionCancel() {
        view.actionCancel();
    }

    @Test public void eventClosing() {
        view.eventClosing();
    }
}
