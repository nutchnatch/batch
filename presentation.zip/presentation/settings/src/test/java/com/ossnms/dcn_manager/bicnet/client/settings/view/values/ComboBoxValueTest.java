package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.DiscoveryPolicesLoader;
import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.DiscoveryPolicy;
import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.awt.event.ItemListener;
import java.util.Arrays;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class) public class ComboBoxValueTest {
    @Mock private ItemListener itemListener;
    private ComboBoxValue value;

    @Before public void setup() {
        value = new ComboBoxValue(WellKnownGlobalSettingsPropertyNames.DISCOVERY_POLICY,
                new DiscoveryPolicesLoader().loadModel(), DiscoveryPolicy.NO_DISCOVERY.getName());
    }

    @Test public void addListener() throws Exception {
        value.addListener(itemListener);
        assertThat(Arrays.stream(value.getItemListeners()).anyMatch(n -> n.equals(itemListener)), is(true));
    }

    @Test public void testGetKey() {
        assertThat(value.getKey(), is(WellKnownGlobalSettingsPropertyNames.DISCOVERY_POLICY));
    }

    @Test public void testContent() {
        assertThat(value.getContent(), is(DiscoveryPolicy.NO_DISCOVERY.getName()));
    }

    @Test public void testContent_changed() {
        value.setSelectedItem(DiscoveryPolicy.DISCOVER_ALL_NETWORK.getName());

        assertThat(value.getContent(), is(DiscoveryPolicy.DISCOVER_ALL_NETWORK.getName()));
        assertTrue(value.isValueModified());
    }

    @Test public void testToDefault() {
        value.setSelectedItem(DiscoveryPolicy.NO_DISCOVERY.getName());
        value.toDefaultValue();

        assertThat(value.getContent(), is(DiscoveryPolicy.NO_DISCOVERY.getName()));
    }
}
