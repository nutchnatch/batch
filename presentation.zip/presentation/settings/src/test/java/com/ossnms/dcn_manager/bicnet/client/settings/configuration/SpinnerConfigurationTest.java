package com.ossnms.dcn_manager.bicnet.client.settings.configuration;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import static org.junit.Assert.assertThat;

public class SpinnerConfigurationTest {

    @Test
    public void testScaleStatupValues() {

        assertThat(SpinnerConfiguration.SCALED_STARTUP_LIMIT.getDefaultValue(), CoreMatchers.is(21));
        assertThat(SpinnerConfiguration.SCALED_STARTUP_LIMIT.getMinimumValue(), CoreMatchers.is(1));
        assertThat(SpinnerConfiguration.SCALED_STARTUP_LIMIT.getMaximumValue(), CoreMatchers.is(999));
    }
    
    @Test
    public void testRetryIntervalValues() {

        assertThat(SpinnerConfiguration.RETRY_INTERVAL.getDefaultValue(), CoreMatchers.is(1));
        assertThat(SpinnerConfiguration.RETRY_INTERVAL.getMinimumValue(), CoreMatchers.is(1));
        assertThat(SpinnerConfiguration.RETRY_INTERVAL.getMaximumValue(), CoreMatchers.is(20));
    }
    
    @Test
    public void testRetryMediatorValues() {

        assertThat(SpinnerConfiguration.RETRY_MEDIATOR.getDefaultValue(), CoreMatchers.is(0));
        assertThat(SpinnerConfiguration.RETRY_MEDIATOR.getMinimumValue(), CoreMatchers.is(0));
        assertThat(SpinnerConfiguration.RETRY_MEDIATOR.getMaximumValue(), CoreMatchers.is(999));
    }
    
    @Test
    public void testRetryNEValues() {

        assertThat(SpinnerConfiguration.RETRY_NE.getDefaultValue(), CoreMatchers.is(0));
        assertThat(SpinnerConfiguration.RETRY_NE.getMinimumValue(), CoreMatchers.is(0));
        assertThat(SpinnerConfiguration.RETRY_NE.getMaximumValue(), CoreMatchers.is(999));
    }
}
