package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.swing.event.DocumentListener;

import static com.ossnms.dcn_manager.bicnet.client.settings.configuration.StringConfiguration.DEFAULT_CONTAINER_NAME;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class StringValueTest {
    @Mock private DocumentListener documentListener;
    private StringValue value;

    @Before
    public void setup() {
        value = new StringValue(WellKnownGlobalSettingsPropertyNames.DEFAULT_CONTAINER_NAME, DEFAULT_CONTAINER_NAME);
    }

    @Test public void addListener() throws Exception {
        value.addListener(documentListener);
    }

    @Test
    public void testGetKey() {
        assertThat(value.getKey(), is(WellKnownGlobalSettingsPropertyNames.DEFAULT_CONTAINER_NAME));
    }

    @Test
    public void testContent() {
        assertThat(value.getContent(), is(DEFAULT_CONTAINER_NAME.getDefaultValue()));
    }

    @Test
    public void testContent_changed() {
        value.setText("newText");

        assertThat(value.getContent(), is("newText"));
        assertTrue(value.isValueModified());
    }

    @Test
    public void testToDefault() {
        value.setContent("newText");
        value.toDefaultValue();

        assertThat(value.getContent(), is(DEFAULT_CONTAINER_NAME.getDefaultValue()));
        assertThat(value.isValueModified(), is(true));
    }

    @Test
    public void testToDefault_no_changes() {
        value.setContent(DEFAULT_CONTAINER_NAME.getDefaultValue());
        value.toDefaultValue();

        assertThat(value.getContent(), is(DEFAULT_CONTAINER_NAME.getDefaultValue()));
        assertThat(value.isValueModified(), is(false));
    }
}