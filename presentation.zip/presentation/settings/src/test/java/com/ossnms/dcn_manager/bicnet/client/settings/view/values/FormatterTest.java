package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.ossnms.tools.jfx.JfxUtils;
import org.junit.Before;
import org.junit.Test;

import java.awt.GridBagConstraints;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class FormatterTest {
    private static final int ROW = 10;
    private Formatter formatter;

    @Before public void setUp() throws Exception {
        formatter = new Formatter();
    }

    @Test public void labelFormatter() throws Exception {
        final GridBagConstraints constraints = formatter.labelFormatter(ROW);
        assertThat(constraints.gridy, is(ROW));
    }

    @Test public void spinnerFormatter() throws Exception {
        final GridBagConstraints constraints = formatter.spinnerFormatter(ROW);
        assertThat(constraints.gridy, is(ROW));
    }

    @Test public void checkboxFormatter() throws Exception {
        final GridBagConstraints constraints = formatter.checkboxFormatter(ROW, true);
        assertThat(constraints.gridy, is(ROW));
        assertThat(constraints.insets.top, is(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS));
    }

    @Test public void comboboxFormatter() throws Exception {
        final GridBagConstraints constraints = (GridBagConstraints)formatter.comboboxFormatter(ROW);
        assertThat(constraints.gridy, is(ROW));
    }

    @Test public void defaultFormatter() throws Exception {
        final GridBagConstraints constraints = formatter.defaultFormatter(ROW);
        assertThat(constraints.gridy, is(ROW));
    }

    @Test public void defaultFormatter1() throws Exception {
        final GridBagConstraints constraints = formatter.defaultFormatter(ROW, 20);
        assertThat(constraints.gridy, is(ROW));
        assertThat(constraints.insets.top, is(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS));
        assertThat(constraints.insets.left, is(20));
    }

    @Test public void indentedPanelFormatter() throws Exception {
        final GridBagConstraints constraints = formatter.indentedPanelFormatter(ROW, 20);
        assertThat(constraints.gridy, is(ROW));
        assertThat(constraints.gridwidth, is(20));
    }

    @Test public void northwest() throws Exception {
        final GridBagConstraints constraints = formatter.northwest(ROW);
        assertThat(constraints.gridy, is(ROW));
    }

    @Test public void southwestFixSize() throws Exception {
        final GridBagConstraints constraints = formatter.southwestFixSize(ROW);
        assertThat(constraints.gridy, is(ROW));
    }
}