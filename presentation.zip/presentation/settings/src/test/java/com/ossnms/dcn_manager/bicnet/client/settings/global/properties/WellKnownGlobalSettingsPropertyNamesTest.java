package com.ossnms.dcn_manager.bicnet.client.settings.global.properties;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class WellKnownGlobalSettingsPropertyNamesTest {

    @Test
    public void testNames() {
        assertThat(WellKnownGlobalSettingsPropertyNames.RETRY_INTERVAL.getName(), CoreMatchers.is("TimeIntervalForScheduler"));
        assertThat(WellKnownGlobalSettingsPropertyNames.RETRY_MEDIATOR.getName(), CoreMatchers.is("RetryMediator"));
        assertThat(WellKnownGlobalSettingsPropertyNames.RETRY_NE.getName(), CoreMatchers.is("RetryNe"));

        assertThat(WellKnownGlobalSettingsPropertyNames.ENABLE_SCHEDULED_STARTUP.getName(), CoreMatchers.is("ActiveScheduleStartup"));
        assertThat(WellKnownGlobalSettingsPropertyNames.SCALED_STARTUP_LIMIT.getName(), CoreMatchers.is("GlobalScheduleStartup"));
      
        assertThat(WellKnownGlobalSettingsPropertyNames.DISCOVERY_POLICY.getName(), CoreMatchers.is("DiscoveryPolicy"));
        assertThat(WellKnownGlobalSettingsPropertyNames.ENABLE_NATIVE_NE_NAMING.getName(), CoreMatchers.is("NativeNeNaming"));
        assertThat(WellKnownGlobalSettingsPropertyNames.DEFAULT_CONTAINER_NAME.getName(), CoreMatchers.is("DefaultContainerName"));
    }
    
    @Test
    public void testToString() {
        assertNotNull(WellKnownGlobalSettingsPropertyNames.RETRY_INTERVAL.toString());
    }
}
