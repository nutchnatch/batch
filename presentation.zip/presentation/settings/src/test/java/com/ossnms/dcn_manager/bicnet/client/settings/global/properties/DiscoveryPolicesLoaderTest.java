package com.ossnms.dcn_manager.bicnet.client.settings.global.properties;

import com.ossnms.tools.jfx.components.JfxComboBox.ItemData;
import org.junit.Test;

import javax.swing.ComboBoxModel;
import java.util.ArrayList;
import java.util.Collection;

import static org.junit.Assert.assertTrue;

public class DiscoveryPolicesLoaderTest {

    @Test
    public void testLoadModel() {
        final DiscoveryPolicesLoader loader = new DiscoveryPolicesLoader();
        final ComboBoxModel<ItemData> model = loader.loadModel();
        
        final Collection<String> items = new ArrayList<>();
        
        for (int i = 0; i < model.getSize(); i++) {
            final ItemData item = model.getElementAt(i);
            items.add(item.getKey().toString());
        }
        
        for (final DiscoveryPolicy policy : DiscoveryPolicy.list()) {
            assertTrue(items.contains(policy.getName()));
        }
    }
}
