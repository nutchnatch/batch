package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.GlobalSettingsLabels;
import com.ossnms.tools.jfx.components.JfxLabel;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class RangeBuilderTest {

    private SpinnerIntegerModel spinnerModel;
    
    @Before
    public void setup() {
        spinnerModel = Mockito.mock(SpinnerIntegerModel.class);
        when(spinnerModel.getMinimum()).thenReturn(1);
        when(spinnerModel.getMaximum()).thenReturn(5);
    }
    
    @Test
    public void testBuild() {
        final JfxLabel label = new RangeBuilder().build(spinnerModel);
        
        assertThat(label.getText(), CoreMatchers.is("[1...5]"));
    }
    
    @Test
    public void testBuildWithUnit() {
        final String unit = GlobalSettingsLabels.UNIT.toString();
        final JfxLabel label = new RangeBuilder().buildWithUnit(unit, spinnerModel);
        
        assertThat(label.getText(), CoreMatchers.is("min [1...5]"));
    }    
}
