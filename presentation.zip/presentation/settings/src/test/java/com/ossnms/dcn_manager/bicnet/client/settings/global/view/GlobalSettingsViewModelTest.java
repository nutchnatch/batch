package com.ossnms.dcn_manager.bicnet.client.settings.global.view;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPage;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.dcn_manager.bicnet.client.settings.view.values.PropertyValues;
import org.junit.Before;
import org.junit.Test;

import static com.google.code.tempusfugit.temporal.Duration.seconds;
import static com.google.code.tempusfugit.temporal.Timeout.timeout;
import static com.google.code.tempusfugit.temporal.WaitFor.waitOrTimeout;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class GlobalSettingsViewModelTest {

    private PropertyValues propertyValues;
    private BiCNetPluginPropertyPage page;
    private BiCNetPluginPropertyPageSite listener;
    
    private GlobalSettingsViewModel model;
    
    @Before
    public void setup() {
        propertyValues = mock(PropertyValues.class);
        page = mock(BiCNetPluginPropertyPage.class);
        listener = mock(BiCNetPluginPropertyPageSite.class);
        
        model = new GlobalSettingsViewModel(propertyValues, page);
    }
    
    @Test
    public void testCreate() {
        assertNotNull(model);
    }
    
    @Test
    public void testSetPluginListener() {
        model.setPluginListener(listener);

        assertNotNull(model.getPluginListener());
        assertTrue(model.getPluginListener().isPresent());
    }
    
    @Test
    public void testSetPluginListener_invalid() {
        model.setPluginListener(null);
        
        assertNotNull(model.getPluginListener());
        assertFalse(model.getPluginListener().isPresent());
    }
        
    @Test
    public void TestBuildMainPanel() {
        assertNotNull(model.buildMainPanel());
    }
    
    @Test public void TestFireStateChanged() throws Exception {
        when(propertyValues.changed()).thenReturn(true);

        model.setPluginListener(listener);
        model.fireStateChanged();

        // waiting EDT process
        waitOrTimeout(() -> {
            try {
                verify(listener).eventPageStatusChanged(page);
            } catch (Error | Exception e) {
                return false;
            } return true;
        }, timeout(seconds(5)));

        verify(listener, times(1)).eventPageStatusChanged(page);
    }
}
