package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.ossnms.dcn_manager.bicnet.client.service.i18n.GlobalSettingsLabels;
import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class CheckBoxValueTest {
    @Mock private ItemListener itemListener;
    private CheckBoxValue value;

    @Before
    public void setup() {
        value = new CheckBoxValue(WellKnownGlobalSettingsPropertyNames.RETRY_NE, GlobalSettingsLabels.NE_RETRY, true);
    }

    @Test public void addListener() throws Exception {
        value.addListener(itemListener);
        assertThat(asList(value.getListeners(ItemListener.class)), containsInAnyOrder(itemListener));
    }

    @Test
    public void testGetKey() {
        assertThat(value.getKey(), CoreMatchers.is(WellKnownGlobalSettingsPropertyNames.RETRY_NE));
    }
    
    @Test
    public void testContent() {
        assertThat(value.getContent(), CoreMatchers.is(String.valueOf(true)));
    }
    
    @Test
    public void testContent_changed() {
        final Action action = new Action();
        
        value.addItemListener(action);        
        value.setSelected(false);
        
        assertThat(value.getContent(), CoreMatchers.is(String.valueOf(false)));
        assertTrue(value.isValueModified());
        assertTrue(action.isExecuted());
    }
    
    @Test
    public void testSetContent() {
        final Action action = new Action();
        
        value.addItemListener(action);        
        value.setContent("false");
        
        assertThat(value.getContent(), CoreMatchers.is(String.valueOf(false)));
        assertTrue(action.isExecuted());
    }

    @Test
    public void testToDefault() {
        value.setSelected(false);
        value.toDefaultValue();
        
        assertThat(value.getContent(), CoreMatchers.is(String.valueOf(true)));
    }
    
    private static class Action implements ItemListener {

        private boolean executed = false;
        
     
        boolean isExecuted() {
            return executed;
        }

        @Override
        public void itemStateChanged(ItemEvent e) {
            executed = true;
        }
    }
}
