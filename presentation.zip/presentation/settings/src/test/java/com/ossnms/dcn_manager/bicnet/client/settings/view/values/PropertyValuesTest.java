package com.ossnms.dcn_manager.bicnet.client.settings.view.values;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.Map;
import java.util.Optional;

import static com.google.code.tempusfugit.temporal.Duration.seconds;
import static com.google.code.tempusfugit.temporal.Timeout.timeout;
import static com.google.code.tempusfugit.temporal.WaitFor.waitOrTimeout;
import static com.ossnms.dcn_manager.bicnet.client.settings.global.properties.WellKnownGlobalSettingsPropertyNames.RETRY_CHANNEL;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class PropertyValuesTest {

    private final WellKnownGlobalSettingsPropertyNames key = WellKnownGlobalSettingsPropertyNames.RETRY_INTERVAL;
    private PropertyValues propertyValues;
    private Value value;

    @Before
    public void setup() {
        value = Mockito.mock(Value.class);

        propertyValues = new PropertyValues();
        propertyValues.add(value);

        when(value.getKey()).thenReturn(key);
    }

    @Test
    public void testAdd() {
        assertNotNull(propertyValues.getProperties().contains(value));
    }

    @Test
    public void testSetValues() throws Exception {
        propertyValues.setValues(ImmutableMap.of(key.getName(), "value"));

        // waiting EDT process
        waitOrTimeout(() -> {
            try {
                verify(value).setContent("value");
            } catch (Error | Exception e) {
                return false;
            } return true;
        }, timeout(seconds(5)));

        verify(value, times(1)).setContent("value");
    }

    @Test
    public void testFind() {
        final Optional<Value> optional = propertyValues.find(key.getName());

        assertTrue(optional.isPresent());
    }

    @Test
    public void testFind_absent() {
        final Optional<Value> optional = propertyValues.find("absent");

        assertFalse(optional.isPresent());
    }

    @Test
    public void testChanged() {
        when(value.isValueModified()).thenReturn(true);

        assertTrue(propertyValues.changed());

        verify(value, times(1)).isValueModified();
    }

    @Test public void testChangedValues() throws Exception {
        when(value.isValueModified()).thenReturn(true);
        when(value.getKey()).thenReturn(RETRY_CHANNEL);
        when(value.getContent()).thenReturn("21");


        final Map<String, String> changedValues = propertyValues.getChangedValues();
        assertThat(changedValues.get(RETRY_CHANNEL.getName()), is("21"));
    }

    @Test public void testChangedValues_noChanges() throws Exception {
        when(value.isValueModified()).thenReturn(false);
        when(value.getKey()).thenReturn(RETRY_CHANNEL);
        when(value.getContent()).thenReturn("21");


        final Map<String, String> changedValues = propertyValues.getChangedValues();
        assertThat(changedValues.size(), is(0));
    }

    @Test
    public void testChanged_false() {
        when(value.isValueModified()).thenReturn(false);

        assertFalse(propertyValues.changed());

        verify(value, times(1)).isValueModified();
    }

    @Test
    public void testToDefault() throws Exception {
        propertyValues.toDefaultValues();

        // waiting EDT process
        waitOrTimeout(() -> {
            try {
                verify(value).toDefaultValue();
            } catch (Error | Exception e) {
                return false;
            } return true;
        }, timeout(seconds(5)));

        verify(value, times(1)).toDefaultValue();
    }
}
