package com.ossnms.dcn_manager.bicnet.client.settings.global.document;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDataChangeListener;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ConfigurationRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static com.google.code.tempusfugit.temporal.Duration.seconds;
import static com.google.code.tempusfugit.temporal.Timeout.timeout;
import static com.google.code.tempusfugit.temporal.WaitFor.waitOrTimeout;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.only;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class SettingsDocumentTest {

    private ConfigurationRepository repository;
    private IFrameworkDataChangeListener listener;
    private IFrameworkJob job;
    private ISessionContext context;
    
    private GlobalSettingsDocument document;
    private final Map<String, String> values = new HashMap<>();
    
    @Before
    public void setup() {
        repository = mock(ConfigurationRepository.class);
        context = mock(ISessionContext.class);
        listener = mock(IFrameworkDataChangeListener.class);
        job = mock(IFrameworkJob.class);
        
        document = new GlobalSettingsDocument(DcnPluginHelperSingleton.getInstance(), repository);
        document.setDataChangeListener(listener);
        
        DcnPluginHelperSingleton.getInstance().setLogonContext(context);
    }
    
    @Test
    public void testSetResult() throws Exception {
        when(job.hasExceptionOccured()).thenReturn(false);

        document.setResult(job, values);

        // waiting EDT process
        waitOrTimeout(() -> {
            try {
                verify(listener).updateData(values);
            } catch (Error | Exception e) {
                return false;
            } return true;
        }, timeout(seconds(5)));

        verify(listener, only()).updateData(values);
    }
    
    @Test(expected=IllegalStateException.class)
    public void testSetResult_error() throws Exception {
        when(job.hasExceptionOccured()).thenReturn(true);

        document.setResult(job, values);
    }
    
    @Test(expected=UnsupportedOperationException.class)
    public void testGetObject() {
        when(job.hasExceptionOccured()).thenReturn(true);
        
        document.getObject(null);
    }
    
    @Test
    public void testUpdateSettings() throws RepositoryException {
        document.updateSettings(values);
        
        verify(repository, only()).updateGlobalSettings(context, values);
    }
}
