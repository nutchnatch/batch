package com.ossnms.dcn_manager.bicnet.client.settings.global.jobs;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ConfigurationRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.only;
import static org.mockito.Mockito.verify;

public class LoadGlobalSettingsFetchJobTest {
    
    private ConfigurationRepository repository;
    private IFrameworkDocument document;
    private ISessionContext context;
    
    @Before
    public void setup() {
        repository = mock(ConfigurationRepository.class);
        document = mock(IFrameworkDocument.class);
        context = mock(ISessionContext.class);
    }
    
    @Test
    public void testExecute() throws FrameworkException, RepositoryException {
        new LoadGlobalSettingsFetchJob(document, context, repository).execute(null);
        
        verify(repository, only()).getGlobalSettings(context);
    }
}
