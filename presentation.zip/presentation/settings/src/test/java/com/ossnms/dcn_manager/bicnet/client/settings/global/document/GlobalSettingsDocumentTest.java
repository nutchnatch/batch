package com.ossnms.dcn_manager.bicnet.client.settings.global.document;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ConfigurationRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class GlobalSettingsDocumentTest {

    @Mock private FrameworkPluginHelper helper;
    @Mock private ConfigurationRepository repository;
    @Mock private IFrameworkJob job;
    @Mock private ISessionContext sessionContext;

    private GlobalSettingsDocument document;

    @Before public void setUp() throws Exception {
        document = new GlobalSettingsDocument(helper, repository);
    }

    @Test
    public void setResult() throws Exception {
        when(job.hasExceptionOccured()).thenReturn(false);

        document.setResult(job, null);

        verify(job, atLeastOnce()).hasExceptionOccured();
        verify(job, never()).getException();
    }

    @Test(expected = IllegalStateException.class)
    public void setResult_error() throws Exception {
        when(job.hasExceptionOccured()).thenReturn(true);
        when(job.getException()).thenReturn(new Exception());

        document.setResult(job, null);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void getObject() throws Exception {
        document.getObject(null);
    }

    @Test public void loadSettings() throws Exception {

    }

    @Test public void updateSettings() throws Exception {
        when(helper.getLogonContext()).thenReturn(sessionContext);

        final HashMap<String, String> map = new HashMap<>();

        document.updateSettings(map);

        verify(repository, atLeastOnce()).updateGlobalSettings(sessionContext, map);
    }

    @Test public void updateSettings_error() throws Exception {
        when(helper.getLogonContext()).thenReturn(sessionContext);
        final HashMap<String, String> map = new HashMap<>();

        doThrow(new RepositoryException()).when(repository).updateGlobalSettings(sessionContext, map);
        document.updateSettings(map);
    }
}