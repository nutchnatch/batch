import { Router } from '@angular/router';
import { ModalExpiredSessionComponent } from 'app/modules/tsp-ui/modals/modal-expired-session/modal-expired-session.component';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { DocumentTypesAndTagsEffect } from './effects/document-types-and-tags.effects';
// import { DocumentTypesEffect } from './effects/document-types.effects';
import { Observable } from 'rxjs';
import { Component, ChangeDetectionStrategy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { HttpClientService } from './services/http-client.service';
import { LoggerService } from './services/logger/logger.service';
import { Error } from 'app/models/error';


import { Store, select } from '@ngrx/store';

import * as fromRoot from './reducers';
import * as layoutAction from './actions/layout.actions';
import * as businessScopeAction from './actions/business-scope.actions';
import * as httpErrorAction from 'app/actions/http-error.actions';


import { BusinessScopeEffect } from 'app/effects/business-scope.effect';
import { InfoEffect } from 'app/effects/application.effect';
import { UserDetails } from './models/user-details';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  currentLanguage$: Observable<string>;
  showSidenav$: Observable<boolean>;
  userDetailsScopeChosen$: Observable<boolean>;
  httpError$: Observable<Error>;
  userName$: Observable<string>;
  isSafEnable$: Observable<boolean>;
  userName: string;
  fullUserName$: Observable<string>;
  fullUserName: string;
  userDetailsLoaded$: Observable<UserDetails>;

  loadedError: boolean;
  safEnabledValue: boolean;

  modalExpiredSession;

  constructor(
    public http: HttpClientService<any>,
    public logger: LoggerService,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,
    public businessScopeEffect: BusinessScopeEffect,
    public infoEffect: InfoEffect,
    public store: Store<fromRoot.State>,
    public translate: TranslateService,
    protected router: Router,
    protected modalService: NgbModal,
  ) {
    /**
    * debug store uncoment line bellow
    */
    // store.subscribe( (state)=> console.log(state));

    // this language will be used as a fallback when a translation isn't found in the current language
    translate.setDefaultLang('en');

    /**
    * Selectors can be applied with the `select` operator which passes the state
    * tree to the provided selector
    */
    this.currentLanguage$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.currentLanguage$.subscribe((selectedLanguage) => { translate.use(selectedLanguage); });

    this.showSidenav$ = store.pipe(select(fromRoot.getShowSidenav));
    // this.showSidenav$.subscribe((open) => console.log(open))

    this.isSafEnable$ = store.pipe(select(fromRoot.getUserDetailIsSafEnabled));
    this.isSafEnable$.subscribe(saf => {
      this.safEnabledValue = saf;
    });

    this.userDetailsScopeChosen$ = store.pipe(select(fromRoot.getUserDetailsBusinessScopeChosen));
    this.userDetailsScopeChosen$.subscribe(detailsScopeChoosen => {
      if (detailsScopeChoosen ) {
        this.store.dispatch( new businessScopeAction.AllLoadedBusinessScope(false) );
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
        this.businessScopeEffect.getBusinessScope();
      }
    });


    this.fullUserName$ = store.pipe(select(fromRoot.getUserDetailsFullUserName));
    this.fullUserName$.subscribe((fullname) => this.fullUserName = fullname);


    this.userName$ = store.pipe(select(fromRoot.getUserDetailsUserName));
    this.userName$.subscribe((username) => this.userName = username);

    this.httpError$ = store.pipe(select(fromRoot.getHttpError));
    this.httpError$.subscribe(error => error && this.errorHandler(error));

    this.store.dispatch(new layoutAction.PutFromSearchAction(null));
    this.store.dispatch(new layoutAction.PutAdvanceSearch(false));

  }

  ngOnInit() {
    this.infoEffect.getApplicationConfigInfo();
  }

  protected errorHandler(error: Error) {
    this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(true));
    if (error.code === '401' || error.code === 401) {
      this.openExpiredModal();
    } else if (error.code === '403' || error.code === 403) {
      // TODO: SHOW A MODAL BOX WITH MISSING CORRECTS ROLES / AUTORIZATION
      //  alert('Missing Role!');
      if (this.safEnabledValue) {
          window.location.href = '/sugar-frontend-webapp/index.html';
      } else {
        this.openExpiredModal();
      }

      // this.onError403();
    } else if (error.code === '404' || error.code === 404) {
      // TODO: SHOW A MODAL WITH PAGE NOT FOUND
      alert('PAGE NOT FOUND');
      // this.onError404();
    } else if ( error.code === '302' || error.code === 302) {
      // alert('Aqui...trabalha');
      window.location.href   = '/sugar-frontend-webapp/index.html';

    }
  }

  getDismissReason(reason: any) {
    if (reason === ModalDismissReasons.ESC) {
      this.router.navigate(['app/user/logout']);
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      this.router.navigate(['app/user/logout']);
    }

    this.modalExpiredSession = undefined;
  }

  openExpiredModal() {

    if (!this.modalExpiredSession) {
      this.modalExpiredSession = this.modalService.open(ModalExpiredSessionComponent);
      this.modalExpiredSession.componentInstance.fullName = this.fullUserName;
      this.modalExpiredSession.componentInstance.username = this.userName;
    }

    this.modalExpiredSession.result.then(() => {
      this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
      this.modalExpiredSession = undefined;
    }, (reason) => {
      this.getDismissReason(reason);
      this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
    });
  }
}
