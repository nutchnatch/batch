import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';

import { find } from 'lodash';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[sugarPermissionRight]'
})
export class PermissionRightDirective {

  public userRoles$: Observable<Array<any>>;

  constructor(
    public templateRef: TemplateRef<any>,
    public viewContainer: ViewContainerRef,
    public store: Store<fromRoot.State>
  ) { }

  @Input() set sugarPermissionRight(keys: Array<string>) {
    this.userRoles$ = this.store.pipe(select(fromRoot.getUserDetailsAuthorities));
    this.userRoles$.subscribe(roles => {
      if (roles) {
        this.viewContainer.clear();
        const haveRoles = roles.filter((role) => find(keys ,  key => key === role ));
        if (haveRoles[0]) {
          this.viewContainer.createEmbeddedView(this.templateRef);
        }
      }
    });
  }
}
