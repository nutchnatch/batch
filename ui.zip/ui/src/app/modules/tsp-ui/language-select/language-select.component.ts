import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

/* store and store interface */
import { Store, select } from '@ngrx/store';
import * as fromRoot from 'app/reducers';

/* actions */
import * as language from 'app/actions/language.actions';

@Component({
  selector: 'app-language-select',
  templateUrl: './language-select.component.html',
  styleUrls: ['./language-select.component.scss']
})
export class LanguageSelectComponent {

  currentLanguage$: Observable<string>;
  localesList$: Observable<Array<string>>;

  public localList: Array<string>;

  constructor(
    public store: Store<fromRoot.State>
  ) {
    this.currentLanguage$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.localesList$ = store.pipe(select(fromRoot.getAppConfigLocaleList));
  }

  changeLang(lang: string) {
    this.store.dispatch(new language.ChangeLanguageAction(lang));
  }

}
