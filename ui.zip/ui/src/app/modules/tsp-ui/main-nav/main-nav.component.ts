import { ModalAboutComponent } from 'app/modules/sugar/modals/modal-about/modal-about.component';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { AuthenticationService } from 'app/services/authentication.service';
import { Router } from 'testing/router.stub';
import { Component, Input } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutAction from 'app/actions/layout.actions';

import * as searchPreviewActions from 'app/actions/search-preview.actions';


@Component({
  selector: 'app-main-nav',
  templateUrl: './main-nav.component.html',
  styleUrls: ['./main-nav.component.scss']
})
export class MainNavComponent implements OnDestroy {

  @Input() label;

  showSidenav$: Observable<boolean>;
  fullUserName$: Observable<string>;
  userLoaded$: Observable<boolean>;
  userCommercialVersion$: Observable<string>;
  userBusinessScopes$: Observable<string>;
  scope$: Observable<string>;
  authServiceSubscription: Subscription;

  isOpened = true;
  aboutModal;

  constructor(
    public store: Store<fromRoot.State>,
    public authenticationService: AuthenticationService,
    public router: Router,
    protected modalService: NgbModal
  ) {
    this.showSidenav$ = store.pipe(select(fromRoot.getShowSidenav));
    this.showSidenav$.subscribe((isOpened) => this.isOpened = isOpened);

    this.fullUserName$ = store.pipe(select(fromRoot.getUserDetailsFullUserName));
    this.userLoaded$ = store.pipe(select(fromRoot.getUserDetailsLoaded));

    this.scope$ = store.pipe(select(fromRoot.getUserDetailCurrentBusinessScope));

    this.userCommercialVersion$ = store.pipe(select(fromRoot.getUserDetailCommercialVersion));
    this.userBusinessScopes$ = store.pipe(select(fromRoot.getUserDetailBusinessScopes));
  }

  onClick() {
    this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
  }

  changeScope() {
    this.router.navigate(['/app/user/changeScope']);
  }

  openSideBarMenu() {
    // tslint:disable-next-line:max-line-length
    (this.isOpened) ? this.store.dispatch(new layoutAction.CloseSidenavAction()) : this.store.dispatch(new layoutAction.OpenSidenavAction());
  }

  openAbout() {

    if (!this.aboutModal) {
      this.aboutModal = this.modalService.open(ModalAboutComponent, {
        backdrop: 'static'
      });
    }

    this.aboutModal.result.then(() => {
      this.aboutModal = undefined;
    }, (reason) => {
      this.getDismissReason(reason);
    });
  }

  getDismissReason(reason: any) {
    if (reason === ModalDismissReasons.ESC) {
      this.aboutModal = undefined;
    }
  }

  ngOnDestroy() {
    if (this.authServiceSubscription) {
      this.authServiceSubscription.unsubscribe();
    }
    if (this.aboutModal) { this.aboutModal.close(); }
  }
}
