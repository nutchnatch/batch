import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Component, Input } from '@angular/core';
import * as fromRoot from 'app/reducers';

@Component({
  selector: 'app-main-content',
  templateUrl: './main-content.component.html',
  styleUrls: ['./main-content.component.scss']
})
export class MainContentComponent {
  hasPreviewResult$: Observable<any>;
  // showMetadataBar$: Observable<any>;

  @Input() sidebarOpened = false;
  @Input() sidebarPined = false;
  @Input() metadataOpened = false;

  constructor(
    public store: Store<fromRoot.State>,

  ) {
    // this.showMetadataBar$ =store.pipe(select(fromRoot.getMetadataBarShow);
    this.hasPreviewResult$ = store.pipe(select(fromRoot.getSearchPreviewHasResult));
   // this.hasPreviewResult$.subscribe(v=> console.log(v))
  }
}
