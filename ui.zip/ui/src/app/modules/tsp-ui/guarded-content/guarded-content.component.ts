import { Error } from 'app/models/error';
import { Component, Input } from '@angular/core';
import { Observable } from 'rxjs';

import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layout from 'app/actions/layout.actions';
import * as httpErrorAction from 'app/actions/http-error.actions';

@Component({
  selector: 'app-guarded-content',
  templateUrl: './guarded-content.component.html',
  styleUrls: ['./guarded-content.component.scss']
})
export class GuardedContentComponent {

  @Input() metadataComponent: boolean;

  public showSidenav$: Observable<boolean>;
  public sideBarPined$: Observable<boolean>;
  public showMetadataBar$: Observable<boolean>;
  public hasPreviewResult$: Observable<boolean>;

  public error$: Observable<Error>;

  constructor(
    public store: Store<fromRoot.State>,
  ) {
    this.showSidenav$ = store.pipe(select(fromRoot.getShowSidenav));
    this.sideBarPined$ = store.pipe(select(fromRoot.getSideBarPined));
    this.showMetadataBar$ = store.pipe(select(fromRoot.getMetadataBarShow));
    this.hasPreviewResult$ = store.pipe(select(fromRoot.getSearchPreviewHasResult));

    this.error$ = store.pipe(select(fromRoot.getHttpError));

    this.error$.subscribe(error => {
      if (error && error.message) {
        setTimeout( () => this.store.dispatch(new httpErrorAction.EraseHttpErrorAction()), 5000);
      } else {
        this.store.dispatch(new httpErrorAction.EraseHttpErrorAction());
      }
    });

  }
}
