import { Subscription } from 'rxjs';
import { Error } from 'app/models/error';
import { Title } from '@angular/platform-browser';
import { LoggerService } from 'app/services/logger/logger.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from 'app/services/authentication.service';

import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as userDetailsAction from 'app/actions/user-detail.actions';
import * as appConfigAction from 'app/actions/app-config.actions';

import { Credentials } from 'app/models/credentials';
import { UserDetails } from 'app/models/user-details';
import { Config } from 'app/models/config';


@Component({
  selector: 'app-login-ui',
  templateUrl: './login-ui.component.html',
  styleUrls: ['./login-ui.component.scss']
})
export class LoginUiComponent implements OnInit, OnDestroy {
  showWaring: boolean;

  loginForm: FormGroup;
  credentials: Credentials = { username: '', password: '' };

  formIsLoading$: Observable<boolean>;
  userDetailsLoaded$: Observable<boolean>;
  userDetailsScopeChosen$: Observable<boolean>;
  httpErrorStatusText$: Observable<Object>;
  fullUserName$: Observable<string>;
  config$: Observable<Config>;

  UserLoged = false;
  /**
   * Creates an instance of LoginUiComponent.
   * @param {AuthenticationService} authenticationService
   * @param {Store<fromRoot.State>} store
   * @param {Router} router
   * @param {LoggerService} logger
   *
   * @memberOf LoginUiComponent
   */
  constructor(
    public authenticationService: AuthenticationService,
    public store: Store<fromRoot.State>,
    public router: Router,
    public route: ActivatedRoute,
    public logger: LoggerService,
    public titleService: Title
  ) {

    this.formIsLoading$ = store.pipe(select(fromRoot.getUserDetailsIsLoading));
    this.httpErrorStatusText$ = store.pipe(select(fromRoot.getUserDetailHttpErrorDetails));
    this.userDetailsLoaded$ = store.pipe(select(fromRoot.getUserDetailsLoaded));
    this.userDetailsScopeChosen$ = store.pipe(select(fromRoot.getUserDetailsBusinessScopeChosen));
    this.fullUserName$ = store.pipe(select(fromRoot.getUserDetailsFullUserName));
    this.config$ = store.pipe(select(fromRoot.getApplicationConfig));


  }

  updateScope(scope: string) {
    this.titleService.setTitle('Sugar // Login - ' + scope);
    this.store.dispatch(new appConfigAction.PutScopeAction(scope));
  }

  initForm() {

    this.loginForm = new FormGroup({
      username: new FormControl(this.credentials.username, Validators.required),
      password: new FormControl(this.credentials.password, Validators.required)
    });
  }

  /**
   *
   *
   * @param {FormGroup} loginForm
   *
   * @memberOf LoginUiComponent
   */
  onSubmit(loginForm: FormGroup) {

    this.store.dispatch(new userDetailsAction.LoadingUserDetail());

    Object.assign(this.credentials, {
      username: loginForm.value.username,
      password: loginForm.value.password
    });

    if (loginForm.valid) {

      this.logger.debug('LoginUIComponent', 'Login with crendetials :', this.credentials);

      this.authenticationService.authenticate(this.credentials)
        .subscribe(
        (res: UserDetails) => {
          this.logger.debug('LoginUIComponent', 'Login Success :', res);
          this.store.dispatch(new userDetailsAction.PutUserDetail(res));
          this.router.navigate(['/app']);
        },
        (error: Error) => {
          this.logger.error('LoginUIComponent', 'Login failed ', error);
          this.store.dispatch(new userDetailsAction.PutHttpError(error));
        });

    }
  }

  ngOnInit() {
    if (this.route.snapshot.queryParams['scope']) {
      this.updateScope(this.route.snapshot.queryParams['scope']);
    }
    this.initForm();

    this.authenticationService.authenticate()
      .subscribe(
      (res: UserDetails) => {
        this.store.dispatch(new userDetailsAction.PutUserDetail(res));
        this.router.navigate(['/app']);

      },
      (error) => {
        this.router.navigate(['app/user/login']);
      });
  }

  ngOnDestroy() {
  }

}
