import { ScopeResolveService } from './../../services/scope-resolve.services';
import { AuthGuardService } from './../../services/auth-guard.services';
import { LoginChooseScopeComponent } from './login-choose-scope/login-choose-scope.component';
import { LoginUiComponent } from './login-ui/login-ui.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login.component';
import { LogoutUiComponent } from './logout-ui/logout-ui.component';


const routes: Routes = [
  {
    path: 'app/user', component: LoginComponent,
    children: [
      { path: 'user', redirectTo: 'app/login', pathMatch: 'full' },
      { path: 'login', component: LoginUiComponent },
      { path: 'logout', component: LogoutUiComponent },
      {
        path: 'chooseScope', component: LoginChooseScopeComponent,
        resolve: {
          userDetailsLoaded: ScopeResolveService
        },
        data: {
          ignoreScopeCheck: true
        },
        canActivate: [AuthGuardService]
      },
      {
        path: 'changeScope', component: LoginChooseScopeComponent,
        canActivate: [AuthGuardService]
      }
    ]
  }
];


/**
 * Login Modulos Routes
 *
 * Login Module Routes:
 *  - Login route - 'user/login'
 *  - Logout route - 'user/logout'
 *
 * @export
 * @class LoginRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoginRoutingModule { }
