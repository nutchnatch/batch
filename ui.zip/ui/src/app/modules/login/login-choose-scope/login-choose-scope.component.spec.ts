import { RouterStub } from 'app/testing/router.stub';
import { LoggerService } from 'app/services/logger/logger.service';
import { Router } from '@angular/router';
import { AuthenticationService } from 'app/services/authentication.service';
import { HttpModule } from '@angular/http';
import { TranslateModule } from '@ngx-translate/core';
import { StoreModule } from '@ngrx/store';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientService } from 'app/services/http-client.service';

import { LoginChooseScopeComponent } from './login-choose-scope.component';
import * as fromRoot from 'app/reducers';

describe('LoginChooseScopeComponent', () => {
  let component: LoginChooseScopeComponent;
  let fixture: ComponentFixture<LoginChooseScopeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginChooseScopeComponent],
      imports: [
        StoreModule.provideStore(fromRoot.reducers, fromRoot.State),
        TranslateModule.forRoot(),
        HttpModule
      ],
      providers: [
        AuthenticationService,
        HttpClientService,
        LoggerService,
        { provide: Router, useClass: RouterStub }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginChooseScopeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
