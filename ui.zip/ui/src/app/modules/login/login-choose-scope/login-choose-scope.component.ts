import { ScopeByUser } from './../../../states/client-settings.state';
import { find, findIndex } from 'lodash';
import { getClientSettingsScope } from './../../../reducers/client-settings.reducer';
import { getUserDetailsLoaded, getUserDetailsIsLoading, getUserDetailCurrentBusinessScope } from './../../../reducers/index';
import { Error } from 'app/models/error';
import { Title } from '@angular/platform-browser';
import { LoggerService } from 'app/services/logger/logger.service';
import { Router, ParamMap, ActivatedRoute, Params } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, of, throwError, Subscription } from 'rxjs';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from 'app/services/authentication.service';

import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as userDetailsAction from 'app/actions/user-detail.actions';
import * as appConfigAction from 'app/actions/app-config.actions';

import { Credentials } from 'app/models/credentials';
import { UserDetails } from 'app/models/user-details';
import { Config } from 'app/models/config';


@Component({
  selector: 'app-login-choose-scope',
  templateUrl: './login-choose-scope.component.html',
  styleUrls: ['./login-choose-scope.component.scss']
})
export class LoginChooseScopeComponent implements OnInit, OnDestroy {

  businessScopes$: Observable<string[]>;
  formIsLoading$: Observable<boolean>;
  authServiceSubscription: Subscription;
  currentScopeSubscription: Subscription;
  usernameSubscription: Subscription;
  defaultSubscription: Subscription;
  chooseScopeForm: FormGroup;
  scope: string;
  availableScopes: string[];
  loading = false;
  currentScope: string;
  originalSCope: string;
  default: boolean;
  username: string;

  constructor(
    public authenticationService: AuthenticationService,
    public store: Store<fromRoot.State>,
    public router: Router,
    public route: ActivatedRoute,
    public logger: LoggerService,
    public titleService: Title
  ) {

    this.businessScopes$ = store.pipe(select(fromRoot.getUserDetailBusinessScopes));

    this.usernameSubscription = store.pipe(select(fromRoot.getUserDetailsUserName)).subscribe((username: string) => {
      this.username = username;
    });

    this.currentScopeSubscription = store.pipe(select(fromRoot.getUserDetailCurrentBusinessScope)).subscribe((currentScope: string) => {
      if (currentScope) {
        this.currentScope = currentScope;
        this.originalSCope = currentScope;
      }
    });
    this.defaultSubscription = store.pipe(select(fromRoot.getAppConfigScope)).subscribe((defaultScopes: Array<ScopeByUser>) => {
      if (defaultScopes) {
        const userIndex = findIndex(defaultScopes, u => u.user === this.username);
        if (userIndex !== -1 && defaultScopes[userIndex].scope) {
          this.default = true;
        }
      }
    });
    this.formIsLoading$ = store.pipe(select(fromRoot.getUserDetailsIsLoading));
  }

  updateScope(chooseScopeForm: FormGroup) {
    if (chooseScopeForm.controls['scope'].value) {
      // tslint:disable-next-line:max-line-length
      const scopeByUser: ScopeByUser = new ScopeByUser();
      scopeByUser.scope = chooseScopeForm.controls['default'].value ? chooseScopeForm.controls['scope'].value : null;
      scopeByUser.user = this.username;
      this.store.dispatch(new appConfigAction.PutDefaultScopeAction(scopeByUser));
      this.setScopeAndRedirect(chooseScopeForm.controls['scope'].value);

    }
  }

  initForm() {
    this.titleService.setTitle('Sugar // Choose Scope');
    this.chooseScopeForm = new FormGroup({
      scope: new FormControl('', Validators.required),
      default: new FormControl(false)
    });
  }

  setScopeAndRedirect(scope: string) {
    if (!this.originalSCope || this.originalSCope !== scope) {
      this.store.dispatch(new userDetailsAction.LoadingUserDetail());
      // set to empty to provoke a store change so when setting the new scope, the types (doc, env, etc) will be reloaded
      this.store.dispatch(new userDetailsAction.ChangeBusinessScopeAction(null));
      this.authServiceSubscription = this.authenticationService.setUserBusinessScope(scope).subscribe(res => {
        if (res) {
          this.store.dispatch(new userDetailsAction.ChangeBusinessScopeAction(scope));
          this.store.dispatch(new appConfigAction.PutScopeAction(scope));
          this.router.navigate(['/app']);
        }
      });
      return;
    }
    this.router.navigate(['/app']);
  }

  ngOnInit() {
    this.initForm();
  }

  ngOnDestroy() {
    if (this.authServiceSubscription) {
      this.authServiceSubscription.unsubscribe();
    }
    if (this.currentScopeSubscription) {
      this.currentScopeSubscription.unsubscribe();
    }
    if (this.defaultSubscription) {
      this.defaultSubscription.unsubscribe();
    }
    if (this.usernameSubscription) {
      this.usernameSubscription.unsubscribe();
    }
  }

}
