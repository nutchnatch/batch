import { Title } from '@angular/platform-browser';
import { InitStore } from 'app/actions/shared.actions';
import { LoggerService } from 'app/services/logger/logger.service';
import { Router } from '@angular/router';
import { AuthenticationService } from 'app/services/authentication.service';
import { Component, OnInit, Inject } from '@angular/core';

import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as sharedAction from 'app/actions/shared.actions';
import * as userDetailsAction from 'app/actions/user-detail.actions';
import * as httpErrorAction from 'app/actions/http-error.actions';

import { DOCUMENT } from '@angular/platform-browser';

@Component({
  selector: 'app-logout-ui',
  templateUrl: './logout-ui.component.html',
  styleUrls: ['./logout-ui.component.scss']
})
export class LogoutUiComponent implements OnInit {

  /**
   * Creates an instance of LogoutComponent.
   * @param {AuthenticationService} authenticationService
   * @param {Router} router
   * @param {Store<fromRoot.State>} store
   *
   * @memberOf LogoutComponent
   */
  constructor(
    public authenticationService: AuthenticationService,
    public router: Router,
    public store: Store<fromRoot.State>,
    public logger: LoggerService,
    public titleService: Title,
    @Inject(DOCUMENT) private document: any
  ) { }

  ngOnInit() {
    this.titleService.setTitle( 'Sugar // Logout' );
    this.authenticationService.logout()
      .subscribe(
      (res) => {
        this.logger.debug('LogoutUiComponent', 'Logout Success');
        this.store.dispatch(new sharedAction.InitStore());
        this.router.navigate(['app/user/login']);
      },
      (error) => {
        this.store.dispatch(new sharedAction.InitStore());
        this.logger.error('LogoutUiComponent', 'Logout Failds');
        // this.store.dispatch(new userDetailsAction.PutHttpError(error));
        // alert(error.status + ' ' + error.statusError);
        if ( error && error.status === 500 || error && error.status === '500' ) {
          this.router.navigate(['app/user/login']);
        } else if ( error && error.status === 404 || error && error.status === '404') {
          this.document.location.href  = '/sugar-frontend-webapp/logout.html';
        }
      });
  }

}
