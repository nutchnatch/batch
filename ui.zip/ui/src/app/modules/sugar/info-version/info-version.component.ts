import { ModalAboutComponent } from './../modals/modal-about/modal-about.component';
import { Observable } from 'rxjs';
import { Component, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-info-version',
  templateUrl: './info-version.component.html',
  styleUrls: ['./info-version.component.scss']
})
export class InfoVersionComponent implements OnDestroy {
  public infoVersion$: Observable<string>;
  public aboutModal;

  constructor(
    store: Store<fromRoot.State>,
    protected modalService: NgbModal
  ) {
    this.infoVersion$ = store.pipe(select(fromRoot.getInfoCommercialVersion));
  }

  openAbout() {

    if (!this.aboutModal) {
      this.aboutModal = this.modalService.open(ModalAboutComponent, {
        backdrop: 'static'
      });
    }

    this.aboutModal.result.then(() => {
      this.aboutModal = undefined;
    }, (reason) => {
      this.getDismissReason(reason);
    });
  }

  getDismissReason(reason: any) {
    if (reason === ModalDismissReasons.ESC) {
      this.aboutModal = undefined;
    }
  }

  ngOnDestroy() {
    if (this.aboutModal) { this.aboutModal.close(); }
  }

}
