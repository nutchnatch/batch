import { EnvelopeEffect } from './../../../effects/envelope.effect';
import { Subscription } from 'rxjs';
import { Envelope } from './../../../models/envelope';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { DocumentEffect } from 'app/effects/document.effect';
import { DocumentLite } from './../../../models/document-lite';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';
import * as documentsActions from 'app/actions/documents.actions';
import { ModalAlertEnvelopeComponent } from 'app/modules/sugar/modals/modal-alert-envelope/modal-alert-envelope.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap/modal/modal';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap/modal/modal.module';

import { find } from 'lodash';

@Component({
  selector: 'app-envelope-files-list',
  templateUrl: './envelope-files-list.component.html',
  styleUrls: ['./envelope-files-list.component.scss']
})
export class EnvelopeFilesListComponent implements OnInit, OnDestroy {
  subscribeDocumentObject: Subscription;
  subscriberEnvelopeResult: Subscription;
  subscribeActiveRouteQueryParams: Subscription;
  subscribesListOfDocumentObjectSelected: Subscription;

  listOfDocument$: Observable<Array<string>>;
  listOfDocumentObject$: Observable<Array<DocumentLite>>;
  listOfDocumentObjectSelected$: Observable<Array<DocumentLite>>;
  selectedDocument$: Observable<string>;
  envelopeState$: Observable<Envelope>;
  filterOn$: Observable<any>;

  envelopeDeleteResult$: Observable<Array<string>>;
  envelopeDeleteLoading$: Observable<any>;
  envelopeDeleteError$: Observable<Error>;
  envelopeDeleteByIdError$: Observable<Error>;

  envelopeStateID: string;
  subscribesEnvelopeStateID: Subscription;

  listOfDocument: Array<any>;
  subscribesListOfDocument: Subscription;

  taskId: string;
  removedDocId: string;
  modalCreate;
  listSelected;

  constructor(
    public store: Store<fromRoot.State>,
    public documentEffect: DocumentEffect,
    public envelopeEffect: EnvelopeEffect,
    public router: Router,
    public activatedRouter: ActivatedRoute,
    protected modalService: NgbModal

  ) {

    this.envelopeState$ = store.pipe(select(fromRoot.getEnvelopeFirstResult));
    this.subscribesEnvelopeStateID = this.envelopeState$.subscribe(envelope => this.envelopeStateID = envelope && envelope['id']);

    this.listOfDocumentObjectSelected$ = store.pipe(select(fromRoot.getDocumentsFilterListSelected));
    // tslint:disable-next-line:max-line-length
    this.subscribesListOfDocumentObjectSelected = this.listOfDocumentObjectSelected$.subscribe(listSelected => this.listSelected = listSelected );

    this.listOfDocument$ = store.pipe(select(fromRoot.getEnvelopeListDocuments));
    this.subscribesListOfDocument = this.listOfDocument$.subscribe(list => list && this.initForm(list));

    this.listOfDocumentObject$ = store.pipe(select(fromRoot.getDocumentsFilterList));

    this.selectedDocument$ = store.pipe(select(fromRoot.getDocumentsFilterSelected));

    this.filterOn$ = store.pipe(select(fromRoot.getDocumentsFilterMultiple));
    this.envelopeDeleteByIdError$ = store.pipe(select(fromRoot.getEnvelopeDeleteError));

    this.envelopeDeleteError$ = store.pipe(select(fromRoot.getEnvelopeDeleteDocumentError));
    this.envelopeDeleteLoading$ = store.pipe(select(fromRoot.getEnvelopeDeleteDocumentLoading));
    this.envelopeDeleteResult$ = store.pipe(select(fromRoot.getEnvelopeDeleteDocumentResult));

    this.subscriberEnvelopeResult = this.envelopeDeleteResult$.subscribe(result => {
      // this.router.navigate(['/app/envelope', this.envelopeStateID ] );
      if (result) {
        if (this.listOfDocument.length > 1) {
          const docId = this.removedDocId === this.listOfDocument[0].id ? this.listOfDocument[1].id : this.listOfDocument[0].id;
          this.router.navigate(['app/refresh'], { queryParams: { url: '/app/envelope/' + this.envelopeStateID + '/' + docId } } );
        } else {
          this.router.navigate(['app/basket']);
        }
      }
    });
  }

  initForm(list) {
    this.listOfDocument = list.map(element => Object.assign({ ...element }, { selected: find(this.listSelected, { 'id': element.id})} ));

    this.store.dispatch(new documentsFilterAction.PutDocumentSelecedList(this.listOfDocument));
  }

  updateSelected(document) {
    this.store.dispatch(new documentsFilterAction.PutDocumentSelecedListById(document.id));
    this.store.dispatch(new documentsFilterAction.PutSelectedDocumentSelecedList(document.id));
  }

  documentSelect(document) {

    this.store.dispatch(new documentsFilterAction.PutDocumentSeleced(document.id));
    if (this.taskId) {
      this.router.navigate(['/app/envelope', this.envelopeStateID, document.id], { queryParams: { taskId: this.taskId } });
    } else {
      this.router.navigate(['/app/envelope', this.envelopeStateID, document.id]);
      this.store.dispatch(new documentsActions.InitUpdateDocument());
    }
  }

  removeFromEnvelope(docId: string) {
    this.removedDocId = docId;
    if (this.listOfDocument.length > 0) {
      this.envelopeEffect.deleteDocumentsFromEnvelope(this.envelopeStateID, docId);
    }
    // console.log(this.envelopeStateID , docId)
  }


  modalDeleteWarning(docId: string) {
    if (!this.modalCreate) {
      this.modalCreate = this.modalService.open(ModalAlertEnvelopeComponent, {
        backdrop: 'static'
      });
      // tslint:disable-next-line:max-line-length
      this.modalCreate.componentInstance.copy = 'ALERT_DELETE_DOCUMENT'; // 'Caution! This action is irreversible. Document will be deleted';

      this.modalCreate.result.then((result) => {

        if ( result === 'continue') {
          this.removeFromEnvelope(docId);
        }
        // this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
        this.modalCreate = undefined;
      }, (reason) => {
        this.getDismissReason(reason);
        // this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
      });
    }
  }

  getDismissReason(reason: any) {
    if (reason === ModalDismissReasons.ESC) {
      // this.store.dispatch(new envelopeActions.PutUnderConstructionStep2(false));
      this.modalCreate = undefined;
    }
  }


  ngOnInit() {
    this.subscribeActiveRouteQueryParams = this.activatedRouter.queryParamMap.subscribe((paramsMap: ParamMap | any) => {
      // this.currentBasketId = paramsMap.get('taskId');
      if (paramsMap.get('taskId')) {
        this.taskId = paramsMap.get('taskId');
      }
    });

  }

  ngOnDestroy() {

    if ( this.modalCreate ) { this.modalCreate.close(); }
    this.subscribesEnvelopeStateID.unsubscribe();
    this.subscribesListOfDocument.unsubscribe();
    this.subscriberEnvelopeResult.unsubscribe();
    this.subscribesListOfDocumentObjectSelected.unsubscribe();
    // this.store.dispatch(new enveloperAction.DeleteDocumentEnvelopeInit());

  }

}
