import { getUserDetailCurrentBusinessScope } from './../../../reducers/index';
import { TaskEffect } from 'app/effects/task.effect';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Observable, combineLatest } from 'rxjs';
import { BasketEffect } from './../../../effects/basket.effect';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { Basket } from 'app/models/basket';
import { Router, ActivatedRoute, ParamMap, RouterStateSnapshot } from '@angular/router';

import { find, findKey } from 'lodash';

import * as fromRoot from 'app/reducers';
import * as taksAction from 'app/actions/task.actions';
import * as appConfigAction from 'app/actions/app-config.actions';
import { BasketByScope } from 'app/states/client-settings.state';

@Component({
  selector: 'app-select-basket',
  templateUrl: './select-basket.component.html',
  styleUrls: ['./select-basket.component.scss']
})
export class SelectBasketComponent implements OnInit, OnDestroy {
  subscriberTransferSuccess: Subscription;
  subscribeActiveRouteQueryParams: Subscription;

  @Input() toChangeBasket: boolean;
  @Input() currentTaskId: string;
  // @Output() changeBasketType: EventEmitter<string> = new EventEmitter<string>();

  subscribeBasketResults: Subscription;
  subscriberPageSize: Subscription;

  public basketTypes$: Observable<Basket>;
  public basketMemorized$: Observable<string>;
  public basketMemorizedByScope$: Observable<any>;
  public scope$: Observable<string>;
  public currentLang$: Observable<string>;
  public pageSize$: Observable<number>;

  public transferingTask$: Observable<boolean>;
  public transferingError$: Observable<Error>;
  public transferingSuccess$: Observable<string>;

  public subscribeActiveRoute: Subscription;
  public subAllFork: Subscription;

  public routerSnapshot: RouterStateSnapshot;

  currentBasketId: string;
  pageSize: number;
  firstTaskId: string;
  selectedId: string;
  toChange: boolean;
  scope: string;

  constructor(
    public store: Store<fromRoot.State>,
    public basketEffect: BasketEffect,
    public taskEffect: TaskEffect,
    public router: Router,
    public activatedRouter: ActivatedRoute,
  ) {

    this.basketTypes$ = store.pipe(select(fromRoot.getBasketsResult));
    // tslint:disable-next-line:max-line-length
    // this.subscribeBasketResults = this.basketTypes$.subscribe( basketResult => {
    //   if (basketResult) {
    //     this.firstTaskId = basketResult[0].basketId;
    //   }
    // });
    this.scope$ = store.pipe(select(fromRoot.getUserDetailCurrentBusinessScope));
    this.basketMemorizedByScope$ = store.pipe(select(fromRoot.getAppConfigBasketByScope));

    const combined = combineLatest(
      this.scope$,
      this.basketMemorizedByScope$
    );

    this.subAllFork = combined.subscribe(([scope, memorizedScope]) => {
      if (scope !== null && scope !== '') {
        this.scope = scope;
      }
      if ( memorizedScope ) {
        const basketMemorizedArray: Array<BasketByScope> = memorizedScope;
        const selectedId = find(basketMemorizedArray, e => e.scope === this.scope);
        if (selectedId && selectedId.basketId) {
          this.selectedId = selectedId.basketId;
        }
      }
    });

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.pageSize$ = store.pipe(select(fromRoot.getAppConfigPageSize));
    this.subscriberPageSize = this.pageSize$.subscribe(value => this.pageSize = value);

    this.transferingTask$ = store.pipe(select(fromRoot.getTasksTransferLoading));
    this.transferingError$ = store.pipe(select(fromRoot.getTasksTransferError));

    this.transferingSuccess$ = store.pipe(select(fromRoot.getTasksTransferResult));
    this.subscriberTransferSuccess = this.transferingSuccess$.subscribe(result => {
      if (result) {
        this.store.dispatch(new taksAction.InitTransferTask());

        this.router.navigate(['app/refresh'], { queryParams: { url: this.router.routerState.snapshot.url } });
      }
    });

  }

  onSearch(basketId: string) {
    this.selectedId = basketId;
    const baseUrl = 'app/basket/' + basketId; // + searchQueryString.value.type.toLowerCase();
    this.store.dispatch(new appConfigAction.PutBasketAction(basketId));
    this.store.dispatch(new appConfigAction.PutBasketByScopeAction({ scope: this.scope, basketId: basketId }));

    if (!this.toChange) {
      this.router.navigate([baseUrl], { queryParams: Object.assign({}, { pageNumber: 1, pageSize: this.pageSize }) });
    }
  }

  onUpdate() {
    // console.log(this.selectedId)
    this.taskEffect.putTaskByIdTransfer(this.currentBasketId, this.selectedId);
    // this.changeBasketType.emit(this.selectedId);
  }


  ngOnInit() {

    this.store.dispatch(new taksAction.InitTransferTask());

    this.toChange = this.toChangeBasket;

    // this.basketEffect.getBaskets();
    this.subscribeActiveRoute = this.activatedRouter.paramMap.subscribe((paramsMap: ParamMap | any) => {
      if (!paramsMap.get('id')) {
        this.subscribeBasketResults = this.basketTypes$.subscribe(basketResult => {
          if (basketResult && basketResult[0]) {
            this.firstTaskId = this.selectedId ? this.selectedId : basketResult[0].basketId;
            const baseUrl = 'app/basket/' + this.firstTaskId; // + searchQueryString.value.type.toLowerCase();
            this.router.navigate([baseUrl], { queryParams: Object.assign({}, { pageNumber: 1, pageSize: this.pageSize }) });
          }
        });
      } else {
        this.selectedId = paramsMap.get('id');

      }
    });

    this.subscribeActiveRouteQueryParams = this.activatedRouter.queryParamMap.subscribe((paramsMap: ParamMap | any) => {
      if (paramsMap.get('taskId')) {
        this.currentBasketId = paramsMap.get('taskId');
        this.selectedId = this.currentTaskId;
      }
    });
  }



  ngOnDestroy() {
    this.subscribeActiveRoute.unsubscribe();
    if (this.subscribeBasketResults) { this.subscribeBasketResults.unsubscribe(); }
  }

}
