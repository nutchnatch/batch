import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectBasketComponent } from './select-basket.component';

describe('SelectBasketComponent', () => {
  let component: SelectBasketComponent;
  let fixture: ComponentFixture<SelectBasketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectBasketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectBasketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
