import { EnvelopeCreationResult } from './../../../models/envelope-creation-result';
import { EnvelopeEffect } from 'app/effects/envelope.effect';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Component, OnInit, Input, ViewChild } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as uploadDocumentsAction from 'app/actions/upload-documents.actions';
import { Router } from '@angular/router';

@Component({
  selector: 'app-upload-document-actions',
  templateUrl: './upload-document-actions.component.html',
  styleUrls: ['./upload-document-actions.component.scss']
})
export class UploadDocumentActionsComponent implements OnInit, OnDestroy {


  @Input() put: boolean;

  public uploadDocument$: Observable<Array<File>>;
  public error$: Observable<Error>;
  public isUpLoading$: Observable<boolean>;
  public result$: Observable<Array<EnvelopeCreationResult>>;

  public currentEnvelope$: Observable<any>;

  subsribeDocument: Subscription;
  subsribeResults: Subscription;
  subscribeCurrentEnvelope: Subscription;

  uploadDocument;
  formData: FormData;
  currentEnvelopeID: string;

  constructor(
    public store: Store<fromRoot.State>,
    public envelopeEffect: EnvelopeEffect,
    public router: Router

  ) {
    this.uploadDocument$ = store.pipe(select(fromRoot.getUploadDocumentsList));

    this.subsribeDocument = this.uploadDocument$.subscribe((files) => this.uploadDocument = files);

    this.error$ = store.pipe(select(fromRoot.getUploadDocumentsError));
    this.isUpLoading$ = store.pipe(select(fromRoot.getUploadDocumentsLoading));

    this.result$ = store.pipe(select(fromRoot.getUploadDocumentsResult));

    this.subsribeResults = this.result$.subscribe( result => {
      if ( result && result.length > 0 ) {
        // , result[0]['documentIdList'][0]
        this.router.navigate(['app/envelope', result[0].envelopeId, result[0].documentIdList[0] ]);
      }

      if ( result && result.length > 0 && this.put ) {

        // tslint:disable-next-line:max-line-length
        this.router.navigate(['app/refresh'], { queryParams: { url: 'app/envelope/' + result[0].envelopeId + '/' + result[0]['documentIdList'][0] } });
      }
      // this.router.navigate(['/envelope', d]);
    });

  }

  removeAll() {
    this.store.dispatch(new uploadDocumentsAction.InitDocumentList());
  }

  upload() {
    if ( !this.put && !this.subscribeCurrentEnvelope ) {
      this.envelopeEffect.postEnvelopes(this.formDataFormarter());
    } else {
      this.envelopeEffect.postEnvelopesDocuments(this.currentEnvelopeID, this.formDataFormarter());
    }

  }

  formDataFormarter(): FormData {
    this.formData = new FormData();
    this.uploadDocument.map((file, i) => { this.formData.append('fileList', file, file.name); });
    return this.formData;
  }

  ngOnInit() {
    // console.log('......', this.put);
    if ( this.put ) {
      this.currentEnvelope$ = this.store.pipe(select(fromRoot.getEnvelopeFirstResult));
      this.subscribeCurrentEnvelope = this.currentEnvelope$.subscribe( currentEnvelope => this.currentEnvelopeID = currentEnvelope.id );
    }
   }

  ngOnDestroy() {
    this.subsribeDocument.unsubscribe();
    this.subsribeResults.unsubscribe();
    if ( this.put && this.subscribeCurrentEnvelope) { this.subscribeCurrentEnvelope.unsubscribe(); }
  }

}
