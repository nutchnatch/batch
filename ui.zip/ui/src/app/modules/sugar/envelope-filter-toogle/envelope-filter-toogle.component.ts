import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Component } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';

@Component({
  selector: 'app-envelope-filter-toogle',
  templateUrl: './envelope-filter-toogle.component.html',
  styleUrls: ['./envelope-filter-toogle.component.scss']
})
export class EnvelopeFilterToogleComponent {

  selectedCount$: Observable<any>;
  filterOn$: Observable<boolean>;

  constructor(
    public store: Store<fromRoot.State>,
  ) {
    this.selectedCount$ = store.pipe(select(fromRoot.getDocumentsFilterListSelectedCount));
    this.filterOn$ = store.pipe(select(fromRoot.getDocumentsFilterMultiple));
   }

  onChange(e) {
    this.store.dispatch( new documentsFilterAction.PutDocumentSelecedMultiple(e));
  }
}
