import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Component, OnInit, ViewChild } from '@angular/core';
import { UploadFile, UploadEvent, FileSystemFileEntry } from 'ngx-file-drop';

import * as fromRoot from 'app/reducers';
import * as uploadDocumentsAction from 'app/actions/upload-documents.actions';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
  selector: 'app-file-drop',
  templateUrl: './file-drop.component.html',
  styleUrls: ['./file-drop.component.scss']
})
export class FileDropComponent implements OnInit, OnDestroy {

  public uploadDocument$: Observable<Array<File>>;
  public isUpLoading$: Observable<boolean>;

  public files: UploadFile[] = [];
  formData: FormData = new FormData();
  @ViewChild('fileInput') fileInput;

  constructor(
    public store: Store<fromRoot.State>) {

    this.uploadDocument$ = store.pipe(select(fromRoot.getUploadDocumentsList));
    this.isUpLoading$ = store.pipe(select(fromRoot.getUploadDocumentsLoading));
    this.uploadDocument$.subscribe(file => {
      if (file && file.length === 0 && this.fileInput) {
        this.fileInput.nativeElement.value = '';
      }
    });
  }

  public dropped(event: UploadEvent) {
    const files = event.files;
    for (const droppedFile of files) {
      if (droppedFile.fileEntry.isFile) {
        const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
        fileEntry.file(fileInfo => {
          this.store.dispatch(new uploadDocumentsAction.PutDocumentList([fileInfo]));

        });
      }
    }
  }

  public fileOver(event) {  /*console.log(event);*/ }

  public fileLeave(event) {  /*console.log(event); */ }

  fileChange(event) {
    const files = event.target.files;
    if (files.length > 0) {
      for (const fileInfo of files) {
        this.store.dispatch(new uploadDocumentsAction.PutDocumentList(fileInfo));
      }
    }
    this.fileInput.nativeElement.value = '';
  }

  removeThis(name: string) {
    this.store.dispatch(new uploadDocumentsAction.RemoveDocumentListByName(name));
  }

  ngOnInit() {

  }

  ngOnDestroy() {
    this.store.dispatch(new uploadDocumentsAction.InitDocumentList());
  }

}
