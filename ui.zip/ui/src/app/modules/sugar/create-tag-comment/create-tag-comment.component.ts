import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { ModalCreateTagCommentComponent } from 'app/modules/sugar/modals/modal-create-tag-comment/modal-create-tag-comment.component';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';

@Component({
  selector: 'app-create-tag-comment',
  templateUrl: './create-tag-comment.component.html',
  styleUrls: ['./create-tag-comment.component.scss']
})
export class CreateTagCommentComponent implements OnInit, OnDestroy {

  modalCreate;

  @Input() model;

  constructor(
    public store: Store<fromRoot.State>,
    protected modalService: NgbModal
  ) { }

  openModal() {

    if (!this.modalCreate) {
      this.modalCreate = this.modalService.open(ModalCreateTagCommentComponent, {
        backdrop: 'static',
        size: 'lg'
      });

      this.modalCreate.componentInstance.model = this.model;
    }

    this.modalCreate.result.then(() => {
      this.modalCreate = undefined;
    }, (reason) => {
      this.getDismissReason(reason);
    });

  }

  getDismissReason(reason: any) {

    if (reason === ModalDismissReasons.ESC) {
      this.modalCreate = undefined;
    }
  }

  ngOnInit() {

  }

  ngOnDestroy() {
    if (this.modalCreate) { this.modalCreate.close(); }
  }
}
