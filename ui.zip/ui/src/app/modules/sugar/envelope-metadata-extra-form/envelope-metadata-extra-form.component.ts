import { Envelope } from 'app/models/envelope';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Observable, combineLatest } from 'rxjs';
import { Component, OnInit, Input, OnDestroy, EventEmitter, Output } from '@angular/core';
import { ExtraFields } from 'app/states/extra-fields.state'; // Model

import { find } from 'lodash';


import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

import * as fromRoot from 'app/reducers';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { DateParserFormaterServices } from 'app/services/date-parser-formater/date-parser-formater.service';


@Component({
  selector: 'app-envelope-metadata-extra-form',
  templateUrl: './envelope-metadata-extra-form.component.html',
  styleUrls: ['./envelope-metadata-extra-form.component.scss']
})
export class EnvelopeMetadataExtraFormComponent implements OnInit, OnDestroy {

  @Input() extraMetadataForm: FormGroup;
  @Input() preview: boolean;
  @Output() envTypeIdSelected = new EventEmitter();

  // extraMetadataForm: FormGroup;
  currentLang$: Observable<string>;
  envelopeTypes$: Observable<Array<ExtraFields>>;
  currentEnvelope$: Observable<Envelope>;
  allDataLoaded$: Observable<boolean>;

  subEnvelopeTypes: Subscription;
  subCurrentEnvelope: Subscription;

  envTypeId;
  currentEnvelope;
  envelopeTypes;
  metadataFormSubscrition;
  dpValues: Array<any> = [];

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public dateToUCT: DateParserFormaterServices,
    public dateParserFormatter: NgbDateParserFormatter

  ) {

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));


    this.envelopeTypes$ = store.pipe(select(fromRoot.getExtraFieldsEnvelopeMetadataFields));
    this.subEnvelopeTypes = this.envelopeTypes$.subscribe(envelopeTypes => this.envelopeTypes = envelopeTypes);

  }

  initExtraMetadaFormCurrentDoc() {
    if (this.extraMetadataForm) { this.removeControls(this.extraMetadataForm); this.dpValues = []; }

    const envTags: any = find(this.envelopeTypes, { id: this.envTypeId });

    envTags.inputsFields.map((tag) => {
      const validators = tag.mandatory && tag.type === 'string' ? [Validators.pattern(new RegExp(tag.pattern))] : [];
      let value = '';

      const envTag: any = find(this.currentEnvelope.tagList, (t) => t.tagName === tag.name);

      if (envTag) {
        if (tag.type === 'timestamp' && envTag.tagName === tag.name) {
          this.dpValues[tag.name] = this.dateParserFormatter.parse(envTag.tagValue);
        }

        value = envTag.tagName === tag.name ? envTag.tagValue : '';
      }
      this.extraMetadataForm.addControl(tag.name, new FormControl(value, validators));
    });

  }

  updateToModel(inputName, newValue) {
    // this.dpValues[inputName] = this.dateToUCT.ngbDatepickerUTCDate(newValue);
    // inputName = this.dateToUCT.ngbDatepickerUTCDate(newValue);
    this.extraMetadataForm.controls[inputName].setValue(this.dateToUCT.ngbDatepickerUTCDate(newValue));
    // fc.setValue = this.dateToUCT.ngbDatepickerUTCDate(newValue);
  }

  initExtraMetadaForm() {
    this.removeControls(this.extraMetadataForm);
    this.envelopeTypes.map(envType => {
      if (envType.id === this.envTypeId) {
        for (let i = 0; i < envType.inputsFields.length; i++) {
          // tslint:disable-next-line:max-line-length
          const validators = envType.inputsFields[i].mandatory ? [Validators.pattern(new RegExp(envType.inputsFields[i].pattern))] : [];
          this.extraMetadataForm.addControl(
            envType.inputsFields[i].name,
            new FormControl('', Validators.compose(validators)));
          // new FormControl('', envType.inputsFields[i].mandatory && Validators.required) );
        }
      }
    });
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).forEach(fc => this.extraMetadataForm.removeControl(fc));
  }

  onChange(envTypeId) {
    const envType = find(this.envelopeTypes, { id: envTypeId });
    // var song = _.find(songs, {id:id});
    // console.log(envType.id)
    if (this.currentEnvelope.envTypeId === envType.id) {
      this.initExtraMetadaFormCurrentDoc();
    } else {
      this.initExtraMetadaForm();
    }

    this.envTypeIdSelected.emit(envType);
  }


  ngOnInit() {

    this.currentEnvelope$ = !this.preview ?
      this.store.pipe(select(fromRoot.getEnvelopeFirstResult)) :
      this.store.pipe(select(fromRoot.getSearchPreviewResults));

    this.allDataLoaded$ = this.store.select(fromRoot.getBusinessScopeAllLoaded);

    const combinedObst$: Observable<any> = combineLatest(this.currentEnvelope$, this.allDataLoaded$);

    this.subCurrentEnvelope = combinedObst$.subscribe( ([currentEnvelope, allDataLoaded ])  => {
      if (currentEnvelope && allDataLoaded ) {

        const env = currentEnvelope;

        const envType: any = find(this.envelopeTypes, { id: env.envTypeId });

        this.envTypeId = env.envTypeId;
        this.currentEnvelope = env;
        // if ( env.validity === 'UNDER_CONSTRUCTION' || env.validity === 'INVALID' ) {
        if (env.validity === 'UNDER_CONSTRUCTION') {
          this.initExtraMetadaForm();
        } else {
          this.initExtraMetadaFormCurrentDoc();
        }
        // tslint:disable-next-line:max-line-length
        this.envTypeIdSelected.emit({ id: this.envTypeId, version: envType && envType.version !== env.envTypeVersion ? envType.version : env.envTypeVersion });

      }
    });
  }

  ngOnDestroy() {
    this.subCurrentEnvelope.unsubscribe();
    this.subEnvelopeTypes.unsubscribe();
  }

}
