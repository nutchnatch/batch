import { BasketEffect } from 'app/effects/basket.effect';
import { BusinessScopeEffect } from 'app/effects/business-scope.effect';
import { BusinessScope } from 'app/models/business-scope';
import { DocumentTypeEffect } from 'app/effects/document-types.effects';
import { EnvelopeTypeEffect } from 'app/effects/envelope-types.effects';
import { DocumentTypes } from 'app/models/document-types';
import { Acl } from 'app/models/acl';
import { Observable } from 'rxjs';
import { Component, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { FormBuilder } from '@angular/forms';

import { EnvelopeTypes } from 'app/models/envelope-types';
import { FolderTypes } from 'app/models/folder-types';
import { FolderTypeEffect } from 'app/effects/folder-types.effects';
import { Basket } from 'app/models/basket';
import { find } from 'lodash';

import * as fromRoot from 'app/reducers';
import * as aclManagementAction from 'app/actions/acl-management.actions';

@Component({
  selector: 'app-form-acl-management',
  templateUrl: './form-acl-management.component.html',
  styleUrls: ['./form-acl-management.component.scss']
})
export class FormAclManagementComponent implements OnDestroy {

  public listAcl$: Observable<Array<Acl>>;
  public docType$: Observable<Array<DocumentTypes>>;
  public envType$: Observable<Array<EnvelopeTypes>>;
  public folderType$: Observable<Array<FolderTypes>>;
  public bussinessScope$: Observable<BusinessScope>;

  public typeIdUpdating$: Observable<string>;
  public typeUpdating$: Observable<boolean>;
  public typeError$: Observable<Error>;
  public typeSuccess$: Observable<any>;
  public basketClass$: Observable<Array<Basket>>;

  listAcl: Array<Acl>;

  filter = {
    bussinessScope: true,
    documents: true,
    envelopes: true,
    folder: true,
    baskets: true
  };

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public envelopeTypeEffect: EnvelopeTypeEffect,
    public documentTypeEffect: DocumentTypeEffect,
    public folderTypeEffect: FolderTypeEffect,
    public bussinessScopeEffect: BusinessScopeEffect,
    public basketEffect: BasketEffect

  ) {
    this.listAcl$ = store.pipe(select(fromRoot.getAclResult));

    this.listAcl$.subscribe( list => this.listAcl = list);

    this.docType$ = store.pipe(select(fromRoot.getDocumentTypesResultNoFilter));
    this.envType$ = store.pipe(select(fromRoot.getEnvelopeTypesResultNoFilter));
    this.folderType$ = store.pipe(select(fromRoot.getFolderTypesResultNoFilter));
    this.basketClass$ = store.pipe(select(fromRoot.getBasketsResult));
    this.bussinessScope$ = store.pipe(select(fromRoot.getBusinessScopeFirstResult));

    // this.basketClass$.subscribe(v => console.log(v))

    this.typeIdUpdating$ = store.pipe(select(fromRoot.getAclManagementUpdatingId));
    this.typeError$ = store.pipe(select(fromRoot.getAclManagementUpdatingError));
    this.typeSuccess$ = store.pipe(select(fromRoot.getAclManagementUpdatingResult));
    this.typeUpdating$ = store.pipe(select(fromRoot.getAclManagementUpdatingLoading));
  }

  onChange(domain: string, typeId: string, aclId: string, typeVersion: number, instance: string) {
    // console.log(domain, typeId, aclId, typeVersion, instance)

    const acl = Object.assign({}, {
      aclId: aclId,
      isInstanceValue: instance,
      name: find(this.listAcl, (aclObj: Acl) => aclObj.aclId === aclId ).name
    });

    switch (domain) {
      case 'bs':
        this.bussinessScopeEffect.putBusinessScopeAcl(typeId, acl);
        break;
      case 'envelope':
        this.envelopeTypeEffect.putEnvelopeTypesAcl(typeId, typeVersion, acl);
        break;
      case 'document':
        this.documentTypeEffect.putDocumentTypesAcl(typeId, typeVersion, acl);
        break;
      case 'folder':
        this.folderTypeEffect.putFolderTypesAcl(typeId, typeVersion, acl);
        break;
      case 'basket':
        this.basketEffect.putBasketsAcl(typeId, acl);
        break;

    }

  }

  ngOnDestroy() {
    this.store.dispatch(new aclManagementAction.PutInitUpdateAclManagementAction());
  }

}
