import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';


import * as fromRoot from 'app/reducers';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';

@Component({
  selector: 'app-under-construction-envelope-results',
  templateUrl: './under-construction-envelope-results.component.html',
  styleUrls: ['./under-construction-envelope-results.component.scss']
})
export class UnderConstructionEnvelopeResultsComponent implements OnInit {

  public searching$: Observable<boolean>;
  public error$: Observable<any>;
  // public searchType$: Observable<string>;
  public searchResult$: Observable<any>;

  constructor(
    public store: Store<fromRoot.State>,
  ) {
    this.searching$ = store.pipe(select(fromRoot.getSearchPagedLoading));
    this.searchResult$ = store.pipe(select(fromRoot.getSearchPagedResults));

    this.error$ = store.pipe(select(fromRoot.getSearchPagedError));

  }

  ngOnInit() {
  }

}
