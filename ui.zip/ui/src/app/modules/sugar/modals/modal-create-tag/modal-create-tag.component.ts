import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Subscription } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { Tag } from 'app/models/tag';
import { Observable } from 'rxjs';
import { BusinessScope } from 'app/models/business-scope';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import { TagsEffect } from 'app/effects/tags.effect';
import { DocumentTypesAndTagsEffect } from 'app/effects/document-types-and-tags.effects';


@Component({
  selector: 'app-modal-create-tag',
  templateUrl: './modal-create-tag.component.html',
  styleUrls: ['./modal-create-tag.component.scss']
})
export class ModalCreateTagComponent implements OnInit, OnDestroy {

  public dataForm: FormGroup;
  public businessScopeResult$: Observable<BusinessScope>;
  public tagTypes$: Observable<Array<any>>;

  public searchResultCreating$: Observable<boolean>;
  public searchResultCreateError$: Observable<Error>;
  public searchResultCreateSuccess$: Observable<Tag>;

  public subscriberBusinessScopeResult: Subscription;
  public subscriberCreateSuccess: Subscription;

  public faChoiseList: FormArray;
  langOnScope: Array<string>;

  constructor(
    public store: Store<fromRoot.State>,
    public activeModal: NgbActiveModal,
    public formBuilder: FormBuilder,
    public tagEffect: TagsEffect,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,

  ) {
    this.initForm();

    this.tagTypes$ = store.pipe(select(fromRoot.getAppConfigTagType));

    this.businessScopeResult$ = store.pipe(select(fromRoot.getBusinessScopeFirstResult));
    this.subscriberBusinessScopeResult = this.businessScopeResult$.subscribe(businessScope => {
      if (businessScope) {
        // this.langDataFrom = this.formBuilder.group({});
        this.langOnScope = businessScope.languages;

        this.displayNameItemFormData();

      }
    });

    this.searchResultCreating$ = store.pipe(select(fromRoot.getTagsCreating));
    this.searchResultCreateError$ = store.pipe(select(fromRoot.getTagsCreateError));

    this.searchResultCreateSuccess$ = store.pipe(select(fromRoot.getTagsCreateSuccess));

    this.subscriberCreateSuccess = this.searchResultCreateSuccess$.subscribe(result => {
      if (result) {
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
        this.dataForm.reset();
        this.initForm();
        this.displayNameItemFormData();
      }
    });
  }

  initForm() {
    const tag = {
      choicelist: null,
      displayNameItem: null,
      name: '',
      type: '',
      pattern: '',
      isSearchable: true
    };

    this.dataForm = this.formBuilder.group(Object.assign({}, tag ));

    this.dataForm.setControl('choicelist', new FormArray([]));
    this.dataForm.setControl('diplayNameItem', new FormArray([]));
    this.dataForm.controls['name'].setValidators(Validators.required);
    this.dataForm.controls['type'].setValue('string');

    this.faChoiseList = <FormArray>this.dataForm.controls['choicelist'];

  }

  displayNameItemFormData() {
    const faDisplayNameValues: FormArray = <FormArray>this.dataForm.controls['diplayNameItem'];
    this.pushValuesFormGroup(faDisplayNameValues);
  }

  onTypeChange(type) {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    if (!this.faChoiseList.valid ) { this.removeRow(0); }
    if (type === 'choicelist' ) { this.addRow(); }
  }

  removeRow(index: number) {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    this.faChoiseList.removeAt(index);
  }

  addRow() {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    this.faChoiseList.push(new FormGroup({
      // symbolicName: new FormControl(''),
      symbolicName: new FormControl('', Validators.required),
      displayNameValues: new FormArray([])
    }));

    // tslint:disable-next-line:max-line-length
    const faDisplayNameValues: FormArray = <FormArray>this.faChoiseList.controls[this.faChoiseList.controls.length - 1]['controls']['displayNameValues'];
    this.pushValuesFormGroup(faDisplayNameValues);
  }

  pushValuesFormGroup(faDisplayNameValues) {
    this.langOnScope.forEach(lang => {
      faDisplayNameValues.push(new FormGroup({
        language: new FormControl(lang, Validators.required),
        // tslint:disable-next-line:max-line-length
        value: new FormControl('', Validators.required)
      }));
    });
  }

  save(dataForm) {
    // console.log(dataForm)
    this.tagEffect.postTags(dataForm);
  }


  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscriberBusinessScopeResult.unsubscribe();
    this.subscriberCreateSuccess.unsubscribe();
  }

}
