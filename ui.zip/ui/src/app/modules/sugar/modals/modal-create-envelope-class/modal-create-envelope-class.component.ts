import { PutEnvelopeTypesCreatingInit } from './../../../../actions/envelope-types.actions';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Subscription } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { BusinessScope } from 'app/models/business-scope';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import { TagsEffect } from 'app/effects/tags.effect';
import { DocumentTypesAndTagsEffect } from 'app/effects/document-types-and-tags.effects';
import { EnvelopeTypes } from 'app/models/envelope-types';
import { Tag } from 'app/models/tag';
import { EnvelopeTypeEffect } from '../../../../effects/envelope-types.effects';


@Component({
  selector: 'app-modal-create-envelope-class',
  templateUrl: './modal-create-envelope-class.component.html',
  styleUrls: ['./modal-create-envelope-class.component.scss']
})
export class ModalCreateEnvelopeClassComponent implements OnInit, OnDestroy {

  public dataForm: FormGroup;
  public businessScopeResult$: Observable<BusinessScope>;
  public tags$: Observable<Tag>;
  // public searchResult$: Observable<EnvelopeTypes>;
  public envelopeTypesCreating$: Observable<boolean>;
  public envelopeTypesCreatingError$: Observable<Error>;
  public envelopeTypesCreatingSuccess$: Observable<EnvelopeTypes>;

  public subscriberBusinessScopeResult: Subscription;
  public subscriberCreateSuccess: Subscription;

  public faTagList: FormArray;
  langOnScope: Array<string>;
  currentEnvelopeType;
  public selectedTags: any = {};
  oldValue: Array<any> = new Array();

  constructor(
    public store: Store<fromRoot.State>,
    public activeModal: NgbActiveModal,
    public formBuilder: FormBuilder,
    public envelopeTypeEffect: EnvelopeTypeEffect,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,

  ) {

    this.tags$ = store.pipe(select(fromRoot.getTagsResult));

    this.initForm();

    this.businessScopeResult$ = store.pipe(select(fromRoot.getBusinessScopeFirstResult));
    this.subscriberBusinessScopeResult = this.businessScopeResult$.subscribe(businessScope => {
      if (businessScope) {
        // this.langDataFrom = this.formBuilder.group({});
        this.langOnScope = businessScope.languages;
        this.displayNameItemFormData();
      }
    });

    this.envelopeTypesCreating$ = store.pipe(select(fromRoot.getEnvelopeTypesCreating));
    this.envelopeTypesCreatingError$ = store.pipe(select(fromRoot.getEnvelopeTypesCreatingError));
    this.envelopeTypesCreatingSuccess$ = store.pipe(select(fromRoot.getEnvelopeTypesCreatingResult));

    this.subscriberCreateSuccess = this.envelopeTypesCreatingSuccess$.subscribe(result => {
      if (result) {
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
        this.dataForm.reset();
        this.initForm();
        this.displayNameItemFormData();
      }
    });

    store.dispatch(new PutEnvelopeTypesCreatingInit);
  }

  initForm() {

    const envType = {
      name: '',
      firstLevel: true,
      active: false,
      displayNameList: null,
      tagList: null,
      allowedChildren: null,
      version: 0,
      id: ''
    };

    this.currentEnvelopeType = envType;

    this.dataForm = this.formBuilder.group(Object.assign({}, envType));

    this.dataForm.setControl('allowedChildren', new FormArray([]));
    this.dataForm.setControl('displayNameList', new FormArray([]));
    this.dataForm.setControl('tagList', new FormArray([]));

    this.dataForm.controls['name'].setValidators(Validators.required);
    this.faTagList = <FormArray>this.dataForm.controls['tagList'];
    this.selectedTags = {};
    this.oldValue = new Array();
  }

   tagSelected(selectedTag: string, index: number) {
    this.selectedTags[selectedTag] = true;
    if (this.oldValue && this.oldValue[index]) {
      this.selectedTags[this.oldValue[index]] = false;
    }
    this.oldValue[index] = selectedTag;
  }

  displayNameItemFormData() {
    const faDisplayNameValues: FormArray = <FormArray>this.dataForm.controls['displayNameList'];

    this.langOnScope.forEach(lang => {
      faDisplayNameValues.push(new FormGroup({
        language: new FormControl(lang, Validators.required),
        value: new FormControl('', Validators.required)
      }));
    });
  }

  removeRow(index: number) {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    this.selectedTags[this.faTagList.at(index)['controls']['symbolicName'].value] = false;
    this.oldValue.splice(index, 1);
    this.faTagList.removeAt(index);
  }

  addRow() {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    this.faTagList.push(new FormGroup({
      mandatory: new FormControl(false),
      symbolicName: new FormControl('', Validators.required),
      multivalued: new FormControl(false)
    }));
  }

  save(dataForm) {
    // console.log(dataForm)
    this.envelopeTypeEffect.postEnvelopeTypes(dataForm);
    // this.tagEffect.postTags(dataForm);
  }

  ngOnInit() {}

  ngOnDestroy() {
    this.subscriberBusinessScopeResult.unsubscribe();
    this.subscriberCreateSuccess.unsubscribe();
  }

}
