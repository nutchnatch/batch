import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, Input } from '@angular/core';
import { Store, select} from '@ngrx/store';
import * as fromRoot from 'app/reducers';
import { Observable } from 'rxjs/internal/Observable';

@Component({
  selector: 'app-modal-about',
  templateUrl: './modal-about.component.html',
  styleUrls: ['./modal-about.component.scss']
})
export class ModalAboutComponent {

  userCommercialVersion$: Observable<string>;
  userTechnicalVersion$: Observable<string>;

  @Input() continueLabel = 'Ok';

  modalWarning;

  constructor(
    public store: Store<fromRoot.State>,
    public activeModal: NgbActiveModal
  ) {
    this.userCommercialVersion$ = store.pipe(select(fromRoot.getUserDetailCommercialVersion));
    this.userTechnicalVersion$ = store.pipe(select(fromRoot.getInfoVersion));
  }

}
