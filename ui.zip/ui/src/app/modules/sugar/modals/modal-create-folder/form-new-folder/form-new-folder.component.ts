import { DocumentAttachedToFoldersResult } from 'app/models/document-attached-to-folder-result';
import { Subscription } from 'rxjs';
import { FolderCreationResult } from 'app/models/folder-creation-result';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { FolderEffect } from 'app/effects/folder.effect';
import { Folder } from 'app/models/folder';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';

import * as FolderState from 'app/states/folder.state';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import * as fromRoot from 'app/reducers';
import * as folderAction from 'app/actions/folder.actions';


export class State extends FolderState.State { }

// this.documentEffect.getDocumentsById(docid);
@Component({
  selector: 'app-form-new-folder',
  templateUrl: './form-new-folder.component.html',
  styleUrls: ['./form-new-folder.component.scss']
})
export class FormNewFolderComponent implements OnInit, OnDestroy {

  @Input() docList;

  errorUploading$: Observable<{}>;

  uploading$: Observable<boolean>;
  subscribeActiveRoute: Subscription;
  subscriptionResult: Subscription;

  public metadataForm: FormGroup;
  public extraMetadataForm: FormGroup;
  public creatingFolderCreating$: Observable<boolean>;
  public creatingFolderError$: Observable<Error>;
  public creatingFolderResult$: Observable<FolderCreationResult>;
  public attachSuccess$: Observable<DocumentAttachedToFoldersResult>;

  folderModal: Folder = FolderState.initialStateFolder;
  selectedFolderType: any;
  extraMetadataFormIsEmpty: boolean;

  public folderId: string;

  public currentDocumentId$: Observable<string>;
  public currentDocumentId: string;
  public subscriptionDocumentId: Subscription;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public activeModal: NgbActiveModal,
    public folderEffect: FolderEffect,

  ) {
    this.selectedFolderType = null;


    this.extraMetadataForm = this.formBuilder.group({});

    this.metadataForm = formBuilder.group(this.folderModal);

    this.creatingFolderCreating$ = store.pipe(select(fromRoot.getFolderCreateCreating));
    this.creatingFolderError$ = store.pipe(select(fromRoot.getFolderCreateError));
    this.creatingFolderResult$ = store.pipe(select(fromRoot.getFolderCreateResult));

    this.subscriptionResult = this.creatingFolderResult$.subscribe(result => {
      if (result) {
        this.folderId = result.folderId;
        this.attachFolder();
      }
    });

    this.currentDocumentId$ = store.pipe(select(fromRoot.getSearchPreviewResultId));
    this.subscriptionDocumentId = this.currentDocumentId$.subscribe(currentDocumentId => {
      if (currentDocumentId) { this.currentDocumentId = currentDocumentId; }
    });

    this.errorUploading$ = store.pipe(select(fromRoot.getFolderUpdateError));
    this.uploading$ = store.pipe(select(fromRoot.getSearchFolderToAttachUploading));
    this.attachSuccess$ = store.pipe(select(fromRoot.getSearchFolderToAttachSuccess));

  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).forEach(fc => this.extraMetadataForm.removeControl(fc));
  }

  updateDocTypeId(folderTypeId) {
    this.selectedFolderType = folderTypeId;
  }

  cancel() {
    // this.store.dispatch(new folderActions.InitUpdateFolder());
    this.store.dispatch(new folderAction.InitCreateFolder());
    this.activeModal.close();
  }

  attachFolder() {
    // console.log('attach', this.currentDocumentId);
    if (this.currentDocumentId && this.folderId && !this.docList) {
      this.folderEffect.postFolderDocuments(this.folderId, [this.currentDocumentId]);
    }
    if ( this.docList && this.folderId) {
      const docListId = this.docList.map( list => list.id);
      this.folderEffect.postFolderDocuments(this.folderId, docListId);
    }
  }

  save(metadataForm, extraMetadataForm) {
    // console.log(this.metadataForm, this.extraMetadataForm);

    const formModel = Object.assign({}, metadataForm, {
      tagList: Object.keys(extraMetadataForm).map(function (key) {
        // return { 'tagName': extraMetadataForm[key], 'tagValue': key };
        return { 'tagValue': extraMetadataForm[key], 'tagName': key };

      }),
      folderTypeId: this.selectedFolderType.id,
      folderTypeVersion: this.selectedFolderType.version
      // folderTypeId: this.selectedFolderType
    });

    // this.folderEffect.putFolderById(formModel.id, formModel); not this


    this.folderEffect.postFolders(formModel);
  }

  ngOnInit() {
    this.removeControls(this.extraMetadataForm);
    // this.subscribeActiveRoute = this.activatedRouter.children[0]..paramsMap.subscribe((params: Params) => {
    //   // this.currentDocumentId = params.get('docid');
    //   console.log('.....', params)
    // });
  }

  ngOnDestroy() {
    this.subscriptionResult.unsubscribe();
    this.subscriptionDocumentId.unsubscribe();
    this.metadataForm.reset();
    this.extraMetadataForm.reset();
    this.store.dispatch(new folderAction.InitCreateFolder());

  }

}
