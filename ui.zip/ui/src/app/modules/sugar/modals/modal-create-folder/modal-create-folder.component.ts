import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-modal-create-folder',
  templateUrl: './modal-create-folder.component.html',
  styleUrls: ['./modal-create-folder.component.scss']
})
export class ModalCreateFolderComponent implements OnInit {
  @Input() docList;

  constructor(

  ) { }

  ngOnInit() {
  }

}
