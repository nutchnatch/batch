import { Paging } from './../../../../../models/paging';
import { FolderEffect } from 'app/effects/folder.effect';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Observable } from 'rxjs';
import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as advanceSearchActions from 'app/actions/advance-search.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as searchFolderToAttachActions from 'app/actions/search-folder-to-attach.actions';


import { filter } from 'lodash';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-search-on-modal',
  templateUrl: './search-on-modal.component.html',
  styleUrls: ['./search-on-modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SearchOnModalComponent implements OnInit, OnDestroy {

  pageSize$: Observable<number>;
  currentLang$: Observable<string>;
  advanceQueryResult$: Observable<string>;
  formGroup$: Observable<any>;
  extraFields$: Observable<any>;

  subscriberPageSize: Subscription;
  subscriberFormGroup: Subscription;
  subscriberExtraFields: Subscription;
  searchQuery$: Observable<any>;
  subscriberSearchQuery: Subscription;

  paging$: Observable<Paging>;
  page: number;
  subscriberPaging: Subscription;
  advanceCriteriaQuery: any = null;
  subscriberAdvanceQuery: Subscription;

  searchQueryString: FormGroup;

  pageSize: number;
  searchQuery: any;
  loaded = false;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router,
    public folderEffect: FolderEffect,
    public dateParserFormatter: NgbDateParserFormatter

  ) {

    this.store.dispatch(new advanceSearchActions.PutDomain('Folders'));
    // this.store.dispatch(new advanceSearchActions.RemoveAllAdvanceSearchModal());

    this.extraFields$ = store.pipe(select(fromRoot.getExtraFields));
    this.subscriberExtraFields = this.extraFields$.subscribe(extraFields => {
      // this.extraFields = extraFields;

      this.store.dispatch(new advanceSearchActions.PutDomainSelected(extraFields['folderMetadataFields']));
      this.store.dispatch(new advanceSearchActions.PutTagsList(extraFields['folderMetadataFields']));
      // this.store.dispatch(new advanceSearchActions.PutAdvanceSearch(new AdvanceQuery));

    });

    this.pageSize$ = this.store.pipe(select(fromRoot.getAppConfigPageSize));
    this.subscriberPageSize = this.pageSize$.subscribe(value => this.pageSize = value);

    this.paging$ = store.pipe(select(fromRoot.getSearchPagedPaging));
    this.subscriberPaging = this.paging$.subscribe(page => { if (page) { this.page = page.currentPage; }});

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));

    this.searchQuery$ = this.store.pipe(select(fromRoot.getSearchPagedQuery));
    this.subscriberSearchQuery = this.searchQuery$.subscribe(query => {

      if (query) {
        this.searchQuery = Object.assign({},
          query, { statusCode: 'equals_to|OPEN' }
        );
        this.getFolder(this.searchQuery);
      }
      // console.log(this.searchQuery)
    });

    this.advanceQueryResult$ = store.pipe(select(fromRoot.getAdvanceSearchQueryModal));

    this.subscriberAdvanceQuery = this.advanceQueryResult$.subscribe( advanceCriteriaQuery =>  {
      if ( advanceCriteriaQuery  ) {
        this.advanceCriteriaQuery = advanceCriteriaQuery;
      }
    });
    // this.advanceQuery$.subscribe(v => c)
  }

  initForm() {

    this.searchQueryString = new FormGroup({
      type: new FormControl('Folders', Validators.required),
    });
    this.searchQueryString.addControl('advanceSearchQuery', new FormArray([]));
    // tslint:disable-next-line:max-line-length
    //  this.store.dispatch(new advanceSearchActions.PutAdvanceSearchModal({ tagName: null, operator: null, type: null, value: null, defaultTag: false }));

  }

  onSearch(searchQueryString: FormGroup) {
    this.store.dispatch(new searchFolderToAttachActions.PutSearchFolderIdToAttach('') );
    const query = Object.assign({},
      this.toQueryParams(searchQueryString.value['advanceSearchQuery']),
      { pageNumber: this.page, pageSize: this.pageSize }
    );
    this.store.dispatch(new searchPagedAction.PutSearchResultsQuery(query));
  }

  getFolder(params) {
    // console.log('-------', params)
    this.folderEffect.getFolders(params, true);
  }

  toQueryParams(formValues): any {

    let paramsObj;
    const tagArray = [];

    filter(formValues, tag => tag['defaultTag'])
      .forEach(tag => {
        const value = tag['type'] === 'timestamp' ? this.dateParserFormatter.format(tag['value']) : tag['value'] === '' ? '' : tag['value'];
        paramsObj = Object.assign({}, paramsObj, { [tag['tagName']]: tag['operator'] + '|' + value });
      });

    filter(formValues, (tag) => !tag['defaultTag'])
      .forEach(tag => {
        // const b = a.concat(tag.tagName + '|' + tag.type + '|' + tag.operator + '|' + tag.value);
        const value = tag.type === 'timestamp' ? this.dateParserFormatter.format(tag.value) : tag.value;
        tagArray.push(tag.tagName + '|' + tag.type + '|' + tag.operator + '|' + value);
        paramsObj = Object.assign({}, paramsObj, { tags: tagArray });
      });

    return paramsObj;
  }

  ngOnInit() {
    this.initForm();

    // this.getFolder({name: 'contains| ', pageNumber: 1, pageSize: this.pageSize});
    // this.store.dispatch(new searchPagedAction.PutSearchResultsQuery( { name: 'contains| ', pageNumber: 1, pageSize: this.pageSize } ));
  }

  ngOnDestroy() {
    this.subscriberPageSize.unsubscribe();
    this.subscriberSearchQuery.unsubscribe();
    this.subscriberPaging.unsubscribe();
    this.subscriberExtraFields.unsubscribe();

  }



}
