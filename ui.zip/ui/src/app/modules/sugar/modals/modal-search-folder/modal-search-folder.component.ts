import { Observable } from 'rxjs';
import { Component, OnInit, Input } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as searchFolderToAttachActions from 'app/actions/search-folder-to-attach.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';

@Component({
  selector: 'app-modal-search-folder',
  templateUrl: './modal-search-folder.component.html',
  styleUrls: ['./modal-search-folder.component.scss']
})
export class ModalSearchFolderComponent implements OnInit {

  @Input() docList;

  public docList$: Observable<boolean>;

  constructor(
    public store: Store<fromRoot.State>,
  ) {
  }

  ngOnInit() {
  }

}
