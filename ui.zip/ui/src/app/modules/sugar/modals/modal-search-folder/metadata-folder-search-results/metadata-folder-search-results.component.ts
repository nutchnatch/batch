import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs';
import { Subscription } from 'rxjs';
import { FolderEffect } from 'app/effects/folder.effect';
import { Store, select } from '@ngrx/store';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as searchFolderToAttachActions from 'app/actions/search-folder-to-attach.actions';
import * as folderActions from 'app/actions/folder.actions';


@Component({
  selector: 'app-metadata-folder-search-results',
  templateUrl: './metadata-folder-search-results.component.html',
  styleUrls: ['./metadata-folder-search-results.component.scss']
})
export class MetadataFolderSearchResultsComponent implements OnInit, OnDestroy {
  @Input() docList;

  subscriberCurrentDocumentId: Subscription;
  currentDocumentId$: Observable<string>;
  currentDocumentId: string;

  public uploading$: Observable<boolean>;

  public searching$: Observable<boolean>;
  public error$: Observable<any>;
  public errorAttach$: Observable<Error>;

  // public searchType$: Observable<string>;
  public searchResult$: Observable<any>;
  public folderToAttach$: Observable<any>;
  public docList$: Observable<boolean>;

  public subscribeFolderToAttach: Subscription;
  // public subscribeActiveRoute: Subscription;
  // public subscribeActiveRouteData: Subscription;
  folderId;

  constructor(
    public store: Store<fromRoot.State>,
    public folderEffect: FolderEffect,
    public activeModal: NgbActiveModal
  ) {

    this.docList$ = this.store.pipe(select(fromRoot.getSearchFolderToAttachDocList));

    this.currentDocumentId$ = store.pipe(select(fromRoot.getSearchPreviewResultId));
    this.subscriberCurrentDocumentId = this.currentDocumentId$.subscribe(currentDocumentId => this.currentDocumentId = currentDocumentId);

    this.uploading$ = store.pipe(select(fromRoot.getSearchFolderToAttachUploading));

    this.searching$ = store.pipe(select(fromRoot.getSearchPagedLoading));
    this.searchResult$ = store.pipe(select(fromRoot.getSearchPagedResults));

    this.error$ = store.pipe(select(fromRoot.getSearchPagedError));
    this.errorAttach$ = store.pipe(select(fromRoot.getFolderUpdateError));

    this.folderToAttach$ = store.pipe(select(fromRoot.getSearchFolderToAttachResultId));
    this.subscribeFolderToAttach = this.folderToAttach$.subscribe( folderId => this.folderId = folderId );
    // this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview());
  }

  attachFolder() {
    // console.log('attach', this.folderId);
    if (this.currentDocumentId && this.folderId && !this.docList) {
      this.folderEffect.postFolderDocuments(this.folderId, [this.currentDocumentId]);
    }

    if ( this.docList && this.folderId) {
      const docListId = this.docList.map( list => list.id);
      this.folderEffect.postFolderDocuments(this.folderId, docListId);
    }
  }

  close() {
    this.store.dispatch(new folderActions.InitUpdateFolder());
    this.store.dispatch(new searchFolderToAttachActions.InitSearchFolderToAttach());
    this.activeModal.close();
  }

  ngOnInit() {  }

  ngOnDestroy() {
    this.subscriberCurrentDocumentId.unsubscribe();
    this.subscribeFolderToAttach.unsubscribe();
  }

}
