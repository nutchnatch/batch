import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-modal-alert-envelope',
  templateUrl: './modal-alert-envelope.component.html',
  styleUrls: ['./modal-alert-envelope.component.scss']
})
export class ModalAlertEnvelopeComponent implements OnInit {

  @Input() copy = 'ALERT_DELETE_ENVELOPE';
  @Input() cancelLabel = 'Cancel';
  @Input() continueLabel = 'Continue';

  modalWarning;

  constructor(
    public activeModal: NgbActiveModal
  ) {  }

  ngOnInit() {
  }

}
