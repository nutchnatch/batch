import { PutDocumentTypesCreatingInit } from './../../../../actions/document-types.actions';
import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { BusinessScope } from 'app/models/business-scope';
import { Store, select } from '@ngrx/store';
import { TagsEffect } from 'app/effects/tags.effect';
import { DocumentTypesAndTagsEffect } from 'app/effects/document-types-and-tags.effects';
import { EnvelopeTypes } from 'app/models/envelope-types';
import { Tag } from 'app/models/tag';
import { DocumentTypes } from 'app/models/document-types';
import { DocumentTypeEffect } from 'app/effects/document-types.effects';

import * as fromRoot from 'app/reducers';


@Component({
  selector: 'app-modal-create-document-class',
  templateUrl: './modal-create-document-class.component.html',
  styleUrls: ['./modal-create-document-class.component.scss']
})
export class ModalCreateDocumentClassComponent implements OnInit, OnDestroy {

  public dataForm: FormGroup;
  public businessScopeResult$: Observable<BusinessScope>;
  public tags$: Observable<Tag>;
  // public searchResult$: Observable<EnvelopeTypes>;
  public documentTypesCreating$: Observable<boolean>;
  public documentTypesCreatingError$: Observable<Error>;
  public documentTypesCreatingSuccess$: Observable<DocumentTypes>;

  public retentionDurationValues$: Observable<Array<any>>;

  public subscriberBusinessScopeResult: Subscription;
  public subscriberCreateSuccess: Subscription;

  public faTagList: FormArray;
  langOnScope: Array<string>;
  currentDocumentType;
  public selectedTags: any = {};
  oldValue: Array<any> = new Array();

  constructor(
    public store: Store<fromRoot.State>,
    public activeModal: NgbActiveModal,
    public formBuilder: FormBuilder,
    public documentTypeEffect: DocumentTypeEffect,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,

  ) {

    this.tags$ = store.pipe(select(fromRoot.getTagsResult));

    this.retentionDurationValues$ = store.pipe(select(fromRoot.getAppConfigRetentionDuration ));

    this.initForm();

    this.businessScopeResult$ = store.pipe(select(fromRoot.getBusinessScopeFirstResult));
    this.subscriberBusinessScopeResult = this.businessScopeResult$.subscribe(businessScope => {
      if (businessScope) {
        // this.langDataFrom = this.formBuilder.group({});
        this.langOnScope = businessScope.languages;
        this.displayNameItemFormData();
      }
    });

    this.documentTypesCreating$ = store.pipe(select(fromRoot.getDocumentTypesCreating));
    this.documentTypesCreatingError$ = store.pipe(select(fromRoot.getDocumentTypesCreatingError));
    this.documentTypesCreatingSuccess$ = store.pipe(select(fromRoot.getDocumentTypesCreatingResult));

    this.subscriberCreateSuccess = this.documentTypesCreatingSuccess$.subscribe(result => {
      if (result) {
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
        this.dataForm.reset();
        this.initForm();
        this.displayNameItemFormData();
      }
    });

    store.dispatch(new PutDocumentTypesCreatingInit);
  }

  initForm() {

    const docType = {
      name: '',
      firstLevel: true,
      active: false,
      displayNameList: null,
      tagList: null,
      allowedChildren: null,
      version: 0,
      id: '',
      retentionDurationUnit: 0,
      retentionDurationValue: ''
    };

    this.currentDocumentType = docType;

    this.dataForm = this.formBuilder.group(Object.assign({}, docType));

    this.dataForm.setControl('allowedChildren', new FormArray([]));
    this.dataForm.setControl('displayNameList', new FormArray([]));
    this.dataForm.setControl('tagList', new FormArray([]));

    this.dataForm.controls['name'].setValidators(Validators.required);
    this.dataForm.controls['retentionDurationUnit'].setValidators(Validators.required);
    this.dataForm.controls['retentionDurationValue'].setValidators(Validators.required);
    this.faTagList = <FormArray>this.dataForm.controls['tagList'];
    this.selectedTags = {};
    this.oldValue = new Array();
  }

 tagSelected(selectedTag: string, index: number) {
    this.selectedTags[selectedTag] = true;
    if (this.oldValue && this.oldValue[index]) {
      this.selectedTags[this.oldValue[index]] = false;
    }
    this.oldValue[index] = selectedTag;
  }

  displayNameItemFormData() {
    const faDisplayNameValues: FormArray = <FormArray>this.dataForm.controls['displayNameList'];

    this.langOnScope.forEach(lang => {
      faDisplayNameValues.push(new FormGroup({
        language: new FormControl(lang, Validators.required),
        value: new FormControl('', Validators.required)
      }));
    });
  }

  removeRow(index: number) {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    this.selectedTags[this.faTagList.at(index)['controls']['symbolicName'].value] = false;
    this.oldValue.splice(index, 1);
    this.faTagList.removeAt(index);
  }

  addRow() {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    this.faTagList.push(new FormGroup({
      mandatory: new FormControl(false),
      symbolicName: new FormControl('', Validators.required),
      multivalued: new FormControl(false)
    }));
  }

  save(dataForm) {
    this.documentTypeEffect.postDocumentTypes(dataForm);
  }

  ngOnInit() {}

  ngOnDestroy() {
    this.subscriberBusinessScopeResult.unsubscribe();
    this.subscriberCreateSuccess.unsubscribe();
  }

}
