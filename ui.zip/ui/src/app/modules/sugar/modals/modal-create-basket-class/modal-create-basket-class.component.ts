import { BasketEffect } from 'app/effects/basket.effect';
import { Basket } from 'app/models/basket';

import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { BusinessScope } from 'app/models/business-scope';
import { Store, select } from '@ngrx/store';
import { DocumentTypesAndTagsEffect } from 'app/effects/document-types-and-tags.effects';

import * as fromRoot from 'app/reducers';


@Component({
  selector: 'app-modal-create-basket-class',
  templateUrl: './modal-create-basket-class.component.html',
  styleUrls: ['./modal-create-basket-class.component.scss']
})
export class ModalCreateBasketClassComponent implements OnInit, OnDestroy {

  public dataForm: FormGroup;
  public businessScopeResult$: Observable<BusinessScope>;
  // public searchResult$: Observable<EnvelopeTypes>;
  public basketClassCreating$: Observable<boolean>;
  public basketClassCreatingError$: Observable<Error>;
  public basketClassCreatingSuccess$: Observable<Basket>;

  public retentionDurationValues$: Observable<Array<any>>;

  public subscriberBusinessScopeResult: Subscription;
  public subscriberCreateSuccess: Subscription;

  public faTagList: FormArray;
  langOnScope: Array<string>;
  currentDocumentType;
  scope: string;

  constructor(
    public store: Store<fromRoot.State>,
    public activeModal: NgbActiveModal,
    public formBuilder: FormBuilder,
    public basketEffect: BasketEffect,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,

  ) {

    this.initForm();

    this.businessScopeResult$ = store.pipe(select(fromRoot.getBusinessScopeFirstResult));
    this.subscriberBusinessScopeResult = this.businessScopeResult$.subscribe(businessScope => {
      if (businessScope) {
        this.scope = businessScope.symbolicName;
        // this.langDataFrom = this.formBuilder.group({});
        this.langOnScope = businessScope.languages;
        this.displayNameItemFormData();
      }
    });
    this.basketClassCreating$ = store.pipe(select(fromRoot.getBasketsPostLoading));
    this.basketClassCreatingError$ = store.pipe(select(fromRoot.getBasketsPostError));
    this.basketClassCreatingSuccess$ = store.pipe(select(fromRoot.getBasketsPostResult));

    this.subscriberCreateSuccess = this.basketClassCreatingSuccess$.subscribe(result => {
      if (result) {
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
        this.dataForm.reset();
        this.initForm();
        this.displayNameItemFormData();
      }
    });


  }

  initForm() {

    const docType: Basket = {
      basketId: null,
      displayNameItem: null,
      symbolicName: null,
      scope: null,
    };

    this.currentDocumentType = docType;

    this.dataForm = this.formBuilder.group(Object.assign({}, docType));

    this.dataForm.setControl('displayNameItem', new FormArray([]));

    this.dataForm.controls['symbolicName'].setValidators(Validators.required);
    // this.dataForm.controls['scope'].setValue(this.scope);

  }

  displayNameItemFormData() {
    const faDisplayNameValues: FormArray = <FormArray>this.dataForm.controls['displayNameItem'];
    this.dataForm.controls['scope'].setValue(this.scope);

    this.langOnScope.forEach(lang => {
      faDisplayNameValues.push(new FormGroup({
        language: new FormControl(lang, Validators.required),
        value: new FormControl('', Validators.required)
      }));
    });
  }

  save(dataForm) {
    // console.log(dataForm)
    this.basketEffect.postBaskets(dataForm);
  }

  ngOnInit() {}

  ngOnDestroy() {
    this.subscriberBusinessScopeResult.unsubscribe();
    this.subscriberCreateSuccess.unsubscribe();
  }

}
