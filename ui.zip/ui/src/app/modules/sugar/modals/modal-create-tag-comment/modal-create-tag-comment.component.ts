import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, ViewEncapsulation, Input } from '@angular/core';

@Component({
  selector: 'app-modal-create-tag-comment',
  templateUrl: './modal-create-tag-comment.component.html',
  styleUrls: ['./modal-create-tag-comment.component.scss'],
  encapsulation: ViewEncapsulation.None

})
export class ModalCreateTagCommentComponent {

  modules = {};
  @Input() model;

  constructor(
    public activeModal: NgbActiveModal,

  ) {
    this.modules = {
      toolbar: [
        ['bold', 'italic', 'underline', 'strike'],

        [{ 'list': 'ordered' }, { 'list': 'bullet' }],

        [{ 'indent': '-1' }, { 'indent': '+1' }],
        // ['clean']
      ],
    };
  }

}
