import { Subscription } from 'rxjs';
import { Folder } from './../../../models/folder';
import { Router, ActivatedRoute } from '@angular/router';
import { DocumentEffect } from 'app/effects/document.effect';
import { DocumentLite } from './../../../models/document-lite';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import {Location} from '@angular/common';
import { FolderEffect } from 'app/effects/folder.effect';
import { DocumentAttachedToFoldersResult } from 'app/models/document-attached-to-folder-result';

import * as fromRoot from 'app/reducers';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';

import { find } from 'lodash';

@Component({
  selector: 'app-folder-files-list',
  templateUrl: './folder-files-list.component.html',
  styleUrls: ['./folder-files-list.component.scss']
})
export class FolderFilesListComponent implements OnInit, OnDestroy {


  public listOfDocument$: Observable<Array<string>>;
  public listOfDocumentObject$: Observable<Array<DocumentLite>>;
  public listOfDocumentObjectSelected$: Observable<Array<DocumentLite>>;
  public selectedDocument$: Observable<string>;
  public folderState$: Observable<Folder>;
  public filterOn$: Observable<any>;

  public deleting$: Observable<boolean>;
  public deletingError$: Observable<boolean>;
  public deletingResult$: Observable<DocumentAttachedToFoldersResult>;

  public subscribeDeletingResult: Subscription;
  public subscriberCurrentDocumentId: Subscription;
  public currentDocumentId$: Observable<{}>;
  public subscribeActiveRoute: Subscription;
  public subscribesListOfDocumentObjectSelected: Subscription;

  folderStateID: string;
  subscribesFolderStateID: Subscription;

  listOfDocument;
  subscribesListOfDocument: Subscription;
  currentDocumentIdToDeleting: string;
  currentDocumentId;
  listSelected;

  constructor(
    public store: Store<fromRoot.State>,
    public folderEffect: FolderEffect,
    public documentEffect: DocumentEffect,
    public router: Router,
    public activatedRouter: ActivatedRoute,
    public location: Location

    ) {


    this.folderState$ = store.pipe(select(fromRoot.getFolderFirstResult));
    this.subscribesFolderStateID = this.folderState$.subscribe( folder => this.folderStateID = folder && folder['id'] );

    this.listOfDocumentObjectSelected$ = store.pipe(select(fromRoot.getDocumentsFilterListSelected));
    // tslint:disable-next-line:max-line-length
    this.subscribesListOfDocumentObjectSelected = this.listOfDocumentObjectSelected$.subscribe(listSelected => this.listSelected = listSelected );

    this.listOfDocument$ = store.pipe(select(fromRoot.getFolderListDocuments));
    this.subscribesListOfDocument = this.listOfDocument$.subscribe( list => list && this.initForm(list));

    this.listOfDocumentObject$ = store.pipe(select(fromRoot.getDocumentsFilterList));
    this.listOfDocumentObjectSelected$ = store.pipe(select(fromRoot.getDocumentsFilterListSelected));

    this.selectedDocument$ = store.pipe(select(fromRoot.getDocumentsFilterSelected));

    this.filterOn$ = store.pipe(select(fromRoot.getDocumentsFilterMultiple));

    this.deleting$ = store.pipe(select(fromRoot.getFolderDeletingDeleting));
    this.deletingError$ = store.pipe(select(fromRoot.getFolderDeletingError));


    this.deletingResult$ = store.pipe(select(fromRoot.getFolderDeletingResult));
    // this.currentDocumentId$ =store.pipe(select(fromRoot.getSearchPreviewResultId);
    // this.subscriberCurrentDocumentId = this.currentDocumentId$.subscribe( currentDocumentId => {
    //   this.currentDocumentId = currentDocumentId;
    //   console.log(this.currentDocumentId)
    // });


    this.subscribeDeletingResult = this.deletingResult$.subscribe( result => {
      if ( result) {

        // this.folderEffect.getFoldersById(result.folderId);
        if ( result.documentIdArray.length > 0 ) {

          // tslint:disable-next-line:max-line-length
          this.router.navigate(['app/refresh'], { queryParams: { url: '/app/folder/' + result.folderId + '/' + result.documentIdArray[0] } });

        } else {
          // this.location.go('app/folder/' + result.folderId);
          this.router.navigate(['app/refresh'], { queryParams: { url: '/app/folder/' + result.folderId } });
          this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
        }
      }
    });
  }

  initForm(list) {
    // const listOfDocument = list.map(element => Object.assign({...element} , { selected: false }));
    const listOfDocument = list.map(element => Object.assign({ ...element }, { selected: find(this.listSelected, { 'id': element.id})} ));

    this.store.dispatch( new documentsFilterAction.PutDocumentSelecedList( listOfDocument ) );
  }

  updateSelected(document) {
    this.store.dispatch( new documentsFilterAction.PutDocumentSelecedListById( document.id ) );
    this.store.dispatch( new documentsFilterAction.PutSelectedDocumentSelecedList( document.id ) );
  }

  documentSelect(document) {

    this.store.dispatch( new documentsFilterAction.PutDocumentSeleced( document.id ) );
    this.router.navigate(['/app/folder', this.folderStateID, document.id ]);
    // this.documentEffect.getDocumentsById(document.id);
  }

  onRemove(id) {
    this.currentDocumentIdToDeleting = id;
    // console.log( this.folderStateID, id)
    if ( this.folderStateID && id) {
      this.folderEffect.deleteFolderDocuments( this.folderStateID, [id] );
    }
    // this.folderEffect.deleteFolderDocuments()
  }


  ngOnInit() {

  }

  ngOnDestroy() {
    this.subscribesFolderStateID.unsubscribe();
    this.subscribesListOfDocument.unsubscribe();
    this.subscribeDeletingResult.unsubscribe();
    this.subscribesListOfDocumentObjectSelected.unsubscribe();

  }

}
