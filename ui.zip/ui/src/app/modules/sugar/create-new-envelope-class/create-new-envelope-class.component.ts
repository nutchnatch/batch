import { Component, OnInit, OnDestroy } from '@angular/core';
// import { ModalCreateTagComponent } from 'app/modules/sugar/modals/modal-create-tag/modal-create-tag.component';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as tagAction from 'app/actions/tag.actions';
import * as fromRoot from 'app/reducers';
import { Store, select } from '@ngrx/store';
// tslint:disable-next-line:max-line-length
import { ModalCreateEnvelopeClassComponent } from 'app/modules/sugar/modals/modal-create-envelope-class/modal-create-envelope-class.component';


@Component({
  selector: 'app-create-new-envelope-class',
  templateUrl: './create-new-envelope-class.component.html',
  styleUrls: ['./create-new-envelope-class.component.scss']
})
export class CreateNewEnvelopeClassComponent implements OnInit, OnDestroy {

  modalCreate;

  constructor(
    public store: Store<fromRoot.State>,
    protected modalService: NgbModal
  ) { }


  openModal() {

    if (!this.modalCreate) {
      this.modalCreate = this.modalService.open(ModalCreateEnvelopeClassComponent, {
        backdrop: 'static'
      });
      // tslint:disable-next-line:max-line-length
      // this.modalCreate.componentInstance.copy = 'Caution ! This action is irreversible. When you save the envelope metadata you cant add more documents to envelopes';
    }

    this.modalCreate.result.then((result) => {
      if (result !== 'continue') {
        this.store.dispatch(new tagAction.CreateTagInit());
        // this.store.dispatch(new envelopeActions.PutUnderConstructionStep2(false));
      }

      // this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
      this.modalCreate = undefined;
    }, (reason) => {
      this.getDismissReason(reason);
      // this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
    });

  }

  getDismissReason(reason: any) {
    this.store.dispatch(new tagAction.CreateTagInit());

    if (reason === ModalDismissReasons.ESC) {
      // this.store.dispatch(new envelopeActions.PutUnderConstructionStep2(false));
      this.modalCreate = undefined;
    }
  }
  ngOnInit() {
  }

  ngOnDestroy() {
    if ( this.modalCreate ) { this.modalCreate.close(); }
  }

}
