import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnvelopeMetadataFormComponent } from './envelope-metadata-form.component';

describe('EnvelopeMetadataFormComponent', () => {
  let component: EnvelopeMetadataFormComponent;
  let fixture: ComponentFixture<EnvelopeMetadataFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnvelopeMetadataFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnvelopeMetadataFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
