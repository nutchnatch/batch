import { Router } from '@angular/router';
import { TagClone } from 'app/models/tag';
import { EnvelopeEffect } from 'app/effects/envelope.effect';
import { Subscription } from 'rxjs';
import { QueryParams } from 'app/models/paged';
import { Store, select } from '@ngrx/store';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Envelope } from 'app/models/envelope';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { delay } from 'rxjs/operators';
import * as fromRoot from 'app/reducers';
import * as envelopeActions from 'app/actions/envelope.actions';
import * as appConfigActions from 'app/actions/app-config.actions';


@Component({
  selector: 'app-envelope-metadata-form',
  templateUrl: './envelope-metadata-form.component.html',
  styleUrls: ['./envelope-metadata-form.component.scss']
})
export class EnvelopeMetadataFormComponent implements OnInit, OnDestroy {

  public metadataForm: FormGroup;
  public extraMetadataForm: FormGroup;
  public envelopeState$: Observable<Envelope>;
  public isUpdateting$: Observable<boolean>;
  public error$: Observable<Error>;
  public updated$: Observable<any>;
  public lastQuery$: Observable<QueryParams>;
  public copiedTags$: Observable<Array<TagClone>>;
  public directionType$: Observable<Array<string>>;
  public allDataLoaded$: Observable<boolean>;

  public subscriberSearchResult: Subscription;
  public subscriberUpdateResult: Subscription;
  public subscriberLastQuery: Subscription;

  public deletingEnvelope$: Observable<boolean>;
  public deleteEnvelopeResult$: Observable<Array<string>>;
  public deleteEnvelopeError$: Observable<Error>;

  lastQuery: QueryParams;
  selecteEnvType: any;
  listOfDocumentIDMemory: Array<any>;
  fromUpdate = false;
  currentEnvelopeId: string;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public envelopeEffect: EnvelopeEffect,
    public router: Router,
  ) {
    this.extraMetadataForm = this.formBuilder.group({});

    this.envelopeState$ = store.pipe(select(fromRoot.getEnvelopeFirstResult));

    this.subscriberSearchResult = this.envelopeState$.subscribe((envelope: Envelope) => {
      this.store.dispatch(new envelopeActions.InitUpdateEnvelope());

      if (envelope && envelope.id) {
        this.currentEnvelopeId = envelope.id;
        this.selecteEnvType = Object.assign({}, this.selecteEnvType, { id: envelope.envTypeId, version: envelope.envTypeVersion });
        this.listOfDocumentIDMemory = envelope.listOfDocumentId;
        this.metadataForm = this.formBuilder.group(Object.assign({}, envelope, { tagList: null, listOfDocumentId: null }));
        this.removeControls(this.extraMetadataForm);
      }
    });

    this.isUpdateting$ = store.pipe(select(fromRoot.getEnvelopeUpdating));
    this.error$ = store.pipe(select(fromRoot.getEnvelopeUpdateError));

    this.lastQuery$ = store.pipe(select(fromRoot.getSearchPagedQuery));

    this.updated$ = store.pipe(select( fromRoot.getEnvelopeUpdateResult ));

    this.subscriberLastQuery = this.lastQuery$.subscribe( lastQuery => this.lastQuery = lastQuery );

    this.subscriberUpdateResult = this.updated$.pipe(delay(1000)).subscribe( id => {
      if (id && this.lastQuery) {
        this.envelopeEffect.getEnvelopes(this.lastQuery);
      }

      if ( id && this.fromUpdate ) {
        this.fromUpdate = false;
        this.envelopeEffect.getEnvelopeById(id.envelopeId, false);
      }
    });

    this.copiedTags$ = store.pipe(select(fromRoot.getAppConfigCopiedTags));

    this.directionType$ = store.pipe(select(fromRoot.getAppConfigDirectionTypes));

    // this.deletingEnvelope$ =store.pipe(select(fromRoot.getEnvelopeDeleteLoading);
    // this.deleteEnvelopeError$ =store.pipe(select(fromRoot.getEnvelopeDeleteError);
    // this.deleteEnvelopeResult$ =store.pipe(select(fromRoot.getEnvelopeDeleteResult);

    // this.deleteEnvelopeResult$.subscribe( result => {
    //   if ( result ) {
    //     this.router.navigate(['app/basket']);
    //   }
    // });
    this.allDataLoaded$ = this.store.select(fromRoot.getBusinessScopeAllLoaded);

  }

  updateDocTypeId(envType) {
    this.selecteEnvType = envType;
    this.store.dispatch(new appConfigActions.PutCopiedTagsAction(null));

    // Object.assign({}, this.metadataForm, { docTypeId: docTypeId });
  }

  deleteEnvelope() {
    this.envelopeEffect.deleteEnvelopeById(this.currentEnvelopeId);
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).forEach( fc => this.extraMetadataForm.removeControl(fc));
  }

  save(metadataForm, extraMetadataForm) {

    if ( this.metadataForm.valid && this.extraMetadataForm.valid ) {
      const formModel = Object.assign({}, metadataForm, {
        tagList: Object.keys(extraMetadataForm).map(function (key) {
          // return { 'tagName': extraMetadataForm[key], 'tagValue': key };
          return { 'tagValue': extraMetadataForm[key], 'tagName': key };

        }),
        envTypeId: this.selecteEnvType.id,
        envTypeVersion: this.selecteEnvType.version,
        listOfDocumentId: this.listOfDocumentIDMemory
      });
      // console.log(this.extraMetadataForm);
      // console.log(formModel);
      this.fromUpdate = true;
      this.envelopeEffect.putEnvelopeById(formModel.id, formModel);
      // this.store.dispatch(new searchPagedAction.PutSearchResultsSearchByID(document));
    }
  }

  copyMetadata() {
    const extraMetadata = this.extraMetadataForm.value;
    const tagList = Object.keys(extraMetadata).map(function (key) {
      return { 'tagName': key, 'tagValue': extraMetadata[key]  };
    });
    this.store.dispatch(new appConfigActions.PutCopiedTagsAction(tagList));
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscriberSearchResult.unsubscribe();
    this.subscriberUpdateResult.unsubscribe();
    this.subscriberLastQuery.unsubscribe();

  }

}
