import { BaseService } from 'app/services/base.service';
import { getBusinessScope } from './../../../reducers/business-scope.reducer';
import { BusinessScopeEffect } from './../../../effects/business-scope.effect';
import { Subscription } from 'rxjs';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { BusinessScope } from 'app/models/business-scope';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

// import { values, map } from 'lodash';

@Component({
  selector: 'app-form-business-scope',
  templateUrl: './form-business-scope.component.html',
  styleUrls: ['./form-business-scope.component.scss']
})
export class FormBusinessScopeComponent implements OnInit {

  public businessScopeResult$: Observable<BusinessScope>;
  public businessScopeUpdating$: Observable<boolean>;
  public businessScopeUpdateError$: Observable<Error>;
  public businessScopeUpdateSuccess$: Observable<BusinessScope>;

  public langISO$: Observable<Array<any>>;
  public currentLang$: Observable<string>;

  public envelopesClass$: Observable<any>;
  public folderClass$: Observable<any>;
  public documentTypes$: Observable<any>;
  public retentionDate$: Observable<any>;
  public encryptionIdentifier$: Observable<any>;
  public businessScopeRuleFileUploadSuccess$: Observable<boolean>;

  public subscriberBusinessScopeResult: Subscription;
  public subscriberBusinessScopeUpdateSuccess: Subscription;

  public dataForm: FormGroup;
  public displayName;
  public languages;
  public preferredLanguages;
  public langOnScope;
  public availableEncryptionIdentifiers;
  public newRuleFile: File;
  public aclList: Array<any>;
  public fileChoosen: string;
  public downloadUrl: string;
  @ViewChild('fileInput') fileInput;


  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public businessScopeEffect: BusinessScopeEffect,
    public router: Router,
    public baseService: BaseService<any>

  ) {

    this.langISO$ = store.pipe(select(fromRoot.getAppConfigLangISO));
    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));

    this.businessScopeResult$ = store.pipe(select(fromRoot.getBusinessScopeFirstResult));

    this.envelopesClass$ = store.pipe(select(fromRoot.getExtraFieldsEnvelopeMetadataFieldsActive));
    this.documentTypes$ = store.pipe(select(fromRoot.getExtraFieldsMetadataFieldsActive));
    this.folderClass$ = store.pipe(select(fromRoot.getExtraFieldsFolderMetadataFieldsActive));
    this.retentionDate$ = store.pipe(select(fromRoot.getAppConfigRetentionStartDate));
    // this.encryptionIdentifier$ =store.pipe(select(fromRoot.getAppConfigEncryptionIdentifier);

    this.subscriberBusinessScopeResult = this.businessScopeResult$.subscribe(businessScope => {
      if (businessScope) {

        this.displayName = businessScope.displayName;
        this.languages = businessScope.languages;
        this.preferredLanguages = businessScope.preferredLanguages;
        this.availableEncryptionIdentifiers =  businessScope.availableEncryptionIdentifiers;
        this.aclList = businessScope.aclList;
        // tslint:disable-next-line:max-line-length
        this.dataForm = this.formBuilder.group(Object.assign({}, businessScope, { displayName: null, languages: null, preferredLanguages: null, availableEncryptionIdentifiers: null, newRuleFile: null, aclList: null }));

        this.dataForm.setControl('displayName', new FormArray([]));
        this.displayNameFormData();

        this.dataForm.setControl('languages', new FormArray([]));
        this.displayLanguages();

        this.dataForm.setControl('preferredLanguages', new FormArray([]));
        this.displayPreferredLanguages();

        this.dataForm.setControl('availableEncryptionIdentifiers', new FormArray([]));
        this.setControlForAvailableEncIdentifiers();
      }
    });

    this.businessScopeUpdating$ = store.pipe(select(fromRoot.getBusinessScopeUpdating));
    this.businessScopeUpdateError$ = store.pipe(select(fromRoot.getBusinessScopeUpdateError));
    this.businessScopeUpdateSuccess$ = store.pipe(select(fromRoot.getBusinessScopeUpdateResult));
    this.businessScopeRuleFileUploadSuccess$ = store.pipe(select(fromRoot.getBusinessScopeRuleFileUploaded));
    this.downloadUrl =  this.baseService.baseUrl + '/business-scopes/rule-file';

  }

  displayNameFormData() {
    const faDisplayNameValues: FormArray = <FormArray>this.dataForm.controls['displayName'];

    this.languages.map((lang, i) => {
      faDisplayNameValues.push(new FormGroup({
        language: new FormControl(lang, Validators.required),
        // tslint:disable-next-line:max-line-length
        value: new FormControl(this.displayName[i] && this.displayName[i].language === lang ? this.displayName[i].value : '', Validators.required)
      }));
    });
  }

  displayLanguages() {
    const faLanguagesValues: FormArray = <FormArray>this.dataForm.controls['languages'];

    this.languages.map(lang => {
      faLanguagesValues.push(new FormGroup({
        value: new FormControl(lang, Validators.required)
      }));
    });
  }

  displayPreferredLanguages() {
    const faPreferredLanguagesValues: FormArray = <FormArray>this.dataForm.controls['preferredLanguages'];

    this.preferredLanguages.map(lang => {
      faPreferredLanguagesValues.push(new FormGroup({
        value: new FormControl(lang)
      }));
    });
  }

  setControlForAvailableEncIdentifiers() {
    const formArrayAvailableEncIdentifiers: FormArray = <FormArray>this.dataForm.controls['availableEncryptionIdentifiers'];
    this.availableEncryptionIdentifiers.map(identifier => {
      formArrayAvailableEncIdentifiers.push(new FormGroup({
        encIdentifier: new FormControl(identifier)
      }));
    });
  }

  save(dataForm) {
    const languagesArray = dataForm.languages.map(v => v.value);
    const preferredLanguagesArray = dataForm.preferredLanguages.map(v => v.value);
    const availableEncryptionIdentifiersArray = dataForm.availableEncryptionIdentifiers.map(v => v.encIdentifier);

    dataForm = Object.assign({}, dataForm, {
      languages: languagesArray,
      preferredLanguages: preferredLanguagesArray,
      availableEncryptionIdentifiers: availableEncryptionIdentifiersArray
    });

    this.businessScopeEffect.putBusinessScopeById(dataForm.businessScopeId, dataForm);
  }

  uploadNewRulesFile() {
    if (this.newRuleFile) {
      const formData: FormData = new FormData();
      formData.append('file', this.newRuleFile);
      this.businessScopeEffect.putRuleFileBusinessScope(formData);
      this.newRuleFile = null;
    }
  }

  fileChange(event) {
    const files = event.target.files;
    if (files.length > 0) {
      this.fileChoosen = files[0].name;
      this.newRuleFile = files[0];
    }
    this.fileInput.nativeElement.value = '';
  }

  ngOnInit() {
  }

}
