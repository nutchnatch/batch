import { Component, OnInit } from '@angular/core';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Store, select } from '@ngrx/store';

import { EnvelopeEffect } from 'app/effects/envelope.effect';
import { Envelope } from 'app/models/envelope';
import { Sidebar } from 'app/models/sidesbars-config';
import { Observable } from 'rxjs';
import { Subscription } from 'rxjs';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';
import * as searchFolderToAttachActions from 'app/actions/search-folder-to-attach.actions';

import { DocumentAttachedToFoldersResult } from 'app/models/document-attached-to-folder-result';
import { DocumentEffect } from 'app/effects/document.effect';
import { dateReviver } from 'ngrx-store-localstorage';
import { ModalAlertEnvelopeComponent } from 'app/modules/sugar/modals/modal-alert-envelope/modal-alert-envelope.component';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-envelope-metadata-sidebar',
  templateUrl: './envelope-metadata-sidebar.component.html',
  styleUrls: ['./envelope-metadata-sidebar.component.scss']
})
export class EnvelopeMetadataSidebarComponent implements OnInit, OnDestroy {
  subscribeActiveRouteQueryParam: Subscription;

  public sidebarConfig$: Observable<Sidebar>;
  public envelopeState$: Observable<Envelope>;
  public envelopeLoading$: Observable<boolean>;
  public attachSuccess$: Observable<DocumentAttachedToFoldersResult>;
  public docIds$: Observable<Array<string>>;

  public deletingEnvelope$: Observable<boolean>;
  public deleteEnvelopeResult$: Observable<Array<string>>;
  public deleteEnvelopeError$: Observable<Error>;

  public subscriberAttachSuccess: Subscription;
  public subscriberDocIds: Subscription;
  public subscriberSearchResult: Subscription;

  taskId;
  currentEnvelopeID;
  currentEnvelope;
  docsId;
  modalCreate;

  constructor(
    public store: Store<fromRoot.State>,
    public activatedRouter: ActivatedRoute,
    public envelopeEffect: EnvelopeEffect,
    public documentEffect: DocumentEffect,
    public router: Router,
    protected modalService: NgbModal

  ) {

    this.sidebarConfig$ = store.pipe(select(fromRoot.getSideBarParams));
    this.envelopeState$ = store.pipe(select(fromRoot.getEnvelopeFirstResult));
    this.envelopeLoading$ = store.pipe(select(fromRoot.getEnvelopeLoading));
    this.subscriberSearchResult = this.envelopeState$.subscribe((envelope: Envelope) => {
      if (envelope) {
        this.currentEnvelope = envelope;
        this.currentEnvelopeID = envelope.id;
      }
    });

    this.docIds$ = store.pipe(select(fromRoot.getSearchFolderToAttachListOfDocumentsToAttach));
    this.subscriberDocIds = this.docIds$.subscribe(docsIds => {
      if (docsIds) {
        this.docsId = docsIds;
      }
    });

    this.attachSuccess$ = store.pipe(select(fromRoot.getSearchFolderToAttachSuccess));

    this.subscriberAttachSuccess = this.attachSuccess$.subscribe(success => {
      if (success && success.documentIdArray.length > 0) {
        // console.log('id -> ' , success.documentIdArray[0])
        // console.log(this.currentDocumentId)
        // console.log(this.router.url, this.router.routerState.snapshot.root.children[0].params['docid'] )
        // if ( this.currentEnvelope && this.currentEnvelope.listOfDocumentId.length > 0 ) {
        if (this.docsId.length > 0) {
          // this.router.navigate(['/app/envelope', this.folderStateID, document.id ]);
          this.documentEffect.getDocumentsById(this.router.routerState.snapshot.root.children[0].params['docid']);
        }
        this.store.dispatch(new searchFolderToAttachActions.InitSearchFolderToAttach());

      }
    });


    this.deletingEnvelope$ = store.pipe(select(fromRoot.getEnvelopeDeleteLoading));
    this.deleteEnvelopeError$ = store.pipe(select(fromRoot.getEnvelopeDeleteError));
    this.deleteEnvelopeResult$ = store.pipe(select(fromRoot.getEnvelopeDeleteResult));

    this.deleteEnvelopeResult$.subscribe(result => {
      if (result) {
        this.router.navigate(['app/basket']);
      }
    });
  }

  ngOnInit() {
    this.subscribeActiveRouteQueryParam = this.activatedRouter.queryParamMap.subscribe((params: ParamMap) => {
      if (params.get('taskId')) {
        this.taskId = params.get('taskId');
      }
      // console.log(this.taskId)
    });
  }

  modalDeleteWarning() {
    if (!this.modalCreate) {
      this.modalCreate = this.modalService.open(ModalAlertEnvelopeComponent, {
        backdrop: 'static'
      });
      // tslint:disable-next-line:max-line-length
      this.modalCreate.componentInstance.copy = 'ALERT_DELETE_ENVELOPE'; // 'Caution! This action is irreversible. Envelope will be deleted';

      this.modalCreate.result.then((result) => {
        // console.log(result)
        // if (result !== 'continue') {
        //   // this.store.dispatch(new tagAction.CreateTagInit());
        //   // this.store.dispatch(new envelopeActions.PutUnderConstructionStep2(false));
        // }
        if ( result === 'continue') {
          this.deleteEnvelope();
        }
        // this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
        this.modalCreate = undefined;
      }, (reason) => {
        this.getDismissReason(reason);
        // this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
      });
    }
  }

  getDismissReason(reason: any) {
    if (reason === ModalDismissReasons.ESC) {
      // this.store.dispatch(new envelopeActions.PutUnderConstructionStep2(false));
      this.modalCreate = undefined;
    }
  }

  deleteEnvelope() {
    this.envelopeEffect.deleteEnvelopeById(this.currentEnvelopeID);
  }

  ngOnDestroy() {
    if ( this.modalCreate ) { this.modalCreate.close(); }

    this.store.dispatch(new layoutActions.PutFromSearchAction(null));
    this.subscriberSearchResult.unsubscribe();
  }


}
