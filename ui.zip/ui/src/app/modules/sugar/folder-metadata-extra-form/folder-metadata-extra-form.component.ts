import { BusinessScope } from './../../../models/business-scope';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Observable, combineLatest  } from 'rxjs';
import { Component, OnInit, Input, OnDestroy, EventEmitter, Output } from '@angular/core';
import { ExtraFields } from 'app/states/extra-fields.state'; // Model
import { Folder } from 'app/models/folder';

import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

import * as fromRoot from 'app/reducers';

import { find } from 'lodash';
import { DateParserFormaterServices } from 'app/services/date-parser-formater/date-parser-formater.service';

@Component({
  selector: 'app-folder-metadata-extra-form',
  templateUrl: './folder-metadata-extra-form.component.html',
  styleUrls: ['./folder-metadata-extra-form.component.scss']
})
export class FolderMetadataExtraFormComponent implements OnInit, OnDestroy {

  @Input() extraMetadataForm: FormGroup;
  @Input() preview;
  @Input() newFolder = false;
  @Output() folderTypeIdSelected = new EventEmitter();

  // extraMetadataForm: FormGroup;
  currentLang$: Observable<string>;
  folderTypes$: Observable<Array<ExtraFields>>;
  currentFolder$: Observable<Folder>;
  allDataLoaded$: Observable<boolean>;

  private businessScopeResult$: Observable<BusinessScope>;
  private subscriberBusinessScopeResult: Subscription;
  private folderTypeFromBusinessScope;

  subFolderTypes: Subscription;
  subCurrentFolder: Subscription;

  folderTypeId;
  currentFolder;
  folderTypes;
  metadataFormSubscrition;
  dpValues: Array<any>;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public dateToUCT: DateParserFormaterServices,
    public dateParserFormatter: NgbDateParserFormatter
  ) {

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.folderTypes$ = store.pipe(select(fromRoot.getExtraFieldsFolderMetadataFields));
    this.subFolderTypes = this.folderTypes$.subscribe(folderTypes => this.folderTypes = folderTypes);

    this.businessScopeResult$ = store.pipe(select(fromRoot.getBusinessScopeFirstResult));
    this.subscriberBusinessScopeResult = this.businessScopeResult$.subscribe(businessScope => {
      if (businessScope) {
        this.folderTypeFromBusinessScope = businessScope.defaultFolderType;
      }
    });
  }

  initExtraMetadaFormCurrentDoc() {
    if (this.extraMetadataForm) { this.removeControls(this.extraMetadataForm); this.dpValues = []; }

    const folderTags: any = find(this.folderTypes, { id: this.folderTypeId });

    folderTags.inputsFields.map((tag) => {
      const validators = tag.mandatory && tag.type === 'string' ? [Validators.pattern(new RegExp(tag.pattern))] : [];
      // tslint:disable-next-line:max-line-length
      // console.log(this.copiedTags)
      const folderTag: any = find(this.currentFolder.tagList, (t) => t.tagName === tag.name);

      let value = '';

      if (folderTag) {
        if (tag.type === 'timestamp' && folderTag.tagName === tag.name) {
          this.dpValues[tag.name] = this.dateParserFormatter.parse(folderTag.tagValue);
        }

        value = folderTag.tagName === tag.name ? folderTag.tagValue : '';

      }

      // tslint:disable-next-line:max-line-length
      this.extraMetadataForm.addControl(tag.name, new FormControl({ value: value, disabled: this.currentFolder.status === 'CLOSE' }, validators));
      // if (this.currentFolder.tagList[i].tagName === tag.name) { console.log(this.currentFolder.tagList[i].tagName , tag.name) }
    });

  }

  updateToModel(inputName, newValue) {
    this.extraMetadataForm.controls[inputName].setValue(this.dateToUCT.ngbDatepickerUTCDate(newValue));
  }

  initExtraMetadaForm() {

    if (this.extraMetadataForm) { this.removeControls(this.extraMetadataForm); this.dpValues = []; }

    this.folderTypes.map(folderType => {
      if (folderType.id === this.folderTypeId) {
        for (let i = 0; i < folderType.inputsFields.length; i++) {
          // tslint:disable-next-line:max-line-length
          const validators = folderType.inputsFields[i].mandatory ? [Validators.pattern(new RegExp(folderType.inputsFields[i].pattern))] : [];
          this.extraMetadataForm.addControl(folderType.inputsFields[i].name, new FormControl('', validators));

        }
      }
    });
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).forEach(fc => this.extraMetadataForm.removeControl(fc));
  }

  onChange(folderTypeId) {
    const folderType = find(this.folderTypes, { id: folderTypeId });

    if (this.currentFolder && this.currentFolder.folderTypeId === folderType.id) {
      this.initExtraMetadaFormCurrentDoc();
    } else {
      this.folderTypeId = folderTypeId;
      this.initExtraMetadaForm();
    }

    this.folderTypeIdSelected.emit(folderType);
  }

  ngOnInit() {

    this.setDefaultFolderType();

    if (this.newFolder === false) {
      this.currentFolder$ = !this.preview
        ? this.store.pipe(select(fromRoot.getFolderFirstResult))
        : this.store.pipe(select(fromRoot.getSearchPreviewResults));

      this.allDataLoaded$ = this.store.pipe(select(fromRoot.getBusinessScopeAllLoaded));

      const combinedObst$: Observable<any> = combineLatest(this.currentFolder$, this.allDataLoaded$);

      this.subCurrentFolder = combinedObst$.subscribe(([currentFolder, allDataLoaded ]) => {
        if (currentFolder && allDataLoaded ) {
          const folder = currentFolder;
          if (folder && folder.id) {
            this.folderTypeId = folder.folderTypeId;
            const folderType: any = find(this.folderTypes, { id: folder.folderTypeId });

            this.folderTypeId = folder.folderTypeId;
            this.currentFolder = folder;
            this.initExtraMetadaFormCurrentDoc();

            // tslint:disable-next-line:max-line-length
            this.folderTypeIdSelected.emit({ id: this.folderTypeId, version: folderType && folderType.version !== folder.folderTypeId ? folderType.version : folder.folderTypeId });
          }
        }
      });
    } else {
      // this.folderTypeId = folderTypeId;
      this.initExtraMetadaForm();
    }
  }

  setDefaultFolderType() {
    if (this.folderTypes) {
      this.folderTypes.filter(folderType => folderType.name === this.folderTypeFromBusinessScope)
        .map(folderType => {
          const defaultFolderType = folderType;
          this.folderTypeId = folderType.id;
          this.folderTypeIdSelected.emit(defaultFolderType);

          for (let i = 0; i < defaultFolderType.inputsFields.length; i++) {
            // tslint:disable-next-line:max-line-length
            const validators = defaultFolderType.inputsFields[i].mandatory ? [Validators.pattern(new RegExp(defaultFolderType.inputsFields[i].pattern))] : [];
            // tslint:disable-next-line:max-line-length
            this.extraMetadataForm.addControl(defaultFolderType.inputsFields[i].name, new FormControl('', validators));
          }
        });
    }
  }

  ngOnDestroy() {
    if (this.subCurrentFolder) { this.subCurrentFolder.unsubscribe(); }
    this.subFolderTypes.unsubscribe();
    this.subscriberBusinessScopeResult.unsubscribe();
  }

}
