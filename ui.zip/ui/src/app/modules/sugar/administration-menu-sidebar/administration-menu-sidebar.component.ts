import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administration-menu-sidebar',
  templateUrl: './administration-menu-sidebar.component.html',
  styleUrls: ['./administration-menu-sidebar.component.scss']
})
export class AdministrationMenuSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
