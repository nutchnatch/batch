import { Subscription } from 'rxjs';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';

import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutAction from 'app/actions/layout.actions';
import * as advanceSearchAction from 'app/actions/advance-search.actions';
import * as searchPagedActions from 'app/actions/search-paged.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';

@Component({
  selector: 'app-search-on-sidebar',
  templateUrl: './search-on-sidebar.component.html',
  styleUrls: ['./search-on-sidebar.component.scss']
})
export class SearchOnSidebarComponent implements OnInit, OnDestroy {

  subscriberSearchQuery: Subscription;
  subscriberSearchType: Subscription;
  searchList$: Observable<Object>;
  pageSize$: Observable<number>;
  searching$: Observable<boolean>;
  allLoaded$: Observable<boolean>;
  subscriberPageSize: Subscription;

  searchQueryString: FormGroup;
  pageSize: number;
  advanceSearch$: Observable<boolean>;
  isUpLoading$: Observable<boolean>;

  subscriberAdvanceSearch: Subscription;
  selected;
  searchTypeCurrent$: Observable<string>;
  searchStringQuery$: Observable<string>;
  currentLayoutUrl: string; // Observable<string>;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router,
    public activatedRouter: ActivatedRoute,
  ) {
    this.searchList$ = store.pipe(select(fromRoot.getAppConfigSearchTypes));
    this.pageSize$ = store.pipe(select(fromRoot.getAppConfigPageSize));
    this.subscriberPageSize = this.pageSize$.subscribe(value => this.pageSize = value);

    this.advanceSearch$ = store.pipe(select(fromRoot.getLayoutAdvanceSearch));

    this.isUpLoading$ = store.pipe(select(fromRoot.getUploadDocumentsLoading));
    this.searching$ = store.pipe(select(fromRoot.getSearchPagedLoading));

    this.allLoaded$ = store.pipe(select(fromRoot.getBusinessScopeAllLoaded));

    this.searchTypeCurrent$ = store.pipe(select(fromRoot.getSearchPagedType));
    this.subscriberSearchType = this.searchTypeCurrent$.subscribe(type => {
      if (type) {
        const t = type.charAt(0).toUpperCase() + type.slice(1);
        this.selected = type !== 'basket' ? t : 'Documents';
        store.dispatch(new advanceSearchAction.PutDomain(t));
      } else {
        this.selected = 'Documents';
        store.dispatch(new advanceSearchAction.PutDomain('Documents'));
      }

      if (type === 'basket') { this.store.dispatch(  new searchPagedActions.PutSearchingSearchStringQuery('')); }
    });

    this.searchStringQuery$ = store.pipe(select(fromRoot.getSearchPagedQueryName));

    // console.log(this.activatedRouter.snapshot.url[1].path)
    this.currentLayoutUrl = this.activatedRouter.snapshot.url[1] ? this.activatedRouter.snapshot.url[1].path : '';
  }


  advanceSearch(bool) {
    this.store.dispatch(new layoutAction.PutAdvanceSearch(bool));
  }

  onSearch(searchQueryString: FormGroup) {

    // tslint:disable-next-line:max-line-length
    const baseUrl = 'app/' + searchQueryString.value.type.toLowerCase();

    const value = searchQueryString.value.name === '' ? ' ' : searchQueryString.value.name;
    this.store.dispatch(  new searchPagedActions.PutSearchingSearchStringQuery(value));
    this.store.dispatch( new searchPreviewActions.InitSearchResultsSearchPreview());

    // tslint:disable-next-line:max-line-length
    this.router.navigate([baseUrl], { queryParams:  Object.assign({}, { quickSearch: value  , pageNumber: 1, pageSize: this.pageSize , t: +new Date() }) });
  }

  onChange(type) {
    this.store.dispatch(new advanceSearchAction.PutDomain(type));

  }

  ngOnInit() {

    this.searchQueryString = new FormGroup({
      name: new FormControl(''),
      type: new FormControl('', Validators.required )
    });
    this.subscriberSearchQuery = this.searchStringQuery$.subscribe( query => {
      this.searchQueryString.controls['name'].setValue(query === '' ? '' : query);
    });

  }

  ngOnDestroy() {
    this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
    this.subscriberPageSize.unsubscribe();
    this.subscriberSearchType.unsubscribe();
    this.subscriberSearchQuery.unsubscribe();
    // if ( this.subscriberSearchQuery ) { }
  }

}
