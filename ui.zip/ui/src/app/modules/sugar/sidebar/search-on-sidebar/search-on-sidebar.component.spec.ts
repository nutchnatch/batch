import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchOnSidebarComponent } from './search-on-sidebar.component';

describe('SearchOnSidebarComponent', () => {
  let component: SearchOnSidebarComponent;
  let fixture: ComponentFixture<SearchOnSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchOnSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchOnSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
