import { Sidebar } from 'app/models/sidesbars-config';
import { Observable } from 'rxjs';
import { Component } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';

@Component({
  selector: 'app-sidebar-content',
  templateUrl: './sidebar-content.component.html',
  styleUrls: ['./sidebar-content.component.scss']
})
export class SidebarContentComponent  {

  public sideConfig$: Observable<Sidebar>;

  constructor(
    store: Store<fromRoot.State>
  ) {

    this.sideConfig$ = store.pipe(select(fromRoot.getSideBarParams));

  }
}
