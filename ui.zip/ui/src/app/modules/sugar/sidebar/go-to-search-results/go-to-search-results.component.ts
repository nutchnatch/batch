import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';

import { Observable } from 'rxjs';

import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as searchPreviewActions from 'app/actions/search-preview.actions';

@Component({
  selector: 'app-go-to-search-results',
  templateUrl: './go-to-search-results.component.html',
  styleUrls: ['./go-to-search-results.component.scss']
})
export class GoToSearchResultsComponent implements OnInit, OnDestroy {
  subFromSearch: Subscription;

  public fromSearch$: Observable<string>;
  public searchRoute: string;
  public routerEvent;
  public subscribeRouter: Subscription;


  constructor(
    public router: Router,
    public store: Store<fromRoot.State>
  ) {


    this.fromSearch$ = store.pipe(select(fromRoot.getLayoutFromSearch));
    this.subFromSearch = this.fromSearch$.subscribe( url => this.searchRoute = url );

  }

  goBack() {
    this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
    this.router.navigateByUrl(this.searchRoute);
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    // this.store.dispatch(new layoutAction.PutFromSearchAction(false));
    // this.subscribeRouter.unsubscribe();

    this.subFromSearch.unsubscribe();
  }

}
