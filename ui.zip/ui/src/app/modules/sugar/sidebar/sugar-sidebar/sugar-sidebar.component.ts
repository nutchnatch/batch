import { Component, Input, ElementRef, HostListener } from '@angular/core';
import { Observable } from 'rxjs';

import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutAction from 'app/actions/layout.actions';

@Component({
  selector: 'app-sugar-sidebar',
  templateUrl: './sugar-sidebar.component.html',
  styleUrls: ['./sugar-sidebar.component.scss']
})

export class SugarSidebarComponent {

  @Input() sidebarComponent;
  @Input() open = false;
  @Input() sidebarOpened = true;

  public sideBarPined$: Observable<boolean>;
  isPinned;

  @HostListener('document:click', ['$event'])
  clickout(event) {
    if (!this.eRef.nativeElement.contains(event.target) && this.sidebarOpened && !this.isPinned) {
      this.store.dispatch(new layoutAction.CloseSidenavAction());
    }
  }

  constructor(
    public store: Store<fromRoot.State>,
    private eRef: ElementRef
  ) {
    this.sideBarPined$ = store.pipe(select(fromRoot.getSideBarPined));
    this.sideBarPined$.subscribe( isPinned => this.isPinned = isPinned);
  }

  openSideBarMenu() {
    // tslint:disable-next-line:max-line-length
    (this.sidebarOpened) ? this.store.dispatch(new layoutAction.CloseSidenavAction()) : this.store.dispatch(new layoutAction.OpenSidenavAction());
  }

  tooglePinedSideBarMenu(event: Event, bool: boolean) {
    event.stopPropagation();
    // tslint:disable-next-line:max-line-length
    (!bool) ? this.store.dispatch(new layoutAction.PinSidenavAction()) : this.store.dispatch(new layoutAction.UnPinSidenavAction());
  }


}
