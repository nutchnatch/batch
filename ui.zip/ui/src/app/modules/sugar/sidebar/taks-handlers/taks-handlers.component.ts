import { TaskService } from 'app/services/task.service';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Task } from 'app/models/task';
import { Subscription } from 'rxjs';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Component, OnInit } from '@angular/core';
import { TaskEffect } from 'app/effects/task.effect';
import * as fromRoot from 'app/reducers';
import { Observable } from 'rxjs';
import { Location } from '@angular/common';

import * as taskAction from 'app/actions/task.actions';
import * as layoutAction from 'app/actions/layout.actions';

@Component({
  selector: 'app-taks-handlers',
  templateUrl: './taks-handlers.component.html',
  styleUrls: ['./taks-handlers.component.scss']
})
export class TaksHandlersComponent implements OnInit, OnDestroy {
  subscribeStatus: Subscription;
  subscribeActiveRouteQueryParams: Subscription;

  public task$: Observable<Task>;
  public taskError$: Observable<Error>;

  public status$: Observable<string>;
  public statusError$: Observable<Error>;
  public statusLoading$: Observable<boolean>;

  public fromSearch$: Observable<string>;
  public searchRoute: string;
  public subscribeRouter: Subscription;
  subFromSearch: Subscription;

  currentBasketId: string;

  constructor(
    public store: Store<fromRoot.State>,
    public taskEffect: TaskEffect,
    public router: Router,
    public activatedRouter: ActivatedRoute,
    public taskService: TaskService,
    public location: Location
  ) {


    this.taskError$ = store.pipe(select(fromRoot.getTasksError));

    this.task$ = store.pipe(select(fromRoot.getTasksResult));

    this.statusError$ = store.pipe(select(fromRoot.getTasksStatusError));
    this.statusLoading$ = store.pipe(select(fromRoot.getTasksStatusLoading));
    this.status$ = store.pipe(select(fromRoot.getTasksStatusResult));

    this.fromSearch$ = store.pipe(select(fromRoot.getLayoutFromSearch));
    this.subFromSearch = this.fromSearch$.subscribe(url => this.searchRoute = url);

    this.subscribeStatus = this.status$.subscribe(result => {
      if (result) {
        // this.router.navigate(['app/refresh', { url: 'app/envelope/' + this.activatedRouter.snapshot.url[2].path }]);
        this.location.replaceState('app/envelope/' + this.activatedRouter.snapshot.url[1].path);
        this.currentBasketId = null;
      }
    });
  }

  closeTask() {
    if (this.currentBasketId) {
      this.taskEffect.putTaskByIdStatus(this.currentBasketId, 'CLOSE');
    }
  }


  ngOnInit() {
    this.subscribeActiveRouteQueryParams = this.activatedRouter.queryParamMap.subscribe((paramsMap: ParamMap | any) => {
      // this.currentBasketId = paramsMap.get('taskId');
      if (paramsMap.get('taskId')) {
        this.currentBasketId = paramsMap.get('taskId');
        this.taskEffect.getTasksById(paramsMap.get('taskId'));
        if (this.searchRoute) { this.store.dispatch(new layoutAction.PutFromSearchAction(this.searchRoute)); }

      }
    });
  }

  ngOnDestroy() {
    this.store.dispatch(new taskAction.InitStatusTask());
    this.subscribeStatus.unsubscribe();
    this.subscribeActiveRouteQueryParams.unsubscribe();
  }
}
