import { FolderEffect } from 'app/effects/folder.effect';
import { Subscription } from 'rxjs';
import { QueryParams } from 'app/models/paged';
import { Store, select } from '@ngrx/store';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Folder } from 'app/models/folder';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as folderActions from 'app/actions/folder.actions';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { ModalAlertEnvelopeComponent } from 'app/modules/sugar/modals/modal-alert-envelope/modal-alert-envelope.component';
import { Router } from '@angular/router';


@Component({
  selector: 'app-folder-metadata-form',
  templateUrl: './folder-metadata-form.component.html',
  styleUrls: ['./folder-metadata-form.component.scss']
})
export class FolderMetadataFormComponent implements OnInit, OnDestroy {

  public folderState$: Observable<Folder>;
  public metadataForm: FormGroup;
  public extraMetadataForm: FormGroup;
  public searchResult$: Observable<Folder>;
  public isUpdateting$: Observable<boolean>;
  public updated$: Observable<any>;
  public folderStatus$: Observable<Array<any>>;
  public allDataLoaded$: Observable<boolean>;

  public lastQuery$: Observable<QueryParams>;

  public error$: Observable<Error>;
  public subscriberfolderState: Subscription;
  public subscriberUpdateResult: Subscription;
  public subscriberLastQuery: Subscription;
  listOfDocumentIDMemory: Array<any>;

  lastQuery: QueryParams;
  selectedFolderType: any;
  modalWarning;

  isFromFreeze = false;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public folderEffect: FolderEffect,
    protected modalService: NgbModal,
    public router: Router,
  ) {
    this.extraMetadataForm = this.formBuilder.group({});

    this.folderState$ = store.pipe(select(fromRoot.getFolderFirstResult));

    this.subscriberfolderState = this.folderState$.subscribe((folder: Folder) => {

      this.store.dispatch(new folderActions.InitUpdateFolder());

      if (folder) {

        this.listOfDocumentIDMemory = folder.listOfDocumentId;

        const folderNew = Object.assign(Object.assign({}, folder, { tagList: null, listOfDocumentId: null }));

        // tslint:disable-next-line:max-line-length
        this.selectedFolderType = Object.assign({}, this.selectedFolderType, { id: folderNew.folderTypeId, version: folderNew.folderTypeVersion });
        this.metadataForm = this.formBuilder.group(folderNew);

        this.metadataForm.controls['name'].setValidators( Validators.required );

        // this.metadataForm = this.formBuilder.group(Object.assign({}, folder, { tagList: null, listOfDocumentId: null }));
        this.removeControls(this.extraMetadataForm);
      }
    });

    this.isUpdateting$ = store.pipe(select(fromRoot.getFolderUpdating));
    this.error$ = store.pipe(select(fromRoot.getFolderUpdateError));

    this.lastQuery$ = store.pipe(select(fromRoot.getSearchPagedQuery));

    this.updated$ = store.pipe(select( fromRoot.getFolderUpdateResult));
    this.subscriberLastQuery = this.lastQuery$.subscribe( lastQuery => this.lastQuery = lastQuery );

    this.subscriberUpdateResult = this.updated$.subscribe( folder => {
      if (folder && this.lastQuery ) {
        this.folderEffect.getFolders(this.lastQuery);
      }
      if (folder && this.isFromFreeze) {
        // this.router.navigateByUrl(this.router.url + '&t=' + new Date());
        this.router.navigate(['app/refresh'], { queryParams: { url: this.router.url } } );
        // this.folderEffect.getFoldersById(folder.folderId);
      }
      if (folder && folder.status) { this.isFromFreeze = false; }
    });

    this.folderStatus$ = store.pipe(select( fromRoot.getAppConfigFolderStatus));
    // this.folderStatus$.subscribe( r => console.log(r))
    this.allDataLoaded$ = this.store.select(fromRoot.getBusinessScopeAllLoaded);


  }

  updateDocTypeId( folderType ) {
    this.selectedFolderType = folderType;
    // Object.assign({}, this.metadataForm, { docTypeId: docTypeId });
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).forEach(fc => this.extraMetadataForm.removeControl(fc));
  }



  openExpiredModal(metadataForm, extraMetadataForm) {

    if (!this.modalWarning) {
      this.modalWarning = this.modalService.open(ModalAlertEnvelopeComponent, {
        backdrop: 'static'
      });
      // tslint:disable-next-line:max-line-length
      this.modalWarning.componentInstance.copy = 'ALERT_CLOSE_FOLDER';
    }

    this.modalWarning.result.then((result) => {
      if (result === 'continue') {
        this.isFromFreeze = true;
        const newMetaform = Object.assign({}, metadataForm, { status: 'CLOSE' });
        this.save(newMetaform, extraMetadataForm);
      } else {
        // this.store.dispatch(new envelopeActions.PutUnderConstructionStep2(false));
      }
      // this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
      this.modalWarning = undefined;
    }, (reason) => {
      this.getDismissReason(reason);
      // this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
    });

  }

  getDismissReason(reason: any) {
    if (reason === ModalDismissReasons.ESC) {
      // this.store.dispatch(new envelopeActions.PutUnderConstructionStep2(false));
      this.modalWarning = undefined;
    }
  }

  save(metadataForm, extraMetadataForm) {
    if ( this.metadataForm.valid && this.extraMetadataForm.valid ) {
      const formModel = Object.assign({}, metadataForm, {
        tagList: Object.keys(extraMetadataForm).map(function (key) {
          // return { 'tagName': extraMetadataForm[key], 'tagValue': key };
          return { 'tagValue': extraMetadataForm[key], 'tagName': key };
        }),
        listOfDocumentId: this.listOfDocumentIDMemory,
        folderTypeId: this.selectedFolderType.id,
        folderTypeVersion: this.selectedFolderType.version
      });
      // delete formModel.listOfDocumentId;
      // console.log(this.metadataForm, this.extraMetadataForm);
      // console.log(formModel)

      this.folderEffect.putFolderById(formModel.id, formModel);
    }
  }

  ngOnInit() { }

  ngOnDestroy() {
    this.subscriberfolderState.unsubscribe();
    this.subscriberUpdateResult.unsubscribe();
    this.subscriberLastQuery.unsubscribe();
  }
}
