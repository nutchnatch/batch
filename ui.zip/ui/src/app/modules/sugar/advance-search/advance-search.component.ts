
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';

import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as advanceSearchActions from 'app/actions/advance-search.actions';
import * as searchPreviewsActions from 'app/actions/search-preview.actions';

import { filter } from 'lodash';

@Component({
  selector: 'app-advance-search',
  templateUrl: './advance-search.component.html',
  styleUrls: ['./advance-search.component.scss']
})
export class AdvanceSearchComponent implements OnInit, OnDestroy {

  pageSize$: Observable<number>;
  currentLang$: Observable<string>;
  advanceQuery$: Observable<string>;
  advanceQueryForm$: Observable<string>;
  advanceQueryType$: Observable<string>;

  domain$: Observable<string>;
  type$: Observable<string>;

  formGroup$: Observable<any>;
  searching$: Observable<boolean>;

  subscriberPageSize: Subscription;
  subscriberFormGroup: Subscription;
  subscriberDomain: Subscription;
  subscriberType: Subscription;

  searchQueryString: FormGroup;

  pageSize: number;
  type: string = null;
  domain: string = null;
  advanceCriteriaQuery: any = null;
  subscriberAdvanceQuery: Subscription;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router,
    public dateParserFormatter: NgbDateParserFormatter
  ) {

    this.pageSize$ = store.pipe(select(fromRoot.getAppConfigPageSize));
    this.subscriberPageSize = this.pageSize$.subscribe(value => this.pageSize = value);
    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));

    this.advanceQuery$ = store.pipe(select(fromRoot.getAdvanceSearchQuery));
    this.searching$ = store.pipe(select(fromRoot.getSearchPagedLoading));

    this.domain$ = store.pipe(select(fromRoot.getAdvanceSearchDomain));
    // this.type = 'Documents';
    this.subscriberDomain = this.domain$.subscribe(domain => {
      if (domain) {
        this.domain = domain;
        if ( this.searchQueryString ) { this.searchQueryString.reset(); }
        this.buildForm();
      }
    });


    this.type$ = store.pipe(select(fromRoot.getAdvanceSearchTypeId));
    this.subscriberType = this.type$.subscribe(type => {
      if (type) {

        // console.log('tyep', type)
        // if (!this.advanceCriteriaQuery ) {
        // tslint:disable-next-line:max-line-length
        //   this.store.dispatch(new advanceSearchActions.PutAdvanceSearch({ tagName: null, operator: null, type: null, value: null, defaultTag: false}));
        // }
        this.type = type;
        this.buildForm();
      } else {
        this.type = null;
      }
    });


    this.subscriberAdvanceQuery = this.advanceQuery$.subscribe( advanceCriteriaQuery =>  {
      if ( advanceCriteriaQuery  ) {
        this.advanceCriteriaQuery = advanceCriteriaQuery;
      }
    });

  }

  onSearch(searchQueryString: FormGroup) {
    // console.log(searchQueryString)
    // console.log(searchQueryString.valid)

    const baseUrl = 'app/' + searchQueryString.value.type.toLowerCase();

    // console.log(this.toQueryParams(searchQueryString.value['advanceSearchQuery']))

    const query = Object.assign({},
      this.toQueryParams(searchQueryString.value['advanceSearchQuery']),
      { pageNumber: 1, pageSize: this.pageSize },
      // tslint:disable-next-line:max-line-length
      searchQueryString.get('filterId').value && searchQueryString.value.type.toLowerCase() === 'documents' && { docTypeIds: searchQueryString.get('filterId').value },
      // tslint:disable-next-line:max-line-length
      searchQueryString.get('filterId').value && searchQueryString.value.type.toLowerCase() === 'envelopes' && { envelopeTypeIds: searchQueryString.get('filterId').value },
      // tslint:disable-next-line:max-line-length
      searchQueryString.get('filterId').value && searchQueryString.value.type.toLowerCase() === 'folders' && { folderTypeIds: searchQueryString.get('filterId').value },
      { t: +new Date() }
    );

    // this.store.dispatch(new advanceSearchActions.PutTagsSelected(searchQueryString.value['advanceSearchQuery']));
    // console.log(searchQueryString.value['advanceSearchQuery'])
    // this.testFormBuilder(searchQueryString);

    this.store.dispatch(new advanceSearchActions.PutTypeId(searchQueryString.value['filterId']));
    this.store.dispatch(new advanceSearchActions.PutAdvanceSearchWithValues( searchQueryString.value['advanceSearchQuery'] ));
    this.store.dispatch( new searchPreviewsActions.InitSearchResultsSearchPreview());
    this.router.navigate([baseUrl], { queryParams: query  });

  }


  buildForm() {

    // if ( this.searchQueryString ) { this.searchQueryString.reset(); }

    this.searchQueryString = new FormGroup({
      type: new FormControl(this.domain, Validators.required),
      filterId: new FormControl(this.type),
      filterSelected: new FormControl(this.type)
    });
    this.searchQueryString.addControl('advanceSearchQuery', new FormArray([]));
  }

  toQueryParams(formValues): any {
    let paramsObj;
    const tagArray = [];

    if ( !formValues[0].value ) {
      return;
    }
    // console.log(formValues)
    filter(formValues, (tag) => tag['defaultTag'])
      .forEach(tag => {

        let value;
        if ( tag['type'] === 'timestamp' ) {
          // tslint:disable-next-line:max-line-length
          value = tag['operator'] === 'between' ? this.dateParserFormatter.format(tag['value']) + '#' + this.dateParserFormatter.format(tag['toValue']) : this.dateParserFormatter.format(tag['value']) ;
        } else {
          value = tag['value'] === '' ? '' : tag['value'];
        }

        let operator = tag['operator'] !== 'VALIDITY' ? tag['operator'] + '|' : tag['tagName'] !== 'validity' ? '|' : '';

        operator = operator === 'STATUS_CODE|' ? '' : operator;
        paramsObj = Object.assign({}, paramsObj, { [tag['tagName']]: operator + value  } );

      });

    filter(formValues, (tag) => !tag['defaultTag'])
      .forEach(tag => {
        let value = tag.type === 'timestamp' ? this.dateParserFormatter.format(tag.value) : tag.value;

        if ( tag['type'] === 'timestamp' ) {
          // tslint:disable-next-line:max-line-length
          value = tag['operator'] === 'between' ? this.dateParserFormatter.format(tag['value']) + '#' + this.dateParserFormatter.format(tag['toValue']) : this.dateParserFormatter.format(tag['value']) ;
        }
        value = tag['type'] === 'float' ? value.toString().replace(/,/g, '.') : value;
        tagArray.push(tag.tagName + '|' + tag.type + '|' + tag.operator + '|' + value);
        paramsObj = Object.assign({}, paramsObj, { tags: tagArray });
      });
    // name=operator|value
    // tags=tagName|type|operator|value


    return paramsObj;
  }

  ngOnInit() {
    if (!this.advanceCriteriaQuery ) {
      // tslint:disable-next-line:max-line-length
      // this.store.dispatch(new advanceSearchActions.PutAdvanceSearch({ tagName: null, operator: null, type: null, value: null, defaultTag: false}));
    }
    this.buildForm();

  }

  ngOnDestroy() {
    this.subscriberPageSize.unsubscribe();
    this.subscriberDomain.unsubscribe();
    this.subscriberAdvanceQuery.unsubscribe();
  }


}
