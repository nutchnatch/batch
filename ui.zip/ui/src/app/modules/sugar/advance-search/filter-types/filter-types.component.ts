import { Store, select } from '@ngrx/store';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { Observable } from 'rxjs';

import * as fromRoot from 'app/reducers';
import * as advanceSearchActions from 'app/actions/advance-search.actions';
import { Subscription } from 'rxjs';
import { FormGroup, FormArray } from '@angular/forms';

@Component({
  selector: 'app-filter-types',
  templateUrl: './filter-types.component.html',
  styleUrls: ['./filter-types.component.scss']
})
export class FilterTypesComponent implements OnInit, OnDestroy {

  @Input() formGroup: FormGroup;

  public currentLang$: Observable<string>;
  isAdvanceSearch$: Observable<boolean>;
  public domainsSelected$: Observable<any>;
  public subDomainsSelected: Subscription;

  domainsSelected;
  domainsSelectedId;
  selected;

  constructor(
    public store: Store<fromRoot.State>,
  ) {
    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.domainsSelected$ = store.pipe(select(fromRoot.getAdvanceSearchDomainSelected));

    this.subDomainsSelected = this.domainsSelected$.subscribe(domainsSelected => {
      this.domainsSelected = domainsSelected;

    });


    this.isAdvanceSearch$ = store.pipe(select(fromRoot.getLayoutAdvanceSearch ));
    this.isAdvanceSearch$.subscribe( bool => !bool && this.reset());
  }

  reset() {

    this.store.dispatch(new advanceSearchActions.RemoveAllAdvanceSearch());
    this.formGroup.controls['advanceSearchQuery'].reset();

    this.formGroup.removeControl('advanceSearchQuery');
    // console.log(this.formGroup.get('advanceSearchQuery').)
    this.formGroup.addControl('advanceSearchQuery', new FormArray([]));
    // tslint:disable-next-line:max-line-length
    this.store.dispatch(new advanceSearchActions.PutAdvanceSearch({ tagName: null, operator: null, type: null, value: null, defaultTag: false }));
  }

  updateState() {
    const extraFieldSelected = this.domainsSelected.filter(types => types.id === this.formGroup.get('filterId').value);
    this.formGroup.controls.filterId.setValue(extraFieldSelected[0].id);
    this.store.dispatch(new advanceSearchActions.PutTagsList(extraFieldSelected));
    // this.store.dispatch(new advanceSearchActions.PutTypeId(this.domainsSelectedId));
  }

  onChange() {
    this.updateState();
    this.reset();
  }

  onFilter() {
    // console.log(this.selected, this.domainsSelectedId)
    if (!this.selected) {
      this.formGroup.controls.filterId.reset();
      this.domainsSelectedId = null;
      this.store.dispatch(new advanceSearchActions.PutTagsList(this.domainsSelected));
    }
  }

  ngOnInit() {
  }


  ngOnDestroy() {
    this.subDomainsSelected.unsubscribe();
  }

}
