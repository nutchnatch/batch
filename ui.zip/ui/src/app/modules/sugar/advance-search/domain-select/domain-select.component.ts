import { Subscription } from 'rxjs';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import * as searchPagedAction from 'app/actions/search-paged.actions';

import * as fromRoot from 'app/reducers';
import * as advanceSearchActions from 'app/actions/advance-search.actions';
import { Router } from '@angular/router';


@Component({
  selector: 'app-domain-select',
  templateUrl: './domain-select.component.html',
  styleUrls: ['./domain-select.component.scss']
})
export class DomainSelectComponent implements OnInit, OnDestroy {

  @Input() formGroup: any;

  searchList$: Observable<Object>;
  extraFields$: Observable<any>;
  domain$: Observable<string>;

  subscriberExtraFields: Subscription;
  subscriberDomain: Subscription;
  controlsArray;
  extraFields;
  type;
  extraFieldSelected;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router,
  ) {
    this.searchList$ = store.pipe(select(fromRoot.getAppConfigSearchTypes));
    this.extraFields$ = store.pipe(select(fromRoot.getExtraFields));
    this.subscriberExtraFields = this.extraFields$.subscribe(extraFields => this.extraFields = extraFields);

    this.domain$ = store.pipe(select(fromRoot.getAdvanceSearchDomain));

    this.subscriberDomain = this.domain$.subscribe(domain => {
      if (domain) {
        this.type = domain;
        // this.store.dispatch(new advanceSearchActions.RemoveAllAdvanceSearch());
        // const baseUrl = 'app/' + this.type.toLowerCase();
        // this.router.navigate([ baseUrl ]);
      }
    });
    // this.subscriberExtraFields = this.extraFields$.subscribe(extraFields => this.extraFields = extraFields);
  }

  updateExtraFields() {

    // if (!this.controlsArray) {
    //   this.controlsArray = <FormArray>this.formGroup.controls['advanceSearchQuery'];
    // } else {
    //   this.controlsArray.controls = [];
    // }


    // let extraFieldSelected;
    switch (this.type) {
      case 'Documents':
        this.extraFieldSelected = this.extraFields['metadataFields'];
        break;
      case 'Folders':
        this.extraFieldSelected = this.extraFields['folderMetadataFields'];
        break;
      case 'Envelopes':
        this.extraFieldSelected = this.extraFields['envelopeMetadataFields'];
        break;
      default:
        this.extraFieldSelected = this.extraFields['metadataFields'];

    }

    this.store.dispatch(new advanceSearchActions.PutDomainSelected(this.extraFieldSelected));
    this.store.dispatch(new advanceSearchActions.PutTagsList(this.extraFieldSelected));

    // const baseUrl = 'app/' + this.type.toLowerCase();
    // if ( !this.router.url.match(this.type.toLowerCase()) ) { this.router.navigate([baseUrl]); }
    this.store.dispatch(new searchPagedAction.PutSearchResultsType(this.type));

  }

  onChangeType(type) {
    this.store.dispatch(new advanceSearchActions.PutDomain(type));
    this.store.dispatch(new advanceSearchActions.RemoveAllAdvanceSearch());
    // tslint:disable-next-line:max-line-length
    this.store.dispatch(new advanceSearchActions.PutAdvanceSearch({ tagName: null, operator: null, type: null, value: null, defaultTag: false}));

    this.updateExtraFields();
  }

  ngOnInit() {
    // console.log(this.type)
    this.updateExtraFields();
    // console.log(this.formGroup)
  }

  ngOnDestroy() {
    this.subscriberExtraFields.unsubscribe();
    this.subscriberDomain.unsubscribe();
  }

}
