import { FormControl, Validators, FormGroup, FormArray } from '@angular/forms';
import { ExtraFields } from './../../../../states/extra-fields.state';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as advanceSearchActions from 'app/actions/advance-search.actions';
import { Subscription } from 'rxjs';

import { filter } from 'lodash';

@Component({
  selector: 'app-type-select',
  templateUrl: './type-select.component.html',
  styleUrls: ['./type-select.component.scss']
})
export class TypeSelectComponent implements OnInit, OnDestroy {

  @Input() formGroup: FormGroup;
  @Input() index: number;
  @Input() length: number;
  @Input() last: boolean;
  @Input() first: boolean;
  @Input() modal = false;
  @Input() item;

  public confidentialLevel$: Observable<Array<any>>;

  public currentLang$: Observable<string>;
  public tagsList$: Observable<Array<ExtraFields>>;
  public advanceQuery$: Observable<string>;
  public subAdvanceQuery: Subscription;
  public subTagsList: Subscription;

  public operators$: Observable<Array<string>>;
  public operatorsTags$: Observable<Array<string>>;
  public subOperators: Subscription;

  public currentTypeSearch$: Observable<string>;


  public tagSelectedList;

  operatorsSelected;
  tagsList;
  tagSelected;
  operators;
  formArray: FormArray;
  // last: boolean = false;
  dpValues = null;
  dpToValue = null;
  tagAlreadySelected = false;
  minus = false;

  type: ExtraFields;
  oldState: ExtraFields;
  allValues: string;
  toAdd: boolean;

  constructor(
    public store: Store<fromRoot.State>,
  ) {
    // this.memoryState = { tagName: '', operator: '', type: '', value: '', defaultTag: false, selected: true };

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.tagsList$ = store.pipe(select(fromRoot.getAdvanceSearchTagsList));
    // this.tagsList$.subscribe( v => console.log(v) );

    this.subTagsList = this.tagsList$.subscribe(tagsList => this.tagsList = tagsList);

    this.operators$ = store.pipe(select(fromRoot.getAdvanceSearchDefaultOperators));
    this.subOperators = this.operators$.subscribe(operators => this.operators = operators);

    this.operatorsTags$ = store.pipe(select(fromRoot.getAdvanceSearchOperatorsTags));
    this.currentTypeSearch$ = store.pipe(select(fromRoot.getSearchPagedType));

    this.confidentialLevel$ = store.pipe(select(fromRoot.getAppConfigConfidentialLevels));

  }

  setDefaults(type) {
    // const fg: any = this.formGroup.controls['advanceSearchQuery'];
    this.tagSelected = filter(this.tagsList, tag => tag.name === type);
    this.operatorsSelected = this.operators[0][this.tagSelected[0].type];
    this.store.dispatch(new advanceSearchActions.PutTagsSelected({ tagName: type, selected: true }));

  }

  onSelectOperator(operator) {
    const fg: any = this.formGroup.controls['advanceSearchQuery'];
    // console.log(operator)
    if (operator === 'between') {
      fg.controls[this.index].get('toValue').setValidators([Validators.required]);
    } else {
      fg.controls[this.index].get('toValue').clearValidators();
    }
    fg.controls[this.index].get('toValue').updateValueAndValidity();
  }

  onChange(type) {
    // console.log(this.index, this.oldState, type)
    this.setDefaults(type);

    const fg: any = this.formGroup.controls['advanceSearchQuery'];

    fg.controls[this.index].setValue(Object.assign(fg.controls[this.index].value, {
      operator: this.operatorsSelected[0].type ? this.operatorsSelected[0].type : '',
      type: this.tagSelected[0].type ? this.tagSelected[0].type : '',
      value: this.tagSelected[0].value ? this.tagSelected[0].value : '',
      toValue: this.tagSelected[0].toValue ? this.tagSelected[0].toValue : '',
      tagName: this.tagSelected[0].name,
      defaultTag: this.tagSelected[0].default ? this.tagSelected[0].default : false,
      selected: true
    }));

    if (fg.controls[this.index].value.tagName === 'validity') {
      fg.controls[this.index].setValue(Object.assign(fg.controls[this.index].value, {
        operator: 'VALIDITY'
      }));
    }

    if (fg.controls[this.index].value.tagName === 'statusCode') {
      fg.controls[this.index].setValue(Object.assign(fg.controls[this.index].value, {
        operator: 'STATUS_CODE'
      }));
    }

    if (fg.controls[this.index].value.type === 'boolean' || fg.controls[this.index].value.type === 'confidentiality') {
      fg.controls[this.index].setValue(Object.assign({}, fg.controls[this.index].value, {
        operator: 'equals_to'
      }));
    }


    this.oldState = type;
    this.type = type;

    if (!this.modal) {
      this.store.dispatch(new advanceSearchActions.PutAdvanceSearchWithValues(this.formGroup.controls['advanceSearchQuery'].value));
    } else {
      this.store.dispatch(new advanceSearchActions.PutAdvanceSearchModalWithValues(this.formGroup.controls['advanceSearchQuery'].value));
    }
    // this.updateSearchState(fg.controls[this.index].value, this.index);PutAdvanceSearchById
  }

  addRow() {
    this.minus = this.index === this.length - 1;
    // this.store.dispatch(new advanceSearchActions.PutAdvanceSearchById( searchQueryString.value['advanceSearchQuery'] ));
    if (!this.modal) {
      // tslint:disable-next-line:max-line-length
      this.store.dispatch(new advanceSearchActions.PutAdvanceSearch({ tagName: null, operator: null, type: null, value: null, defaultTag: false }));

    } else {
      // tslint:disable-next-line:max-line-length
      this.store.dispatch(new advanceSearchActions.PutAdvanceSearchModal({ tagName: null, operator: null, type: null, value: null, defaultTag: false }));

    }

  }

  removeRow(index: number) {
    if (this.subAdvanceQuery) { this.subAdvanceQuery.unsubscribe(); }

    // tslint:disable-next-line:max-line-length
    this.store.dispatch(new advanceSearchActions.PutTagsSelected({ tagName: this.formArray.controls[this.index].value.tagName, selected: false }));

    const controls = <FormArray>this.formGroup.controls['advanceSearchQuery'];
    controls.removeAt(index);
    if (!this.modal) {
      this.store.dispatch(new advanceSearchActions.RemoveAdvanceSearchByID(index));
    } else {
      this.store.dispatch(new advanceSearchActions.RemoveAdvanceSearchByIDModal(index));

    }
  }

  addDeafultsFG(typeValue) {
    if (typeValue && typeValue[this.index]) {
      // debugger
      // const tag = typeValue[this.index];
      const tag = this.item;
      // console.log(tag)

      if (this.formArray.length <= this.index && !this.toAdd) {
        const fg: FormGroup = new FormGroup({
          tagName: new FormControl(tag['tagName'], Validators.required),
          operator: new FormControl(tag['operator'], Validators.required),
          type: new FormControl(tag['type'], Validators.required),
          value: new FormControl(tag['value'], Validators.required),
          toValue: new FormControl(tag['toValue']),
          defaultTag: new FormControl(tag['defaultTag']),
          selected: new FormControl(true),
        });
        this.formArray.push(fg);
      }

      if (tag['tagName']) {

        if (!this.dpValues && tag['type'] === 'timestamp') {
          this.dpValues = tag['value'];
        }
        if (!this.dpToValue && tag['type'] === 'timestamp' && tag['operator'] === 'between') {
          this.dpToValue = tag['toValue'];
        }

        this.setDefaults(tag['tagName']);
        this.setOldState(tag['tagName']);
      }
    }

  }

  setOldState(type) {

    // if (!this.modal) {
    this.oldState = type;
    // this.type = type;
    // }
  }

  ngOnInit() {
    this.advanceQuery$ = this.store.pipe(select(!this.modal ? fromRoot.getAdvanceSearchQuery : fromRoot.getAdvanceSearchQueryModal));

    this.formArray = <FormArray>this.formGroup.controls['advanceSearchQuery'];
    this.subAdvanceQuery = this.advanceQuery$.subscribe(typeValue => {
      // this.allValues = typeValue;
      this.addDeafultsFG(typeValue);
    });
  }

  ngOnDestroy() {
    this.subTagsList.unsubscribe();
    this.subOperators.unsubscribe();

    if (this.subAdvanceQuery) { this.subAdvanceQuery.unsubscribe(); }
    if (this.oldState) {
      this.store.dispatch(new advanceSearchActions.PutTagsSelected({ tagName: this.oldState, selected: false }));
      this.oldState = null;
    }

  }
}
