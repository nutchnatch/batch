import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Observable, Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { ActivatedRoute } from '@angular/router';
import { Router } from 'testing/router.stub';
import { Component, Input } from '@angular/core';

import * as fromRoot from 'app/reducers';

@Component({
  selector: 'app-table-sortable-col',
  templateUrl: './table-sortable-col.component.html',
  styleUrls: ['./table-sortable-col.component.scss']
})
export class TableSortableColComponent implements OnDestroy {

  @Input() orderField: string;

  searchQuery$: Observable<any>;
  subscriberSearchQuery: Subscription;
  searchQuery: any;

  orderAscending: string;
  orderFieldState: string;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router,
    public activatedRouter: ActivatedRoute
  ) {

    this.searchQuery$ = this.store.pipe(select(fromRoot.getSearchPagedQuery));
    this.subscriberSearchQuery = this.searchQuery$.subscribe(query => {
      this.searchQuery = query;
      this.orderFieldState = this.searchQuery.orderField;
      this.orderAscending = '' + this.searchQuery.orderAscending;
    });
  }

  sort() {
    const baseUrl = 'app/' + this.activatedRouter.snapshot.routeConfig.path;

    // tslint:disable-next-line:max-line-length
    const orderAscending = this.setOrderAscending( this.searchQuery.orderField === this.orderField ? this.orderAscending : null);
    // tslint:disable-next-line:max-line-length
    this.router.navigate([baseUrl], { queryParams: Object.assign({}, this.searchQuery, { orderAscending: orderAscending, orderField: this.orderField }) });
  }

  setOrderAscending(oldState) {
    if (oldState === 'true') { this.orderAscending = 'false'; return 'false'; }
    if (oldState === 'false') { this.orderAscending = null; return null; }
    if (oldState === 'undefined' || oldState === null) { this.orderAscending = 'true'; return 'true'; }
  }

  ngOnDestroy() {
    if (this.subscriberSearchQuery) {
      this.subscriberSearchQuery.unsubscribe();
    }
  }
}
