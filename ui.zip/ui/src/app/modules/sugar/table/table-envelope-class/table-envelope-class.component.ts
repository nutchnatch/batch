import { PutEnvelopeTypesUpdatingInit } from 'app/actions/envelope-types.actions';
import { BusinessScopeEffect } from 'app/effects/business-scope.effect';
import { EnvelopeTypeEffect } from 'app/effects/envelope-types.effects';
import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Router } from '@angular/router';
import { Tag } from 'app/models/tag';

import * as fromRoot from 'app/reducers';
import * as searchPreviewAction from 'app/actions/search-preview.actions';
import { EnvelopeTypes } from 'app/models/envelope-types';
import { DocumentTypesAndTagsEffect } from 'app/effects/document-types-and-tags.effects';
import { find } from 'lodash';

@Component({
  selector: 'table-envelope-class',
  templateUrl: './table-envelope-class.component.html',
  styleUrls: ['./table-envelope-class.component.scss']
})
export class TableEnvelopeClassComponent implements OnInit, OnDestroy {

  public searchResult$: Observable<Document[]>;

  public compactTables$: Observable<boolean>;
  public previewIndex$: Observable<any>;
  public pageSizeList$: Observable<Array<number>>;
  public currentLang$: Observable<string>;

  public tooglingState$: Observable<boolean>;
  public tooglingStateId$: Observable<string>;
  public tooglingError$: Observable<Error>;
  public tooglingResult$: Observable<Array<any>>;

  // public subsrcribeCurrentLang: Subscription;
  public subscrisbePreviewIndex: Subscription;
  public subscriberenvelopeClasses: Subscription;
  public subscriberEnvelopeTypesResult: Subscription;
  public envelopeClasses$: Observable<Array<Tag>>;

  previewIndex: string;
  tag;
  oldTag: Tag;

  constructor(
    public store: Store<fromRoot.State>,
    public envelopeTypeEffect: EnvelopeTypeEffect,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,
    public businessScopeEffect: BusinessScopeEffect,

    public router: Router
  ) {
    // this.searchResult$ =store.pipe(select(fromRoot.getSearchPagedResults);
    this.previewIndex$ = store.pipe(select(fromRoot.getSearchPreviewResultId));
    this.subscrisbePreviewIndex = this.previewIndex$.subscribe(id => this.previewIndex = id);

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.compactTables$ = store.pipe(select(fromRoot.getLayoutTableCompact));

    this.envelopeClasses$ = store.pipe(select(fromRoot.getEnvelopeTypesResultNoFilter));

    this.subscriberenvelopeClasses = this.envelopeClasses$.subscribe(tags => {
      // console.log(tags, this.previewIndex)
      if (tags && this.previewIndex) {
        const tag = find(tags, (t) => t.id === this.previewIndex);
        // console.log( tag )
        this.preview(tag);
      }

      if (tags && !this.previewIndex) {
        this.preview(tags[0]);
      }

    });

    this.tooglingState$ = store.pipe(select(fromRoot.getEnvelopeTypesTooglingState));
    this.tooglingStateId$ = store.pipe(select(fromRoot.getEnvelopeTypesTooglingStateId));
    this.tooglingError$ = store.pipe(select(fromRoot.getEnvelopeTypesTooglingStateError));
    this.tooglingResult$ = store.pipe(select(fromRoot.getEnvelopeTypesTooglingStateResult));

    this.subscriberEnvelopeTypesResult = this.tooglingResult$.subscribe(result => {
      if (result) {
        // this.preview(this.tag);
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
        this.businessScopeEffect.getBusinessScope();
      }
    });

  }

  preview(tag: Tag): void {

    if (tag) {
      // this.tag = tag;
      this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(tag));
      this.store.dispatch(new searchPreviewAction.PutSearchTypeSearchPreview('tags'));
    }
    if (!this.oldTag || tag.id !== this.oldTag.id) {
      this.oldTag = tag;
      this.store.dispatch(new PutEnvelopeTypesUpdatingInit);
    }
  }

  onChange(envType: EnvelopeTypes) {
    if (envType.active) {
      this.envelopeTypeEffect.putEnvelopeTypesDeactivate(envType.id, envType.version);
    } else {
      this.envelopeTypeEffect.putEnvelopeTypesActivate(envType.id, envType.version);
    }
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscrisbePreviewIndex.unsubscribe();
    this.subscriberenvelopeClasses.unsubscribe();
    this.subscriberEnvelopeTypesResult.unsubscribe();
    this.store.dispatch(new searchPreviewAction.PutSearchTypeSearchPreview(null));
    this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview());
  }

}
