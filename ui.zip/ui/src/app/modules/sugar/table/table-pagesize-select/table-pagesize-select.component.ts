import { Subscription } from 'rxjs';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Component, OnDestroy, Input, OnInit } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as appConfigActions from 'app/actions/app-config.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';

import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-table-pagesize-select',
  templateUrl: './table-pagesize-select.component.html',
  styleUrls: ['./table-pagesize-select.component.scss']
})
export class TablePagesizeSelectComponent implements OnInit, OnDestroy {

  @Input() modalMode: boolean;
  // @Output()

  pageSize$: Observable<number>;
  pageSizeList$: Observable<Array<number>>;
  subscriberPageSize: Subscription;

  searchQuery$: Observable<any>;
  subscriberSearchQuery: Subscription;

  searchType$: Observable<string>;
  searchType: string;
  subscriberSearchType: Subscription;

  pageSize: number;
  searchQuery: any;
  isModalMode: boolean;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router,
    public activatedRouter: ActivatedRoute

  ) {
    this.pageSize$ = this.store.pipe(select(fromRoot.getAppConfigPageSize));
    this.subscriberPageSize = this.pageSize$.subscribe(value => this.pageSize = value);

    this.pageSizeList$ = this.store.pipe(select(fromRoot.getAppConfigPageSizeList));

    this.searchQuery$ = this.store.pipe(select(fromRoot.getSearchPagedQuery));
    this.subscriberSearchQuery = this.searchQuery$.subscribe(query => this.searchQuery = query);

    this.searchType$ = this.store.pipe(select(fromRoot.getSearchPagedType));
    this.subscriberSearchType = this.searchType$.subscribe(type => this.searchType = type);

  }

  updateSelectedValue(event: number) {
    this.store.dispatch(new appConfigActions.PutPageSizeAction(event));
    if (this.isModalMode) {
      // Object.assign({}, this.searchQuery, { pageSize: event })
      // tslint:disable-next-line:max-line-length
      this.store.dispatch(new searchPagedAction.PutSearchResultsQuery(Object.assign({}, this.searchQuery, { pageNumber: 1, pageSize: event })));
    } else if (this.activatedRouter.snapshot.data.type === 'BASKET') {
      // tslint:disable-next-line:max-line-length
      const id = this.activatedRouter.snapshot.url[1] ? '/' + this.activatedRouter.snapshot.url[1] : '';
      // tslint:disable-next-line:max-line-length
      this.router.navigate(['app/' + this.searchType + id], { queryParams: Object.assign({}, this.searchQuery, { pageNumber: 1, pageSize: event }) });

    } else {
      // tslint:disable-next-line:max-line-length
      this.router.navigate(['app/' + this.searchType], { queryParams: Object.assign({}, this.searchQuery, { pageNumber: 1, pageSize: event }) });
    }
  }

  ngOnInit() {
    this.isModalMode = this.modalMode;
  }

  ngOnDestroy() {
    this.subscriberPageSize.unsubscribe();
    this.subscriberSearchQuery.unsubscribe();
    this.subscriberSearchType.unsubscribe();
  }

}
