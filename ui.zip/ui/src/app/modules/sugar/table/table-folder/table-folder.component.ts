import { getFolderTypesResultNoFilter } from './../../../../reducers/folder-types.reducer';
import { FolderTypes } from 'app/models/folder-types';
import { Subscription } from 'rxjs';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { Folder } from 'app/models/folder';
import { Paging } from 'app/models/paging';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
// import * as foldersFilterAction from 'app/actions/folder-filter.actions';
import * as searchPagedActions from 'app/actions/search-paged.actions';
import * as searchFolderToAttachActions from 'app/actions/search-folder-to-attach.actions';

import { find } from 'lodash';
import { Router } from '@angular/router';


@Component({
  selector: 'app-table-folder',
  templateUrl: './table-folder.component.html',
  styleUrls: ['./table-folder.component.scss']
})
export class TableFolderComponent implements OnInit, OnDestroy {

  @Input() modalMode: boolean;

  public searchResult$: Observable<Folder[]>;
  public pagingResult$: Observable<Paging>;
  public compactTables$: Observable<boolean>;
  public previewIndex$: Observable<any>;
  public pageSizeList$: Observable<Array<number>>;
  public currentLang$: Observable<string>;
  public folderIdToAttach$: Observable<string>;

  public subsrcribeCurrentLang: Subscription;
  public subscrisbePreviewIndex: Subscription;

  public tableCompactState: boolean;
  public previewIndex: number = null;

  public folderTypes$: Observable<Array<FolderTypes>>;
  public subsciberFolderType: Subscription;

  folderTypes: Array<FolderTypes>;
  currentLang: string;
  isModalMode: boolean;
  folderToAttach: string;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router

  ) {

    // this.modalMode = false;

    this.searchResult$ = store.pipe(select(fromRoot.getSearchPagedResults));
    this.previewIndex$ = store.pipe(select(fromRoot.getSearchPreviewResultId));
    this.subscrisbePreviewIndex = this.previewIndex$.subscribe( id => this.previewIndex = id);

    this.compactTables$ = store.pipe(select(fromRoot.getLayoutTableCompact));
    // this.compactTables$.subscribe(compact => this.tableCompactState = compact );

    this.pageSizeList$ = store.pipe(select(fromRoot.getAppConfigPageSizeList));

    this.folderTypes$ = store.pipe(select(fromRoot.getFolderTypesResultNoFilter));
    this.subsciberFolderType = this.folderTypes$.subscribe(folderTypes => {
      this.folderTypes = folderTypes;
    });

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.subsrcribeCurrentLang = this.currentLang$.subscribe(currentLang => {
      this.currentLang = currentLang.toUpperCase();
    });

    /** IF is a Modal */
    this.folderIdToAttach$ = store.pipe(select(fromRoot.getSearchFolderToAttachResultId));
    // this.folderIdToAttach$.subscribe(v => console.log(v))

  }

  changeTableStyle() {
    this.store.dispatch(new layoutActions.PutCompactTableAction( !this.tableCompactState ));
  }

  preview(doc: Folder): void {
    if ( doc.id === '' + this.previewIndex ) {
      this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
      this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview(null));
    } else {
      this.store.dispatch(new searchPreviewActions.PutSearchResultsSearchPreview(doc));
      this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview('folders'));
    }
  }

  selectedFolder(doc: Folder) {
    // this.store.dispatch( new foldersFilterAction.PutFolderSeleced( doc.id ) );
  }

  getFolderTypeName(id: string, version: number): string {

    const folderType: FolderTypes = find(this.folderTypes, { id: id });
    if (!folderType) {
      // this.envelopeTypeEffect.getEnvelopeTypeById(id, version);
      return 'Error';
    }
    const displayName = find(folderType.displayNameList, { language: this.currentLang });
    return displayName['value'];
  }

  getFolderTypeActive(id: string, version: number): boolean {

    const folderType: FolderTypes = find(this.folderTypes, { id: id });
    if (!folderType) {
      // this.envelopeTypeEffect.getEnvelopeTypeById(id, version);
      return;
    }
    return folderType.active;
  }

  fromSearch() {
    this.store.dispatch(new layoutActions.PutFromSearchAction(this.router.url));
  }

  attachThis(doc) {
    this.store.dispatch(new searchFolderToAttachActions.PutSearchFolderIdToAttach(doc.id) );
  }

  ngOnInit() {
    this.isModalMode = this.modalMode;
  }

  ngOnDestroy() {
    // this.store.dispatch( new searchPagedActions.InitSearchResults);
    this.subscrisbePreviewIndex.unsubscribe();
    this.subsciberFolderType.unsubscribe();
    this.subsrcribeCurrentLang.unsubscribe();
  }
}
