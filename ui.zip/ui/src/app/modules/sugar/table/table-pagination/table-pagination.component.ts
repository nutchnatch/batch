import { Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Paging } from 'app/models/paging';
import { Observable } from 'rxjs';
import { Component, OnDestroy, Input, OnInit } from '@angular/core';


import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-table-pagination',
  templateUrl: './table-pagination.component.html',
  styleUrls: ['./table-pagination.component.scss']
})
export class TablePaginationComponent implements OnInit, OnDestroy {

  @Input() modalMode: boolean;

  paging$: Observable<Paging>;
  page: number;
  subscriberPaging: Subscription;

  searchQuery$: Observable<any>;
  searchQuery: any;
  subscriberSearchQuery: Subscription;

  searching$: Observable<boolean>;

  searchType$: Observable<string>;
  searchType: string;
  subscriberSearchType: Subscription;

  isModalMode: boolean;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router,
    public activatedRouter: ActivatedRoute

  ) {

    this.paging$ = store.pipe(select(fromRoot.getSearchPagedPaging));
    this.subscriberPaging = this.paging$.subscribe(page => { if (page) { this.page = page.currentPage; }});

    this.searchQuery$ = this.store.pipe(select(fromRoot.getSearchPagedQuery));
    this.subscriberSearchQuery = this.searchQuery$.subscribe(query => this.searchQuery = query);

    this.searching$ = this.store.pipe(select(fromRoot.getSearchPagedLoading));

    this.searchType$ = this.store.pipe(select(fromRoot.getSearchPagedType));
    this.subscriberSearchType = this.searchType$.subscribe(type => this.searchType = type);

  }

  pageChange(page) {
    if (page) {

      if (this.isModalMode) {
        this.store.dispatch(new searchPagedAction.PutSearchResultsQuery(Object.assign({}, this.searchQuery, { pageNumber: page })));
      } else if (this.activatedRouter.snapshot.data.type === 'BASKET') {
        // tslint:disable-next-line:max-line-length
        const id = this.activatedRouter.snapshot.url[1] ? '/' + this.activatedRouter.snapshot.url[1] : '';
        this.router.navigate(['app/' + this.searchType + id ], { queryParams: Object.assign({}, this.searchQuery, { pageNumber: page }) });

      } else {
        this.router.navigate(['app/' + this.searchType], { queryParams: Object.assign({}, this.searchQuery, { pageNumber: page }) });
      }
    }
  }

  ngOnInit() {
    this.isModalMode = this.modalMode;
  }
  ngOnDestroy() {
    this.subscriberPaging.unsubscribe();
    this.subscriberSearchQuery.unsubscribe();
    this.subscriberSearchType.unsubscribe();

  }
}
