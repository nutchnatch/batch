import { find } from 'lodash';
import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Router } from '@angular/router';
import { Tag } from 'app/models/tag';

import * as fromRoot from 'app/reducers';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';


@Component({
  selector: 'app-table-tag-class',
  templateUrl: './table-tag-class.component.html',
  styleUrls: ['./table-tag-class.component.scss']
})
export class TableTagClassComponent implements OnInit, OnDestroy {

  public searchResult$: Observable<Document[]>;

  public compactTables$: Observable<boolean>;
  public previewIndex$: Observable<any>;
  public pageSizeList$: Observable<Array<number>>;
  public currentLang$: Observable<string>;

  public subscrisbePreviewIndex: Subscription;
  public subscriberTagResult: Subscription;
  public tagResult$: Observable<Array<Tag>>;
  public tagType$: Observable<any>;
  public subscriberTagReadable: Subscription;
  public tagsReadable: any;

  previewIndex: string;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router
  ) {
    // this.searchResult$ =store.pipe(select(fromRoot.getSearchPagedResults);
    this.previewIndex$ = store.pipe(select(fromRoot.getSearchPreviewResultId));
    this.subscrisbePreviewIndex = this.previewIndex$.subscribe( id => this.previewIndex = id);

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.compactTables$ = store.pipe(select(fromRoot.getLayoutTableCompact));

    this.tagType$ = store.pipe(select(fromRoot.getAppConfigTagType));


    this.subscriberTagReadable = this.tagType$.subscribe(tags => {
      if (tags) {
        this.tagsReadable = tags;
      }
    });

    this.tagResult$ = store.pipe(select(fromRoot.getTagsResult));
    this.subscriberTagResult = this.tagResult$.subscribe( tags => {
      if (tags && !this.previewIndex) {
        this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(tags[0]));
        this.store.dispatch(new searchPreviewAction.PutSearchTypeSearchPreview('tags'));
      }
    });

   }

   preview(tag: Tag): void {
     if (tag) {
      this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(tag));
      this.store.dispatch(new searchPreviewAction.PutSearchTypeSearchPreview('tags'));
     }

  }

  getReadableName(internalName: string): string {
    return find(this.tagsReadable, {value: internalName})['label'];
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscrisbePreviewIndex.unsubscribe();
    this.subscriberTagResult.unsubscribe();
    this.subscriberTagReadable.unsubscribe();
    this.store.dispatch(new searchPreviewAction.PutSearchTypeSearchPreview(null));
    this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview());
  }

}
