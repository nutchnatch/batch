/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { TableTagClassComponent } from './table-tag-class.component';

describe('TableTagClassComponent', () => {
  let component: TableTagClassComponent;
  let fixture: ComponentFixture<TableTagClassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TableTagClassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableTagClassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
