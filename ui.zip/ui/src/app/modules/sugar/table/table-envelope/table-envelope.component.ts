import { EnvelopeTypes } from 'app/models/envelope-types';
import { Subscription } from 'rxjs';
import { Envelope } from 'app/models/envelope';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy, Input} from '@angular/core';
import { Paging } from 'app/models/paging';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';

import { find } from 'lodash';
import { Router } from 'testing/router.stub';

@Component({
  selector: 'app-table-envelope',
  templateUrl: './table-envelope.component.html',
  styleUrls: ['./table-envelope.component.scss']
})
export class TableEnvelopeComponent implements OnInit, OnDestroy {

  @Input() modalMode: boolean;

  public searchResult$: Observable<Envelope[]>;
  public pagingResult$: Observable<Paging>;
  public compactTables$: Observable<boolean>;
  public previewIndex$: Observable<any>;
  public pageSizeList$: Observable<Array<number>>;
  public currentLang$: Observable<string>;

  public subscrisbePreviewIndex: Subscription;
  public subsrcribeCurrentLang: Subscription;

  public tableCompactState: boolean;
  public previewIndex: number = null;

  public envelopeTypes$: Observable<Array<EnvelopeTypes>>;
  public subsciberEnvelopeType: Subscription;

  envTypes: Array<EnvelopeTypes>;
  currentLang: string;
  isModalMode: boolean;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router
  ) {
    this.searchResult$ = store.pipe(select(fromRoot.getSearchPagedResults));
    this.previewIndex$ = store.pipe(select(fromRoot.getSearchPreviewResultId));
    this.subscrisbePreviewIndex = this.previewIndex$.subscribe(id => this.previewIndex = id);

    this.compactTables$ = store.pipe(select(fromRoot.getLayoutTableCompact));
    // this.compactTables$.subscribe(compact => this.tableCompactState = compact );

    this.pageSizeList$ = store.pipe(select(fromRoot.getAppConfigPageSizeList));

    this.envelopeTypes$ = store.pipe(select(fromRoot.getEnvelopeTypesResultNoFilter));
    this.subsciberEnvelopeType = this.envelopeTypes$.subscribe(envTypes => {
      // console.log(envTypes)
      this.envTypes = envTypes;
    });

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.subsrcribeCurrentLang = this.currentLang$.subscribe(currentLang => {
      this.currentLang = currentLang.toUpperCase();
    });

  }

  changeTableStyle() {
    this.store.dispatch(new layoutActions.PutCompactTableAction(!this.tableCompactState));
  }

  preview(env: Envelope): void {
    if ( env.id === '' + this.previewIndex ) {
      this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
      this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview(null));
    } else {
      this.store.dispatch(new searchPreviewActions.PutSearchResultsSearchPreview(env));
      this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview('envelopes'));
    }
  }

  selectedEnvelope(env: Envelope) {

    // getEnvelopeTypeById
    // this.store.dispatch( new documentsFilterAction.PutDocumentSeleced( doc.id ) );
  }

  fromSearch() {
    this.store.dispatch(new layoutActions.PutFromSearchAction(this.router.url));
  }


  getEnvelopeTypeName(id: string, version: number): string {
    const envType: EnvelopeTypes = find(this.envTypes, { id: id });
    if (!envType) {
      return 'Error';
    }
    const displayName = find(envType.displayNameList, { language: this.currentLang });
    if (!displayName && displayName === undefined) {
      return '- missing translation -';
    }
    return displayName['value'];
  }

  getEnvelopeTypeActive(id: string, version: number): boolean {
    const envType: EnvelopeTypes = find(this.envTypes, { id: id });
    if (!envType) {
      return;
    }
    return envType.active;
  }

  ngOnInit() {
    this.isModalMode = this.modalMode;
  }

  ngOnDestroy() {
    // this.store.dispatch( new searchPagedActions.InitSearchResults);
    this.subscrisbePreviewIndex.unsubscribe();
    this.subsciberEnvelopeType.unsubscribe();
    this.subsrcribeCurrentLang.unsubscribe();
  }

}
