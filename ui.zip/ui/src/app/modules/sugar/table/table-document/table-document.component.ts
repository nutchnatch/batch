import { DocumentTypes } from './../../../../models/document-types';
import { Subscription } from 'rxjs';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Document } from 'app/models/document';
import { Paging } from 'app/models/paging';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
import * as layoutAction from 'app/actions/layout.actions';

import { find } from 'lodash';
import { Router } from '@angular/router';


@Component({
  selector: 'app-table-document',
  templateUrl: './table-document.component.html',
  styleUrls: ['./table-document.component.scss']
})
export class TableDocumentComponent implements OnInit, OnDestroy {

  public searchResult$: Observable<Document[]>;
  public pagingResult$: Observable<Paging>;
  public compactTables$: Observable<boolean>;
  public previewIndex$: Observable<any>;
  public pageSizeList$: Observable<Array<number>>;
  public currentLang$: Observable<string>;

  public subsrcribeCurrentLang: Subscription;
  public subscrisbePreviewIndex: Subscription;

  public tableCompactState: boolean;
  public previewIndex: number = null;

  public documentTypes$: Observable<Array<DocumentTypes>>;
  public subsciberDocumentType: Subscription;

  docTypes: Array<DocumentTypes>;
  currentLang: string;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router
  ) {

    this.searchResult$ = store.pipe(select(fromRoot.getSearchPagedResults));
    this.previewIndex$ = store.pipe(select(fromRoot.getSearchPreviewResultId));
    this.subscrisbePreviewIndex = this.previewIndex$.subscribe( id => this.previewIndex = id);

    this.compactTables$ = store.pipe(select(fromRoot.getLayoutTableCompact));
    // this.compactTables$.subscribe(compact => this.tableCompactState = compact );

    this.pageSizeList$ = store.pipe(select(fromRoot.getAppConfigPageSizeList));

    this.documentTypes$ = store.pipe(select(fromRoot.getDocumentTypesResultNoFilter));
    this.subsciberDocumentType = this.documentTypes$.subscribe(docTypes => {
      // console.log(docTypes)
      this.docTypes = docTypes;
    });

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.subsrcribeCurrentLang = this.currentLang$.subscribe(currentLang => {
      this.currentLang = currentLang.toUpperCase();
    });

  }

  changeTableStyle() {
    this.store.dispatch(new layoutActions.PutCompactTableAction( !this.tableCompactState ));
  }

  preview(doc: Document): void {
    if ( doc.id === '' + this.previewIndex ) {
      this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
      this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview(null));
    } else {
      this.store.dispatch(new searchPreviewActions.PutSearchResultsSearchPreview(doc));
      this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview('documents'));
    }
  }

  selectedDocument(doc: Document) {
    // this.store.dispatch( new documentsFilterAction.PutDocumentSeleced( doc.id ) );
  }

  getDocumentTypeName(id: string, version: number): string {
    const docType: DocumentTypes = find(this.docTypes, { id: id });
    if (!docType) {
      // this.envelopeTypeEffect.getEnvelopeTypeById(id, version);
      return 'Error';
    }
    const displayName = find(docType.displayNameList, { language: this.currentLang });
    return displayName  ? displayName['value'] : '' ;
  }

  getDocumentTypeActive(id: string, version: number): boolean {
    const docType: DocumentTypes = find(this.docTypes, { id: id });
    if (!docType) {
      // this.envelopeTypeEffect.getEnvelopeTypeById(id, version);
      return;
    }
    return docType.active;
  }

  fromSearch() {
    this.store.dispatch(new layoutAction.PutFromSearchAction(this.router.url));
  }

  ngOnInit() {}

  ngOnDestroy() {
    this.subscrisbePreviewIndex.unsubscribe();
    this.subsciberDocumentType.unsubscribe();
    this.subsrcribeCurrentLang.unsubscribe();
  }
}
