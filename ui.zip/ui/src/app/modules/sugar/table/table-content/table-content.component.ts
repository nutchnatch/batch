import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Component } from '@angular/core';

import * as fromRoot from 'app/reducers';
import { Paging } from 'app/models/paging';


@Component({
  selector: 'app-table-content',
  templateUrl: './table-content.component.html',
  styleUrls: ['./table-content.component.scss']
})
export class TableContentComponent {
  public searchType$: Observable<string>;
  public searchTypeResult$: Observable<string>;
  public paging$: Observable<Paging>;

  constructor(
    store: Store<fromRoot.State>,
  ) {
    this.paging$ = store.pipe(select(fromRoot.getSearchPagedPaging));

    this.searchType$ = store.pipe(select(fromRoot.getSearchPagedType));
    this.searchTypeResult$ = store.pipe(select(fromRoot.getSearchPagedTypeResult));
  }

}
