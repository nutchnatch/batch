import { PutDocumentTypesUpdatingInit } from 'app/actions/document-types.actions';
import { BusinessScopeEffect } from 'app/effects/business-scope.effect';
import { DocumentTypes } from 'app/models/document-types';
import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Router } from '@angular/router';
import { Tag } from 'app/models/tag';
import { DocumentTypesAndTagsEffect } from 'app/effects/document-types-and-tags.effects';
import { find } from 'lodash';
import { DocumentTypeEffect } from 'app/effects/document-types.effects';


import * as fromRoot from 'app/reducers';
import * as searchPreviewAction from 'app/actions/search-preview.actions';


@Component({
  selector: 'table-document-class',
  templateUrl: './table-document-class.component.html',
  styleUrls: ['./table-document-class.component.scss']
})
export class TableDocumentClassComponent implements OnInit, OnDestroy {

  public searchResult$: Observable<Document[]>;

  public compactTables$: Observable<boolean>;
  public previewIndex$: Observable<any>;
  public pageSizeList$: Observable<Array<number>>;
  public currentLang$: Observable<string>;

  public tooglingState$: Observable<boolean>;
  public tooglingStateId$: Observable<string>;
  public tooglingError$: Observable<Error>;
  public tooglingResult$: Observable<Array<any>>;

  // public subsrcribeCurrentLang: Subscription;
  public subscrisbePreviewIndex: Subscription;
  public subscriberDocumentClasses: Subscription;
  public subscriberDocumentTypesResult: Subscription;
  public documentClasses$: Observable<Array<Tag>>;
  public documentTypesLoading$: Observable<boolean>;

  previewIndex: string;
  tag;
  oldTag: Tag;

  constructor(
    public store: Store<fromRoot.State>,
    public documentTypeEffect: DocumentTypeEffect,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,
    public businessScopeEffect: BusinessScopeEffect,
    public router: Router
  ) {
    // this.searchResult$ =store.pipe(select(fromRoot.getSearchPagedResults);
    this.previewIndex$ = store.pipe(select(fromRoot.getSearchPreviewResultId));
    this.subscrisbePreviewIndex = this.previewIndex$.subscribe(id => this.previewIndex = id);

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.compactTables$ = store.pipe(select(fromRoot.getLayoutTableCompact));

    this.documentClasses$ = store.pipe(select(fromRoot.getDocumentTypesResultNoFilter));
    // this.documentTypesLoading$ =store.pipe(select(fromRoot.getDocumentTypesLoading);

    this.subscriberDocumentClasses = this.documentClasses$.subscribe(tags => {
      if (tags && this.previewIndex) {
        const tag = find(tags, (t) => t.id === this.previewIndex);
        // console.log( tag )
        this.preview(tag);
      }

      if (tags && !this.previewIndex) {
        this.preview(tags[0]);
      }

    });

    this.tooglingState$ = store.pipe(select(fromRoot.getDocumentTypesTooglingState));
    this.tooglingStateId$ = store.pipe(select(fromRoot.getDocumentTypesTooglingStateId));
    this.tooglingError$ = store.pipe(select(fromRoot.getDocumentTypesTooglingStateError));
    this.tooglingResult$ = store.pipe(select(fromRoot.getDocumentTypesTooglingStateResult));

    this.subscriberDocumentTypesResult = this.tooglingResult$.subscribe(result => {
      if (result) {
        // this.preview(this.tag);
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
        this.businessScopeEffect.getBusinessScope();
      }
    });

  }

  preview(tag: Tag): void {

    if (tag) {
      // this.tag = tag;
      this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(tag));
      this.store.dispatch(new searchPreviewAction.PutSearchTypeSearchPreview('tags'));
    }
    if (!this.oldTag || tag.id !== this.oldTag.id) {
      this.oldTag = tag;
      this.store.dispatch(new PutDocumentTypesUpdatingInit);
    }
  }

  onChange(docType: DocumentTypes) {
    if (docType.active) {
      this.documentTypeEffect.putDocumentTypesDeactivate(docType.id, docType.version);
    } else {
      this.documentTypeEffect.putDocumentTypesActivate(docType.id, docType.version);
    }
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscrisbePreviewIndex.unsubscribe();
    this.subscriberDocumentClasses.unsubscribe();
    this.subscriberDocumentTypesResult.unsubscribe();
    this.store.dispatch(new searchPreviewAction.PutSearchTypeSearchPreview(null));
    this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview());
  }

}
