import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { Paging } from 'app/models/paging';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';


@Component({
  selector: 'app-table-basket',
  templateUrl: './table-basket.component.html',
  styleUrls: ['./table-basket.component.scss']
})
export class TableBasketComponent implements OnInit, OnDestroy {

  public searchResult$: Observable<Document[]>;
  public pagingResult$: Observable<Paging>;
  public compactTables$: Observable<boolean>;
  public pageSizeList$: Observable<Array<number>>;
  public currentLang$: Observable<string>;

  public subsrcribeCurrentLang: Subscription;
  // public subscrisbePreviewIndex: Subscription;
  // public subsciberDocumentType: Subscription;

  public tableCompactState: boolean;
  public previewIndex: number = null;

  // public documentTypes$: Observable<Array<DocumentTypes>>;

  // docTypes: Array<DocumentTypes>;
  currentLang: string;
  page = 1;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router
  ) {
    this.searchResult$ = store.pipe(select(fromRoot.getSearchPagedResults));
    // this.previewIndex$ =store.pipe(select(fromRoot.getSearchPreviewResultId);
    // this.subscrisbePreviewIndex = this.previewIndex$.subscribe( id => this.previewIndex = id);

    this.compactTables$ = store.pipe(select(fromRoot.getLayoutTableCompact));
    // this.compactTables$.subscribe(compact => this.tableCompactState = compact );

    this.pageSizeList$ = store.pipe(select(fromRoot.getAppConfigPageSizeList));

    // this.documentTypes$ =store.pipe(select(fromRoot.getDocumentTypesResult);
    // this.subsciberDocumentType = this.documentTypes$.subscribe(docTypes => {
    //   // console.log(docTypes)
    //   this.docTypes = docTypes;
    // });

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.subsrcribeCurrentLang = this.currentLang$.subscribe(currentLang => {
      this.currentLang = currentLang.toUpperCase();
    });

  }

  fromSearch() {
    this.store.dispatch(new layoutActions.PutFromSearchAction(this.router.url));
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    // this.subscrisbePreviewIndex.unsubscribe();
    // this.subsciberDocumentType.unsubscribe();
    this.subsrcribeCurrentLang.unsubscribe();
  }

}
