import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Component } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';

@Component({
  selector: 'app-table-action-menu',
  templateUrl: './table-action-menu.component.html',
  styleUrls: ['./table-action-menu.component.scss']
})
export class TableActionMenuComponent {

  public compactTables$: Observable<boolean>;
  public tableCompactState: boolean;


  constructor(
    public store: Store<fromRoot.State>
  ) {

    this.compactTables$ = store.pipe(select(fromRoot.getLayoutTableCompact));
    this.compactTables$.subscribe(compact => this.tableCompactState = compact );

  }

  changeTableStyle() {
    this.store.dispatch(new layoutActions.PutCompactTableAction( !this.tableCompactState ));
  }
}
