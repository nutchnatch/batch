import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TableFilesToUploadComponent } from './table-files-to-upload.component';

describe('TableFilesToUploadComponent', () => {
  let component: TableFilesToUploadComponent;
  let fixture: ComponentFixture<TableFilesToUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TableFilesToUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableFilesToUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
