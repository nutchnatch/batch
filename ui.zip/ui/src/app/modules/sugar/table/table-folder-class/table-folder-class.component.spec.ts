/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { TableFolderClassComponent } from './table-folder-class.component';

describe('TableTagClassComponent', () => {
  let component: TableFolderClassComponent;
  let fixture: ComponentFixture<TableFolderClassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TableFolderClassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableFolderClassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
