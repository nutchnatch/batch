import { PutFolderTypesUpdatingInit } from './../../../../actions/folder-types.actions';
import { BusinessScopeEffect } from 'app/effects/business-scope.effect';
import { DocumentTypes } from './../../../../models/document-types';
import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Router } from '@angular/router';
import { Tag } from 'app/models/tag';
import { DocumentTypesAndTagsEffect } from 'app/effects/document-types-and-tags.effects';
import { find } from 'lodash';
import { FolderTypeEffect } from 'app/effects/folder-types.effects';
import { FolderTypes } from 'app/models/folder-types';


import * as fromRoot from 'app/reducers';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';


@Component({
  selector: 'table-folder-class',
  templateUrl: './table-folder-class.component.html',
  styleUrls: ['./table-folder-class.component.scss']
})
export class TableFolderClassComponent implements OnInit, OnDestroy {

  public searchResult$: Observable<Array<any>>;

  public compactTables$: Observable<boolean>;
  public previewIndex$: Observable<any>;
  public pageSizeList$: Observable<Array<number>>;
  public currentLang$: Observable<string>;

  public tooglingState$: Observable<boolean>;
  public tooglingStateId$: Observable<string>;
  public tooglingError$: Observable<Error>;
  public tooglingResult$: Observable<Array<any>>;

  // public subsrcribeCurrentLang: Subscription;
  public subscrisbePreviewIndex: Subscription;
  public subscriberFolderClasses: Subscription;
  public subscriberDocumentTypesResult: Subscription;
  public folderClasses$: Observable<Array<Tag>>;
  public folderTypesLoading$: Observable<boolean>;

  previewIndex: string;
  tag;
  oldTag: Tag;

  constructor(
    public store: Store<fromRoot.State>,
    public folderTypeEffect: FolderTypeEffect,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,
    public businessScopeEffect: BusinessScopeEffect,

    public router: Router
  ) {
    // this.searchResult$ =store.pipe(select(fromRoot.getSearchPagedResults);
    this.previewIndex$ = store.pipe(select(fromRoot.getSearchPreviewResultId));
    this.subscrisbePreviewIndex = this.previewIndex$.subscribe(id => this.previewIndex = id);

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.compactTables$ = store.pipe(select(fromRoot.getLayoutTableCompact));

    this.folderClasses$ = store.pipe(select(fromRoot.getFolderTypesResultNoFilter));
    // this.folderTypesLoading$ =store.pipe(select(fromRoot.getfolderTypesLoading);

    this.subscriberFolderClasses = this.folderClasses$.subscribe(tags => {
      if (tags && this.previewIndex) {
        const tag = find(tags, (t) => t.id === this.previewIndex);
        // console.log( tag )
        this.preview(tag);
      }

      if (tags && !this.previewIndex) {
        this.preview(tags[0]);
      }

    });

    this.tooglingState$ = store.pipe(select(fromRoot.getFolderTypesTooglingState));
    this.tooglingStateId$ = store.pipe(select(fromRoot.getFolderTypesTooglingStateId));
    this.tooglingError$ = store.pipe(select(fromRoot.getFolderTypesTooglingStateError));
    this.tooglingResult$ = store.pipe(select(fromRoot.getFolderTypesTooglingStateResult));

    this.subscriberDocumentTypesResult = this.tooglingResult$.subscribe(result => {
      if (result) {
        // this.preview(this.tag);
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
        this.businessScopeEffect.getBusinessScope();
      }
    });

  }

  preview(tag: Tag): void {

    if (tag) {
      // this.tag = tag;
      this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(tag));
      this.store.dispatch(new searchPreviewAction.PutSearchTypeSearchPreview('tags'));
    }
    if (!this.oldTag || tag.id !== this.oldTag.id) {
      this.oldTag = tag;
      this.store.dispatch(new PutFolderTypesUpdatingInit);
    }
  }

  onChange(folderType: FolderTypes) {
    if (folderType.active) {
      this.folderTypeEffect.putFolderTypesDeactivate(folderType.id, folderType.version);
    } else {
      this.folderTypeEffect.putFolderTypesActivate(folderType.id, folderType.version);
    }
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscrisbePreviewIndex.unsubscribe();
    this.subscriberFolderClasses.unsubscribe();
    this.subscriberDocumentTypesResult.unsubscribe();
    this.store.dispatch(new searchPreviewAction.PutSearchTypeSearchPreview(null));
    this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview());
  }

}
