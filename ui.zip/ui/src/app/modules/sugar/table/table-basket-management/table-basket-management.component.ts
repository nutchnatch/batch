import { Basket } from 'app/models/basket';
import { BusinessScopeEffect } from 'app/effects/business-scope.effect';
import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Router } from '@angular/router';
import { DocumentTypesAndTagsEffect } from 'app/effects/document-types-and-tags.effects';
import { find } from 'lodash';
import { DocumentTypeEffect } from 'app/effects/document-types.effects';


import * as fromRoot from 'app/reducers';
// import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';
import * as basketActions from 'app/actions/basket.actions';

@Component({
  selector: 'table-basket-management',
  templateUrl: './table-basket-management.component.html',
  styleUrls: ['./table-basket-management.component.scss']
})
export class TableBasketManagementComponent implements OnInit, OnDestroy {


  public compactTables$: Observable<boolean>;
  public previewIndex$: Observable<any>;
  public pageSizeList$: Observable<Array<number>>;
  public currentLang$: Observable<string>;

  public tooglingState$: Observable<boolean>;
  public tooglingStateId$: Observable<string>;
  public tooglingError$: Observable<Error>;
  public tooglingResult$: Observable<Array<any>>;

  public subscriberBasketClasses: Subscription;
  public basketClasses$: Observable<Array<Basket>>;
  public basketLoading$: Observable<boolean>;
  public basketCreating$: Observable<boolean>;
  public currentBasket$: Observable<string>;


  previewIndex: string;
  tag;
  subscriberCurrentBasket: Subscription;

  constructor(
    public store: Store<fromRoot.State>,
    public documentTypeEffect: DocumentTypeEffect,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,
    public businessScopeEffect: BusinessScopeEffect,
    public router: Router
  ) {

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.compactTables$ = store.pipe(select(fromRoot.getLayoutTableCompact));

    this.basketClasses$ = store.pipe(select(fromRoot.getBasketsResult));
    this.basketLoading$ = store.pipe(select(fromRoot.getBasketsLoading));

    this.currentBasket$ = store.pipe(select(fromRoot.getBasketsCurrentSelected));
    this.subscriberCurrentBasket = this.currentBasket$.subscribe( basketId => this.previewIndex = basketId );

    this.subscriberBasketClasses = this.basketClasses$.subscribe(baskets => {
      if (baskets && this.previewIndex) {
        const basket = find(baskets, (t) => t.basketId === this.previewIndex);
        // console.log( basket )
        this.preview(basket);
      }

      if (baskets && !this.previewIndex) {
        this.preview(baskets[0]);
      }

    });


  }

  preview(basket: any): void {

    if (basket) {
      // this.tag = tag;
      this.previewIndex = basket.basketId;

      this.store.dispatch(new basketActions.PutCurrentBasket(basket.basketId));
      this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(basket));
      this.store.dispatch(new searchPreviewAction.PutSearchTypeSearchPreview('basket'));
    }
  }


  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscriberBasketClasses.unsubscribe();
    this.subscriberCurrentBasket.unsubscribe();
    this.store.dispatch(new searchPreviewAction.PutSearchTypeSearchPreview(null));
    this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview());
  }

}
