import { Sidebar } from 'app/models/sidesbars-config';
import { Observable } from 'rxjs';
import { Component, Input, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';
import { Folder } from 'app/models/folder';

@Component({
  selector: 'app-folder-metadata-sidebar',
  templateUrl: './folder-metadata-sidebar.component.html',
  styleUrls: ['./folder-metadata-sidebar.component.scss']
})
export class FolderMetadataSidebarComponent implements OnDestroy {

  public sidebarConfig$: Observable<Sidebar>;
  public folderState$: Observable<Folder>;

  constructor(
    public store: Store<fromRoot.State>
  ) {

    this.sidebarConfig$ = store.pipe(select(fromRoot.getSideBarParams));
    this.folderState$ = store.pipe(select(fromRoot.getFolderFirstResult));

  }

  ngOnDestroy() {
    this.store.dispatch(new layoutActions.PutFromSearchAction(null));
  }
}
