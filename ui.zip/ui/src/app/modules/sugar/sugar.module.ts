import { QuillModule } from 'ngx-quill';
import { ModalCreateTagCommentComponent } from './modals/modal-create-tag-comment/modal-create-tag-comment.component';
import { CreateTagCommentComponent } from './create-tag-comment/create-tag-comment.component';
import { ReportSearchFilterComponent } from './report-search-filter/report-search-filter.component';
import { FormAclManagementComponent } from './form-acl-management/form-acl-management.component';
import { MetadataBasketClassFormComponent } from './metadata-sidebar/metadata-basket-class-form/metadata-basket-class-form.component';
import { PermissionRightDirective } from './../../directives/permission-right.directive';
import { ReportAndLogsMenuSidebarMenuSidebarComponent } from './report-and-logs-menu-sidebar/report-and-logs-menu-sidebar.component';
import { SugarDatePipe } from './../../pipes/sugar-date.pipe';
import { TableFolderClassComponent } from './table/table-folder-class/table-folder-class.component';
// tslint:disable-next-line:max-line-length
import { ModalCreateDocumentClassComponent } from 'app/modules/sugar/modals/modal-create-document-class/modal-create-document-class.component';
import { MetadataEnvelopeClassFormComponent } from './metadata-sidebar/metadata-envelope-class-form/metadata-envelope-class-form.component';
import { TableEnvelopeClassComponent } from './table/table-envelope-class/table-envelope-class.component';
import { ModalCreateTagComponent } from './modals/modal-create-tag/modal-create-tag.component';
import { MetadataTagsFormComponent } from './metadata-sidebar/metadata-tags-form/metadata-tags-form.component';
import { TableTagClassComponent } from './table/table-tag-class/table-tag-class.component';
// tslint:disable-next-line:max-line-length
import { MetadataFolderSearchResultsComponent } from './modals/modal-search-folder/metadata-folder-search-results/metadata-folder-search-results.component';
import { SearchOnModalComponent } from './modals/modal-search-folder/search-on-modal/search-on-modal.component';
import { ModalSearchFolderComponent } from './modals/modal-search-folder/modal-search-folder.component';
import { MetadataDocumentFolderComponent } from './metadata-sidebar/metadata-document-folder/metadata-document-folder.component';
import { FilterTypesComponent } from './advance-search/filter-types/filter-types.component';
import { TypeSelectComponent } from './advance-search/type-select/type-select.component';
import { SafeUrlPipe } from './../../pipes/safe-url.pipe';
import { FolderMetadataFormComponent } from 'app/modules/sugar/folder-metadata-form/folder-metadata-form.component';
import { TableFolderComponent } from './table/table-folder/table-folder.component';
import { MetadataEnvelopeFormComponent } from './metadata-sidebar/metadata-envelope-form/metadata-envelope-form.component';
import { MetadataSidebarPreviewsComponent } from './metadata-sidebar/metadata-sidebar-previews/metadata-sidebar-previews.component';
import { TableEnvelopeComponent } from './table/table-envelope/table-envelope.component';
import { EnvelopeMetadataExtraFormComponent } from './envelope-metadata-extra-form/envelope-metadata-extra-form.component';
import { LoadingComponent } from './loading-bars/loading-bars.component';
import { EnvelopeFilterToogleComponent } from './envelope-filter-toogle/envelope-filter-toogle.component';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// import { GuardedContentComponent } from './guarded-content/guarded-content.component';
import { SugarSidebarComponent } from './sidebar/sugar-sidebar/sugar-sidebar.component';
import { SearchOnSidebarComponent } from './sidebar/search-on-sidebar/search-on-sidebar.component';
import { SidebarContentComponent } from './sidebar/sidebar-content/sidebar-content.component';
import { TableBasketComponent } from './table/table-basket/table-basket.component';
import { TableContentComponent } from './table/table-content/table-content.component';
import { TableDocumentComponent } from './table/table-document/table-document.component';
import { MetadataSidebarComponent } from './metadata-sidebar/metadata-sidebar/metadata-sidebar.component';
import { MetadataSidebarEnvelopeComponent } from './metadata-sidebar/metadata-sidebar-envelope/metadata-sidebar-envelope.component';
import { TableActionMenuComponent } from './table/table-action-menu/table-action-menu.component';
import { TablePagesizeSelectComponent } from './table/table-pagesize-select/table-pagesize-select.component';
import { TablePaginationComponent } from './table/table-pagination/table-pagination.component';
// import { StringToDatePipe } from 'app/pipes/string-to-date.pipe';
import { EnvelopeFilesListComponent } from './envelope-files-list/envelope-files-list.component';
import { EnvelopeMetadataSidebarComponent } from './envelope-metadata-sidebar/envelope-metadata-sidebar.component';
import { MetadataDocumentFormComponent } from './metadata-sidebar/metadata-document-form/metadata-document-form.component';
import { EnvelopeArenderIframeComponent } from './envelope-arender-iframe/envelope-arender-iframe.component';
import { EnvelopeMetadataFormComponent } from './envelope-metadata-form/envelope-metadata-form.component';
import { GoToSearchResultsComponent } from 'app/modules/sugar/sidebar/go-to-search-results/go-to-search-results.component';
import { MetadataFolderFormComponent } from 'app/modules/sugar/metadata-sidebar/metadata-folder-form/metadata-folder-form.component';
import { FolderMetadataExtraFormComponent } from 'app/modules/sugar/folder-metadata-extra-form/folder-metadata-extra-form.component';
import { FolderMetadataSidebarComponent } from 'app/modules/sugar/folder-metadata-sidebar/folder-metadata-sidebar.component';
import { FolderFilesListComponent } from 'app/modules/sugar/folder-files-list/folder-files-list.component';
// tslint:disable-next-line:max-line-length
import { MetadataSidebarFolderComponent } from 'app/modules/sugar/metadata-sidebar/metadata-sidebar-folder/metadata-sidebar-folder.component';
import { AdvanceSearchComponent } from './advance-search/advance-search.component';
import { DomainSelectComponent } from 'app/modules/sugar/advance-search/domain-select/domain-select.component';
// tslint:disable-next-line:max-line-length
import { MetadataFolderListComponent } from 'app/modules/sugar/metadata-sidebar/metadata-document-folder/metadata-folder-list/metadata-folder-list.component';
// tslint:disable-next-line:max-line-length
import { MetadataFolderSearcherComponent } from 'app/modules/sugar/metadata-sidebar/metadata-document-folder/metadata-folder-searcher/metadata-folder-searcher.component';
import { FileDropModule } from 'ngx-file-drop';
import { FileDropComponent } from './file-drop/file-drop.component';
import { TableFilesToUploadComponent } from './table/table-files-to-upload/table-files-to-upload.component';
import { UploadDocumentActionsComponent } from './upload-document-actions/upload-document-actions.component';
// tslint:disable-next-line:max-line-length
import { UnderConstructionEnvelopeResultsComponent } from './under-construction-envelope-results/under-construction-envelope-results.component';
import { InfoVersionComponent } from './info-version/info-version.component';
import { ModalCreateFolderComponent } from './modals/modal-create-folder/modal-create-folder.component';
import { FormNewFolderComponent } from './modals/modal-create-folder/form-new-folder/form-new-folder.component';
import { SelectBasketComponent } from './select-basket/select-basket.component';
import { TaksHandlersComponent } from './sidebar/taks-handlers/taks-handlers.component';
import { ModalAlertEnvelopeComponent } from 'app/modules/sugar/modals/modal-alert-envelope/modal-alert-envelope.component';
import { AdministrationMenuSidebarComponent } from './administration-menu-sidebar/administration-menu-sidebar.component';
import { CreateNewTagComponent } from './create-new-tag/create-new-tag.component';
import { FormBusinessScopeComponent } from './form-business-scope/form-business-scope.component';
import { CreateNewEnvelopeClassComponent } from 'app/modules/sugar/create-new-envelope-class/create-new-envelope-class.component';
// tslint:disable-next-line:max-line-length
import { ModalCreateEnvelopeClassComponent } from 'app/modules/sugar/modals/modal-create-envelope-class/modal-create-envelope-class.component';
import { TableDocumentClassComponent } from 'app/modules/sugar/table/table-document-class/table-document-class.component';
// tslint:disable-next-line:max-line-length
import { MetadataDocumentClassFormComponent } from 'app/modules/sugar/metadata-sidebar/metadata-document-class-form/metadata-document-class-form.component';
import { CreateNewDocumentClassComponent } from './create-new-document-class/create-new-document-class.component';
// tslint:disable-next-line:max-line-length
import { MetadataFolderClassFormComponent } from 'app/modules/sugar/metadata-sidebar/metadata-folder-class-form/metadata-folder-class-form.component';
import { CreateNewFolderClassComponent } from 'app/modules/sugar/create-new-folder-class/create-new-folder-class.component';
import { ModalCreateFolderClassComponent } from 'app/modules/sugar/modals/modal-create-folder-class/modal-create-folder-class.component';
// tslint:disable-next-line:max-line-length
import { MetadataDocumentExtraFormComponent } from 'app/modules/sugar/metadata-sidebar/metadata-document-extra-form/metadata-document-extra-form.component';
import { TableBasketManagementComponent } from 'app/modules/sugar/table/table-basket-management/table-basket-management.component';
import { CreateNewBasketClassComponent } from './create-new-basket-class/create-new-basket-class.component';
import { ModalCreateBasketClassComponent } from 'app/modules/sugar/modals/modal-create-basket-class/modal-create-basket-class.component';
import { TableSortableColComponent } from 'app/modules/sugar/table/table-sortable-col/table-sortable-col.component';
import { ModalAboutComponent } from 'app/modules/sugar/modals/modal-about/modal-about.component';

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    RouterModule,
    TranslateModule,
    FormsModule,
    // TspUIModule,
    ReactiveFormsModule,
    FileDropModule,
    QuillModule
  ],
  exports: [
    SugarSidebarComponent,
    TableBasketComponent,
    TableContentComponent,
    TranslateModule,
    MetadataSidebarComponent,
    TablePaginationComponent,
    TableTagClassComponent,
    TableFolderClassComponent,
    LoadingComponent,
    EnvelopeArenderIframeComponent,
    FileDropComponent,
    TableFilesToUploadComponent,
    UploadDocumentActionsComponent,
    TableEnvelopeComponent,
    UnderConstructionEnvelopeResultsComponent,
    InfoVersionComponent,
    SelectBasketComponent,
    TaksHandlersComponent,
    MetadataTagsFormComponent,
    ModalCreateFolderComponent,
    ModalAlertEnvelopeComponent,
    ModalSearchFolderComponent,
    ModalCreateTagComponent,
    ModalCreateEnvelopeClassComponent,
    ModalCreateDocumentClassComponent,
    ModalCreateFolderClassComponent,
    ModalCreateTagCommentComponent,
    ModalCreateBasketClassComponent,
    ModalAboutComponent,
    FormBusinessScopeComponent,
    FormAclManagementComponent,
    TableEnvelopeClassComponent,
    TableDocumentClassComponent,
    PermissionRightDirective,
    TableBasketManagementComponent,
    MetadataBasketClassFormComponent,
    ReportSearchFilterComponent,
    TableSortableColComponent
  ],
  declarations: [
    EnvelopeFilterToogleComponent,
    EnvelopeFilesListComponent,
    EnvelopeMetadataSidebarComponent,
    EnvelopeMetadataExtraFormComponent,
    SugarSidebarComponent,
    SearchOnSidebarComponent,
    SidebarContentComponent,
    TableBasketComponent,
    TableContentComponent,
    TableDocumentComponent,
    TableEnvelopeComponent,
    TableFolderComponent,
    TableEnvelopeClassComponent,
    TableDocumentClassComponent,
    MetadataSidebarComponent,
    MetadataSidebarPreviewsComponent,
    MetadataSidebarEnvelopeComponent,
    TableActionMenuComponent,
    TablePagesizeSelectComponent,
    TablePaginationComponent,
    TableTagClassComponent,
    TableFolderClassComponent,
    TableBasketManagementComponent,
    // StringToDatePipe,
    SafeUrlPipe,
    EnvelopeFilesListComponent,
    LoadingComponent,
    MetadataDocumentFormComponent,
    MetadataEnvelopeFormComponent,
    MetadataFolderFormComponent,
    EnvelopeArenderIframeComponent,
    MetadataDocumentExtraFormComponent,
    EnvelopeMetadataFormComponent,
    GoToSearchResultsComponent,
    FolderMetadataExtraFormComponent,
    FolderMetadataSidebarComponent,
    FolderFilesListComponent,
    FolderMetadataFormComponent,
    MetadataSidebarFolderComponent,
    AdvanceSearchComponent,
    DomainSelectComponent,
    TypeSelectComponent,
    FilterTypesComponent,
    MetadataDocumentFolderComponent,
    MetadataFolderListComponent,
    MetadataFolderSearcherComponent,
    SearchOnModalComponent,
    MetadataFolderSearchResultsComponent,
    FileDropComponent,
    TableFilesToUploadComponent,
    UploadDocumentActionsComponent,
    UnderConstructionEnvelopeResultsComponent,
    InfoVersionComponent,
    FormNewFolderComponent,
    FormAclManagementComponent,
    SelectBasketComponent,
    TaksHandlersComponent,
    ModalSearchFolderComponent,
    ModalCreateFolderComponent,
    ModalAlertEnvelopeComponent,
    ModalAboutComponent,
    ModalCreateTagComponent,
    ModalCreateTagCommentComponent,
    ModalCreateEnvelopeClassComponent,
    ModalCreateDocumentClassComponent,
    ModalCreateFolderClassComponent,
    ModalCreateBasketClassComponent,
    AdministrationMenuSidebarComponent,
    MetadataTagsFormComponent,
    CreateNewTagComponent,
    CreateNewEnvelopeClassComponent,
    CreateNewDocumentClassComponent,
    CreateNewFolderClassComponent,
    CreateTagCommentComponent,
    FormBusinessScopeComponent,
    MetadataEnvelopeClassFormComponent,
    MetadataDocumentClassFormComponent,
    MetadataFolderClassFormComponent,
    SugarDatePipe,
    ReportAndLogsMenuSidebarMenuSidebarComponent,
    PermissionRightDirective,
    MetadataBasketClassFormComponent,
    CreateNewBasketClassComponent,
    ReportSearchFilterComponent,
    TableSortableColComponent
]
})
export class SugarModule { }
