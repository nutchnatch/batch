import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { DateParserFormaterServices } from 'app/services/date-parser-formater/date-parser-formater.service';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Component, OnInit, Input, ViewChild } from '@angular/core';
import * as fromRoot from 'app/reducers';

import * as moment from 'moment';



@Component({
  selector: 'app-report-search-filter',
  templateUrl: './report-search-filter.component.html',
  styleUrls: ['./report-search-filter.component.scss']
})
export class ReportSearchFilterComponent implements OnInit {

  @Input()
  public dataForm: FormGroup;
  @Input()
  public downloadURL: string;
  @ViewChild('submit') submit;
  public disabledDatepicker = true;
  public loading$: Observable<boolean>;
  public now: Date = new Date();
  public validBetween = true;
  constructor(
    public store: Store<fromRoot.State>,
    public dateToUCT: DateParserFormaterServices
  ) {

    this.loading$ = store.pipe(select(fromRoot.getReportingLoading));
  }

  ngOnInit() {

    this.dataForm.addControl('filter', new FormControl('day'));
    // tslint:disable-next-line:max-line-length
    this.dataForm.addControl('start', new FormControl({ year: this.now.getFullYear(), month: this.now.getMonth() + 1, day: this.now.getDate() }));
    // tslint:disable-next-line:max-line-length
    this.dataForm.addControl('end', new FormControl({ year: this.now.getFullYear(), month: this.now.getMonth() + 1, day: this.now.getDate() }, ));
  }

  handleChange(value) {

    this.disabledDatepicker = true;
    this.dataForm.controls['end'].setValue({ year: this.now.getFullYear(), month: this.now.getMonth() + 1, day: this.now.getDate() });

    switch (value) {
      case 'day':
        this.dataForm.controls['start'].setValue({ year: this.now.getFullYear(), month: this.now.getMonth() + 1, day: this.now.getDate() });
        break;
      case 'week':
        const dateMoment = moment(this.now);
        // MODAY = moment().startOf('isoWeek');
        // SUNDAY = moment().startOf('week');
        // tslint:disable-next-line:max-line-length
        this.dataForm.controls['start'].setValue({ year: +dateMoment.format('YYYY'), month: +dateMoment.startOf('isoWeek').format('M'), day: +dateMoment.startOf('isoWeek').format('D') });
        break;
      case 'month':
        this.dataForm.controls['start'].setValue({ year: this.now.getFullYear(), month: this.now.getMonth() + 1, day: 1 });
        break;
      case 'year':
        // tslint:disable-next-line:max-line-length
        this.dataForm.controls['start'].setValue({ year: this.now.getFullYear(), month: 1, day: 1 });
        break;
      case 'custom':
        this.disabledDatepicker = false;
        break;
    }
    if (value !== 'custom') {
        this.submit.nativeElement.click();
    }
  }

 betweenDates(): boolean {
    // tslint:disable-next-line:max-line-length
    const startDate =  new Date(Date.UTC(this.dataForm.value.start.year, this.dataForm.value.start.month - 1, this.dataForm.value.start.day));
    const endDate =  new Date(Date.UTC(this.dataForm.value.end.year, this.dataForm.value.end.month - 1, this.dataForm.value.end.day));
    this.validBetween = !startDate || !endDate || startDate <= endDate;
    return this.validBetween;
  }

}
