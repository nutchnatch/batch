/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { ReportAndLogsMenuSidebarMenuSidebarComponent } from './report-and-logs-menu-sidebar.component';

describe('ReportAndLogsMenuSidebarMenuSidebarComponent', () => {
  let component: ReportAndLogsMenuSidebarMenuSidebarComponent;
  let fixture: ComponentFixture<ReportAndLogsMenuSidebarMenuSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportAndLogsMenuSidebarMenuSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportAndLogsMenuSidebarMenuSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
