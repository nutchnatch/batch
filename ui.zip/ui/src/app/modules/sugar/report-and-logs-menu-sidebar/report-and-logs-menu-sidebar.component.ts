import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-and-logs-menu-sidebar',
  templateUrl: './report-and-logs-menu-sidebar.component.html',
  styleUrls: ['./report-and-logs-menu-sidebar.component.scss']
})
export class ReportAndLogsMenuSidebarMenuSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
