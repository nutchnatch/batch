import { Document } from 'app/models/document';
import { Observable } from 'rxjs';
import { Component, OnInit, HostListener, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';


@Component({
  selector: 'app-envelope-arender-iframe',
  templateUrl: './envelope-arender-iframe.component.html',
  styleUrls: ['./envelope-arender-iframe.component.scss']
})
export class EnvelopeArenderIframeComponent implements OnInit, OnDestroy {

  @ViewChild('divToClick') myDiv: ElementRef;

  public subscribeEnvelope: Subscription;
  public subscribeFolder: Subscription;
  public multiDocumentFilter$: Observable<boolean>;
  public documentsResult$: Observable<Document>;
  public documentList$: Observable<Array<Document>>;
  public documentSelected$: Observable<string>;
  public envelope$: Observable<any>;
  public folder$: Observable<any>;
  public currentLanguage$: Observable<string>;

  folder = false;
  envelopeId;
  folderId: any;


  constructor(
    public store: Store<fromRoot.State>,
    public router: Router
  ) {

    this.multiDocumentFilter$ = store.pipe(select(fromRoot.getDocumentsFilterMultiple));
    this.documentList$ = store.pipe(select(fromRoot.getDocumentsFilterListSelected));
    this.documentSelected$ = store.pipe(select(fromRoot.getDocumentsFilterSelected));
    this.documentsResult$ = store.pipe(select(fromRoot.getDocumentsResult));

    this.currentLanguage$ = store.pipe(select(fromRoot.getCurrentLanguage));

    this.envelope$ = store.pipe(select(fromRoot.getEnvelopeFirstResult));
    this.folder$ = store.pipe(select(fromRoot.getFolderFirstResult));

    this.subscribeEnvelope = this.envelope$.subscribe(r => {

      if (r) {
        this.folder = false;
        this.envelopeId = r['id'];
      }
    });

    this.subscribeFolder = this.folder$.subscribe(r => {
      if (r) {
        this.folder = true;
        this.folderId = r['id'];
      }
    });
  }

  public listenToEvent(event) {
    const doc = event.target.contentDocument || event.target.contentWindow;
    // tslint:disable-next-line:typeof-compare
    if (typeof doc.addEventListener !== undefined) {
      doc.addEventListener('click', () => this.triggerFalseClick(), false);
    // tslint:disable-next-line:typeof-compare
    } else if (typeof doc.attachEvent !== undefined) {
      doc.attachEvent('onclick', () => this.triggerFalseClick());
    }
  }

  @HostListener('window:split-event', ['$event'])
  updateNodes(event) {

    if (!this.folder) {
      this.router.navigate(['app/refresh' ], { queryParams : {  url: '/app/envelope/' + this.envelopeId } } );
    } else {
      this.router.navigate(['app/refresh' ], { queryParams : { url: '/app/folder/' + this.folderId } });
    }

  }


  triggerFalseClick() {
      const el: HTMLElement = this.myDiv.nativeElement as HTMLElement;
      el.click();
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscribeEnvelope.unsubscribe();
  }

}
