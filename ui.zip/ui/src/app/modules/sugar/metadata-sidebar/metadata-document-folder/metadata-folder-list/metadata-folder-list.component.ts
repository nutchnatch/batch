import { DocumentEffect } from 'app/effects/document.effect';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { DocumentAttachedToFoldersResult } from './../../../../../models/document-attached-to-folder-result';
import { FolderEffect } from 'app/effects/folder.effect';
import { Subscription } from 'rxjs';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Document } from 'app/models/document';


import * as fromRoot from 'app/reducers';
// import * as searchPreviewAction from 'app/actions/search-preview.actions';
import * as folderAction from 'app/actions/folder.actions';

@Component({
  selector: 'app-metadata-folder-list',
  templateUrl: './metadata-folder-list.component.html',
  styleUrls: ['./metadata-folder-list.component.scss']
})
export class MetadataFolderListComponent implements OnInit, OnDestroy {
  subscriberCurrentDocumentId: Subscription;
  currentDocumentId$: Observable<{}>;
  subscribeActiveRoute: Subscription;

  public documentsResult$: Observable<Document>;
  public subscribeDocumentResult: Subscription;

  public deleting$: Observable<boolean>;
  public deletingError$: Observable<boolean>;
  public deletingResult$: Observable<DocumentAttachedToFoldersResult>;

  public subscribeDeletingResult: Subscription;

  public currentId: string;
  public currentDocumentIdToDeleting: string;
  public currentDocumentId;

  constructor(
    public store: Store<fromRoot.State>,
    public folderEffect: FolderEffect,
    public activatedRouter: ActivatedRoute,
    public documentEffect: DocumentEffect,

  ) {

    this.documentsResult$ = store.pipe(select(fromRoot.getDocumentsResult));

    this.deleting$ = store.pipe(select(fromRoot.getFolderDeletingDeleting));
    this.deletingError$ = store.pipe(select(fromRoot.getFolderDeletingError));


    this.deletingResult$ = store.pipe(select(fromRoot.getFolderDeletingResult));
    this.currentDocumentId$ = store.pipe(select(fromRoot.getSearchPreviewResultId));
    this.subscriberCurrentDocumentId = this.currentDocumentId$.subscribe( currentDocumentId => this.currentDocumentId = currentDocumentId);


    this.subscribeDeletingResult = this.deletingResult$.subscribe( result => {
      if ( result ) {
        this.documentEffect.getDocumentsById(this.currentDocumentId);
      }
    });
  }

  onRemove(id) {
    this.currentDocumentIdToDeleting = id;
    // console.log( this.currentDocumentId, id)
    if ( this.currentDocumentId && id) {
      this.folderEffect.deleteFolderDocuments( id, [ this.currentDocumentId] );
    }
    // this.folderEffect.deleteFolderDocuments()
  }

  ngOnInit() {

    this.subscribeActiveRoute = this.activatedRouter.queryParamMap.subscribe((params: ParamMap) => {
      // console.log(params.get('id'))
      this.currentId = params.get('id');
      // this.folderEffect.getFoldersById(params.get('id'));
    });
  }

  ngOnDestroy() {
    this.store.dispatch(new folderAction.InitDeleteFolder());
    this.subscribeActiveRoute.unsubscribe();
    this.subscribeDeletingResult.unsubscribe();
    this.subscriberCurrentDocumentId.unsubscribe();
  }

}
