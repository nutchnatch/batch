import { DocumentEffect } from 'app/effects/document.effect';
import { DocumentAttachedToFoldersResult } from './../../../../../models/document-attached-to-folder-result';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Folder } from 'app/models/folder';
import { Observable } from 'rxjs';
import { FolderEffect } from 'app/effects/folder.effect';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { ModalSearchFolderComponent } from 'app/modules/sugar/modals/modal-search-folder/modal-search-folder.component';
import { ModalCreateFolderComponent } from 'app/modules/sugar/modals/modal-create-folder/modal-create-folder.component';
import { Subject } from 'rxjs';

import * as fromRoot from 'app/reducers';
import * as searchFolderToAttachActions from 'app/actions/search-folder-to-attach.actions';
import * as folderActions from 'app/actions/folder.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';

import { filter } from 'lodash';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-metadata-folder-searcher',
  templateUrl: './metadata-folder-searcher.component.html',
  styleUrls: ['./metadata-folder-searcher.component.scss']
})
export class MetadataFolderSearcherComponent implements OnInit, OnDestroy {

  @Input() docList;

  pageSize: any;
  pageSize$: any;
  subscriberPageSize: Subscription;
  subscriberCurrentDocumentId: Subscription;
  subscribeFolderResults: Subscription;
  subscribeFolderSelected: Subscription;

  uploading$: Observable<boolean>;
  searching$: Observable<boolean>;
  error$: Observable<Error>;
  attachSuccess$: Observable<DocumentAttachedToFoldersResult>;

  subscriberAttachSuccess: Subscription;

  currentDocumentId$: Observable<string>;
  currentDocumentId: string;

  modalSearch;
  searchTerm$ = new Subject<any>();

  folderResults$: Observable<Array<Folder>>;
  folderResults: Array<Folder>;

  folderSelected$: Observable<string>;
  folderSelected: any;

  searchFolder: FormGroup;

  show = false;
  to: any;
  // modalON: boolean = false;

  constructor(
    protected modalService: NgbModal,
    public folderEffect: FolderEffect,
    public documentEffect: DocumentEffect,
    public store: Store<fromRoot.State>,
  ) {

    this.pageSize$ = store.pipe(select(fromRoot.getAppConfigPageSize));
    this.subscriberPageSize = this.pageSize$.subscribe(value => this.pageSize = value);


    this.uploading$ = store.pipe(select(fromRoot.getSearchFolderToAttachUploading));
    this.searching$ = store.pipe(select(fromRoot.getSearchFolderToAttachLoading));
    this.error$ = store.pipe(select(fromRoot.getFolderUpdateError));

    // this.folderResults$ =store.pipe(select(fromRoot.getSearchPagedResults);
    this.folderResults$ = store.pipe(select(fromRoot.getSearchFolderToAttachResults));

    this.subscribeFolderResults = this.folderResults$.subscribe(folders => this.folderResults = folders);

    this.folderSelected$ = store.pipe(select(fromRoot.getSearchFolderToAttachResultId));
    this.subscribeFolderSelected = this.folderSelected$.subscribe(id => {
      this.folderSelected = filter(this.folderResults, folder => folder.id === id);
    });

    this.attachSuccess$ = store.pipe(select(fromRoot.getSearchFolderToAttachSuccess));

    this.subscriberAttachSuccess = this.attachSuccess$.subscribe(success => {
      if (success && success.documentIdArray.length > 0 && !this.docList) {
        // console.log('id -> ' , success.documentIdArray[0])
        // console.log(this.currentDocumentId)
        this.documentEffect.getDocumentsById(this.currentDocumentId);
        if (this.modalSearch) { this.modalSearch.close(); }
      } else {
        if (this.modalSearch) { this.modalSearch.close(); }
      }
      this.store.dispatch(new searchFolderToAttachActions.InitSearchFolderToAttach());
    });
  }

  open() {
    this.store.dispatch(new folderActions.InitUpdateFolder());
    this.store.dispatch(new folderActions.InitDeleteFolder());
    this.store.dispatch(new searchPagedAction.InitSearchResults());

    this.store.dispatch(new searchPagedAction.PutSearchResultsType('folders'));

    this.modalSearch = this.modalService.open(ModalSearchFolderComponent, { windowClass: 'modal-xl', backdrop: 'static' });

    if (this.docList) {
      this.modalSearch.componentInstance.docList = this.docList;
      this.store.dispatch(new searchFolderToAttachActions.PutSearchResultsToAttachDocList(true));
    } else {
      this.store.dispatch(new searchFolderToAttachActions.PutSearchResultsToAttachDocList(false));

    }
  }

  openCreateFolder() {
    this.store.dispatch(new folderActions.InitUpdateFolder());
    this.store.dispatch(new folderActions.InitDeleteFolder());
    // this.store.dispatch(new folderActions.InitUpdateFolder());
    this.modalSearch = this.modalService.open(ModalCreateFolderComponent, { backdrop: 'static' });
    if (this.docList) {
      this.modalSearch.componentInstance.docList = this.docList;
      this.store.dispatch(new searchFolderToAttachActions.PutSearchResultsToAttachDocList(true));
    } else {
      this.store.dispatch(new searchFolderToAttachActions.PutSearchResultsToAttachDocList(false));
    }
  }


  onBlur() {
    if (this.to) { clearTimeout(this.to); }
    this.to = setTimeout(() => { this.show = false; }, 500);
  }
  onFocus() {
    this.show = true;
  }

  attachThis(id) {
    if (!this.docList) {
      this.store.dispatch(new searchFolderToAttachActions.PutSearchFolderIdToAttach(id));
      // setTimeout( () => this.show = false, 400);
      this.show = false;
    }
  }

  onAttach(folderId: string) {
    if (this.currentDocumentId && !this.docList) {
      this.folderEffect.postFolderDocuments(folderId, [this.currentDocumentId]);
    }
  }

  searchTerm(query) {
    // this.folderEffect.getFoldersLive(query);
  }



  onSubmit(searchFolder: FormGroup) {
    this.store.dispatch(new searchPagedAction.InitSearchResults());

    this.store.dispatch(new searchPagedAction.PutSearchResultsType('folders'));


    const value = searchFolder.value.name === '' ? ' ' : searchFolder.value.name;
    // tslint:disable-next-line:max-line-length
    this.store.dispatch(new searchPagedAction.PutSearchResultsQuery(Object.assign({}, { name: 'contains|' + value, pageNumber: 1, pageSize: this.pageSize })));
  }
  ngOnInit() {

    if (!this.docList) {
      this.currentDocumentId$ = this.store.pipe(select(fromRoot.getSearchPreviewResultId));
      this.subscriberCurrentDocumentId = this.currentDocumentId$.subscribe(currentDocumentId => this.currentDocumentId = currentDocumentId);
    }

    this.searchFolder = new FormGroup({
      name: new FormControl('', Validators.required),
    });
  }
  ngOnDestroy() {
    if (this.subscriberCurrentDocumentId) { this.subscriberCurrentDocumentId.unsubscribe(); }
    this.subscriberAttachSuccess.unsubscribe();
    this.subscriberPageSize.unsubscribe();
    this.subscribeFolderResults.unsubscribe();
    this.subscribeFolderSelected.unsubscribe();
    this.store.dispatch(new searchPagedAction.PutSearchResultsType(''));


    this.store.dispatch(new searchFolderToAttachActions.PutSearchResultsToAttachDocList(false));
    if (this.modalSearch) { this.modalSearch.close(); }
  }

}
