import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit } from '@angular/core';
import * as fromRoot from 'app/reducers';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-metadata-document-folder',
  templateUrl: './metadata-document-folder.component.html',
  styleUrls: ['./metadata-document-folder.component.scss']
})
export class MetadataDocumentFolderComponent implements OnInit {
  public searchType$: Observable<string>;

  modalSearch;
  constructor(
    protected modalService: NgbModal,
    public store: Store<fromRoot.State>,
  ) {
    this.searchType$ = store.pipe(select(fromRoot.getSearchPreviewType));
  }

  open() {
    // this.modalSearch = this.modalService.open(ModalSearchFolderComponent, { windowClass: 'modal-xl', backdrop: 'static' });
  }

  ngOnInit( ) {
  }

}
