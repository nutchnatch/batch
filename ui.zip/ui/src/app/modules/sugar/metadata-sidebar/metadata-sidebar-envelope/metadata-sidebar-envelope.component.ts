import { Subscription } from 'rxjs';
import { NgbModal, ModalDismissReasons, NgbTabChangeEvent } from '@ng-bootstrap/ng-bootstrap';
import { Envelope } from 'app/models/envelope';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as envelopeActions from 'app/actions/envelope.actions';
import { ModalAlertEnvelopeComponent } from 'app/modules/sugar/modals/modal-alert-envelope/modal-alert-envelope.component';

@Component({
  selector: 'app-metadata-sidebar-envelope',
  templateUrl: './metadata-sidebar-envelope.component.html',
  styleUrls: ['./metadata-sidebar-envelope.component.scss']
})
export class MetadataSidebarEnvelopeComponent implements OnInit, OnDestroy {
  subscribeEnvelopeState: Subscription;
  subscriberStep2: Subscription;

  public envelopeState$: Observable<Envelope>;
  public envelopeConstructionStep2$: Observable<boolean>;
  public getEnvelopeError$: Observable<Error>;

  modalWarning;
  underConstrution = false;
  tabStep2 = false;

  constructor(
    public store: Store<fromRoot.State>,
    protected modalService: NgbModal
  ) {

    this.getEnvelopeError$ = store.pipe(select(fromRoot.getEnvelopeError));

    this.envelopeState$ = store.pipe(select(fromRoot.getEnvelopeFirstResult));
    this.subscribeEnvelopeState = this.envelopeState$.subscribe( env => {
      if ( env ) {
        this.underConstrution = env.validity === 'UNDER_CONSTRUCTION';
        this.store.dispatch(new envelopeActions.PutUnderConstructionStep2(this.underConstrution));

      }
    });

    this.envelopeConstructionStep2$ = store.pipe(select(fromRoot.getEnvelopeUnderConstructionStep2));
    this.subscriberStep2 =  this.envelopeConstructionStep2$.subscribe( step2 => this.tabStep2 = step2 );
  }

  step2() {
    this.store.dispatch(new envelopeActions.PutUnderConstructionStep2(false));
    // this.openExpiredModal();
  }

  openExpiredModal() {

    if (!this.modalWarning) {
      this.modalWarning = this.modalService.open(ModalAlertEnvelopeComponent, {
        backdrop: 'static'
      });
      // tslint:disable-next-line:max-line-length
      this.modalWarning.componentInstance.copy = 'Caution ! This action is irreversible. When you save the envelope metadata you cant add more documents to envelopes';
      this.modalWarning.componentInstance.cancelLabel = '';
    }

    this.modalWarning.result.then((result) => {
      if (result !== 'continue') {
        this.store.dispatch(new envelopeActions.PutUnderConstructionStep2(false));
      }
      // this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
      this.modalWarning = undefined;
    }, (reason) => {
      this.getDismissReason(reason);
      // this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
    });

  }

  getDismissReason(reason: any) {
    if (reason === ModalDismissReasons.ESC) {
      this.store.dispatch(new envelopeActions.PutUnderConstructionStep2(false));
      this.modalWarning = undefined;
    }
  }

  beforeChange($event: NgbTabChangeEvent) {
    // if ($event.nextId === 'metadata-invalid' && !this.tabStep2) {
    //   // $event.preventDefault();
    //   this.step2();
    // }
    if ($event.nextId === 'metadata' && this.tabStep2) {
      this.step2();
    }
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscriberStep2.unsubscribe();
    this.subscribeEnvelopeState.unsubscribe();
  }

}
