import { TagsEffect } from './../../../../effects/tags.effect';
import { Subscription } from 'rxjs';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { Observable } from 'rxjs';
import { Tag } from 'app/models/tag';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import { BusinessScope } from 'app/models/business-scope';
import { DocumentTypesAndTagsEffect } from 'app/effects/document-types-and-tags.effects';

import { find } from 'lodash';

@Component({
  selector: 'app-metadata-tags-form',
  templateUrl: './metadata-tags-form.component.html',
  styleUrls: ['./metadata-tags-form.component.scss']
})
export class MetadataTagsFormComponent implements OnInit, OnDestroy {

  public dataForm: FormGroup;

  public searchResult$: Observable<Tag>;

  public searchResultUpdating$: Observable<boolean>;
  public searchResultUpdatingError$: Observable<Error>;
  public searchResultUpdatingSuccess$: Observable<Tag>;

  public businessScopeResult$: Observable<BusinessScope>;
  public tagTypes$: Observable<Array<any>>;

  public subscriberSearchResult: Subscription;
  public subscriberBusinessScopeResult: Subscription;
  public subscriberSearchResultSuccess: Subscription;

  public faChoiseList: FormArray;

  currentTag;
  choicelist;
  displayNameItem;

  langOnScope: Array<string>;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public tagEffect: TagsEffect,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,

  ) {

    // this.choiceDataForm = this.formBuilder.group({ });

    this.searchResultUpdating$ = store.pipe(select(fromRoot.getTagsUpdating));
    this.searchResultUpdatingError$ = store.pipe(select(fromRoot.getTagsUpdatingError));
    this.searchResultUpdatingSuccess$ = store.pipe(select(fromRoot.getTagsUpdatingSuccess));

    this.tagTypes$ = store.pipe(select(fromRoot.getAppConfigTagType));
    this.searchResult$ = store.pipe(select(fromRoot.getSearchPreviewResults));

    this.subscriberSearchResult = this.searchResult$.subscribe(tag => {

      if (tag && tag.id && tag.hasOwnProperty('isSearchable' )) {
        this.currentTag = tag;
        if (this.dataForm) { this.removeControls(); }
        this.initForm(tag);
      }
    });

    this.subscriberSearchResultSuccess = this.searchResultUpdatingSuccess$.subscribe(result => {

      if (result && result.hasOwnProperty('isSearchable' )) {
        this.dataForm.reset();
        this.currentTag = result;
        if ( this.langOnScope ) { this.initForm(result); }
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
      }
    });


    this.businessScopeResult$ = store.pipe(select(fromRoot.getBusinessScopeFirstResult));

    this.subscriberBusinessScopeResult = this.businessScopeResult$.subscribe(businessScope => {
      if (businessScope) {
        this.langOnScope = businessScope.languages;

        this.displayNameItemFormData();
      }
    });

  }

  initForm(tag) {

    this.choicelist = tag.choicelist;
    this.displayNameItem = tag['diplayNameItem'];

    this.dataForm = this.formBuilder.group(Object.assign({}, tag, { choicelist: null, diplayNameItem: null }));

    this.dataForm.setControl('choicelist', new FormArray([]));
    this.dataForm.setControl('diplayNameItem', new FormArray([]));

    this.choicelistFormData();
    // console.log(this.choicelist.length)
    if (this.langOnScope) { this.displayNameItemFormData(); }

  }

  removeControls() {
    Object.keys(this.dataForm.controls).forEach(fc => this.dataForm.removeControl(fc));
  }

  displayNameItemFormData() {
    const faDisplayNameValues: FormArray = <FormArray>this.dataForm.controls['diplayNameItem'];

    this.langOnScope.forEach(lang => {
      const dp = find(this.displayNameItem, obj => obj.language === lang);
        faDisplayNameValues.push(new FormGroup({
          language: new FormControl(lang, Validators.required),
          value: new FormControl(dp && dp.value ? dp.value : '', Validators.required)
        }));
    });
  }

  choicelistFormData() {

    this.faChoiseList = <FormArray>this.dataForm.controls['choicelist'];

    this.choicelist.map((opt, i) => {

      this.faChoiseList.push(new FormGroup({
        // symbolicName: new FormControl(''),
        symbolicName: new FormControl(opt.symbolicName, Validators.required),
        displayNameValues: new FormArray([])
      }));

      const faDisplayNameValues: FormArray = <FormArray>this.faChoiseList.controls[i]['controls']['displayNameValues'];
      if (this.langOnScope) {
        this.langOnScope.forEach((lang, ii ) => {
          // console.log(opt.displayNameValues[i] && opt.displayNameValues[i].language === lang ? opt.displayNameValues[i].value)
          faDisplayNameValues.push(new FormGroup({
            language: new FormControl(lang, Validators.required),
            // tslint:disable-next-line:max-line-length
            value: new FormControl(opt.displayNameValues[ii] && opt.displayNameValues[ii].language === lang ? opt.displayNameValues[ii].value : '', Validators.required)
          }));
        });
      }
    });
  }

  onTypeChange(type) {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    // if (this.faChoiseList && !this.faChoiseList.valid ) { this.removeRow(0); }
    if (type === 'choicelist' && this.choicelist.length === 0) { this.addRow(); }
  }

  removeRow(index: number) {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    this.faChoiseList.removeAt(index);
  }

  addRow() {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    this.faChoiseList.push(new FormGroup({
      // symbolicName: new FormControl(''),
      symbolicName: new FormControl('', Validators.required),
      displayNameValues: new FormArray([])
    }));

    // tslint:disable-next-line:max-line-length
    const faDisplayNameValues: FormArray = <FormArray>this.faChoiseList.controls[this.faChoiseList.controls.length - 1]['controls']['displayNameValues'];
    if (this.langOnScope) {
      this.langOnScope.forEach(lang => {
        faDisplayNameValues.push(new FormGroup({
          language: new FormControl(lang, Validators.required),
          // tslint:disable-next-line:max-line-length
          value: new FormControl('', Validators.required)
        }));
      });
    }
  }

  save(dataForm) {
    // console.log(dataForm)
    if (dataForm.type !== 'string') {
      dataForm = Object.assign(dataForm, { pattern: '' } );
    }
    // console.log(dataForm)
    this.tagEffect.putTagsById(dataForm.id, dataForm);

  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscriberSearchResult.unsubscribe();
    this.subscriberBusinessScopeResult.unsubscribe();
    this.subscriberSearchResultSuccess.unsubscribe();
  }
}

