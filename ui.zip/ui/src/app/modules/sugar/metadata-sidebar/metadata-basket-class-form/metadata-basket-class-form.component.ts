import { Basket } from 'app/models/basket';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { Subscription } from 'rxjs';
import { BusinessScope } from 'app/models/business-scope';
import { Store, select } from '@ngrx/store';
import { AssociatedTag } from 'app/models/associated-tag';
import { Tag } from 'app/models/tag';
import { FolderTypes } from 'app/models/folder-types';
import { DisplayNameItem } from 'app/models/display-name-item';
import { DocumentTypesAndTagsEffect } from 'app/effects/document-types-and-tags.effects';

import { BasketEffect } from 'app/effects/basket.effect';

import * as fromRoot from 'app/reducers';
import * as basketActions from 'app/actions/basket.actions';

import { find } from 'lodash';

@Component({
  selector: 'app-metadata-basket-class-form',
  templateUrl: './metadata-basket-class-form.component.html',
  styleUrls: ['./metadata-basket-class-form.component.scss']
})
export class MetadataBasketClassFormComponent implements OnInit, OnDestroy {

  public dataForm: FormGroup;
  public searchResult$: Observable<Basket>;
  public businessScopeResult$: Observable<BusinessScope>;
  public tags$: Observable<Tag>;
  public retentionDurationValues$: Observable<Array<any>>;
  public tooglingState$: Observable<boolean>;
  public updatingBasketType$: Observable<boolean>;
  public updatingBasketTypeResult$: Observable<Array<any>>;
  public updatingBasketTypeError$: Observable<Error>;
  public basketLoading$: Observable<boolean>;

  public deleteBasket$: Observable<boolean>;
  public deleteBasketSuccess$: Observable<string>;
  public deleteBasketError$: Observable<Error>;

  public subscriberSearchResult: Subscription;
  public subscriberBusinessScopeResult: Subscription;
  public subscriberUpdatingBasketTypeResult: Subscription;

  public faTagList: FormArray;

  currentBasketType: FolderTypes | any;

  tagList: Array<AssociatedTag>;
  allowedChildren: Array<any>;
  displayNameItem: Array<DisplayNameItem>;
  langOnScope: Array<string>;
  subscriberDeleteResult: Subscription;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public basketEffect: BasketEffect,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect
  ) {

    this.searchResult$ = store.pipe(select(fromRoot.getSearchPreviewResults));
    this.basketLoading$ = store.pipe(select(fromRoot.getBasketsLoading));

    this.subscriberSearchResult = this.searchResult$.subscribe(basket => {

      if (basket && basket.basketId && basket.hasOwnProperty('basketId')) {
        this.currentBasketType = basket;
        if (this.dataForm) { this.removeControls(); }
        this.initForm(basket);
      }
    });

    this.businessScopeResult$ = store.pipe(select(fromRoot.getBusinessScopeFirstResult));

    this.subscriberBusinessScopeResult = this.businessScopeResult$.subscribe(businessScope => {
      if (businessScope) {
        this.langOnScope = businessScope.languages;
        this.displayNameItemFormData();
      }
    });

    this.updatingBasketType$ = store.pipe(select(fromRoot.getBasketsUpdating));

    this.updatingBasketTypeError$ = store.pipe(select(fromRoot.getBasketsUpdateError));
    this.updatingBasketTypeResult$ = store.pipe(select(fromRoot.getBasketsUpdateResult));

    this.subscriberUpdatingBasketTypeResult = this.updatingBasketTypeResult$.subscribe(result => {
      if (result) {
        this.dataForm.reset();
        this.currentBasketType = result;
        this.initForm(result);
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
      }
    });


    this.deleteBasket$ = store.pipe(select(fromRoot.getBasketsDeleteLoading));
    this.deleteBasketError$ = store.pipe(select(fromRoot.getBasketsDeleteError));
    this.deleteBasketSuccess$ = store.pipe(select(fromRoot.getBasketsDeleteResult));

    this.subscriberDeleteResult = this.deleteBasketSuccess$.subscribe( success => {
      if ( success ) {
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
      }
    });
}

  initForm(folderType) {
    this.displayNameItem = folderType.displayNameItem;

    // tslint:disable-next-line:max-line-length
    this.dataForm = this.formBuilder.group(Object.assign({}, folderType, { displayNameItem: null }));

    this.dataForm.setControl('displayNameItem', new FormArray([]));
    if (this.langOnScope) { this.displayNameItemFormData(); }
  }

  removeControls() {
    Object.keys(this.dataForm.controls).forEach(fc => this.dataForm.removeControl(fc));
  }

  displayNameItemFormData() {
    const faDisplayNameValues: FormArray = <FormArray>this.dataForm.controls['displayNameItem'];

    this.langOnScope.forEach(lang => {
      const dp = find(this.displayNameItem, obj => obj.language === lang);
      faDisplayNameValues.push(new FormGroup({
        language: new FormControl(lang, Validators.required),
        value: new FormControl(dp && dp.value ? dp.value : '', Validators.required)
      }));
    });

  }

  delete() {
    this.basketEffect.deleteBasketsById(this.currentBasketType.basketId);
    this.store.dispatch(new basketActions.PutCurrentBasket(null));

  }

  save(dataForm) {
    // console.log(dataForm);
    this.basketEffect.putBasketsById(dataForm.basketId, Object.assign({}, dataForm , { aclList: null} ));
  }

  ngOnInit() {}

  ngOnDestroy() {
    this.subscriberBusinessScopeResult.unsubscribe();
    this.subscriberSearchResult.unsubscribe();
    this.subscriberUpdatingBasketTypeResult.unsubscribe();
  }

}
