import { QueryParams } from 'app/models/paged';
import { Subscription } from 'rxjs';
import { Folder } from 'app/models/folder';

import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';

import {
  FormGroup,
  FormBuilder} from '@angular/forms';

import * as fromRoot from 'app/reducers';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
import * as folderActions from 'app/actions/folder.actions';

import { FolderEffect } from 'app/effects/folder.effect';

@Component({
  selector: 'app-metadata-folder-form',
  templateUrl: './metadata-folder-form.component.html',
  styleUrls: ['./metadata-folder-form.component.scss']
})
export class MetadataFolderFormComponent implements OnInit, OnDestroy {

  public metadataForm: FormGroup;
  public extraMetadataForm: FormGroup;
  public searchResult$: Observable<Folder>;
  public isUpdateting$: Observable<boolean>;
  public updated$: Observable<any>;

  public lastQuery$: Observable<QueryParams>;

  public error$: Observable<Error>;
  public subscriberSearchResult: Subscription;
  public subscriberUpdateResult: Subscription;
  public subscriberLastQuery: Subscription;

  public metadataFormSubscrition;

  lastQuery: QueryParams;
  selectedFolderType: any;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public folderEffect: FolderEffect,
  ) {

    this.extraMetadataForm = this.formBuilder.group({});
    // this.metadataForm = formBuilder.group({});

    this.searchResult$ = store.pipe(select(fromRoot.getSearchPreviewResults));
    this.subscriberSearchResult = this.searchResult$.subscribe(folder => {
      this.store.dispatch(new folderActions.InitUpdateFolder());

      const folderNew = Object.assign(Object.assign({}, folder, { tagList: null, listOfDocumentId: null }));

      if (folder && folderNew.id) {
        // this.metadataForm = formBuilder.group(new Document);
        this.selectedFolderType = folderNew.folderTypeId;
        // console.log(Object.assign({}, folder, { tagList: null, listOfDocumentId: null }))
        this.metadataForm = this.formBuilder.group(folderNew);
        this.removeControls(this.extraMetadataForm);
      }

    });

    this.isUpdateting$ = store.pipe(select(fromRoot.getFolderUpdating));
    this.error$ = store.pipe(select(fromRoot.getFolderUpdateError));

    this.lastQuery$ = store.pipe(select(fromRoot.getSearchPagedQuery));

    this.updated$ = store.pipe(select( fromRoot.getFolderUpdateResult));
    this.subscriberLastQuery = this.lastQuery$.subscribe( lastQuery => this.lastQuery = lastQuery );

    this.subscriberUpdateResult = this.updated$.subscribe( id => {
      if (id && this.lastQuery) {
        this.folderEffect.getFolders(this.lastQuery);
      }
    });


  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).forEach( fc => this.extraMetadataForm.removeControl(fc));
  }

  update(folder) {
    this.store.dispatch(new searchPreviewActions.PutSearchResultsSearchPreview(folder));
  }

  updateDocTypeId( folderTypeId ) {
    this.selectedFolderType = folderTypeId;
    // Object.assign({}, this.metadataForm, { docTypeId: docTypeId });
  }

  save(metadataForm, extraMetadataForm) {

    const formModel = Object.assign({}, metadataForm, {
      tagList: Object.keys(extraMetadataForm).map(function (key) {
        // return { 'tagName': extraMetadataForm[key], 'tagValue': key };
        return { 'tagValue': extraMetadataForm[key], 'tagName': key };

      }),
      // folderTypeId: this.selectedFolderType.id,
      // folderTypeVersion: this.selectedFolderType.version
      folderTypeId: this.selectedFolderType.id,
      folderTypeVersion: this.selectedFolderType.version

    });
    // console.log(this.metadataForm, this.extraMetadataForm);
    // console.log(formModel)
    this.folderEffect.putFolderById(formModel.id, formModel);

    // this.store.dispatch(new searchPagedAction.PutSearchResultsSearchByID(document));
  }

  cancel() {
    // this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
  }

  ngOnInit() {
    // this.initSubcrition();
    // this.store.dispatch(new searchPagedAction.PutSearchResultsSearchByID())
  }

  ngOnDestroy() {
    this.subscriberSearchResult.unsubscribe();
    this.subscriberUpdateResult.unsubscribe();
    this.subscriberLastQuery.unsubscribe();
  }

}
