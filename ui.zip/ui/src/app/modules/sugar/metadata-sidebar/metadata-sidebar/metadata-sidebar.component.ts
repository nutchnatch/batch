import { MetadataBar } from 'app/models/sidesbars-config';
import { Observable } from 'rxjs';
import { Component } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';

@Component({
  selector: 'app-metadata-sidebar',
  templateUrl: './metadata-sidebar.component.html',
  styleUrls: ['./metadata-sidebar.component.scss']
})
export class MetadataSidebarComponent  {

  public metadataBarConfig$: Observable<MetadataBar>;
  public searchResult$: Observable<Document>;
  public searchType$: Observable<string>;
  public currentLanguage$: Observable<string>;


  constructor(
    store: Store<fromRoot.State>
  ) {
    this.metadataBarConfig$ = store.pipe(select(fromRoot.getMetadataBarParams));
    this.searchResult$ = store.pipe(select(fromRoot.getSearchPreviewResults));
    this.searchType$ = store.pipe(select(fromRoot.getSearchPagedType));
    this.currentLanguage$ = store.pipe(select(fromRoot.getCurrentLanguage));
    this.searchType$ = store.pipe(select(fromRoot.getSearchPreviewType));

  }
}
