import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';


import * as fromRoot from 'app/reducers';

@Component({
  selector: 'app-metadata-sidebar-previews',
  templateUrl: './metadata-sidebar-previews.component.html',
  styleUrls: ['./metadata-sidebar-previews.component.scss']
})
export class MetadataSidebarPreviewsComponent implements OnInit, OnDestroy {

  public searchType$: Observable<string>;
  public hasResults$: Observable<boolean>;

  constructor(
    public store: Store<fromRoot.State>,
  ) {

    this.searchType$ = store.pipe(select(fromRoot.getSearchPreviewType));
    this.hasResults$ = store.pipe(select(fromRoot.getSearchPreviewHasResult));
   }

  ngOnInit() {
  }

  ngOnDestroy() {
  }

}
