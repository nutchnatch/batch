/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { MetadataEnvelopeClassFormComponent } from './metadata-envelope-class-form.component';

describe('MetadataEnvelopeClassFormComponent', () => {
  let component: MetadataEnvelopeClassFormComponent;
  let fixture: ComponentFixture<MetadataEnvelopeClassFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetadataEnvelopeClassFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetadataEnvelopeClassFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
