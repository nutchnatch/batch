import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetadataDocumentFormComponent } from './metadata-document-form.component';

describe('MetadataDocumentFormComponent', () => {
  let component: MetadataDocumentFormComponent;
  let fixture: ComponentFixture<MetadataDocumentFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetadataDocumentFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetadataDocumentFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
