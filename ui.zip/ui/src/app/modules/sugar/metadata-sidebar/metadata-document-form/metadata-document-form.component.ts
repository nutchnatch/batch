import { Envelope } from 'app/models/envelope';
import { EnvelopeEffect } from 'app/effects/envelope.effect';
import { Router } from '@angular/router';
import { QueryParams } from 'app/models/paged';
import { DocumentEffect } from 'app/effects/document.effect';
import { Subscription } from 'rxjs';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Document } from 'app/models/document';
import { Error } from 'app/models/error';

import { filter, find } from 'lodash';

import {
  FormGroup,
  FormBuilder,
  Validators} from '@angular/forms';

import * as fromRoot from 'app/reducers';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
import * as documentsActions from 'app/actions/documents.actions';
import * as envelopeActions from 'app/actions/envelope.actions';
import * as folderActions from 'app/actions/folder.actions';
import * as appConfigActions from 'app/actions/app-config.actions';

import { TagClone } from 'app/models/tag';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { DateParserFormaterServices } from 'app/services/date-parser-formater/date-parser-formater.service';

const now = new Date();

@Component({
  selector: 'app-metadata-document-form',
  templateUrl: './metadata-document-form.component.html',
  styleUrls: ['./metadata-document-form.component.scss']
})
export class MetadataDocumentFormComponent implements OnInit, OnDestroy {

  public metadataForm: FormGroup;
  public extraMetadataForm: FormGroup;
  public searchResultPreview$: Observable<Document>;
  public searchResultPreviewType$: Observable<string>;
  public isUpdateting$: Observable<boolean>;
  public langs$: Observable<Array<any>>;
  public favoriteLang$: Observable<Array<any>>;
  public error$: Observable<Error>;
  public updated$: Observable<any>;
  public lastQuery$: Observable<QueryParams>;
  public confidentialLevel$: Observable<Array<any>>;
  public envelopeStatus$: Observable<Envelope>;
  public allDataLoaded$: Observable<boolean>;

  public userDetailsAuthorities$: Observable<Array<any>>;

  public subscriberSearchResult: Subscription;
  public subscriberSearchResultType: Subscription;
  public subscriberLastQuery: Subscription;
  public subscriberUpdateResult: Subscription;
  public subscriberLanguages: Subscription;
  public subscriberFavoriteLang: Subscription;
  public subscriberDetailsAuthorities: Subscription;
  public subscriberEnvelopeStatus: Subscription;

  public copiedTags$: Observable<Array<TagClone>>;

  listOfFolderMemory: Array<any>;
  listIsoLangs: Array<any>;
  listFavoriteLangs: Array<any>;
  lastQuery: any;
  selectedDocType: any;
  selectedDocType2: any;
  dpDate; // = {year: 2000, month: 2};
  parseDate;
  previewType;
  roles;
  confidentiality;
  futureConfidentiality;
  oldValidity;
  showWarning = false;
  envelopeStatus;

  constructor(
    public store: Store<fromRoot.State>,
    public router: Router,
    public formBuilder: FormBuilder,
    public documentEffect: DocumentEffect,
    public envelopeEffect: EnvelopeEffect,
    public dateToUCT: DateParserFormaterServices,
    public dateParserFormatter: NgbDateParserFormatter
  ) {

    this.extraMetadataForm = this.formBuilder.group({});

    this.envelopeStatus$ = store.pipe(select(fromRoot.getEnvelopeResult));
    this.subscriberEnvelopeStatus = this.envelopeStatus$.subscribe(status => {
      if (status) { this.envelopeStatus = status[0].validity; }
    });

    this.searchResultPreviewType$ = store.pipe(select(fromRoot.getSearchPreviewType));
    this.subscriberSearchResultType = this.searchResultPreviewType$.subscribe(type => this.previewType = type);


    this.isUpdateting$ = store.pipe(select(fromRoot.getDocumentsUpdating));
    this.error$ = store.pipe(select(fromRoot.getDocumentsUpdateError));

    this.lastQuery$ = store.pipe(select(fromRoot.getSearchPagedQuery));

    this.subscriberLastQuery = this.lastQuery$.subscribe(lastQuery => this.lastQuery = lastQuery);


    this.copiedTags$ = store.pipe(select(fromRoot.getAppConfigCopiedTags));
    this.confidentialLevel$ = store.pipe(select(fromRoot.getAppConfigConfidentialLevels));

    this.langs$ = store.pipe(select(fromRoot.getAppConfigLangISO));

    this.subscriberLanguages = this.langs$.subscribe(langs => this.listIsoLangs = langs);

    this.favoriteLang$ = store.pipe(select(fromRoot.getBusinessScopePreferredLanguages));

    this.subscriberFavoriteLang = this.favoriteLang$.subscribe(favoriteLang => {
      const cleanedFavoriteLang = filter(favoriteLang, (lang) => lang !== '');
      if (cleanedFavoriteLang.length > 0) {
        this.listFavoriteLangs = cleanedFavoriteLang.map(fl => {
          return find(this.listIsoLangs, (lang) => lang.code === fl);
        });
      } else {
        this.listFavoriteLangs = [];
      }
    });

    this.userDetailsAuthorities$ = store.pipe(select(fromRoot.getUserDetailsAuthorities));
    this.subscriberDetailsAuthorities = this.userDetailsAuthorities$.subscribe(roles => this.roles = roles);

    // this.metadataForm = formBuilder.group(new Document);
    this.searchResultPreview$ = store.pipe(select(fromRoot.getSearchPreviewResults));
    this.subscriberSearchResult = this.searchResultPreview$.subscribe(document => {

      // this.store.dispatch(new documentsActions.InitUpdateDocument());
      if (document && document.id) {

        this.confidentiality = document.confidentiality;
        this.futureConfidentiality = document.validity;

        if (this.previewType === 'documents_single') { this.store.dispatch(new envelopeActions.PutListDocumentName(document)); }
        if (this.previewType === 'folder_single') { this.store.dispatch(new folderActions.PutListDocumentName(document)); }
        // this.metadataForm = formBuilder.group(new Document);
        // this.selectedDocType = document.docTypeId;
        this.selectedDocType = Object.assign({}, this.selectedDocType, { id: document.docTypeId, version: document.docTypeVersion });

        this.metadataForm = this.formBuilder.group(
          Object.assign({}, document, { tagList: null, folderList: null }),
        );
        this.listOfFolderMemory = document.folderList;

        // if (this.metadataForm.value.retentionStartDate) {
        //   this.dpDate = dateParserFormatter.parse(this.metadataForm.value.retentionStartDate);
        //   this.parseDate = this.metadataForm.value.retentionStartDate;
        // } else {
        //   this.dpDate = {year: now.getFullYear(), month: now.getMonth() + 1, day: now.getDate()};
        //   this.parseDate = this.dateToUCT.ngbDatepickerUTCDate(this.dpDate);
        // }

        this.setRetentionStartDate(this.metadataForm.value.retentionStartDate);
        this.setConfidentiality(this.metadataForm.value.confidentiality);

        this.metadataForm.controls['name'].setValidators(Validators.required);
        this.removeControls(this.extraMetadataForm);
      }

      this.allDataLoaded$ = this.store.select(fromRoot.getBusinessScopeAllLoaded);

    });

    this.isUpdateting$ = store.pipe(select(fromRoot.getDocumentsUpdating));
    this.error$ = store.pipe(select(fromRoot.getDocumentsUpdateError));

    this.lastQuery$ = store.pipe(select(fromRoot.getSearchPagedQuery));

    this.updated$ = store.pipe(select(fromRoot.getDocumentsUpdateResult));
    this.subscriberLastQuery = this.lastQuery$.subscribe(lastQuery => this.lastQuery = lastQuery);

    this.subscriberUpdateResult = this.updated$.subscribe(result => {

      // tslint:disable-next-line:max-line-length
      if (result && this.lastQuery && !this.router.routerState.snapshot.url.match('envelope') && !this.router.routerState.snapshot.url.match('folder')) {
        // tslint:disable-next-line:max-line-length
        const avoidUnderConstruction = Object.assign({}, this.lastQuery, { validity: this.lastQuery.validity ? this.lastQuery.validity : 'not_equals_to|UNDER_CONSTRUCTION' });
        this.documentEffect.getDocuments(avoidUnderConstruction);
      }

      if (result && !this.lastQuery) {
        this.documentEffect.getDocumentsById(result.documentId);
      }

      if (result && this.router.routerState.snapshot.url.match('envelope') && this.envelopeStatus === 'INVALID') {
        this.envelopeEffect.getEnvelopeById(result.envelopeId, false);
      }

      if (result && this.futureConfidentiality === 'UNDER_CONSTRUCTION') {
        this.documentEffect.getDocumentsById(result.documentId, false);

      }
      // console.log(this.futureConfidentiality);
      if (result && this.futureConfidentiality === 'CONFIDENTIAL') {
        this.router.navigate(['app/refresh'], { queryParams: { url: this.router.routerState.snapshot.url } });
      }
    });
  }

  hasRole(role): boolean {
    return find(this.roles, r => r === role);
  }

  setRetentionStartDate(date) {
    if (date) {
      this.dpDate = this.dateParserFormatter.parse(date);
      this.parseDate = date;
    } else {
      this.dpDate = { year: now.getFullYear(), month: now.getMonth() + 1, day: now.getDate() };
      this.parseDate = this.dateToUCT.ngbDatepickerUTCDate(this.dpDate);
    }
  }

  setConfidentiality(confidentiality) {
    if (!confidentiality) { this.metadataForm.controls['confidentiality'].setValue('PUBLIC'); }
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).forEach(fc => this.extraMetadataForm.removeControl(fc));
  }

  update(document) {
    this.store.dispatch(new searchPreviewActions.PutSearchResultsSearchPreview(document));
  }

  updateDocFormTypeId(docType) {
    this.selectedDocType = docType;
    // Object.assign({}, this.metadataForm, { docTypeId: docTypeId });
  }

  updateToModel(newValue) {
    this.parseDate = this.dateToUCT.ngbDatepickerUTCDate(newValue);
  }

  changeConfidentiality(value) {
    this.futureConfidentiality = value;
    // tslint:disable-next-line:max-line-length
    this.showWarning = !this.hasRole('SUGAR_CONFIDENTIAL_USER_ROLE') && value === 'CONFIDENTIAL' && this.confidentiality !== 'CONFIDENTIAL';

  }

  save(metadataForm, extraMetadataForm) {

    if (this.metadataForm.valid && this.extraMetadataForm.valid) {
      const formModel = Object.assign({}, metadataForm, {
        tagList: Object.keys(extraMetadataForm).map(function (key) {
          // return { 'tagName': extraMetadataForm[key], 'tagValue': key };
          return { 'tagValue': extraMetadataForm[key], 'tagName': key };
        }),
        folderList: this.listOfFolderMemory,
        docTypeId: this.selectedDocType.id,
        docTypeVersion: this.selectedDocType.version
      });

      const formDateFINAL = Object.assign({}, formModel, {
        retentionStartDate: this.parseDate // this.dateToUCT.ngbDatepickerUTCDate(this.metadataForm.value.retentionStartDate),
        // retentionEndDate: this.dateToUCT.ngbDatepickerUTCDate(this.metadataForm.value.retentionEndDate),
      });
      this.documentEffect.putDocumentsById(formModel.id, formDateFINAL);
      this.store.dispatch(new appConfigActions.PutCopiedTagsAction(null));

    }

    // console.log(metadataForm, extraMetadataForm)
    // this.store.dispatch(new searchPagedAction.PutSearchResultsSearchByID(document));
  }

  cancel() {
    // this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
  }

  ngOnInit() {
    // this.changeConfidentiality();
  }

  ngOnDestroy() {
    this.subscriberSearchResult.unsubscribe();
    this.subscriberUpdateResult.unsubscribe();
    this.subscriberLastQuery.unsubscribe();
    this.subscriberFavoriteLang.unsubscribe();
    this.subscriberDetailsAuthorities.unsubscribe();
    this.metadataForm.reset();
    this.extraMetadataForm.reset();
    this.subscriberEnvelopeStatus.unsubscribe();
    this.store.dispatch(new documentsActions.InitUpdateDocument());
    // this.store.dispatch(new documentsActions.InitPutDocument());
    if (this.extraMetadataForm) { this.extraMetadataForm.reset(); }
    if (this.metadataForm) { this.metadataForm.reset(); }
  }

}
