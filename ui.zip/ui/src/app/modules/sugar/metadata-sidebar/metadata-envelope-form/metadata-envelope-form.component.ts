import { QueryParams } from 'app/models/paged';
import { EnvelopeEffect } from './../../../../effects/envelope.effect';
import { Subscription } from 'rxjs';
import { Envelope } from 'app/models/envelope';

import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';

import {
  FormGroup,
  FormBuilder} from '@angular/forms';

import * as fromRoot from 'app/reducers';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
import * as envelopeActions from 'app/actions/envelope.actions';

@Component({
  selector: 'app-metadata-envelope-form',
  templateUrl: './metadata-envelope-form.component.html',
  styleUrls: ['./metadata-envelope-form.component.scss']
})
export class MetadataEnvelopeFormComponent implements OnInit, OnDestroy {

  public metadataForm: FormGroup;
  public extraMetadataForm: FormGroup;
  public searchResult$: Observable<Envelope>;
  public isUpdateting$: Observable<boolean>;
  public error$: Observable<Error>;
  public updated$: Observable<any>;
  public lastQuery$: Observable<QueryParams>;
  public directionType$: Observable<Array<string>>;

  public subscriberSearchResult: Subscription;
  public subscriberUpdateResult: Subscription;
  public subscriberLastQuery: Subscription;

  lastQuery: any;
  selecteEnvType: any;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public envelopeEffect: EnvelopeEffect
  ) {

    this.extraMetadataForm = this.formBuilder.group({});
    this.directionType$ = store.pipe(select(fromRoot.getAppConfigDirectionTypes));

    // this.metadataForm = formBuilder.group(new Document);
    this.searchResult$ = store.pipe(select(fromRoot.getSearchPreviewResults));
    this.subscriberSearchResult = this.searchResult$.subscribe(envelope => {
      this.store.dispatch(new envelopeActions.InitUpdateEnvelope());
      const envelopeNew = Object.assign(Object.assign({}, envelope, { tagList: null, listOfDocumentId: null }));

      if (envelope && envelopeNew.id) {
        // this.metadataForm = formBuilder.group(new Document);
        this.selecteEnvType = envelopeNew.envTypeId;
        // console.log(Object.assign({}, envelope, { tagList: null, listOfDocumentId: null }))
        this.metadataForm = this.formBuilder.group(envelopeNew);
        this.removeControls(this.extraMetadataForm);
      }

    });

    this.isUpdateting$ = store.pipe(select(fromRoot.getEnvelopeUpdating));
    this.error$ = store.pipe(select(fromRoot.getEnvelopeUpdateError));

    this.lastQuery$ = store.pipe(select(fromRoot.getSearchPagedQuery));

    this.updated$ = store.pipe(select( fromRoot.getEnvelopeUpdateResult));
    this.subscriberLastQuery = this.lastQuery$.subscribe( lastQuery => this.lastQuery = lastQuery );

    this.subscriberUpdateResult = this.updated$.subscribe( id => {
      if (id && this.lastQuery) {
        // tslint:disable-next-line:max-line-length
        const avoidUnderConstruction = Object.assign({}, this.lastQuery, { validity: this.lastQuery.validity ? this.lastQuery.validity : 'not_equals_to|UNDER_CONSTRUCTION' });
        this.envelopeEffect.getEnvelopes(avoidUnderConstruction);
      }
    });
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).forEach(fc => this.extraMetadataForm.removeControl(fc));
  }

  update(envelope) {
    this.store.dispatch(new searchPreviewActions.PutSearchResultsSearchPreview(envelope));
  }

  updateDocTypeId(envTypeId) {
    this.selecteEnvType = envTypeId;
    // Object.assign({}, this.metadataForm, { docTypeId: docTypeId });
  }

  save(metadataForm, extraMetadataForm) {
    const formModel = Object.assign({}, metadataForm, {
      tagList: Object.keys(extraMetadataForm).map(function (key) {
        // return { 'tagName': extraMetadataForm[key], 'tagValue': key };
        return { 'tagValue': extraMetadataForm[key], 'tagName': key };

      }),
      envTypeId: this.selecteEnvType.id
    });
    // console.log(this.metadataForm, this.extraMetadataForm);
    // console.log(formModel);
    this.envelopeEffect.putEnvelopeById(formModel.id, formModel);
  }

  ngOnInit() {}

  ngOnDestroy() {
    this.subscriberSearchResult.unsubscribe();
    this.subscriberUpdateResult.unsubscribe();
    this.subscriberLastQuery.unsubscribe();
  }

}
