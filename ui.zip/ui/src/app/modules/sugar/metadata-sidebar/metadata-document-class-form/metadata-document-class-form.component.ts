import { Component, OnInit, OnDestroy } from '@angular/core';
import { DocumentTypesAndTagsEffect } from 'app/effects/document-types-and-tags.effects';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { Subscription } from 'rxjs';
import { BusinessScope } from 'app/models/business-scope';
import { Store, select } from '@ngrx/store';
import { AssociatedTag } from 'app/models/associated-tag';
import { Tag } from 'app/models/tag';
import { DocumentTypes } from 'app/models/document-types';
import { DocumentTypeEffect } from 'app/effects/document-types.effects';
import { DisplayNameItem } from 'app/models/display-name-item';


import * as fromRoot from 'app/reducers';

import { find } from 'lodash';
import { Acl } from 'app/models/acl';

@Component({
  selector: 'app-metadata-document-class-form',
  templateUrl: './metadata-document-class-form.component.html',
  styleUrls: ['./metadata-document-class-form.component.scss']
})
export class MetadataDocumentClassFormComponent implements OnInit, OnDestroy {

  public dataForm: FormGroup;
  public searchResult$: Observable<DocumentTypes>;
  public businessScopeResult$: Observable<BusinessScope>;
  public tags$: Observable<Tag>;
  public retentionDurationValues$:  Observable<Array<any>>;
  public tooglingState$: Observable<boolean>;
  public updatingDocumentType$: Observable<boolean>;
  public updatingDocumentTypeResult$: Observable<Array<any>>;
  public updatingDocumentTypeError$: Observable<Error>;

  public subscriberSearchResult: Subscription;
  public subscriberBusinessScopeResult: Subscription;
  public subscriberUpdatingDocumentTypeResult: Subscription;

  public faTagList: FormArray;

  currentEnvelopeType: DocumentTypes | any;

  tagList: Array<AssociatedTag>;
  allowedChildren: Array<any>;
  displayNameList: Array<DisplayNameItem>;
  langOnScope: Array<string>;
  aclList: Array<Acl>;

  public selectedTags: any = {};
  oldValue: Array<any> = new Array();

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public documentTypeEffect: DocumentTypeEffect,
    public documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,
  ) {

    this.tooglingState$ = store.pipe(select(fromRoot.getDocumentTypesTooglingState));
    this.retentionDurationValues$ = store.pipe(select(fromRoot.getAppConfigRetentionDuration ));

    this.searchResult$ = store.pipe(select(fromRoot.getSearchPreviewResults));

    this.subscriberSearchResult = this.searchResult$.subscribe(envelopeType => {

      if (envelopeType && envelopeType.id && envelopeType.hasOwnProperty('retentionDurationUnit')) {
        this.currentEnvelopeType = envelopeType;
        if (this.dataForm) { this.removeControls(); }
        this.initForm(envelopeType);
      }
    });

    this.businessScopeResult$ = store.pipe(select(fromRoot.getBusinessScopeFirstResult));

    this.subscriberBusinessScopeResult = this.businessScopeResult$.subscribe(businessScope => {
      if (businessScope) {
        this.langOnScope = businessScope.languages;
        this.dataForm.setControl('displayNameList', new FormArray([]));
        this.displayNameListFormData();
      }
    });

    this.tags$ = store.pipe(select(fromRoot.getTagsResult));
    // this.tags$.subscribe( v => console.log(v))
    this.updatingDocumentType$ = store.pipe(select(fromRoot.getDocumentTypesUpdating));

    this.updatingDocumentTypeError$ = store.pipe(select(fromRoot.getDocumentTypesUpdatingError));
    this.updatingDocumentTypeResult$ = store.pipe(select(fromRoot.getDocumentTypesUpdatingResult));

    this.subscriberUpdatingDocumentTypeResult = this.updatingDocumentTypeResult$.subscribe(result => {
      if (result) {
        this.dataForm.reset();
        this.currentEnvelopeType = result;
        this.initForm(result);
        this.documentTypesAndTagsEffect.getDocumentAndTagsTypes();
      }
    });
  }

  initForm(documentType) {

    this.allowedChildren = documentType.allowedChildren;
    this.displayNameList = documentType.displayNameList;
    this.tagList = documentType.tagList;
    this.aclList = documentType.aclList;
    // tslint:disable-next-line:max-line-length
    this.dataForm = this.formBuilder.group(Object.assign({}, documentType, {
      tagList: null,
      allowedChildren: null,
      displayNameList: null,
      aclList: null
    }));

    this.dataForm.setControl('allowedChildren', new FormArray([]));
    this.dataForm.setControl('displayNameList', new FormArray([]));
    this.dataForm.setControl('tagList', new FormArray([]));
    this.dataForm.setControl('aclList', new FormArray([]));

    this.selectedTags = {};
    this.oldValue = new Array();
    this.tagListFormData();
    if (this.langOnScope) { this.displayNameListFormData(); }
  }

  tagSelected(selectedTag: string, index: number) {
    this.selectedTags[selectedTag] = true;
    if (this.oldValue && this.oldValue[index]) {
      this.selectedTags[this.oldValue[index]] = false;
    }
    this.oldValue[index] = selectedTag;
  }

  removeControls() {
    Object.keys(this.dataForm.controls).forEach(fc => this.dataForm.removeControl(fc));
  }

  displayNameListFormData() {

    const faDisplayNameValues: FormArray = <FormArray>this.dataForm.controls['displayNameList'];

    this.langOnScope.forEach(lang => {
      const dp = find(this.displayNameList, obj => obj.language === lang);
        faDisplayNameValues.push(new FormGroup({
        language: new FormControl(lang, Validators.required),
        value: new FormControl(dp && dp.value ? dp.value : '', Validators.required)
      }));
    });

  }

  tagListFormData() {

    this.faTagList = <FormArray>this.dataForm.controls['tagList'];

    this.tagList.forEach((opt, i) => {

      this.faTagList.push(new FormGroup({
        mandatory: new FormControl(opt.mandatory ? opt.mandatory : false),
        symbolicName: new FormControl(opt.symbolicName ? opt.symbolicName : '', Validators.required),
        multivalued: new FormControl(opt.multivalued ? opt.multivalued : false)
      }));
      this.selectedTags[opt.symbolicName] = true;
      this.oldValue[i] = opt.symbolicName;
    });

  }

  onChange(docType: DocumentTypes) {
    if (docType.active) {
      this.documentTypeEffect.putDocumentTypesDeactivate(docType.id, docType.version);
    } else {
      this.documentTypeEffect.putDocumentTypesActivate(docType.id, docType.version);
    }
  }

  addRow() {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    this.faTagList.push(new FormGroup({
      mandatory: new FormControl(false),
      symbolicName: new FormControl('', Validators.required),
      multivalued: new FormControl(false)
    }));

    // tslint:disable-next-line:max-line-length
    // const faDisplayNameValues: FormArray = <FormArray>this.faTagList.controls[this.faTagList.controls.length - 1]['controls']['displayNameValues'];
    // this.langOnScope.map(lang => {
    //   faDisplayNameValues.push(new FormGroup({
    //     language: new FormControl(lang, Validators.required),
    //     // tslint:disable-next-line:max-line-length
    //     value: new FormControl('', Validators.required)
    //   }));
    // });
  }

  removeRow(index: number) {
    // const faChoiseList: FormArray = <FormArray>this.dataForm.controls['choicelist'];
    this.selectedTags[this.faTagList.at(index)['controls']['symbolicName'].value] = false;
    this.oldValue.splice(index, 1);
    this.faTagList.removeAt(index);
  }
  save(dataForm) {
    this.documentTypeEffect.putDocumentTypeById(dataForm.id, dataForm.version, dataForm);
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscriberBusinessScopeResult.unsubscribe();
    this.subscriberSearchResult.unsubscribe();
    this.subscriberUpdatingDocumentTypeResult.unsubscribe();
  }

}
