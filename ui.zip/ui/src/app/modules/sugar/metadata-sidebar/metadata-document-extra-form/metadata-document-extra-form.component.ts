import { TagClone } from 'app/models/tag';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Observable, combineLatest } from 'rxjs';
import { Component, OnInit, Input, OnDestroy, EventEmitter, Output } from '@angular/core';
import { ExtraFields } from 'app/states/extra-fields.state'; // Model

import { find } from 'lodash';

import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

import * as fromRoot from 'app/reducers';

import { DateParserFormaterServices } from 'app/services/date-parser-formater/date-parser-formater.service';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-document-metadata-extra-form',
  templateUrl: './metadata-document-extra-form.component.html',
  styleUrls: ['./metadata-document-extra-form.component.scss']
})
export class MetadataDocumentExtraFormComponent implements OnInit, OnDestroy {
  @Input() extraMetadataForm: FormGroup;
  @Output() docTypeIdSelected = new EventEmitter();

  // extraMetadataForm: FormGroup;
  currentLang$: Observable<string>;
  documentTypes$: Observable<Array<ExtraFields>>;
  currentDocumentType$: Observable<string>;
  currentDocument$: Observable<Document>;
  copiedTags$: Observable<Array<TagClone>>;
  copiedTags: Array<TagClone>;
  allDataLoaded$: Observable<boolean>;

  subDocumentTypes: any;
  subCurrentDocument: any;

  subAllFork: Subscription;
  combinedSubscribe: Subscription;
  subCurrentDocumentType: Subscription;

  originalDocTypeId;
  docTypeId;
  currentDocument;
  documentTypes;
  metadataFormSubscrition;

  dpValues: Array<any> = [];
  doc: Document;
  results;
  error: Error;
  subscribeCopiedTags: Subscription;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public dateToUCT: DateParserFormaterServices,
    public dateParserFormatter: NgbDateParserFormatter
  ) {

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));


    // this.subDocumentTypes = this.documentTypes$.subscribe(documentTypes => {
    //   this.documentTypes = documentTypes;
    // });

    this.currentDocumentType$ = store.select(fromRoot.getSearchPreviewResultsDocTypeID);
    this.subCurrentDocumentType = this.currentDocumentType$.subscribe(docTypeId => this.originalDocTypeId = docTypeId);

    this.copiedTags$ = store.pipe(select(fromRoot.getAppConfigCopiedTags));
    this.subscribeCopiedTags = this.copiedTags$.subscribe(copiedTags => {
      if (copiedTags && this.documentTypes) {
        this.copiedTags = copiedTags;
        if (this.currentDocument && this.currentDocument.docTypeId === this.docTypeId) {
          this.initExtraMetadaFormCurrentDoc();
        } else {
          this.initExtraMetadaForm();
        }
      } else {
        this.copiedTags = null;
      }
    });

  }

  initExtraMetadaFormCurrentDoc() {
    if (this.extraMetadataForm) { this.removeControls(this.extraMetadataForm); this.dpValues = []; }


    const documentsTypes = find(this.documentTypes, { id: this.docTypeId });

    if (documentsTypes && documentsTypes.hasOwnProperty('inputsFields')) {

      documentsTypes['inputsFields'].map((tag, i) => {

        const validators = tag.mandatory && tag.type === 'string' ? [Validators.pattern(new RegExp(tag.pattern))] : [];

        const copiedTag: any = find(this.copiedTags, (copyTag) => {
          return copyTag.tagName === tag.name;
        });

        const currentDocumentTag: any = find(this.currentDocument.tagList, (t) => t.tagName === tag.name);

        let value = '';

        if (currentDocumentTag && currentDocumentTag.tagName === tag.name) {

          if (tag.type === 'timestamp' && currentDocumentTag.tagName === tag.name) {
            // tslint:disable-next-line:max-line-length
            this.dpValues[tag.name] = copiedTag ? this.dateParserFormatter.parse(copiedTag.tagValue) : this.dateParserFormatter.parse(currentDocumentTag.tagValue);
          }

          if (copiedTag) {
            // tslint:disable-next-line:max-line-length
            value = currentDocumentTag.tagName === copiedTag.tagName ? copiedTag.tagValue : this.docTypeId === this.originalDocTypeId ? currentDocumentTag.tagValue : '';
          } else {
            // tslint:disable-next-line:max-line-length
            value = currentDocumentTag.tagName === tag.name ? this.docTypeId === this.originalDocTypeId ? currentDocumentTag.tagValue : '' : '';
          }
        } else {

          value = copiedTag ? copiedTag.tagValue : '';
          // console.log(copiedTag, value)
        }


        this.extraMetadataForm.addControl(tag.name, new FormControl(value, validators));
        this.extraMetadataForm.controls[tag.name].markAsTouched();
        // if (this.currentDocument.tagList[i].tagName === tag.name) { console.log(this.currentDocument.tagList[i].tagName , tag.name) }
      });
    }


  }

  initExtraMetadaForm() {
    if (this.extraMetadataForm) { this.removeControls(this.extraMetadataForm); }

    this.documentTypes.map(docType => {

      if (docType.id === this.docTypeId) {

        for (let i = 0; i < docType.inputsFields.length; i++) {
          // tslint:disable-next-line:max-line-length
          const validators = docType.inputsFields[i].mandatory ? [Validators.pattern(new RegExp(docType.inputsFields[i].pattern))] : [];
          const copiedTag: any = find(this.copiedTags, (t) => t['tagName'] === docType.inputsFields[i].name);

          // let value;
          if (copiedTag) {
            // tslint:disable-next-line:max-line-length
            if (docType.inputsFields[i].type === 'timestamp') {
              // value = this.dateParserFormatter.parse(copiedTag.tagValue);
              this.dpValues[docType.inputsFields[i].name] = this.dateParserFormatter.parse(copiedTag.tagValue);
            }

            this.extraMetadataForm.addControl(docType.inputsFields[i].name,
              new FormControl(docType.inputsFields[i].name === copiedTag.tagName ? copiedTag.tagValue : '', Validators.compose(validators))
            );
          } else {
            // tslint:disable-next-line:max-line-length
            this.extraMetadataForm.addControl(docType.inputsFields[i].name, new FormControl('', Validators.compose(validators)));
          }

          this.extraMetadataForm.controls[docType.inputsFields[i].name].markAsTouched();


        }
      }
    });

  }

  updateToModel(inputName, newValue) {
    // this.dpValues[inputName] = this.dateToUCT.ngbDatepickerUTCDate(newValue);
    // inputName = this.dateToUCT.ngbDatepickerUTCDate(newValue);
    this.extraMetadataForm.controls[inputName].setValue(this.dateToUCT.ngbDatepickerUTCDate(newValue));
    // fc.setValue = this.dateToUCT.ngbDatepickerUTCDate(newValue);
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).forEach(fc => this.extraMetadataForm.removeControl(fc));
  }

  onChange(docTypeId) {

    const docType = find(this.documentTypes, { id: docTypeId });
    if (this.currentDocument.docTypeId === docType.id) {
      this.initExtraMetadaFormCurrentDoc();
    } else {
      this.initExtraMetadaForm();
    }
    this.docTypeId = docTypeId;
    this.docTypeIdSelected.emit(docType);
  }


  ngOnInit() {

    this.currentDocument$ = this.store.pipe(select(fromRoot.getSearchPreviewResults));
    this.documentTypes$ = this.store.pipe(select(fromRoot.getExtraFieldsMetadataFields));
    this.allDataLoaded$ = this.store.pipe(select(fromRoot.getBusinessScopeAllLoaded));

    const combined = combineLatest(
      this.currentDocument$,
      this.documentTypes$,
      this.allDataLoaded$
    );

    this.combinedSubscribe = combined.subscribe(([currentDocument, types, allDataLoaded]) => {
      if (currentDocument && currentDocument.hasOwnProperty('id') && types && allDataLoaded) {
        const doc = currentDocument;
        this.documentTypes = types;
        const docType: any = find(this.documentTypes, { id: doc['docTypeId'] });

        this.docTypeId = doc['docTypeId'];
        this.currentDocument = doc;

        this.initExtraMetadaFormCurrentDoc();
        // tslint:disable-next-line:max-line-length
        this.docTypeIdSelected.emit({ id: this.docTypeId, version: docType && docType.version !== doc['docTypeVersion'] ? docType.version : doc['docTypeVersion'] });
      }
    });
  }

  ngOnDestroy() {
    if (this.subCurrentDocument) { this.subCurrentDocument.unsubscribe(); }
    // this.subDocumentTypes.unsubscribe();
    this.copiedTags = null;
    this.subscribeCopiedTags.unsubscribe();
    this.combinedSubscribe.unsubscribe();
    this.subCurrentDocumentType.unsubscribe();
    if (this.subAllFork) { this.subAllFork.unsubscribe(); }
  }

}


