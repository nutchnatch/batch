import { Folder } from 'app/models/folder';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { Component, OnInit } from '@angular/core';

import * as fromRoot from 'app/reducers';

@Component({
  selector: 'app-metadata-sidebar-folder',
  templateUrl: './metadata-sidebar-folder.component.html',
  styleUrls: ['./metadata-sidebar-folder.component.scss']
})
export class MetadataSidebarFolderComponent implements OnInit {

  folderState$: Observable<Folder>;

  constructor(
    public store: Store<fromRoot.State>,
  ) {

    this.folderState$ = store.pipe(select(fromRoot.getFolderFirstResult));
  }

  ngOnInit() {
  }

}
