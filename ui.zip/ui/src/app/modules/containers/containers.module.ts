import { ModalCreateTagCommentComponent } from './../sugar/modals/modal-create-tag-comment/modal-create-tag-comment.component';
import { QuillModule } from 'ngx-quill';
import { ModalAboutComponent } from './../sugar/modals/modal-about/modal-about.component';
import { ReportingEffect } from './../../effects/reporting.effect';
import { ModalCreateFolderClassComponent } from './../sugar/modals/modal-create-folder-class/modal-create-folder-class.component';
import { FolderTypeEffect } from './../../effects/folder-types.effects';
import { ModalCreateDocumentClassComponent } from './../sugar/modals/modal-create-document-class/modal-create-document-class.component';
import { DocumentTypeEffect } from 'app/effects/document-types.effects';
// tslint:disable-next-line:max-line-length
import { ModalCreateTagComponent } from 'app/modules/sugar/modals/modal-create-tag/modal-create-tag.component';
import { BusinessScopeEffect } from './../../effects/business-scope.effect';
import { TaskEffect } from 'app/effects/task.effect';
import { ModalCreateFolderComponent } from 'app/modules/sugar/modals/modal-create-folder/modal-create-folder.component';
import { InfoEffect } from '../../effects/application.effect';
import { DocumentTypesAndTagsEffect } from './../../effects/document-types-and-tags.effects';
import { EnvelopeEffect } from './../../effects/envelope.effect';
import { ReactiveFormsModule } from '@angular/forms';
import { DocumentEffect } from 'app/effects/document.effect';
import { SugarModule } from './../sugar/sugar.module';
import { ModalExpiredSessionComponent } from 'app/modules/tsp-ui/modals/modal-expired-session/modal-expired-session.component';
import { TspUIModule } from 'app/modules/tsp-ui/tsp-ui.module';
import { ContainersRoutingModule } from './containers-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaseComponent } from './base/base.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SearchResultsComponent } from './search-results/search-results.component';
import { EnvelopeComponent } from './envelope/envelope.component';
import { EnvelopeTypeEffect } from 'app/effects/envelope-types.effects';
import { FolderEffect } from 'app/effects/folder.effect';
import { FolderComponent } from 'app/modules/containers/folder/folder.component';
import { ModalSearchFolderComponent } from 'app/modules/sugar/modals/modal-search-folder/modal-search-folder.component';
import { UploadDocumentComponent } from './upload-document/upload-document.component';
import { BasketEffect } from 'app/effects/basket.effect';
import { ModalAlertEnvelopeComponent } from 'app/modules/sugar/modals/modal-alert-envelope/modal-alert-envelope.component';
import { TagsEffect } from '../../effects/tags.effect';
// tslint:disable-next-line:max-line-length
import { ModalCreateEnvelopeClassComponent } from 'app/modules/sugar/modals/modal-create-envelope-class/modal-create-envelope-class.component';
import { ModalCreateBasketClassComponent } from 'app/modules/sugar/modals/modal-create-basket-class/modal-create-basket-class.component';

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    ReactiveFormsModule,
    ContainersRoutingModule,
    TspUIModule,
    SugarModule,
    QuillModule
  ],
   providers: [
    DocumentEffect,
    DocumentTypesAndTagsEffect,
    EnvelopeEffect,
    EnvelopeTypeEffect,
    FolderEffect,
    InfoEffect,
    BasketEffect,
    TaskEffect,
    BusinessScopeEffect,
    TagsEffect,
    DocumentTypeEffect,
    FolderTypeEffect,
    ReportingEffect
    // EnvelopeTypeEffect
  ],
  entryComponents: [
    ModalExpiredSessionComponent,
    ModalSearchFolderComponent,
    ModalCreateFolderComponent,
    ModalAlertEnvelopeComponent,
    ModalCreateTagComponent,
    ModalCreateTagCommentComponent ,
    ModalCreateEnvelopeClassComponent,
    ModalCreateDocumentClassComponent,
    ModalCreateFolderClassComponent,
    ModalCreateBasketClassComponent,
    ModalAboutComponent
  ],
  declarations: [
    BaseComponent,
    DashboardComponent,
    SearchResultsComponent,
    EnvelopeComponent,
    FolderComponent,
    UploadDocumentComponent,

]
})
export class ContainersModule { }
