import { Title } from '@angular/platform-browser';
import { EnvelopeEffect } from 'app/effects/envelope.effect';
import { Paging } from './../../../models/paging';
import { Link, Breadcrumb } from './../../../models/breadcrumb';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { BaseComponent } from './../base/base.component';
import { PageConfig } from 'app/states/app-config.state';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as enveloperAction from 'app/actions/envelope.actions';

@Component({
  selector: 'app-upload-document',
  templateUrl: './upload-document.component.html',
  styleUrls: ['./upload-document.component.scss']
})
export class UploadDocumentComponent extends BaseComponent implements OnInit, OnDestroy {

  public pageConfig$: Observable<PageConfig>;
  public uploadDocument$: Observable<Array<File>>;
  public error$: Observable<any>;

  public subscribePageConfig: Subscription;
  public subscribeActiveRouteData: Subscription;
  public subscribeActiveRoute: Subscription;

  breadcrumb: Breadcrumb = new Breadcrumb;
  linksToBreadcrumb: Link[];
  title: string;
  searchType: string;

  pageSize$: Observable<number>;
  currentLang$: Observable<string>;
  advanceQueryResult$: Observable<string>;

  subscriberPageSize: Subscription;
  subscriberExtraFields: Subscription;
  searchQuery$: Observable<any>;
  subscriberSearchQuery: Subscription;

  paging$: Observable<Paging>;
  page: number;
  subscriberPaging: Subscription;
  subscriberGetEnvelope: Subscription;

  pageSize: number;
  searchQuery: any;
  loaded = false;

  constructor(
    public activatedRouter: ActivatedRoute,
    public envelopeEffect: EnvelopeEffect,
    public titleService: Title,
    store: Store<fromRoot.State>,
  ) {

    super(store);

    this.breadcrumb.links = this.linksToBreadcrumb;

    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigUploadDocuments));

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
      this.store.dispatch(new layoutAction.CloseSidenavAction());
    });

    this.store.dispatch(new layoutAction.PutAdvanceSearch(false));

    this.uploadDocument$ = store.pipe(select(fromRoot.getUploadDocumentsList));

    this.pageSize$ = store.pipe(select(fromRoot.getAppConfigPageSize));
    this.subscriberPageSize = this.pageSize$.subscribe(value => this.pageSize = value);

    this.paging$ = store.pipe(select(fromRoot.getSearchPagedPaging));
    this.subscriberPaging = this.paging$.subscribe(page => { if (page) { this.page = page.currentPage; }} );

    this.currentLang$ = store.pipe(select(fromRoot.getCurrentLanguage));

    this.searchQuery$ = store.pipe(select(fromRoot.getSearchPagedQuery));
    this.subscriberSearchQuery = this.searchQuery$.subscribe(query => {
      this.searchQuery = query;
      if (query && query.hasOwnProperty('validity')) { this.getEnvelopeUnderConstruction(this.searchQuery); }
      //  console.log(query['validity'])
    });

    this.advanceQueryResult$ = store.pipe(select(fromRoot.getAdvanceSearchQuery));
  }

  getEnvelopeUnderConstruction(params) {
    this.subscriberGetEnvelope = this.envelopeEffect.getEnvelopes(params);
  }

  ngOnInit() {
    this.titleService.setTitle('Sugar // Upload Documents');
    // this.store.dispatch(new uploadDocumentsAction.InitDocumentList());
    this.subscribeActiveRouteData = this.activatedRouter.data.subscribe((data) => {
      this.title = data.title ? data.type : 'documents';
      this.searchType = data.type ? data.type : 'DOCUMENTS';
    });

    this.subscribeActiveRoute = this.activatedRouter.queryParamMap.subscribe((paramsMap: ParamMap | any) => {

      this.linksToBreadcrumb = [
        { 'label': '<strong> ' + this.title + ' </strong>' },
        // { 'label': paramsMap.get('name').split('|')[1] }
      ];

      this.breadcrumb = new Breadcrumb;
      this.breadcrumb.links = this.linksToBreadcrumb;

      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));


    });
    // tslint:disable-next-line:max-line-length
    // const query = Object.assign({},
    //   this.toQueryParams(searchQueryString.value['advanceSearchQuery']),
    //   { pageNumber: 1, pageSize: this.pageSize }
    // );

    // tslint:disable-next-line:max-line-length
    this.store.dispatch(new searchPagedAction.PutSearchResultsQuery({ validity: 'equals_to|UNDER_CONSTRUCTION', orderField: 'creation_date', pageNumber: 1, pageSize: this.pageSize }));

  }



  ngOnDestroy() {
    this.store.dispatch(new enveloperAction.InitEnvelope());
    this.store.dispatch(new layoutAction.OpenSidenavAction());
    this.store.dispatch(new searchPagedAction.InitSearchResults());
    this.store.dispatch(new searchPagedAction.PutSearchingSearchStringQuery(' '));

    // this.store.dispatch(new searchPagedAction.InitSearchResults());
    this.subscriberGetEnvelope.unsubscribe();
    this.subscribePageConfig.unsubscribe();
    this.subscribeActiveRoute.unsubscribe();
    this.subscribeActiveRouteData.unsubscribe();
    this.subscriberSearchQuery.unsubscribe();
  }
}
