import { Observable } from 'rxjs';
import { Error } from 'app/models/error';
import { Component, ChangeDetectionStrategy } from '@angular/core';

import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';


@Component({
  selector: 'app-base',
  templateUrl: './base.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./base.component.scss']
})
export class BaseComponent {

  public httpError$: Observable<Error>;

  constructor(
    protected store: Store<fromRoot.State>,
  ) {

    this.httpError$ = store.pipe(select(fromRoot.getHttpError));
    this.httpError$.subscribe(error => error && this.errorHandler(error));
  }


  protected errorHandler(error: Error) {
    if (error.code === '401' || error.code === 401) {
      this.onError401();
    } else if (error.code === '403' || error.code === 403) {
      // TODO: SHOW A MODAL BOX WITH MISSING CORRECTS ROLES / AUTORIZATION
      // alert('Missing Role!');
      this.onError403();
    } else if (error.code === '404' || error.code === 404) {
      // TODO: SHOW A MODAL WITH PAGE NOT FOUND
      alert('PAGE NOT FOUND');
      this.onError404();
    }
  }

  onError401() { }
  onError403() { }
  onError404() { }
}
