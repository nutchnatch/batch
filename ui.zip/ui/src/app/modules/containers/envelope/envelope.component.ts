import { Envelope } from 'app/models/envelope';
import { Subscription } from 'rxjs';
import { Document } from './../../../models/document';
import { DocumentEffect } from './../../../effects/document.effect';
import { Title } from '@angular/platform-browser';
import { EnvelopeEffect } from './../../../effects/envelope.effect';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { BaseComponent } from './../base/base.component';
import { Breadcrumb, Link } from 'app/models/breadcrumb';
import { Store, select } from '@ngrx/store';
import {Location} from '@angular/common';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as appConfigActions from 'app/actions/app-config.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as envelopeAction from 'app/actions/envelope.actions';
import * as documentAction from 'app/actions/documents.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';

import { PageConfig } from 'app/states/app-config.state';

@Component({
  selector: 'app-envelope',
  templateUrl: './envelope.component.html',
  styleUrls: ['./envelope.component.scss']
})
export class EnvelopeComponent extends BaseComponent implements OnInit, OnDestroy {
  subscribeActiveRouteQueryParam: Subscription;

  public pageConfig$: Observable<PageConfig>;
  public documentsResult$: Observable<Document>;
  public subscribeDocumentResult: Subscription;

  public envelopeResult$: Observable<Envelope>;
  public subscribeEnvelopeResult: Subscription;


  public subscribePageConfig: Subscription;

  public breadcrumb: Breadcrumb = new Breadcrumb;
  public linksToBreadcrumb: Link[];
  public showMetadataBar$: Observable<boolean>;

  public subscribeActiveRoute: Subscription;

  currentId;
  hasTask;
  docid;

  constructor(
    store: Store<fromRoot.State>,
    public router: Router,
    public activatedRouter: ActivatedRoute,
    public envelopeEffect: EnvelopeEffect,
    public documentEffect: DocumentEffect,
    public titleService: Title,
    public location: Location

  ) {
    super(store);

    this.breadcrumb.links = this.linksToBreadcrumb;
    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigEnvelop));
    this.showMetadataBar$ = store.pipe(select(fromRoot.getMetadataBarShow));

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });

    this.documentsResult$ = store.pipe(select(fromRoot.getDocumentsResult));
    this.subscribeDocumentResult = this.documentsResult$.subscribe(document => {
      if (document) { this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(document)); }
    });

    this.envelopeResult$ = store.pipe(select(fromRoot.getEnvelopeFirstResult));

    // this.store.dispatch(new searchPagedActions.InitSearchResults);
    this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview('documents_single'));

  }


  ngOnInit() {

    this.subscribeActiveRoute = this.activatedRouter.paramMap.subscribe((params: ParamMap) => {

      if (this.currentId !== params.get('id')) {
        this.currentId = params.get('id');
        this.envelopeEffect.getEnvelopeById(this.currentId);
      }

      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.titleService.setTitle('Sugar // Envelope - ' + this.currentId);

      if (params.get('docid') !== null) {

        this.docid = params.get('docid');
        this.documentEffect.getDocumentsById(this.docid);
        this.store.dispatch(new documentsFilterAction.PutDocumentSeleced(this.docid));
      } else {
        this.subscribeEnvelopeResult = this.envelopeResult$.subscribe(result => {
          if (result && !this.docid) {
            this.docid = result.listOfDocumentId[0]['id'];

            // this.location.go('app/envelope/' + this.currentId + '/' + result.listOfDocumentId[0]['id']);
            if ( params.get('docid') !== result.listOfDocumentId[0]['id'] ) { this.documentEffect.getDocumentsById(this.docid); }

            this.store.dispatch(new documentsFilterAction.PutDocumentSeleced(this.docid));
            // this.refreshWithDocID(result.listOfDocumentId[0]['id']);
          }
        });
      }

      this.titleService.setTitle('Sugar // Envelope - ' + this.currentId);

    });
  }


  ngOnDestroy() {
    this.subscribePageConfig.unsubscribe();
    this.subscribeActiveRoute.unsubscribe();
    this.subscribeDocumentResult.unsubscribe();
    if (this.subscribeEnvelopeResult) { this.subscribeEnvelopeResult.unsubscribe(); }
    // this.subscribeActiveRouteQueryParam.unsubscribe();
    this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
    this.store.dispatch(new appConfigActions.PutCopiedTagsAction(null));
    this.store.dispatch(new envelopeAction.InitEnvelope());
    this.store.dispatch(new documentAction.InitPutDocument());
    this.store.dispatch(new documentsFilterAction.InitDocumentSelecedList());

  }
}
