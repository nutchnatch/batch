import { Subscription } from 'rxjs';
import { Title } from '@angular/platform-browser';

import { Observable } from 'rxjs';
import { Breadcrumb } from 'app/models/breadcrumb';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { BaseComponent } from 'app/modules/containers/base/base.component';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';

import { PageConfig } from 'app/states/app-config.state';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent extends BaseComponent implements OnInit, OnDestroy {

  public pageConfig$: Observable<PageConfig>;
  public subscribePageConfig: Subscription;

  public breadcrumb: Breadcrumb = new Breadcrumb;

  page = 1;

  constructor(
    store: Store<fromRoot.State>,
    public titleService: Title,
  ) {
    super(store);

    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigDashboard));


    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.breadcrumb.links = config.breadcrumb;
      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
      this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview());

    });

  }

  ngOnInit() {
    this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
    this.titleService.setTitle('Sugar // Dashboard');
    this.store.dispatch(new searchPagedAction.InitSearchResults());

  }

  ngOnDestroy() {
    this.subscribePageConfig.unsubscribe();
    this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview(null));

  }
}
