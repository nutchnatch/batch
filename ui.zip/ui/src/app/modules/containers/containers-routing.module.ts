import { AuthGuardService } from './../../services/auth-guard.services';
import { RolesGuardService } from 'app/services/roles-guard.service';
// tslint:disable-next-line:max-line-length
import { EnvelopeComponent } from './envelope/envelope.component';
import { SearchResultsComponent } from './search-results/search-results.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RefreshUrlComponent } from 'app/modules/tsp-ui/refresh-url/refresh-url.component';
import { FolderComponent } from 'app/modules/containers/folder/folder.component';
import { UploadDocumentComponent } from 'app/modules/containers/upload-document/upload-document.component';

const routes: Routes = [
  {
    path: 'app',
    // component: GuardedContentComponent,
    canActivate: [AuthGuardService],
    canActivateChild: [AuthGuardService],
    children: [
      {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: []
      },
      {
        path: 'basket',
        component: SearchResultsComponent,
        canActivate: [RolesGuardService],
        data: {
          title: 'Basket', type: 'BASKET',
          roles: ['SUGAR_CONFIDENTIAL_USER_ROLE', 'SUGAR_USER_ROLE', 'SUGAR_READ_USER_ROLE']
        }
      },
      {
        path: 'basket/:id',
        component: SearchResultsComponent,
        canActivate: [RolesGuardService],
        data: {
          title: 'Basket', type: 'BASKET',
          roles: ['SUGAR_CONFIDENTIAL_USER_ROLE', 'SUGAR_USER_ROLE', 'SUGAR_READ_USER_ROLE']
        }
      },
      {
        path: 'documents',
        component: SearchResultsComponent,
        // loadChildren: 'app/modules/containers/search-results/search-results.component#SearchResultsComponent',
        canActivate: [RolesGuardService],
        data: {
          title: 'Documents', type: 'DOCUMENTS',
          roles: ['SUGAR_CONFIDENTIAL_USER_ROLE', 'SUGAR_USER_ROLE', 'SUGAR_READ_USER_ROLE']
        }
      },
      {
        path: 'envelopes',
        component: SearchResultsComponent,
        canActivate: [RolesGuardService],
        data: {
          title: 'Envelopes', type: 'ENVELOPES',
          roles: ['SUGAR_CONFIDENTIAL_USER_ROLE', 'SUGAR_USER_ROLE', 'SUGAR_READ_USER_ROLE']
        }
      },
      {
        path: 'folders',
        component: SearchResultsComponent,
        canActivate: [RolesGuardService],
        data: {
          title: 'Folders', type: 'FOLDERS',
          roles: ['SUGAR_CONFIDENTIAL_USER_ROLE', 'SUGAR_USER_ROLE', 'SUGAR_READ_USER_ROLE']
        }
      },
      {
        path: 'envelope/:id',
        component: EnvelopeComponent,
        canActivate: [RolesGuardService],
        data: {
          roles: ['SUGAR_CONFIDENTIAL_USER_ROLE', 'SUGAR_USER_ROLE', 'SUGAR_READ_USER_ROLE']
        },

      },
      {
        path: 'envelope/:id/:docid',
        component: EnvelopeComponent,
        canActivate: [RolesGuardService],
        data: {
          roles: ['SUGAR_CONFIDENTIAL_USER_ROLE', 'SUGAR_USER_ROLE', 'SUGAR_READ_USER_ROLE']
        }
      },
      {
        path: 'folder/:id',
        component: FolderComponent,
        canActivate: [RolesGuardService],
        data: {
          roles: ['SUGAR_CONFIDENTIAL_USER_ROLE', 'SUGAR_USER_ROLE', 'SUGAR_READ_USER_ROLE']
        }
      },
      {
        path: 'folder/:id/:docid',
        component: FolderComponent,
        canActivate: [RolesGuardService],
        data: {
          roles: ['SUGAR_CONFIDENTIAL_USER_ROLE', 'SUGAR_USER_ROLE', 'SUGAR_READ_USER_ROLE']
        }
      },
      {
        path: 'search',
        component: SearchResultsComponent,
        canActivate: [RolesGuardService],
        data: {
          roles: ['SUGAR_CONFIDENTIAL_USER_ROLE', 'SUGAR_USER_ROLE', 'SUGAR_READ_USER_ROLE']
        }
      },
      {
        path: 'upload-document',
        component: UploadDocumentComponent,
        canActivate: [RolesGuardService],
        data: {
          title: 'Envelope Under Construction', type: 'Envelope Under Construction',
          roles: ['SUGAR_CONFIDENTIAL_USER_ROLE', 'SUGAR_USER_ROLE']
        }
      },
      {
        path: 'refresh',
        component: RefreshUrlComponent,
      },
      {
        path: '',
        redirectTo: 'basket',
        pathMatch: 'full'
      }
    ]
  }
];

/**
 * Containers (Pages) Modulos Routes
 *
 * Login Module Routes:
 *  - Homepage/welcome - 'welcome'
 *
 * @export
 * @class LoginRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContainersRoutingModule { }
