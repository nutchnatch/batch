import { BasketEffect } from 'app/effects/basket.effect';
import { Title } from '@angular/platform-browser';
import { DocumentEffect } from 'app/effects/document.effect';
import { Observable } from 'rxjs';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { BaseComponent } from './../base/base.component';
import { Breadcrumb, Link } from 'app/models/breadcrumb';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { PageConfig } from 'app/states/app-config.state';
import { Subscription } from 'rxjs';
import { EnvelopeEffect } from 'app/effects/envelope.effect';
import { FolderEffect } from 'app/effects/folder.effect';
import { Paging } from 'app/models/paging';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as appConfigAction from 'app/actions/app-config.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';
import * as envelopeSelectedAction from 'app/actions/envelope.actions';
import * as searchPagedActions from 'app/actions/search-paged.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';

@Component({
  selector: 'app-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.scss']
})
export class SearchResultsComponent extends BaseComponent implements OnInit, OnDestroy {

  subscriberSearchQuery: Subscription;
  searchStringQuery$: Observable<string>;
  public pageConfig$: Observable<PageConfig>;
  public subscribePageConfig: Subscription;
  public searching$: Observable<boolean>;
  public error$: Observable<any>;
  public searchType$: Observable<string>;
  public searchResult$: Observable<any>;
  public paging$: Observable<Paging>;
  public allLoaded$: Observable<boolean>;

  // public basketsResult$: Observable<Array<Basket>>;

  public breadcrumb: Breadcrumb = new Breadcrumb;
  public linksToBreadcrumb: Link[];

  public clickPreview: any;

  public subscribeActiveRoute: Subscription;
  public subscribeActiveRouteData: Subscription;
  public subscribeActiveRouteParamMap: Subscription;
    // public subscribeBasketResults: Subscription;
  // public route: ActivatedRoute;

  title: string;
  searchType: string;
  firstTaskId: string;

  searchSubcriber: Subscription;
  basketId: string;
  params: any;

  constructor(
    store: Store<fromRoot.State>,
    public activatedRouter: ActivatedRoute,
    public documentEffect: DocumentEffect,
    public envelopeEffect: EnvelopeEffect,
    public folderEffect: FolderEffect,
    public basketEffect: BasketEffect,
    public titleService: Title,

  ) {

    super(store);

    this.breadcrumb.links = this.linksToBreadcrumb;

    this.searching$ = store.pipe(select(fromRoot.getSearchPagedLoading));
    this.searchResult$ = store.pipe(select(fromRoot.getSearchPagedResults));

    this.error$ = store.pipe(select(fromRoot.getSearchPagedError));

    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigSearch));
    this.paging$ = store.pipe(select(fromRoot.getSearchPagedPaging));

    this.allLoaded$ = store.pipe(select(fromRoot.getBusinessScopeAllLoaded));

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });

    this.searchStringQuery$ = store.pipe(select( fromRoot.getSearchPagedQueryName ));
    this.subscriberSearchQuery = this.searchStringQuery$.subscribe( query => {
      if ( query !== '' ) {
        this.store.dispatch(new searchPagedActions.PutSearchingSearchStringQuery( query ));
      }
    });

    this.store.dispatch(new documentsFilterAction.InitDocumentSelecedList());
    this.store.dispatch(new envelopeSelectedAction.InitEnvelope());
    // this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview());

  }

  ngOnInit() {

    // tslint:disable-next-line:max-line-length
    this.subscribeActiveRouteData = this.activatedRouter.data.subscribe((data) => {

      this.title = data.title ? data.type : 'documents';
      this.searchType = data.type ? data.type : 'DOCUMENTS';
      if (this.searchType === 'BASKET') { this.store.dispatch(new layoutAction.PutAdvanceSearch(false)); }
      this.store.dispatch(new searchPagedAction.PutSearchResultsType(this.searchType));

    });

    this.subscribeActiveRoute = this.activatedRouter.queryParamMap.subscribe((paramsMap: ParamMap | any) => {

      this.killSubcribersEffects();

      this.linksToBreadcrumb = [
        { 'label': 'Search by <strong> ' + this.title + ' </strong>' },
        // { 'label': paramsMap.get('name').split('|')[1] }
      ];

      // this.titleService.setTitle('Sugar // Search by - ' + this.title + ' - ' + paramsMap.get('name').split('|')[1]);

      this.breadcrumb = new Breadcrumb;
      this.breadcrumb.links = this.linksToBreadcrumb;

      if (paramsMap.get('pageSize')) { this.store.dispatch(new appConfigAction.PutPageSizeAction(paramsMap.get('pageSize'))); }


      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new searchPagedAction.PutSearchResultsQuery(paramsMap.params));

      // this.store.dispatch(new searchPagedAction.InitSearchResults());
      // tslint:disable-next-line:max-line-length
      const avoidUnderConstruction = Object.assign({}, paramsMap.params, { validity: paramsMap.params.validity ? paramsMap.params.validity : 'not_equals_to|UNDER_CONSTRUCTION'  });
      if (this.searchType === 'ENVELOPES') { this.searchSubcriber = this.envelopeEffect.getEnvelopes(avoidUnderConstruction); }
      if (this.searchType === 'DOCUMENTS') { this.searchSubcriber = this.documentEffect.getDocuments(avoidUnderConstruction); }
      if (this.searchType === 'FOLDERS') { this.searchSubcriber = this.folderEffect.getFolders(paramsMap.params); }
      if (this.searchType === 'BASKET') { this.params = paramsMap.params; this.getBaskets(); }
    });

    this.subscribeActiveRouteParamMap = this.activatedRouter.paramMap.subscribe((paramsMap: ParamMap | any) => {
      if (this.searchType === 'BASKET' && paramsMap.get('id')) {
        this.basketId = paramsMap.get('id');
        this.getBaskets();
        // this.searchSubcriber = this.basketEffect.getBasketsTasksById(paramsMap.get('id'), paramsMap.params);
      }
    });

    this.titleService.setTitle('Sugar // Search  - ' + this.searchType);


  }

  getBaskets() {
    // debugger
    if (this.basketId) {
      this.searchSubcriber = this.basketEffect.getBasketsTasksById(this.basketId, this.params);
    }
  }



  killSubcribersEffects() {
    this.store.dispatch(new searchPagedAction.InitSearchResultsArray());
    if ( this.searchSubcriber ) { this.searchSubcriber.unsubscribe(); }
  }

  ngOnDestroy() {

    this.killSubcribersEffects();

    this.subscribePageConfig.unsubscribe();
    this.subscribeActiveRoute.unsubscribe();
    this.subscribeActiveRouteData.unsubscribe();
    this.subscribeActiveRouteParamMap.unsubscribe();
    this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview(null));
    // this.store.dispatch(new searchPagedAction.InitSearchResults());

    // this.subscribeBasketResults.unsubscribe();
  }
}
