import { Subscription } from 'rxjs';
import { Document } from './../../../models/document';
import { DocumentEffect } from './../../../effects/document.effect';
import { Title } from '@angular/platform-browser';
import { FolderEffect } from './../../../effects/folder.effect';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { BaseComponent } from './../base/base.component';
import { Breadcrumb, Link } from 'app/models/breadcrumb';
import { Store, select } from '@ngrx/store';
import { Location } from '@angular/common';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as folderAction from 'app/actions/folder.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';
import * as documentAction from 'app/actions/documents.actions';

import * as searchPagedActions from 'app/actions/search-paged.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';

import { PageConfig } from 'app/states/app-config.state';
import { Folder } from 'app/models/folder';



@Component({
  selector: 'app-folder',
  templateUrl: './folder.component.html',
  styleUrls: ['./folder.component.scss']
})
export class FolderComponent extends BaseComponent implements OnInit, OnDestroy {

  subscribeFolderResult: Subscription;
  public folderResult$: Observable<Folder>;

  public pageConfig$: Observable<PageConfig>;
  public documentsResult$: Observable<Document>;
  public subscribeDocumentResult: Subscription;

  public subscribePageConfig: Subscription;

  public breadcrumb: Breadcrumb = new Breadcrumb;
  public linksToBreadcrumb: Link[];
  public showMetadataBar$: Observable<boolean>;

  public subscribeActiveRoute: Subscription;
  currentId;
  docid;

  constructor(
    store: Store<fromRoot.State>,
    router: Router,
    public activatedRouter: ActivatedRoute,
    public folderEffect: FolderEffect,
    public documentEffect: DocumentEffect,
    public titleService: Title,
    public location: Location

  ) {
    super(store);

    this.breadcrumb.links = this.linksToBreadcrumb;
    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigFolder));
    this.showMetadataBar$ = store.pipe(select(fromRoot.getMetadataBarShow));

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });

    this.documentsResult$ = store.pipe(select(fromRoot.getDocumentsResult));
    this.subscribeDocumentResult = this.documentsResult$.subscribe(document => {
      if (document) { this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(document)); }
    });

    this.folderResult$ = store.pipe(select(fromRoot.getFolderFirstResult));

    this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview('folder_single'));

  }

  ngOnInit() {

    this.subscribeActiveRoute = this.activatedRouter.paramMap.subscribe((params: ParamMap) => {

      if (this.currentId !== params.get('id')) {
        this.currentId = params.get('id');
        this.folderEffect.getFoldersById(this.currentId);
      }

      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new searchPagedActions.PutSearchResultsType(null));

      if (params.get('docid') !== null) {

        this.docid = params.get('docid');
        this.documentEffect.getDocumentsById(this.docid);
        this.store.dispatch(new documentsFilterAction.PutDocumentSeleced(this.docid));
      } else {
        this.subscribeFolderResult = this.folderResult$.subscribe(result => {
          if (result && !this.docid && result.listOfDocumentId.length > 0) {
            this.docid = result.listOfDocumentId[0]['id'];
            // this.location.go('app/envelope/' + this.currentId + '/' + result.listOfDocumentId[0]['id']);
            if (params.get('docid') !== result.listOfDocumentId[0]['id']) { this.documentEffect.getDocumentsById(this.docid); }


            this.store.dispatch(new documentsFilterAction.PutDocumentSeleced(this.docid));
            // this.refreshWithDocID(result.listOfDocumentId[0]['id']);
          }
        });
      }

      this.titleService.setTitle('Sugar // Folder - ' + this.currentId);

    });
  }

  ngOnDestroy() {
    this.store.dispatch(new folderAction.InitFolder());
    this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
    this.store.dispatch(new documentsFilterAction.InitDocumentSelecedList());
    this.store.dispatch(new documentAction.InitPutDocument());

    this.subscribePageConfig.unsubscribe();
    this.subscribeActiveRoute.unsubscribe();
    this.subscribeDocumentResult.unsubscribe();
    if (this.subscribeFolderResult) { this.subscribeFolderResult.unsubscribe(); }

  }
}
