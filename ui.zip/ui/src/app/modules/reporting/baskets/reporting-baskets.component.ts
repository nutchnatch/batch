import { BasketReporting } from './../../../models/basket-reporting';
import { DateParserFormaterServices } from './../../../services/date-parser-formater/date-parser-formater.service';
import { Breadcrumb } from 'app/models/breadcrumb';
import { PageConfig } from './../../../states/app-config.state';
import { Subscription } from 'rxjs';
import { BaseService } from 'app/services/base.service';
import { Error } from 'app/models/error';
import { Observable } from 'rxjs';
import { ReportingEffect } from 'app/effects/reporting.effect';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Store, select } from '@ngrx/store';
import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';

const now = new Date();

@Component({
  selector: 'app-report-baskets',
  templateUrl: './reporting-baskets.component.html',
  styleUrls: ['./reporting-baskets.component.scss']
})
export class ReportingBasketsComponent implements OnInit, OnDestroy {

  public loading$: Observable<boolean>;
  public error$: Observable<Error>;
  public result$: Observable<BasketReporting>;
  public pageConfig$: Observable<PageConfig>;
  public subscribePageConfig: Subscription;

  public breadcrumb: Breadcrumb = new Breadcrumb;
  public form: FormGroup;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public reportingEffect: ReportingEffect,
    public baseService: BaseService<any>,
    public dateToUCT: DateParserFormaterServices,

  ) {
    // this.form = new FormGroup({});
    this.form = this.formBuilder.group({});


    this.loading$ = store.pipe(select(fromRoot.getReportingLoading));
    this.error$ = store.pipe(select(fromRoot.getReportingError));
    this.result$ = store.pipe(select(fromRoot.getBasketReportResult));
    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigBasketReport));

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.breadcrumb.links = config.breadcrumb;
      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });

  }
  ngOnInit() {
  // tslint:disable-next-line:max-line-length
    this.reportingEffect.getBasketReport(this.dateToUCT.ngbDatepickerUTCDate(
      { year: now.getFullYear(),
         month: now.getMonth() + 1,
          day: now.getDate()
        }), this.dateToUCT.ngbDatepickerUTCDate(
        { year: now.getFullYear(),
           month: now.getMonth() + 1,
            day: now.getDate() }));
  }


  search(form) {
    this.reportingEffect.getBasketReport(this.dateToUCT.ngbDatepickerUTCDate(form.start), this.dateToUCT.ngbDatepickerUTCDate(form.end));
  }

  ngOnDestroy() {
    if (this.subscribePageConfig) {
      this.subscribePageConfig.unsubscribe();
    }
  }
}
