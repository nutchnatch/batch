import { ReportingBasketsComponent } from './baskets/reporting-baskets.component';
import { ReportingFoldersComponent } from './folders/reporting-folders.component';
import { ReportingDocumentsComponent } from './documents/reporting-documents.component';
import { ReportingEnvelopesComponent } from './envelopes/reporting-envelopes.component';
import { ReportingSummaryComponent } from './summary/reporting-summary.component';
import { RolesGuardService } from 'app/services/roles-guard.service';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from 'app/services/auth-guard.services';
import { ReportingComponent } from './reporting.component';
import { NgModule } from '@angular/core';
import { TrackingComponent } from './tracking/tracking.component';

const routes: Routes = [
  {
    path: 'app/reporting',
    component: ReportingComponent,
    canActivate: [AuthGuardService],
    children: [
      {
        path: '',
        canActivate: [RolesGuardService],
        data: {
          title: 'Reports and Logs', type: 'REPORTS_AND_LOGS',
          roles: ['SUGAR_BS_MANAGER']
        },
        children: [
          { path: '', redirectTo: 'tracking', pathMatch: 'full' },
          {
            path: 'tracking',
            component: TrackingComponent,
            data: {
              title: 'Reporting',
              type: 'TRACKING'
            }
          },
          {
            path: 'summary',
            component: ReportingSummaryComponent,
            data: {
              title: 'Reporting',
              type: 'SUMMARY'
            }
          },
          {
            path: 'document',
            component: ReportingDocumentsComponent,
            data: {
              title: 'Reporting',
              type: 'DOCUMENTS'
            }
          },
          {
            path: 'envelope',
            component: ReportingEnvelopesComponent,
            data: {
              title: 'Reporting',
              type: 'ENVELOPES'
            }
          },
          {
            path: 'folder',
            component: ReportingFoldersComponent,
            data: {
              title: 'Reporting',
              type: 'FOLDERS'
            }
          },
          {
            path: 'basket',
            component: ReportingBasketsComponent,
            data: {
              title: 'Reporting',
              type: 'BASKETS'
            }
          }
        ]
      }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportingRoutingModule { }
