import { Subscription } from 'rxjs';
import { BaseService } from 'app/services/base.service';
import { Error } from 'app/models/error';
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { Store, select } from '@ngrx/store';
import { URLSearchParams } from '@angular/http';
import * as fromRoot from 'app/reducers';

import { forOwn } from 'lodash';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-tracking',
  templateUrl: './tracking.component.html',
  styleUrls: ['./tracking.component.scss']
})
export class TrackingComponent implements OnInit, OnDestroy {

  subs: Subscription;

  public loading$: Observable<boolean>;
  public error$: Observable<Error>;

  public hours: Array<string> = Array.apply(null, { length: 24 }).map((i) => { return i <= 9 ? '0' + i : (i) + ''; });
  public minutes: Array<string> = Array.apply(null, { length: 60 }).map((i) => { return i <= 9 ? '0' + i : (i) + ''; });
  public seconds: Array<number> = Array.apply(null, { length: 60 }).map((i) => { return i <= 9 ? '0' + i : (i) + ''; });

  public trackingForm: FormGroup;

  validBetween = true;
  validURL: string;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public dateParserFormatter: NgbDateParserFormatter,
    public baseService: BaseService<any>,
    public titleService: Title
  ) {

    this.loading$ = store.pipe(select(fromRoot.getTrackingAndLogsLoading));
    this.error$ = store.pipe(select(fromRoot.getTrackingAndLogsError));

    this.trackingForm = new FormGroup({
      startDateTime: new FormGroup({
        date: new FormControl('', Validators.required),
        hours: new FormControl('00'),
        minutes: new FormControl('00'),
        seconds: new FormControl('00'),
      }),
      endDateTime: new FormGroup({
        date: new FormControl('', Validators.required),
        hours: new FormControl('23'),
        minutes: new FormControl('59'),
        seconds: new FormControl('59'),
      }),
      objectId: new FormControl(''),
      userId: new FormControl(''),
    });

     this.subs = this.trackingForm.valueChanges.subscribe(formData => this.onSubmit(formData));
  }

  onSubmit(trackingForm: any) {

    const startDate = trackingForm.startDateTime.date && new Date(
      this.dateParserFormatter.format(trackingForm.startDateTime.date) + 'T'
      + trackingForm.startDateTime.hours + ':'
      + trackingForm.startDateTime.minutes + ':'
      + trackingForm.startDateTime.seconds).toISOString();

    const endDate = trackingForm.endDateTime.date && new Date(
      this.dateParserFormatter.format(trackingForm.endDateTime.date) + 'T'
      + trackingForm.endDateTime.hours + ':'
      + trackingForm.endDateTime.minutes + ':'
      + trackingForm.endDateTime.seconds).toISOString();

    this.validBetween = this.betweenDates(startDate, endDate);

    if (this.trackingForm.valid && this.validBetween) {
      const formData: any = Object.assign({}, trackingForm, {
        startDateTime: startDate,
        endDateTime: endDate
      });

      const queryParam: URLSearchParams = new URLSearchParams();

      forOwn(formData, (value, key) => queryParam.set(key, value));
      this.validURL = this.baseService.baseUrl + '/track-and-log?' + queryParam.toString();
      // this.reportingEffects.getTrackingAndLog(formData);
    }

  }

  betweenDates(startDate, endDate): boolean {
    return !startDate || !endDate || startDate < endDate;
  }

  ngOnInit() {
    this.titleService.setTitle('Sugar // Report - Tracking & log');

  }

  ngOnDestroy() {
    if ( this.subs ) { this.subs.unsubscribe(); }
  }
}
