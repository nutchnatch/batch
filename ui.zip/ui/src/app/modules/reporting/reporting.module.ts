import { ReportingBasketsComponent } from './baskets/reporting-baskets.component';
import { ReportingFoldersComponent } from './folders/reporting-folders.component';
import { ReportingDocumentsComponent } from './documents/reporting-documents.component';
import { ReportingEnvelopesComponent } from './envelopes/reporting-envelopes.component';
import { ReportingSummaryComponent } from './summary/reporting-summary.component';
import { ReportingRoutingModule } from './reporting-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportingComponent } from './reporting.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TspUIModule } from 'app/modules/tsp-ui/tsp-ui.module';
import { SugarModule } from 'app/modules/sugar/sugar.module';
import { TrackingComponent } from './tracking/tracking.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    ReportingRoutingModule,
    TspUIModule,
    SugarModule
  ],
  declarations: [
    ReportingComponent,
    TrackingComponent,
    ReportingSummaryComponent,
    ReportingEnvelopesComponent,
    ReportingDocumentsComponent,
    ReportingFoldersComponent,
    ReportingBasketsComponent
]
})
export class ReportingModule { }
