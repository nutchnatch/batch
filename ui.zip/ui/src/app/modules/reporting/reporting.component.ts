import { Component, OnInit, OnDestroy } from '@angular/core';
import { BaseComponent } from 'app/modules/containers/base/base.component';
import { Store, select } from '@ngrx/store';

import { Observable } from 'rxjs';
import { Subscription } from 'rxjs';
import { PageConfig } from 'app/states/app-config.state';
import { Breadcrumb } from 'app/models/breadcrumb';


import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';


@Component({
  selector: 'app-reporting',
  templateUrl: './reporting.component.html',
  styleUrls: ['./reporting.component.scss']
})
export class ReportingComponent extends BaseComponent implements OnInit, OnDestroy  {

  public pageConfig$: Observable<PageConfig>;
  public subscribePageConfig: Subscription;

  public breadcrumb: Breadcrumb = new Breadcrumb;

  constructor(
    store: Store<fromRoot.State>,

  ) {
    super(store);

    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigReportAndLogsTracking));

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.breadcrumb.links = config.breadcrumb;
      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });


  }

  ngOnInit() { }

  ngOnDestroy() {}

}
