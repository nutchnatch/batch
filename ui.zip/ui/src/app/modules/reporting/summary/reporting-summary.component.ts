import { ReportSummary } from './../../../models/reporting-summary';
import { Breadcrumb } from 'app/models/breadcrumb';
import { PageConfig } from './../../../states/app-config.state';
import { Subscription } from 'rxjs';
import { BaseService } from 'app/services/base.service';
import { Error } from 'app/models/error';
import { Observable } from 'rxjs';
import { ReportingEffect } from 'app/effects/reporting.effect';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Store, select } from '@ngrx/store';
import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';

import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-report-summary',
  templateUrl: './reporting-summary.component.html',
  styleUrls: ['./reporting-summary.component.scss']
})
export class ReportingSummaryComponent implements OnInit, OnDestroy {

  public loading$: Observable<boolean>;
  public error$: Observable<Error>;
  public summary$: Observable<ReportSummary>;
  public pageConfig$: Observable<PageConfig>;
  public subscribePageConfig: Subscription;

  public breadcrumb: Breadcrumb = new Breadcrumb;

  constructor(
    public store: Store<fromRoot.State>,
    public formBuilder: FormBuilder,
    public reportingEffect: ReportingEffect,
    public baseService: BaseService<any>,
    public titleService: Title
  ) {

    this.loading$ = store.pipe(select(fromRoot.getReportingLoading));
    this.error$ = store.pipe(select(fromRoot.getReportingError));
    this.summary$ = store.pipe(select(fromRoot.getSummaryResult));
    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigReportingSummary));

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.breadcrumb.links = config.breadcrumb;
      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });

  }

  ngOnInit() {
    this.reportingEffect.getSummary();
    this.titleService.setTitle('Sugar // Report - Stock');

  }

  ngOnDestroy() {
    if (this.subscribePageConfig) {
      this.subscribePageConfig.unsubscribe();
    }
  }
}
