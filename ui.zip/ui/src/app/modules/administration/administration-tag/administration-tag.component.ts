import { Component, OnInit, OnDestroy } from '@angular/core';
import { BaseComponent } from 'app/modules/containers/base/base.component';
import { Store, select } from '@ngrx/store';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs';
import { PageConfig } from 'app/states/app-config.state';
import { Subscription } from 'rxjs';
import { Breadcrumb } from 'app/models/breadcrumb';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-administration-tag',
  templateUrl: './administration-tag.component.html',
  styleUrls: ['./administration-tag.component.scss']
})
export class AdministrationTagComponent extends BaseComponent implements OnInit, OnDestroy {

  // subscribeActiveRoute: any;

  public pageConfig$: Observable<PageConfig>;
  public subscribePageConfig: Subscription;

  public breadcrumb: Breadcrumb = new Breadcrumb;

  constructor(
    store: Store<fromRoot.State>,
    public titleService: Title,
    public activatedRouter: ActivatedRoute
  ) {
    super(store);

    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigAdminstrationTag));

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.breadcrumb.links = config.breadcrumb;
      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });

  }

  ngOnInit() {
    this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
    this.titleService.setTitle('Sugar // Administration - Tag Classes');

    this.store.dispatch(new searchPagedAction.PutSearchResultsType('tag-class'));
  }

  ngOnDestroy() {
    // this.store.dispatch(new searchPagedAction.PutSearchResultsType(null));
    this.store.dispatch(new searchPagedAction.PutSearchingSearchStringQuery( ' ' ));
    // this.store.dispatch(new searchPagedAction.InitSearchResults());
  }
}
