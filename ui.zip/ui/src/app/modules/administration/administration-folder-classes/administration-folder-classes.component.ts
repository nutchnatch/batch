import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';

import { BaseComponent } from 'app/modules/containers/base/base.component';
import { Observable } from 'rxjs';
import { PageConfig } from 'app/states/app-config.state';
import { Subscription } from 'rxjs';
import { Breadcrumb } from 'app/models/breadcrumb';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';

@Component({
  selector: 'app-administration-folder-classes',
  templateUrl: './administration-folder-classes.component.html',
  styleUrls: ['./administration-folder-classes.component.scss']
})
export class AdministrationFolderClassesComponent extends BaseComponent implements OnInit, OnDestroy {

  public pageConfig$: Observable<PageConfig>;
  public subscribePageConfig: Subscription;

  public breadcrumb: Breadcrumb = new Breadcrumb;

  constructor(
    store: Store<fromRoot.State>,
    public titleService: Title,
    public activatedRouter: ActivatedRoute) {
    super(store);

    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigAdminstrationFolderClasses));

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.breadcrumb.links = config.breadcrumb;
      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });


  }

  ngOnInit() {
    this.titleService.setTitle('Sugar // Administration - Folder Classes');

  }

  ngOnDestroy() {
  }

}
