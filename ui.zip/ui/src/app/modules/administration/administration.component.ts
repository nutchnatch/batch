import { Component, OnInit, OnDestroy } from '@angular/core';
import { BaseComponent } from 'app/modules/containers/base/base.component';
import { Store, select } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';
import { Observable } from 'rxjs';
import { PageConfig } from 'app/states/app-config.state';
import { Subscription } from 'rxjs';
import { Breadcrumb } from 'app/models/breadcrumb';

@Component({
  selector: 'app-administration',
  templateUrl: './administration.component.html',
  styleUrls: ['./administration.component.scss']
})
export class AdministrationComponent extends BaseComponent implements OnInit, OnDestroy {

  public pageConfig$: Observable<PageConfig>;
  public subscribePageConfig: Subscription;

  public breadcrumb: Breadcrumb = new Breadcrumb;

  constructor(
    store: Store<fromRoot.State>,
  ) {
    super(store);

    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigAdminstration));


    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.breadcrumb.links = config.breadcrumb;
      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });
  }

  ngOnInit() {
  }

  ngOnDestroy() {

  }
}
