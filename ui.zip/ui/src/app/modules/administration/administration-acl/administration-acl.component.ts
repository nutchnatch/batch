
import { ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { BaseComponent } from 'app/modules/containers/base/base.component';
import { Store, select } from '@ngrx/store';

import { Observable } from 'rxjs';
import { Subscription } from 'rxjs';
import { PageConfig } from 'app/states/app-config.state';
import { Breadcrumb } from 'app/models/breadcrumb';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';

@Component({
  selector: 'app-administration-acl',
  templateUrl: './administration-acl.component.html',
  styleUrls: ['./administration-acl.component.scss']
})
export class AdministrationAclComponent extends BaseComponent implements OnInit, OnDestroy  {

  public pageConfig$: Observable<PageConfig>;
  public subscribePageConfig: Subscription;
  public breadcrumb: Breadcrumb = new Breadcrumb;
  public basketLoading$: Observable<boolean>;

  constructor(
    store: Store<fromRoot.State>,
    public titleService: Title,
    public activatedRouter: ActivatedRoute
  ) {
    super(store);

    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigAdminstrationAcl));

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.breadcrumb.links = config.breadcrumb;
      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });
    // this.basketLoading$ =store.pipe(select(fromRoot.getBasketsLoading);


  }

  ngOnInit() {
    this.titleService.setTitle('Sugar // Administration - ACL Management');

  }

  ngOnDestroy() {}
}
