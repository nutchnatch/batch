import { AdministrationBasketComponent } from './administration-basket/administration-basket.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TspUIModule } from 'app/modules/tsp-ui/tsp-ui.module';
import { SugarModule } from 'app/modules/sugar/sugar.module';

import { AdministrationRoutingModule } from './administration-routing.module';
import { AdministrationTagComponent } from './administration-tag/administration-tag.component';
import { AdministrationBusinessScopeComponent } from './administration-business-scope/administration-business-scope.component';
import { AdministrationEnvelopeClassesComponent } from './administration-envelope-classes/administration-envelope-classes.component';
import { AdministrationDocumentClassesComponent } from './administration-document-classes/administration-document-classes.component';
import { AdministrationFolderClassesComponent } from './administration-folder-classes/administration-folder-classes.component';
import { AdministrationComponent } from './administration.component';
import { AdministrationAclComponent } from './administration-acl/administration-acl.component';

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    AdministrationRoutingModule,
    TspUIModule,
    SugarModule
  ],
  declarations: [
    AdministrationComponent,
    AdministrationTagComponent,
    AdministrationBusinessScopeComponent,
    AdministrationEnvelopeClassesComponent,
    AdministrationDocumentClassesComponent,
    AdministrationFolderClassesComponent,
    AdministrationBasketComponent,
    AdministrationAclComponent
]
})
export class AdministrationModule { }
