import { AdministrationBasketComponent } from './administration-basket/administration-basket.component';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from 'app/services/auth-guard.services';
// tslint:disable-next-line:max-line-length
// tslint:disable-next-line:max-line-length
import { NgModule } from '@angular/core';
import { AdministrationBusinessScopeComponent } from './administration-business-scope/administration-business-scope.component';
import { AdministrationTagComponent } from './administration-tag/administration-tag.component';
import { AdministrationEnvelopeClassesComponent } from './administration-envelope-classes/administration-envelope-classes.component';
import { AdministrationDocumentClassesComponent } from './administration-document-classes/administration-document-classes.component';
import { AdministrationFolderClassesComponent } from './administration-folder-classes/administration-folder-classes.component';
import { AdministrationComponent } from './administration.component';
import { RolesGuardService } from 'app/services/roles-guard.service';
import { AdministrationAclComponent } from './administration-acl/administration-acl.component';

const routes: Routes = [
  {
    path: 'app/administration',
    component: AdministrationComponent,
    // redirectTo: 'app/administration/tag-class', pathMatch: 'full',
    canActivate: [AuthGuardService],
    children: [
      {
        path: '',
        canActivate: [RolesGuardService],
        data: {
          title: 'Administration', type: 'ADMINISTRATION',
          roles: ['SUGAR_ADMIN']
        },
        children: [
          { path: '', redirectTo: 'business-scope', pathMatch: 'full' },
          {
            path: 'business-scope',
            component: AdministrationBusinessScopeComponent,
            data: {
              title: 'Administration - Business Scope', type: 'ADMINISTRATION_BUSINESS_SCOPE',
            }
          },
          {
            path: 'tag-class',
            component: AdministrationTagComponent,
            data: { title: 'Administration - Tag Classes', type: 'ADMINISTRATION_TAGS' }
          },
          {
            path: 'envelope-classes',
            component: AdministrationEnvelopeClassesComponent,
            data: { title: 'Administration - Envelope Classes', type: 'ADMINISTRATION_ENVELOPE_CLASSES' }
          },
          {
            path: 'document-classes',
            component: AdministrationDocumentClassesComponent,
            data: { title: 'Administration - Document Classes', type: 'ADMINISTRATION_DOCUMENT_CLASSES' }
          },
          {
            path: 'folder-classes',
            component: AdministrationFolderClassesComponent,
            data: { title: 'Administration - Folder Classes', type: 'ADMINISTRATION_FOLDER_CLASSES' }
          },
          {
            path: 'baskets',
            component: AdministrationBasketComponent,
            data: { title: 'Administration - Baskets', type: 'ADMINISTRATION_BASKERT' }
          },
          {
            path: 'acl',
            component: AdministrationAclComponent,
            data: { title: 'Administration - Acl', type: 'ADMINISTRATION_ACL' }
          },
        ]
      },
    ]
  },
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdministrationRoutingModule { }
