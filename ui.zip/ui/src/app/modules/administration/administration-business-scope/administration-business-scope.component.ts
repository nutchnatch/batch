import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { PageConfig } from 'app/states/app-config.state';
import { Breadcrumb } from 'app/models/breadcrumb';
import { Store, select } from '@ngrx/store';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { BaseComponent } from 'app/modules/containers/base/base.component';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';


@Component({
  selector: 'app-administration-business-scope',
  templateUrl: './administration-business-scope.component.html',
  styleUrls: ['./administration-business-scope.component.scss']
})
export class AdministrationBusinessScopeComponent extends BaseComponent implements OnInit, OnDestroy  {

  public pageConfig$: Observable<PageConfig>;

  public subscribePageConfig: Subscription;

  public breadcrumb: Breadcrumb = new Breadcrumb;

  constructor(
    store: Store<fromRoot.State>,
    public titleService: Title,
    public activatedRouter: ActivatedRoute
  ) {
    super(store);

    this.pageConfig$ = store.pipe(select(fromRoot.getAppConfigAdminstrationBusinessScope));

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.breadcrumb.links = config.breadcrumb;
      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });

  }

  ngOnInit() {
    this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
    this.titleService.setTitle('Sugar // Administration - Business Scope');
    // this.store.dispatch(new searchPagedAction.PutSearchResultsType('tag-class'));
  }

  ngOnDestroy() {
    // this.store.dispatch(new searchPagedAction.InitSearchResults());
    this.store.dispatch(new searchPagedAction.PutSearchingSearchStringQuery( ' ' ));

  }

}
