import { Action } from '@ngrx/store';
import { type } from '../util';
import { TagClone } from 'app/models/tag';
import { Acl } from 'app/models/acl';

export const ActionTypes = {
  PUT_LOADING: type('[ACL] loading Acl'),
  PUT_ACL: type('[ACL] Put Acl'),
  PUT_ERROR: type('[ACL] Put Acl Error'),
  INIT: type('[ACL] init'),
};


export class PutLoadingAclAction implements Action {
  type = ActionTypes.PUT_LOADING;
  /**
   * @param {boolean} [payload]
   * @memberof PutLoadingAclAction
   */
  constructor(public payload: boolean ) {}
}

export class PutAclAction implements Action {
  type = ActionTypes.PUT_ACL;
  /**
   * @param {Array<any>} [payload]
   * @memberof PutAclAction
   */
  constructor(public payload: Array<any> ) {}
}


export class InitAclAction implements Action {
  type = ActionTypes.PUT_ACL;
  /**
   *
   * @memberof InitAclAction
   */
  constructor(public payload?) {}
}

export class PutErrorAclAction implements Action {
  type = ActionTypes.PUT_ERROR;
  /**
   *
   * @memberof PutErrorAclAction
   */
  constructor(public payload: Error) {}
}


export type Actions
= PutAclAction
| PutLoadingAclAction
| InitAclAction
| PutErrorAclAction;
