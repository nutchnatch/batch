// import { TrackingAndLogCreationResult } from 'app/models/TrackingAndLog-creation-result';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';

export const ActionTypes = {
  LOADING_TRACKING_AND_LOG: type('[TrackingAndLog] loading'),
  PUT_TRACKING_AND_LOG_RESULTS: type('[TrackingAndLog] put TrackingAndLog'),
  PUT_TRACKING_AND_LOG_ERROR: type('[TrackingAndLog] put TrackingAndLog error'),
  PUT_UPDATE_TRACKING_AND_LOG: type('[TrackingAndLog] put upadate TrackingAndLog results'),
  INIT:  type('[TrackingAndLog] init state'),
};

export class LoadingTrackingAndLog implements Action {
  type = ActionTypes.LOADING_TRACKING_AND_LOG;
  /**
   * Creates an instance of LoadingEnvelope.
   * @param {boolean} payload
   *
   * @memberOf LoadingEnvelope
   */
  constructor(public payload?: boolean) { }
}

export class PutTrackingAndLogResults implements Action {
  type = ActionTypes.PUT_TRACKING_AND_LOG_RESULTS;
  /**
   * Creates an instance of PutTrackingAndLog.
   * @param {any} payload
   * @memberof PutTrackingAndLog
   */
  constructor(public payload?: any ) { }
}

export class PutTrackingAndLogError implements Action {
  type = ActionTypes.PUT_TRACKING_AND_LOG_ERROR;
 /**
  * Creates an instance of PutTrackingAndLogError.
  * @param {Error} payload
  * @memberof PutTrackingAndLogError
  */
  constructor(public payload: Error ) { }
}

export class InitPutTrackingAndLog implements Action {
  type = ActionTypes.INIT;
  /**
   * Creates an instance of InitPutTrackingAndLog.
   * @param {any} [payload]
   * @memberof InitPutTrackingAndLog
   */
  constructor(public payload? ) { }
}


export type Actions
= PutTrackingAndLogResults
| LoadingTrackingAndLog
| PutTrackingAndLogError
| InitPutTrackingAndLog;

