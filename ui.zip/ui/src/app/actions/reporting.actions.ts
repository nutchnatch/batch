import { Action } from '@ngrx/store';
import { type } from '../util';

export const ActionTypes = {
  LOADING: type('[Reporting] loading'),
  ERROR: type('[Reporting] error'),
  PUT_SUMMARY_RESULT: type('[Reporting] put summary result error'),
  PUT_ENVELOPES_RESULT: type('[Reporting] put envelopes result error'),
  PUT_DOCUMENTS_RESULT: type('[Reporting] put documents result error'),
  PUT_FOLDERS_RESULT: type('[Reporting] put folders result error'),
  PUT_BASKETS_RESULT: type('[Reporting] put baskets result error'),
  INIT:  type('[Reporting] init state'),
};

export class Loading implements Action {
  type = ActionTypes.LOADING;
  /**
   * Creates an instance of Loading.
   * @param {boolean} payload
   *
   * @memberOf Loading
   */
  constructor(public payload?: boolean) { }
}

export class PutSummaryResult implements Action {
  type = ActionTypes.PUT_SUMMARY_RESULT;
  /**
   * Creates an instance of PutSummaryResult.
   * @param {any} payload
   * @memberof PutSummaryResult
   */
  constructor(public payload?: any ) { }
}

export class PutEnvelopesResult implements Action {
  type = ActionTypes.PUT_ENVELOPES_RESULT;
  /**
   * Creates an instance of PutEnvelopesResult.
   * @param {any} payload
   * @memberof PutEnvelopesResult
   */
  constructor(public payload?: any ) { }
}

export class PutFoldersResult implements Action {
  type = ActionTypes.PUT_FOLDERS_RESULT;
  /**
   * Creates an instance of PutFoldersResult.
   * @param {any} payload
   * @memberof PutFoldersResult
   */
  constructor(public payload?: any ) { }
}

export class PutBasketsResult implements Action {
  type = ActionTypes.PUT_BASKETS_RESULT;
  /**
   * Creates an instance of PutBasketsResult.
   * @param {any} payload
   * @memberof PutBasketsResult
   */
  constructor(public payload?: any ) { }
}

export class PutDocumentsResult implements Action {
  type = ActionTypes.PUT_DOCUMENTS_RESULT;
  /**
   * Creates an instance of PutDocumentsResult.
   * @param {any} payload
   * @memberof PutDocumentsResult
   */
  constructor(public payload?: any ) { }
}

export class ReportingError implements Action {
  type = ActionTypes.ERROR;
 /**
  * Creates an instance of ReportingError.
  * @param {Error} payload
  * @memberof ReportingError
  */
  constructor(public payload: any ) { }
}

export class InitReporting implements Action {
  type = ActionTypes.INIT;
  /**
   * Creates an instance of InitReporting.
   * @param {any} [payload]
   * @memberof InitReporting
   */
  constructor(public payload? ) { }
}


export type Actions
= Loading
| PutSummaryResult
| ReportingError
| InitReporting
| PutEnvelopesResult
| PutDocumentsResult
| PutFoldersResult
| PutBasketsResult;

