import { FolderTypes } from './../models/folder-types';
import { EnvelopeTypes } from './../models/envelope-types';
import { DocumentTypes } from './../models/document-types';
import { Tag } from 'app/models/tag';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  LOADING_EXTRA_FIELDS: type('[Extra Field] loading'),
  PUT_EXTRA_FIELDS: type('[Extra Field] put tag'),
  PUT_ENVELOPE_EXTRA_FIELDS: type('[Extra Field] put envelope tag'),
  PUT_FOLDER_EXTRA_FIELDS: type('[Extra Field] put folder tag'),
  INIT_EXTRA_FIELDS:  type('[Extra Field] init state'),
};

export class LoadingExtraFields implements Action {
  type = ActionTypes.LOADING_EXTRA_FIELDS;
  /**
   * Creates an instance of LoadingExtraFields.
   * @param {boolean} [payload]
   * @memberof LoadingExtraFields
   */
  constructor(public payload?: boolean) { }
}

export class PutExtraFields implements Action {
  type = ActionTypes.PUT_EXTRA_FIELDS;
  /**
   * Creates an instance of PutExtraFields.
   * @param {({ tags: Array<Tag> | Array<any>, documentType: Array<DocumentTypes> | Array<any> })} payload
   * @memberof PutExtraFields
   */
  constructor(public payload: { tags: Array<Tag> | Array<any>, documentType: Array<DocumentTypes> | Array<any> }) { }
}

export class PutEnvelopeExtraFields implements Action {
  type = ActionTypes.PUT_ENVELOPE_EXTRA_FIELDS;
  /**
   * Creates an instance of PutEnvelopeExtraFields.
   * @param {({ tags: Array<Tag> | Array<any>, envelopeType: Array<EnvelopeTypes> | Array<any> })} payload
   * @memberof PutEnvelopeExtraFields
   */
  constructor(public payload: { tags: Array<Tag> | Array<any>, envelopeType: Array<EnvelopeTypes> | Array<any> }) { }
}

export class PutFolderExtraFields implements Action {
  type = ActionTypes.PUT_FOLDER_EXTRA_FIELDS;
  /**
   * Creates an instance of PutEnvelopeExtraFields.
   * @param {({ tags: Array<Tag> | Array<any>, folderType: Array<FolderTypes> | Array<any> })} payload
   * @memberof PutEnvelopeExtraFields
   */
  constructor(public payload: { tags: Array<Tag> | Array<any>, folderType: Array<FolderTypes> | Array<any> }) { }
}

export class InitPutExtraField implements Action {
  type = ActionTypes.INIT_EXTRA_FIELDS;
  /**
   * Creates an instance of InitPutExtraField.
   * @param {any} [payload]
   * @memberof InitPutExtraField
   */
  constructor(public payload? ) { }
}

export type Actions
= PutExtraFields
| PutEnvelopeExtraFields
| PutFolderExtraFields
| LoadingExtraFields
| InitPutExtraField;
