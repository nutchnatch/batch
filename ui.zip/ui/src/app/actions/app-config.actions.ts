import { ScopeByUser } from './../states/client-settings.state';
import { Action } from '@ngrx/store';
import { type } from '../util';
import { TagClone } from 'app/models/tag';

export const ActionTypes = {
  PUT_PAGE_SIZE: type('[AppConfig] Put pageSize'),
  PUT_SCOPE: type('[AppConfig] Put scope'),
  PUT_COPIED_TAGS: type('[AppConfig] Put Copied Tags'),
  PUT_BASKET_BY_SCOPE: type('[AppConfig] Put Basket by scope'),
  PUT_BASKET: type('[AppConfig] Put Basket'),
  PUT_DEFAULT_SCOPE: type('[AppConfig] Put default user scope'),
};

/**
 * Action Update PageSize to store
 *
 * @export
 * @class PutPageSizeAction
 * @implements {Action}
 */
export class PutPageSizeAction implements Action {
  type = ActionTypes.PUT_PAGE_SIZE;
  /**
   * @param {number} [payload]
   * @memberof PutPageSizeAction
   */
  constructor(public payload?: number) { }
}
/**
 * Action Update Scope to store
 *
 * @export
 * @class PutScopeAction
 * @implements {Action}
 */
export class PutScopeAction implements Action {
  type = ActionTypes.PUT_SCOPE;
  /**
   * Creates an instance of PutScopeAction.
   * @param {string} [payload]
   * @memberof PutScopeAction
   */
  constructor(public payload?: string) { }
}
/**
 * Action Update default Scope to store
 *
 * @export
 * @class PutDefaultScopeAction
 * @implements {Action}
 */
export class PutDefaultScopeAction implements Action {
  type = ActionTypes.PUT_DEFAULT_SCOPE;
  /**
   * Creates an instance of PutDefaultScopeAction.
   * @param {ScopeByUser} [payload]
   * @memberof PutDefaultScopeAction
   */
  constructor(public payload?: ScopeByUser) { }
}

/**
 * Action Update Scope to store
 *
 * @export
 * @class PutScopeAction
 * @implements {Action}
 */
export class PutCopiedTagsAction implements Action {
  type = ActionTypes.PUT_COPIED_TAGS;
  /**
   * Creates an instance of PutCopiedTagsAction.
   * @param {Array<TagClone> } [payload]
   * @memberof PutCopiedTagsAction
   */
  constructor(public payload: Array<TagClone | any>) { }
}

/**
 * Action Update Scope to store
 *
 * @export
 * @class PutScopeAction
 * @implements {Action}
 */
export class PutBasketAction implements Action {
  type = ActionTypes.PUT_BASKET;
  /**
   * Creates an instance of PutBasketAction.
   * @param { string } [payload]
   * @memberof PutBasketAction
   */
  constructor(public payload: string) { }
}
/**
 *
 *
 * @export
 * @class PutBasketByScopeAction
 * @implements {Action}
 */
export class PutBasketByScopeAction implements Action {
  type = ActionTypes.PUT_BASKET_BY_SCOPE;
  /**
   *Creates an instance of PutBasketByScopeAction.
   * @param {*} payload
   * @memberof PutBasketByScopeAction
   */
  constructor(public payload: any) { }
}




export type Actions
  = PutPageSizeAction
  | PutScopeAction
  | PutBasketAction
  | PutBasketByScopeAction
  | PutCopiedTagsAction;
