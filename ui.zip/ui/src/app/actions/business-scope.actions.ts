import { BusinessScope } from './../models/business-scope';
import { Basket } from './../models/basket';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';

export const ActionTypes = {
  BUSINESS_SCOPE_LOADING: type('[Business Scope] loading'),
  PUT_BUSINESS_SCOPE_RESULTS: type('[Business Scope] put Business Scope result'),
  PUT_BUSINESS_SCOPE_ERROR: type('[Business Scope] put Business Scope error'),
  PUT_BUSINESS_SCOPE_ALL_LOADED: type('[Business Scope] put Business Scope all loaded'),
  INIT:  type('[Business Scope] init state'),


  PUT_BUSINESS_SCOPE_UPDATING: type('[Business Scope] put Business Scope updating'),
  PUT_BUSINESS_SCOPE_UPDATE_RESULT: type('[Business Scope] put Business Scope update result'),
  PUT_BUSINESS_SCOPE_UPDATE_ERROR: type('[Business Scope] put Business Scope update error'),
  PUT_BUSINESS_SCOPE_UPDATE_INT: type('[Business Scope] put Business Scope update init'),
  PUT_BUSINESS_SCOPE_UPDATE_RULE_FILE_RESULT: type('[Business Scope] put Business Scope file result update')

};

export class AllLoadedBusinessScope implements Action {
  type = ActionTypes.PUT_BUSINESS_SCOPE_ALL_LOADED;
  /**
   * Creates an instance of LoadingBusinessScope.
   * @param {any} [payload]
   * @memberof LoadingBusinessScope
   */
  constructor(public payload?: boolean ) { }
}

export class LoadingBusinessScope implements Action {
  type = ActionTypes.BUSINESS_SCOPE_LOADING;
  /**
   * Creates an instance of LoadingBusinessScope.
   * @param {any} [payload]
   * @memberof LoadingBusinessScope
   */
  constructor(public payload: boolean ) { }
}

export class PutBusinessScopeResults implements Action {
  type = ActionTypes.PUT_BUSINESS_SCOPE_RESULTS;
  /**
   * Creates an instance of PutBusinessScopeResults.
   * @param {any} [payload]
   * @memberof PutBusinessScopeResults
   */
  constructor(public payload: Array<BusinessScope> ) { }
}

export class PutBusinessScopeError implements Action {
  type = ActionTypes.PUT_BUSINESS_SCOPE_ERROR;
  /**
   * Creates an instance of PutBusinessScopeError.
   * @param {any} [payload]
   * @memberof PutBusinessScopeError
   */
  constructor(public payload: Error ) { }
}

export class InitBusinessScope implements Action {
  type = ActionTypes.INIT;
  /**
   * Creates an instance of InitBusinessScope.
   * @param {any} [payload]
   * @memberof InitBusinessScope
   */
  constructor(public payload? ) { }
}


export class PutUpdatingBusinessScope implements Action {
  type = ActionTypes.PUT_BUSINESS_SCOPE_UPDATING;
  /**
   * Creates an instance of LoadingBusinessScope.
   * @param {any} [payload]
   * @memberof LoadingBusinessScope
   */
  constructor(public payload: boolean ) { }
}

export class InitUpdatingBusinessScope implements Action {
  type = ActionTypes.PUT_BUSINESS_SCOPE_UPDATE_INT;
  /**
   * Creates an instance of InitBusinessScope.
   * @param {any} [payload]
   * @memberof InitBusinessScope
   */
  constructor(public payload? ) { }
}

export class PutUpdatingBusinessScopeResults implements Action {
  type = ActionTypes.PUT_BUSINESS_SCOPE_UPDATE_RESULT;
  /**
   * Creates an instance of PutBusinessScopeResults.
   * @param {any} [payload]
   * @memberof PutBusinessScopeResults
   */
  constructor(public payload: Array<BusinessScope> ) { }
}

export class PutUpdatingBusinessScopeRuleFileResults implements Action {
  type = ActionTypes.PUT_BUSINESS_SCOPE_UPDATE_RULE_FILE_RESULT;
  /**
   * Creates an instance of PutUpdatingBusinessScopeRuleFileResults.
   * @param {any} [payload]
   * @memberof PutUpdatingBusinessScopeRuleFileResults
   */
  constructor(public payload: Array<BusinessScope> ) { }
}


export class PutUpdatingBusinessScopeError implements Action {
  type = ActionTypes.PUT_BUSINESS_SCOPE_UPDATE_ERROR;
  /**
   * Creates an instance of PutBusinessScopeError.
   * @param {any} [payload]
   * @memberof PutBusinessScopeError
   */
  constructor(public payload: Error ) { }
}

export type Actions
= InitBusinessScope
| AllLoadedBusinessScope
| PutBusinessScopeResults
| PutBusinessScopeError
| LoadingBusinessScope
| PutUpdatingBusinessScope
| InitUpdatingBusinessScope
| PutUpdatingBusinessScopeResults
| PutUpdatingBusinessScopeError
| PutUpdatingBusinessScopeRuleFileResults;
