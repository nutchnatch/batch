import { Action } from '@ngrx/store';
import { type } from '../util';
import { Error } from 'app/models/error';
import { EnvelopeCreationResult } from 'app/models/envelope-creation-result';


export const ActionTypes = {
  LOADING: type('[Upload] loading'),
  PUT_DOCUMENT_LIST: type('[Upload] put document list'),
  PUT_DOCUMENT_LIST_ERROR: type('[Upload] put document list error'),
  PUT_RESULT: type('[Upload] put result'),
  POST_DOCUMENT_ERROR:  type('[Upload] post error'),
  REMOVE_DOCUMENT_LIST_BY_NAME: type('[Upload] remove document list by name'),
  INIT_DOCUMENT_LIST:  type('[Upload] init document list state'),
};

export class LoadingDocumentList implements Action {
  type = ActionTypes.LOADING;
  /**
   * Creates an instance of LoadingDocumentList.
   * @param {boolean} [payload]
   * @memberof LoadingDocumentList
   */
  constructor(public payload?: boolean) { }
}

export class PutDocumentList implements Action {
  type = ActionTypes.PUT_DOCUMENT_LIST;
  /**
   * Creates an instance of PutDocumentList.
   * @param {Array<File>} [payload]
   * @memberof PutDocumentList
   */
  constructor(public payload: Array<File>) { }
}

export class PutDocumentListError implements Action {
  type = ActionTypes.PUT_DOCUMENT_LIST_ERROR;
  /**
   * Creates an instance of PutDocumentListError.
   * @param {Error} [payload]
   * @memberof PutDocumentListError
   */
  constructor(public payload: Error) { }
}

export class PostDocumentError implements Action {
  type = ActionTypes.PUT_DOCUMENT_LIST_ERROR;
  /**
   * Creates an instance of PostDocumentError.
   * @param {Error} [payload]
   * @memberof PostDocumentError
   */
  constructor(public payload: Error) { }
}


export class PutResult implements Action {
  type = ActionTypes.PUT_RESULT;
  /**
   * Creates an instance of PutResult.
   * @param {Array<EnvelopeCreationResult>} [payload]
   * @memberof PutResult
   */
  constructor(public payload: Array<EnvelopeCreationResult>) { }
}

export class RemoveDocumentListByName implements Action {
  type = ActionTypes.REMOVE_DOCUMENT_LIST_BY_NAME;
  /**
   * Creates an instance of RemoveDocumentListByName.
   * @param {string} [payload]
   * @memberof RemoveDocumentListByName
   */
  constructor(public payload: string) { }
}

export class InitDocumentList implements Action {
  type = ActionTypes.INIT_DOCUMENT_LIST;
  /**
   * Creates an instance of InitDocumentList.
   * @param {?} [payload]
   * @memberof InitDocumentList
   */
  constructor(public payload? ) { }
}


export type Actions
= LoadingDocumentList
| PutDocumentList
| PutDocumentListError
| PostDocumentError
| RemoveDocumentListByName
| InitDocumentList;
