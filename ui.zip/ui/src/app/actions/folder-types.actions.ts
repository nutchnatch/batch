import { FolderTypes } from './../models/folder-types';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  LOADING_FOLDER_TYPES: type('[Folder Types] loading'),
  PUT_FOLDER_TYPES: type('[Folder Types] put document'),
  PUT_FOLDER_TYPES_BY_ID: type('[Folder Types] put document by ID'),
  PUT_FOLDER_TYPES_ERROR: type('[Folder Types] put document error'),
  INIT_FOLDER_TYPES: type('[Folder Types] init state'),

  PUT_TOOGLING_STATE: type('[Folder Types] activating/deativating state'),
  PUT_TOOGLING_RESULT: type('[Folder Types] activating/deativating state result'),
  PUT_TOOGLING_ERROR: type('[Folder Types] activating/deativating state error'),
  PUT_TOOGLING_INIT: type('[Folder Types] activating/deativating init'),

  PUT_FOLDER_TYPES_UPDATING: type('[Folder Types] Folder Types updating state'),
  PUT_FOLDER_TYPES_UPDATING_RESULT: type('[Folder Types] Folder Types updating state result'),
  PUT_FOLDER_TYPES_UPDATING_ERROR: type('[Folder Types] Folder Types updating state error'),
  PUT_FOLDER_TYPES_UPDATING_INIT: type('[Folder Types] Folder Types updating init'),

  PUT_FOLDER_TYPES_CREATING: type('[Folder Types] Folder Types creating state'),
  PUT_FOLDER_TYPES_CREATING_RESULT: type('[Folder Types] Folder Types creating state result'),
  PUT_FOLDER_TYPES_CREATING_ERROR: type('[Folder Types] Folder Types creating state error'),
  PUT_FOLDER_TYPES_CREATING_INIT: type('[Folder Types] Folder Types creating init')

};

export class LoadingFolderTypes implements Action {
  type = ActionTypes.LOADING_FOLDER_TYPES;
  /**
   * Creates an instance of LoadingFolderTypes.
   * @param {boolean} [payload]
   * @memberof LoadingFolderTypes
   */
  constructor(public payload?: boolean) { }
}

export class PutFolderTypes implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES;
  /**
   * Creates an instance of PutFolderTypes.
   * @param {Array<FolderTypes> | Array<any>} payload
   * @memberof PutFolderTypes
   */
  constructor(public payload: Array<FolderTypes> | Array<any>) { }
}

export class PutFolderTypesById implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_BY_ID;
  /**
   * Creates an instance of PutFolderTypes.
   * @param {FolderTypes} payload
   * @memberof PutFolderTypes
   */
  constructor(public payload: FolderTypes) { }
}

export class PutFolderTypesError implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_ERROR;
  /**
   * Creates an instance of PutFolderTypesError.
   * @param {Error} payload
   * @memberof PutFolderTypesError
   */
  constructor(public payload: Error) { }
}

export class InitPutFolderTypes implements Action {
  type = ActionTypes.INIT_FOLDER_TYPES;
  /**
   * Creates an instance of InitPutFolderTypes.
   * @param {any} [payload]
   * @memberof InitPutFolderTypes
   */
  constructor(public payload?) { }
}



export class PutFolderTypesTooglingState implements Action {
  type = ActionTypes.PUT_TOOGLING_STATE;
  /**
   * Creates an instance of PutFolderTypesTooglingState.
   * @param {any} [payload]
   * @memberof PutFolderTypesTooglingState
   */
  constructor(public payload?) { }
}

export class PutFolderTypesToogleStateResult implements Action {
  type = ActionTypes.PUT_TOOGLING_RESULT;
  /**
   * Creates an instance of PutFolderTypesToogleStateResult.
   * @param {Array<any>} payload
   * @memberof PutFolderTypesToogleStateResult
   */
  constructor(public payload: Array<any>) { }
}

export class PutFolderTypesToogleStateError implements Action {
  type = ActionTypes.PUT_TOOGLING_ERROR;
  /**
   * Creates an instance of PutFolderTypesToogleStateError.
   * @param {Error} payload
   * @memberof PutFolderTypesToogleStateError
   */
  constructor(public payload: Error) { }
}

export class PutFolderTypesToogleStateInit implements Action {
  type = ActionTypes.PUT_TOOGLING_INIT;
  /**
   * Creates an instance of PutFolderTypesToogleStateInit.
   * @param {any} [payload]
   * @memberof PutFolderTypesToogleStateInit
   */
  constructor(public payload?) { }
}



export class PutFolderTypesUpdating implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_UPDATING;
  /**
   * Creates an instance of PutFolderTypesUpdating.
   * @param {any} [payload]
   * @memberof PutFolderTypesUpdating
   */
  constructor(public payload?) { }
}

export class PutFolderTypesUpdatingResult implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_UPDATING_RESULT;
  /**
   * Creates an instance of PutFolderTypesUpdatingResult.
   * @param {Array<any>} payload
   * @memberof PutFolderTypesUpdatingResult
   */
  constructor(public payload: Array<any>) { }
}

export class PutFolderTypesUpdatingError implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_UPDATING_ERROR;
  /**
   * Creates an instance of PutFolderTypesUpdatingError.
   * @param {Error} payload
   * @memberof PutFolderTypesUpdatingError
   */
  constructor(public payload: Error) { }
}

export class PutFolderTypesUpdatingInit implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_UPDATING_INIT;
  /**
   * Creates an instance of PutFolderTypesUpdatingInit.
   * @param {any} [payload]
   * @memberof PutFolderTypesUpdatingInit
   */
  constructor(public payload?) { }
}


export class PutFolderTypesCreating implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_CREATING;
  /**
   * Creates an instance of PutFolderTypesCreating.
   * @param {any} [payload]
   * @memberof PutFolderTypesCreating
   */
  constructor(public payload?) { }
}

export class PutFolderTypesCreatingResult implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_CREATING_RESULT;
  /**
   * Creates an instance of PutFolderTypesCreatingResult.
   * @param {Array<any>} payload
   * @memberof PutFolderTypesCreatingResult
   */
  constructor(public payload: Array<any>) { }
}

export class PutFolderTypesCreatingError implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_CREATING_ERROR;
  /**
   * Creates an instance of PutFolderTypesCreatingError.
   * @param {Error} payload
   * @memberof PutFolderTypesCreatingError
   */
  constructor(public payload: Error) { }
}

export class PutFolderTypesCreatingInit implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_CREATING_INIT;
  /**
   * Creates an instance of PutFolderTypesCreatingInit.
   * @param {any} [payload]
   * @memberof PutFolderTypesCreatingInit
   */
  constructor(public payload?) { }
}


export type Actions
  = PutFolderTypes
  | PutFolderTypesById
  | LoadingFolderTypes
  | PutFolderTypesError
  | InitPutFolderTypes
  | PutFolderTypesTooglingState
  | PutFolderTypesToogleStateResult
  | PutFolderTypesToogleStateError
  | PutFolderTypesToogleStateInit
  | PutFolderTypesUpdating
  | PutFolderTypesUpdatingError
  | PutFolderTypesUpdatingResult
  | PutFolderTypesUpdatingInit
  | PutFolderTypesCreating
  | PutFolderTypesCreatingResult
  | PutFolderTypesCreatingError
  | PutFolderTypesCreatingInit;
