import { Tag } from 'app/models/tag';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  LOADING_TAG: type('[Tag] loading'),
  PUT_TAG: type('[Tag] put tag'),
  PUT_TAG_ERROR: type('[Tag] put tag error'),
  INIT_TAG:  type('[Tag] init state'),

  UPDATING_TAG: type('[Tag] updating'),
  UPDATING_TAG_ERROR: type('[Tag] updating error'),
  UPDATING_TAG_SUCCESS: type('[Tag] updating success'),

  CREATING_TAG: type('[Tag] create'),
  CREATE_INIT: type('[Tag] create int'),
  CREATE_TAG_ERROR: type('[Tag] create error'),
  CREATE_TAG_SUCCESS: type('[Tag] create success')

};

export class LoadingTag implements Action {
  type = ActionTypes.LOADING_TAG;
  /**
   * Creates an instance of LoadingTag.
   * @param {boolean} [payload]
   * @memberof LoadingTag
   */
  constructor(public payload?: boolean) { }
}

export class PutTag implements Action {
  type = ActionTypes.PUT_TAG;
  /**
   * Creates an instance of PutTag.
   * @param {Tag} payload
   * @memberof PutTag
   */
  constructor(public payload: Array<Tag> | Array<any>) { }
}

export class PutTagError implements Action {
  type = ActionTypes.PUT_TAG_ERROR;
  /**
   * Creates an instance of PutTagError.
   * @param {Error} payload
   * @memberof PutTagError
   */
  constructor(public payload: Error) { }
}

export class InitPutTag implements Action {
  type = ActionTypes.INIT_TAG;
  /**
   * Creates an instance of InitPutTag.
   * @param {any} [payload]
   * @memberof InitPutTag
   */
  constructor(public payload? ) { }
}

export class UpdatingTag implements Action {
  type = ActionTypes.UPDATING_TAG;
  /**
   * Creates an instance of LoadingTag.
   * @param {boolean} [payload]
   * @memberof LoadingTag
   */
  constructor(public payload?: boolean) { }
}

export class UpdatingTagError implements Action {
  type = ActionTypes.UPDATING_TAG_ERROR;
  /**
   * Creates an instance of UpdatingTagError.
   * @param {Error} [payload]
   * @memberof UpdatingTagError
   */
  constructor(public payload: Error) { }
}

export class UpdatingTagSuccess implements Action {
  type = ActionTypes.UPDATING_TAG_SUCCESS;
  /**
   * Creates an instance of UpdatingTagSuccess.
   * @param {Tag} [payload]
   * @memberof UpdatingTagSuccess
   */
  constructor(public payload: Array<Tag> ) { }
}

export class CreatingTag implements Action {
  type = ActionTypes.CREATING_TAG;
  /**
   * Creates an instance of CreatingTag.
   * @param {boolean} [payload]
   * @memberof CreatingTag
   */
  constructor(public payload?: boolean) { }
}

export class CreateTagError implements Action {
  type = ActionTypes.CREATE_TAG_ERROR;
  /**
   * Creates an instance of CreateTagError.
   * @param {Error} [payload]
   * @memberof CreateTagError
   */
  constructor(public payload: Error) { }
}

export class CreateTagSuccess implements Action {
  type = ActionTypes.CREATE_TAG_SUCCESS;
  /**
   * Creates an instance of CreateTagSuccess.
   * @param {Tag} [payload]
   * @memberof CreateTagSuccess
   */
  constructor(public payload: Array<Tag> ) { }
}

export class CreateTagInit implements Action {
  type = ActionTypes.CREATE_INIT;
  /**
   * Creates an instance of CreateTagInit.
   * @param {any} [payload]
   * @memberof CreateTagInit
   */
  constructor(public payload? ) { }
}

export type Actions
= PutTag
| LoadingTag
| PutTagError
| InitPutTag
| UpdatingTag
| UpdatingTagError
| UpdatingTagSuccess
| CreatingTag
| CreateTagError
| CreateTagSuccess
| CreateTagInit;
