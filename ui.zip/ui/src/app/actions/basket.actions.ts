// import { BasketCreationResult } from 'app/models/basket-creation-result';
import { Basket } from './../models/basket';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';

export const ActionTypes = {
  LOADING_BASKET: type('[Basket] loading'),
  PUT_BASKET_RESULTS: type('[Basket] put basket'),
  PUT_BASKET_ERROR: type('[Basket] put basket error'),

  PUT_UPDATE_BASKET_LOADING: type('[Basket] put basket loading update'),
  PUT_UPDATE_BASKET_RESULTS: type('[Basket] put basket update'),
  PUT_UPDATE_BASKET_ERROR: type('[Basket] put update basket error '),


  PUT_DELETE_BASKET_LOADING: type('[Basket] put basket loading DELETE'),
  PUT_DELETE_BASKET_RESULTS: type('[Basket] put basket DELETE'),
  PUT_DELETE_BASKET_ERROR: type('[Basket] put delete basket error '),


  PUT_POST_BASKET_LOADING: type('[Basket] put basket loading POST'),
  PUT_POST_BASKET_RESULTS: type('[Basket] put basket POST'),
  PUT_POST_BASKET_ERROR: type('[Basket] put post basket error '),

  PUT_CURRENT_BASKET: type('[Basket] put current basket'),

  INIT_DELETE: type('[Basket] init delete'),
  INIT_POST: type('[Basket] init psot'),
  INIT_UPDATE: type('[Basket] init updating'),
  INIT: type('[Basket] init state'),
};

export class LoadingBasket implements Action {
  type = ActionTypes.LOADING_BASKET;
  /**
   * Creates an instance of LoadingEnvelope.
   * @param {boolean} payload
   *
   * @memberOf LoadingEnvelope
   */
  constructor(public payload?: boolean) { }
}

export class PutBasketResults implements Action {
  type = ActionTypes.PUT_BASKET_RESULTS;
  /**
   * Creates an instance of PutBasket.
   * @param {Basket} payload
   * @memberof PutBasket
   */
  constructor(public payload: any) { }
}

export class PutBasketError implements Action {
  type = ActionTypes.PUT_BASKET_ERROR;
  /**
   * Creates an instance of PutBasketError.
   * @param {Error} payload
   * @memberof PutBasketError
   */
  constructor(public payload: Error) { }
}


export class LoadingUpdatingBasket implements Action {
  type = ActionTypes.PUT_UPDATE_BASKET_LOADING;
  /**
   * Creates an instance of LoadingEnvelope.
   * @param {boolean} payload
   *
   * @memberOf LoadingUpdatingBasket
   */
  constructor(public payload?: boolean) { }
}

export class PutUpdateBasketResults implements Action {
  type = ActionTypes.PUT_UPDATE_BASKET_RESULTS;
  /**
   * Creates an instance of PutBasket.
   * @param {Basket} payload
   * @memberof PutBasket
   */
  constructor(public payload: Basket) { }
}

export class PutUpdateBasketError implements Action {
  type = ActionTypes.PUT_UPDATE_BASKET_ERROR;
  /**
   * Creates an instance of PutBasketError.
   * @param {Error} payload
   * @memberof PutBasketError
   */
  constructor(public payload: Error) { }
}

export class LoadingDeleteBasket implements Action {
  type = ActionTypes.PUT_DELETE_BASKET_LOADING;
  /**
   * Creates an instance of LoadingEnvelope.
   * @param {boolean} payload
   *
   * @memberOf LoadingDeleteBasket
   */
  constructor(public payload?: boolean) { }
}

export class PutDeleteBasketResults implements Action {
  type = ActionTypes.PUT_DELETE_BASKET_RESULTS;
  /**
   * Creates an instance of PutDeleteBasketResults.
   * @param {string} payload
   * @memberof PutDeleteBasketResults
   */
  constructor(public payload: string) { }
}

export class PutDeleteBasketError implements Action {
  type = ActionTypes.PUT_DELETE_BASKET_ERROR;
  /**
   * Creates an instance of PutBasketError.
   * @param {Error} payload
   * @memberof PutDeleteBasketError
   */
  constructor(public payload: Error) { }
}

export class LoadingPostBasket implements Action {
  type = ActionTypes.PUT_POST_BASKET_LOADING;
  /**
   * Creates an instance of LoadingEnvelope.
   * @param {boolean} payload
   *
   * @memberOf LoadingDeleteBasket
   */
  constructor(public payload?: boolean) { }
}

export class PutPostBasketResults implements Action {
  type = ActionTypes.PUT_POST_BASKET_RESULTS;
  /**
   * Creates an instance of PutDeleteBasketResults.
   * @param {Basket} payload
   * @memberof PutDeleteBasketResults
   */
  constructor(public payload: Basket) { }
}

export class PutPostBasketError implements Action {
  type = ActionTypes.PUT_POST_BASKET_ERROR;
  /**
   * Creates an instance of PutBasketError.
   * @param {Error} payload
   * @memberof PutDeleteBasketError
   */
  constructor(public payload: Error) { }
}

export class PutCurrentBasket implements Action {
  type = ActionTypes.PUT_CURRENT_BASKET;
  /**
   * Creates an instance of PutBasketError.
   * @param {string} payload
   * @memberof PutCurrentBasket
   */
  constructor(public payload: string) { }
}



export class InitPostBasket implements Action {
  type = ActionTypes.INIT_POST;
  /**
   * Creates an instance of InitPutBasket.
   * @param {any} [payload]
   * @memberof InitDeleteBasket
   */
  constructor(public payload?) { }
}
export class InitDeleteBasket implements Action {
  type = ActionTypes.INIT_DELETE;
  /**
   * Creates an instance of InitPutBasket.
   * @param {any} [payload]
   * @memberof InitDeleteBasket
   */
  constructor(public payload?) { }
}
export class InitUpdateBasket implements Action {
  type = ActionTypes.INIT_UPDATE;
  /**
   * Creates an instance of InitPutBasket.
   * @param {any} [payload]
   * @memberof InitPutBasket
   */
  constructor(public payload?) { }
}
export class InitPutBasket implements Action {
  type = ActionTypes.INIT;
  /**
   * Creates an instance of InitPutBasket.
   * @param {any} [payload]
   * @memberof InitPutBasket
   */
  constructor(public payload?) { }
}

export type Actions
  = LoadingBasket
  | PutBasketResults
  | PutBasketError
  | LoadingUpdatingBasket
  | PutUpdateBasketResults
  | PutUpdateBasketError
  | LoadingDeleteBasket
  | PutDeleteBasketResults
  | PutDeleteBasketError
  | LoadingPostBasket
  | PutPostBasketResults
  | PutPostBasketError
  | PutCurrentBasket
  | InitPostBasket
  | InitDeleteBasket
  | InitUpdateBasket
  | InitPutBasket;
