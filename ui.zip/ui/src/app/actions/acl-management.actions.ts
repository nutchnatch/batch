import { Action } from '@ngrx/store';
import { type } from '../util';

export const ActionTypes = {
  PUT_LOADING: type('[ACL] loading Acl Management'),
  PUT_ACL: type('[ACL] Put Acl Management'),
  PUT_ERROR: type('[ACL] Put Acl Error Management'),

  PUT_UPDATE_LOADING: type('[ACL] Put Acl UPDATE Error Management'),
  PUT_UPDATE_RESULT: type('[ACL] Put Acl UPDATE result Management'),
  PUT_UPDATE_ERROR: type('[ACL] Put Acl UPDATE error Management'),
  PUT_UPDATE_ID: type('[ACL] Put Acl UPDATE id Management'),
  PUT_UPDATE_INIT: type('[ACL] Put Acl UPDATE init Management'),

  INIT: type('[ACL] init Management'),
};


export class PutLoadingAclManagementAction implements Action {
  type = ActionTypes.PUT_LOADING;
  /**
   * @param {boolean} [payload]
   * @memberof PutLoadingAclManagementAction
   */
  constructor(public payload: boolean ) {}
}

export class PutAclManagementAction implements Action {
  type = ActionTypes.PUT_ACL;
  /**
   * @param {Array<any>} [payload]
   * @memberof PutAclManagementAction
   */
  constructor(public payload: Array<any> ) {}
}

export class InitAclManagementAction implements Action {
  type = ActionTypes.PUT_ACL;
  /**
   *
   * @memberof InitAclManagementAction
   */
  constructor(public payload?) {}
}


export class PutErrorAclManagementAction implements Action {
  type = ActionTypes.PUT_ERROR;
  /**
   *
   * @memberof PutErrorAclManagementAction
   */
  constructor(public payload: Error) {}
}

export class PutUpdateLoadingAclManagementAction implements Action {
  type = ActionTypes.PUT_UPDATE_LOADING;
  /**
   * @param {boolean} [payload]
   * @memberof PutUpdateLoadingAclManagementAction
   */
  constructor(public payload?: boolean ) {}
}

export class PutResultUpdateAclManagementAction implements Action {
  type = ActionTypes.PUT_UPDATE_RESULT;
  /**
   * @param {Array<any>} [payload]
   * @memberof PutResultUpdateAclManagementAction
   */
  constructor(public payload: Array<any> ) {}
}

export class PutErrorUpdateAclManagementAction implements Action {
  type = ActionTypes.PUT_UPDATE_ERROR;
  /**
   * @param {Error} [payload]
   * @memberof PutErrorUpdateAclManagementAction
   */
  constructor(public payload: Error | any ) {}
}

export class PutIdUpdateAclManagementAction implements Action {
  type = ActionTypes.PUT_UPDATE_ID;
  /**
   * @param {string} [payload]
   * @memberof PutIdUpdateAclManagementAction
   */
  constructor(public payload: string) {}
}

export class PutInitUpdateAclManagementAction implements Action {
  type = ActionTypes.PUT_UPDATE_INIT;
  /**
   * @param {string} [payload]
   * @memberof PutInitUpdateAclManagementAction
   */
  constructor(public payload?) {}
}


export type Actions
= PutAclManagementAction
| PutLoadingAclManagementAction
| InitAclManagementAction
| PutErrorAclManagementAction
| PutUpdateLoadingAclManagementAction
| PutResultUpdateAclManagementAction
| PutErrorUpdateAclManagementAction
| PutIdUpdateAclManagementAction
| PutInitUpdateAclManagementAction;
