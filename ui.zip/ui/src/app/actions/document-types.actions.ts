import { DocumentTypes } from './../models/document-types';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  LOADING_DOCUMENT_TYPES: type('[Document Types] loading'),
  PUT_DOCUMENT_TYPES: type('[Document Types] put document'),
  PUT_DOCUMENT_TYPES_BY_ID: type('[Document Types] put Document Types by ID'),
  PUT_DOCUMENT_TYPES_ERROR: type('[Document Types] put document error'),
  INIT_DOCUMENT_TYPES:  type('[Document Types] init state'),

  PUT_TOOGLING_STATE: type('[Document Types] activating/deativating state'),
  PUT_TOOGLING_RESULT: type('[Document Types] activating/deativating state result'),
  PUT_TOOGLING_ERROR: type('[Document Types] activating/deativating state error'),
  PUT_TOOGLING_INIT: type('[Document Types] activating/deativating init'),

  PUT_DOCUMENT_TYPES_UPDATING: type('[Document Types] Document Types updating state'),
  PUT_DOCUMENT_TYPES_UPDATING_RESULT: type('[Document Types] Document Types updating state result'),
  PUT_DOCUMENT_TYPES_UPDATING_ERROR: type('[Document Types] Document Types updating state error'),
  PUT_DOCUMENT_TYPES_UPDATING_INIT: type('[Document Types] Document Types updating init'),

  PUT_DOCUMENT_TYPES_CREATING: type('[Document Types] Document Types creating state'),
  PUT_DOCUMENT_TYPES_CREATING_RESULT: type('[Document Types] Document Types creating state result'),
  PUT_DOCUMENT_TYPES_CREATING_ERROR: type('[Document Types] Document Types creating state error'),
  PUT_DOCUMENT_TYPES_CREATING_INIT: type('[Document Types] Document Types creating init')

};

export class LoadingDocumentTypes implements Action {
  type = ActionTypes.LOADING_DOCUMENT_TYPES;
  /**
   * Creates an instance of LoadingDocumentTypes.
   * @param {boolean} [payload]
   * @memberof LoadingDocumentTypes
   */
  constructor(public payload?: boolean) { }
}

export class PutDocumentTypes implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES;
  /**
   * Creates an instance of PutDocumentTypes.
   * @param {DocumentTypes} payload
   * @memberof PutDocumentTypes
   */
  constructor(public payload: Array<DocumentTypes> | Array<any>) { }
}

export class PutDocumentTypesError implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES_ERROR;
  /**
   * Creates an instance of PutDocumentTypesError.
   * @param {Error} payload
   * @memberof PutDocumentTypesError
   */
  constructor(public payload: Error) { }
}

export class PutDocumentTypesById implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES_BY_ID;
  /**
   * Creates an instance of PutDocumentTypes.
   * @param {DocumentTypes} payload
   * @memberof PutDocumentTypes
   */
  constructor(public payload: DocumentTypes ) { }
}

export class InitPutDocumentTypes implements Action {
  type = ActionTypes.INIT_DOCUMENT_TYPES;
  /**
   * Creates an instance of InitPutDocumentTypes.
   * @param {any} [payload]
   * @memberof InitPutDocumentTypes
   */
  constructor(public payload? ) { }
}


export class PutDocumentTypesTooglingState implements Action {
  type = ActionTypes.PUT_TOOGLING_STATE;
  /**
   * Creates an instance of PutDocumentTypesTooglingState.
   * @param {any} [payload]
   * @memberof PutDocumentTypesTooglingState
   */
  constructor(public payload? ) { }
}

export class PutDocumentTypesToogleStateResult implements Action {
  type = ActionTypes.PUT_TOOGLING_RESULT;
/**
 * Creates an instance of PutDocumentTypesToogleStateResult.
 * @param {Array<any>} payload
 * @memberof PutDocumentTypesToogleStateResult
 */
constructor(public payload: Array<any> ) { }
}

export class PutDocumentTypesToogleStateError implements Action {
  type = ActionTypes.PUT_TOOGLING_ERROR;
/**
 * Creates an instance of PutDocumentTypesToogleStateError.
 * @param {Error} payload
 * @memberof PutDocumentTypesToogleStateError
 */
constructor(public payload: Error ) { }
}

export class PutDocumentTypesToogleStateInit implements Action {
  type = ActionTypes.PUT_TOOGLING_INIT;
/**
 * Creates an instance of PutDocumentTypesToogleStateInit.
 * @param {any} [payload]
 * @memberof PutDocumentTypesToogleStateInit
 */
constructor(public payload? ) { }
}



export class PutDocumentTypesUpdating implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES_UPDATING;
  /**
   * Creates an instance of PutDocumentTypesUpdating.
   * @param {any} [payload]
   * @memberof PutDocumentTypesUpdating
   */
  constructor(public payload? ) { }
}

export class PutDocumentTypesUpdatingResult implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES_UPDATING_RESULT;
/**
 * Creates an instance of PutDocumentTypesUpdatingResult.
 * @param {Array<any>} payload
 * @memberof PutDocumentTypesUpdatingResult
 */
constructor(public payload: Array<any> ) { }
}

export class PutDocumentTypesUpdatingError implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES_UPDATING_ERROR;
/**
 * Creates an instance of PutDocumentTypesUpdatingError.
 * @param {Error} payload
 * @memberof PutDocumentTypesUpdatingError
 */
constructor(public payload: Error) { }
}

export class PutDocumentTypesUpdatingInit implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES_UPDATING_INIT;
/**
 * Creates an instance of PutDocumentTypesUpdatingInit.
 * @param {any} [payload]
 * @memberof PutDocumentTypesUpdatingInit
 */
constructor(public payload? ) { }
}


export class PutDocumentTypesCreating implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES_CREATING;
  /**
   * Creates an instance of PutDocumentTypesCreating.
   * @param {any} [payload]
   * @memberof PutDocumentTypesCreating
   */
  constructor(public payload? ) { }
}

export class PutDocumentTypesCreatingResult implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES_CREATING_RESULT;
/**
 * Creates an instance of PutDocumentTypesCreatingResult.
 * @param {Array<any>} payload
 * @memberof PutDocumentTypesCreatingResult
 */
constructor(public payload: Array<any> ) { }
}

export class PutDocumentTypesCreatingError implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES_CREATING_ERROR;
/**
 * Creates an instance of PutDocumentTypesCreatingError.
 * @param {Error} payload
 * @memberof PutDocumentTypesCreatingError
 */
constructor(public payload: Error) { }
}

export class PutDocumentTypesCreatingInit implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES_CREATING_INIT;
/**
 * Creates an instance of PutDocumentTypesCreatingInit.
 * @param {any} [payload]
 * @memberof PutDocumentTypesCreatingInit
 */
constructor(public payload? ) { }
}


export type Actions
= PutDocumentTypes
| LoadingDocumentTypes
| PutDocumentTypesError
| PutDocumentTypesById
| InitPutDocumentTypes
| PutDocumentTypesTooglingState
| PutDocumentTypesToogleStateResult
| PutDocumentTypesToogleStateError
| PutDocumentTypesToogleStateInit
| PutDocumentTypesUpdating
| PutDocumentTypesUpdatingError
| PutDocumentTypesUpdatingResult
| PutDocumentTypesUpdatingInit
| PutDocumentTypesCreating
| PutDocumentTypesCreatingResult
| PutDocumentTypesCreatingError
| PutDocumentTypesCreatingInit;
