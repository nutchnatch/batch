import { Document } from './../models/document';
import { EnvelopeCreationResult } from 'app/models/envelope-creation-result';
import { Envelope } from './../models/envelope';
import { RestResponse } from 'app/models/rest-response';
import { Error } from 'app/models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';

export const ActionTypes = {
  LOADING_ENVELOPE: type('[Envelope] loading'),
  PUT_ENVELOPE_RESULT: type('[Envelope] put envelope result'),
  PUT_ENVELOPE_ERROR: type('[Envelope] put envelope error'),
  PUT_UPDATE_ENVELOPE: type('[Envelope] put upadate Envelope results'),
  UPDATING_ENVELOPE: type('[Envelope] put upadateing Envelope'),

  PUT_UPDATE_ENVELOPE_ERROR: type('[Envelope] put update envelope error'),
  PUT_UNDER_CONSTRUCTION: type('[Envelope] envelope update under construction step 1 (false) or 2 (true)'),
  PUT_UPDATE_ENVELOPE_INIT: type('[Envelope] envelope update init'),

  PUT_LIST_DOCUMENT_NAME: type('[Envelope] envelope update document name'),

  DELETE_DOCUMENT_ENVELOPE_LOADING: type('[Envelope] delete document envelope loading'),
  DELETE_DOCUMENT_ENVELOPE_RESULT: type('[Envelope] delete document envelope result'),
  DELETE_DOCUMENT_ENVELOPE_ERROR: type('[Envelope] delete document envelope error'),
  DELETE_DOCUMENT_ENVELOPE_INIT: type('[Envelope] delete document envelope init'),

  DELETE_ENVELOPE_LOADING: type('[Envelope] delete envelope loading'),
  DELETE_ENVELOPE_RESULT: type('[Envelope] delete envelope result'),
  DELETE_ENVELOPE_ERROR: type('[Envelope] delete envelope error'),
  DELETE_ENVELOPE_INIT: type('[Envelope] delete envelope init'),

  INIT_ENVELOPE: type('[Envelope] envelope init')
};


export class LoadingEnvelope implements Action {
  type = ActionTypes.LOADING_ENVELOPE;
  /**
   * Creates an instance of LoadingEnvelope.
   * @param {boolean} payload
   *
   * @memberOf LoadingEnvelope
   */
  constructor(public payload?: boolean) { }
}


export class UpdatingEnvelope implements Action {
  type = ActionTypes.UPDATING_ENVELOPE;
  /**
   * Creates an instance of UpdatingEnvelope.
   * @param {boolean} payload
   *
   * @memberOf UpdatingEnvelope
   */
  constructor(public payload?: boolean) { }
}

export class PutEnvelopeResult implements Action {
  type = ActionTypes.PUT_ENVELOPE_RESULT;
  /**
   * Creates an instance of PutEnvelopeResult.
   * @param { Array<Envelope> )} payload
   *
   * @memberOf PutEnvelopeResult
   */
  constructor(public payload: Array<Envelope> ) { }
}

export class PutUpdateEnvelope implements Action {
  type = ActionTypes.PUT_UPDATE_ENVELOPE;
  /**
   * Creates an instance of PutUpdateEnvelope.
   * @param {EnvelopeCreationResult} payload
   * @memberof PutUpdateEnvelope
   */
  constructor(public payload: EnvelopeCreationResult ) { }
}

export class PutEnvelopeError implements Action {
  type = ActionTypes.PUT_ENVELOPE_ERROR;
  /**
   * Creates an instance of PutEnvelopeError.
   * @param { Error } payload
   *
   * @memberOf PutEnvelopeError
   */
  constructor(public payload: Error ) { }
}

export class PutListDocumentName implements Action {
  type = ActionTypes.PUT_LIST_DOCUMENT_NAME;
  /**
   * Creates an instance of PutListDocumentName.
   * @param {Document} payload
   * @memberof PutListDocumentName
   */
  constructor(public payload: Document ) { }
}

export class PutUnderConstructionStep2 implements Action {
  type = ActionTypes.PUT_UNDER_CONSTRUCTION;
  /**
   * Creates an instance of PutUnderConstructionStep2.
   * @param { boolean } payload
   * step 1 = false and step 2 = true
   * @memberOf PutUpdateEnvelopeError
   */
  constructor(public payload: boolean ) { }
}

export class PutUpdateEnvelopeError implements Action {
  type = ActionTypes.PUT_UPDATE_ENVELOPE_ERROR;
  /**
   * Creates an instance of PutUpdateEnvelopeError.
   * @param { Error } payload
   *
   * @memberOf PutUpdateEnvelopeError
   */
  constructor(public payload: Error ) { }
}

export class InitUpdateEnvelope implements Action {
  type = ActionTypes.PUT_UPDATE_ENVELOPE_INIT;

  /**
   * Creates an instance of InitUpdateEnvelope.
   * @param {any} [payload]
   * @memberof InitUpdateEnvelope
   */
  constructor(public payload? ) { }
}

export class InitEnvelope implements Action {
  type = ActionTypes.INIT_ENVELOPE;

  /**
   * Creates an instance of InitEnvelope.
   * @param {any} [payload]
   * @memberof InitEnvelope
   */
  constructor(public payload? ) { }
}

export class DeleteDocumentEnvelopeLoading implements Action {
  type = ActionTypes.DELETE_DOCUMENT_ENVELOPE_LOADING;
  /**
   * Creates an instance of DeleteDocumentEnvelopeLoading.
   * @param {any} payload
   *
   * @memberOf DeleteDocumentEnvelopeLoading
   */
  constructor(public payload: { deleteLoading: boolean, deletingId: string }) { }
}

export class DeleteDocumentEnvelopeResults implements Action {
  type = ActionTypes.DELETE_DOCUMENT_ENVELOPE_RESULT;
  /**
   * Creates an instance of DeleteDocumentEnvelopeResults.
   * @param {Array<string>} payload
   *
   * @memberOf DeleteDocumentEnvelopeResults
   */
  constructor(public payload: Array<string>) { }
}

export class DeleteDocumentEnvelopeError implements Action {
  type = ActionTypes.DELETE_DOCUMENT_ENVELOPE_ERROR;
  /**
   * Creates an instance of DeleteDocumentEnvelopeError.
   * @param {Error} payload
   *
   * @memberOf DeleteDocumentEnvelopeError
   */
  constructor(public payload: Error) { }
}

export class DeleteDocumentEnvelopeInit implements Action {
  type = ActionTypes.DELETE_DOCUMENT_ENVELOPE_INIT;
  /**
   * Creates an instance of DeleteDocumentEnvelopeInit.
   * @param {any} payload
   *
   * @memberOf DeleteDocumentEnvelopeInit
   */
  constructor(public payload?) { }
}

export class DeleteEnvelopeLoading implements Action {
  type = ActionTypes.DELETE_ENVELOPE_LOADING;
  /**
   * Creates an instance of DeleteEnvelopeLoading.
   * @param {any} payload
   *
   * @memberOf DeleteEnvelopeLoading
   */
  constructor(public payload? ) { }
}

export class DeleteEnvelopeResults implements Action {
  type = ActionTypes.DELETE_ENVELOPE_RESULT;
  /**
   * Creates an instance of DeleteEnvelopeResults.
   * @param {Array<string>} payload
   *
   * @memberOf DeleteEnvelopeResults
   */
  constructor(public payload: Array<string>) { }
}

export class DeleteEnvelopeError implements Action {
  type = ActionTypes.DELETE_ENVELOPE_ERROR;
  /**
   * Creates an instance of DeleteEnvelopeError.
   * @param {Error} payload
   *
   * @memberOf DeleteEnvelopeError
   */
  constructor(public payload: Error) { }
}

export class DeleteEnvelopeInit implements Action {
  type = ActionTypes.DELETE_ENVELOPE_INIT;
  /**
   * Creates an instance of DeleteEnvelopeInit.
   * @param {any} payload
   *
   * @memberOf DeleteEnvelopeInit
   */
  constructor(public payload?) { }
}




export type Actions
  = LoadingEnvelope
  | PutEnvelopeResult
  | PutUpdateEnvelope
  | PutEnvelopeError
  | PutUpdateEnvelopeError
  | UpdatingEnvelope
  | DeleteDocumentEnvelopeLoading
  | DeleteDocumentEnvelopeResults
  | DeleteDocumentEnvelopeError
  | DeleteDocumentEnvelopeInit
  | DeleteEnvelopeLoading
  | DeleteEnvelopeResults
  | DeleteEnvelopeError
  | DeleteEnvelopeInit
  | PutListDocumentName;
