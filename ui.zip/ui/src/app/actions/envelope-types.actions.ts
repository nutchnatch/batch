import { EnvelopeTypes } from './../models/envelope-types';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  LOADING_ENVELOPE_TYPES: type('[Envelope Types] loading'),
  PUT_ENVELOPE_TYPES: type('[Envelope Types] put Envelope Types'),
  PUT_ENVELOPE_TYPES_BY_ID: type('[Envelope Types] put Envelope Types by ID'),
  PUT_ENVELOPE_TYPES_ERROR: type('[Envelope Types] put Envelope Types error'),
  INIT_ENVELOPE_TYPES:  type('[Envelope Types] init state'),

  PUT_TOOGLING_STATE: type('[Envelope Types] activating/deativating state'),
  PUT_TOOGLING_RESULT: type('[Envelope Types] activating/deativating state result'),
  PUT_TOOGLING_ERROR: type('[Envelope Types] activating/deativating state error'),
  PUT_TOOGLING_INIT: type('[Envelope Types] activating/deativating init'),

  PUT_ENVELOPE_TYPES_UPDATING: type('[Envelope Types] Envelope Types updating state'),
  PUT_ENVELOPE_TYPES_UPDATING_RESULT: type('[Envelope Types] Envelope Types updating state result'),
  PUT_ENVELOPE_TYPES_UPDATING_ERROR: type('[Envelope Types] Envelope Types updating state error'),
  PUT_ENVELOPE_TYPES_UPDATING_INIT: type('[Envelope Types] Envelope Types updating init'),

  PUT_ENVELOPE_TYPES_CREATING: type('[Envelope Types] Envelope Types creating state'),
  PUT_ENVELOPE_TYPES_CREATING_RESULT: type('[Envelope Types] Envelope Types creating state result'),
  PUT_ENVELOPE_TYPES_CREATING_ERROR: type('[Envelope Types] Envelope Types creating state error'),
  PUT_ENVELOPE_TYPES_CREATING_INIT: type('[Envelope Types] Envelope Types creating init')
};

export class LoadingEnvelopeTypes implements Action {
  type = ActionTypes.LOADING_ENVELOPE_TYPES;
  /**
   * Creates an instance of LoadingEnvelopeTypes.
   * @param {boolean} [payload]
   * @memberof LoadingEnvelopeTypes
   */
  constructor(public payload?: boolean) { }
}

export class PutEnvelopeTypes implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES;
  /**
   * Creates an instance of PutEnvelopeTypes.
   * @param {Array<EnvelopeTypes> | Array<any>} payload
   * @memberof PutEnvelopeTypes
   */
  constructor(public payload: Array<EnvelopeTypes> | Array<any>) { }
}

export class PutEnvelopeTypesById implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_BY_ID;
  /**
   * Creates an instance of PutEnvelopeTypes.
   * @param {EnvelopeTypes} payload
   * @memberof PutEnvelopeTypes
   */
  constructor(public payload: EnvelopeTypes ) { }
}

export class PutEnvelopeTypesError implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_ERROR;
  /**
   * Creates an instance of PutEnvelopeTypesError.
   * @param {Error} payload
   * @memberof PutEnvelopeTypesError
   */
  constructor(public payload: Error) { }
}

export class InitPutEnvelopeTypes implements Action {
  type = ActionTypes.INIT_ENVELOPE_TYPES;
  /**
   * Creates an instance of InitPutEnvelopeTypes.
   * @param {any} [payload]
   * @memberof InitPutEnvelopeTypes
   */
  constructor(public payload? ) { }
}


export class PutEnvelopeTypesTooglingState implements Action {
  type = ActionTypes.PUT_TOOGLING_STATE;
  /**
   * Creates an instance of PutEnvelopeTypesTooglingState.
   * @param {any} [payload]
   * @memberof PutEnvelopeTypesTooglingState
   */
  constructor(public payload? ) { }
}

export class PutEnvelopeTypesToogleStateResult implements Action {
  type = ActionTypes.PUT_TOOGLING_RESULT;
/**
 * Creates an instance of PutEnvelopeTypesToogleStateResult.
 * @param {Array<any>} payload
 * @memberof PutEnvelopeTypesToogleStateResult
 */
constructor(public payload: Array<any> ) { }
}

export class PutEnvelopeTypesToogleStateError implements Action {
  type = ActionTypes.PUT_TOOGLING_ERROR;
/**
 * Creates an instance of PutEnvelopeTypesToogleStateError.
 * @param {Error} payload
 * @memberof PutEnvelopeTypesToogleStateError
 */
constructor(public payload: Error ) { }
}

export class PutEnvelopeTypesToogleStateInit implements Action {
  type = ActionTypes.PUT_TOOGLING_INIT;
/**
 * Creates an instance of PutEnvelopeTypesToogleStateInit.
 * @param {any} [payload]
 * @memberof PutEnvelopeTypesToogleStateInit
 */
constructor(public payload? ) { }
}



export class PutEnvelopeTypesUpdating implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_UPDATING;
  /**
   * Creates an instance of PutEnvelopeTypesUpdating.
   * @param {any} [payload]
   * @memberof PutEnvelopeTypesUpdating
   */
  constructor(public payload? ) { }
}

export class PutEnvelopeTypesUpdatingResult implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_UPDATING_RESULT;
/**
 * Creates an instance of PutEnvelopeTypesUpdatingResult.
 * @param {Array<any>} payload
 * @memberof PutEnvelopeTypesUpdatingResult
 */
constructor(public payload: Array<any> ) { }
}

export class PutEnvelopeTypesUpdatingError implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_UPDATING_ERROR;
/**
 * Creates an instance of PutEnvelopeTypesUpdatingError.
 * @param {Error} payload
 * @memberof PutEnvelopeTypesUpdatingError
 */
constructor(public payload: Error) { }
}

export class PutEnvelopeTypesUpdatingInit implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_UPDATING_INIT;
/**
 * Creates an instance of PutEnvelopeTypesUpdatingInit.
 * @param {any} [payload]
 * @memberof PutEnvelopeTypesUpdatingInit
 */
constructor(public payload? ) { }
}


export class PutEnvelopeTypesCreating implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_CREATING;
  /**
   * Creates an instance of PutEnvelopeTypesCreating.
   * @param {any} [payload]
   * @memberof PutEnvelopeTypesCreating
   */
  constructor(public payload? ) { }
}

export class PutEnvelopeTypesCreatingResult implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_CREATING_RESULT;
/**
 * Creates an instance of PutEnvelopeTypesCreatingResult.
 * @param {Array<any>} payload
 * @memberof PutEnvelopeTypesCreatingResult
 */
constructor(public payload: Array<any> ) { }
}

export class PutEnvelopeTypesCreatingError implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_CREATING_ERROR;
/**
 * Creates an instance of PutEnvelopeTypesCreatingError.
 * @param {Error} payload
 * @memberof PutEnvelopeTypesCreatingError
 */
constructor(public payload: Error) { }
}

export class PutEnvelopeTypesCreatingInit implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_CREATING_INIT;
/**
 * Creates an instance of PutEnvelopeTypesCreatingInit.
 * @param {any} [payload]
 * @memberof PutEnvelopeTypesCreatingInit
 */
constructor(public payload? ) { }
}



export type Actions
= PutEnvelopeTypes
| PutEnvelopeTypesById
| LoadingEnvelopeTypes
| PutEnvelopeTypesError
| InitPutEnvelopeTypes
| PutEnvelopeTypesTooglingState
| PutEnvelopeTypesToogleStateResult
| PutEnvelopeTypesToogleStateError
| PutEnvelopeTypesToogleStateInit
| PutEnvelopeTypesUpdating
| PutEnvelopeTypesUpdatingError
| PutEnvelopeTypesUpdatingResult
| PutEnvelopeTypesUpdatingInit
| PutEnvelopeTypesCreating
| PutEnvelopeTypesCreatingResult
| PutEnvelopeTypesCreatingError
| PutEnvelopeTypesCreatingInit;
