export class Acl {
  aclId: string;
  isInstanceValue: boolean;
  name: string;
}

export class AclId {
  value: string;
  issuer: string;
  scheme: string;
  setValue: boolean;
  setIssuer: boolean;
  setScheme: boolean;
}

export class AccessControlEntry {
  principal: Array<string>;
  permission: string;
  grant: string;
  setPrincipal: boolean;
  setPermission: boolean;
  setGrant: boolean;
}

export class AccessControlList {
  aclId: AclId;
  creatnDate: string;
  accessControlEntry: AccessControlEntry;
  name: string;
  scope: string;
  setAclId: boolean;
  setCreatnDate: boolean;
  setName: boolean;
  setScope: boolean;
  setAccessControlEntry: boolean;
}

export class AclManagementClass {
  businessScope: Array<AccessControlList>;
  envType: Array<AccessControlList>;
  docType: Array<AccessControlList>;
  folderType: Array<AccessControlList>;
}
