
export class DocumentLite {
  id: string;
  name?: string;
  selected: boolean;
}

/**
 * "id": "string",
   "name": "string"
 */
