import { EnvelopeCreationResult } from './envelope-creation-result';

import { Error } from './error';

/**
 *
 * @param documentsList attribute, selected documents to be uploaded.
 * @param loading is uploading
 * @param error perform when the somethign wrong
 * @export
 * @class UploadDocuments
 *
 */
export class UploadDocuments {
  documentsList: Array<File>;
  loading: boolean;
  error: Error;
  errorPost: Error;
  result: Array<EnvelopeCreationResult>;
  uploaded: boolean;
}
