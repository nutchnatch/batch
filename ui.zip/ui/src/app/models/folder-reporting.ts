
export class FolderReporting {
  classId: string;
  classVersion: number;
  numberOfFolders: number;
}
