import { AssociatedTag } from './associated-tag';
import { DisplayNameItem } from './display-name-item';
import { AllowedChildren } from 'app/models/allowable-allowed-children';
import { Acl } from 'app/models/acl';

export class EnvelopeTypes {
  id: string;
  version: number;
  name: string;
  firstLevel: boolean;
  active: boolean;
  displayNameList: Array<DisplayNameItem>;
  tagList: Array<AssociatedTag>;
  allowedChildren: Array<AllowedChildren>;
  aclList: Array<Acl>;
}
