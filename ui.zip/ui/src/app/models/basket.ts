import { DisplayNameItem } from './display-name-item';

export class Basket {
  basketId: string;
  displayNameItem: Array<DisplayNameItem>;
  scope?: string;
  symbolicName: string;
}
