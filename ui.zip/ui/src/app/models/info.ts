export class Info {
  commercialVersion: string;
  technicalVersion: string;
}
