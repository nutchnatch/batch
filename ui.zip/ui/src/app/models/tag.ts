import { DisplayNameItem } from './display-name-item';
import { AllowableTagValue } from './allowable-tag-value';

/**
 *
 * @param choicelist attribute, used when type selected is choice list.
 * @param displayNameItem display name item
 * @param name Unique name (ID)
 * @param type Type of the tag = ['string', 'timestamp', 'boolean', 'integer', 'choicelist']
 * @export
 * @class Tag
 *
 */
export class Tag {
  choicelist: Array<AllowableTagValue>;
  displayNameItem: Array<DisplayNameItem>;
  name: string;
  type: string;
  id: string;
  pattern: string;
  isSearchable: boolean;
}

export class TagClone {
  tagName: string;
  tagValue: string;
}
