export class Task {
  basketId: string;
  creationDate: string;
  docId: string;
  lockName: string;
  name: string;
  scope: string;
  status: string;
  taskId: string;
  updateDate: string;
}

