import { TagElement } from './tag-element';
/**
 *
 *
 * @export
 * @class Envelope
 */
export class Envelope {
  confidentiality: string;
  creationDate: string;
  envTypeId: string;
  envTypeVersion: string;
  envTypeSymbolicName: string;
  envelopeStatus: string;
  id: string;
  listOfDocumentId: Array<string>;
  tagList: Array<TagElement>;
  updatingDate: string;
  validity: string;
}
