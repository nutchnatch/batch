export class DocumentIdentifier  {
  docViewURL: string;
  id: string;
  name: string;
}
