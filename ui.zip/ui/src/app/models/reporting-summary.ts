export class ReportSummary {
    numberOfDocuments: number;
    numberOfEnvelopes: number;
    numberOfFolders: number;
    numberOfTasks: number;
}
