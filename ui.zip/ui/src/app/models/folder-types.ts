import { AssociatedTag } from './associated-tag';
import { DisplayNameItem } from './display-name-item';
import { Acl } from 'app/models/acl';

export class FolderTypes {
  id: string;
  version: number;
  name: string;
  type: string;
  displayNameList: Array<DisplayNameItem>;
  tagList: Array<AssociatedTag>;
  active: boolean;
  retentionDurationValue: number;
  retentionDurationUnit: string;
  aclList: Array<Acl>;
}
