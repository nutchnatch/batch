
export class Breadcrumb {
  links: Link[];
}

export class Link {
  path?: string;
  href?: string;
  label: string;
}

