export interface Credentials {
  username: string | number;
  password: string;
}
