
export class Config {
  changePasswordUrl: string;
}
