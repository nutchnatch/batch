export class DocumentAttachedToFoldersResult {
  documentIdArray: Array<string>;
  folderId: string;
}
