
export class DocumentReporting {
  classId: string;
  classVersion: number;
  numberOfDocuments: number;
  sizeOfFiles: number;
}
