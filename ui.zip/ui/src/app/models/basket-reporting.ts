
export class BasketReporting {
  basketId: string;
  numberOfClosed: number;
  numberOfOpened: number;
}
