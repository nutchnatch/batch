/**
 *
 *
 * @export
 * @class DocumentCreationResult
 */
export class DocumentCreationResult {
  envelopeId: string;
  documentId: string;
}
