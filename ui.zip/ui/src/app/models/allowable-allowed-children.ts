
export class AllowedChildren {
  id: string;
  symbolicName: string;
  version: number;
}
