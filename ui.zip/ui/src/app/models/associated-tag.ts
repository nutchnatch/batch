export class AssociatedTag {
  mandatory: boolean;
  multivalued: boolean;
  symbolicName: string;
}
