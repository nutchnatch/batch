import { DocumentIdentifier } from './document-identifier';
import { DisplayNameItem } from './display-name-item';
import { Acl } from 'app/models/acl';

export class BusinessScope {
  basketRuleFile: DocumentIdentifier;
  businessScopeId: string;
  creationDate: string;
  defaultDocumentType: string;
  defaultEnvelopeType: string;
  defaultFolderType: string;
  defaultRetentionDate: string; //  ['NOT_CURRENT_DATE', 'CURRENT_DATE'],
  description: Array<DisplayNameItem>;
  encryptionIdentifier: string;
  availableEncryptionIdentifiers: Array<string>;
  languages: Array<string>;
  organizationalUnit: string;
  preferredLanguages: Array<string>;
  symbolicName: string;
  displayName: Array<any>;
  aclList: Array<Acl>;
}


