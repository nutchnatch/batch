import { AssociatedTag } from './associated-tag';
import { DisplayNameItem } from './display-name-item';
import { Acl } from 'app/models/acl';

export class DocumentTypes {
  displayNameList: Array<DisplayNameItem>;
  id: string;
  name: string;
  tagList: Array<AssociatedTag>;
  version: number;
  active: boolean;
  retentionDurationUnit: string;
  retentionDurationValue: string;
  aclList: Array<Acl>;
}
