
export class EnvelopeReporting {
  classId: string;
  classVersion: number;
  directionCode: string;
  numberOfDocuments: number;
  numberOfEnvelopes: number;
  sizeOfDocuments: number;
}
