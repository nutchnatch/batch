import { PutUpdatingBusinessScopeRuleFileResults } from './../actions/business-scope.actions';
import { Acl } from 'app/models/acl';
import { BusinessScopeService } from './../services/business-scope.service';
// import { PutUpdateBasketError } from './../actions/baskets.actions';
// import { BasketCreationResult } from './../models/basket-creation-result';
import { RestResponse } from './../models/rest-response';
import { Error } from 'app/models/error';
import { LoggerService } from 'app/services/logger/logger.service';
import { Store, select } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as businessScopeAction from '../actions/business-scope.actions';
import * as httpErrorAction from '../actions/http-error.actions';

import { Injectable } from '@angular/core';
import { BusinessScope } from 'app/models/business-scope';
import * as aclManagementAction from '../actions/acl-management.actions';

/**
 * This Class is the Sample Controler Store/{@link BasketService}
 * @export
 * @class SampleEffect
 */
@Injectable()
export class BusinessScopeEffect {

  constructor(
    public businessScopeService: BusinessScopeService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

  }

  /**
   * Get Business Scope
   *
   * Get List from the Store, if not exist, call the {@link BusinessScopeService}
   * also change set loading = true, on sample state
   *
   */
  getBusinessScope(): any {

    this.logger.debug('BusinessScopeEffect', 'getBusinessScope()');
    this.store.dispatch(new businessScopeAction.LoadingBusinessScope(true));

    this.businessScopeService.getBusinessScope()
      .subscribe(
      (resp: any) => {
        this.logger.debug('BusinessScopeEffect', 'getBusinessScope success with result: ', resp);
        this.store.dispatch(new businessScopeAction.PutBusinessScopeResults(resp['result']));
      },
      (error: Error) => {
        this.logger.error('BusinessScopeEffect', 'getBusinessScope error!! ', error);
        this.errorToGlobalState(error, 'get');
      }
      );
  }

  putBusinessScopeById(scopeName: string, body: BusinessScope): any {

    this.logger.debug('BusinessScopeEffect', 'putBusinessScopeById() with ', { scopeName: scopeName, body: body });
    this.store.dispatch(new businessScopeAction.PutUpdatingBusinessScope(true));
    this.businessScopeService.putBusinessScopeById(scopeName, body)
      .subscribe(
      (resp: RestResponse<BusinessScope>) => {
        this.logger.debug('BusinessScopeEffect', 'putBusinessScopeById success with result: ', resp);
        this.store.dispatch(new businessScopeAction.PutUpdatingBusinessScopeResults(resp.result));
      },
      (error: Error) => {
        this.logger.error('BusinessScopeEffect', 'putBusinessScopeById error!! ', error);
        this.errorToGlobalState(error, 'put');
      }
      );
  }

  /**
   *
   *
   * @param {string} businessScopeId
   * @returns {*}
   * @memberof BusinessScopeEffect
   */
  getAclBusinessScope(businessScopeId: string ): any {

    this.logger.debug('BusinessScopeEffect', 'getAclBusinessScope() with ', { businessScopeId: businessScopeId });
    this.store.dispatch(new businessScopeAction.PutUpdatingBusinessScope(true));

    this.businessScopeService.getAclBusinessScope(businessScopeId)
      .subscribe(
      (resp: RestResponse<Acl>) => {
        this.logger.debug('BusinessScopeEffect', 'putBusinessScopeById success with result: ', resp);
        // this.store.dispatch(new businessScopeAction.PutUpdatingBusinessScopeResults(resp.result));
      },
      (error: Error) => {
        this.logger.error('BusinessScopeEffect', 'putBusinessScopeById error!! ', error);
        this.errorToGlobalState(error, 'put-acl');
      }
      );
  }

  putRuleFileBusinessScope(body ): any {

    this.logger.debug('BusinessScopeEffect', 'putRuleFileBusinessScope()');
    this.store.dispatch(new businessScopeAction.PutUpdatingBusinessScope(true));

    this.businessScopeService.putRuleFileBusinessScope(body)
      .subscribe(
      (resp: RestResponse<BusinessScope>) => {
        this.logger.debug('BusinessScopeEffect', 'putBusinessScopeById success with result: ', resp);
        this.store.dispatch(new businessScopeAction.PutUpdatingBusinessScopeRuleFileResults(resp.result));
      },
      (error: Error) => {
        this.logger.error('BusinessScopeEffect', 'putBusinessScopeById error!! ', error);
        this.errorToGlobalState(error, 'put-acl');
      }
      );
  }

  putBusinessScopeAcl(businessScopeId: string, body ): any {

    this.logger.debug('BusinessScopeEffect', 'putBusinessScopeAcl() with ', { businessScopeId: businessScopeId });
    this.store.dispatch(new aclManagementAction.PutUpdateLoadingAclManagementAction(true));
    this.store.dispatch(new aclManagementAction.PutIdUpdateAclManagementAction(businessScopeId));

    this.businessScopeService.putBusinessScopeAcl(businessScopeId, body)
      .subscribe(
      (resp: RestResponse<BusinessScope> | any) => {
        this.logger.debug('BusinessScopeEffect', 'putBusinessScopeAcl success with result: ', resp);
        this.store.dispatch(new aclManagementAction.PutResultUpdateAclManagementAction(resp));

      },
      (error: Error) => {
        this.logger.error('BusinessScopeEffect', 'putBusinessScopeAcl error!! ', error);
        this.errorToGlobalState(error, 'acl');
      }
      );
  }



  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf BusinessScopeEffect
   */
  public errorToGlobalState(error: Error | any, store: string) {
    this.logger.error('BusinessScopeEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('BusinessScopeEffect', 'Dispatch Scope Error to Store', error);
      // tslint:disable-next-line:max-line-length
      // search ? this.store.dispatch(new searchPagedAction.PutSearchResultsError(error)) : this.store.dispatch(new basketAction.PutUpdateBasketError(error));
      if ( store === 'post') { }
      if ( store === 'put') { this.store.dispatch(new businessScopeAction.PutUpdatingBusinessScopeError(error)); }
      if ( store === 'put-acl') { this.store.dispatch(new businessScopeAction.PutUpdatingBusinessScopeError(error)); }
      if ( store === 'acl') { this.store.dispatch(new aclManagementAction.PutErrorUpdateAclManagementAction(error)); }
    } else {
      this.logger.debug('BusinessScopeEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      // this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));

    }

  }
}
