import { RestResponse } from './../models/rest-response';
import { TagsService } from './../services/tags.services';
import { LoggerService } from 'app/services/logger/logger.service';
import { Error } from 'app/models/error';


import { Store } from '@ngrx/store';

import * as fromRoot from '../reducers';
// import * as infoAction from '../actions/info.actions';
import * as tagAction from '../actions/tag.actions';
import * as httpErrorAction from '../actions/http-error.actions';

import { Injectable } from '@angular/core';
import { Tag } from 'app/models/tag';

/**
 * This Class is the Sample Controler Store/{@link InfoService}
 * @export
 * @class TagsEffect
 */
@Injectable()
export class TagsEffect {

  // public actionMethod: string;

  constructor(
    public tagService: TagsService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

  }

  /**
   *
   *
   * @param {string} id
   * @param {Tag} body
   * @returns {*}
   * @memberof TagsEffect
   */
  putTagsById(id: string, body: Tag): any {

    this.logger.debug('TagsEffect', 'putTagsById()', { id: id, body: body });
    this.store.dispatch(new tagAction.UpdatingTag(true));

    this.tagService.putTagsById(id, body)
      .subscribe(
        (resp: RestResponse<Array<Tag>>) => {
          this.logger.debug('TagsEffect', 'putTagsById success with result: ', resp);
          this.store.dispatch(new tagAction.UpdatingTagSuccess(resp[0]));
        },
        (error: Error) => {
          this.logger.error('TagsEffect', 'putTagsById error!! ', error);
          this.errorToGlobalState(error, 'put');
        }
      );
  }

  /**
   *
   *
   * @param {string} id
   * @param {Tag} body
   * @returns {*}
   * @memberof TagsEffect
   */
  postTags(body: Tag): any {

    this.logger.debug('TagsEffect', 'postTags()', { body: body });
    this.store.dispatch(new tagAction.CreatingTag(true));

    this.tagService.postTags(body)
      .subscribe(
        (resp: any | Array<Tag> ) => {
          this.logger.debug('TagsEffect', 'postTags success with result: ', resp);
          this.store.dispatch(new tagAction.CreateTagSuccess(resp[0]));
        },
        (error: Error) => {
          this.logger.error('TagsEffect', 'postTags error!! ', error);
          this.errorToGlobalState(error, 'post');
        }
      );
  }


  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf InfoEffect
   */
  public errorToGlobalState(error: Error | any, store: string) {
    this.logger.error('InfoEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('InfoEffect', 'Dispatch Scope Error to Store');
      // tslint:disable-next-line:max-line-length
      // this.store.dispatch(new infoAction(error));

      if (store === 'put') { this.store.dispatch(new tagAction.UpdatingTagError(error)); }
      if (store === 'post') { this.store.dispatch(new tagAction.CreateTagError(error)); }

    } else {
      this.logger.debug('InfoEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      // this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));

    }

  }
}
