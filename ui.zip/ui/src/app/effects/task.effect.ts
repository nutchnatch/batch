import { RestResponse } from './../models/rest-response';
// import { QueryParams } from 'app/models/paged';
import { Error } from 'app/models/error';
import { LoggerService } from 'app/services/logger/logger.service';

import { TaskService } from 'app/services/task.service';

import { Store } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as taskAction from '../actions/task.actions';
import * as httpErrorAction from '../actions/http-error.actions';
// import * as searchPagedAction from '../actions/search-paged.actions';

import { Injectable } from '@angular/core';

/**
 * This Class is the Sample Controler Store/{@link TaskService}
 * @export
 * @class SampleEffect
 */
@Injectable()
export class TaskEffect {

  // public actionMethod: string;
  // public query$: Observable<QueryParams>;
  // query: QueryParams;

  constructor(
    public taskService: TaskService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

    // this.query$ =store.pipe(select(fromRoot.getSearchPagedQuery);
    // this.query$.subscribe((q) => this.query = q);
  }

  /**
* Get Task by id
*
* Get List from the Store, if not exist, call the {@link TaskService}
* also change set loading = true, on sample state
*
*/
  getTasksById(id: string): any {

    this.logger.debug('TaskEffect', 'getTasksById() with id: ', id);
    this.store.dispatch(new taskAction.LoadingTask());

    this.taskService.getTasksById(id)
      .subscribe(
      (resp: any) => {
        this.logger.debug('TaskEffect', 'getTasksById success with result: ', resp);
        this.store.dispatch(new taskAction.PutTaskResults(resp.result[0]));
        // this.store.dispatch(new searchPagedAction.PutSearchResultsSearchPaged(resp));

      },
      (error: Error) => {
        this.logger.error('TaskEffect', 'getTasksById error!! ', error);
        this.errorToGlobalState(error, 'get');
      }
      );
  }

  putTaskByIdTransfer(fromId: string, toId: string): any {

    this.logger.debug('TaskEffect', 'putTaskByIdTransfer() with ', { formId: fromId, toId: toId });
    this.store.dispatch(new taskAction.LoadingTaskTransfer());

    this.taskService.putTaskByIdTransfer(fromId, toId)
      .subscribe(
      (resp: RestResponse<string>) => {
        this.logger.debug('TaskEffect', 'putTaskByIdTransfer success with result: ', resp);
        this.store.dispatch(new taskAction.PutTransferTask(resp.result[0]) );
      },
      (error: Error) => {
        this.logger.error('TaskEffect', 'putTaskByIdTransfer error!! ', error);
        // this.errorToGlobalState(error, true);
        this.errorToGlobalState(error, 'transfer');
      }
      );
  }

  putTaskByIdStatus(id: string, status: string): any {

    this.logger.debug('TaskEffect', 'putTaskByIdStatus() with ', { id: id, status: status });
    this.store.dispatch(new taskAction.LoadingTaskStatus());

    this.taskService.putTaskByIdStatus(id, status)
      .subscribe(
      (resp: RestResponse<string>) => {
        this.logger.debug('TaskEffect', 'putTaskByIdStatus success with result: ', resp);
        this.store.dispatch(new taskAction.PutStatusTask(resp.result[0]) );
      },
      (error: Error) => {
        this.logger.error('TaskEffect', 'putTaskByIdStatus error!! ', error);
        this.errorToGlobalState(error, 'status');
      }
      );
  }

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf TaskEffect
   */
  public errorToGlobalState(error: Error | any, store?: string) {
    this.logger.error('TaskEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('TaskEffect', 'Dispatch Scope Error to Store', error);

      this.errorDispacher(error, store);
    } else {
      this.logger.debug('TaskEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      // this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));

      // this.store.dispatch(new taskAction.PutTaskError(error)) ;
      // if( transfer) { this.store.dispatch(new taskAction.PutUpdateTaskTransferError(error)); }
    }

  }

  errorDispacher(error, store) {
    switch (store) {
      case 'get':
        this.store.dispatch(new taskAction.PutTaskError(error));
        break;
      case 'transfer':
        this.store.dispatch(new taskAction.PutUpdateTaskTransferError(error));
        break;
      case 'status':
      this.store.dispatch(new taskAction.PutUpdateTaskStatusError(error));
        break;
      default:
        this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
    }
  }

}
