import { BasketService } from 'app/services/basket.service';
import { EnvelopeTypeService } from './../services/envelope-type.service';
import { FolderTypesService } from './../services/folder-types.service';
import { TagsService } from './../services/tags.services';
import { AclService } from '../services/acl.service';
import { Injectable } from '@angular/core';
import { forkJoin } from 'rxjs';
import { DocumentTypeService } from 'app/services/document-type.service';
import { LoggerService } from 'app/services/logger/logger.service';
import { Store } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as documentTypeAction from '../actions/document-types.actions';
import * as tagAction from '../actions/tag.actions';
import * as envelopeTypeAction from '../actions/envelope-types.actions';
import * as folderTypeAction from '../actions/folder-types.actions';
import * as extraFieldAction from '../actions/extra-fields.actions';
import * as aclAction from '../actions/acl.actions';
import * as basketAction from '../actions/basket.actions';
import * as businessScopeAction from '../actions/business-scope.actions';


@Injectable()
export class DocumentTypesAndTagsEffect {

  constructor(
    public documentTypeService: DocumentTypeService,
    public envelopeTypeService: EnvelopeTypeService,
    public folderTypesService: FolderTypesService,
    public tagsService: TagsService,
    public aclServices: AclService,
    public basketServices: BasketService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

  }

  getDocumentAndTagsTypes(): any {

    this.logger.debug('DocumentTypesAndTagsEffect', 'getDocumentAndTagsTypes()');

    this.store.dispatch(new documentTypeAction.LoadingDocumentTypes());
    this.store.dispatch(new tagAction.LoadingTag());
    this.store.dispatch(new envelopeTypeAction.LoadingEnvelopeTypes());
    this.store.dispatch(new folderTypeAction.LoadingFolderTypes());
    this.store.dispatch(new aclAction.PutLoadingAclAction(true));
    this.store.dispatch(new basketAction.LoadingBasket(true));

    // const types = this.documentTypeService.getDocumentsTypes(true).map(res => res);
    // const tags = this.tagsService.getTags().map(res => res);
    // const envelopeType = this.envelopeTypeService.getEnvelopeTypes(true).map(res => res);
    // const folderTypes = this.folderTypesService.getFolderTypes(true).map(res => res);
    // const acl = this.aclServices.getAcl().map(res => res);
    // const basket = this.basketServices.getBaskets().map(res => res);


    forkJoin(
      this.documentTypeService.getDocumentsTypes(true),
      this.tagsService.getTags(),
      this.envelopeTypeService.getEnvelopeTypes(true),
      this.folderTypesService.getFolderTypes(true),
      this.aclServices.getAcl(),
      this.basketServices.getBaskets()
    )

      .subscribe(([types, tags, envelopeType, folderTypes, acl, basket]) => {
        // tslint:disable-next-line:max-line-length
        this.logger.debug('DocumentTypesAndTagsEffect', 'getDocumentAndTagsTypes() success with result: ', [types, tags, envelopeType, folderTypes, acl, basket]);

        this.store.dispatch(new documentTypeAction.PutDocumentTypes(types));
        this.store.dispatch(new tagAction.PutTag(tags));
        this.store.dispatch(new envelopeTypeAction.PutEnvelopeTypes(envelopeType));
        this.store.dispatch(new folderTypeAction.PutFolderTypes(folderTypes));
        this.store.dispatch(new aclAction.PutAclAction(acl));
        this.store.dispatch(new basketAction.PutBasketResults(basket));

        this.store.dispatch(new extraFieldAction.PutExtraFields({ tags: tags, documentType: types }));
        this.store.dispatch(new extraFieldAction.PutEnvelopeExtraFields({ tags: tags, envelopeType: envelopeType }));
        this.store.dispatch(new extraFieldAction.PutFolderExtraFields({ tags: tags, folderType: folderTypes }));

      },
      (error: Error) => {
        this.logger.error('DocumentTypesAndTagsEffect', 'getDocumentAndTagsTypes() error!! ', error);
        // this.errorToGlobalState(error);
        // this.store.dispatch( new documentTypeAction.PutDocumentTypes( error[0].result ));
        // this.store.dispatch( new tagAction.PutTag( error[1].result ))
      },
      () => {
        this.store.dispatch( new businessScopeAction.AllLoadedBusinessScope(true) );

      });
  }

}
