import { ApplicationService } from '../services/application.services';
import { LoggerService } from 'app/services/logger/logger.service';
import { Error } from 'app/models/error';
import { forkJoin } from 'rxjs';
import { Store, select } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as infoAction from '../actions/info.actions';
import * as httpErrorAction from '../actions/http-error.actions';

import { Injectable } from '@angular/core';

/**
 * This Class is the Sample Controler Store/{@link InfoService}
 * @export
 * @class InfoEffect
 */
@Injectable()
export class InfoEffect {

  // public actionMethod: string;

  constructor(
    public applicationService: ApplicationService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

  }

  getApplicationConfigInfo(): any {
    this.logger.debug('ApplicationEffect', 'getApplicationConfigInfo()');

    forkJoin(
      this.applicationService.getInfoVersion(),
      this.applicationService.getConfig()
    ).subscribe(([info, config]) => {
      this.logger.debug('ApplicationEffect', 'getApplicationConfigInfo success with result: ', [info, config]);
      this.store.dispatch(new infoAction.PutInfoVersionAction(info));
      this.store.dispatch(new infoAction.PutConfigAction(config));
    });
  }


  /**
   * Get App builded Version
   *
   * Get App Version {@link InfoService}
   *
   */
  getInfoVersion(): any {

    this.logger.debug('InfoEffect', 'getInfoVersion()');
    this.store.dispatch(new infoAction.LoadinInfoAction());

    this.applicationService.getInfoVersion()
      .subscribe(
        (resp: any) => {
          this.logger.debug('InfoEffect', 'getInfoVersion success with result: ', resp);
          this.store.dispatch(new infoAction.PutInfoVersionAction(resp));
        },
        (error: Error) => {
          this.logger.error('InfoEffect', 'getInfoVersion error!! ', error);
          this.errorToGlobalState(error);
        }
      );
  }


  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf InfoEffect
   */
  public errorToGlobalState(error: Error | any ) {
    this.logger.error('InfoEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('InfoEffect', 'Dispatch Scope Error to Store');
      // tslint:disable-next-line:max-line-length
      // this.store.dispatch(new infoAction(error));
    } else {
      this.logger.debug('InfoEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      // this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));

    }

  }
}
