import { Subscription } from 'rxjs';
import { EnvelopeTypes } from 'app/models/envelope-types';
import { EnvelopeTypeService } from './../services/envelope-type.service';
import { RestResponse } from './../models/rest-response';
import { Error } from 'app/models/error';
import { LoggerService } from 'app/services/logger/logger.service';

import { Observable } from 'rxjs';

import { Store, select } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as envelopeTypesAction from '../actions/envelope-types.actions';
import * as httpErrorAction from '../actions/http-error.actions';
import * as aclManagementAction from '../actions/acl-management.actions';

import { Injectable } from '@angular/core';


/**
 * This Class is the Sample Controler Store/{@link EnvelopeTypeService}
 * @export
 * @class EnvelopeTypeEffect
 */
@Injectable()
export class EnvelopeTypeEffect {

  public envelopeTypes$: Observable<Array<EnvelopeTypes>>;
  public subsciberEnvelopeType: Subscription;

  envTypes: Array<EnvelopeTypes>;

  constructor(
    public envelopeTypesServices: EnvelopeTypeService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

    this.envelopeTypes$ = store.pipe(select(fromRoot.getEnvelopeTypesResult));
    this.subsciberEnvelopeType = this.envelopeTypes$.subscribe(envTypes => {
      this.envTypes = envTypes;
    });

  }


  /**
   *
   *
   * @param {string} id
   * @param {number} version
   * @returns {(any | EnvelopeTypes)}
   * @memberof EnvelopeTypeEffect
   */
  getEnvelopeTypeById(id: string, version: number): any | EnvelopeTypes {

    this.logger.debug('EnvelopeTypeEffect', 'getEnvelopeTypeById() with id ($1) and version ($2): ', { $1: id, $2: version });
    // this.store.dispatch(new envelopeTypesAction.LoadingEnvelopeTypes());


    this.envelopeTypesServices.getEnvelopeTypesById(id, version)
      .subscribe(
        (resp: any) => {
          this.logger.debug('EnvelopeTypeEffect', 'getEnvelopeTypeById success with result: ', resp);
          this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesById(resp.result[0]));
        },
        (error: Error) => {
          this.logger.error('EnvelopeTypeEffect', 'getEnvelopeTypeById error!! ', error);
          this.errorToGlobalState(error, 'get');
        }
      );
  }

  /**
 *
 *
 * @param {string} id
 * @param {number} version
 * @returns {(any | EnvelopeTypes)}
 * @memberof EnvelopeTypeEffect
 */
  putEnvelopeTypeById(id: string, version: number, body: FormData): any | EnvelopeTypes {

    this.logger.debug('EnvelopeTypeEffect', 'putEnvelopeTypeById() with id ($1) and version ($2): ', { $1: id, $2: version });
    this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesUpdating(true));
    this.envelopeTypesServices.putEnvelopeTypesById(id, version, body)
      .subscribe(
        (resp: RestResponse<EnvelopeTypes> | any) => {
          this.logger.debug('EnvelopeTypeEffect', 'putEnvelopeTypeById success with result: ', resp);
          this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesUpdatingResult(resp[0]));
        },
        (error: Error) => {
          this.logger.error('EnvelopeTypeEffect', 'putEnvelopeTypeById error!! ', error);
          this.errorToGlobalState(error, 'updating');
        }
      );
  }

  /**
   *
   *
   * @param {string} id
   * @param {number} version
   * @returns {(any | EnvelopeTypes)}
   * @memberof EnvelopeTypeEffect
   */
  putEnvelopeTypesActivate(id: string, version: number): any | EnvelopeTypes {

    this.logger.debug('EnvelopeTypeEffect', 'putEnvelopeTypesActivate() with id ($1) and version ($2): ', { $1: id, $2: version });
    this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesTooglingState({ loading: true, id: id }));
    this.envelopeTypesServices.putEnvelopeTypesActivate(id, version)
      .subscribe(
        (resp: RestResponse<EnvelopeTypes> | any) => {
          this.logger.debug('EnvelopeTypeEffect', 'putEnvelopeTypesActivate success with result: ', resp);
          this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesToogleStateResult(resp));
        },
        (error: Error) => {
          this.logger.error('EnvelopeTypeEffect', 'putEnvelopeTypesActivate error!! ', error);
          this.errorToGlobalState(error, 'toogle');
        }
      );
  }

  /**
 *
 *
 * @param {string} id
 * @param {number} version
 * @returns {(any | EnvelopeTypes)}
 * @memberof EnvelopeTypeEffect
 */
  putEnvelopeTypesDeactivate(id: string, version: number): any | EnvelopeTypes {

    this.logger.debug('EnvelopeTypeEffect', 'putEnvelopeTypesDeactivate() with id ($1) and version ($2): ', { $1: id, $2: version });
    this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesTooglingState({ loading: true, id: id }));

    this.envelopeTypesServices.putEnvelopeTypesDeactivate(id, version)
      .subscribe(
        (resp: RestResponse<EnvelopeTypes> | any) => {
          this.logger.debug('EnvelopeTypeEffect', 'putEnvelopeTypesDeactivate success with result: ', resp);
          this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesToogleStateResult(resp));
        },
        (error: Error) => {
          this.logger.error('EnvelopeTypeEffect', 'putEnvelopeTypesDeactivate error!! ', error);
          this.errorToGlobalState(error, 'toogle');
        }
      );
  }

  postEnvelopeTypes(body: EnvelopeTypes): any | EnvelopeTypes {

    this.logger.debug('EnvelopeTypeEffect', 'postEnvelopeTypes() body: ', body);
    this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesCreating(true));

    this.envelopeTypesServices.postEnvelopeTypes(body)
      .subscribe(
        (resp: RestResponse<EnvelopeTypes> | any) => {
          this.logger.debug('EnvelopeTypeEffect', 'postEnvelopeTypes success with result: ', resp);
          this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesCreatingResult(resp));
        },
        (error: Error) => {
          this.logger.error('EnvelopeTypeEffect', 'postEnvelopeTypes error!! ', error);
          this.errorToGlobalState(error, 'post');
        }
      );
  }
  /**
   *
   *
   * @param {string} id
   * @param {number} version
   * @param {*} body
   * @returns {*}
   * @memberof EnvelopeTypeEffect
   */
  putEnvelopeTypesAcl(id: string, version: number, body: any): any {

    this.logger.debug('EnvelopeTypeEffect', 'putEnvelopeTypesAcl()', { 'id': id, 'version': version, body: body });
    this.store.dispatch(new aclManagementAction.PutUpdateLoadingAclManagementAction(true));
    this.store.dispatch(new aclManagementAction.PutIdUpdateAclManagementAction(id));

    this.envelopeTypesServices.putEnvelopeTypesAcl(id, version, body)
      .subscribe(
        (resp: any) => {
          this.logger.debug('EnvelopeTypeEffect', 'putEnvelopeTypesAcl success with result: ', resp);
          this.store.dispatch(new aclManagementAction.PutResultUpdateAclManagementAction(resp));
        },
        (error: Error) => {
          this.logger.error('EnvelopeTypeEffect', 'putEnvelopeTypesAcl error!! ', error);
          this.errorToGlobalState(error, 'acl');
        }
      );
  }

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf DocumentEffect
   */
  public errorToGlobalState(error: Error | any, store: string) {
    this.logger.error('EnvelopeTypeEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('EnvelopeTypeEffect', 'Dispatch Scope Error to Store');
      // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
      this.errorDispacher(error, store);

    } else {
      this.logger.debug('EnvelopeTypeEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      // this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));

    }

  }

  errorDispacher(error, store) {
    switch (store) {
      case 'toogle':
        this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesToogleStateError(error));
        break;
      case 'updating':
        this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesUpdatingError(error));
        break;
      case 'get':
        this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesError(error));
        break;
      case 'post':
        this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesCreatingError(error));
        break;
      case 'acl':
        this.store.dispatch(new aclManagementAction.PutErrorUpdateAclManagementAction(error));
        break;
      default:
        this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesError(error));
    }
  }
}
