import { DocumentCreationResult } from './../models/document-creation-result';
import { RestResponse } from './../models/rest-response';
import { QueryParams } from 'app/models/paged';
import { Error } from 'app/models/error';
import { Document } from 'app/models/document';
import { LoggerService } from 'app/services/logger/logger.service';

import { Observable } from 'rxjs';
import { DocumentService } from 'app/services/document.service';

import { Store, select } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as searchPagedAction from '../actions/search-paged.actions';
import * as documentAction from '../actions/documents.actions';
import * as httpErrorAction from '../actions/http-error.actions';

import { Injectable } from '@angular/core';
import { Subscription } from 'rxjs';

/**
 * This Class is the Sample Controler Store/{@link DocumentService}
 * @export
 * @class SampleEffect
 */
@Injectable()
export class DocumentEffect {

  // public actionMethod: string;
  public query$: Observable<QueryParams>;
  query: QueryParams;

  public s$: Subscription;

  constructor(
    public documentService: DocumentService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

    this.query$ = store.pipe(select(fromRoot.getSearchPagedQuery));
    this.query$.subscribe((q) => this.query = q);
  }

  /**
   * Get Document List
   *
   * Get List from the Store, if not exist, call the {@link DocumentService}
   * also change set loading = true, on sample state
   *
   */
  getDocuments(params: QueryParams): Subscription {

    // this.killSubscription();

    this.logger.debug('DocumentEffect', 'getDocuments() with this params: ', params);
    this.store.dispatch(new searchPagedAction.SearchingSearchPaged());

    return this.documentService.getDocuments(params)
      .subscribe(
        (resp: any) => {
          this.logger.debug('DocumentEffect', 'getDocuments success with result: ', resp);
          this.store.dispatch(new searchPagedAction.PutSearchResultsSearchPaged(resp));
          this.store.dispatch(new searchPagedAction.PutSearchResultsTypeResult('documents'));

        },
        (error: Error) => {
          this.logger.error('DocumentEffect', 'getDocuments error!! ', error);
          this.errorToGlobalState(error, true);
        }
      );
  }
  /**
 * Get Document by id
 *
 * Get List from the Store, if not exist, call the {@link DocumentService}
 * also change set loading = true, on sample state
 *
 */
  getDocumentsById(id: string,  showLoading: boolean = true): Subscription {

    // this.killSubscription();

    this.logger.debug('DocumentEffect', 'getDocumentsById() with id: ', id);

    if ( showLoading ) { this.store.dispatch(new documentAction.LoadingDocument()); }
    return this.documentService.getDocumentsById(id)
      .subscribe(
        (resp: RestResponse<Document>) => {
          this.logger.debug('DocumentEffect', 'getDocumentsById success with result: ', resp);
          this.store.dispatch(new documentAction.PutDocument(resp.result[0]));
        },
        (error: Error) => {
          this.logger.error('DocumentEffect', 'getDocumentsById error!! ', error);
          this.errorToGlobalState(error, true);
        }
      );
  }

  /**
* Get Document by id
*
* Get List from the Store, if not exist, call the {@link DocumentService}
* also change set loading = true, on sample state
*
*/
  putDocumentsById(id: string, body: Document): Subscription {

    // this.killSubscription();

    this.logger.debug('DocumentEffect', 'putDocumentsById() with ', { id: id, body: body });
    this.store.dispatch(new documentAction.UpdatingDocument());

    return this.documentService.putDocumentsById(id, body)
      .subscribe(
        (resp: RestResponse<DocumentCreationResult>) => {
          this.logger.debug('DocumentEffect', 'putDocumentsById success with result: ', resp);
          this.store.dispatch(new documentAction.PutUpdateDocument(resp.result[0]));
        },
        (error: Error) => {
          this.logger.error('DocumentEffect', 'putDocumentsById error!! ', error);
          this.errorToGlobalState(error);
        }
      );
  }

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf DocumentEffect
   */
  public errorToGlobalState(error: Error | any, search?: boolean) {
    this.logger.error('DocumentEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);

    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 500 || error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('DocumentEffect', 'Dispatch Scope Error to Store', error);
      // tslint:disable-next-line:max-line-length
      search ? this.store.dispatch(new searchPagedAction.PutSearchResultsError(error)) : this.store.dispatch(new documentAction.PutUpdateDocumentError(error));
    } else {
      this.logger.debug('DocumentEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      // tslint:disable-next-line:max-line-length
      if (search) {
        if (error.code === '401' || error.code === 401 ) {
          this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
        } else {
          this.store.dispatch(new searchPagedAction.PutSearchResultsError(error instanceof  Error ? error : error.json()));
        }
      } else {
          // this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
          this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));

      }

    }

  }
}
