import { RestResponse } from './../models/rest-response';
import { QueryParams } from 'app/models/paged';
import { Envelope } from './../models/envelope';
import { EnvelopesService } from './../services/envelopes.service';
import { Error } from 'app/models/error';
import { LoggerService } from 'app/services/logger/logger.service';

import { Observable } from 'rxjs';

import { Store, select } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as httpErrorAction from '../actions/http-error.actions';
import * as envelopeAction from '../actions/envelope.actions';
import * as searchPagedAction from '../actions/search-paged.actions';
import * as uploadDocumentsAction from 'app/actions/upload-documents.actions';

import { Injectable } from '@angular/core';
import { EnvelopeCreationResult } from 'app/models/envelope-creation-result';
import { Subscription } from 'rxjs';

/**
 *
 *
 * @export
 * @class EnvelopeEffect
 */
@Injectable()
export class EnvelopeEffect {


  envelopeState$: Observable<Envelope>;
  envelopeStateID: string;

  public s$: Subscription;

  constructor(
    public envelopeService: EnvelopesService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

    this.envelopeState$ = store.pipe(select(fromRoot.getEnvelopeFirstResult));
    this.envelopeState$.subscribe(envelope => this.envelopeStateID = envelope && envelope['id']);
  }

  /**
   * Get Document List
   *
   * Get List from the Store, if not exist, call the {@link DocumentService}
   * also change set loading = true, on sample state
   *
   */
  getEnvelopes(params: QueryParams): Subscription {

    // this.killSubscription();

    this.logger.debug('EnvelopeEffect', 'getEnvelopes() with this params: ', params);
    this.store.dispatch(new searchPagedAction.SearchingSearchPaged());

    return this.envelopeService.getEnvelopes(params)
      .subscribe(
        (resp: any) => {
          this.logger.debug('EnvelopeEffect', 'getEnvelopes success with result: ', resp);
          this.store.dispatch(new searchPagedAction.PutSearchResultsSearchPaged(resp));
          this.store.dispatch(new searchPagedAction.PutSearchResultsTypeResult('envelopes'));

        },
        (error: Error) => {
          this.logger.error('EnvelopeEffect', 'getEnvelopes error!! ', error);
          this.errorToGlobalState(error, 'put');
        }
      );
  }

  /**
   * Get Envelope by Id
   *
   * Get List from the Store, if not exist, call the {@link EnvelopeService}
   * also change set loading = true, on sample state
   */
  getEnvelopeById(id: string, refresh?: boolean): Subscription {

    // if (id === this.envelopeStateID) { return; }
    // this.killSubscription();

    this.logger.debug('EnvelopeEffect', 'getEnvelopeById() with this id: ', id);
    if (refresh !== false) {
      this.store.dispatch(new envelopeAction.LoadingEnvelope());
    }

    return this.envelopeService.getEnvelopeById(id)
      .subscribe(
        (resp: RestResponse<Envelope>) => {
          this.logger.debug('EnvelopeEffect', 'getEnvelopeById success with result: ', resp.result);
          this.store.dispatch(new envelopeAction.PutEnvelopeResult(resp.result));
        },
        (error: Error) => {
          this.logger.error('EnvelopeEffect', 'getEnvelopeById error!! ', error);
          this.errorToGlobalState(error, 'get');
        }
      );
  }

  /**
  * Put Envelope by id
  * {@link EnvelopeService}
  *
  */
  putEnvelopeById(id: string, body: Envelope): Subscription {

    // this.killSubscription();

    this.logger.debug('EnvelopeEffect', 'putEnvelopeById() with ', { id: id, body: body });
    this.store.dispatch(new envelopeAction.UpdatingEnvelope());

    return this.envelopeService.putEnvelopesById(id, body)
      .subscribe(
        (resp: RestResponse<EnvelopeCreationResult>) => {
          this.logger.debug('EnvelopeEffect', 'putEnvelopeById success with result: ', resp);
          this.store.dispatch(new envelopeAction.PutUpdateEnvelope(resp.result[0]));
        },
        (error: Error) => {
          this.logger.error('EnvelopeEffect', 'putEnvelopeById error!! ', error);
          this.errorToGlobalState(error, 'put_update');
        }
      );
  }

  /**
  * Delete Envelope by id
  * {@link EnvelopeService}
  *
  */
  deleteEnvelopeById(id: string): Subscription {

    // this.killSubscription();

    this.logger.debug('EnvelopeEffect', 'deleteEnvelopeById() with ', id);
    this.store.dispatch(new envelopeAction.DeleteEnvelopeLoading());

    return this.envelopeService.deleteEnvelopesById(id)
      .subscribe(
        (resp: RestResponse<string>) => {
          this.logger.debug('EnvelopeEffect', 'deleteEnvelopeById success with result: ', resp);
          this.store.dispatch(new envelopeAction.DeleteEnvelopeResults(resp[0]));
        },
        (error: Error) => {
          this.logger.error('EnvelopeEffect', 'deleteEnvelopeById error!! ', error);
          this.errorToGlobalState(error, 'delete-envelope');
        }
      );
  }


  postEnvelopes(formData: FormData): Subscription {

    // this.killSubscription();
    this.logger.debug('EnvelopeEffect', 'postEnvelopes() with this form data: ', formData);

    this.store.dispatch(new uploadDocumentsAction.LoadingDocumentList());
    // console.log( formData.getAll('fileList') );
    return this.envelopeService.postEnvelopes(formData)
      .subscribe(
        (resp: RestResponse<EnvelopeCreationResult>) => {
          this.logger.debug('EnvelopeEffect', 'postEnvelopes success with result: ', resp.result);
          this.store.dispatch(new uploadDocumentsAction.PutResult(resp.result));
        },
        (error: Error) => {
          this.logger.error('EnvelopeEffect', 'postEnvelopes error!! ', error);
          this.errorToGlobalState(error, 'post');
        }
      );

  }

  postEnvelopesDocuments(id: string, formData: FormData): Subscription {

    // this.killSubscription();

    this.logger.debug('EnvelopeEffect', 'with this id: ', id);
    this.logger.debug('EnvelopeEffect', 'postEnvelopesDocuments() with this form data: ', formData);

    this.store.dispatch(new uploadDocumentsAction.LoadingDocumentList());
    // console.log( formData.getAll('fileList') );

    return this.envelopeService.postEnvelopesDocuments(id, formData)
      .subscribe(
        (resp: RestResponse<EnvelopeCreationResult>) => {
          this.logger.debug('EnvelopeEffect', 'postEnvelopesDocuments success with result: ', resp.result);
          this.store.dispatch(new uploadDocumentsAction.PutResult(resp.result));
        },
        (error: Error) => {
          this.logger.error('EnvelopeEffect', 'postEnvelopesDocuments error!! ', error);
          this.errorToGlobalState(error, 'post');
          // this.errorToGlobalState(error, 'status');
        }
      );

  }

  deleteDocumentsFromEnvelope(envId: string, docId: string): Subscription {

    // this.killSubscription();

    this.logger.debug('EnvelopeEffect', 'remove : ', { envelopeId: envId, documentId: docId });
    // this.logger.debug('EnvelopeEffect', 'deleteDocumentsFromEnvelope() with this form data: ', formData);

    this.store.dispatch(new envelopeAction.DeleteDocumentEnvelopeLoading({ deleteLoading: true, deletingId: docId }));

    return this.envelopeService.deleteDocumentsFromEnvelope(envId, docId)
      .subscribe(
        (resp: RestResponse<string>) => {
          this.logger.debug('EnvelopeEffect', 'deleteDocumentsFromEnvelope success with result: ', resp.result);
          this.store.dispatch(new envelopeAction.DeleteDocumentEnvelopeResults(resp.result));
        },
        (error: Error) => {
          this.logger.error('EnvelopeEffect', 'deleteDocumentsFromEnvelope error!! ', error);
          this.errorToGlobalState(error, 'delete');
          // this.errorToGlobalState(error, 'status');
        }
      );

  }

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf DocumentEffect
   */
  public errorToGlobalState(error: Error | any, store?: string) {
    this.logger.error('EnvelopeEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);

    // this.store.dispatch(new envelopeAction.PutEnvelopeError( error ) );
    if (error.code === 400 || error.code === '400' || error.code === 'error' || error.code === '413' || error.code === 413) {
      this.logger.debug('EnvelopeEffect', 'Dispatch Scope Error to Store');
      // tslint:disable-next-line:max-line-length
      // search ? this.store.dispatch(new envelopeAction.PutEnvelopeError(error)) : this.store.dispatch(new envelopeAction.PutUpdateEnvelopeError(error));
      this.errorDispacher(error, store);
    } else {
      this.logger.debug('EnvelopeEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      if (error['status'] === 0 || error['status'] === 502 || error['status'] === 500 || error['status'] === 500) {
        this.errorDispacher({ code: error['status'], message: 'Server Error' }, store);
      } else {
        // this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
        this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));

      }
    }

  }

  errorDispacher(error, store) {
    switch (store) {
      case 'put':
        // this.store.dispatch(new envelopeAction.PutEnvelopeError(error));
        this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
        break;
      case 'put_update':
        this.store.dispatch(new envelopeAction.PutUpdateEnvelopeError(error));
        break;
      case 'post':
        this.store.dispatch(new uploadDocumentsAction.PostDocumentError(error));
        break;
      case 'delete':
        this.store.dispatch(new envelopeAction.DeleteDocumentEnvelopeError(error));
        break;
      case 'delete-envelope':
        this.store.dispatch(new envelopeAction.DeleteEnvelopeError(error));
        break;
      case 'get':
        this.store.dispatch(new envelopeAction.PutEnvelopeError(error));
        break;
      default:
        this.store.dispatch(new envelopeAction.PutUpdateEnvelopeError(error));
    }
  }

  // killSubscription() {
  //   this.logger.debug('EnvelopeEffect', 'killSubscription');
  //   if (this.s$) { this.s$.unsubscribe(); }
  // }
}
