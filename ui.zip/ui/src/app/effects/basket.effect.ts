import { Subscription } from 'rxjs';
// import { PutUpdateBasketError } from './../actions/baskets.actions';
// import { BasketCreationResult } from './../models/basket-creation-result';
import { RestResponse } from './../models/rest-response';
import { QueryParams } from 'app/models/paged';
import { Error } from 'app/models/error';
import { Basket } from 'app/models/basket';
import { LoggerService } from 'app/services/logger/logger.service';

import { Observable } from 'rxjs';
import { BasketService } from 'app/services/basket.service';

import { Store, select } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as basketAction from '../actions/basket.actions';
import * as httpErrorAction from '../actions/http-error.actions';
import * as searchPagedAction from '../actions/search-paged.actions';

import { Injectable } from '@angular/core';
import * as aclManagementAction from '../actions/acl-management.actions';

/**
 * This Class is the Sample Controler Store/{@link BasketService}
 * @export
 * @class SampleEffect
 */
@Injectable()
export class BasketEffect {

  // public actionMethod: string;
  public query$: Observable<QueryParams>;
  query: QueryParams;

  public s$: Subscription;

  constructor(
    public basketService: BasketService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

    this.query$ = store.pipe(select(fromRoot.getSearchPagedQuery));
    this.query$.subscribe((q) => this.query = q);
  }

  /**
   * Get Basket List
   *
   * Get List from the Store, if not exist, call the {@link BasketService}
   * also change set loading = true, on sample state
   *
   */
  getBaskets(params?: QueryParams): Subscription {

    // this.killSubscription();

    this.logger.debug('BasketEffect', 'getBaskets() with this params: ', params);
    this.store.dispatch(new basketAction.LoadingBasket());

    return this.basketService.getBaskets(params)
      .subscribe(
        (resp: any) => {
          this.logger.debug('BasketEffect', 'getBaskets success with result: ', resp);
          this.store.dispatch(new basketAction.PutBasketResults(resp['result']));
        },
        (error: Error) => {
          this.logger.error('BasketEffect', 'getBaskets error!! ', error);
          this.errorToGlobalState(error);
        }
      );
  }

  /**
 * Get Basket by id
 *
 * Get List from the Store, if not exist, call the {@link BasketService}
 * also change set loading = true, on sample state
 *
 */
  getBasketsTasksById(id: string, params?: QueryParams): Subscription {

    // this.killSubscription();

    this.logger.debug('BasketEffect', 'getBasketsTasksById() with id: ', id);
    // this.store.dispatch(new basketAction.LoadingBasket());
    this.store.dispatch(new searchPagedAction.SearchingSearchPaged());

    return this.basketService.getBasketsTasksById(id, params)
      .subscribe(
        (resp: any) => {
          this.logger.debug('BasketEffect', 'getBasketsTasksById success with result: ', resp);
          // this.store.dispatch(new basketAction.PutBasket(resp.result[0]));
          this.store.dispatch(new searchPagedAction.PutSearchResultsSearchPaged(resp));
          this.store.dispatch(new searchPagedAction.PutSearchResultsTypeResult('basket'));

        },
        (error: Error) => {
          this.logger.error('BasketEffect', 'getBasketsTasksById error!! ', error);
          this.errorToGlobalState(error, 'get');
        }
      );
  }


  /**
*
*
* @param {string} id
* @param {number} version
* @returns {(any | Basket)}
* @memberof BasketEffect
*/
  putBasketsById(id: string, body: Basket): any | Basket {

    this.logger.debug('BasketEffect', 'putBasketsById() with ', { id: id });
    this.store.dispatch(new basketAction.LoadingUpdatingBasket(true));
    this.basketService.putBasketsById(id, body)
      .subscribe(
        (resp: RestResponse<Basket> | any) => {
          this.logger.debug('BasketEffect', 'putBasketsById success with result: ', resp);
          this.store.dispatch(new basketAction.PutUpdateBasketResults(resp[0]));
        },
        (error: Error) => {
          this.logger.error('BasketEffect', 'putBasketsById error!! ', error);
          this.errorToGlobalState(error, 'updating');
        }
      );
  }


  postBaskets(body: Basket): any | Basket {

    this.logger.debug('BasketEffect', 'postBaskets() with ', body);
    this.store.dispatch(new basketAction.LoadingPostBasket(true));
    this.basketService.postBaskets(body)
      .subscribe(
        (resp: RestResponse<Basket> | any) => {
          this.logger.debug('BasketEffect', 'putBasketsById success with result: ', resp);
          this.store.dispatch(new basketAction.PutPostBasketResults(resp[0]));
        },
        (error: Error) => {
          this.logger.error('BasketEffect', 'putBasketsById error!! ', error);
          this.errorToGlobalState(error, 'post');
        }
      );
  }

  deleteBasketsById(id: string): any {

    this.logger.debug('BasketEffect', 'deleteBasketsById() with ', { id: id });
    this.store.dispatch(new basketAction.LoadingDeleteBasket(true));
    this.basketService.deleteBasketsById(id)
      .subscribe(
        (resp: RestResponse<Basket> | any) => {
          this.logger.debug('BasketEffect', 'deleteBasketsById success with result: ', resp);
          this.store.dispatch(new basketAction.PutDeleteBasketResults(resp.result));
        },
        (error: Error) => {
          this.logger.error('BasketEffect', 'deleteBasketsById error!! ', error);
          this.errorToGlobalState(error, 'delete');
        }
      );
  }

  putBasketsAcl(businessScopeId: string, body): any {

    this.logger.debug('BusinessScopeEffect', 'putBusinessScopeAcl() with ', { businessScopeId: businessScopeId });
    this.store.dispatch(new aclManagementAction.PutUpdateLoadingAclManagementAction(true));
    this.store.dispatch(new aclManagementAction.PutIdUpdateAclManagementAction(businessScopeId));

    this.basketService.putBasketsAcl(businessScopeId, body)
      .subscribe(
        (resp: any ) => {
          this.logger.debug('BusinessScopeEffect', 'putBusinessScopeAcl success with result: ', resp);
          this.store.dispatch(new aclManagementAction.PutResultUpdateAclManagementAction(resp));

        },
        (error: Error) => {
          this.logger.error('BusinessScopeEffect', 'putBusinessScopeAcl error!! ', error);
          this.errorToGlobalState(error, 'acl');
        }
      );
  }

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf BasketEffect
   */
  public errorToGlobalState(error: Error | any, store?: string) {
    this.logger.error('BasketEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('BasketEffect', 'Dispatch Scope Error to Store', error);
      this.errorDispacher(error, store);
      // tslint:disable-next-line:max-line-length
      // search ? this.store.dispatch(new searchPagedAction.PutSearchResultsError(error)) : this.store.dispatch(new basketAction.PutUpdateBasketError(error));
    } else {
      this.logger.debug('BasketEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      // this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));

    }

  }

  errorDispacher(error, store) {
    switch (store) {
      case 'get':
        this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
        break;
      case 'updating':
        this.store.dispatch(new basketAction.PutUpdateBasketError(error));
        break;
      case 'post':
        this.store.dispatch(new basketAction.PutPostBasketError(error));
        break;
      case 'delete':
        this.store.dispatch(new basketAction.PutDeleteBasketError(error));
        break;
       case 'acl':
        this.store.dispatch(new aclManagementAction.PutErrorUpdateAclManagementAction(error));
        break;
      default:
        this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    }
  }
}
