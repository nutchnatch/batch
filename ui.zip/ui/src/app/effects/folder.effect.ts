import { Subscription } from 'rxjs';
import { DocumentAttachedToFoldersResult } from './../models/document-attached-to-folder-result';
import { FolderCreationResult } from './../models/folder-creation-result';
import { Subject } from 'rxjs';
import { RestResponse } from './../models/rest-response';
import { QueryParams } from 'app/models/paged';
import { Error } from 'app/models/error';
import { Folder } from 'app/models/folder';
import { LoggerService } from 'app/services/logger/logger.service';

import { Observable } from 'rxjs';
import { FolderService } from 'app/services/folder.service';

import { Store, select } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as searchPagedAction from '../actions/search-paged.actions';
import * as searchFolderAction from '../actions/search-folder-to-attach.actions';
import * as folderAction from '../actions/folder.actions';

import * as httpErrorAction from '../actions/http-error.actions';

import { Injectable } from '@angular/core';

/**
 * This Class is the Sample Controler Store/{@link FolderService}
 * @export
 * @class SampleEffect
 */
@Injectable()
export class FolderEffect {

  // public actionMethod: string;
  public query$: Observable<QueryParams>;
  query: QueryParams;
  searchTerm$ = new Subject<any>();
  s$: Subscription;

  constructor(
    public folderService: FolderService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

    this.query$ = store.pipe(select(fromRoot.getSearchPagedQuery));
    this.query$.subscribe((q) => this.query = q);

    // this.folderService.getFolderLive(this.searchTerm$)
    //   .subscribe(resp => {
    //     this.logger.debug('FolderEffect', 'getFolders success with result: ', resp);
    //     this.store.dispatch(new searchFolderAction.PutSearchResultsToAttach(resp.result));
    //   });
  }

  // getFoldersLive(query: any): any {
  //   this.logger.debug('FolderEffect', 'getFoldersLive() with this query: ', query);
  //   this.store.dispatch(new searchFolderAction.SearchingFolderToAttach());
  //   this.searchTerm$.next(Object.assign({}, { name: 'contains|' + query }));
  // }
  /**
   * Get Folder List
   *
   * Get List from the Store, if not exist, call the {@link FolderService}
   * also change set loading = true, on sample state
   *
   */

  getFolders(params: QueryParams, toAttach?: boolean): Subscription {

    // this.killSubscription();

    this.logger.debug('FolderEffect', 'getFolders() with this params: ', params);
    this.store.dispatch(new searchPagedAction.SearchingSearchPaged());

    return this.folderService.getFolder(params)
      .subscribe(
      (resp: any) => {
        this.logger.debug('FolderEffect', 'getFolders success with result: ', resp);
        this.store.dispatch(new searchPagedAction.PutSearchResultsSearchPaged(resp));
        this.store.dispatch(new searchPagedAction.PutSearchResultsTypeResult('folders'));

        if (toAttach) { this.store.dispatch(new searchFolderAction.PutSearchResultsToAttach(resp.result)); }

      },
      (error: Error) => {
        this.logger.error('FolderEffect', 'getFolders error!! ', error);
        this.errorToGlobalState(error, 'search');
      }
      );
  }
  /**
 * Get Folder by id
 *
 * Get List from the Store, if not exist, call the {@link FolderService}
 * also change set loading = true, on sample state
 *
 */
  getFoldersById(id: string): Subscription {

    // this.killSubscription();

    this.logger.debug('FolderEffect', 'getFoldersById() with id: ', id);
    this.store.dispatch(new folderAction.LoadingFolder());

    return this.folderService.getFolderById(id)
      .subscribe(
      (resp: RestResponse<Folder>) => {
        this.logger.debug('FolderEffect', 'getFolderById success with result: ', resp);
        this.store.dispatch(new folderAction.PutFolderResult(resp.result));
      },
      (error: Error) => {
        this.logger.error('FolderEffect', 'getFolderById error!! ', error);
        this.errorToGlobalState(error);
      }
      );
  }
  /**
    * Put Folder by id
    * {@link FolderService}
    *
    */
  putFolderById(id: string, body: Folder): Subscription {

    // this.killSubscription();

    this.logger.debug('FolderEffect', 'putFolderById() with ', { id: id, body: body });
    this.store.dispatch(new folderAction.UpdatingFolder());

    return this.folderService.putFoldersById(id, body)
      .subscribe(
      (resp: RestResponse<FolderCreationResult>) => {
        this.logger.debug('FolderEffect', 'putFolderById success with result: ', resp);
        this.store.dispatch(new folderAction.PutUpdateFolder(resp.result[0]));
      },
      (error: Error) => {
        this.logger.error('FolderEffect', 'putFolderById error!! ', error);
        this.errorToGlobalState(error);
      }
      );
  }


  /**
   * Post Folder performe a create new folder
   * @param body
   */
  postFolders(body: Folder): Subscription {

    // this.killSubscription();

    this.logger.debug('FolderEffect', 'postFolder() with ', { body: body });
    this.store.dispatch(new folderAction.PostCreateFolderCreating(true));

    return this.folderService.postFolders(body)
      .subscribe(
      (resp: RestResponse<FolderCreationResult>) => {
        this.logger.debug('FolderEffect', 'postFolders success with result: ', resp);
        this.store.dispatch(new folderAction.PostCreateFolderResult(resp.result[0]));
      },
      (error: Error) => {
        this.store.dispatch(new folderAction.PostCreateFolderCreating(false));
        this.logger.error('FolderEffect', 'postFolders error!! ', error);
        this.errorToGlobalState(error, 'creating');
      }
      );
  }

  /**
    * Post Folder's Documents (attach documents to a folder)
    * {@link FolderService}
    *
    */
  // TODO: remove from search action

  postFolderDocuments(id: string, docId: Array<string>): Subscription {

    // this.killSubscription();
    this.logger.debug('FolderEffect', 'postFolderDocuments() with ', { id: id, docId: docId });
    this.store.dispatch(new searchFolderAction.UploadingFolderToAttach(true));
    this.store.dispatch(new searchFolderAction.PutSearchResultsDocumentsToAttach(docId));

    return this.folderService.postFoldersDocument(id, docId)
      .subscribe(
      (resp: RestResponse<DocumentAttachedToFoldersResult>) => {
        this.logger.debug('FolderEffect', 'postFolderDocuments success with result: ', resp);

        this.store.dispatch(new searchFolderAction.PutSearchResultsToAttachSuccess(resp.result[0]));
      },
      (error: Error) => {
        this.store.dispatch(new searchFolderAction.UploadingFolderToAttach(false));
        this.logger.error('FolderEffect', 'postFolderDocuments error!! ', error);
        this.errorToGlobalState(error, 'creating');
      }
      );
  }

  /**
   * Delete Folder's Documents (attach documents to a folder)
   * {@link FolderService}
   *
   */
  deleteFolderDocuments(id: string, docId: Array<string>): Subscription {

    // this.killSubscription();

    this.logger.debug('FolderEffect', 'deleteFolderDocuments() with ', { id: id, docIds: docId });
    this.store.dispatch(new folderAction.DeleteFolderDeleting(true));

    return this.folderService.deleteFoldersDocument(id, docId)
      .subscribe(
      (resp: RestResponse<DocumentAttachedToFoldersResult>) => {
        this.logger.debug('FolderEffect', 'deleteFolderDocuments success with result: ', resp);
        this.store.dispatch(new folderAction.DeleteFolderResult(resp.result[0]));
      },
      (error: Error | any) => {
        this.store.dispatch(new folderAction.DeleteFolderDeleting(false));
        this.logger.error('FolderEffect', 'deleteFolderDocuments error!! ', error);
        this.errorToGlobalState(error, 'deleting');
      }
      );
  }


  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf FolderEffect
   */
  public errorToGlobalState(error: Error | any, store?: string) {
    this.logger.error('FolderEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('FolderEffect', 'Dispatch Scope Error to Store, to', store);
      this.errorDispacher(error, store);
      // tslint:disable-next-line:max-line-length
      //  search ? this.store.dispatch(new searchPagedAction.PutSearchResultsError(error)) : this.store.dispatch(new folderAction.PutUpdateFolderError(error));
    } else {
      // console.log(error instanceof  Error)
      this.logger.debug('FolderEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));
    }

  }

  errorDispacher(error, store) {
    switch (store) {
      case 'search':
        this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
        break;
      case 'creating':
        this.store.dispatch(new folderAction.PostCreateFolderError(error));
        break;
      case 'deleting':
        this.store.dispatch(new folderAction.DeleteFolderError(error));
        break;
      default:
        this.store.dispatch(new folderAction.PutUpdateFolderError(error));
    }
  }

  // killSubscription() {
  //   this.logger.debug('FolderEffect', 'killSubscription');
  //   if (this.s$) { this.s$.unsubscribe(); }
  // }
}
