import { FolderTypesService } from './../services/folder-types.service';
import { Subscription } from 'rxjs';
import { RestResponse } from './../models/rest-response';
import { Error } from 'app/models/error';
import { LoggerService } from 'app/services/logger/logger.service';
import { FolderTypes } from 'app/models/folder-types';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as folderTypesAction from '../actions/folder-types.actions';
import * as httpErrorAction from '../actions/http-error.actions';
import * as aclManagementAction from '../actions/acl-management.actions';



/**
 *
 *
 * @export
 * @class FolderTypeEffect
 */
@Injectable()
export class FolderTypeEffect {

  public folderTypes$: Observable<Array<FolderTypes>>;
  public subsciberDocumentType: Subscription;

  folderTypes: Array<FolderTypes>;

  constructor(
    public folderTypesServices: FolderTypesService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

    this.folderTypes$ = store.pipe(select(fromRoot.getFolderTypesResult));
    this.subsciberDocumentType = this.folderTypes$.subscribe(folderTypes => {
      this.folderTypes = folderTypes;
    });

  }


  /**
   *
   *
   * @param {string} id
   * @param {number} version
   * @returns {(any | FolderTypes)}
   * @memberof FolderTypeEffect
   */
  getFolderTypeById(id: string, version: number): any | FolderTypes {

    this.logger.debug('FolderTypeEffect', 'getFolderTypeById() with id ($1) and version ($2): ', { $1: id, $2: version });
    this.store.dispatch(new folderTypesAction.LoadingFolderTypes());

    this.folderTypesServices.getFolderTypeById(id, version)
      .subscribe(
        (resp: RestResponse<FolderTypes> | any) => {
          this.logger.debug('FolderTypeEffect', 'getFolderTypeById success with result: ', resp);
          this.store.dispatch(new folderTypesAction.PutFolderTypesById(resp.result[0]));
        },
        (error: Error) => {
          this.logger.error('FolderTypeEffect', 'getEnvelopeTypeById error!! ', error);
          this.errorToGlobalState(error, 'get');
        }
      );
  }

  /**
 *
 *
 * @param {string} id
 * @param {number} version
 * @returns {(any | folderTypes)}
 * @memberof FolderTypeEffect
 */
  putFolderTypeById(id: string, version: number, body: FormData): any | FolderTypes {

    this.logger.debug('FolderTypeEffect', 'putFolderTypeById() with id ($1) and version ($2): ', { $1: id, $2: version });
    this.store.dispatch(new folderTypesAction.PutFolderTypesUpdating(true));
    this.folderTypesServices.putFolderTypeById(id, version, body)
      .subscribe(
        (resp: RestResponse<FolderTypes> | any) => {
          this.logger.debug('FolderTypeEffect', 'putFolderTypeById success with result: ', resp);
          this.store.dispatch(new folderTypesAction.PutFolderTypesUpdatingResult(resp[0]));
        },
        (error: Error) => {
          this.logger.error('FolderTypeEffect', 'putFolderTypeById error!! ', error);
          this.errorToGlobalState(error, 'updating');
        }
      );
  }

  /**
   *
   *
   * @param {string} id
   * @param {number} version
   * @returns {(any | folderTypes)}
   * @memberof FolderTypeEffect
   */
  putFolderTypesActivate(id: string, version: number): any | FolderTypes {

    this.logger.debug('FolderTypeEffect', 'putFolderTypesActivate() with: ', { id: id, version: version });
    this.store.dispatch(new folderTypesAction.PutFolderTypesTooglingState({ loading: true, id: id }));
    this.folderTypesServices.putFolderTypeActivate(id, version)
      .subscribe(
        (resp: RestResponse<FolderTypes> | any) => {
          this.logger.debug('FolderTypeEffect', 'putFolderTypesActivate success with result: ', resp);
          this.store.dispatch(new folderTypesAction.PutFolderTypesToogleStateResult(resp));
        },
        (error: Error) => {
          this.logger.error('FolderTypeEffect', 'putFolderTypesActivate error!! ', error);
          this.errorToGlobalState(error, 'toogle');
        }
      );
  }

  /**
   *
   *
   * @param {string} id
   * @param {number} version
   * @returns {(any | DocumentType)}
   * @memberof FolderTypeEffect
   */
  putFolderTypesDeactivate(id: string, version: number): FolderTypes | any {

    this.logger.debug('FolderTypeEffect', 'putFolderTypeDeactivate() with id ($1) and version ($2): ', { $1: id, $2: version });
    this.store.dispatch(new folderTypesAction.PutFolderTypesTooglingState({ loading: true, id: id }));

    this.folderTypesServices.putFolderTypeDeactivate(id, version)
      .subscribe(
        (resp: RestResponse<FolderTypes> | any) => {
          this.logger.debug('FolderTypeEffect', 'putFolderTypeDeactivate success with result: ', resp);
          this.store.dispatch(new folderTypesAction.PutFolderTypesToogleStateResult(resp));
        },
        (error: Error) => {
          this.logger.error('FolderTypeEffect', 'putFolderTypeDeactivate error!! ', error);
          this.errorToGlobalState(error, 'toogle');
        }
      );
  }

  postFolderTypes(body: FolderTypes): FolderTypes | any {

    this.logger.debug('FolderTypeEffect', 'postFolderTypes() body: ', body);
    this.store.dispatch(new folderTypesAction.PutFolderTypesCreating(true));

    this.folderTypesServices.postFolderType(body)
      .subscribe(
        (resp: RestResponse<FolderTypes> | any) => {
          this.logger.debug('FolderTypeEffect', 'postFolderTypes success with result: ', resp);
          this.store.dispatch(new folderTypesAction.PutFolderTypesCreatingResult(resp));
        },
        (error: Error) => {
          this.logger.error('FolderTypeEffect', 'postFolderTypes error!! ', error);
          this.errorToGlobalState(error, 'post');
        }
      );
  }

  /**
  *
  *
  * @param {string} id
  * @param {number} version
  * @param {*} body
  * @returns {*}
  * @memberof FolderTypeEffect
  */
  putFolderTypesAcl(id: string, version: number, body: any): any {

    this.logger.debug('FolderTypeEffect', 'putFolderTypesAcl()', { 'id': id, 'version': version, body: body });
    this.store.dispatch(new aclManagementAction.PutUpdateLoadingAclManagementAction(true));
    this.store.dispatch(new aclManagementAction.PutIdUpdateAclManagementAction(id));

    this.folderTypesServices.putFolderTypesAcl(id, version, body)
      .subscribe(
        (resp: any) => {
          this.logger.debug('FolderTypeEffect', 'putFolderTypesAcl success with result: ', resp);
          this.store.dispatch(new aclManagementAction.PutResultUpdateAclManagementAction(resp));
        },
        (error: Error) => {
          this.logger.error('FolderTypeEffect', 'putFolderTypesAcl error!! ', error);
          this.errorToGlobalState(error, 'acl');
        }
      );
  }

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf DocumentEffect
   */
  public errorToGlobalState(error: Error | any, store: string) {
    this.logger.error('FolderTypeEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('FolderTypeEffect', 'Dispatch Scope Error to Store');
      // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
      this.errorDispacher(error, store);

    } else {
      this.logger.debug('FolderTypeEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      // this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));

      if (store === 'acl') {  this.store.dispatch(new aclManagementAction.PutErrorUpdateAclManagementAction(
        {
          'code': '404',
          'message': 'something wrongs'
        })); }
    }

  }

  errorDispacher(error, store) {
    switch (store) {
      case 'toogle':
        this.store.dispatch(new folderTypesAction.PutFolderTypesToogleStateError(error));
        break;
      case 'updating':
        this.store.dispatch(new folderTypesAction.PutFolderTypesUpdatingError(error));
        break;
      case 'get':
        this.store.dispatch(new folderTypesAction.PutFolderTypesError(error));
        break;
      case 'post':
        this.store.dispatch(new folderTypesAction.PutFolderTypesCreatingError(error));
        break;
      case 'acl':
        this.store.dispatch(new aclManagementAction.PutErrorUpdateAclManagementAction(error));
        break;
      default:
        this.store.dispatch(new folderTypesAction.PutFolderTypesError(error));
    }
  }
}
