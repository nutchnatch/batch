import { Subscription } from 'rxjs';
import { QueryParams } from 'app/models/paged';
import { Error } from 'app/models/error';
import { LoggerService } from 'app/services/logger/logger.service';
import { ReportingService } from 'app/services/reporting.service';

import { Observable } from 'rxjs';

import { Store, select } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as httpErrorAction from '../actions/http-error.actions';
import * as reportingAction from '../actions/reporting.actions';

import { Injectable } from '@angular/core';

/**
 * This Class is the Sample Controler Store/{@link reportingService}
 * @export
 * @class SampleEffect
 */
@Injectable()
export class ReportingEffect {

  // public actionMethod: string;
  public query$: Observable<QueryParams>;
  query: QueryParams;

  public s$: Subscription;

  constructor(
    public reportingService: ReportingService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService

  ) {

    this.query$ = store.pipe(select(fromRoot.getSearchPagedQuery));
    // this.query$.subscribe((q) => this.query = q);
  }

  getSummary(): Subscription {

    this.logger.debug('ReportingEffect', 'getSummary(): ');
    this.store.dispatch(new reportingAction.Loading);
    return this.reportingService.getReportingSummary()
      .subscribe(
      (resp: any) => {
        this.logger.debug('ReportingEffect', 'getSummary success with result: ', resp);
        this.store.dispatch(new reportingAction.PutSummaryResult(resp.result[0]));

      },
      (error: Error) => {
        this.logger.error('ReportingEffect', 'getSummary error!! ', error);
        this.errorToGlobalState(error, 'search');
      }
      );
  }

  getEnvelopeReport(start: string, end: string): Subscription {

    this.logger.debug('ReportingEffect', 'getEnvelopeReport() with parameters: ', { start, end });
    this.store.dispatch(new reportingAction.Loading);

    return this.reportingService.getReportingEnvelope(start, end)
      .subscribe(
      (resp: any) => {
        this.logger.debug('ReportingEffect', 'getEnvelopeReport success with result: ', resp);
        this.store.dispatch(new reportingAction.PutEnvelopesResult(resp.result));

      },
      (error: Error) => {
        this.logger.error('ReportingEffect', 'getEnvelopeReport error!! ', error);
        this.errorToGlobalState(error, 'search');
      }
      );
  }

  getDocumentReport(start: string, end: string): Subscription {

    this.logger.debug('ReportingEffect', 'getDocumentReport() with parameters: ', { start, end });
    this.store.dispatch(new reportingAction.Loading);

    return this.reportingService.getReportingDocument(start, end)
      .subscribe(
      (resp: any) => {
        this.logger.debug('ReportingEffect', 'getDocumentReport success with result: ', resp);
        this.store.dispatch(new reportingAction.PutDocumentsResult(resp.result));

      },
      (error: Error) => {
        this.logger.error('ReportingEffect', 'getDocumentReport error!! ', error);
        this.errorToGlobalState(error, 'search');
      }
      );
  }

  getFolderReport(start: string, end: string): Subscription {

    this.logger.debug('ReportingEffect', 'getFolderReport() with parameters: ', { start, end });
    this.store.dispatch(new reportingAction.Loading);

    return this.reportingService.getReportingFolder(start, end)
      .subscribe(
      (resp: any) => {
        this.logger.debug('ReportingEffect', 'getFolderReport success with result: ', resp);
        this.store.dispatch(new reportingAction.PutFoldersResult(resp.result));

      },
      (error: Error) => {
        this.logger.error('ReportingEffect', 'getFolderReport error!! ', error);
        this.errorToGlobalState(error, 'search');
      }
      );
  }

  getBasketReport(start: string, end: string): Subscription {

    this.logger.debug('ReportingEffect', 'getBasketReport() with parameters: ', { start, end });
    this.store.dispatch(new reportingAction.Loading);

    return this.reportingService.getReportingBasket(start, end)
      .subscribe(
      (resp: any) => {
        this.logger.debug('ReportingEffect', 'getBasketReport success with result: ', resp);
        this.store.dispatch(new reportingAction.PutBasketsResult(resp.result));

      },
      (error: Error) => {
        this.logger.error('ReportingEffect', 'getBasketReport error!! ', error);
        this.errorToGlobalState(error, 'search');
      }
      );
  }

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf ReportingEffect
   */
  public errorToGlobalState(error: Error | any, store?: string) {
    this.logger.error('ReportingEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('ReportingEffect', 'Dispatch Scope Error to Store', error);
      this.errorDispacher(error, store);
    } else {
      this.store.dispatch(new reportingAction.Loading(false));
      // const e: Response = error;
      this.logger.debug('ReportingEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      // this.store.dispatch(new httpErrorAction.PutHttpErrorAction(e.json()));
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));

    }

  }

  errorDispacher(error, store) {
    this.store.dispatch(new reportingAction.ReportingError(error));
  }
}
