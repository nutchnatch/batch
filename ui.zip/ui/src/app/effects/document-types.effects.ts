import { Subscription } from 'rxjs';
import { RestResponse } from './../models/rest-response';
import { Error } from 'app/models/error';
import { LoggerService } from 'app/services/logger/logger.service';

import { Observable } from 'rxjs';

import { Store, select } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as documentTypesAction from '../actions/document-types.actions';
import * as httpErrorAction from '../actions/http-error.actions';

import { Injectable } from '@angular/core';

import { DocumentTypes } from 'app/models/document-types';
import { DocumentTypeService } from 'app/services/document-type.service';
import * as aclManagementAction from '../actions/acl-management.actions';

/**
 * This Class is the Sample Controler Store/{@link DocumentTypeService}
 * @export
 * @class DocumentTypeEffect
 */
@Injectable()
export class DocumentTypeEffect {

  public documentTypes$: Observable<Array<DocumentTypes>>;
  public subsciberDocumentType: Subscription;

  docTypes: Array<DocumentTypes>;

  constructor(
    public documentTypesServices: DocumentTypeService,
    public store: Store<fromRoot.State>,
    public logger: LoggerService
  ) {

    this.documentTypes$ = store.pipe(select(fromRoot.getDocumentTypesResult));
    this.subsciberDocumentType = this.documentTypes$.subscribe(docTypes => {
      this.docTypes = docTypes;
    });

  }


  /**
   *
   *
   * @param {string} id
   * @param {number} version
   * @returns {(any | DocumentTypes)}
   * @memberof DocumentTypeEffect
   */
  getDocumentTypeById(id: string, version: number): any | DocumentTypes {

    this.logger.debug('DocumentTypeEffect', 'getDocumentTypeById() with id ($1) and version ($2): ', { $1: id, $2: version });
    this.store.dispatch(new documentTypesAction.LoadingDocumentTypes());

    this.documentTypesServices.getDocumentTypeById(id, version)
      .subscribe(
        (resp: RestResponse<DocumentTypes> | any) => {
          this.logger.debug('DocumentTypeEffect', 'getDocumentTypeById success with result: ', resp);
          this.store.dispatch(new documentTypesAction.PutDocumentTypesById(resp.result[0]));
        },
        (error: Error) => {
          this.logger.error('DocumentTypeEffect', 'getEnvelopeTypeById error!! ', error);
          this.errorToGlobalState(error, 'get');
        }
      );
  }

  /**
 *
 *
 * @param {string} id
 * @param {number} version
 * @returns {(any | DocumentTypes)}
 * @memberof DocumentTypeEffect
 */
  putDocumentTypeById(id: string, version: number, body: FormData): any | DocumentTypes {

    this.logger.debug('DocumentTypeEffect', 'putDocumentTypeById() with id ($1) and version ($2): ', { $1: id, $2: version });
    this.store.dispatch(new documentTypesAction.PutDocumentTypesUpdating(true));
    this.documentTypesServices.putDocumentTypeById(id, version, body)
      .subscribe(
        (resp: RestResponse<DocumentTypes> | any) => {
          this.logger.debug('DocumentTypeEffect', 'putDocumentTypeById success with result: ', resp);
          this.store.dispatch(new documentTypesAction.PutDocumentTypesUpdatingResult(resp.result[0]));
        },
        (error: Error) => {
          this.logger.error('DocumentTypeEffect', 'putDocumentTypeById error!! ', error);
          this.errorToGlobalState(error, 'updating');
        }
      );
  }

  /**
   *
   *
   * @param {string} id
   * @param {number} version
   * @returns {(any | DocumentTypes)}
   * @memberof DocumentTypeEffect
   */
  putDocumentTypesActivate(id: string, version: number): any | DocumentTypes {

    this.logger.debug('DocumentTypeEffect', 'putDocumentTypesActivate() with: ', { id: id, version: version });
    this.store.dispatch(new documentTypesAction.PutDocumentTypesTooglingState({ loading: true, id: id }));
    this.documentTypesServices.putDocumentTypeActivate(id, version)
      .subscribe(
        (resp: RestResponse<DocumentTypes> | any) => {
          this.logger.debug('DocumentTypeEffect', 'putDocumentTypesActivate success with result: ', resp);
          this.store.dispatch(new documentTypesAction.PutDocumentTypesToogleStateResult(resp));
        },
        (error: Error) => {
          this.logger.error('DocumentTypeEffect', 'putDocumentTypesActivate error!! ', error);
          this.errorToGlobalState(error, 'toogle');
        }
      );
  }

  /**
   *
   *
   * @param {string} id
   * @param {number} version
   * @returns {(any | DocumentType)}
   * @memberof DocumentTypeEffect
   */
  putDocumentTypesDeactivate(id: string, version: number): any | DocumentType {

    this.logger.debug('DocumentTypeEffect', 'putDocumentTypeDeactivate() with id ($1) and version ($2): ', { $1: id, $2: version });
    this.store.dispatch(new documentTypesAction.PutDocumentTypesTooglingState({ loading: true, id: id }));

    this.documentTypesServices.putDocumentTypeDeactivate(id, version)
      .subscribe(
        (resp: RestResponse<DocumentType> | any) => {
          this.logger.debug('DocumentTypeEffect', 'putDocumentTypeDeactivate success with result: ', resp);
          this.store.dispatch(new documentTypesAction.PutDocumentTypesToogleStateResult(resp));
        },
        (error: Error) => {
          this.logger.error('DocumentTypeEffect', 'putDocumentTypeDeactivate error!! ', error);
          this.errorToGlobalState(error, 'toogle');
        }
      );
  }

  postDocumentTypes(body: DocumentType): any | DocumentType {

    this.logger.debug('DocumentTypeEffect', 'postDocumentTypes() body: ', body);
    this.store.dispatch(new documentTypesAction.PutDocumentTypesCreating(true));

    this.documentTypesServices.postDocumentType(body)
      .subscribe(
        (resp: RestResponse<DocumentTypes> | any) => {
          this.logger.debug('DocumentTypeEffect', 'postDocumentTypes success with result: ', resp);
          this.store.dispatch(new documentTypesAction.PutDocumentTypesCreatingResult(resp));
        },
        (error: Error) => {
          this.logger.error('DocumentTypeEffect', 'postDocumentTypes error!! ', error);
          this.errorToGlobalState(error, 'post');
        }
      );
  }

  /**
  *
  *
  * @param {string} id
  * @param {number} version
  * @param {*} body
  * @returns {*}
  * @memberof DocumentTypeEffect
  */
  putDocumentTypesAcl(id: string, version: number, body: any): any {

    this.logger.debug('DocumentTypeEffect', 'putDocumentTypesAcl()', { 'id': id, 'version': version, body: body });
    this.store.dispatch(new aclManagementAction.PutUpdateLoadingAclManagementAction(true));
    this.store.dispatch(new aclManagementAction.PutIdUpdateAclManagementAction(id));

    this.documentTypesServices.putDocumentTypesAcl(id, version, body)
      .subscribe(
        (resp: any) => {
          this.logger.debug('DocumentTypeEffect', 'putDocumentTypesAcl success with result: ', resp);
          this.store.dispatch(new aclManagementAction.PutResultUpdateAclManagementAction(resp));
        },
        (error: Error) => {
          this.logger.error('DocumentTypeEffect', 'putDocumentTypesAcl error!! ', error);
          this.errorToGlobalState(error, 'acl');
        }
      );
  }

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf DocumentEffect
   */
  public errorToGlobalState(error: Error | any, store: string) {
    this.logger.error('DocumentTypeEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('DocumentTypeEffect', 'Dispatch Scope Error to Store');
      // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
      this.errorDispacher(error, store);

    } else {
      this.logger.debug('DocumentTypeEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      // this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error instanceof  Error ? error : error.json()));

    }

  }

  errorDispacher(error, store) {
    switch (store) {
      case 'toogle':
        this.store.dispatch(new documentTypesAction.PutDocumentTypesToogleStateError(error));
        break;
      case 'updating':
        this.store.dispatch(new documentTypesAction.PutDocumentTypesUpdatingError(error));
        break;
      case 'get':
        this.store.dispatch(new documentTypesAction.PutDocumentTypesError(error));
        break;
      case 'post':
        this.store.dispatch(new documentTypesAction.PutDocumentTypesCreatingError(error));
        break;
      case 'acl':
        this.store.dispatch(new aclManagementAction.PutErrorUpdateAclManagementAction(error));
        break;
      default:
        this.store.dispatch(new documentTypesAction.PutDocumentTypesError(error));
    }
  }
}
