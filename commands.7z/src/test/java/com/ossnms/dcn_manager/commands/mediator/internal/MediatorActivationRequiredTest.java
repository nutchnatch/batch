package com.ossnms.dcn_manager.commands.mediator.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.mediator.MediatorTestBase;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.IllegalMediatorStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.iterableWithSize;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MediatorActivationRequiredTest extends MediatorTestBase {

    private static final int MEDIATOR_INSTANCE_ID = 20;

    private MediatorManagers mediatorManagers;

	@Override
    @Before
	public void setUp() throws RepositoryException
    {
		super.setUp();

		when(physicalDataRepository.queryAll()).thenReturn(ImmutableList.of(
		        new MediatorPhysicalDataBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION),
		        new MediatorPhysicalDataBuilder().build(9987, 8856, VERSION)
	        ));

        mediatorManagers = new MediatorManagers(repo, physicalMediatorRepository, notif, mediatorActivationManager, mediatorEvents);
        
        when(physicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(ImmutableList.of(
				new MediatorPhysicalConnectionBuilder()
					.setActive(true)
        			.setActualActivationState(ActualActivationState.INACTIVE)
					.build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION),
				new MediatorPhysicalConnectionBuilder()
					.setActive(false) // standby - must not be activated
					.setActualActivationState(ActualActivationState.INACTIVE)
					.build(MEDIATOR_INSTANCE_ID + 1, MEDIATOR_ID, VERSION)));
		when(physicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class)))
		.thenAnswer(new MutationAnswer<>());
    }

	@Test(expected=UnknownMediatorIdException.class)
	public void activate_withNonExistingMediatorId_throwsException() throws Exception
	{
		// Set up repository stub (Arrange)
    	when(repo.query(MEDIATOR_ID)).thenReturn(Optional.<MediatorEntity>empty());

    	// Execute command (Act)
		new MediatorActivationRequired<>(context, MEDIATOR_ID, mediatorManagers, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

	@Test(expected=IllegalMediatorStateException.class)
	public void activate_onAnActivatedMediator_throwsException() throws Exception
	{
		// Set up repository and mediator entity stubs (Arrange)
        final MediatorEntity mediatorEntity = new MediatorEntity(
                newInfo(true),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));
		when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(mediatorEntity));

    	// Execute command (Act)
		new MediatorActivationRequired<>(context, MEDIATOR_ID, mediatorManagers, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

	@Test(expected=IllegalMediatorStateException.class)
	public void activate_onAConcurrentlyActivatedMediator_throwsException() throws Exception
	{
		// Set up repository stub (Arrange)
        final MediatorEntity mediatorEntity = new MediatorEntity(
                newInfo(false),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));
        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(mediatorEntity));
		when(infoRepo.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
			.thenReturn(Optional.<MediatorInfoData>empty());

    	// Execute command (Act)
		new MediatorActivationRequired<>(context, MEDIATOR_ID, mediatorManagers, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

	@Test
	public void activate_onADeactivatedMediator_activatesItAndTriggersConnectionEstablishment() throws Exception
	{
		// Set up repository and mediator entity stubs (Arrange)
        final MediatorEntity mediatorEntity = new MediatorEntity(
                newInfo(false),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));
        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(mediatorEntity));

		when(infoRepo.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
			.thenAnswer(new MutationAnswer<>());

    	// Execute command (Act)
		new MediatorActivationRequired<>(context, MEDIATOR_ID, mediatorManagers, loggerManager).call();

		// Verify mediator state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
		final ArgumentCaptor<MediatorInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(MediatorInfoMutationDescriptor.class);
		verify(infoRepo).tryUpdate(argsCaptor.capture());

		assertThat(argsCaptor.getValue().getActivationRequired().get(), is(true));

        final ArgumentCaptor<ActivateMediatorEvent> activationCaptor = ArgumentCaptor.forClass(ActivateMediatorEvent.class);
        final ArgumentCaptor<ActivateMediatorEvent> notificationCaptor = ArgumentCaptor.forClass(ActivateMediatorEvent.class);

		verify(mediatorActivationManager).scheduleActivation(activationCaptor.capture());
		verify(notif).notifyChanges(notificationCaptor.capture());

		assertThat(activationCaptor.getValue().getMediatorId(), is(MEDIATOR_ID));
		assertThat(activationCaptor.getValue().getMediatorInstanceIdentifiers(), is(iterableWithSize(1)));
		assertThat(activationCaptor.getValue().getMediatorInstanceIdentifiers(), hasItem(MEDIATOR_INSTANCE_ID));

        assertThat(notificationCaptor.getValue().getMediatorId(), is(MEDIATOR_ID));
        assertThat(notificationCaptor.getValue().getMediatorInstanceIdentifiers(), is(iterableWithSize(1)));
        assertThat(notificationCaptor.getValue().getMediatorInstanceIdentifiers(), hasItem(MEDIATOR_INSTANCE_ID));

		verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
	}

	@Test(expected=RepositoryException.class)
	public void activate_whenRepositoryThrowsException_throwsRepositoryException() throws Exception
	{
		// Set up repository stub (Arrange)
		when(repo.query(MEDIATOR_ID)).thenThrow(new RepositoryException());

    	// Execute command (Act)
		new MediatorActivationRequired<>(context, MEDIATOR_ID, mediatorManagers, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

}
