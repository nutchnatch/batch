package com.ossnms.dcn_manager.commands.mediator;

import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.DuplicatedHostException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorTypeException;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CreateMediatorTest extends MediatorTestBase {

    private static final int MEDIATOR_INSTANCE_ID = 1000;
    private MediatorType type;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();
        type = mock(MediatorType.class);
        when(type.getName()).thenReturn("type");
        when(mediatorTypes.values()).thenReturn(Collections.singletonList(type));
        when(mediatorTypes.containsKey("type")).thenReturn(true);
        when(mediatorTypes.get("type")).thenReturn(type);
    }

    private void setupSibling(final String siblingName) throws RepositoryException {
        final MediatorInfoData sibling = new MediatorInfoBuilder().setTypeName("type").setName(siblingName).build(9876, 1);

        when(infoRepo.queryByHost(anyString(), anyString())).thenReturn(Optional.empty());
        when(infoRepo.query(anyString())).thenReturn(Optional.empty());
        when(infoRepo.query(eq(siblingName))).thenReturn(Optional.of(sibling));
    }

    private MediatorInstance buildMediatorInstance() {
        return new MediatorInstance(
                new MediatorPhysicalDataBuilder().setHost("host").setPriority(MediatorInstance.PRIMARY_PRIORITY_LEVEL).build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 1),
                new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 1));
    }

    @Test
    public void testCreate() throws DcnManagerException  {
        final MediatorEntity repoEntity = new MediatorEntity(
                newInfo(false),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        setupSibling("other");

        when(repo.create(any(MediatorCreateDescriptor.class))).thenReturn(repoEntity);
        when(physicalMediatorRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(buildMediatorInstance()));

        final CreateMediator<CallContext> create = new CreateMediator<>(context, mediatorManagers, mediatorScheduling, staticConfig, loggerManager,
                new MediatorCreateDescriptor("name", "type"));
        final MediatorEntity entity = create.call();

        assertThat(entity, is(repoEntity));
        verify(notif).notifyCreate(repoEntity);
        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(MEDIATOR_INSTANCE_ID, CONCURRENT_ACTIVATIONS_LIMIT);
    }

    @Test
    public void testCreate_withoutSchedulingLimit() throws DcnManagerException  {
        final MediatorInfoData newInfo = newInfoBuilder(false).setConcurrentActivationsLimited(false).build(MEDIATOR_ID, VERSION);
        final MediatorEntity repoEntity = new MediatorEntity(
                newInfo,
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        setupSibling("other");

        when(repo.create(any(MediatorCreateDescriptor.class))).thenReturn(repoEntity);
        when(physicalMediatorRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(buildMediatorInstance()));

        final CreateMediator<CallContext> create = new CreateMediator<>(context, mediatorManagers, mediatorScheduling, staticConfig, loggerManager,
                new MediatorCreateDescriptor("name", "type"));
        final MediatorEntity entity = create.call();

        assertThat(entity, is(repoEntity));
        verify(notif).notifyCreate(repoEntity);
        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(MEDIATOR_INSTANCE_ID, Integer.MAX_VALUE);
    }

    @Test(expected=DuplicatedHostException.class)
    public void testCreateWithDuplicatedHost_duplicatesForbidden() throws DcnManagerException {
        setupSibling("other");

        when(infoRepo.queryByHost(anyString(), anyString()))
            .thenReturn(Optional.of(
                new MediatorInfoBuilder().setTypeName("type").setName("blah").build(9876, 123)));

        final MediatorCreateDescriptor creation = new MediatorCreateDescriptor("same_name", "type");
        creation.getInstanceCreateDescriptors().add(new MediatorInstanceCreateDescriptor("host"));

        new CreateMediator<>(context, mediatorManagers, mediatorScheduling, staticConfig, loggerManager,
                creation).call();
    }

    @Test
    public void testCreateWithDuplicatedHost_duplicatesAllowed() throws DcnManagerException {
        final MediatorEntity repoEntity = new MediatorEntity(
                newInfo(false),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        setupSibling("other");

        when(repo.create(any(MediatorCreateDescriptor.class))).thenReturn(repoEntity);
        when(physicalMediatorRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(buildMediatorInstance()));

        when(type.allowManyOnSameHost()).thenReturn(true);

        when(infoRepo.queryByHost(anyString(), anyString()))
                .thenReturn(Optional.of(
                        new MediatorInfoBuilder().setTypeName("type").setName("blah").build(9876, 123)));

        final MediatorCreateDescriptor creation = new MediatorCreateDescriptor("same_name", "type");
        creation.getInstanceCreateDescriptors().add(new MediatorInstanceCreateDescriptor("host"));

        final MediatorEntity entity = new CreateMediator<>(context, mediatorManagers, mediatorScheduling, staticConfig, loggerManager,
                creation).call();

        assertThat(entity, is(repoEntity));
        verify(notif).notifyCreate(repoEntity);
        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(MEDIATOR_INSTANCE_ID, CONCURRENT_ACTIVATIONS_LIMIT);
    }

    @Test(expected=DuplicatedObjectNameException.class)
    public void testCreateWithDuplicatedName() throws DcnManagerException {
        setupSibling("same_name");
        new CreateMediator<>(context, mediatorManagers, mediatorScheduling, staticConfig, loggerManager,
                new MediatorCreateDescriptor("same_name", "bad type")).call();
    }

    @Test(expected=UnknownMediatorTypeException.class)
    public void testCreateWithInvalidType() throws DcnManagerException {
        setupSibling("other");
        new CreateMediator<>(context, mediatorManagers, mediatorScheduling, staticConfig, loggerManager,
                new MediatorCreateDescriptor("name", "bad type")).call();
    }

    @Test(expected=CommandException.class)
    public void testCreateWithRepositoryError() throws DcnManagerException {
        setupSibling("other");
        when(repo.create(any(MediatorCreateDescriptor.class))).thenThrow(new RepositoryException());
        new CreateMediator<>(context, mediatorManagers, mediatorScheduling, staticConfig, loggerManager,
                new MediatorCreateDescriptor("name", "type")).call();
    }

}
