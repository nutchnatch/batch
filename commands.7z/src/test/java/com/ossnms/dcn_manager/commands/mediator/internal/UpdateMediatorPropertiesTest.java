package com.ossnms.dcn_manager.commands.mediator.internal;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.commands.mediator.MediatorTestBase;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalDataMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.MediatorConnectionManager;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceUpdates;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class UpdateMediatorPropertiesTest extends MediatorTestBase {

    private static final int MEDIATOR_INSTANCE_ID = 1000;
    private MediatorType mediatorType;

    private ChannelPhysicalConnectionRepository physicalChannelRepository;
    private NePhysicalConnectionRepository physicalNeRepository;
    private ChannelEntityRepository channelEntityRepository;
    private ChannelEntityRepository.ChannelInfoRepository channelInfoRepository;
    private NeEntityRepository neEntityRepository;
    private NeEntityRepository.NeInfoRepository neInfoRepository;
    private ChannelNotifications channelNotifications;
    private NetworkElementNotifications neNotifications;

    private ChannelManagers channelManagers;
    private NetworkElementManagers neManagers;
    
    private MediatorConnectionManager connectionManager;
    private ChannelSchedulingConfiguration channelScheduling;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        physicalChannelRepository = mock(ChannelPhysicalConnectionRepository.class);
        physicalNeRepository = mock(NePhysicalConnectionRepository.class);
        channelNotifications = mock(ChannelNotifications.class);
        neNotifications = mock(NetworkElementNotifications.class);
        channelEntityRepository = mock(ChannelEntityRepository.class);
        neEntityRepository = mock(NeEntityRepository.class);
        neInfoRepository = mock(NeEntityRepository.NeInfoRepository.class);
        channelInfoRepository = mock(ChannelEntityRepository.ChannelInfoRepository.class);

        connectionManager = mock(MediatorConnectionManager.class);

        channelScheduling = mock(ChannelSchedulingConfiguration.class);
        
        mediatorType = MockFactory.mockMediatorType();

        when(mediatorTypes.get("type")).thenReturn(mediatorType);

        when(neEntityRepository.getNeInfoRepository()).thenReturn(neInfoRepository);
        when(channelEntityRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);

        when(physicalMediatorRepository.updateInstance(anyInt(), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
            .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), Collections.emptyList()));

        when(physicalDataRepository.queryAll()).thenReturn(ImmutableList.of(
                new MediatorPhysicalDataBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION),
                new MediatorPhysicalDataBuilder().build(MEDIATOR_INSTANCE_ID + 1, MEDIATOR_ID, VERSION)
            ));

        final MediatorConnectionData mediatorConnectionData = new MediatorConnectionBuilder().setActualActivationState(ActualActivationState.ACTIVE).build(MEDIATOR_ID, VERSION);

        when(mediatorConnectionRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(mediatorConnectionData));

        final MediatorInstance instance = new MediatorInstance(
                new MediatorPhysicalDataBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION),
                new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION));

        when(physicalMediatorRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(instance));

        final MediatorPhysicalConnectionData mediatorState =
                new MediatorPhysicalConnectionBuilder()
                        .setActive(true)
                        .setActualActivationState(com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState.ACTIVE)
                        .build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION);
        when(physicalConnectionRepository.query(MEDIATOR_INSTANCE_ID)).thenReturn(Optional.of(mediatorState));
        
        final MediatorPhysicalConnectionData standbyMediatorState =
                new MediatorPhysicalConnectionBuilder()
                        .setActive(false)
                        .setActualActivationState(com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState.ACTIVE)
                        .build(MEDIATOR_INSTANCE_ID + 1, MEDIATOR_ID, VERSION);
        when(physicalConnectionRepository.query(MEDIATOR_INSTANCE_ID + 1)).thenReturn(Optional.of(standbyMediatorState));
        
        channelManagers = new ChannelManagers(channelEntityRepository, physicalChannelRepository, channelNotifications, null, null);
        neManagers = new NetworkElementManagers(neEntityRepository, physicalNeRepository, null, neNotifications, null);
    }

    @Test
    public void update() throws Exception {

        final MediatorEntity entity = new MediatorEntity(
            newInfo(true),
            new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(entity));
        when(infoRepo.tryUpdate(isA(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        final Map<String, String> updatedProps = ImmutableMap.of(WellKnownMediatorPropertyNames.DESCRIPTION, "new description");
        
        new UpdateMediatorProperties<>(context, mediatorManagers, connectionManager, channelManagers, neManagers, mediatorScheduling, channelScheduling, staticConfig, loggerManager,
                new UpdateMediatorProperties.Data(MEDIATOR_ID,
                        "mediator",
                        updatedProps,
                        MediatorInstance.PRIMARY_PRIORITY_LEVEL))
            .call();

        verify(infoRepo).tryUpdate(isA(MediatorInfoMutationDescriptor.class));
        verify(notif).notifyUpdate(isA(MediatorInfoMutationDescriptor.class));
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemMediator.class));
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(MEDIATOR_INSTANCE_ID, CONCURRENT_ACTIVATIONS_LIMIT);
        verify(connectionManager).updateMediatorProperties(MEDIATOR_INSTANCE_ID, updatedProps);
    }

    @Test
    public void update_noSchedulingLimit() throws Exception {

        final MediatorEntity entity = new MediatorEntity(
            newInfoBuilder(true).setConcurrentActivationsLimited(false).build(MEDIATOR_ID, VERSION),
            new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        final MediatorInstance instance = new MediatorInstance(
            new MediatorPhysicalDataBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION),
            new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION));

        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(entity));
        when(physicalMediatorRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(instance));
        when(infoRepo.tryUpdate(isA(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        new UpdateMediatorProperties<>(context, mediatorManagers, connectionManager, channelManagers, neManagers, mediatorScheduling, channelScheduling, staticConfig, loggerManager,
                new UpdateMediatorProperties.Data(MEDIATOR_ID,
                        "mediator",
                        ImmutableMap.of(WellKnownMediatorPropertyNames.DESCRIPTION, "new description"),
                        MediatorInstance.PRIMARY_PRIORITY_LEVEL))
            .call();

        verify(infoRepo).tryUpdate(isA(MediatorInfoMutationDescriptor.class));
        verify(notif).notifyUpdate(isA(MediatorInfoMutationDescriptor.class));
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemMediator.class));
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(MEDIATOR_INSTANCE_ID, Integer.MAX_VALUE);
    }

    @Test
    public void update_noProperties_doesNothing() throws Exception {

        final MediatorEntity entity = new MediatorEntity(
            newInfo(true),
            new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(entity));
        when(infoRepo.tryUpdate(isA(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        new UpdateMediatorProperties<>(context, mediatorManagers, connectionManager, channelManagers, neManagers, mediatorScheduling, channelScheduling, staticConfig, loggerManager,
                new UpdateMediatorProperties.Data(MEDIATOR_ID,
                        "mediator",
                        ImmutableMap.of(),
                        MediatorInstance.PRIMARY_PRIORITY_LEVEL))
            .call();

        verify(infoRepo, never()).tryUpdate(isA(MediatorInfoMutationDescriptor.class));
        verifyZeroInteractions(notif, loggerManager, mediatorScheduling);
    }

    @Test
    public void update_inactiveInstance_doesNot_pushToMediation() throws Exception {

        final MediatorEntity entity = new MediatorEntity(
            newInfo(true),
            new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(entity));
        final MediatorPhysicalConnectionData mediatorState =
                new MediatorPhysicalConnectionBuilder()
                        .setActive(true)
                        .setActualActivationState(com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState.ACTIVE)
                        .build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION);
        when(physicalConnectionRepository.query(MEDIATOR_INSTANCE_ID)).thenReturn(Optional.of(mediatorState));
        
        final MediatorPhysicalConnectionData standbyMediatorState =
                new MediatorPhysicalConnectionBuilder()
                        .setActive(false)
                        .setActualActivationState(com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState.INACTIVE)
                        .build(MEDIATOR_INSTANCE_ID + 1, MEDIATOR_ID, VERSION);
        when(physicalConnectionRepository.query(MEDIATOR_INSTANCE_ID + 1)).thenReturn(Optional.of(standbyMediatorState));
        
        when(infoRepo.tryUpdate(isA(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        final Map<String, String> updatedProps = ImmutableMap.of(WellKnownMediatorPropertyNames.DESCRIPTION, "new description");
        
        new UpdateMediatorProperties<>(context, mediatorManagers, connectionManager, channelManagers, neManagers, mediatorScheduling, channelScheduling, staticConfig, loggerManager,
                new UpdateMediatorProperties.Data(MEDIATOR_ID,
                        "mediator",
                        updatedProps,
                        MediatorInstance.PRIMARY_PRIORITY_LEVEL))
            .call();

        verify(infoRepo).tryUpdate(isA(MediatorInfoMutationDescriptor.class));
        verify(notif).notifyUpdate(isA(MediatorInfoMutationDescriptor.class));
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemMediator.class));
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(MEDIATOR_INSTANCE_ID, CONCURRENT_ACTIVATIONS_LIMIT);
        verify(connectionManager).updateMediatorProperties(MEDIATOR_INSTANCE_ID, updatedProps);
        verify(connectionManager, never()).updateMediatorProperties(MEDIATOR_INSTANCE_ID + 1, updatedProps);
        
    }


}
