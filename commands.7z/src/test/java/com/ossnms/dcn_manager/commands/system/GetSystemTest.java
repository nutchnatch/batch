package com.ossnms.dcn_manager.commands.system;

import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownSystemIdException;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class GetSystemTest extends SystemTestBase {

    @Test
    public void testGetSystem() throws Exception {
        final SystemInfo repoEntity = newInfo();

        when(repo.query(SYSTEM_ID)).thenReturn(Optional.of(repoEntity));

        final SystemInfo result = new GetSystem<>(null, repo, SYSTEM_ID).call();

        assertThat(result, is(repoEntity));
    }

    @Test(expected=UnknownSystemIdException.class)
    public void testGetSystem_unknownId() throws Exception {

        when(repo.query(SYSTEM_ID)).thenReturn(Optional.empty());

        new GetSystem<>(null, repo, SYSTEM_ID).call();
    }

    @Test(expected=RepositoryException.class)
    public void testGetSystems_withRepositoryError() throws Exception {

        when(repo.query(SYSTEM_ID)).thenThrow(new RepositoryException());

        new GetSystem<>(null, repo, SYSTEM_ID).call();
    }

}
