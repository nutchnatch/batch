package com.ossnms.dcn_manager.commands.ne;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.domain.DomainChildrenChanged;
import com.ossnms.dcn_manager.core.events.domain.DomainParticipationDeleted;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.IllegalNetworkElementStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class DeleteNetworkElementTest extends NeTestBase {

    private static final int CHANNEL_INSTANCE_ID = 8;
    private static final int PHYSICAL_NE_ID = 34;
    private static final int DOMAIN_ID = 2;
    private static final int NE_ID = 95;
    private static final int CHANNEL_ID = 65;
    private static final int VERSION = 1;

    private DomainNotifications domainNotifications;
    private NetworkElementManagers neManagers;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        domainNotifications = mock(DomainNotifications.class);

        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().build(PHYSICAL_NE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
            ));

        neManagers = new NetworkElementManagers(neRepo, neInstanceRepo, null, notif, null);
    }

    private NeEntity buildNeEntity(int neId, ActualActivationState actualActivationState, RequiredActivationState activationState) {
        return new NeEntity(
                new NeConnectionBuilder().setActivationState(actualActivationState).build(neId, VERSION),
                new NeOperationBuilder().build(neId, VERSION),
                new NeInfoBuilder().setProxyType("type").setRequiredActivationState(activationState).build(neId, CHANNEL_ID, VERSION),
                new NeSynchronizationBuilder().build(neId, VERSION),
                new NeUserPreferencesBuilder().setName("name").build(neId, VERSION));
    }

    @Test
    public void delete_withSiblings() throws Exception {

        final NeEntity entity = buildNeEntity(NE_ID, ActualActivationState.DISCONNECTED, RequiredActivationState.INACTIVE);
        final DomainInfoData domain = new DomainInfoData(DOMAIN_ID, VERSION, "domain");
        final Iterable<Integer> siblings = ImmutableList.of(56);

        when(neRepo.queryNe(NE_ID)).thenReturn(Optional.of(entity));
        when(domainRepo.queryAllForNE(NE_ID)).thenReturn(Collections.singleton(domain));
        when(domainRepo.queryChildrenNEs(DOMAIN_ID)).thenReturn(siblings);
        when(domainRepo.tryRemoveNaturalNE(DOMAIN_ID, NE_ID)).thenReturn(true);
        when(domainRepo.tryRemoveTransitiveNE(DOMAIN_ID, NE_ID)).thenReturn(true);

        new DeleteNetworkElement<>(context, neManagers, domainRepo, domainNotifications, settingsRepository, loggerManager, NE_ID)
            .call();

        // direct consequences
        verify(domainRepo).tryRemoveTransitiveNE(DOMAIN_ID, NE_ID);
        verify(domainRepo).tryRemoveNaturalNE(DOMAIN_ID, NE_ID);
        verify(neRepo).delete(new NeDeleteDescriptor(NE_ID));
        verify(notif).notifyDelete(entity);
        verify(loggerManager).createCommandLog(any(CallContext.class), any(LoggerItemNe[].class));
        verify(neInstanceRepo).remove(PHYSICAL_NE_ID);

        // side effects
        final ArgumentCaptor<DomainChildrenChanged> eventCaptor = ArgumentCaptor.forClass(DomainChildrenChanged.class);
        verify(domainNotifications).notifyChanges(eventCaptor.capture());
        verify(domainNotifications, never()).notifyDelete(any(DomainInfoData.class));
        assertThat(eventCaptor.getValue().getDomain(), is(domain));
        assertThat(eventCaptor.getValue().getChildrenIds(), is(siblings));

        verify(domainNotifications).notifyChanges(new DomainParticipationDeleted(DOMAIN_ID, NE_ID));
        verify(domainNotifications, never()).notifyChanges(new DomainParticipationDeleted(DOMAIN_ID, 56));
    }

    @Test
    public void delete_lastInDomain_removesDomain() throws Exception {

        final NeEntity entity = buildNeEntity(NE_ID, ActualActivationState.DISCONNECTED, RequiredActivationState.INACTIVE);
        final DomainInfoData domain = new DomainInfoData(DOMAIN_ID, VERSION, "domain");
        final Iterable<Integer> siblings = ImmutableList.of();

        when(neRepo.queryNe(NE_ID)).thenReturn(Optional.of(entity));
        when(domainRepo.queryAllForNE(NE_ID)).thenReturn(Collections.singleton(domain));
        when(domainRepo.queryChildrenNEs(DOMAIN_ID)).thenReturn(siblings);
        when(domainRepo.tryRemoveNaturalNE(DOMAIN_ID, NE_ID)).thenReturn(true);
        when(domainRepo.tryRemoveTransitiveNE(DOMAIN_ID, NE_ID)).thenReturn(true);

        new DeleteNetworkElement<>(context, neManagers, domainRepo, domainNotifications, settingsRepository, loggerManager, NE_ID)
            .call();

        // direct consequences
        verify(domainRepo).tryRemoveTransitiveNE(DOMAIN_ID, NE_ID);
        verify(domainRepo).tryRemoveNaturalNE(DOMAIN_ID, NE_ID);
        verify(neRepo).delete(new NeDeleteDescriptor(NE_ID));
        verify(notif).notifyDelete(entity);
        verify(loggerManager).createCommandLog(any(CallContext.class), any(LoggerItemNe[].class));
        verify(neInstanceRepo).remove(PHYSICAL_NE_ID);

        // side effects
        verify(domainNotifications).notifyDelete(domain);
        verify(domainNotifications, never()).notifyChanges(isA(DomainChildrenChanged.class));
        verify(domainNotifications, never()).notifyChanges(new DomainParticipationDeleted(DOMAIN_ID, NE_ID));
    }

    @Test
    public void delete_withSiblings_domainRemovalFails() throws Exception {

        final NeEntity entity = buildNeEntity(NE_ID, ActualActivationState.DISCONNECTED, RequiredActivationState.INACTIVE);
        final DomainInfoData domain = new DomainInfoData(DOMAIN_ID, VERSION, "domain");
        final Iterable<Integer> siblings = ImmutableList.of(56);

        when(neRepo.queryNe(NE_ID)).thenReturn(Optional.of(entity));
        when(domainRepo.queryAllForNE(NE_ID)).thenReturn(Collections.singleton(domain));
        when(domainRepo.queryChildrenNEs(DOMAIN_ID)).thenReturn(siblings);
        when(domainRepo.tryRemoveNaturalNE(DOMAIN_ID, NE_ID)).thenReturn(false);
        when(domainRepo.tryRemoveTransitiveNE(DOMAIN_ID, NE_ID)).thenReturn(false);

        new DeleteNetworkElement<>(context, neManagers, domainRepo, domainNotifications, settingsRepository, loggerManager, NE_ID)
            .call();

        // direct consequences
        verify(domainRepo).tryRemoveTransitiveNE(DOMAIN_ID, NE_ID);
        verify(domainRepo).tryRemoveNaturalNE(DOMAIN_ID, NE_ID);
        verify(neRepo).delete(new NeDeleteDescriptor(NE_ID));
        verify(notif).notifyDelete(entity);
        verify(loggerManager).createCommandLog(any(CallContext.class), any(LoggerItemNe[].class));
        verify(neInstanceRepo).remove(PHYSICAL_NE_ID);

        // side effects
        verify(domainNotifications, never()).notifyDelete(isA(DomainInfoData.class));
        verify(domainNotifications, never()).notifyChanges(isA(DomainChildrenChanged.class));
        verify(domainNotifications, never()).notifyChanges(new DomainParticipationDeleted(DOMAIN_ID, NE_ID));
        verify(domainNotifications, never()).notifyChanges(new DomainParticipationDeleted(DOMAIN_ID, 56));
    }

    @Test
    public void delete_unknownNeId_ignores() throws Exception {

        when(neRepo.queryNe(NE_ID)).thenReturn(Optional.empty());

        new DeleteNetworkElement<>(context, neManagers, domainRepo, domainNotifications, settingsRepository, loggerManager, NE_ID)
            .call();

        verify(neRepo, never()).delete(new NeDeleteDescriptor(NE_ID));
        verifyZeroInteractions(domainRepo, notif, loggerManager, domainNotifications, neInstanceRepo);
    }

    @Test(expected=IllegalNetworkElementStateException.class)
    public void delete_connectedNe_throws() throws Exception {

        final NeEntity entity = buildNeEntity(NE_ID, ActualActivationState.CONNECTED, RequiredActivationState.INACTIVE);

        when(neRepo.queryNe(NE_ID)).thenReturn(Optional.of(entity));

        new DeleteNetworkElement<>(context, neManagers, domainRepo, domainNotifications, settingsRepository, loggerManager, NE_ID)
            .call();
    }

    @Test(expected=IllegalNetworkElementStateException.class)
    public void delete_activeNe_throws() throws Exception {

        final NeEntity entity = buildNeEntity(NE_ID, ActualActivationState.DISCONNECTED, RequiredActivationState.ACTIVE);

        when(neRepo.queryNe(NE_ID)).thenReturn(Optional.of(entity));

        new DeleteNetworkElement<>(context, neManagers, domainRepo, domainNotifications, settingsRepository, loggerManager, NE_ID)
            .call();
    }

}
