package com.ossnms.dcn_manager.commands.mediator;

import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Before;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorInfoRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalDataRepository;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public abstract class MediatorTestBase {

    protected CallContext context;
    protected StaticConfiguration staticConfig;
    protected Types<MediatorType> mediatorTypes;
    protected MediatorEntityRepository repo;
    protected MediatorInfoRepository infoRepo;
    protected MediatorNotifications notif;
    protected MediatorSchedulingConfiguration mediatorScheduling;
    protected MessageSource<MediatorEvent> mediatorEvents;
    protected MediatorManagers mediatorManagers;
    protected LoggerManager<CallContext> loggerManager;
    protected MediatorInteractionManager mediatorActivationManager;
    protected MediatorInstanceEntityRepository physicalMediatorRepository;
    protected MediatorPhysicalConnectionRepository physicalConnectionRepository;
    protected MediatorPhysicalDataRepository physicalDataRepository;
    protected MediatorConnectionRepository mediatorConnectionRepository;

    protected static final int MEDIATOR_ID = 1;
    protected static final int VERSION = 1;
    protected static final int CONCURRENT_ACTIVATIONS_LIMIT = 54;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws RepositoryException {
        context = mock(CallContext.class);
        mediatorTypes = mock(Types.class);
        staticConfig = mock(StaticConfiguration.class);
        repo = mock(MediatorEntityRepository.class);
        infoRepo = mock(MediatorInfoRepository.class);
        notif = mock(MediatorNotifications.class);
        loggerManager = mock(LoggerManager.class);
        mediatorScheduling = mock(MediatorSchedulingConfiguration.class);
        mediatorEvents = mock(MessageSource.class);
        mediatorActivationManager = mock(MediatorInteractionManager.class);
        physicalConnectionRepository = mock(MediatorPhysicalConnectionRepository.class);
        physicalDataRepository = mock(MediatorPhysicalDataRepository.class);
        physicalMediatorRepository = mock(MediatorInstanceEntityRepository.class);
        mediatorConnectionRepository = mock(MediatorConnectionRepository.class);

        when(staticConfig.getMediatorTypes()).thenReturn(mediatorTypes);

        when(repo.getMediatorInfoRepository()).thenReturn(infoRepo);
        
        when(repo.getMediatorConnectionRepository()).thenReturn(mediatorConnectionRepository);

        when(physicalMediatorRepository.getMediatorPhysicalConnectionRepository()).thenReturn(physicalConnectionRepository);
        when(physicalMediatorRepository.getMediatorPhysicalDataRepository()).thenReturn(physicalDataRepository);

        when(infoRepo.query(anyString())).thenReturn(Optional.<MediatorInfoData>empty());
        
        when(mediatorConnectionRepository.query(anyInt())).thenReturn(Optional.<MediatorConnectionData>empty());
        
        mediatorManagers = new MediatorManagers(repo, physicalMediatorRepository, notif, mediatorActivationManager, mediatorEvents);
    }

    protected MediatorInfoData newInfo(boolean activationRequired) {
        return newInfoBuilder(activationRequired)
            .build(MEDIATOR_ID, VERSION);
    }

    protected MediatorInfoBuilder newInfoBuilder(boolean activationRequired) {
        return new MediatorInfoBuilder()
            .setName("name")
            .setTypeName("type")
            .setDescription(Optional.of(""))
            .setActivationRequired(activationRequired)
            .setConcurrentActivationsLimited(true)
            .setConcurrentActivationsLimit(CONCURRENT_ACTIVATIONS_LIMIT);
    }

}
