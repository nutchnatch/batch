package com.ossnms.dcn_manager.commands.container;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class ModifyContainersTest {

    public static final String EXISTS = "exists";
    private CallContext context;
    private ContainerRepository containerRepository;
    private SystemRepository systemRepository;
    private LoggerManager<CallContext> loggerManager;
    private ContainerNotifications containerNotifications;

    @SuppressWarnings("unchecked") @Before public void setUp() throws RepositoryException {
        context = mock(CallContext.class);
        containerRepository = mock(ContainerRepository.class);
        loggerManager = mock(LoggerManager.class);
        containerNotifications = mock(ContainerNotifications.class);
        systemRepository = mock(SystemRepository.class);

        when(systemRepository.queryByName(anyString())).thenReturn(Optional.empty());
    }

    @Test public void update() throws Exception {
        final ImmutableList<ContainerInfoMutationDescriptor> changes = ImmutableList
                .of(new ContainerInfoMutationDescriptor(new ContainerInfo(1, 1, "c1"))
                                .setDescription(Optional.of("d1")),
                        new ContainerInfoMutationDescriptor(new ContainerInfo(2, 1, "c2"))
                                .setDescription(Optional.of("d2")));

        when(containerRepository.tryUpdate(isA(ContainerInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        new ModifyContainers<>(context, containerRepository, systemRepository, containerNotifications, loggerManager, changes).call();

        verify(containerRepository).tryUpdate(changes.get(0));
        verify(containerRepository).tryUpdate(changes.get(1));

        verify(containerNotifications).notifyChanges(changes.get(0));
        verify(containerNotifications).notifyChanges(changes.get(1));

        verify(loggerManager, times(2)).createCommandLog(eq(context), isA(LoggerItemContainer.class));
    }

    @Test public void update_repoError_throws() throws Exception {
        final ImmutableList<ContainerInfoMutationDescriptor> changes = ImmutableList
                .of(new ContainerInfoMutationDescriptor(new ContainerInfo(1, 1, "c1"))
                        .setDescription(Optional.of("d1")));

        when(containerRepository.tryUpdate(isA(ContainerInfoMutationDescriptor.class)))
                .thenThrow(new RepositoryException());

        try {
            new ModifyContainers<>(context, containerRepository, systemRepository, containerNotifications, loggerManager, changes).call();
            fail("Should have thrown exception.");
        } catch (final CommandException e) {
            // good
        }

        verifyZeroInteractions(containerNotifications);

        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemContainer.class));
    }

    @Test public void update_concurrentUpdate_throws() throws Exception {
        final ImmutableList<ContainerInfoMutationDescriptor> changes = ImmutableList
                .of(new ContainerInfoMutationDescriptor(new ContainerInfo(1, 1, "c1"))
                        .setDescription(Optional.of("d1")));

        when(containerRepository.tryUpdate(isA(ContainerInfoMutationDescriptor.class)))
                .thenReturn(Optional.<ContainerInfo>empty());

        try {
            new ModifyContainers<>(context, containerRepository, systemRepository, containerNotifications, loggerManager, changes).call();
            fail("Should have thrown exception.");
        } catch (final CommandException e) {
            // good
        }

        verifyZeroInteractions(containerNotifications);

        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemContainer.class));
    }

    @Test public void update_partialFailure_throws() throws Exception {
        final ImmutableList<ContainerInfoMutationDescriptor> changes = ImmutableList
                .of(new ContainerInfoMutationDescriptor(new ContainerInfo(1, 1, "c1"))
                                .setDescription(Optional.of("d1")),
                        new ContainerInfoMutationDescriptor(new ContainerInfo(2, 1, "c2"))
                                .setDescription(Optional.of("d2")));

        when(containerRepository.tryUpdate(changes.get(0))).thenThrow(new RepositoryException());
        when(containerRepository.tryUpdate(changes.get(1))).then(new MutationAnswer<>());

        try {
            new ModifyContainers<>(context, containerRepository, systemRepository,  containerNotifications, loggerManager, changes).call();
            fail("Should have thrown exception.");
        } catch (final CommandException e) {
            // good
        }

        verify(containerRepository).tryUpdate(changes.get(0));
        verify(containerRepository).tryUpdate(changes.get(1));

        verify(containerNotifications, never()).notifyChanges(changes.get(0));
        verify(containerNotifications).notifyChanges(changes.get(1));

        verify(loggerManager, times(2)).createCommandLog(eq(context), isA(LoggerItemContainer.class));
    }

    @Test(expected = IllegalArgumentException.class)
    public void create_empty_name_throws()
            throws CommandException, RepositoryException {
        final ImmutableList<ContainerInfoMutationDescriptor> changes = ImmutableList
                .of(new ContainerInfoMutationDescriptor(new ContainerInfo(1, 1, "")).setDescription(Optional.of("d1")),
                        new ContainerInfoMutationDescriptor(new ContainerInfo(2, 1, EXISTS))
                                .setDescription(Optional.of("d2")));

        try {
            new ModifyContainers<>(context, containerRepository, systemRepository, containerNotifications, loggerManager, changes).call();
            fail("Should have thrown exception.");
        } catch (final CommandException e) {
            // good
        }
    }

    @Test(expected = CommandException.class)
    public void create_duplicated_container_name_throws()
            throws CommandException, RepositoryException {
        final ContainerInfoMutationDescriptor containerInfoMutationDescriptor = new ContainerInfoMutationDescriptor(
                new ContainerInfo(1, 1, EXISTS)).setDescription(Optional.of("d1"));

        containerInfoMutationDescriptor.setName(EXISTS);

        when(containerRepository.queryByName(EXISTS)).thenReturn(Optional.of(new ContainerInfo(1, 1, EXISTS)));

        new ModifyContainers<>(context, containerRepository, systemRepository, containerNotifications, loggerManager,
                ImmutableList.of(containerInfoMutationDescriptor)).call();

    }
}

