package com.ossnms.dcn_manager.commands.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelConnectionRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public abstract class ChannelTestBase {

    protected CallContext context;
    protected StaticConfiguration staticConfig;
    protected Types<ChannelType> channelTypes;
    protected ChannelEntityRepository repo;
    protected ChannelInfoRepository infoRepo;
    protected ChannelConnectionRepository connectionRepo;
    protected ChannelUserPreferencesRepository userPrefsRepo;
    protected ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    protected ChannelSchedulingConfiguration channelScheduling;
    protected ChannelNotifications notif;
    protected LoggerManager<CallContext> loggerManager;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws RepositoryException {
        context = mock(CallContext.class);
        channelTypes = mock(Types.class);
        staticConfig = mock(StaticConfiguration.class);
        repo = mock(ChannelEntityRepository.class);
        infoRepo = mock(ChannelInfoRepository.class);
        connectionRepo = mock(ChannelConnectionRepository.class);
        userPrefsRepo = mock(ChannelUserPreferencesRepository.class);
        when(repo.getChannelInfoRepository()).thenReturn(infoRepo);
        when(repo.getChannelConnectionRepository()).thenReturn(connectionRepo);
        when(repo.getChannelUserPreferencesRepository()).thenReturn(userPrefsRepo);
        notif = mock(ChannelNotifications.class);
        loggerManager = mock(LoggerManager.class);
        channelScheduling = mock(ChannelSchedulingConfiguration.class);
        channelPhysicalConnectionRepository = mock(ChannelPhysicalConnectionRepository.class);

        when(staticConfig.getChannelTypes()).thenReturn(channelTypes);

        when(userPrefsRepo.tryUpdate(any(ChannelUserPreferencesMutationDescriptor.class)))
            .then(new MutationAnswer<ChannelUserPreferencesData>());
    }

}
