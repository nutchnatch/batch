package com.ossnms.dcn_manager.commands.domain;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemDomain;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.domain.DomainNeActivationPolicyChanged;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class SetAutomaticNeActivationDomainPolicyTest {

    private static final int DOMAIN_ID = 1;
    private static final int VERSION = 1;
    private static final String DOMAIN_NAME = "domain";

    private DomainRepository domainRepository;
    private DomainNotifications domainNotifications;
    private LoggerManager<CallContext> loggerManager;
    private CallContext context;
    private NeEntityRepository neRepo;
    private NePhysicalConnectionRepository neInstanceRepo;
    private NetworkElementInteractionManager neInteractionManager;
    private NetworkElementNotifications neNotifs;
    
    private NetworkElementManagers neManagers;
    
    private ChannelEntityRepository channelEntityRepository;
    private ChannelPhysicalConnectionRepository physicalChannelRepository;
    private ChannelNotifications channelNotifications;
    private ChannelInteractionManager channelInteractionManager;
    private ChannelManagers channelManagers;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        domainRepository = mock(DomainRepository.class);
        domainNotifications = mock(DomainNotifications.class);
        loggerManager = mock(LoggerManager.class);
        context = mock(CallContext.class);
        
        neRepo = mock(NeEntityRepository.class);
        neInstanceRepo = mock(NePhysicalConnectionRepository.class);
        neInteractionManager = mock(NetworkElementInteractionManager.class);
        neNotifs = mock(NetworkElementNotifications.class);        
        neManagers = new NetworkElementManagers(neRepo, neInstanceRepo, neInteractionManager, neNotifs, null);

        channelEntityRepository = mock(ChannelEntityRepository.class);
        physicalChannelRepository = mock(ChannelPhysicalConnectionRepository.class);
        channelNotifications = mock(ChannelNotifications.class);
        channelInteractionManager = mock(ChannelInteractionManager.class);
        channelManagers = new ChannelManagers(channelEntityRepository, physicalChannelRepository, channelNotifications, channelInteractionManager, null);
    }

    @Test
    public void domainDoesNotExist_throws() throws Exception {
        when(domainRepository.query(anyInt())).thenReturn(Optional.empty());

        try {
            new SetAutomaticNeActivationDomainPolicy<>(context, neManagers, channelManagers, domainRepository, domainNotifications, loggerManager, Collections.singleton(DOMAIN_ID), false)
                .call();
            fail("No exception on unknown domain.");
        } catch (final CommandException e) {
            // ok
        }

        verifyZeroInteractions(domainNotifications, loggerManager);
    }

    @Test
    public void domainQuery_repoError_throws() throws Exception {
        when(domainRepository.query(anyInt())).thenThrow(new RepositoryException());

        try {
            new SetAutomaticNeActivationDomainPolicy<>(context, neManagers, channelManagers, domainRepository, domainNotifications, loggerManager, Collections.singleton(DOMAIN_ID), false)
                .call();
            fail("No exception on unknown domain.");
        } catch (final CommandException e) {
            // ok
        }

        verifyZeroInteractions(domainNotifications, loggerManager);
    }

    @Test
    public void concurrentUpdate_logsAndThrows() throws Exception {

        when(domainRepository.query(DOMAIN_ID)).thenReturn(Optional.of(new DomainInfoData(DOMAIN_ID, VERSION, DOMAIN_NAME)));
        when(domainRepository.tryUpdate(isA(DomainInfoMutationDescriptor.class))).thenReturn(Optional.empty());

        try {
            new SetAutomaticNeActivationDomainPolicy<>(context, neManagers, channelManagers, domainRepository, domainNotifications, loggerManager, Collections.singleton(DOMAIN_ID), false)
                .call();
            fail("No exception on concurrent update.");
        } catch (final CommandException e) {
            // ok
        }

        verifyZeroInteractions(domainNotifications);
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemDomain.class));
    }

    @Test
    public void errorOnUpdate_logsAndThrows() throws Exception {

        when(domainRepository.query(DOMAIN_ID)).thenReturn(Optional.of(new DomainInfoData(DOMAIN_ID, VERSION, DOMAIN_NAME)));
        when(domainRepository.tryUpdate(isA(DomainInfoMutationDescriptor.class))).thenThrow(new RepositoryException());

        try {
            new SetAutomaticNeActivationDomainPolicy<>(context, neManagers, channelManagers, domainRepository, domainNotifications, loggerManager, Collections.singleton(DOMAIN_ID), false)
                .call();
            fail("No exception on concurrent update.");
        } catch (final CommandException e) {
            // ok
        }

        verifyZeroInteractions(domainNotifications);
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemDomain.class));
    }

    @Test
    public void policyChanged() throws Exception {

        when(domainRepository.query(DOMAIN_ID)).thenReturn(Optional.of(new DomainInfoData(DOMAIN_ID, VERSION, DOMAIN_NAME, false)));
        when(domainRepository.tryUpdate(isA(DomainInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        new SetAutomaticNeActivationDomainPolicy<>(context, neManagers, channelManagers, domainRepository, domainNotifications, loggerManager, Collections.singleton(DOMAIN_ID), true)
            .call();

        final ArgumentCaptor<DomainInfoMutationDescriptor> captor = ArgumentCaptor.forClass(DomainInfoMutationDescriptor.class);

        verify(domainRepository).tryUpdate(captor.capture());
        verify(domainNotifications).notifyChanges(new DomainNeActivationPolicyChanged(DOMAIN_ID, true));
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemDomain.class));

        assertThat(captor.getValue().getAutomaticNeActivationPermitted(), hasValue(true));
    }

    @Test
    public void twoUpdates_oneFails_updatesOther_throws() throws Exception {

        when(domainRepository.query(999)).thenReturn(Optional.empty());
        when(domainRepository.query(DOMAIN_ID)).thenReturn(Optional.of(new DomainInfoData(DOMAIN_ID, VERSION, DOMAIN_NAME, false)));
        when(domainRepository.tryUpdate(isA(DomainInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        try  {
            new SetAutomaticNeActivationDomainPolicy<>(context, neManagers, channelManagers, domainRepository, domainNotifications, loggerManager,
                    ImmutableList.of(999, DOMAIN_ID), true)
                .call();
            fail("No exception on partial failure.");
        } catch (final CommandException e) {
            // ok
        }

        final ArgumentCaptor<DomainInfoMutationDescriptor> captor = ArgumentCaptor.forClass(DomainInfoMutationDescriptor.class);

        verify(domainRepository).tryUpdate(captor.capture());
        verify(domainNotifications).notifyChanges(new DomainNeActivationPolicyChanged(DOMAIN_ID, true));
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemDomain.class));

        assertThat(captor.getValue().getTarget().getId(), is(DOMAIN_ID));
        assertThat(captor.getValue().getAutomaticNeActivationPermitted(), hasValue(true));

    }
}
