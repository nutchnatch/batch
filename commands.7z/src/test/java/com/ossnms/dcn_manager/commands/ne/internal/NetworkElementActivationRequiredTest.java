package com.ossnms.dcn_manager.commands.ne.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.ne.NeTestBase;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.*;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelConnectionRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.IllegalNetworkElementStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.*;

public class NetworkElementActivationRequiredTest extends NeTestBase {

    private NetworkElementInteractionManager activationScheduler;
	private NetworkElementNotifications eventDispatcher;

    private ChannelPhysicalConnectionRepository channelInstanceRepository;
	private ChannelEntityRepository channelRepository;
	private ChannelConnectionRepository channelConnectionRepository;

    private static final int MEDIATOR_INSTANCE_ID = 880;
	private static final int NE_ID = 10;
	private static final int NE_INSTANCE_ID = 100;
	private static final int STANDBY_NE_INSTANCE_ID = 110;
	private static final int CHANNEL_ID = 20;
	private static final int CHANNEL_INSTANCE_ID = 200;
	private static final int STANDBY_CHANNEL_INSTANCE_ID = 210;
	private static final int VERSION = 1;

    private final ChannelConnectionData activeChannel =
            new ChannelConnectionBuilder().setActivation(ActualActivationState.ACTIVE).build(CHANNEL_ID, VERSION);
    private final ChannelConnectionData inactiveChannel =
            new ChannelConnectionBuilder().setActivation(ActualActivationState.INACTIVE).build(CHANNEL_ID, VERSION);

    private NetworkElementManagers neManagers;

	@Override
    @Before
	public void setUp() throws RepositoryException
    {
		super.setUp();
        activationScheduler = mock(NetworkElementInteractionManager.class);
		eventDispatcher = mock(NetworkElementNotifications.class);

		channelInstanceRepository = mock(ChannelPhysicalConnectionRepository.class);

		channelConnectionRepository = mock(ChannelConnectionRepository.class);
		channelRepository = mock(ChannelEntityRepository.class);

		when(channelRepository.getChannelConnectionRepository()).thenReturn(channelConnectionRepository);

		when(neRepo.queryNeName(NE_ID)).thenReturn(Optional.of("name"));

        when(synchronizationRepo.query(anyInt())).thenReturn(Optional.empty());

		neManagers = new NetworkElementManagers(neRepo, neInstanceRepo, activationScheduler, eventDispatcher, null);
    }

    private NeInfoData createInfo(RequiredActivationState requiredState) {
        return new NeInfoBuilder()
                    .setRequiredActivationState(requiredState)
                    .setProxyType("proxy")
                    .build(NE_ID, CHANNEL_ID, VERSION);
    }

    private NePhysicalConnectionData createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState actualState) {
        return new NePhysicalConnectionBuilder()
                    .setActive(true)
                    .setActivationState(actualState)
                    .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION);
    }

    private ChannelPhysicalConnectionData createChannelPhysicalConnection(ActualActivationState actualState) {
        return new ChannelPhysicalConnectionBuilder()
                    .setActivation(actualState)
                    .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
    }

	@Test(expected=UnknownNetworkElementIdException.class)
	public void activate_withNonExistingNetworkElementId_throwsException() throws Exception
	{
		// Set up repository stub (Arrange)
    	when(infoRepo.query(NE_ID)).thenReturn(Optional.empty());

    	// Execute command (Act)
		new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

    @Test(expected=UnknownChannelIdException.class)
    public void activate_withNonExistingChannelConnectionId_throwsException() throws Exception
    {
        // Set up repository stub (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.ACTIVE)));
        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.empty());

        // Execute command (Act)
        new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

    @Test
    public void activate_onAnActualActivatedNetworkElement_ignores() throws Exception
    {

        // Set up repository and mediator entity stubs (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.INACTIVE)));
        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(Collections.singleton(createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.INITIALIZED)));
        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(createChannelPhysicalConnection(ActualActivationState.ACTIVE)));

        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        try {
            // Execute command (Act)
            new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();
            fail("Should throw an IllegalNetworkElementStateException");
        } catch (IllegalNetworkElementStateException e) {
            // (good)
        }

        // Verify no changes (Assert)
        verifyZeroInteractions(activationScheduler);
    }

    @Test(expected=IllegalNetworkElementStateException.class)
    public void activate_onAConcurrentlyActuallyActivatedNetworkElement_throwsException() throws Exception
    {
        // Set up repository stub (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.INACTIVE)));

        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class)))
            .thenReturn(Optional.empty());

        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(Collections.singleton(createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.INITIALIZED)));
        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(createChannelPhysicalConnection(ActualActivationState.ACTIVE)));

        // Execute command (Act)
        new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

	@Test(expected=IllegalNetworkElementStateException.class)
	public void activate_onAnActivatedNetworkElement_throwsException() throws Exception
	{
		// Set up repository and entity stubs (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.ACTIVE)));
        when(neInstanceRepo.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
		when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));

        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(Collections.singleton(createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)));
        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(createChannelPhysicalConnection(ActualActivationState.ACTIVE)));

    	// Execute command (Act)
		new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

	@Test(expected=IllegalNetworkElementStateException.class)
	public void activate_onAConcurrentlyActivatedNetworkElement_throwsException() throws Exception
	{
		// Set up repository stub (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.ACTIVE)));

		when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class)))
			.thenReturn(Optional.empty());

		when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));

        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(Collections.singleton(createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)));
        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(createChannelPhysicalConnection(ActualActivationState.ACTIVE)));

        when(neInstanceRepo.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).thenReturn(Optional.empty());

		// Execute command (Act)
		new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

	@Test
	public void activate_onADeactivatedNetworkElement_activatesItAndTriggersConnectionEstablishment() throws Exception
	{
		// Set up repository and mediator entity stubs (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.INACTIVE)));

        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());
        when(neInstanceRepo.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));

        final NePhysicalConnectionData standbyNeInstance = new NePhysicalConnectionBuilder()
                .setActive(false)
                .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)
                .build(STANDBY_NE_INSTANCE_ID, NE_ID, STANDBY_CHANNEL_INSTANCE_ID, VERSION);

        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(ImmutableList.of(
                standbyNeInstance,
                createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)));
        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(createChannelPhysicalConnection(ActualActivationState.ACTIVE)));

        final NeSynchronizationBuilder originalSynchronizationBuilder =
                new NeSynchronizationBuilder().setAlarms(Optional.of(1L)).setAll(Optional.of(2L)).setPacket(Optional.of(3L));
        when(synchronizationRepo.query(NE_ID)).thenReturn(Optional.of(
                originalSynchronizationBuilder.build(NE_ID, 0)
        ));
        when(synchronizationRepo.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

    	// Execute command (Act)
		new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

		// Verify mediator state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
		final ArgumentCaptor<NeInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);
		verify(infoRepo).tryUpdate(argsCaptor.capture());

		assertThat(argsCaptor.getValue().getRequiredActivationState().get(), is(RequiredActivationState.ACTIVE));

		verify(activationScheduler).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));
        verify(activationScheduler, never()).scheduleActivation(new Activate(NE_ID, STANDBY_CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, STANDBY_NE_INSTANCE_ID, false));
		verify(eventDispatcher).notifyChanges(new Activate(NE_ID, 0, 0, 0, false));

		verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));

        verify(synchronizationRepo).tryUpdate(eq(new NeSynchronizationMutationDescriptor(originalSynchronizationBuilder.build(NE_ID, 0)).clearCounters()));
	}

    @Test
    @SuppressWarnings("unchecked")
    public void activate_onADeactivatedNetworkElement_withConcurrentInfoUpdate_retriesAndActivatesItAndTriggersConnectionEstablishment() throws Exception
    {
        // Set up repository and mediator entity stubs (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.INACTIVE)));

        when(neInstanceRepo.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class)))
                .thenReturn(Optional.empty())
                .then(new MutationAnswer<>());

        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));

        final NePhysicalConnectionData standbyNeInstance = new NePhysicalConnectionBuilder()
                .setActive(false)
                .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)
                .build(STANDBY_NE_INSTANCE_ID, NE_ID, STANDBY_CHANNEL_INSTANCE_ID, VERSION);

        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(
            ImmutableList.of(
                standbyNeInstance,
                createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)),
            ImmutableList.of(
                standbyNeInstance,
                createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.STARTUP))); // for the retry
        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(createChannelPhysicalConnection(ActualActivationState.ACTIVE)));

        // Execute command (Act)
        new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

        // Verify mediator state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        final ArgumentCaptor<NeInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);
        verify(infoRepo, times(2)).tryUpdate(argsCaptor.capture()); // notice the retry

        assertThat(argsCaptor.getValue().getRequiredActivationState().get(), is(RequiredActivationState.ACTIVE));

        verify(activationScheduler).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));
        verify(activationScheduler, never()).scheduleActivation(new Activate(NE_ID, STANDBY_CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, STANDBY_NE_INSTANCE_ID, false));
        verify(eventDispatcher).notifyChanges(new Activate(NE_ID, 0, 0, 0, false));

        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
    }

    @Test
    public void activate_onADeactivatedNetworkElement_withStandby_activatesOnlyActiveAndTriggersConnectionEstablishment() throws Exception
    {
        // Set up repository and mediator entity stubs (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.INACTIVE)));

        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());
        when(neInstanceRepo.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));

        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(Collections.singleton(
                createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)));
        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(createChannelPhysicalConnection(ActualActivationState.ACTIVE)));

        // Execute command (Act)
        new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

        // Verify mediator state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        final ArgumentCaptor<NeInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);
        verify(infoRepo).tryUpdate(argsCaptor.capture());

        assertThat(argsCaptor.getValue().getRequiredActivationState().get(), is(RequiredActivationState.ACTIVE));

        verify(activationScheduler).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));
        verify(eventDispatcher).notifyChanges(new Activate(NE_ID, 0, 0, 0, false));

        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
    }

    @Test
    public void activate_onADeactivatedNetworkElementAndInactiveChannel_activatesItAndDoesNotTriggerConnectionEstablishment() throws Exception
    {
        // Set up repository and mediator entity stubs (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.INACTIVE)));

        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class)))
            .thenAnswer(new MutationAnswer<>());

        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(Collections.singleton(createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)));
        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(inactiveChannel));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(createChannelPhysicalConnection(ActualActivationState.INACTIVE)));

        // Execute command (Act)
        new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

        // Verify mediator state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        final ArgumentCaptor<NeInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);
        verify(infoRepo).tryUpdate(argsCaptor.capture());

        assertThat(argsCaptor.getValue().getRequiredActivationState().get(), is(RequiredActivationState.ACTIVE));

        verify(activationScheduler, never()).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));
        verify(eventDispatcher).notifyChanges(new Activate(NE_ID, 0, 0, 0, false));

        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
    }

    @Test
    public void activate_onADeactivatedNetworkElementAndInactiveChannelInstance_activatesItAndDoesNotTriggerConnectionEstablishment() throws Exception
    {
        // Set up repository and mediator entity stubs (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.INACTIVE)));

        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class)))
            .thenAnswer(new MutationAnswer<>());

        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(Collections.singleton(createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)));
        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(createChannelPhysicalConnection(ActualActivationState.INACTIVE)));

        // Execute command (Act)
        new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

        // Verify mediator state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        final ArgumentCaptor<NeInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);
        verify(infoRepo).tryUpdate(argsCaptor.capture());

        assertThat(argsCaptor.getValue().getRequiredActivationState().get(), is(RequiredActivationState.ACTIVE));

        verify(activationScheduler, never()).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));
        verify(eventDispatcher).notifyChanges(new Activate(NE_ID, 0, 0, 0, false));

        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
    }

    @Test
    public void activate_onADeactivatedNetworkElementAndAbsentChannelInstance_doesNotActivateItAndDoesNotTriggerConnectionEstablishment() throws Exception
    {
        // Set up repository and mediator entity stubs (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.INACTIVE)));

        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class)))
            .thenAnswer(new MutationAnswer<>());

        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(Collections.singleton(createPhysicalConnection(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)));
        when(channelConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(activeChannel));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        try {
            // Execute command (Act)
            new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();
            fail("Should throw an IllegalNetworkElementStateException");
        } catch (IllegalNetworkElementStateException e) {
            // (good)
        }

        // Verify mediator state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        verify(infoRepo, never()).tryUpdate(isA(NeInfoMutationDescriptor.class));

        verify(activationScheduler, never()).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(eventDispatcher, never()).notifyChanges(new Activate(NE_ID, 0, 0, 0, false));

        verify(loggerManager, never()).createCommandLog(eq(context), any(LoggerItem[].class));
    }

	@Test(expected=RepositoryException.class)
	public void activate_whenNeRepositoryThrowsException_throwsRepositoryException() throws Exception
	{
		// Set up repository stub (Arrange)
	    when(infoRepo.query(NE_ID)).thenThrow(new RepositoryException());

    	// Execute command (Act)
		new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

    @Test(expected=RepositoryException.class)
    public void activate_whenChannelConnectionRepositoryThrowsException_throwsRepositoryException() throws Exception
    {
        // Set up repository stub (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(createInfo(RequiredActivationState.ACTIVE)));
        when(channelConnectionRepository.query(CHANNEL_ID)).thenThrow(new RepositoryException());

        // Execute command (Act)
        new NetworkElementActivationRequired<>(context, NE_ID, neManagers, channelRepository, channelInstanceRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

}
