package com.ossnms.dcn_manager.commands.container;

import static org.mockito.Mockito.mock;

import org.junit.Before;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public abstract class ContainerTestBase {

    protected CallContext context;
    protected StaticConfiguration staticConfig;
    protected ContainerRepository repo;
    protected LoggerManager<CallContext> loggerManager;

    protected static final int CONTAINER_ID = 1;
    protected static final int VERSION = 1;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws RepositoryException {
        context = mock(CallContext.class);
        staticConfig = mock(StaticConfiguration.class);
        repo = mock(ContainerRepository.class);
        loggerManager = mock(LoggerManager.class);
    }

    protected ContainerInfo newInfo() {
        return new ContainerInfo(CONTAINER_ID, VERSION, "name");
    }

}
