package com.ossnms.dcn_manager.commands.mediator;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.Test;

import com.ossnms.dcn_manager.commands.mediator.GetAllMediators;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public class GetAllMediatorsTest extends MediatorTestBase {

    @Test
    public void testGetMediators() throws RepositoryException {
        final Iterable<MediatorEntity> results = Collections.emptyList();
        when(repo.queryAll()).thenReturn(results);

        final Iterable<MediatorEntity> iterable = new GetAllMediators<>(null, repo).call();

        assertThat(iterable, is(results));
    }

    @Test(expected=RepositoryException.class)
    public void testGetMediators_withRepositoryError() throws RepositoryException {

        when(repo.queryAll()).thenThrow(new RepositoryException());

        new GetAllMediators<>(null, repo).call();
    }

}
