package com.ossnms.dcn_manager.commands.ne.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeSynchronizationRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class ResynchronizeNetworkElementsTest {

    private static final int MEDIATOR_INSTANCE_ID = 987;
    private static final int NE_ID = 1;
    private static final int NE_INSTANCE_ID = 1;
    private static final int VERSION = 0;
    private static final String NE_NAME = "neName";
    private static final String NE_TYPE = "type-name";
    private static final int CHANNEL_INSTANCE_ID = 3;
    private static final int CHANNEL_ID = 30;

    private NePhysicalConnectionRepository neInstanceRepository;
    private NeInfoRepository infoRepository;
    private NeUserPreferencesRepository preferencesRepository;
    private NeSynchronizationRepository synchronizationRepository;
    private NeConnectionRepository connectionRepository;
    private LoggerManager<CallContext> loggerManager;
    private CallContext context;
    private NetworkElementInteractionManager interactionManager;
    private ChannelPhysicalConnectionRepository channelInstanceRepository;

    private NetworkElementManagers neManagers;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        final NeEntityRepository neEntityRepository = mock(NeEntityRepository.class);
        final NetworkElementNotifications notifications = mock(NetworkElementNotifications.class);

        context = mock(CallContext.class);
        loggerManager = mock(LoggerManager.class);
        infoRepository = mock(NeInfoRepository.class);
        preferencesRepository = mock(NeUserPreferencesRepository.class);
        neInstanceRepository = mock(NePhysicalConnectionRepository.class);
        connectionRepository = mock(NeConnectionRepository.class);
        synchronizationRepository = mock(NeSynchronizationRepository.class);
        interactionManager = mock(NetworkElementInteractionManager.class);

        channelInstanceRepository = mock(ChannelPhysicalConnectionRepository.class);

        when(neEntityRepository.getNeInfoRepository()).thenReturn(infoRepository);
        when(neEntityRepository.getNeUserPreferencesRepository()).thenReturn(preferencesRepository);
        when(neEntityRepository.getNeConnectionRepository()).thenReturn(connectionRepository);
        when(neEntityRepository.getNeSynchronizationRepository()).thenReturn(synchronizationRepository);

        neManagers = new NetworkElementManagers(neEntityRepository, neInstanceRepository, interactionManager, notifications, null);
    }

    @Test
    public void resynchronization_successful() throws Exception {

        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));
        final NeSynchronizationBuilder originalSynchronizationBuilder =
                new NeSynchronizationBuilder().setAlarms(Optional.of(1L)).setAll(Optional.of(2L)).setPacket(Optional.of(3L));
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.of(
                originalSynchronizationBuilder.build(NE_ID, 0)
        ));

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)));

        when(connectionRepository.tryUpdate(isA(NeConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(synchronizationRepository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
            Collections.singleton(NE_ID))
                .call();

        verify(synchronizationRepository).tryUpdate(eq(new NeSynchronizationMutationDescriptor(originalSynchronizationBuilder.build(NE_ID, 0)).clearCounters()));
        verify(interactionManager).scheduleSynchronization(isA(NeSynchronizationEvent.class));
        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemNe.class));
    }

    @Test
    public void resynchronization_partiallySuccessful_throws() throws Exception {
        final ArgumentCaptor<NeSynchronizationEvent> eventCaptor = ArgumentCaptor.forClass(NeSynchronizationEvent.class);

        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeSynchronizationBuilder().setAlarms(Optional.of(1L)).setAll(Optional.of(2L)).setPacket(Optional.of(3L)).build(NE_ID, 0)
        ));

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)));

        when(connectionRepository.tryUpdate(isA(NeConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(synchronizationRepository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        when(infoRepository.query(NE_ID + 1)).thenReturn(Optional.empty());
        when(preferencesRepository.query(NE_ID + 1)).thenReturn(Optional.empty());
        when(neInstanceRepository.query(NE_ID + 1)).thenReturn(Optional.empty());

        try {
            new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
                ImmutableList.of(NE_ID + 1, NE_ID))
                    .call();
            fail("Should have thrown on partial failure.");
        } catch (final CommandException e) {
            // good
        }

        verify(interactionManager, times(1)).scheduleSynchronization(eventCaptor.capture());
        assertThat(eventCaptor.getValue().getNeId(), is(NE_ID));

        verify(loggerManager, times(2)).createCommandLog(isA(CallContext.class), isA(LoggerItemNe.class));
    }

    @Test
    public void concurrentModification_onInstance_ignores() throws Exception {

        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeSynchronizationBuilder().setAlarms(Optional.of(1L)).setAll(Optional.of(2L)).setPacket(Optional.of(3L)).build(NE_ID, 0)
        ));

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)));

        when(connectionRepository.tryUpdate(isA(NeConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).thenReturn(Optional.empty());
        when(synchronizationRepository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
            Collections.singleton(NE_ID))
                .call();

        verifyZeroInteractions(interactionManager);
        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemNe.class));
    }

    @Test
    public void neInstanceNotInitialized_ignores() throws Exception {

        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.DISCONNECTED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeSynchronizationBuilder().setAlarms(Optional.of(1L)).setAll(Optional.of(2L)).setPacket(Optional.of(3L)).build(NE_ID, 0)
        ));

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)));

        when(synchronizationRepository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());
        when(connectionRepository.tryUpdate(isA(NeConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
            Collections.singleton(NE_ID))
                .call();

        verifyZeroInteractions(interactionManager);
        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemNe.class));
    }

    @Test(expected=RepositoryException.class)
    public void neInfo_repoError_throws() throws Exception {
        when(infoRepository.query(NE_ID)).thenThrow(new RepositoryException());
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));

        new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
                Collections.singleton(NE_ID))
                    .call();
    }

    @Test
    public void neInfo_notFound_fails() throws Exception {

        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(infoRepository.query(NE_ID)).thenReturn(Optional.empty());
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));

        try {
            new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
                Collections.singleton(NE_ID))
                    .call();
            fail("Should have thrown on NE not found.");
        } catch (final CommandException e) {
            // good
        }

        verifyZeroInteractions(interactionManager);
        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemNe.class));
    }

    @Ignore /* only reactivate if the NE instance repository throws on queryAll */
    @Test(expected=RepositoryException.class)
    public void neConnection_repoError_throws() throws Exception {
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenThrow(new RepositoryException());

        new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
                Collections.singleton(NE_ID))
                    .call();
    }

    @Test
    public void nePhysicalConnection_instanceNotFound_ignores() throws Exception {

        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.emptyList());
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeSynchronizationBuilder().setAlarms(Optional.of(1L)).setAll(Optional.of(2L)).setPacket(Optional.of(3L)).build(NE_ID, 0)
        ));

        when(synchronizationRepository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());
        when(connectionRepository.tryUpdate(isA(NeConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
            Collections.singleton(NE_ID))
                .call();

        verifyZeroInteractions(interactionManager);
        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
        verify(loggerManager, never()).createCommandLog(isA(CallContext.class), isA(LoggerItemNe.class));
    }

    @Test(expected=RepositoryException.class)
    public void nePreferences_repoError_throws() throws Exception {
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenThrow(new RepositoryException());
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));

        new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
                Collections.singleton(NE_ID))
                    .call();
    }

    @Test
    public void nePreferences_notFound_fails() throws Exception {
        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.empty());
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));

        try {
            new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
                Collections.singleton(NE_ID))
                    .call();
            fail("Should have thrown on NE not found.");
        } catch (final CommandException e) {
            // good
        }

        verifyZeroInteractions(interactionManager);
        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemNe.class));
    }

    @Test(expected=RepositoryException.class)
    public void neSynchronization_repoError_throws() throws Exception {
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
        ));
        when(synchronizationRepository.query(NE_ID)).thenThrow(new RepositoryException());

        new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
                Collections.singleton(NE_ID))
                .call();
    }

    @Test
    public void neSynchronization_notFound_fails() throws Exception {
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
        ));
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.empty());

        try {
            new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
                    Collections.singleton(NE_ID))
                    .call();
            fail("Should have thrown on NE not found.");
        } catch (final CommandException e) {
            // good
        }

        verifyZeroInteractions(interactionManager);
        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemNe.class));
    }

    @Test
    public void channelNotFound_fails() throws Exception {

        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.DISCONNECTED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeSynchronizationBuilder().setAlarms(Optional.of(1L)).setAll(Optional.of(2L)).setPacket(Optional.of(3L)).build(NE_ID, 0)
        ));

        when(synchronizationRepository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());
        when(connectionRepository.tryUpdate(isA(NeConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        try {
            new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
                Collections.singleton(NE_ID))
                    .call();
            fail("Should have thrown on Channel not found.");
        } catch (final CommandException e) {
            // good
        }

        verifyZeroInteractions(interactionManager);
        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemChannel.class));
    }

    @Test(expected=RepositoryException.class)
    public void channelNotFound_repoError_throws() throws Exception {

        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.DISCONNECTED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeSynchronizationBuilder().setAlarms(Optional.of(1L)).setAll(Optional.of(2L)).setPacket(Optional.of(3L)).build(NE_ID, 0)
        ));

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenThrow(new RepositoryException());

        when(connectionRepository.tryUpdate(isA(NeConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(synchronizationRepository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        new ResynchronizeNetworkElements<>(context, neManagers, channelInstanceRepository, loggerManager,
            Collections.singleton(NE_ID))
                .call();
    }
}
