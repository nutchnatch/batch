
package com.ossnms.dcn_manager.commands.channel;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.Collections;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.emptyIterableOf;
import static org.hamcrest.Matchers.hasItems;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class GetAllRegisteredChannelsTest extends ChannelTestBase {

    private MediatorType mediatorType;
    private Types<MediatorType> mediatorTypes;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        mediatorType = mock(MediatorType.class);
        mediatorTypes = Types.from(asList(mediatorType));

        when(staticConfig.getMediatorTypes()).thenReturn(mediatorTypes);
    }

    @Test
    public void testCall() {
        final ChannelType type1 = mock(ChannelType.class);
        final ChannelType type2 = mock(ChannelType.class);
        final Collection<ChannelType> types = ImmutableList.of(type1, type2);

        when(mediatorType.getSupportedChannelTypes()).thenReturn(types);

        final Iterable<ChannelType> result = new GetAllRegisteredChannels<>(context, staticConfig).call();

        assertThat(result, hasItems(type1, type2));
    }

    @Test
    public void testCallWithoutTypes() {

        when(mediatorType.getSupportedChannelTypes()).thenReturn(Collections.emptyList());

        final Iterable<ChannelType> result = new GetAllRegisteredChannels<>(context, staticConfig).call();

        assertThat(result, emptyIterableOf(ChannelType.class));
    }

}
