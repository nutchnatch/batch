package com.ossnms.dcn_manager.commands.mediator;

import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.IllegalMediatorStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class DeleteMediatorTest extends MediatorTestBase {

    private static final int MEDIATOR_INSTANCE_ID = 1000;
    private ChannelEntityRepository channelRepository;
    private ChannelInfoRepository channelInfoRepository;

    @Override
    public void setUp() throws RepositoryException {
        super.setUp();

        channelRepository = mock(ChannelEntityRepository.class);
        channelInfoRepository = mock(ChannelInfoRepository.class);

        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
    }

    @Test
    public void testDelete() throws DcnManagerException {
        final MediatorEntity repoEntity = new MediatorEntity(
                newInfo(false),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        final MediatorInstance instanceEntity = new MediatorInstance(
                new MediatorPhysicalDataBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION),
                new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION));

        final ArgumentCaptor<MediatorDeleteDescriptor> deleteDescriptorCaptor = ArgumentCaptor.forClass(MediatorDeleteDescriptor.class);

        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(repoEntity));
        when(physicalMediatorRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(instanceEntity));

        setupChildChannel(999);

        new DeleteMediator<>(context, mediatorManagers, mediatorScheduling, channelRepository, loggerManager, MEDIATOR_ID).call();

        verify(repo).delete(deleteDescriptorCaptor.capture());
        verify(notif).notifyDelete(repoEntity);
        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
        verify(mediatorScheduling).onMediatorRemoved(MEDIATOR_INSTANCE_ID);

        assertThat(deleteDescriptorCaptor.getValue().getId(), is(MEDIATOR_ID));
    }

    @Test(expected=IllegalMediatorStateException.class)
    public void testDeleteActiveMediator() throws DcnManagerException {
        final MediatorEntity repoEntity = new MediatorEntity(
                newInfo(true),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(repoEntity));

        new DeleteMediator<>(context, mediatorManagers, mediatorScheduling, channelRepository, loggerManager, MEDIATOR_ID).call();
    }

    @Test(expected=RepositoryException.class)
    public void testDeleteWithRepositoryError() throws DcnManagerException {
        final MediatorEntity repoEntity = new MediatorEntity(
                newInfo(false),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(repoEntity));
        when(physicalMediatorRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.emptyList());

        setupChildChannel(999);

        doThrow(new RepositoryException()).when(repo).delete(any(MediatorDeleteDescriptor.class));

        new DeleteMediator<>(context, mediatorManagers, mediatorScheduling, channelRepository, loggerManager, MEDIATOR_ID).call();
    }

    @Test(expected=IllegalMediatorStateException.class)
    public void testDeleteWithChildChannels() throws DcnManagerException {
        final MediatorEntity repoEntity = new MediatorEntity(
                newInfo(false),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(repoEntity));

        setupChildChannel(MEDIATOR_ID);

        doThrow(new RepositoryException()).when(repo).delete(any(MediatorDeleteDescriptor.class));

        new DeleteMediator<>(context, mediatorManagers, mediatorScheduling, channelRepository, loggerManager, MEDIATOR_ID).call();
    }

    @Test(expected=UnknownMediatorIdException.class)
    public void testDeleteUnknownMediator() throws DcnManagerException {

        when(repo.query(anyInt())).thenReturn(Optional.empty());

        doThrow(new RepositoryException()).when(repo).delete(any(MediatorDeleteDescriptor.class));

        new DeleteMediator<>(context, mediatorManagers, mediatorScheduling, channelRepository, loggerManager, 1).call();
    }

    private void setupChildChannel(final int parentMediatorId) throws RepositoryException {
        when(channelInfoRepository.channelsExist(parentMediatorId)).thenReturn(true);
    }

}
