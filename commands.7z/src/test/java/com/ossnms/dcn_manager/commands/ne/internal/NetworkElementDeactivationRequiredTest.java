package com.ossnms.dcn_manager.commands.ne.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.ne.NeTestBase;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.*;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.Alarms;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.IllegalNetworkElementStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.*;

public class NetworkElementDeactivationRequiredTest extends NeTestBase {

	private NetworkElementInteractionManager activationScheduler;

	private ChannelPhysicalConnectionRepository channelInstanceRepository;

    private Alarms alarms;

    private NetworkElementManagers neManagers;

	private static final int NE_ID = 10;
	private static final int NE_ACTIVE_INSTANCE_ID = 11;
	private static final int NE_INACTIVE_INSTANCE_ID = 12;
	private static final int CHANNEL_ID = 20;
	private static final int CHANNEL_ACTIVE_INSTANCE_ID = 2;
	private static final int CHANNEL_INACTIVE_INSTANCE_ID = 3;
    private static final int MEDIATOR_INSTANCE_ID = 88;
	private static final int VERSION = 1;

    private final ChannelPhysicalConnectionData activeChannel =
            new ChannelPhysicalConnectionBuilder().setActivation(ActualActivationState.ACTIVE).build(CHANNEL_ACTIVE_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
    private final ChannelPhysicalConnectionData inactiveChannel =
            new ChannelPhysicalConnectionBuilder().setActivation(ActualActivationState.INACTIVE).build(CHANNEL_INACTIVE_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);

    private final NePhysicalConnectionData activeNe =
            new NePhysicalConnectionBuilder().setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.INITIALIZED)
				.setActive(true)
                .build(NE_ACTIVE_INSTANCE_ID, NE_ID, CHANNEL_ACTIVE_INSTANCE_ID, VERSION);
    private final NePhysicalConnectionData inactiveNe =
            new NePhysicalConnectionBuilder().setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)
                .build(NE_INACTIVE_INSTANCE_ID, NE_ID, CHANNEL_INACTIVE_INSTANCE_ID, VERSION);

	@Override
    @Before
	public void setUp() throws RepositoryException
    {
		super.setUp();

		alarms = mock(Alarms.class);
        activationScheduler = mock(NetworkElementInteractionManager.class);
        channelInstanceRepository = mock(ChannelPhysicalConnectionRepository.class);

        when(neRepo.queryNeName(NE_ID)).thenReturn(Optional.of("name"));

        neManagers = new NetworkElementManagers(neRepo, neInstanceRepo, activationScheduler, notif, null);
    }

	private NeEntity createEntity(RequiredActivationState requiredState, com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState activationState) {
        return new NeEntity(
                new NeConnectionBuilder()
                    .setActivationState(activationState)
                    .build(NE_ID, VERSION),
                new NeOperationBuilder().build(NE_ID, VERSION),
                new NeInfoBuilder()
                .setRequiredActivationState(requiredState)
                    .setProxyType("proxy")
                    .build(NE_ID, CHANNEL_ID, VERSION),
                new NeSynchronizationBuilder().build(NE_ID, VERSION),
                new NeUserPreferencesBuilder()
                    .setName("name")
                    .build(NE_ID, VERSION));
	}

    private NeEntity createEntity(RequiredActivationState requiredState) {
        return createEntity(requiredState, com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.CONNECTED);
    }

	@Test(expected=UnknownNetworkElementIdException.class)
	public void deactivate_withNonExistingNetworkElementId_throwsException() throws Exception
	{
		// Set up repository stub (Arrange)
    	when(infoRepo.query(NE_ID)).thenReturn(Optional.empty());

    	// Execute command (Act)
		new NetworkElementDeactivationRequired<>(context, NE_ID, neManagers, channelInstanceRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

    @Test(expected=UnknownChannelIdException.class)
    public void deactivate_withNonExistingChannelConnectionId_throwsException() throws Exception
    {
        // Set up repository stub (Arrange)
        final NeEntity entity = createEntity(RequiredActivationState.INACTIVE);
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(ImmutableList.of(activeNe, inactiveNe));

        when(channelInstanceRepository.queryAll(CHANNEL_ID)).thenReturn(Collections.emptyList());

        // Execute command (Act)
        new NetworkElementDeactivationRequired<>(context, NE_ID, neManagers, channelInstanceRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

    @Test
    public void deactivate_onADeactivatedNetworkElement_ignores() throws Exception
    {
        final NeEntity entity = createEntity(RequiredActivationState.INACTIVE,
                com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED);

        // Set up repository and mediator entity stubs (Arrange)
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(ImmutableList.of(inactiveNe));

        when(channelInstanceRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(activeChannel, inactiveChannel));

        try {
            // Execute command (Act)
            new NetworkElementDeactivationRequired<>(context, NE_ID, neManagers, channelInstanceRepository, loggerManager).call();
            fail("Should throw an IllegalNetworkElementStateException");
        } catch (IllegalNetworkElementStateException e) {
            // (good)
        }

        // Verify that no changes were attempted (Assert)
        verify(infoRepo, never()).tryUpdate(isA(NeInfoMutationDescriptor.class));
        verify(connectionRepo, never()).tryUpdate(isA(NeConnectionMutationDescriptor.class));
        verifyZeroInteractions(notif, activationScheduler, alarms);
    }

    @Test
    public void deactivate_onAConcurrentlyActualDeactivatedNetworkElement_ignores() throws Exception
    {
        // Set up repository stub (Arrange)
        final NeEntity entity = createEntity(RequiredActivationState.ACTIVE);
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());
        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(ImmutableList.of(activeNe, inactiveNe));

        when(channelInstanceRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(activeChannel, inactiveChannel));

        when(neInstanceRepo.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
            .thenReturn(Optional.empty());

        // Execute command (Act)
        new NetworkElementDeactivationRequired<>(context, NE_ID, neManagers, channelInstanceRepository, loggerManager).call();

        // Verify that no changes were attempted (Assert)
        verifyZeroInteractions(activationScheduler, alarms);
    }

	@Test(expected=IllegalNetworkElementStateException.class)
	public void deactivate_onAConcurrentlyDeactivatedNetworkElement_throwsException() throws Exception
	{
		// Set up repository stub (Arrange)
	    final NeEntity entity = createEntity(RequiredActivationState.ACTIVE);
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(ImmutableList.of(activeNe, inactiveNe));

        when(channelInstanceRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(activeChannel, inactiveChannel));

        when(neInstanceRepo.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
            .then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class)))
			.thenReturn(Optional.empty());

    	// Execute command (Act)
		new NetworkElementDeactivationRequired<>(context, NE_ID, neManagers, channelInstanceRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

	@Test
	public void deactivate_onAnActivatedNetworkElement_withActivatedChannel_deactivatesItAndTriggersConnectionClosure() throws Exception
	{
		// Set up repository and mediator entity stubs (Arrange)
        final NeEntity entity = createEntity(RequiredActivationState.ACTIVE);
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(ImmutableList.of(activeNe, inactiveNe));

        when(channelInstanceRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(activeChannel, inactiveChannel));

        when(neInstanceRepo.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
            .then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class)))
			.then(new MutationAnswer<>());

    	// Execute command (Act)
		new NetworkElementDeactivationRequired<>(context, NE_ID, neManagers, channelInstanceRepository, loggerManager).call();

		// Verify mediator state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        final ArgumentCaptor<NeInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);
        verify(infoRepo).tryUpdate(argsCaptor.capture());

		assertThat(argsCaptor.getValue().getRequiredActivationState().get(), is(RequiredActivationState.INACTIVE));

		verify(activationScheduler).scheduleDeactivation(new Deactivate(NE_ID, CHANNEL_ACTIVE_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_ACTIVE_INSTANCE_ID, true));
		verify(notif).notifyChanges(new Deactivate(NE_ID, 0, 0, 0, false));

		verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
	}

    @Test
    @SuppressWarnings("unchecked")
    public void deactivate_onAnActivatedNetworkElement_withActivatedChannel_withConcurrentInfoUpdate_retriesAndDeactivatesItAndTriggersConnectionClosure() throws Exception
    {
        // Set up repository and mediator entity stubs (Arrange)
        final NeEntity entity = createEntity(RequiredActivationState.ACTIVE);
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(
                ImmutableList.of(activeNe, inactiveNe),
                ImmutableList.of(new NePhysicalConnectionBuilder().setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.SHUTDOWN)
                        .build(NE_ACTIVE_INSTANCE_ID, NE_ID, CHANNEL_ACTIVE_INSTANCE_ID, VERSION), inactiveNe));

        when(channelInstanceRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(activeChannel, inactiveChannel));

        when(neInstanceRepo.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
                .then(new MutationAnswer<>());

        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class)))
                .thenReturn(Optional.empty())
                .then(new MutationAnswer<>());

        // Execute command (Act)
        new NetworkElementDeactivationRequired<>(context, NE_ID, neManagers, channelInstanceRepository, loggerManager).call();

        // Verify mediator state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        final ArgumentCaptor<NeInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);
        verify(infoRepo, times(2)).tryUpdate(argsCaptor.capture()); // notice the retry

        assertThat(argsCaptor.getValue().getRequiredActivationState().get(), is(RequiredActivationState.INACTIVE));

        verify(activationScheduler).scheduleDeactivation(new Deactivate(NE_ID, CHANNEL_ACTIVE_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_ACTIVE_INSTANCE_ID, true));
        verify(notif).notifyChanges(new Deactivate(NE_ID, 0, 0, 0, false));

        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
    }

    @Test
    public void deactivate_onAnActivatedNetworkElement_withDeactivatedChannel_deactivatesIt() throws Exception
    {
        // Set up repository and mediator entity stubs (Arrange)
        final NeEntity entity = createEntity(RequiredActivationState.ACTIVE);
        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(neInstanceRepo.queryAll(NE_ID)).thenReturn(ImmutableList.of(activeNe, inactiveNe));

        when(channelInstanceRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(ActualActivationState.INACTIVE).build(CHANNEL_ACTIVE_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION),
                inactiveChannel));

        when(neInstanceRepo.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
            .then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(isA(NeInfoMutationDescriptor.class)))
            .then(new MutationAnswer<>());

        // Execute command (Act)
        new NetworkElementDeactivationRequired<>(context, NE_ID, neManagers, channelInstanceRepository, loggerManager).call();

        // Verify mediator state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        final ArgumentCaptor<NeInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);
        verify(infoRepo).tryUpdate(argsCaptor.capture());

        assertThat(argsCaptor.getValue().getRequiredActivationState().get(), is(RequiredActivationState.INACTIVE));

        verify(activationScheduler).scheduleDeactivation(new Deactivate(NE_ID, CHANNEL_ACTIVE_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_ACTIVE_INSTANCE_ID, true));
        verify(notif).notifyChanges(new Deactivate(NE_ID, 0, 0, 0, false));

        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
    }

	@Test(expected=RepositoryException.class)
	public void deactivate_whenRepositoryThrowsException_throwsRepositoryException() throws Exception
	{
		// Set up repository stub (Arrange)
	    when(infoRepo.query(NE_ID)).thenThrow(new RepositoryException());

    	// Execute command (Act)
		new NetworkElementDeactivationRequired<>(context, NE_ID, neManagers, channelInstanceRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

}
