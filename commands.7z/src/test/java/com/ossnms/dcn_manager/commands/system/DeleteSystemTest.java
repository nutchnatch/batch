package com.ossnms.dcn_manager.commands.system;

import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.container.system.SystemDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.SystemNotifications;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class DeleteSystemTest {

    private static final int SYSTEM_ID = 19;

    private SystemNotifications notifications;
    private LoggerManager<CallContext> loggerManager;
    private SystemRepository systemRepository;
    private CallContext context;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        notifications = mock(SystemNotifications.class);
        loggerManager = mock(LoggerManager.class);
        systemRepository = mock(SystemRepository.class);
        context = mock(CallContext.class);
    }

    @Test
    public void delete() throws Exception {
        final SystemInfo system = new SystemInfo(SYSTEM_ID, 1, "name");

        when(systemRepository.query(anyInt())).thenReturn(Optional.of(system));

        new DeleteSystem<>(context, systemRepository, notifications, loggerManager, SYSTEM_ID)
            .call();

        final ArgumentCaptor<SystemDeletionDescriptor> delCaptor = ArgumentCaptor.forClass(SystemDeletionDescriptor.class);

        verify(systemRepository).delete(delCaptor.capture());
        verify(notifications).notifyDelete(system);
        verify(loggerManager).createCommandLog(any(CallContext.class), any(LoggerItem[].class));

        assertThat(delCaptor.getValue().getId(), is(SYSTEM_ID));
    }

    @Test
    public void delete_unknownSystemId_ignores() throws Exception {

        when(systemRepository.query(anyInt())).thenReturn(Optional.empty());

        new DeleteSystem<>(context, systemRepository, notifications, loggerManager, SYSTEM_ID)
            .call();

        verify(systemRepository, never()).delete(any(SystemDeletionDescriptor.class));
        verifyZeroInteractions(notifications, loggerManager);
    }

    @Test(expected=CommandException.class)
    public void delete_queryRepoError_throws() throws Exception {

        when(systemRepository.query(anyInt())).thenThrow(new RepositoryException());

        new DeleteSystem<>(context, systemRepository, notifications, loggerManager, SYSTEM_ID)
            .call();
    }

    @Test(expected=CommandException.class)
    public void delete_deleteRepoError_throws() throws Exception {
        final SystemInfo system = new SystemInfo(SYSTEM_ID, 1, "name");

        when(systemRepository.query(anyInt())).thenReturn(Optional.of(system));
        doThrow(new RepositoryException()).when(systemRepository).delete(any(SystemDeletionDescriptor.class));

        new DeleteSystem<>(context, systemRepository, notifications, loggerManager, SYSTEM_ID)
            .call();
    }
}
