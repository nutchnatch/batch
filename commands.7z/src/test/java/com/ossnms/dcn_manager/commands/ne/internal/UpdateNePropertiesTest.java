package com.ossnms.dcn_manager.commands.ne.internal;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.commands.ne.NeTestBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NeDomainsUpdater;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.NePropertiesChangedEvent;
import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.core.jaxb.netype.RouteMapping;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.properties.ne.NeProperty;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.UnitOfWorkImplBaseStub;
import com.ossnms.dcn_manager.core.test.UowMutationAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownNeTypeException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import com.ossnms.dcn_manager.test.util.OtherMatchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasEntry;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class UpdateNePropertiesTest extends NeTestBase {

    private static final int ID = 1, VERSION = 1;
    private static final int CHANNEL_INSTANCE_ID = 2000;
    private static final int NE_INSTANCE_ID = 1000;

    private CallContext context;
    private LoggerManager<CallContext> loggerManager;
    private NetworkElementNotifications entityNotifications;
    private NeConnectionManager connectionManager;
    private NetworkElementInteractionManager interactionManager;
    private SystemRepository systemRepository;

    private NeType type;

    private NeEntity entity;
    private NeInfoData state;
    private NeUserPreferencesData prefs;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        context = mock(CallContext.class);
        loggerManager = mock(LoggerManager.class);
        entityNotifications = mock(NetworkElementNotifications.class);
        connectionManager = mock(NeConnectionManager.class);
        interactionManager = mock(NetworkElementInteractionManager.class);
        systemRepository = mock(SystemRepository.class);

        when(systemRepository.queryByName(anyString())).thenReturn(Optional.empty());

        type = MockFactory.mockNeType();

        state = new NeInfoData.NeInfoBuilder()
            .setProxyType("neType")
            .build(ID, 1, VERSION);
        prefs = new NeUserPreferencesBuilder()
            .setName("neName")
            .build(ID, VERSION);

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationData.NeSynchronizationBuilder().build(ID, VERSION),
                prefs);

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.<String>empty());
        when(type.getProtocol()).thenReturn("TL1");

        when(neTypes.get("neType")).thenReturn(type);

        when(neRepo.queryNe(ID)).thenReturn(Optional.of(entity));
        when(neRepo.unitOfWork(any())).then(invocation -> new UnitOfWorkImplBaseStub<>(invocation.getArguments()[0]));

        when(domainRepo.queryTransitiveDomainsForNE(anyInt())).thenReturn(Collections.<DomainInfoData>emptyList());
        when(domainRepo.queryNaturalDomainsForNE(anyInt())).thenReturn(Collections.<DomainInfoData>emptyList());
        when(domainRepo.queryAllForNE(anyInt())).thenReturn(Collections.<DomainInfoData>emptyList());

        when(operationRepo.tryUpdate(isA(UowContext.class), isA(NeOperationMutationDescriptor.class))).then(new UowMutationAnswer<>());

    }

    @Test
    public void testNameChange() throws DcnManagerException {
        when(preferencesRepo.query("New Name")).thenReturn(Optional.empty());

        runPropertyChange(true, ImmutableMap.of(NeProperty.ID_NAME.getName(), "New Name"));

        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> newPreferences =
                ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(connectionManager).updateNeProperties(
                isA(NeEntity.class), isA(NePhysicalConnectionData.class),
                newPreferences.capture(), isA(Map.class));

        assertThat(newPreferences.getValue().getName(), OtherMatchers.hasValue("New Name"));

        verify(loggerManager).createCommandLog(context, new LoggerItemNe("New Name", "NE ne was renamed to New Name", ID));
        verify(loggerManager).createCommandLog(context, new LoggerItemNe("New Name", "NE properties changed", ID));
    }

    @Test(expected = DuplicatedObjectNameException.class)
    public void testNameChange_duplicated_name() throws DcnManagerException {
        when(preferencesRepo.query("New Name")).thenReturn(Optional.of(prefs));

        runPropertyChange(true, ImmutableMap.of(NeProperty.ID_NAME.getName(), "New Name"));
    }

    @Test
    public void testPropertyChangeOnline() throws DcnManagerException, ConnectException {

        runPropertyChange(true);

        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> newPreferences =
                ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(connectionManager).updateNeProperties(
                isA(NeEntity.class), isA(NePhysicalConnectionData.class),
                newPreferences.capture(), isA(Map.class));

        assertThat(newPreferences.getValue().getProperties(), allOf(
                hasEntry("C", "CHANGE")
            ));

        verifyZeroInteractions(interactionManager);

        verify(loggerManager).createCommandLog(context, new LoggerItemNe("ne", "NE properties changed", ID));
    }

    @Test
    public void testPropertyChangeOffline() throws DcnManagerException {
        runPropertyChange(false);

        verifyZeroInteractions(connectionManager, interactionManager);

        verify(loggerManager).createCommandLog(context, new LoggerItemNe("ne", "NE properties changed", ID));
    }

    @Test
    public void testPropertyChangeOnlineConnectionManagerError() throws DcnManagerException, ConnectException {

        doThrow(new ConnectException()).when(connectionManager)
            .updateNeProperties(
                    isA(NeEntity.class), isA(NePhysicalConnectionData.class),
                    isA(NeUserPreferencesMutationDescriptor.class), isA(Map.class));

        testPropertyChangeOnline();

        verify(loggerManager).createCommandLog(context, new LoggerItemNe("ne",
                "NE was active but updating the properties failed ID=" + ID, ID));
    }

    @Test(expected=InvalidMutationException.class)
    public void testPropertyChangeInvalidMutationError() throws DcnManagerException {

        runPropertyChange(false, ImmutableMap.of(NeProperty.ID_NAME.getName(), "")); // empty names are not allowed

    }

    public void runPropertyChange(boolean online) throws DcnManagerException {
        final Map<String, String> mutatedProperties = runPropertyChange(
            online,
            new HashMap<>(ImmutableMap.of("A", "vA", "B", "vB", "C", "CHANGE")));

        assertThat(mutatedProperties.size(), is(1));
        assertThat(mutatedProperties, hasEntry("C", "CHANGE"));

        verify(loggerManager).createCommandLog(context, new LoggerItemNe("ne", "NE properties changed", ID));
    }

    public Map<String, String> runPropertyChange(boolean online, Map<String, String> properties)
            throws DcnManagerException {

        final NePhysicalConnectionData neInstance = new NePhysicalConnectionBuilder()
                .setActive(true)
                .setActivationState(online ? ActualActivationState.INITIALIZED : ActualActivationState.DISCONNECTED)
                .build(NE_INSTANCE_ID, ID, CHANNEL_INSTANCE_ID, 0);
        when(neInstanceRepo.queryAll(ID)).thenReturn(Collections.singleton(neInstance));

        final NeConnectionData connState = new NeConnectionBuilder()
            .setActivationState(online ? ActualActivationState.INITIALIZED : ActualActivationState.DISCONNECTED)
            .build(ID, VERSION);

        final NeUserPreferencesData prefs = new NeUserPreferencesBuilder()
                    .setName("ne")
                    .setProperty("A", "vA")
                    .setProperty("B", "vB")
                    .build(ID, VERSION);

        entity = new NeEntity(
                connState,
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationData.NeSynchronizationBuilder().build(ID, VERSION),
                prefs);
        when(neRepo.queryNe(ID)).thenReturn(Optional.of(entity));

        when(preferencesRepo.tryUpdate(isA(UowContext.class), isA(NeUserPreferencesMutationDescriptor.class))).then(new UowMutationAnswer<>());

        buildCommand(properties).call();

        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationNotif = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        verify(preferencesRepo).tryUpdate(isA(UowContext.class), mutationRepo.capture());
        verify(entityNotifications).notifyChanges(mutationNotif.capture());

        final NeUserPreferencesMutationDescriptor repoDescriptor = mutationRepo.getValue();
        final NeUserPreferencesMutationDescriptor notifDescriptor = mutationNotif.getValue();

        assertThat(repoDescriptor, is(notifDescriptor));

        return repoDescriptor.getProperties();
    }

    @Test
    public void testSameProperties() throws DcnManagerException {

        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("A", "vA", "B", "vB"));
        final NeUserPreferencesData prefs = new NeUserPreferencesBuilder()
                    .setName("ne")
                    .setProperty("A", "vA")
                    .setProperty("B", "vB")
                    .build(ID, VERSION);

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationData.NeSynchronizationBuilder().build(ID, VERSION),
                prefs);
        when(neRepo.queryNe(ID)).thenReturn(Optional.of(entity));

        final UpdateNeProperties<CallContext> cmd = buildCommand(properties);

        cmd.call();

        verify(preferencesRepo, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, entityNotifications, connectionManager);
    }

    @Test
    public void testEmptyChangedProperties() throws DcnManagerException {

        final UpdateNeProperties<CallContext> cmd = buildCommand(Collections.<String, String>emptyMap());

        cmd.call();

        verify(preferencesRepo, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, entityNotifications, connectionManager);
    }

    @Test(expected=RepositoryException.class)
    public void testRepositoryErrorOnNe() throws DcnManagerException {

        when(neRepo.queryNe(anyInt())).thenThrow(new RepositoryException());

        buildCommand(ImmutableMap.of("a", "A")).call();
    }

    @Test(expected=UnknownNetworkElementIdException.class)
    public void testInvalidNeId() throws DcnManagerException {

        when(neRepo.queryNe(anyInt())).thenReturn(Optional.<NeEntity>empty());

        final UpdateNeProperties<CallContext> cmd = new UpdateNeProperties<>(context,
                new NetworkElementManagers(neRepo, neInstanceRepo,  interactionManager, entityNotifications, null),
                systemRepository, staticConfig, loggerManager, connectionManager,
                new NeDomainsUpdater(domainRepo, domainNotifications, settingsRepository),
                new NePropertiesChangedEvent(-1, ImmutableMap.of("a", "A")));

        cmd.call();
    }

    @Test(expected=UnknownNeTypeException.class)
    public void testInvalidNeType() throws DcnManagerException {

        state = new NeInfoData.NeInfoBuilder()
            .setProxyType("badType")
            .build(ID, 1, VERSION);

        entity = new NeEntity(null, null, state, null, prefs);
        when(neRepo.queryNe(ID)).thenReturn(Optional.of(entity));

        final UpdateNeProperties<CallContext> cmd = buildCommand(ImmutableMap.of("a", "A"));

        cmd.call();
    }

    @Test
    public void testGatewayRoutesChanged() throws Exception {
        final NePhysicalConnectionData neInstance = new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, ID, CHANNEL_INSTANCE_ID, 0);
        when(neInstanceRepo.queryAll(ID)).thenReturn(Collections.singleton(neInstance));

        when(type.getGatewayRouteAttributes())
            .thenReturn(ImmutableMap.of(
                    "routeCost", attribute("routeCost", RouteMapping.COST),
                    "routePrio", attribute("routePrio", RouteMapping.PRIORITY),
                    "routeUse", attribute("routeUse", RouteMapping.USAGE),
                    "routeDomain", attribute("routeDomain", RouteMapping.DOMAIN_NAME),
                    "routeStuff", attribute("routeStuff"))
            );
        when(type.getGatewayRouteAddressKeySource())
            .thenReturn(Optional.of("${route.routeStuff}"));

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationData.NeSynchronizationBuilder().build(ID, VERSION),
                prefs);

        when(routesRepo.queryRoutes(ID)).thenReturn(Collections.singletonList(new NeGatewayRouteBuilder()
                    .setKey("stuff1")
                    .setCost(10)
                    .setPriority(1)
                    .setProperty("routeStuff", "stuff1")
                    .build(ID, VERSION)));
        when(neRepo.queryNe(ID)).thenReturn(Optional.of(entity));
        when(preferencesRepo.tryUpdate(isA(UowContext.class), isA(NeUserPreferencesMutationDescriptor.class))).then(new UowMutationAnswer<>());

        buildCommand(new HashMap<>(ImmutableMap.of(
                "routeCost_000", "50",
                "routePrio_000", "2",
                "routeUse_000", "false",
                "routeStuff_000", "newStuff",
                WellKnownNePropertyNames.INTERNAL_ROUTE_ROW_COUNT, "1")
            ))
            .call();

        final ArgumentCaptor<NeGatewayRouteMutationDescriptor> createCaptor = ArgumentCaptor.forClass(NeGatewayRouteMutationDescriptor.class);
        final ArgumentCaptor<String> deleteCaptor = ArgumentCaptor.forClass(String.class);

        verify(routesRepo).deleteRoute(isA(UowContext.class), deleteCaptor.capture());
        verify(routesRepo).createRoute(isA(UowContext.class), eq(ID), createCaptor.capture());

        assertThat(deleteCaptor.getValue(), is("stuff1"));

        final NeGatewayRouteData route = createCaptor.getValue().getResult();
        assertThat(route.getPriority(), is(1));
        assertThat(route.getCost(), is(50));
        assertThat(route.isUsed(), is(false));
        assertThat(route.getAllOpaqueProperties().get("routeStuff"), is("newStuff"));
    }

    @Test
    public void testGatewayRoutesChangedKeysOnly() throws Exception {
        final NePhysicalConnectionData neInstance = new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, ID, CHANNEL_INSTANCE_ID, 0);
        when(neInstanceRepo.queryAll(ID)).thenReturn(Collections.singleton(neInstance));

        when(type.getGatewayRouteAttributes())
            .thenReturn(ImmutableMap.of(
                    "routeCost", attribute("routeCost", RouteMapping.COST),
                    "routePrio", attribute("routePrio", RouteMapping.PRIORITY),
                    "routeUse", attribute("routeUse", RouteMapping.USAGE),
                    "routeDomain", attribute("routeDomain", RouteMapping.DOMAIN_NAME),
                    "routeStuff", attribute("routeStuff"))
            );
        when(type.getGatewayRouteAddressKeySource())
            .thenReturn(Optional.of("${route.routeStuff}#${Property."+WellKnownNePropertyNames.ID_NAME+"}"));
        when(preferencesRepo.query("newNeName")).thenReturn(Optional.empty());
        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationData.NeSynchronizationBuilder().build(ID, VERSION),
                prefs);

        when(routesRepo.queryRoutes(ID)).thenReturn(Collections.singletonList(new NeGatewayRouteBuilder()
                    .setKey("stuff1#"+prefs.getName())
                    .setCost(10)
                    .setPriority(1)
                    .setProperty("routeStuff", "stuff1")
                    .build(ID, VERSION)));
        when(neRepo.queryNe(ID)).thenReturn(Optional.of(entity));
        when(preferencesRepo.tryUpdate(isA(UowContext.class), isA(NeUserPreferencesMutationDescriptor.class))).then(new UowMutationAnswer<>());

        buildCommand(new HashMap<>(ImmutableMap.of(
                WellKnownNePropertyNames.ID_NAME, "newNeName")
            ))
            .call();

        final ArgumentCaptor<NeGatewayRouteMutationDescriptor> updateCaptor = ArgumentCaptor.forClass(NeGatewayRouteMutationDescriptor.class);

        verify(routesRepo, never()).deleteRoutes(any(Iterable.class));
        verify(routesRepo, never()).createRoute(isA(UowContext.class), eq(ID), isA(NeGatewayRouteMutationDescriptor.class));
        verify(routesRepo).updateRoute(isA(UowContext.class), eq(ID), updateCaptor.capture());

        final NeGatewayRouteData route = updateCaptor.getValue().getResult();
        assertThat(route.getKey(), is("stuff1#newNeName"));
    }

    private UpdateNeProperties<CallContext> buildCommand(Map<String, String> properties) {
        final UpdateNeProperties<CallContext> cmd = new UpdateNeProperties<>(context,
                new NetworkElementManagers(neRepo, neInstanceRepo, interactionManager, entityNotifications, null),
                systemRepository, staticConfig, loggerManager, connectionManager,
                new NeDomainsUpdater(domainRepo, domainNotifications, settingsRepository),
                new NePropertiesChangedEvent(ID, ImmutableMap.copyOf(properties)));
        return cmd;
    }

    private Attribute attribute(String name, RouteMapping mapping) {
        final Attribute attr = attribute(name);
        attr.setMapsTo(mapping);
        return attr;
    }

    private Attribute attribute(String name) {
        final Attribute attr = new Attribute();
        attr.setName(name);
        return attr;
    }

}
