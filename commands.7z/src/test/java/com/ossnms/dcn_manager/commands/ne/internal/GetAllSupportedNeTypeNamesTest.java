package com.ossnms.dcn_manager.commands.ne.internal;

import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.commands.ne.NeTestBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import org.junit.Test;

import java.util.Collections;
import java.util.Map;

import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class GetAllSupportedNeTypeNamesTest extends NeTestBase {

    @SuppressWarnings("unchecked")
    @Test
    public void testWithTypes() {
        final Types<NeType> types = mock(Types.class);

        final NeType type1 = mock(NeType.class);
        final NeType type2 = mock(NeType.class);

        final Map.Entry<String, NeType> entry1 = mock(Map.Entry.class);
        final Map.Entry<String, NeType> entry2 = mock(Map.Entry.class);

        when(type1.getName()).thenReturn("T1");
        when(type2.getName()).thenReturn("T2");

        when(entry1.getValue()).thenReturn(type1);
        when(entry2.getValue()).thenReturn(type2);

        when(types.entrySet()).thenReturn(ImmutableSet.of(entry1, entry2));

        when(staticConfig.getNeTypes()).thenReturn(types);

        final Iterable<String> names = new GetAllSupportedNeTypeNames<CallContext>(null, staticConfig).call();
        assertThat(names, hasItems("T1", "T2"));
    }

    @Test
    public void testWithNoTypes() {
        final Types<NeType> types = mock(Types.class);

        when(types.entrySet()).thenReturn(Collections.<Map.Entry<String, NeType>>emptySet());

        when(staticConfig.getNeTypes()).thenReturn(types);

        final Iterable<String> names = new GetAllSupportedNeTypeNames<CallContext>(null, staticConfig).call();
        assertThat(names, is(emptyIterable()));
    }

}
