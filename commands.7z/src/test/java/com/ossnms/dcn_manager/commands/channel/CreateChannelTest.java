package com.ossnms.dcn_manager.commands.channel;

import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CreateChannelTest extends ChannelTestBase {


    private final class ChannelCreateAnswer implements Answer<ChannelEntity> {
        @Override
        public ChannelEntity answer(InvocationOnMock invocation) throws Throwable {
            final ChannelCreateDescriptor descriptor = (ChannelCreateDescriptor)invocation.getArguments()[0];
            return new ChannelEntity(
                    new ChannelInfoData(CHANNEL_ID, 1, descriptor.getMediatorId(), descriptor.getInfoInitialData()),
                    new ChannelConnectionData(CHANNEL_ID, 1, descriptor.getConnectionInitialData()),
                    new ChannelUserPreferencesData(CHANNEL_ID, 1, descriptor.getPreferencesInitialData()));
        }
    }

    private final class ChannelInstanceCreateAnswer implements Answer<ChannelPhysicalConnectionData> {
        @Override
        public ChannelPhysicalConnectionData answer(InvocationOnMock invocation) throws Throwable {
            return new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0);
        }

    }

    private static final String CHANNEL_NAME = "channelName";
    private static final int MEDIATOR_ID = 42;
    private static final int CHANNEL_ID = 12;
    private static final int MEDIATOR_INSTANCE_ID = 3;
    private static final int CHANNEL_INSTANCE_ID = 6;

    private MediatorEntityRepository mediatorRepo;
    private MediatorInstanceEntityRepository mediatorInstanceRepo;
    private ChannelType type;

    private ChannelManagers channelManagers;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        mediatorRepo = mock(MediatorEntityRepository.class);
        mediatorInstanceRepo = mock(MediatorInstanceEntityRepository.class);

        type = MockFactory.mockEmType();
        when(type.getName()).thenReturn("type");
        when(channelTypes.values()).thenReturn(Collections.singletonList(type));
        when(channelTypes.get("type")).thenReturn(type);

        when(userPrefsRepo.query(anyString())).thenReturn(Optional.empty());

        channelManagers = new ChannelManagers(repo, channelPhysicalConnectionRepository, notif, null, null);
    }

    private void buildSibling(final String siblingName) throws RepositoryException {
        when(userPrefsRepo.query(siblingName)).thenReturn(
            Optional.of(new ChannelUserPreferencesBuilder().setName(siblingName).build(7654, 1))
        );
    }

    private MediatorEntity buildMediator() {
        return new MediatorEntity(
                new MediatorInfoBuilder().setName("name").setTypeName("type").build(MEDIATOR_ID, 1),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, 1));
    }

    private MediatorInstance buildMediatorInstance() {
        return new MediatorInstance(
                new MediatorPhysicalDataBuilder().setHost("host").setPriority(MediatorInstance.PRIMARY_PRIORITY_LEVEL).build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 1),
                new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 1));
    }

    private ChannelCreateDescriptor buildCreateDescriptor() {
        final ChannelCreateDescriptor createDescriptor = new ChannelCreateDescriptor(type, MEDIATOR_ID);
        createDescriptor.getPreferencesInitialData().setName(CHANNEL_NAME);
        return createDescriptor;
    }

    @Test
    public void testCreate() throws Exception {

        final ChannelCreateDescriptor createDescriptor = buildCreateDescriptor();
        createDescriptor.getPreferencesInitialData()
            .setConcurrentActivationsLimited(true)
            .setConcurrentActivationsLimit(34);

        buildSibling("other");

        when(mediatorRepo.query(MEDIATOR_ID)).thenReturn(Optional.of(buildMediator()));
        when(mediatorInstanceRepo.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(buildMediatorInstance()));
        when(repo.create(any(ChannelCreateDescriptor.class))).then(new ChannelCreateAnswer());
        when(channelPhysicalConnectionRepository.insert(isA(ChannelConnectionInitialData.class), eq(CHANNEL_ID), eq(MEDIATOR_INSTANCE_ID)))
            .then(new ChannelInstanceCreateAnswer());

        final CreateChannel<CallContext> createEM = new CreateChannel<>(context, channelManagers, channelScheduling, mediatorRepo, mediatorInstanceRepo, loggerManager, createDescriptor);
        final ChannelEntity entity = createEM.call();

        assertThat(entity.getInfo().getId(), is(CHANNEL_ID));
        assertThat(entity.getInfo().getMediatorId(), is(MEDIATOR_ID));

        verify(notif).notifyCreate(entity);
        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
        verify(channelScheduling).setMaxOngoingChannelJobCount(CHANNEL_INSTANCE_ID, 34);
    }

    @Test
    public void testCreate_withoutScheduling() throws Exception {

        final ChannelCreateDescriptor createDescriptor = buildCreateDescriptor();
        createDescriptor.getPreferencesInitialData()
            .setConcurrentActivationsLimited(false);

        buildSibling("other");

        when(mediatorRepo.query(MEDIATOR_ID)).thenReturn(Optional.of(buildMediator()));
        when(mediatorInstanceRepo.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(buildMediatorInstance()));
        when(repo.create(any(ChannelCreateDescriptor.class))).then(new ChannelCreateAnswer());
        when(channelPhysicalConnectionRepository.insert(isA(ChannelConnectionInitialData.class), eq(CHANNEL_ID), eq(MEDIATOR_INSTANCE_ID)))
        .then(new ChannelInstanceCreateAnswer());

        final CreateChannel<CallContext> createEM = new CreateChannel<>(context, channelManagers, channelScheduling, mediatorRepo, mediatorInstanceRepo, loggerManager, createDescriptor);
        final ChannelEntity entity = createEM.call();

        assertThat(entity.getInfo().getId(), is(CHANNEL_ID));
        assertThat(entity.getInfo().getMediatorId(), is(MEDIATOR_ID));

        verify(notif).notifyCreate(entity);
        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
        verify(channelScheduling).setMaxOngoingChannelJobCount(CHANNEL_INSTANCE_ID, Integer.MAX_VALUE);
    }

    @Test(expected=DuplicatedObjectNameException.class)
    public void testCreateWithDuplicatedName() throws Exception {

        buildSibling(CHANNEL_NAME);

        when(mediatorRepo.query(anyInt())).thenReturn(Optional.empty());

        new CreateChannel<>(context, channelManagers, channelScheduling, mediatorRepo, mediatorInstanceRepo, loggerManager, buildCreateDescriptor())
            .call();
    }

    @Test(expected=IllegalStateException.class)
    public void testCreateWithEmptyName() throws Exception {

        new CreateChannel<>(context, channelManagers, channelScheduling, mediatorRepo, mediatorInstanceRepo, loggerManager, new ChannelCreateDescriptor(type, MEDIATOR_ID))
            .call();
    }

    @Test(expected=CommandException.class)
    public void testCreateWithInvalidMediatorId() throws Exception {

        buildSibling("other");

        when(mediatorRepo.query(anyInt())).thenReturn(Optional.empty());

        new CreateChannel<>(context, channelManagers, channelScheduling, mediatorRepo, mediatorInstanceRepo, loggerManager, buildCreateDescriptor())
            .call();
    }

    @Test(expected=CommandException.class)
    public void testCreateWithMediatorRepositoryError() throws Exception {

        buildSibling("other");

        when(mediatorRepo.query(anyInt())).thenThrow(new RepositoryException());

        new CreateChannel<>(context, channelManagers, channelScheduling, mediatorRepo, mediatorInstanceRepo, loggerManager, buildCreateDescriptor())
            .call();
    }

    @Test(expected=CommandException.class)
    public void testCreateWithChannelRepositoryError() throws Exception {

        buildSibling("other");

        when(mediatorRepo.query(MEDIATOR_ID)).thenReturn(Optional.of(buildMediator()));

        when(repo.create(any(ChannelCreateDescriptor.class))).thenThrow(new RepositoryException());

        new CreateChannel<>(context, channelManagers, channelScheduling, mediatorRepo, mediatorInstanceRepo, loggerManager, buildCreateDescriptor())
            .call();
    }

}
