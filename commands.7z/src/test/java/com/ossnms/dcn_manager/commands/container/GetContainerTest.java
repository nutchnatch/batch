package com.ossnms.dcn_manager.commands.container;

import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownContainerIdException;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class GetContainerTest extends ContainerTestBase {

    @Test
    public void testGetContainer() throws Exception {
        final ContainerInfo repoEntity = newInfo();

        when(repo.query(CONTAINER_ID)).thenReturn(Optional.of(repoEntity));

        final ContainerInfo result = new GetContainer<>(null, repo, CONTAINER_ID).call();

        assertThat(result, is(repoEntity));
    }

    @Test(expected=UnknownContainerIdException.class)
    public void testGetContainer_unknownId() throws Exception {

        when(repo.query(CONTAINER_ID)).thenReturn(Optional.empty());

        new GetContainer<>(null, repo, CONTAINER_ID).call();
    }

    @Test(expected=RepositoryException.class)
    public void testGetContainers_withRepositoryError() throws Exception {

        when(repo.query(CONTAINER_ID)).thenThrow(new RepositoryException());

        new GetContainer<>(null, repo, CONTAINER_ID).call();
    }

}
