package com.ossnms.dcn_manager.commands.channel.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.channel.ChannelTestBase;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelStartingUpEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Activate;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.emptyIterable;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * TODO: Clean up
 *
 */
public class ChannelActivationRequiredTest extends ChannelTestBase {

	private ChannelInteractionManager activationScheduler;
	private ChannelInfoData channelInfo;
	private MediatorConnectionRepository mediatorConnectionRepository;
	private MediatorEntityRepository mediatorRepository;
	private MediatorInstanceEntityRepository mediatorInstanceRepository;
	private MediatorPhysicalConnectionRepository mediatorPhysicalConnectionRepository;
	private MediatorConnectionData activeMediator;

	private ChannelManagers channelManagers;

	private final int CHANNEL_ID = 1;
	private final int CHANNEL_INSTANCE_ID = 2;
	private final int MEDIATOR_ID = 10;
	private final int MEDIATOR_INSTANCE_ID = 20;
	private final int VERSION = 1;

	@Override
    @Before
	public void setUp() throws RepositoryException
    {
		super.setUp();
        activationScheduler = mock(ChannelInteractionManager.class);

        final ChannelType channelType = MockFactory.mockEmType();

        final ChannelCreateDescriptor createDescriptor =
                new ChannelCreateDescriptor(channelType, MEDIATOR_ID);
        createDescriptor.getInfoInitialData().setCoreId("");

        channelInfo = new ChannelInfoBuilder()
            .setType("type")
            .setCoreId("")
            .setActivationRequired(false)
            .build(CHANNEL_ID, VERSION, MEDIATOR_ID);

	    activeMediator = new MediatorConnectionBuilder().setActualActivationState(ActualActivationState.ACTIVE).build(MEDIATOR_ID, VERSION);

		mediatorConnectionRepository = mock(MediatorConnectionRepository.class);
		mediatorRepository = mock(MediatorEntityRepository.class);
		when(mediatorRepository.getMediatorConnectionRepository()).thenReturn(mediatorConnectionRepository);

		mediatorInstanceRepository = mock(MediatorInstanceEntityRepository.class);
		mediatorPhysicalConnectionRepository = mock(MediatorPhysicalConnectionRepository.class);
		when(mediatorInstanceRepository.getMediatorPhysicalConnectionRepository()).thenReturn(mediatorPhysicalConnectionRepository);

		when(userPrefsRepo.query(CHANNEL_ID)).thenReturn(Optional.of(
		        new ChannelUserPreferencesBuilder().setName("name").build(CHANNEL_ID, VERSION)
	        ));

        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE_ID)).thenReturn(Optional.of(
                new MediatorPhysicalConnectionBuilder().setActualActivationState(ActualActivationState.ACTIVE).build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION)));

		channelManagers = new ChannelManagers(repo, channelPhysicalConnectionRepository, notif, activationScheduler, null);
    }

	@Test(expected=UnknownChannelIdException.class)
	public void activate_withNonExistingChannelInfoId_throwsException() throws Exception
	{
		// Set up repository stub (Arrange)
    	when(infoRepo.query(CHANNEL_ID)).thenReturn(Optional.empty());
    	when(connectionRepo.query(CHANNEL_ID)).thenReturn(Optional.empty());

    	// Execute command (Act)
		new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

    @Test(expected=UnknownChannelIdException.class)
    public void activate_withNonExistingChannelConnectionId_throwsException() throws Exception
    {
        // Set up repository stub (Arrange)
        when(infoRepo.query(CHANNEL_ID)).thenReturn(Optional.of(channelInfo));
        when(mediatorConnectionRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(activeMediator));

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(Collections.emptyList());

        // Execute command (Act)
        new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

    @Test(expected=UnknownMediatorIdException.class)
    public void activate_withNonExistingMediatorId_throwsException() throws Exception
    {
        // Set up repository stub (Arrange)
        when(infoRepo.query(CHANNEL_ID)).thenReturn(Optional.of(channelInfo));
        when(connectionRepo.query(CHANNEL_ID)).thenReturn(Optional.of(new ChannelConnectionBuilder().build(CHANNEL_ID, VERSION)));
        when(mediatorConnectionRepository.query(MEDIATOR_ID)).thenReturn(Optional.empty());

        // Execute command (Act)
        new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

	@Test
	public void activate_onAnActivatedChannel_ignores() throws Exception
	{
		// Set up repository and channel entity stubs (Arrange)

		when(infoRepo.query(CHANNEL_ID)).thenReturn(Optional.of(channelInfo));
        when(mediatorConnectionRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(activeMediator));

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                    .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
            ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

    	// Execute command (Act)
        new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

		// Verify channel state and interactions (Assert)

        verify(notif, never()).notifyChanges(isA(ChannelStartingUpEvent.class));
	}

    @Test
    public void activate_onAConcurrentlyActivatedChannel_ignores() throws Exception
    {
        // Set up repository and channel entity stubs (Arrange)

        when(infoRepo.query(CHANNEL_ID)).thenReturn(Optional.of(channelInfo));
        when(mediatorConnectionRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(activeMediator));

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                    .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
            ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).thenReturn(Optional.empty());
        when(infoRepo.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        // Execute command (Act)
        new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

        // Verify channel state and interactions (Assert)

        verify(notif, never()).notifyChanges(isA(ChannelStartingUpEvent.class));
    }

    @Test(expected=IllegalChannelStateException.class)
    public void activate_onARequiredActiveChannel_throwsException() throws Exception
    {
        // Set up repository and channel entity stubs (Arrange)
        channelInfo = new ChannelInfoBuilder().setType("type").setActivationRequired(true).build(CHANNEL_ID, VERSION, MEDIATOR_ID);

        when(infoRepo.query(CHANNEL_ID)).thenReturn(Optional.of(channelInfo));
        when(mediatorConnectionRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(activeMediator));

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.INACTIVE)
                    .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
            ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(connectionRepo.tryUpdate(isA(ChannelConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        // Execute command (Act)
        new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

     // Does not get here because tested behavior should throw exception (Assert)
    }

	@Test(expected=IllegalChannelStateException.class)
	public void activate_onAConcurrentlyRequiredActiveChannel_throwsException() throws Exception
	{
		// Set up repository stub (Arrange)

        when(infoRepo.query(CHANNEL_ID)).thenReturn(Optional.of(channelInfo));
        when(mediatorConnectionRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(activeMediator));

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.INACTIVE)
                    .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
            ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).thenReturn(Optional.empty());

    	// Execute command (Act)
        new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

	@Test
	public void activate_onADeactivatedChannel_withActiveMediatorInstance_activatesItAndTriggersConnectionEstablishment() throws Exception
	{
		// Set up repository and channel entity stubs (Arrange)

        when(infoRepo.query(CHANNEL_ID)).thenReturn(Optional.of(channelInfo));

        when(mediatorConnectionRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(activeMediator));

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActive(true)
                        .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.INACTIVE)
                        .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION),
                new ChannelPhysicalConnectionBuilder()
                        .setActive(false)
                        .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.INACTIVE)
                        .build(CHANNEL_INSTANCE_ID + 1, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
            ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

		when(infoRepo.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

    	// Execute command (Act)
        new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

		// Verify channel state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
		final ArgumentCaptor<ChannelInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(ChannelInfoMutationDescriptor.class);
		verify(infoRepo).tryUpdate(argsCaptor.capture());

		assertThat(argsCaptor.getValue().getResult().getId(), is(CHANNEL_ID));
		assertThat(argsCaptor.getValue().getActive().get(), is(true));

		final ArgumentCaptor<Activate> activationEventCaptor =
		        ArgumentCaptor.forClass(Activate.class);

		verify(activationScheduler).scheduleActivation(activationEventCaptor.capture());
		assertThat(activationEventCaptor.getValue().getChannelInstanceIdentifiers(), hasItem(CHANNEL_INSTANCE_ID));

		verify(notif).notifyChanges(isA(Activate.class));
		verify(notif).notifyChanges(isA(ChannelStartingUpEvent.class));

		verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
	}

    @Test
    public void activate_onADeactivatedChannel_withInactiveMediatorInstance_activatesItAndDoesNotTriggerConnectionEstablishment() throws Exception
    {
        // Set up repository and channel entity stubs (Arrange)

        when(infoRepo.query(CHANNEL_ID)).thenReturn(Optional.of(channelInfo));

        when(mediatorConnectionRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(activeMediator));
        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE_ID)).thenReturn(Optional.of(
                new MediatorPhysicalConnectionBuilder().setActualActivationState(ActualActivationState.INACTIVE).build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION)));

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.INACTIVE)
                    .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
            ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(infoRepo.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        // Execute command (Act)
        new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

        // Verify channel state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        final ArgumentCaptor<ChannelInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(ChannelInfoMutationDescriptor.class);
        verify(infoRepo).tryUpdate(argsCaptor.capture());

        assertThat(argsCaptor.getValue().getResult().getId(), is(CHANNEL_ID));
        assertThat(argsCaptor.getValue().getActive().get(), is(true));

        final ArgumentCaptor<Activate> activationEventCaptor =
                ArgumentCaptor.forClass(Activate.class);

        verify(notif).notifyChanges(activationEventCaptor.capture());
        assertThat(activationEventCaptor.getValue().getChannelInstanceIdentifiers(), is(emptyIterable()));

        verify(activationScheduler, never()).scheduleActivation(any(Activate.class));
        verify(notif, never()).notifyChanges(isA(ChannelStartingUpEvent.class));

        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
    }

    @Test
    public void activate_onADeactivatedChannelAndInactiveMediator_activatesItAndDoesNotTriggerConnectionEstablishment() throws Exception
    {
        // Set up repository and channel entity stubs (Arrange)

        when(infoRepo.query(CHANNEL_ID)).thenReturn(Optional.of(channelInfo));

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.INACTIVE)
                    .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
            ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        final MediatorConnectionData inactiveMediator = new MediatorConnectionBuilder().setActualActivationState(ActualActivationState.INACTIVE).build(MEDIATOR_ID, VERSION);
        when(mediatorConnectionRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(inactiveMediator));

        // Execute command (Act)
        new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

        // Verify channel state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        final ArgumentCaptor<ChannelInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(ChannelInfoMutationDescriptor.class);
        verify(infoRepo).tryUpdate(argsCaptor.capture());

        assertThat(argsCaptor.getValue().getResult().getId(), is(CHANNEL_ID));
        assertThat(argsCaptor.getValue().getActive().get(), is(true));

        verify(activationScheduler, never()).scheduleActivation(any(Activate.class));
        verify(notif).notifyChanges(any(Activate.class));
        verify(notif, never()).notifyChanges(any(ChannelStartingUpEvent.class));

        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
    }

	@Test(expected=RepositoryException.class)
	public void activate_whenChannelRepositoryThrowsException_throwsRepositoryException() throws Exception
	{
		// Set up repository stub (Arrange)
		when(infoRepo.query(CHANNEL_ID)).thenThrow(new RepositoryException());

    	// Execute command (Act)
        new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

    @Test(expected=RepositoryException.class)
    public void activate_whenMediatorRepositoryThrowsException_throwsRepositoryException() throws Exception
    {
        // Set up repository stub (Arrange)
        when(infoRepo.query(CHANNEL_ID)).thenReturn(Optional.of(channelInfo));
        when(mediatorConnectionRepository.query(MEDIATOR_ID)).thenThrow(new RepositoryException());

        // Execute command (Act)
        new ChannelActivationRequired<>(context, CHANNEL_ID, channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }
}
