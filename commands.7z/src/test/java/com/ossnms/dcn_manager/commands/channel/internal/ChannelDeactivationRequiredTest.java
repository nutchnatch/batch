package com.ossnms.dcn_manager.commands.channel.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.channel.ChannelTestBase;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.IllegalNetworkElementStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ChannelDeactivationRequiredTest extends ChannelTestBase {

    private ChannelInteractionManager activationScheduler;
    private ChannelInfoData channelInfo;
    private ChannelUserPreferencesData channelPrefs;
    private ChannelEntity entity;
    private ChannelConnectionData connState;

    private NeEntityRepository neRepository;
    private MediatorInfoRepository mediatorInfoRepository;
    private MediatorEntityRepository mediatorRepository;
    private MediatorInfoData activeMediator;
    private MediatorInfoData inactiveMediator;

    private ChannelManagers channelManagers;

    private final int CHANNEL_ID = 1;
    private final int CHANNEL_INSTANCE_ID = 2;
    private final int MEDIATOR_ID = 10;
    private final int MEDIATOR_INSTANCE_ID = 20;
    private final int VERSION = 1;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        neRepository = mock(NeEntityRepository.class);
        activationScheduler = mock(ChannelInteractionManager.class);
        mediatorInfoRepository = mock(MediatorInfoRepository.class);
        mediatorRepository = mock(MediatorEntityRepository.class);

        final ChannelType channelType = MockFactory.mockEmType();

        final ChannelCreateDescriptor createDescriptor =
                new ChannelCreateDescriptor(channelType, MEDIATOR_ID);
        createDescriptor.getInfoInitialData().setCoreId("");

        channelInfo = new ChannelInfoBuilder()
                .setType("type")
                .setCoreId("")
                .setActivationRequired(true)
                .build(CHANNEL_ID, VERSION, MEDIATOR_ID);

        connState = new ChannelConnectionData(CHANNEL_ID, VERSION, new ChannelConnectionInitialData().setActivation(
                ActualActivationState.ACTIVE));

        activeMediator = newMediatorInfo(true);
        inactiveMediator = newMediatorInfo(false);

        channelPrefs = new ChannelUserPreferencesBuilder().setName("name").build(CHANNEL_ID, VERSION);

        entity = new ChannelEntity(channelInfo, connState, channelPrefs);

        when(userPrefsRepo.query(CHANNEL_ID)).thenReturn(Optional.of(channelPrefs));

        when(mediatorRepository.getMediatorInfoRepository()).thenReturn(mediatorInfoRepository);
        when(mediatorInfoRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(activeMediator));

        channelManagers = new ChannelManagers(repo, channelPhysicalConnectionRepository, notif, activationScheduler, null);
    }

    @Test(expected = UnknownChannelIdException.class)
    public void deactivate_withNonExistingChannelId_throwsException() throws Exception {
        // Set up repository stub (Arrange)
        when(repo.queryChannel(CHANNEL_ID)).thenReturn(Optional.empty());

        // Execute command (Act)
        new ChannelDeactivationRequired<>(context, CHANNEL_ID, channelManagers, neRepository, mediatorRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

    @Test
    public void deactivate_onADeactivatedChannel_doesNotUpdateConnection() throws Exception {
        // Set up repository and channel entity stubs (Arrange)

        when(repo.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(entity));
        when(neRepository.queryActivationRequiredIs(CHANNEL_ID, RequiredActivationState.ACTIVE)).thenReturn(Collections.emptySet());

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(ActualActivationState.INACTIVE)
                        .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());


        // Execute command (Act)
        new ChannelDeactivationRequired<>(context, CHANNEL_ID, channelManagers, neRepository, mediatorRepository, loggerManager).call();

        // Validate (Assert)
        verify(connectionRepo, never()).tryUpdate(isA(ChannelConnectionMutationDescriptor.class));
    }

    @Test
    public void deactivate_onAConcurrentlyDeactivatedChannel_ignores() throws Exception {
        // Set up repository and channel entity stubs (Arrange)

        when(repo.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(entity));
        when(neRepository.queryActivationRequiredIs(CHANNEL_ID, RequiredActivationState.ACTIVE)).thenReturn(Collections.emptySet());

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(ActualActivationState.ACTIVE)
                        .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).thenReturn(Optional.empty());
        when(infoRepo.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        // Execute command (Act)
        new ChannelDeactivationRequired<>(context, CHANNEL_ID, channelManagers, neRepository, mediatorRepository, loggerManager).call();

        // (Assert)

        verify(notif).notifyChanges(any(Deactivate.class));
        verify(notif, never()).notifyChanges(any(ChannelShuttingDownEvent.class));
        verify(activationScheduler, never()).scheduleDeactivation(any(Deactivate.class));
    }

    @Test(expected = IllegalChannelStateException.class)
    public void deactivate_onARequiredInactiveChannel_throwsException() throws Exception {
        // Set up repository and channel entity stubs (Arrange)
        channelInfo = new ChannelInfoBuilder().setType("type").setActivationRequired(false).build(CHANNEL_ID, VERSION, MEDIATOR_ID);
        entity = new ChannelEntity(channelInfo, connState, channelPrefs);

        when(repo.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(entity));
        when(neRepository.queryActivationRequiredIs(CHANNEL_ID, RequiredActivationState.ACTIVE)).thenReturn(Collections.emptySet());

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(ActualActivationState.ACTIVE)
                        .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        // Execute command (Act)
        new ChannelDeactivationRequired<>(context, CHANNEL_ID, channelManagers, neRepository, mediatorRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

    @Test(expected = IllegalChannelStateException.class)
    public void deactivate_onAConcurrentlyRequiredInactiveChannel_throwsException() throws Exception {
        // Set up repository stub (Arrange)
        when(repo.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(entity));
        when(neRepository.queryActivationRequiredIs(CHANNEL_ID, RequiredActivationState.ACTIVE)).thenReturn(Collections.emptySet());

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(ActualActivationState.ACTIVE)
                        .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(any(ChannelInfoMutationDescriptor.class))).thenReturn(Optional.empty());

        // Execute command (Act)
        new ChannelDeactivationRequired<>(context, CHANNEL_ID, channelManagers, neRepository, mediatorRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

    @Test
    public void deactivate_onAnActivatedChannel_deactivatesIt() throws Exception {
        // Set up repository and channel entity stubs (Arrange)

        when(repo.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(entity));
        when(neRepository.queryActivationRequiredIs(CHANNEL_ID, RequiredActivationState.ACTIVE)).thenReturn(Collections.emptySet());

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(ActualActivationState.ACTIVE)
                        .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        // Execute command (Act)
        new ChannelDeactivationRequired<>(context, CHANNEL_ID, channelManagers, neRepository, mediatorRepository, loggerManager).call();

        // Verify channel state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        final ArgumentCaptor<ChannelInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(ChannelInfoMutationDescriptor.class);
        verify(infoRepo).tryUpdate(argsCaptor.capture());

        assertThat(argsCaptor.getValue().getResult().getId(), is(CHANNEL_ID));
        assertThat(argsCaptor.getValue().getActive().get(), is(false));

        verify(notif).notifyChanges(any(Deactivate.class));
        verify(notif).notifyChanges(any(ChannelShuttingDownEvent.class));

        verify(activationScheduler).cancelActivations(any(Deactivate.class));
        verify(activationScheduler).scheduleDeactivation(any(Deactivate.class));

        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
    }

    @Test(expected = RepositoryException.class)
    public void deactivate_whenChannelRepositoryThrowsException_throwsRepositoryException() throws Exception {
        // Set up repository stub (Arrange)
        when(repo.queryChannel(CHANNEL_ID)).thenThrow(new RepositoryException());
        when(neRepository.queryActivationRequiredIs(CHANNEL_ID, RequiredActivationState.ACTIVE)).thenReturn(Collections.emptySet());

        // Execute command (Act)
        new ChannelDeactivationRequired<>(context, CHANNEL_ID, channelManagers, neRepository, mediatorRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

    @Test(expected = IllegalNetworkElementStateException.class)
    public void deactivate_withActiveNetworkElements_throwsIllegalNetworkElementStateException() throws Exception {
        // Set up repository stub (Arrange)
        when(repo.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(entity));
        when(neRepository.queryActivationRequiredIs(CHANNEL_ID, RequiredActivationState.ACTIVE))
                .thenReturn(Collections.singleton(new NeInfoBuilder().setProxyType("type").setRequiredActivationState(RequiredActivationState.ACTIVE).build(34, CHANNEL_ID, VERSION)));

        // Execute command (Act)
        new ChannelDeactivationRequired<>(context, CHANNEL_ID, channelManagers, neRepository, mediatorRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

    @Test
    public void deactivate_whenMediatorIsRequiredState_false() throws Exception {
        // Set up repository and channel entity stubs (Arrange)
        when(mediatorInfoRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(inactiveMediator));
        when(neRepository.queryActivationRequiredIs(CHANNEL_ID, RequiredActivationState.ACTIVE)).thenReturn(Collections.emptySet());

        when(repo.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(entity));

        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(
                new ChannelPhysicalConnectionBuilder().setActivation(ActualActivationState.ACTIVE)
                        .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(infoRepo.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        // Execute command (Act)
        new ChannelDeactivationRequired<>(context, CHANNEL_ID, channelManagers, neRepository, mediatorRepository, loggerManager).call();

        // Verify channel state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
        final ArgumentCaptor<ChannelInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(ChannelInfoMutationDescriptor.class);
        verify(infoRepo).tryUpdate(argsCaptor.capture());

        assertThat(argsCaptor.getValue().getResult().getId(), is(CHANNEL_ID));
        assertThat(argsCaptor.getValue().getActive().get(), is(false));

        verify(notif).notifyChanges(any(Deactivate.class));

        verify(activationScheduler, never()).cancelActivations(any(Deactivate.class));
        verify(activationScheduler, never()).scheduleDeactivation(any(Deactivate.class));

        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
    }

    @Test(expected = UnknownMediatorIdException.class)
    public void deactivate_mediator_not_present() throws Exception {
        // Set up repository and channel entity stubs (Arrange)
        when(mediatorInfoRepository.query(MEDIATOR_ID)).thenReturn(Optional.empty());
        when(repo.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(entity));
        when(neRepository.queryActivationRequiredIs(CHANNEL_ID, RequiredActivationState.ACTIVE)).thenReturn(Collections.emptySet());

        // Execute command (Act)
        new ChannelDeactivationRequired<>(context, CHANNEL_ID, channelManagers, neRepository, mediatorRepository, loggerManager).call();
    }

    protected MediatorInfoData newMediatorInfo(final boolean activationRequired) {
        return new MediatorInfoBuilder()
                .setName("name")
                .setTypeName("type")
                .setDescription(Optional.of(""))
                .setActivationRequired(activationRequired)
                .build(MEDIATOR_ID, VERSION);
    }

}
