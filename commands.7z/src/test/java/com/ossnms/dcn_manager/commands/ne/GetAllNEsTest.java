package com.ossnms.dcn_manager.commands.ne;

import static org.hamcrest.Matchers.hasItems;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.commands.ne.GetAllNEs;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public class GetAllNEsTest extends NeTestBase {

    @Test
    public void testList() throws RepositoryException, CommandException {
        final NeEntity entity1 = new NeEntity(null, null, null, null, null);
        final NeEntity entity2 = new NeEntity(null, null, null, null, null);

        when(neRepo.queryAll()).thenReturn(ImmutableList.of(entity1, entity2));

        final Iterable<NeEntity> nes = new GetAllNEs<>(context, neRepo).call();
        assertThat(nes, hasItems(entity1, entity2));
    }

    @Test(expected=CommandException.class)
    public void testListError() throws RepositoryException, CommandException {
        when(neRepo.queryAll()).thenThrow(new RepositoryException());

        new GetAllNEs<>(context, neRepo).call();
    }

}
