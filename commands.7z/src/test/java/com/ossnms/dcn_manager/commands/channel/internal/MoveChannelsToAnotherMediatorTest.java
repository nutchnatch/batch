package com.ossnms.dcn_manager.commands.channel.internal;

import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.channel.PhysicalChannelModification;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorInfoRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static java.util.Collections.singleton;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class MoveChannelsToAnotherMediatorTest {
    private static final int CHANNEL_ID = 1;
    private static final int CHANNEL_INSTANCE_ID = 10;
    private static final int NEW_MEDIATOR_ID = 2;
    private static final int NEW_MEDIATOR_INSTANCE_ID = 20;
    private static final int MEDIATOR_INSTANCE_ID = 200;
    private static final int OLD_MEDIATOR_ID = 3;
    private static final int OLD_MEDIATOR_INSTANCE_ID = 30;
    private static final int VERSION = 0;
    private static final String CHANNEL_NAME = "channelName";
    private static final String CHANNEL_TYPE = "type-name";
    private static final String OLD_MEDIATOR_NAME = "oldMediator";
    private static final String MEDIATOR_TYPE = "mediator-type";

    private CallContext context;
    private LoggerManager<CallContext> loggerManager;
    private ChannelNotifications channelNotifications;
    private ChannelInfoRepository channelInfoRepository;
    private ChannelUserPreferencesRepository channelUserPreferencesRepository;
    private ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    private MediatorInstanceEntityRepository mediatorInstanceEntityRepository;
    private MediatorInfoRepository mediatorInfoRepository;
    private MediatorEntityRepository mediatorEntityRepository;

    private ChannelManagers channelManagers;
    private PhysicalChannelModification physicalChannelModification;

    @Before
    public void setUp() {
        context = mock(CallContext.class);
        loggerManager = mock(LoggerManager.class);
        channelNotifications = mock(ChannelNotifications.class);
        channelInfoRepository = mock(ChannelInfoRepository.class);
        ChannelEntityRepository channelEntityRepository = mock(ChannelEntityRepository.class);
        channelUserPreferencesRepository = mock(ChannelUserPreferencesRepository.class);
        channelPhysicalConnectionRepository = mock(ChannelPhysicalConnectionRepository.class);
        mediatorInstanceEntityRepository = mock(MediatorInstanceEntityRepository.class);
        mediatorInfoRepository = mock(MediatorInfoRepository.class);
        MediatorPhysicalConnectionRepository mediatorPhysicalConnectionRepository = mock(MediatorPhysicalConnectionRepository.class);
        mediatorEntityRepository = mock(MediatorEntityRepository.class);

        when(channelEntityRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
        when(channelEntityRepository.getChannelUserPreferencesRepository()).thenReturn(channelUserPreferencesRepository);
        when(mediatorInstanceEntityRepository.getMediatorPhysicalConnectionRepository()).thenReturn(mediatorPhysicalConnectionRepository);
        when(mediatorEntityRepository.getMediatorInfoRepository()).thenReturn(mediatorInfoRepository);

        when(mediatorPhysicalConnectionRepository.queryAll(NEW_MEDIATOR_ID)).thenReturn(singleton(
                new MediatorPhysicalConnectionBuilder().build(NEW_MEDIATOR_INSTANCE_ID, MEDIATOR_INSTANCE_ID, VERSION)));

        channelManagers = new ChannelManagers(channelEntityRepository, channelPhysicalConnectionRepository, channelNotifications, mock(ChannelInteractionManager.class), mock(MessageSource.class));

        physicalChannelModification = mock(PhysicalChannelModification.class);
    }

    @Test
    public void moveSuccessful() throws Exception {
        final ArgumentCaptor<ChannelInfoMutationDescriptor> mutationCaptor = ArgumentCaptor.forClass(ChannelInfoMutationDescriptor.class);

        when(channelInfoRepository.query(CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder()
                .setType(CHANNEL_TYPE).build(CHANNEL_ID, VERSION, OLD_MEDIATOR_ID)));
        when(channelUserPreferencesRepository.query(CHANNEL_ID)).thenReturn(Optional.of(
                new ChannelUserPreferencesBuilder().setName(CHANNEL_NAME).build(CHANNEL_ID, VERSION)));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(singleton(
                new ChannelPhysicalConnectionBuilder().build(
                        CHANNEL_INSTANCE_ID, OLD_MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(mediatorInfoRepository.query(OLD_MEDIATOR_ID)).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName(OLD_MEDIATOR_NAME).setTypeName(MEDIATOR_TYPE).build(OLD_MEDIATOR_ID, VERSION)
        ));
        when(mediatorInfoRepository.query(NEW_MEDIATOR_ID)).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName(OLD_MEDIATOR_NAME).setTypeName(MEDIATOR_TYPE).build(OLD_MEDIATOR_ID, VERSION)
        ));

        when(channelInfoRepository.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        new MoveChannelsToAnotherMediator<>(context, channelManagers, mediatorEntityRepository, mediatorInstanceEntityRepository,
                loggerManager, Collections.singletonList(CHANNEL_ID), NEW_MEDIATOR_ID, physicalChannelModification)
                .call();

        verify(channelInfoRepository).tryUpdate(isA(ChannelInfoMutationDescriptor.class));
        verify(channelNotifications).notifyChanges(mutationCaptor.capture());

        verify(loggerManager, times(1)).createCommandLog(eq(context), isA(LoggerItemChannel.class));
        assertThat(mutationCaptor.getValue().getMediatorId(), hasValue(NEW_MEDIATOR_ID));
    }

    @Test
    public void movePartialSuccessful() throws DcnManagerException {
        when(channelInfoRepository.query(CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder()
                .setType(CHANNEL_TYPE).build(CHANNEL_ID, VERSION, OLD_MEDIATOR_ID)));
        when(channelUserPreferencesRepository.query(CHANNEL_ID)).thenReturn(Optional.of(
                new ChannelUserPreferencesBuilder().setName(CHANNEL_NAME).build(CHANNEL_ID, VERSION)));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(singleton(
                new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, OLD_MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)));

        when(channelInfoRepository.query(CHANNEL_ID + 1)).thenReturn(Optional.empty());
        when(mediatorInfoRepository.query(OLD_MEDIATOR_ID)).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName(OLD_MEDIATOR_NAME).setTypeName(MEDIATOR_TYPE).build(OLD_MEDIATOR_ID, VERSION)
        ));
        when(mediatorInfoRepository.query(NEW_MEDIATOR_ID)).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName(OLD_MEDIATOR_NAME).setTypeName(MEDIATOR_TYPE).build(OLD_MEDIATOR_ID, VERSION)
        ));

        when(channelInfoRepository.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        try {
            new MoveChannelsToAnotherMediator<>(context, channelManagers, mediatorEntityRepository, mediatorInstanceEntityRepository,
                    loggerManager, Collections.singletonList(CHANNEL_ID + 1), NEW_MEDIATOR_ID, physicalChannelModification)
                    .call();
        } catch (CommandException e) {
            //Exception caught
        }

        verifyZeroInteractions(channelNotifications, channelPhysicalConnectionRepository);
    }

    @Test
    public void moveToSameMediatorIgnored() throws DcnManagerException {
        when(channelInfoRepository.query(CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder()
                .setType(CHANNEL_TYPE).build(CHANNEL_ID, VERSION, OLD_MEDIATOR_ID)));
        when(channelUserPreferencesRepository.query(CHANNEL_ID)).thenReturn(Optional.of(
                new ChannelUserPreferencesBuilder().setName(CHANNEL_NAME).build(CHANNEL_ID, VERSION)));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(singleton(
                new ChannelPhysicalConnectionBuilder().build(
                        CHANNEL_INSTANCE_ID, OLD_MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(mediatorInfoRepository.query(OLD_MEDIATOR_ID)).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName(OLD_MEDIATOR_NAME).setTypeName(MEDIATOR_TYPE).build(OLD_MEDIATOR_ID, VERSION)
        ));
        when(mediatorInfoRepository.query(NEW_MEDIATOR_ID)).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName(OLD_MEDIATOR_NAME).setTypeName(MEDIATOR_TYPE).build(OLD_MEDIATOR_ID, VERSION)
        ));

        new MoveChannelsToAnotherMediator<>(context, channelManagers, mediatorEntityRepository, mediatorInstanceEntityRepository,
                loggerManager, Collections.singletonList(CHANNEL_ID), OLD_MEDIATOR_ID, physicalChannelModification)
                .call();

        verifyZeroInteractions(channelNotifications, loggerManager, channelPhysicalConnectionRepository);
    }

    @Test
    public void moveToWrongMediatorType() throws DcnManagerException {
        when(channelInfoRepository.query(CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder()
                .setType(CHANNEL_TYPE).build(CHANNEL_ID, VERSION, OLD_MEDIATOR_ID)));
        when(channelUserPreferencesRepository.query(CHANNEL_ID)).thenReturn(Optional.of(
                new ChannelUserPreferencesBuilder().setName(CHANNEL_NAME).build(CHANNEL_ID, VERSION)));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(singleton(
                new ChannelPhysicalConnectionBuilder().build(
                        CHANNEL_INSTANCE_ID, OLD_MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(mediatorInfoRepository.query(OLD_MEDIATOR_ID)).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName(OLD_MEDIATOR_NAME).setTypeName(MEDIATOR_TYPE).build(OLD_MEDIATOR_ID, VERSION)
        ));
        when(mediatorInfoRepository.query(NEW_MEDIATOR_ID)).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName(OLD_MEDIATOR_NAME).setTypeName("wrong type").build(OLD_MEDIATOR_ID, VERSION)
        ));

        when(channelInfoRepository.tryUpdate(isA(ChannelInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        try {
            new MoveChannelsToAnotherMediator<>(context, channelManagers, mediatorEntityRepository, mediatorInstanceEntityRepository,
                    loggerManager, Collections.singletonList(CHANNEL_ID), NEW_MEDIATOR_ID, physicalChannelModification)
                    .call();
        } catch (CommandException e) {
            //Exception caught
        }

        verifyZeroInteractions(channelNotifications, channelPhysicalConnectionRepository);
    }

    @Test
    public void oldMediatorNotFound() throws DcnManagerException {
        when(channelInfoRepository.query(CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder()
                .setType(CHANNEL_TYPE).build(CHANNEL_ID, VERSION, OLD_MEDIATOR_ID)));
        when(channelUserPreferencesRepository.query(CHANNEL_ID)).thenReturn(Optional.of(
                new ChannelUserPreferencesBuilder().setName(CHANNEL_NAME).build(CHANNEL_ID, VERSION)));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(singleton(
                new ChannelPhysicalConnectionBuilder().build(
                        CHANNEL_INSTANCE_ID, OLD_MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(mediatorInfoRepository.query(OLD_MEDIATOR_ID)).thenReturn(Optional.empty());
        when(mediatorInfoRepository.query(NEW_MEDIATOR_ID)).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName(OLD_MEDIATOR_NAME).setTypeName(MEDIATOR_TYPE).build(OLD_MEDIATOR_ID, VERSION)
        ));

        try {
            new MoveChannelsToAnotherMediator<>(context, channelManagers, mediatorEntityRepository, mediatorInstanceEntityRepository,
                    loggerManager, Collections.singletonList(CHANNEL_ID), NEW_MEDIATOR_ID, physicalChannelModification)
                    .call();
        } catch (CommandException e) {
            //Exception caught
        }

        verifyZeroInteractions(channelNotifications, channelPhysicalConnectionRepository);
    }

    @Test(expected = CommandException.class)
    public void newMediatorNotFoundFails() throws Exception {
        when(channelInfoRepository.query(CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder()
                .setType(CHANNEL_TYPE).build(CHANNEL_ID, VERSION, OLD_MEDIATOR_ID)));
        when(channelUserPreferencesRepository.query(CHANNEL_ID)).thenReturn(Optional.of(
                new ChannelUserPreferencesBuilder().setName(CHANNEL_NAME).build(CHANNEL_ID, VERSION)));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(singleton(
                new ChannelPhysicalConnectionBuilder().build(
                        CHANNEL_INSTANCE_ID, OLD_MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(mediatorInfoRepository.query(OLD_MEDIATOR_ID)).thenReturn(Optional.empty());
        when(mediatorInfoRepository.query(NEW_MEDIATOR_ID)).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName(OLD_MEDIATOR_NAME).setTypeName(MEDIATOR_TYPE).build(OLD_MEDIATOR_ID, VERSION)
        ));

        new MoveChannelsToAnotherMediator<>(context, channelManagers, mediatorEntityRepository, mediatorInstanceEntityRepository,
                loggerManager, Collections.singletonList(CHANNEL_ID), NEW_MEDIATOR_ID, physicalChannelModification)
                .call();
    }
}
