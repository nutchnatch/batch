package com.ossnms.dcn_manager.commands.channel;

import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.when;

public class GetChannelTest extends ChannelTestBase {

    private ChannelEntity entity;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        entity = new ChannelEntity(null, null, null);
    }

    @Test
    public void testGet() throws Exception {
        when(repo.queryChannel(1)).thenReturn(Optional.of(entity));
        final Optional<ChannelEntity> result = new GetChannel<>(null, repo, 1).call();
        assertThat(result.get(), is(entity));
    }

    @Test
    public void testNotFound() throws Exception {
        when(repo.queryChannel(anyInt())).thenReturn(Optional.empty());
        final Optional<ChannelEntity> result = new GetChannel<>(null, repo, 987).call();
        assertThat(result.isPresent(), is(false));
    }

    @Test(expected=CommandException.class)
    public void testGetError() throws Exception {
        when(repo.queryChannel(anyInt())).thenThrow(new RepositoryException());
        new GetChannel<>(null, repo, 987).call();
    }

}
