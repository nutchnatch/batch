package com.ossnms.dcn_manager.commands.container;

import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class DeleteContainerTest {

    private static final int SYSTEM_ID = 19;

    private ContainerNotifications notifications;
    private LoggerManager<CallContext> loggerManager;
    private ContainerRepository containerRepository;
    private CallContext context;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        notifications = mock(ContainerNotifications.class);
        loggerManager = mock(LoggerManager.class);
        containerRepository = mock(ContainerRepository.class);
        context = mock(CallContext.class);
    }

    @Test
    public void delete() throws Exception {
        final ContainerInfo container = new ContainerInfo(SYSTEM_ID, 1, "name");

        when(containerRepository.query(anyInt())).thenReturn(Optional.of(container));

        new DeleteContainer<>(context, containerRepository, notifications, loggerManager, SYSTEM_ID)
            .call();

        final ArgumentCaptor<ContainerDeletionDescriptor> delCaptor = ArgumentCaptor.forClass(ContainerDeletionDescriptor.class);

        verify(containerRepository).delete(delCaptor.capture());
        verify(notifications).notifyDelete(container);
        verify(loggerManager).createCommandLog(any(CallContext.class), any(LoggerItem[].class));

        assertThat(delCaptor.getValue().getId(), is(SYSTEM_ID));
    }

    @Test
    public void delete_unknownContainerId_ignores() throws Exception {

        when(containerRepository.query(anyInt())).thenReturn(Optional.empty());

        new DeleteContainer<>(context, containerRepository, notifications, loggerManager, SYSTEM_ID)
            .call();

        verify(containerRepository, never()).delete(any(ContainerDeletionDescriptor.class));
        verifyZeroInteractions(notifications, loggerManager);
    }

    @Test(expected=CommandException.class)
    public void delete_queryRepoError_throws() throws Exception {

        when(containerRepository.query(anyInt())).thenThrow(new RepositoryException());

        new DeleteContainer<>(context, containerRepository, notifications, loggerManager, SYSTEM_ID)
            .call();
    }

    @Test(expected=CommandException.class)
    public void delete_deleteRepoError_throws() throws Exception {
        final ContainerInfo container = new ContainerInfo(SYSTEM_ID, 1, "name");

        when(containerRepository.query(anyInt())).thenReturn(Optional.of(container));
        doThrow(new RepositoryException()).when(containerRepository).delete(any(ContainerDeletionDescriptor.class));

        new DeleteContainer<>(context, containerRepository, notifications, loggerManager, SYSTEM_ID)
            .call();
    }
}
