package com.ossnms.dcn_manager.events.discovery;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import com.ossnms.dcn_manager.core.test.MockFactory;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class HasPropertiesPresentTest {

    private LoggerManager<CallContext> logger;
    private NeType type;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        logger = mock(LoggerManager.class);
        type = MockFactory.mockNeType();
    }

    @Test
    public void propertiesPresent() {
        final NeDiscoveredEvent event = new NeDiscoveredEvent(new NeCreateDescriptor(2, type),
                ImmutableMap.of("A", "B"), Optional.of("name"), 1);
        final Boolean result = new HasPropertiesPresent<>(null, logger).call(event);
        assertThat(result, is(true));
    }

    @Test
    public void noPropertiesPresent_zeroLength() {
        final NeDiscoveredEvent event = new NeDiscoveredEvent(new NeCreateDescriptor(2, type),
                ImmutableMap.of(), Optional.of("name"), 1);

        final Boolean result = new HasPropertiesPresent<>(null, logger).call(event);
        assertThat(result, is(false));

        verify(logger).createNetworkResourceLog(any(CallContext.class), any(LoggerItemNe[].class));
    }

    @Test
    public void noPropertiesPresent_null() {
        final NeDiscoveredEvent event = new NeDiscoveredEvent(new NeCreateDescriptor(2, type),
                null, Optional.of("name"), 1);

        final Boolean result = new HasPropertiesPresent<>(null, logger).call(event);
        assertThat(result, is(false));

        verify(logger).createNetworkResourceLog(any(CallContext.class), any(LoggerItemNe[].class));
    }

}
