package com.ossnms.dcn_manager.events.mediator;

import static java.util.Collections.emptyList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.QChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelConnectionRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.CollQueryAnswer;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public class PhysicalMediatorActivatedEventHandlerTest {

    private static final int MEDIATOR_ID = 42;
    private static final int MEDIATOR_INSTANCE = 33;
    private static final int VERSION = 1;

    private static final int ACTIVE_CHANNEL_INSTANCE = 99;
    private static final int INACTIVE_CHANNEL_INSTANCE = 88;
    private static final int FOREIGN_CHANNEL_INSTANCE = 77;

    private static final int CHANNEL_ID = 90;
    private static final int FOREIGN_CHANNEL_ID = 21;
    
    protected static final int CONCURRENT_ACTIVATIONS_LIMIT = 64;


    private PhysicalMediatorActivatedEventHandler<CallContext> handler;
    private CallContext context;

    

    private MediatorEntityRepository entityRepository;
    private MediatorConnectionRepository connectionStateRepository;
    private MediatorInstanceEntityRepository physicalRepository;
    private MediatorPhysicalConnectionRepository mediatorPhysicalConnectionRepository;
    private MediatorNotifications notifications;
    private MediatorInteractionManager activationManager;
    private MessageSource<MediatorEvent> mediatorEvents;

    private ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    private ChannelEntityRepository channelRepository;
    private ChannelInfoRepository channelInfoRepository;
    private ChannelConnectionRepository channelConnectionRepository;
    private ChannelNotifications channelNotifications;
    private ChannelInteractionManager channelActivationManager;
    private MessageSource<ChannelEvent> channelEvents;

    private SettingsRepository settingsRepository;
    
    private Types<MediatorType> mediatorTypes;
    private StaticConfiguration configuration;
    private MediatorType mediatorType;
    private MediatorEntity mediatorEntity;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        context = mock(CallContext.class);

        physicalRepository = mock(MediatorInstanceEntityRepository.class);
        mediatorPhysicalConnectionRepository = mock(MediatorPhysicalConnectionRepository.class);
        entityRepository = mock(MediatorEntityRepository.class);
        connectionStateRepository = mock(MediatorConnectionRepository.class);
        notifications = mock(MediatorNotifications.class);
        activationManager = mock(MediatorInteractionManager.class);
        mediatorEvents = mock(MessageSource.class);

        channelPhysicalConnectionRepository = mock(ChannelPhysicalConnectionRepository.class);
        channelInfoRepository = mock(ChannelInfoRepository.class);
        channelConnectionRepository = mock(ChannelConnectionRepository.class);
        channelRepository = mock(ChannelEntityRepository.class);
        channelNotifications = mock(ChannelNotifications.class);
        channelActivationManager = mock(ChannelInteractionManager.class);
        channelEvents = mock(MessageSource.class);

        settingsRepository = mock(SettingsRepository.class);

        configuration = mock(StaticConfiguration.class);
        mediatorTypes = mock(Types.class);
        mediatorType = mock(MediatorType.class);
        mediatorEntity = new MediatorEntity(
                newInfo(false),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));
        
        when(channelInfoRepository.queryActivationRequiredIs(MEDIATOR_ID, ChannelInfoData.ACTIVATION_REQUIRED))
            .thenReturn(ImmutableList.of(
                new ChannelInfoBuilder().setType("type").setActivationRequired(true).build(CHANNEL_ID, VERSION, MEDIATOR_ID)
            )
        );
        when(channelPhysicalConnectionRepository.query(isA(QChannelPhysicalConnectionData.class)))
            .then(new CollQueryAnswer<>(
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE).build(ACTIVE_CHANNEL_INSTANCE, MEDIATOR_INSTANCE, CHANNEL_ID, VERSION),
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.INACTIVE).build(INACTIVE_CHANNEL_INSTANCE, MEDIATOR_INSTANCE, CHANNEL_ID, VERSION),
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.INACTIVE).build(FOREIGN_CHANNEL_INSTANCE, MEDIATOR_INSTANCE, FOREIGN_CHANNEL_ID, VERSION)
            )
        );

        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
        when(channelRepository.getChannelConnectionRepository()).thenReturn(channelConnectionRepository);

        when(physicalRepository.getMediatorPhysicalConnectionRepository()).thenReturn(mediatorPhysicalConnectionRepository);

        when(entityRepository.getMediatorConnectionRepository()).thenReturn(connectionStateRepository);

        when(mediatorPhysicalConnectionRepository.queryAll(anyInt())).thenReturn(emptyList());

        when(entityRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(mediatorEntity));
        
        when(configuration.getMediatorTypes()).thenReturn(mediatorTypes);      
        when(mediatorTypes.get(anyString())).thenReturn(mediatorType);        
        when(mediatorType.supportsHotStandby()).thenReturn(true);
        
        handler = new PhysicalMediatorActivatedEventHandler<>(context,
                new MediatorManagers(entityRepository, physicalRepository, notifications, activationManager, mediatorEvents),
                new ChannelManagers(channelRepository, channelPhysicalConnectionRepository, channelNotifications, channelActivationManager, channelEvents),
                settingsRepository,
                configuration);
    }

    
    @Test
    public void event_onActivatingMediator() throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.ACTIVATING)
            .setAdditionalInfo("")
            .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);
        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));
        when(mediatorPhysicalConnectionRepository.tryUpdate(isA(MediatorPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(settingsRepository.areStandbyConnectionsAllowed()).thenReturn(true);

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        final ArgumentCaptor<MediatorPhysicalConnectionMutationDescriptor> captor =
                ArgumentCaptor.forClass(MediatorPhysicalConnectionMutationDescriptor.class);
        verify(mediatorPhysicalConnectionRepository).tryUpdate(captor.capture());

        assertThat(captor.getValue().getTarget().getId(), is(MEDIATOR_INSTANCE));
        assertThat(captor.getValue().getTarget().getLogicalMediatorId(), is(MEDIATOR_ID));
        assertThat(captor.getValue().getActiveState().get(), is(ActualActivationState.ACTIVE));
    }

    @Test
    public void event_onActivatingMediator_updateFails_isIgnored() throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.ACTIVATING)
            .setAdditionalInfo("")
            .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);
        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class)))
            .thenReturn(Optional.empty());

        when(settingsRepository.areStandbyConnectionsAllowed()).thenReturn(true);

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verifyZeroInteractions(channelActivationManager, channelConnectionRepository, channelInfoRepository);
    }

    @Test
    public void event_onActivatingMediator_standbyConnectionsAllowed_cascadesToStandbyInstances() throws Exception {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
                .setActualActivationState(ActualActivationState.ACTIVATING)
                .setAdditionalInfo("")
                .setActive(true)
                .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);

        final MediatorPhysicalConnectionData standbyState = new MediatorPhysicalConnectionBuilder()
                .setActualActivationState(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .setActive(false)
                .build(MEDIATOR_INSTANCE + 1, MEDIATOR_ID, VERSION);

        when(settingsRepository.areStandbyConnectionsAllowed()).thenReturn(true);

        when(entityRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(mediatorEntity));
        
        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));
        when(mediatorPhysicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(ImmutableList.of(state, standbyState));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verify(activationManager, never()).scheduleActivation(new ActivateMediatorEvent(MEDIATOR_ID, MEDIATOR_INSTANCE));
        verify(activationManager).scheduleActivation(new ActivateMediatorEvent(MEDIATOR_ID, MEDIATOR_INSTANCE + 1));
    }

    @Test
    public void event_onActivatingMediator_standbyConnectionsNotAllowed_doesNotCascadeToStandbyInstances() throws Exception {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
                .setActualActivationState(ActualActivationState.ACTIVATING)
                .setAdditionalInfo("")
                .setActive(true)
                .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);

        final MediatorPhysicalConnectionData standbyState = new MediatorPhysicalConnectionBuilder()
                .setActualActivationState(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .setActive(false)
                .build(MEDIATOR_INSTANCE + 1, MEDIATOR_ID, VERSION);

        when(settingsRepository.areStandbyConnectionsAllowed()).thenReturn(false);

        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));
        when(mediatorPhysicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(ImmutableList.of(state, standbyState));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verify(activationManager, never()).scheduleActivation(new ActivateMediatorEvent(MEDIATOR_ID, MEDIATOR_INSTANCE));
        verify(activationManager, never()).scheduleActivation(new ActivateMediatorEvent(MEDIATOR_ID, MEDIATOR_INSTANCE + 1));
    }

    @Test
    public void event_onActivatingMediator_standbyInstance_doesNotCascadeToSiblingInstances() throws Exception {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
                .setActualActivationState(ActualActivationState.ACTIVATING)
                .setAdditionalInfo("")
                .setActive(false)
                .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);

        final MediatorPhysicalConnectionData standbyState = new MediatorPhysicalConnectionBuilder()
                .setActualActivationState(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .setActive(false)
                .build(MEDIATOR_INSTANCE + 1, MEDIATOR_ID, VERSION);

        when(settingsRepository.areStandbyConnectionsAllowed()).thenReturn(true);

        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));
        when(mediatorPhysicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(ImmutableList.of(state, standbyState));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verify(activationManager, never()).scheduleActivation(new ActivateMediatorEvent(MEDIATOR_ID, MEDIATOR_INSTANCE));
        verify(activationManager, never()).scheduleActivation(new ActivateMediatorEvent(MEDIATOR_ID, MEDIATOR_INSTANCE + 1));
    }

    @Test
    public void event_onActivatingMediator_cascadesToStandbyInstances_mediatorStandbyRepoError_isIgnored() throws Exception {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
                .setActualActivationState(ActualActivationState.ACTIVATING)
                .setAdditionalInfo("")
                .setActive(true)
                .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);

        final MediatorPhysicalConnectionData standbyState = new MediatorPhysicalConnectionBuilder()
                .setActualActivationState(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .setActive(false)
                .build(MEDIATOR_INSTANCE + 1, MEDIATOR_ID, VERSION);

        when(settingsRepository.areStandbyConnectionsAllowed()).thenReturn(true);

        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));
        when(mediatorPhysicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(ImmutableList.of(state, standbyState));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class)))
                .then(new MutationAnswer<>()).thenThrow(new RepositoryException());
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verify(activationManager, never()).scheduleActivation(any(ActivateMediatorEvent.class));
    }

    @Test
    public void event_onActivatingMediator_cascadesToStandbyInstances_concurrentStandbyActivation_isIgnored() throws Exception {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
                .setActualActivationState(ActualActivationState.ACTIVATING)
                .setAdditionalInfo("")
                .setActive(true)
                .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);

        final MediatorPhysicalConnectionData standbyState = new MediatorPhysicalConnectionBuilder()
                .setActualActivationState(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .setActive(false)
                .build(MEDIATOR_INSTANCE + 1, MEDIATOR_ID, VERSION);

        when(settingsRepository.areStandbyConnectionsAllowed()).thenReturn(true);

        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));
        when(mediatorPhysicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(ImmutableList.of(state, standbyState));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class)))
                .then(new MutationAnswer<>()).thenReturn(Optional.empty());
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verify(activationManager, never()).scheduleActivation(any(ActivateMediatorEvent.class));
    }

    @Test
    public void event_onActivatingMediator_cascadesToChannels() throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.ACTIVATING)
            .setAdditionalInfo("")
            .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);
        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verify(channelActivationManager).scheduleActivation(new Activate(CHANNEL_ID, MEDIATOR_ID, Collections.singleton(INACTIVE_CHANNEL_INSTANCE)));
    }

    @Test
    public void event_onActivatingMediator_cascadesToChannels_channelRepoError_isIgnored() throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.ACTIVATING)
            .setAdditionalInfo("")
            .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);
        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));

        when(channelInfoRepository.queryActivationRequiredIs(MEDIATOR_ID, ChannelInfoData.ACTIVATION_REQUIRED)).thenThrow(new RepositoryException());
        when(mediatorPhysicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verifyZeroInteractions(channelActivationManager);
    }

    @Test
    public void event_onActivatingMediator_cascadesToChannels_channelConnectionUpdateFailure_isIgnored() throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.ACTIVATING)
            .setAdditionalInfo("")
            .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);
        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class)))
            .thenReturn(Optional.empty());

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verifyZeroInteractions(channelActivationManager);
    }

    @Test
    public void event_onActivatingMediator_cascadesToChannels_channelConnectionRepositoryException_isIgnored() throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.ACTIVATING)
            .setAdditionalInfo("")
            .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);
        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class)))
            .thenThrow(new RepositoryException());

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verifyZeroInteractions(channelActivationManager);
    }

    @Test
    public void event_mediatorNotFound() throws RepositoryException {
        when(connectionStateRepository.query(MEDIATOR_ID)).thenReturn(Optional.empty());

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verify(mediatorPhysicalConnectionRepository, never()).tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void event_onActiveMediator() throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.ACTIVE)
            .setAdditionalInfo("")
            .build(MEDIATOR_INSTANCE, MEDIATOR_ID, VERSION);
        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE)).thenReturn(Optional.of(state));

        handler.call(new PhysicalMediatorActivatedEvent(MEDIATOR_INSTANCE, MEDIATOR_ID, false));

        verify(mediatorPhysicalConnectionRepository, never()).tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class));
    }
    
    protected MediatorInfoData newInfo(boolean activationRequired) {
        return newInfoBuilder(activationRequired)
            .build(MEDIATOR_ID, VERSION);
    }

    protected MediatorInfoBuilder newInfoBuilder(boolean activationRequired) {
        return new MediatorInfoBuilder()
            .setName("name")
            .setTypeName("type")
            .setDescription(Optional.of(""))
            .setActivationRequired(activationRequired)
            .setConcurrentActivationsLimited(true)
            .setConcurrentActivationsLimit(CONCURRENT_ACTIVATIONS_LIMIT);
    }

}
