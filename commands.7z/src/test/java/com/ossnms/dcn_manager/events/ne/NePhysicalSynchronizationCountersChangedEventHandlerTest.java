package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NePhysicalSynchronizationCountersChangedEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeSynchronizationRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class NePhysicalSynchronizationCountersChangedEventHandlerTest {

    private static final int NE_ID = 23;
    private static final int NE_INSTANCE_ID = 230;

    private NeSynchronizationRepository repository;
    private NePhysicalSynchronizationCountersChangedEventHandler<?> eventHandler;

    @Before
    public void setUp() {
        repository = mock(NeSynchronizationRepository.class);

        final NeEntityRepository entityRepository = mock(NeEntityRepository.class);
        when(entityRepository.getNeSynchronizationRepository()).thenReturn(repository);

        eventHandler = new NePhysicalSynchronizationCountersChangedEventHandler<>(null, entityRepository);
    }

    @Test(expected=UnknownNetworkElementIdException.class)
    public void neNotFound_throws() throws Exception {
        when(repository.query(anyInt())).thenReturn(Optional.empty());

        eventHandler.handleEvent(new NePhysicalSynchronizationCountersChangedEvent(NE_INSTANCE_ID, NE_ID,
                Optional.empty(), Optional.empty(), Optional.empty()));
    }

    @Test(expected=DataUpdateException.class)
    public void neFound_withEventData_updateFails_throws() throws Exception {
        final NeSynchronizationData originalData = new NeSynchronizationBuilder()
                .setAlarms(Optional.of(1L))
                .setAll(Optional.of(2L))
                .setPacket(Optional.of(3L))
                .build(NE_ID, 0);

        when(repository.query(NE_ID)).thenReturn(Optional.of(originalData));
        when(repository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).thenReturn(Optional.empty());

        eventHandler.handleEvent(new NePhysicalSynchronizationCountersChangedEvent(NE_INSTANCE_ID, NE_ID,
                Optional.of(9L), Optional.of(8L), Optional.of(7L)));
    }

    @Test
    public void neFound_noEventData_noUpdate() throws Exception {
        final NeSynchronizationData originalData = new NeSynchronizationBuilder().build(NE_ID, 0);

        when(repository.query(NE_ID)).thenReturn(Optional.of(originalData));
        when(repository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        eventHandler.handleEvent(new NePhysicalSynchronizationCountersChangedEvent(NE_INSTANCE_ID, NE_ID,
                Optional.empty(), Optional.empty(), Optional.empty()));

        final ArgumentCaptor<NeSynchronizationMutationDescriptor> captor =
                ArgumentCaptor.forClass(NeSynchronizationMutationDescriptor.class);
        verify(repository).tryUpdate(captor.capture());
        assertThat(captor.getValue().getResult(), is(originalData));
    }

    @Test
    public void neFound_withEventData_updates() throws Exception {
        final NeSynchronizationData originalData = new NeSynchronizationBuilder()
                .setAll(Optional.of(1L))
                .setAlarms(Optional.of(2L))
                .setPacket(Optional.of(3L))
                .build(NE_ID, 0);

        final NeSynchronizationData targetData = new NeSynchronizationBuilder()
                .setAll(Optional.of(9L))
                .setAlarms(Optional.of(8L))
                .setPacket(Optional.of(7L))
                .build(NE_ID, 0);

        when(repository.query(NE_ID)).thenReturn(Optional.of(originalData));
        when(repository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        eventHandler.handleEvent(new NePhysicalSynchronizationCountersChangedEvent(NE_INSTANCE_ID, NE_ID,
                Optional.of(9L), Optional.of(8L), Optional.of(7L)));

        final ArgumentCaptor<NeSynchronizationMutationDescriptor> captor =
                ArgumentCaptor.forClass(NeSynchronizationMutationDescriptor.class);
        verify(repository).tryUpdate(captor.capture());
        assertThat(captor.getValue().getResult(), is(targetData));
    }
}
