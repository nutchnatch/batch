package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatingEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class PhysicalMediatorActivatingEventHandlerTest {

    private static final int MEDIATOR_ID = 42;
    private static final int PHYSICAL_ID = 87;
    private static final int VERSION = 1;

    private PhysicalMediatorActivatingEventHandler<CallContext> handler;
    private CallContext context;
    private MediatorEntityRepository entityRepository;
    private MediatorInstanceEntityRepository physicalRepository;
    private MediatorPhysicalConnectionRepository connectionStateRepository;
    private MediatorNotifications notifications;
    private MediatorInteractionManager activationManager;
    private MessageSource<MediatorEvent> mediatorEvents;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        context = mock(CallContext.class);
        entityRepository = mock(MediatorEntityRepository.class);
        physicalRepository = mock(MediatorInstanceEntityRepository.class);
        connectionStateRepository = mock(MediatorPhysicalConnectionRepository.class);
        notifications = mock(MediatorNotifications.class);
        activationManager = mock(MediatorInteractionManager.class);
        mediatorEvents = mock(MessageSource.class);

        when(connectionStateRepository.tryUpdate(isA(MediatorPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(physicalRepository.getMediatorPhysicalConnectionRepository()).thenReturn(connectionStateRepository);

        handler = new PhysicalMediatorActivatingEventHandler<>(context,
                new MediatorManagers(entityRepository, physicalRepository, notifications, activationManager, mediatorEvents));
    }

    @Test
    public void event_onStartingUpMediator_inactiveInstance_doesNotPropagate() throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.STARTINGUP)
            .setAdditionalInfo("")
            .build(PHYSICAL_ID, MEDIATOR_ID, VERSION);
        when(connectionStateRepository.query(PHYSICAL_ID)).thenReturn(Optional.of(state));

        final PhysicalMediatorActivatingEvent event = new PhysicalMediatorActivatingEvent(PHYSICAL_ID, MEDIATOR_ID, false);
        handler.call(event);

        final ArgumentCaptor<MediatorPhysicalConnectionMutationDescriptor> captor =
                ArgumentCaptor.forClass(MediatorPhysicalConnectionMutationDescriptor.class);
        verify(connectionStateRepository).tryUpdate(captor.capture());

        assertThat(captor.getValue().getTarget().getId(), is(PHYSICAL_ID));
        assertThat(captor.getValue().getActiveState().get(), is(ActualActivationState.ACTIVATING));

        verify(mediatorEvents, never()).push(new MediatorActivatingEvent(MEDIATOR_ID, event));
        verify(notifications).notifyChanges(new MediatorActivatingEvent(MEDIATOR_ID, event));
    }

    @Test
    public void event_onStartingUpMediator_activeInstance_propagates() throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.STARTINGUP)
            .setAdditionalInfo("")
            .setActive(true)
            .build(PHYSICAL_ID, MEDIATOR_ID, VERSION);
        when(connectionStateRepository.query(PHYSICAL_ID)).thenReturn(Optional.of(state));

        final PhysicalMediatorActivatingEvent event = new PhysicalMediatorActivatingEvent(PHYSICAL_ID, MEDIATOR_ID, true);
        handler.call(event);

        final ArgumentCaptor<MediatorPhysicalConnectionMutationDescriptor> captor =
                ArgumentCaptor.forClass(MediatorPhysicalConnectionMutationDescriptor.class);
        verify(connectionStateRepository).tryUpdate(captor.capture());

        assertThat(captor.getValue().getTarget().getId(), is(PHYSICAL_ID));
        assertThat(captor.getValue().getActiveState().get(), is(ActualActivationState.ACTIVATING));

        verify(mediatorEvents).push(new MediatorActivatingEvent(MEDIATOR_ID, event));
        verify(notifications).notifyChanges(new MediatorActivatingEvent(MEDIATOR_ID, event));
    }

    @Test
    public void event_mediatorNotFound() throws RepositoryException {
        when(connectionStateRepository.query(MEDIATOR_ID)).thenReturn(Optional.empty());

        handler.call(new PhysicalMediatorActivatingEvent(PHYSICAL_ID, MEDIATOR_ID, false));

        verify(connectionStateRepository, never()).tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void event_onActiveMediator() throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.ACTIVE)
            .setAdditionalInfo("")
            .build(PHYSICAL_ID, MEDIATOR_ID, VERSION);
        when(connectionStateRepository.query(PHYSICAL_ID)).thenReturn(Optional.of(state));

        handler.call(new PhysicalMediatorActivatingEvent(PHYSICAL_ID, MEDIATOR_ID, false));

        verify(connectionStateRepository, never()).tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class));
    }

}
