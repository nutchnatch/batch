package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.commands.ne.NeTestBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NeTypeChangedEvent;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class UpdateNeTypeEventHandlerTest extends NeTestBase {

    private static final int ID = 1, VERSION = 1;

    private NeType type;

    private UpdateNeTypeEventHandler<CallContext> handler;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        type = MockFactory.mockNeType();

        when(neTypes.get(type.getName())).thenReturn(type);

        handler = new UpdateNeTypeEventHandler<>(context, neRepo, notif, staticConfig);
    }

    @Test
    public void updateNeType() throws RepositoryException {

        when(infoRepo.query(ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType("other").build(ID, 1, VERSION)));
        when(infoRepo.tryUpdate(any(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new NeTypeChangedEvent(ID, type.getName()));

        final ArgumentCaptor<NeInfoMutationDescriptor> mutationCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);

        verify(infoRepo).tryUpdate(mutationCaptor.capture());
        verify(notif).notifyChanges(isA(NeInfoMutationDescriptor.class));

        assertThat(mutationCaptor.getValue().getProxyType().get(), is(type.getName()));

    }

    @Test
    public void updateNeType_unknownType_ignores() throws RepositoryException {

        handler.call(new NeTypeChangedEvent(ID, "unknown type"));

        verify(infoRepo, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verifyZeroInteractions(notif);

    }

    @Test
    public void updateNeType_unknownNe_ignores() throws RepositoryException {

        when(infoRepo.query(ID)).thenReturn(Optional.<NeInfoData>empty());

        handler.call(new NeTypeChangedEvent(ID, type.getName()));

        verify(infoRepo, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verifyZeroInteractions(notif);
    }

    @Test
    public void updateNeType_dataNotUpdated_ignores() throws RepositoryException {

        when(infoRepo.query(ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType("other").build(ID, 1, VERSION)));
        when(infoRepo.tryUpdate(any(NeInfoMutationDescriptor.class))).thenReturn(Optional.<NeInfoData>empty());

        handler.call(new NeTypeChangedEvent(ID, type.getName()));

        verifyZeroInteractions(notif);
    }
}
