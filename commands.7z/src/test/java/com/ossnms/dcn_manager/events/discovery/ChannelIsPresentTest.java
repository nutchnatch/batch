package com.ossnms.dcn_manager.events.discovery;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import com.ossnms.dcn_manager.core.test.MockFactory;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class ChannelIsPresentTest {

    private LoggerManager<CallContext> logger;
    private NeDiscoveredEvent event;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        logger = mock(LoggerManager.class);
        final NeType type = MockFactory.mockNeType();
        event = new NeDiscoveredEvent(new NeCreateDescriptor(2, type), ImmutableMap.of(), Optional.of("name"), 1);
    }

    @Test
    public void isPresent() {
        final ChannelInfoData info = new ChannelInfoBuilder().setType("type").setCoreId("").setActivationRequired(false).build(1, 1, 1);
        final Pair<Optional<ChannelInfoData>, NeDiscoveredEvent> data =
                Pair.of(Optional.of(info), event);

        final Boolean result = new ChannelIsPresent<>(null, logger).call(data);
        assertThat(result, is(true));
    }

    @Test
    public void isAbsent() {
        final Pair<Optional<ChannelInfoData>, NeDiscoveredEvent> data =
                Pair.of(Optional.<ChannelInfoData>empty(), event);

        final Boolean result = new ChannelIsPresent<>(null, logger).call(data);
        assertThat(result, is(false));

        verify(logger).createNetworkResourceLog(any(CallContext.class), any(LoggerItemNe[].class));
    }

}
