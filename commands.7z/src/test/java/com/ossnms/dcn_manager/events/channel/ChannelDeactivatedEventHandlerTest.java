package com.ossnms.dcn_manager.events.channel;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.QNeConnectionData;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelConnectionRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.CollQueryAnswer;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class ChannelDeactivatedEventHandlerTest {

    private static final int CHANNEL_ID = 42;
    private static final int VERSION = 1;
    private static final int ACTIVE_NE_ID = 20;
    private static final int INACTIVE_NE_ID = 30;

    private ChannelDeactivatedEventHandler<CallContext> handler;
    private CallContext context;
    private ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    private ChannelEntityRepository entityRepository;
    private ChannelConnectionRepository connectionStateRepository;
    private ChannelNotifications notifications;
    private ChannelInteractionManager activationManager;
    private NetworkElementInteractionManager neActivationManager;
    private NeEntityRepository neRepository;
    private NeConnectionRepository neConnectionRepo;
    private NePhysicalConnectionRepository neInstancesRepository;
    private NetworkElementNotifications neNotifications;
    private MessageSource<NeEvent> neMessages;
    private MessageSource<ChannelEvent> channelEvents;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        context = mock(CallContext.class);
        channelPhysicalConnectionRepository = mock(ChannelPhysicalConnectionRepository.class);
        entityRepository = mock(ChannelEntityRepository.class);
        connectionStateRepository = mock(ChannelConnectionRepository.class);
        notifications = mock(ChannelNotifications.class);
        activationManager = mock(ChannelInteractionManager.class);
        neActivationManager = mock(NetworkElementInteractionManager.class);
        neRepository = mock(NeEntityRepository.class);
        neConnectionRepo = mock(NeConnectionRepository.class);
        neNotifications = mock(NetworkElementNotifications.class);
        neMessages = mock(MessageSource.class);
        channelEvents = mock(MessageSource.class);
        neInstancesRepository = mock(NePhysicalConnectionRepository.class);

        when(neRepository.getNeConnectionRepository()).thenReturn(neConnectionRepo);
        when(neConnectionRepo.query(any(QNeConnectionData.class))).then(
                new CollQueryAnswer<>(
                        new NeConnectionBuilder().setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.CONNECTED).build(ACTIVE_NE_ID, VERSION),
                        new NeConnectionBuilder().setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED).build(INACTIVE_NE_ID, VERSION)
                )
        );
        when(neRepository.queryActualActivationIsDifferentThan(anyInt(), any(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.class)))
            .thenReturn(ImmutableList.of(new NeInfoBuilder().setProxyType("type").build(ACTIVE_NE_ID, CHANNEL_ID, VERSION)));

        when(connectionStateRepository.tryUpdate(any(ChannelConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(entityRepository.getChannelConnectionRepository()).thenReturn(connectionStateRepository);

        handler = new ChannelDeactivatedEventHandler<>(context,
                new ChannelManagers(entityRepository, channelPhysicalConnectionRepository, notifications, activationManager, channelEvents),
                new NetworkElementManagers(neRepository, neInstancesRepository, neActivationManager, neNotifications, neMessages));
    }

    @Test
    public void event_onDeactivatingChannel() throws RepositoryException {
        final ChannelConnectionData state = new ChannelConnectionBuilder()
            .setActivation(ActualActivationState.DEACTIVATING)
            .setAdditionalInfo("")
            .build(CHANNEL_ID, VERSION);
        when(connectionStateRepository.query(CHANNEL_ID)).thenReturn(Optional.of(state));

        handler.call(new ChannelDeactivatedEvent(CHANNEL_ID));

        final ArgumentCaptor<ChannelConnectionMutationDescriptor> captor =
                ArgumentCaptor.forClass(ChannelConnectionMutationDescriptor.class);
        verify(connectionStateRepository).tryUpdate(captor.capture());

        assertThat(captor.getValue().getTarget().getId(), is(CHANNEL_ID));
        assertThat(captor.getValue().getActualActivationState().get(), is(ActualActivationState.INACTIVE));

        verify(neMessages, never()).push(new NeDisconnectedEvent(ACTIVE_NE_ID));
        verify(neMessages, never()).push(new NeDisconnectedEvent(INACTIVE_NE_ID));
    }

    @Test
    public void event_channelNotFound() throws RepositoryException {
        when(connectionStateRepository.query(CHANNEL_ID)).thenReturn(Optional.empty());

        handler.call(new ChannelDeactivatedEvent(CHANNEL_ID));

        verify(connectionStateRepository, never()).tryUpdate(any(ChannelConnectionMutationDescriptor.class));
        verifyZeroInteractions(neMessages);
    }

    @Test
    public void event_onInactiveChannel() throws RepositoryException {
        final ChannelConnectionData state = new ChannelConnectionBuilder()
            .setActivation(ActualActivationState.INACTIVE)
            .setAdditionalInfo("")
            .build(CHANNEL_ID, VERSION);
        when(connectionStateRepository.query(CHANNEL_ID)).thenReturn(Optional.of(state));

        handler.call(new ChannelDeactivatedEvent(CHANNEL_ID));

        verify(connectionStateRepository, never()).tryUpdate(any(ChannelConnectionMutationDescriptor.class));
        verifyZeroInteractions(neMessages);
    }

}
