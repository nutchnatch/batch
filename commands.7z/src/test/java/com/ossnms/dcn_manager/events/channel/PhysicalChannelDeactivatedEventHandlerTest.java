package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.QNePhysicalConnectionData;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectedEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.CollQueryAnswer;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class PhysicalChannelDeactivatedEventHandlerTest {

    private static final int CHANNEL_ID = 42;
    private static final int VERSION = 1;
    private static final int ACTIVE_NE_ID = 20;
    private static final int INACTIVE_NE_ID = 30;
    private static final int CHANNEL_INSTANCE_ID = 4200;
    private static final int MEDIATOR_INSTANCE_ID = 5300;
    private static final int ACTIVE_NE_INSTANCE_ID = 9900;
    private static final int INACTIVE_NE_INSTANCE_ID = 8800;
    private static final int FOREIGN_NE_INSTANCE_ID = 7700;
    private static final int FOREIGN_NE_ID = 9900;

    private PhysicalChannelDeactivatedEventHandler<CallContext> handler;
    private CallContext context;
    private ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    private ChannelEntityRepository entityRepository;
    private ChannelNotifications notifications;
    private ChannelInteractionManager activationManager;
    private NetworkElementInteractionManager neActivationManager;
    private NeEntityRepository neRepository;
    private NePhysicalConnectionRepository neInstancesRepository;
    private NetworkElementNotifications neNotifications;
    private MessageSource<NeEvent> neMessages;
    private MessageSource<ChannelEvent> channelEvents;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        context = mock(CallContext.class);
        channelPhysicalConnectionRepository = mock(ChannelPhysicalConnectionRepository.class);
        entityRepository = mock(ChannelEntityRepository.class);
        notifications = mock(ChannelNotifications.class);
        activationManager = mock(ChannelInteractionManager.class);
        neActivationManager = mock(NetworkElementInteractionManager.class);
        neRepository = mock(NeEntityRepository.class);
        neNotifications = mock(NetworkElementNotifications.class);
        neMessages = mock(MessageSource.class);
        channelEvents = mock(MessageSource.class);
        neInstancesRepository = mock(NePhysicalConnectionRepository.class);

        when(neInstancesRepository.query(isA(QNePhysicalConnectionData.class)))
                .then(new CollQueryAnswer<>(
                    new NePhysicalConnectionBuilder().setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.INITIALIZED).build(ACTIVE_NE_INSTANCE_ID, ACTIVE_NE_ID, CHANNEL_INSTANCE_ID, VERSION),
                    new NePhysicalConnectionBuilder().setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED).build(INACTIVE_NE_INSTANCE_ID, INACTIVE_NE_ID, CHANNEL_INSTANCE_ID, VERSION),
                    new NePhysicalConnectionBuilder().setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED).build(FOREIGN_NE_INSTANCE_ID, FOREIGN_NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                )
            );
        when(neInstancesRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
            .then(new MutationAnswer<>());

        when(channelPhysicalConnectionRepository.tryUpdate(any(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler = new PhysicalChannelDeactivatedEventHandler<>(context,
                new ChannelManagers(entityRepository, channelPhysicalConnectionRepository, notifications, activationManager, channelEvents),
                new NetworkElementManagers(neRepository, neInstancesRepository, neActivationManager, neNotifications, neMessages));
    }

    @Test
    public void event_onDeactivatingChannel() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.DEACTIVATING)
                .setAdditionalInfo("")
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalChannelDeactivatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, false));

        final ArgumentCaptor<ChannelPhysicalConnectionMutationDescriptor> captor =
                ArgumentCaptor.forClass(ChannelPhysicalConnectionMutationDescriptor.class);
        verify(channelPhysicalConnectionRepository).tryUpdate(captor.capture());

        assertThat(captor.getValue().getTarget().getId(), is(CHANNEL_INSTANCE_ID));
        assertThat(captor.getValue().getActualActivationState().get(), is(ActualActivationState.INACTIVE));

        verify(neMessages).push(new PhysicalNeDisconnectedEvent(ACTIVE_NE_INSTANCE_ID, ACTIVE_NE_ID, false));
        verify(neMessages, never()).push(new PhysicalNeDisconnectedEvent(INACTIVE_NE_INSTANCE_ID, INACTIVE_NE_ID, false));
    }

    @Test
    public void event_channelNotFound() throws RepositoryException {
        when(channelPhysicalConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.empty());

        handler.call(new PhysicalChannelDeactivatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, false));

        verify(channelPhysicalConnectionRepository, never()).tryUpdate(any(ChannelPhysicalConnectionMutationDescriptor.class));
        verifyZeroInteractions(neMessages);
    }

    @Test
    public void event_onInactiveChannel() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalChannelDeactivatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, false));

        verify(channelPhysicalConnectionRepository, never()).tryUpdate(any(ChannelPhysicalConnectionMutationDescriptor.class));
        verifyZeroInteractions(neMessages);
    }

}
