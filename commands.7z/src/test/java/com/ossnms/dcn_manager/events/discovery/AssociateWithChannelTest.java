package com.ossnms.dcn_manager.events.discovery;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AssociateWithChannelTest {

    private static final int CHANNEL_ID = 2;
    private static final int NE_ID = 1;

    private ChannelEntityRepository repository;
    private ChannelInfoRepository infoRepository;
    private NeDiscoveredEvent event;

    @Before
    public void setUp() {
        repository = mock(ChannelEntityRepository.class);
        infoRepository = mock(ChannelInfoRepository.class);

        when(repository.getChannelInfoRepository()).thenReturn(infoRepository);

        final NeType type = MockFactory.mockNeType();
        event = new NeDiscoveredEvent(new NeCreateDescriptor(CHANNEL_ID, type), ImmutableMap.of(), Optional.of("name"), NE_ID);
    }

    @Test
    public void association() throws RepositoryException {
        final ChannelInfoData data = new ChannelInfoBuilder().setType("type").setCoreId("").setActivationRequired(false).build(CHANNEL_ID, 1, 1);
        when(infoRepository.query(CHANNEL_ID)).thenReturn(Optional.of(data));

        final Pair<Optional<ChannelInfoData>,NeDiscoveredEvent> pair =
            new AssociateWithChannel(repository).call(event);

        assertThat(pair, not(is(nullValue())));
        assertThat(pair.getLeft(), is(present()));
        assertThat(pair.getLeft().get(), is(data));
        assertThat(pair.getRight(), is(event));
    }

    @Test
    public void association_channelNotFound_absent() throws RepositoryException {
        when(infoRepository.query(CHANNEL_ID)).thenReturn(Optional.empty());

        final Pair<Optional<ChannelInfoData>,NeDiscoveredEvent> pair =
            new AssociateWithChannel(repository).call(event);

        assertThat(pair, not(is(nullValue())));
        assertThat(pair.getLeft(), is(absent()));
    }

    @Test
    public void association_repoError_absent() throws RepositoryException {
        when(infoRepository.query(CHANNEL_ID)).thenThrow(new RepositoryException());

        final Pair<Optional<ChannelInfoData>,NeDiscoveredEvent> pair =
            new AssociateWithChannel(repository).call(event);

        assertThat(pair, not(is(nullValue())));
        assertThat(pair.getLeft(), is(absent()));
    }

}
