package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class PhysicalMediatorActivationFailureEventHandlerTest extends MediatorFinalStatusEventHandlerTestBase {

    private static final String ERROR = "error";

    private PhysicalMediatorActivationFailureEventHandler<CallContext> handler;
    private CallContext context;
    private MediatorEntityRepository entityRepository;
    private MediatorInstanceEntityRepository physicalRepository;
    private MediatorPhysicalConnectionRepository connectionStateRepository;
    private MediatorNotifications notifications;
    private MediatorInteractionManager activationManager;
    private MessageSource<MediatorEvent> mediatorEvents;

    @SuppressWarnings("unchecked")
    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        context = mock(CallContext.class);
        entityRepository = mock(MediatorEntityRepository.class);
        physicalRepository = mock(MediatorInstanceEntityRepository.class);
        connectionStateRepository = mock(MediatorPhysicalConnectionRepository.class);
        notifications = mock(MediatorNotifications.class);
        activationManager = mock(MediatorInteractionManager.class);
        mediatorEvents = mock(MessageSource.class);

        when(physicalRepository.getMediatorPhysicalConnectionRepository()).thenReturn(connectionStateRepository);
        when(connectionStateRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler = new PhysicalMediatorActivationFailureEventHandler<>(context,
                new MediatorManagers(entityRepository, physicalRepository, notifications, activationManager, mediatorEvents),
                new ChannelManagers(channelRepository, channelPhysicalConnectionRepository, channelNotifications, channelActivationManager, channelEvents)
            );
    }

    @Test
    public void event_onActiveMediator() throws RepositoryException {
        verifyTransitionToFailedFrom(ActualActivationState.ACTIVE);
    }

    @Test
    public void event_onInactiveMediator() throws RepositoryException {
        verifyNoTransitionToFailedFrom(ActualActivationState.INACTIVE);
    }

    @Test
    public void event_onFailedMediator() throws RepositoryException {
        verifyTransitionToFailedFrom(ActualActivationState.FAILED);
    }

    @Test
    public void event_mediatorNotFound() throws RepositoryException {
        when(connectionStateRepository.query(INSTANCE_ID)).thenReturn(Optional.empty());

        handler.call(new PhysicalMediatorActivationFailedEvent(INSTANCE_ID, MEDIATOR_ID, false, ERROR));

        verify(connectionStateRepository, never()).tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class));
        verifyZeroInteractions(channelEvents);
    }

    private void verifyTransitionToFailedFrom(ActualActivationState initialState) throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(initialState)
            .setAdditionalInfo("")
            .build(INSTANCE_ID, MEDIATOR_ID, VERSION);
        when(connectionStateRepository.query(INSTANCE_ID)).thenReturn(Optional.of(state));

        handler.call(new PhysicalMediatorActivationFailedEvent(INSTANCE_ID, MEDIATOR_ID, false, ERROR));

        final ArgumentCaptor<MediatorPhysicalConnectionMutationDescriptor> captor =
                ArgumentCaptor.forClass(MediatorPhysicalConnectionMutationDescriptor.class);
        verify(connectionStateRepository).tryUpdate(captor.capture());

        assertThat(captor.getValue().getResult().getId(), is(INSTANCE_ID));
        assertThat(captor.getValue().getResult().getActualActivationState(), is(ActualActivationState.FAILED));
        assertThat(captor.getValue().getAdditionalInfo().get(), is(ERROR));

        verify(channelEvents).push(new PhysicalChannelActivationFailedEvent(ACTIVE_CHANNEL_ID, CHANNEL_ID, false, Message.MEDIATOR_FAILED.toString()));
        verify(channelEvents, never()).push(new PhysicalChannelActivationFailedEvent(INACTIVE_CHANNEL_ID, CHANNEL_ID, false, Message.MEDIATOR_FAILED.toString()));
        verify(channelEvents, never()).push(new PhysicalChannelActivationFailedEvent(FOREIGN_CHANNEL_ID, CHANNEL_ID, false, Message.MEDIATOR_FAILED.toString()));

        verify(notifications).notifyChanges(new MediatorActivationFailedEvent(MEDIATOR_ID,
                new PhysicalMediatorActivationFailedEvent(INSTANCE_ID, MEDIATOR_ID, false, ERROR), ERROR));
    }

    private void verifyNoTransitionToFailedFrom(ActualActivationState initialState) throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(initialState)
            .setAdditionalInfo("")
            .build(INSTANCE_ID, MEDIATOR_ID, VERSION);
        when(connectionStateRepository.query(INSTANCE_ID)).thenReturn(Optional.of(state));

        handler.call(new PhysicalMediatorActivationFailedEvent(INSTANCE_ID, MEDIATOR_ID, false, ERROR));

        verify(connectionStateRepository, never()).tryUpdate(isA(MediatorPhysicalConnectionMutationDescriptor.class));

        verify(channelEvents, never()).push(new PhysicalChannelActivationFailedEvent(ACTIVE_CHANNEL_ID, CHANNEL_ID, false, Message.MEDIATOR_FAILED.toString()));
        verify(channelEvents, never()).push(new PhysicalChannelActivationFailedEvent(INACTIVE_CHANNEL_ID, CHANNEL_ID, false, Message.MEDIATOR_FAILED.toString()));
        verify(channelEvents, never()).push(new PhysicalChannelActivationFailedEvent(FOREIGN_CHANNEL_ID, CHANNEL_ID, false, Message.MEDIATOR_FAILED.toString()));

        verify(notifications, never()).notifyChanges(new MediatorActivationFailedEvent(MEDIATOR_ID,
                new PhysicalMediatorActivationFailedEvent(INSTANCE_ID, MEDIATOR_ID, false, ERROR), ERROR));
    }

}
