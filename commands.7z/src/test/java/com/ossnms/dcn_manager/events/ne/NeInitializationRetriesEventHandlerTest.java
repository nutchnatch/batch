package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.periodic.PeriodicInitializationVerificationEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.CollQueryAnswer;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.time.Instant;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.*;

public class NeInitializationRetriesEventHandlerTest {

    private NePhysicalConnectionRepository neInstanceRepository;
    private NetworkElementNotifications neNotifications;
    private NetworkElementInteractionManager activationManager;
    private ChannelPhysicalConnectionRepository channelInstanceConnections;
    private NeInitializationRetriesEventHandler<CallContext> handler;
    private SettingsRepository settingsRepository;

    @Before
    public void setUp() throws Exception {
        final CallContext ctx = mock(CallContext.class);

        neInstanceRepository = mock(NePhysicalConnectionRepository.class);
        neNotifications = mock(NetworkElementNotifications.class);
        activationManager = mock(NetworkElementInteractionManager.class);
        channelInstanceConnections = mock(ChannelPhysicalConnectionRepository.class);
        settingsRepository = mock(SettingsRepository.class);

        when(settingsRepository.getSettings()).thenReturn(
                GlobalSettings.build().setNeRetries(0).toGlobalSettings(1, 0)); // infinite retries

        handler = new NeInitializationRetriesEventHandler<>(
                ctx,
                new NetworkElementManagers(null, neInstanceRepository, activationManager, neNotifications, null),
                new ChannelManagers(null, channelInstanceConnections, null, null, null),
                settingsRepository
        );
    }

    @Test
    public void failedNe_inInitRecoverMode_schedulesReactivation() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setRetryCounter(0) // first try
                        .setInitStartTime(Optional.of(Instant.MIN)) // oh yeah, timeout has elapsed :)
                        .setActivationState(ActualActivationState.FAILED)
                        .setActivationMode(ActualActivationMode.INIT_RECOVER)
                        .build(1, 1, 1, 0)
        ));

        when(channelInstanceConnections.query(1)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                        .build(1, 2, 10, 0)
        ));

        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PeriodicInitializationVerificationEvent());

        verify(activationManager).scheduleActivation(new Activate(1, 1, 2, 1, false));

        final ArgumentCaptor<NePhysicalConnectionMutationDescriptor> mutationCaptor = ArgumentCaptor.forClass(NePhysicalConnectionMutationDescriptor.class);
        verify(neInstanceRepository).tryUpdate(mutationCaptor.capture());
        assertThat(mutationCaptor.getValue().getRetryCounter(), is(Optional.of(1))); // retries must be incremented
    }

    @Test
    public void failedNe_inInitRecoverMode_timeoutDidNotElapse_doesNotScheduleReactivation() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setRetryCounter(0) // first try
                        .setInitStartTime(Optional.of(Instant.MAX)) // there's no way this has elapsed.
                        .setActivationState(ActualActivationState.FAILED)
                        .setActivationMode(ActualActivationMode.INIT_RECOVER)
                        .build(1, 1, 1, 0)
        ));

        when(channelInstanceConnections.query(1)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                        .build(1, 2, 10, 0)
        ));

        handler.call(new PeriodicInitializationVerificationEvent());

        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
        verify(activationManager, never()).scheduleActivation(new Activate(1, 1, 2, 1, false));
    }

    @Test
    public void failedNe_inInitRecoverMode_retriesExceeded_doesNotScheduleReactivation() throws Exception {

        when(settingsRepository.getSettings()).thenReturn(
                GlobalSettings.build().setNeRetries(1).toGlobalSettings(1, 0)); // one retry maximum

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setRetryCounter(1) // already retried once
                        .setInitStartTime(Optional.of(Instant.MIN)) // oh yeah, timeout has elapsed :)
                        .setActivationState(ActualActivationState.FAILED)
                        .setActivationMode(ActualActivationMode.INIT_RECOVER)
                        .build(1, 1, 1, 0)
        ));

        when(channelInstanceConnections.query(1)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                        .build(1, 2, 10, 0)
        ));

        handler.call(new PeriodicInitializationVerificationEvent());

        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
        verify(activationManager, never()).scheduleActivation(new Activate(1, 1, 2, 1, false));
    }

    @Test
    public void failedNe_notInInitRecoverMode_doesNotScheduleReactivation() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.FAILED)
                        .setActivationMode(ActualActivationMode.STANDARD)
                        .build(1, 1, 1, 0)
        ));

        handler.call(new PeriodicInitializationVerificationEvent());

        verify(activationManager, never()).scheduleActivation(any(Activate.class));
        verify(activationManager, never()).scheduleSynchronization(any(NeSynchronizationEvent.class));
    }

    @Test
    public void notFailedNe_doesNotScheduleReactivation() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.INITIALIZED)
                        .build(1, 1, 1, 0)
        ));

        handler.call(new PeriodicInitializationVerificationEvent());

        verify(activationManager, never()).scheduleActivation(any(Activate.class));
        verify(activationManager, never()).scheduleSynchronization(any(NeSynchronizationEvent.class));
    }

    @Test
    public void failedNe_inInitRecoverMode_channelNotFound_doesNotScheduleReactivation() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setInitStartTime(Optional.of(Instant.MIN)) // oh yeah, timeout has elapsed :)
                        .setActivationState(ActualActivationState.FAILED)
                        .setActivationMode(ActualActivationMode.INIT_RECOVER)
                        .build(1, 1, 1, 0)
        ));

        when(channelInstanceConnections.query(1)).thenReturn(Optional.empty());

        handler.call(new PeriodicInitializationVerificationEvent());

        verify(activationManager, never()).scheduleActivation(any(Activate.class));
        verify(activationManager, never()).scheduleSynchronization(any(NeSynchronizationEvent.class));
    }

    @Test
    public void failedNe_inInitRecoverMode_channelNotActive_doesNotScheduleReactivation() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setInitStartTime(Optional.of(Instant.MIN)) // oh yeah, timeout has elapsed :)
                        .setActivationState(ActualActivationState.FAILED)
                        .setActivationMode(ActualActivationMode.INIT_RECOVER)
                        .build(1, 1, 1, 0)
        ));

        when(channelInstanceConnections.query(1)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.INACTIVE)
                        .build(1, 2, 10, 0)
        ));

        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PeriodicInitializationVerificationEvent());

        verify(activationManager, never()).scheduleActivation(any(Activate.class));
        verify(activationManager, never()).scheduleSynchronization(new NeSynchronizationEvent(1, 1, 1, 2, false));
    }

    @Test
    public void failedNe_inInitRecoverMode_channelRepoError_doesNotScheduleReactivation() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setInitStartTime(Optional.of(Instant.MIN)) // oh yeah, timeout has elapsed :)
                        .setActivationState(ActualActivationState.FAILED)
                        .setActivationMode(ActualActivationMode.INIT_RECOVER)
                        .build(1, 1, 1, 0)
        ));

        when(channelInstanceConnections.query(1)).thenThrow(new RepositoryException());

        handler.call(new PeriodicInitializationVerificationEvent());

        verify(activationManager, never()).scheduleActivation(any(Activate.class));
        verify(activationManager, never()).scheduleSynchronization(any(NeSynchronizationEvent.class));
    }

    @Test
    public void failedNe_inInitRecoverMode_neUpdateError_doesNotScheduleReactivation() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setInitStartTime(Optional.of(Instant.MIN)) // oh yeah, timeout has elapsed :)
                        .setActivationState(ActualActivationState.FAILED)
                        .setActivationMode(ActualActivationMode.INIT_RECOVER)
                        .build(1, 1, 1, 0)
        ));

        when(channelInstanceConnections.query(1)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                        .build(1, 2, 10, 0)
        ));

        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
                .thenThrow(new RepositoryException());

        handler.call(new PeriodicInitializationVerificationEvent());

        verify(activationManager, never()).scheduleActivation(any(Activate.class));
        verify(activationManager, never()).scheduleSynchronization(new NeSynchronizationEvent(1, 1, 1, 2, false));
    }

    @Test
    public void failedNe_inInitRecoverMode_neConcurrentUpdate_doesNotScheduleReactivation() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setInitStartTime(Optional.of(Instant.MIN)) // oh yeah, timeout has elapsed :)
                        .setActivationState(ActualActivationState.FAILED)
                        .setActivationMode(ActualActivationMode.INIT_RECOVER)
                        .build(1, 1, 1, 0)
        ));

        when(channelInstanceConnections.query(1)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                        .build(1, 2, 10, 0)
        ));

        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
                .thenReturn(Optional.empty());

        handler.call(new PeriodicInitializationVerificationEvent());

        verify(activationManager, never()).scheduleActivation(any(Activate.class));
        verify(activationManager, never()).scheduleSynchronization(new NeSynchronizationEvent(1, 1, 1, 2, false));
    }
}
