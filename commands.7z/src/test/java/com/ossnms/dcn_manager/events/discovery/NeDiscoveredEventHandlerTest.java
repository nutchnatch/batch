package com.ossnms.dcn_manager.events.discovery;

import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableBiMap.Builder;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.composables.configuration.AppProperties;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNeDataTransferPropertyNames;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeOperationRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.core.test.UnitOfWorkImplBaseStub;
import com.ossnms.dcn_manager.core.test.UowMutationAnswer;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.identification.ne.NeIdentification;
import com.ossnms.dcn_manager.identification.ne.globalneid.GlobalNeId;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class NeDiscoveredEventHandlerTest {

    private NeEntityRepository neRepository;
    private NetworkElementNotifications neNotifications;
    private NeGatewayRoutesRepository neRoutesRepository;
    private NeUserPreferencesRepository nePreferencesRepository;
    private NeOperationRepository neOperationRepository;

    private DomainRepository domainRepository;

    private NeDiscoveredEventHandler handler;
    private NePhysicalConnectionRepository neInstanceRepository;
    private NeIdentification neIdentification;
    private NetworkElementInteractionManager neActivations;

    private DomainNotifications domainNotifications;

    private ContainerNotifications containerNotifications;
    private ContainerRepository containerRepository;
    private SystemRepository systemRepository;

    private CallContext context;
    private SettingsRepository settingsRepository;
    private AppProperties appProperties;
    private ChannelEntityRepository channelRepository;
    private ChannelPhysicalConnectionRepository channelInstanceRepository;
    private LoggerManager<CallContext> loggerManager;
    private NeType neType;
    private MessageSource<NeEvent> neEvents;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws Exception {
        context = mock(CallContext.class);

        neRepository = mock(NeEntityRepository.class);
        neInstanceRepository = mock(NePhysicalConnectionRepository.class);
        neActivations = mock(NetworkElementInteractionManager.class);
        neNotifications = mock(NetworkElementNotifications.class);
        neIdentification = mock(NeIdentification.class);
        neRoutesRepository = mock(NeGatewayRoutesRepository.class);
        nePreferencesRepository = mock(NeUserPreferencesRepository.class);
        neOperationRepository = mock(NeOperationRepository.class);
        neEvents = mock(MessageSource.class);

        systemRepository = mock(SystemRepository.class);
        channelRepository = mock(ChannelEntityRepository.class);
        channelInstanceRepository = mock(ChannelPhysicalConnectionRepository.class);

        domainRepository = mock(DomainRepository.class);
        domainNotifications = mock(DomainNotifications.class);

        containerNotifications = mock(ContainerNotifications.class);
        containerRepository = mock(ContainerRepository.class);

        settingsRepository = mock(SettingsRepository.class);
        appProperties = mock(AppProperties.class);
        loggerManager = mock(LoggerManager.class);

        when(systemRepository.queryByName(anyString())).thenReturn(Optional.empty());
        when(neRepository.getNeGatewayRoutesRepository()).thenReturn(neRoutesRepository);
        when(neRepository.getNeUserPreferencesRepository()).thenReturn(nePreferencesRepository);
        when(neRepository.getNeOperationRepository()).thenReturn(neOperationRepository);
        when(neRepository.unitOfWork(any())).then(invocation -> new UnitOfWorkImplBaseStub<>(invocation.getArguments()[0]));
        when(containerRepository.queryAllByNE(anyInt())).thenReturn(Collections.emptyList());
        when(containerRepository.getRootContainer()).thenReturn(new ContainerInfo(1, 100, "root"));

        when(containerRepository.queryByName(anyString())).thenReturn(Optional.of(new ContainerInfo(1,1,"c")));
        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().toGlobalSettings(1,1));

        NetworkElementManagers neManagers = new NetworkElementManagers(neRepository, neInstanceRepository,
                neActivations, neNotifications, neEvents);
        DomainManagers domainManagers = new DomainManagers(domainRepository, domainNotifications);

        handler = new NeDiscoveredEventHandler<>(context, neManagers, neIdentification, domainManagers,
                containerRepository, systemRepository, containerNotifications, settingsRepository, appProperties, channelRepository,
                channelInstanceRepository, loggerManager);

        neType = MockFactory.mockNeType();
        when(neType.getProtocol()).thenReturn(GlobalNeId.SNMP.toString());
        
        when(neType.getIdentificationControlMap()).thenReturn(buildEmptyControlMap());
        when(neType.getAdditionalTypeInfoControlMap()).thenReturn(buildEmptyControlMap());

    }

    @Test
    public void testPropertyNamesToIgnoreOnDiscovery_onExistingNe_areNotUpdated() throws Exception {

        final ChannelInfoData channel = new ChannelInfoBuilder().setType("type").build(10, 0, 100);

        final NeUserPreferencesBuilder preferences =
                new NeUserPreferencesBuilder()
                        .setName("blah")
                        .setUserName(Optional.of("user"))
                        .setPassword(Optional.of("pwd"));
        preferences.getDataTransferSettingsAdapter()
                .setPassword(Optional.of("dts pwd"))
                .setUsername(Optional.of("dts uname"));
        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(5, 0),
                new NeOperationBuilder().build(5, 0),
                new NeInfoBuilder().setProxyType("type").build(5, 10, 0),
                new NeSynchronizationBuilder().build(5, 0),
                preferences.build(5, 0)
        );

        final NePhysicalConnectionData instance = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .build(5000, 5, 11, 0);

        final Map<String, String> newProperties = ImmutableMap.<String, String>builder()
                .put("Blah", "Bleeehh")
                .put("30A800AC-70A6-424D-B776-DB23E919C34D/USERCLASS_MAINTENANCEUSERNAME", "new user")
                .put("SNMP_USER_NAME", "other user")
                .put("BD4B7A2F-1406-4617-B163-39D1AF00EF03/Radius", "true")
                .build();

        when(neType.getPropertyNamesToIgnoreOnDiscoveryUpdates()).thenReturn(ImmutableList.of(
                "30A800AC-70A6-424D-B776-DB23E919C34D/USERCLASS_MAINTENANCEUSERNAME",
                "SNMP_USER_NAME",
                "BD4B7A2F-1406-4617-B163-39D1AF00EF03/Radius"
        ));

        when(neIdentification.tryIdentifyNe(any(NeCreateDescriptor.class))).thenReturn(Optional.of(entity));
        when(neRoutesRepository.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(false);
        when(nePreferencesRepository.tryUpdate(any(UowContext.class), any(NeUserPreferencesMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(neOperationRepository.tryUpdate(any(UowContext.class), any(NeOperationMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(neRepository.queryNe(5)).thenReturn(Optional.of(entity));
        when(domainRepository.queryAllForNE(5)).thenReturn(Collections.emptyList());
        when(neInstanceRepository.queryAll(5)).thenReturn(Collections.singleton(instance));
        when(domainRepository.queryTransitiveDomainsForNE(5)).thenReturn(Collections.emptyList());
        when(domainRepository.queryNaturalDomainsForNE(5)).thenReturn(Collections.emptyList());

        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(1, neType);
        createDescriptor.getPreferences().setName("some name");

        final NeDiscoveredEvent event = new NeDiscoveredEvent(createDescriptor, newProperties, Optional.of("netName"), 1);

        handler.handleEvent(ImmutablePair.of(Optional.of(channel), event));

        ArgumentCaptor<NeUserPreferencesMutationDescriptor> captor = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(nePreferencesRepository).tryUpdate(isA(UowContext.class), captor.capture());
        final NeUserPreferencesMutationDescriptor mutation = captor.getValue();
        verify(neNotifications).notifyChanges(mutation);
        assertThat(mutation.getProperties(), is(ImmutableMap.of("Blah", "Bleeehh")));
        verify(neActivations).onNePropertiesUpdated(isA(NeEntity.class), eq(instance), eq(mutation));
    }

    @Test
    public void testPropertyNamesToIgnoreOnDiscovery_onNewNe_areStored() throws Exception {

        final ChannelEntity channel = new ChannelEntity(
                new ChannelInfoBuilder().setType("type").build(10, 0, 100),
                new ChannelConnectionBuilder().build(10, 0),
                new ChannelUserPreferencesBuilder().setName("channel name").build(10, 0)
        );

        final Map<String, String> newProperties = ImmutableMap.<String, String>builder()
                .put("Blah", "Bleeehh")
                .put("30A800AC-70A6-424D-B776-DB23E919C34D/USERCLASS_MAINTENANCEUSERNAME", "new user")
                .put("SNMP_USER_NAME", "other user")
                .put("BD4B7A2F-1406-4617-B163-39D1AF00EF03/Radius", "true")
                .put(WellKnownNePropertyNames.USER_NAME, "new user")
                .put(WellKnownNePropertyNames.USER_PASSWORD, "new password")
                .build();

        when(neType.getPropertyNamesToIgnoreOnDiscoveryUpdates()).thenReturn(ImmutableList.of(
                "30A800AC-70A6-424D-B776-DB23E919C34D/USERCLASS_MAINTENANCEUSERNAME",
                "SNMP_USER_NAME",
                "BD4B7A2F-1406-4617-B163-39D1AF00EF03/Radius"
        ));

        when(neIdentification.tryIdentifyNe(any(NeCreateDescriptor.class))).thenReturn(Optional.empty());
        when(nePreferencesRepository.query(anyString())).thenReturn(Optional.empty());
        when(channelRepository.queryChannel(10)).thenReturn(Optional.of(channel));
        when(channelInstanceRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());
        when(neRepository.create(isA(NeCreateDescriptor.class))).then(invocation -> {
            final NeCreateDescriptor createDescriptor = (NeCreateDescriptor) invocation.getArguments()[0];
            return new NeEntity(
                    new NeConnectionData(5, 0, createDescriptor.getConnection()),
                    new NeOperationData(5, 0, createDescriptor.getOperation()),
                    new NeInfoData(5, 10, 0, createDescriptor.getInfo()),
                    new NeSynchronizationData(5, 0, createDescriptor.getSynchronization()),
                    new NeUserPreferencesData(5, 0, createDescriptor.getPreferences()));
        });
        when(domainRepository.queryAllForNE(5)).thenReturn(Collections.emptyList());
        when(domainRepository.queryTransitiveDomainsForNE(5)).thenReturn(Collections.emptyList());
        when(domainRepository.queryNaturalDomainsForNE(5)).thenReturn(Collections.emptyList());

        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(10, neType);
        createDescriptor.getPreferences().setName("some name");

        final NeDiscoveredEvent event = new NeDiscoveredEvent(createDescriptor, newProperties, Optional.of("netName"), 1);

        handler.handleEvent(ImmutablePair.of(Optional.of(channel), event));

        ArgumentCaptor<NeEntity> captor = ArgumentCaptor.forClass(NeEntity.class);
        verify(neNotifications).notifyCreate(captor.capture());
        final NeUserPreferencesData preferences = captor.getValue().getPreferences();
        assertThat(preferences.getAllOpaqueProperties(), is(ImmutableMap.of(
                "Blah", "Bleeehh",
                "30A800AC-70A6-424D-B776-DB23E919C34D/USERCLASS_MAINTENANCEUSERNAME", "new user",
                "SNMP_USER_NAME", "other user",
                "BD4B7A2F-1406-4617-B163-39D1AF00EF03/Radius", "true"
        )));
        assertThat(preferences.getUserName(), hasValue("new user"));
        assertThat(preferences.getPassword(), hasValue("new password"));
    }

    @Test
    public void testUserNameAndPassword_onExistingNe_areNotUpdated() throws Exception {

        final ChannelInfoData channel = new ChannelInfoBuilder().setType("type").build(10, 0, 100);

        final NeUserPreferencesBuilder preferences =
                new NeUserPreferencesBuilder()
                    .setName("blah")
                    .setUserName(Optional.of("user"))
                    .setPassword(Optional.of("pwd"));
        preferences.getDataTransferSettingsAdapter()
                .setPassword(Optional.of("dts pwd"))
                .setUsername(Optional.of("dts uname"));
        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(5, 0),
                new NeOperationBuilder().build(5, 0),
                new NeInfoBuilder().setProxyType("type").build(5, 10, 0),
                new NeSynchronizationBuilder().build(5, 0),
                preferences.build(5, 0)
        );

        final NePhysicalConnectionData instance = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .build(5000, 5, 11, 0);

        final Map<String, String> newProperties = ImmutableMap.<String, String>builder()
                .put("Blah", "Bleeehh")
                .put(WellKnownNePropertyNames.USES_GNE, "true")
                .put(WellKnownNePropertyNames.USER_NAME, "new user")
                .put(WellKnownNePropertyNames.USER_PASSWORD, "new password")
                .put(WellKnownNeDataTransferPropertyNames.USERNAME, "new dts user")
                .put(WellKnownNeDataTransferPropertyNames.PASSWORD, "new dts pwd")
                .build();

        when(neIdentification.tryIdentifyNe(any(NeCreateDescriptor.class))).thenReturn(Optional.of(entity));
        when(neRoutesRepository.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(false);
        when(nePreferencesRepository.tryUpdate(any(UowContext.class), any(NeUserPreferencesMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(neOperationRepository.tryUpdate(any(UowContext.class), any(NeOperationMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(neRepository.queryNe(5)).thenReturn(Optional.of(entity));
        when(domainRepository.queryAllForNE(5)).thenReturn(Collections.emptyList());
        when(neInstanceRepository.queryAll(5)).thenReturn(Collections.singleton(instance));
        when(domainRepository.queryTransitiveDomainsForNE(5)).thenReturn(Collections.emptyList());
        when(domainRepository.queryNaturalDomainsForNE(5)).thenReturn(Collections.emptyList());

        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(1, neType);
        createDescriptor.getPreferences().setName("some name");

        final NeDiscoveredEvent event = new NeDiscoveredEvent(createDescriptor, newProperties, Optional.of("netName"), 1);

        handler.handleEvent(ImmutablePair.of(Optional.of(channel), event));

        ArgumentCaptor<NeUserPreferencesMutationDescriptor> captor = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(nePreferencesRepository).tryUpdate(isA(UowContext.class), captor.capture());
        final NeUserPreferencesMutationDescriptor mutation = captor.getValue();
        verify(neNotifications).notifyChanges(mutation);
        assertThat(mutation.getUserName(), is(absent()));
        assertThat(mutation.getUsesGne(), is(absent()));
        assertThat(mutation.getPassword(), is(absent()));
        assertThat(mutation.getDataTransferSettingsAdapter().getUsername(), is(absent()));
        assertThat(mutation.getDataTransferSettingsAdapter().getPassword(), is(absent()));
        assertThat(mutation.getProperties(), is(ImmutableMap.of("Blah", "Bleeehh")));
        verify(neActivations).onNePropertiesUpdated(isA(NeEntity.class), eq(instance), eq(mutation));
    }

    @Test
    public void testAutomaticCopyOfNeName_withPropertyChanges() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(5, 0),
                new NeOperationBuilder().build(5, 0),
                new NeInfoBuilder().setProxyType("type").build(5, 10, 0),
                new NeSynchronizationBuilder().build(5, 0),
                new NeUserPreferencesBuilder().setName("blah").build(5, 0)
        );

        final NePhysicalConnectionData instance = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .build(5000, 5, 11, 0);

        final Map<String, String> newProperties = new HashMap<>(ImmutableMap.of("Blah", "Bleeehh"));

        when(neIdentification.tryIdentifyNe(any(NeCreateDescriptor.class))).thenReturn(Optional.of(entity));
        when(neRoutesRepository.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);
        when(nePreferencesRepository.tryUpdate(any(UowContext.class), any(NeUserPreferencesMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(neOperationRepository.tryUpdate(any(UowContext.class), any(NeOperationMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(neRepository.queryNe(5)).thenReturn(Optional.of(entity));
        when(domainRepository.queryAllForNE(5)).thenReturn(Collections.emptyList());
        when(neInstanceRepository.queryAll(5)).thenReturn(Collections.singleton(instance));
        when(domainRepository.queryTransitiveDomainsForNE(5)).thenReturn(Collections.emptyList());
        when(domainRepository.queryNaturalDomainsForNE(5)).thenReturn(Collections.emptyList());

        final ChannelInfoData channel = new ChannelInfoBuilder().setType("type").build(10, 0, 100);

        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(1, neType);
        createDescriptor.getPreferences().setName("some name");

        final NeDiscoveredEvent event = new NeDiscoveredEvent(createDescriptor, newProperties, Optional.of("netName"), 1);

        handler.handleEvent(ImmutablePair.of(Optional.of(channel), event));

        ArgumentCaptor<NeUserPreferencesMutationDescriptor> captor = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(nePreferencesRepository).tryUpdate(isA(UowContext.class), captor.capture());
        final NeUserPreferencesMutationDescriptor mutation = captor.getValue();
        verify(neNotifications).notifyChanges(mutation);
        assertThat(mutation.getName(), hasValue("netName"));
        assertThat(mutation.getProperties(), is(newProperties));
        verify(neActivations).onNePropertiesUpdated(isA(NeEntity.class), eq(instance), eq(mutation));
    }


    @Test
    public void testAutomaticCopyOfNeName_withPropertyChanges_autoCopyDisabled_doesNotUpdateName() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(5, 0),
                new NeOperationBuilder().build(5, 0),
                new NeInfoBuilder().setProxyType("type").build(5, 10, 0),
                new NeSynchronizationBuilder().build(5, 0),
                new NeUserPreferencesBuilder().setName("blah").build(5, 0)
        );

        final NePhysicalConnectionData instance = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .build(5000, 5, 11, 0);

        final Map<String, String> newProperties = new HashMap<>(ImmutableMap.of("Blah", "Bleeehh"));

        when(neIdentification.tryIdentifyNe(any(NeCreateDescriptor.class))).thenReturn(Optional.of(entity));
        when(neRoutesRepository.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(false);
        when(nePreferencesRepository.tryUpdate(any(UowContext.class), any(NeUserPreferencesMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(neOperationRepository.tryUpdate(any(UowContext.class), any(NeOperationMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(neRepository.queryNe(5)).thenReturn(Optional.of(entity));
        when(domainRepository.queryAllForNE(5)).thenReturn(Collections.emptyList());
        when(neInstanceRepository.queryAll(5)).thenReturn(Collections.singleton(instance));
        when(domainRepository.queryTransitiveDomainsForNE(5)).thenReturn(Collections.emptyList());
        when(domainRepository.queryNaturalDomainsForNE(5)).thenReturn(Collections.emptyList());

        final ChannelInfoData channel = new ChannelInfoBuilder().setType("type").build(10, 0, 100);

        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(1, neType);
        createDescriptor.getPreferences().setName("some name");

        final NeDiscoveredEvent event = new NeDiscoveredEvent(createDescriptor, newProperties, Optional.of("netName"), 1);

        handler.handleEvent(ImmutablePair.of(Optional.of(channel), event));

        ArgumentCaptor<NeUserPreferencesMutationDescriptor> captor = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(nePreferencesRepository).tryUpdate(isA(UowContext.class), captor.capture());
        final NeUserPreferencesMutationDescriptor mutation = captor.getValue();
        verify(neNotifications).notifyChanges(mutation);
        assertThat(mutation.getName(), is(absent()));
        assertThat(mutation.getProperties(), is(newProperties));
        verify(neActivations).onNePropertiesUpdated(isA(NeEntity.class), eq(instance), eq(mutation));
    }

    @Test
    public void testAutomaticCopyOfNeName_withPropertyChanges_noNameReported_doesNotChangeName() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(5, 0),
                new NeOperationBuilder().build(5, 0),
                new NeInfoBuilder().setProxyType("type").build(5, 10, 0),
                new NeSynchronizationBuilder().build(5, 0),
                new NeUserPreferencesBuilder().setName("blah").build(5, 0)
        );

        final NePhysicalConnectionData instance = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .build(5000, 5, 11, 0);

        final Map<String, String> newProperties = new HashMap<>(ImmutableMap.of("Blah", "Bleeehh"));

        when(neIdentification.tryIdentifyNe(any(NeCreateDescriptor.class))).thenReturn(Optional.of(entity));
        when(neRoutesRepository.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);
        when(nePreferencesRepository.tryUpdate(any(UowContext.class), any(NeUserPreferencesMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(neOperationRepository.tryUpdate(any(UowContext.class), any(NeOperationMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(neRepository.queryNe(5)).thenReturn(Optional.of(entity));
        when(domainRepository.queryAllForNE(5)).thenReturn(Collections.emptyList());
        when(neInstanceRepository.queryAll(5)).thenReturn(Collections.singleton(instance));
        when(domainRepository.queryTransitiveDomainsForNE(5)).thenReturn(Collections.emptyList());
        when(domainRepository.queryNaturalDomainsForNE(5)).thenReturn(Collections.emptyList());

        final ChannelInfoData channel = new ChannelInfoBuilder().setType("type").build(10, 0, 100);

        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(1, neType);

        final NeDiscoveredEvent event = new NeDiscoveredEvent(createDescriptor, newProperties, Optional.empty(), 1);

        handler.handleEvent(ImmutablePair.of(Optional.of(channel), event));

        ArgumentCaptor<NeUserPreferencesMutationDescriptor> captor = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(nePreferencesRepository).tryUpdate(isA(UowContext.class), captor.capture());
        final NeUserPreferencesMutationDescriptor mutation = captor.getValue();
        verify(neNotifications).notifyChanges(mutation);
        assertThat(mutation.getName(), is(absent()));
        assertThat(mutation.getProperties(), is(newProperties));
        verify(neActivations).onNePropertiesUpdated(isA(NeEntity.class), eq(instance), eq(mutation));
    }

    @Test
    public void testAutomaticCopyOfNeName_withoutPropertyChanges() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(5, 0),
                new NeOperationBuilder().build(5, 0),
                new NeInfoBuilder().setProxyType("type").build(5, 10, 0),
                new NeSynchronizationBuilder().build(5, 0),
                new NeUserPreferencesBuilder().setName("blah").build(5, 0)
        );

        final NePhysicalConnectionData instance = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .build(5000, 5, 11, 0);

        when(neIdentification.tryIdentifyNe(any(NeCreateDescriptor.class))).thenReturn(Optional.of(entity));
        when(neRoutesRepository.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);
        when(nePreferencesRepository.tryUpdate(any(NeUserPreferencesMutationDescriptor.class))).then(new MutationAnswer<>());
        when(neRepository.queryNe(5)).thenReturn(Optional.of(entity));
        when(domainRepository.queryAllForNE(5)).thenReturn(Collections.emptyList());
        when(neInstanceRepository.queryAll(5)).thenReturn(Collections.singleton(instance));

        final ChannelInfoData channel = new ChannelInfoBuilder().setType("type").build(10, 0, 100);

        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(1, neType);
        createDescriptor.getPreferences().setName("some name");

        final NeDiscoveredEvent event = new NeDiscoveredEvent(createDescriptor, Collections.emptyMap(), Optional.of("netName"), 1);

        handler.handleEvent(ImmutablePair.of(Optional.of(channel), event));

        ArgumentCaptor<NeUserPreferencesMutationDescriptor> captor = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(nePreferencesRepository).tryUpdate(captor.capture());
        final NeUserPreferencesMutationDescriptor mutation = captor.getValue();
        verify(neNotifications).notifyChanges(mutation);
        assertThat(mutation.getName(), hasValue("netName"));
        verify(neActivations).onNePropertiesUpdated(isA(NeEntity.class), eq(instance), eq(mutation));
    }

    @Test
    public void testAutomaticCopyOfNeName_withoutPropertyChanges_noNameReceived_doesNothing() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(5, 0),
                new NeOperationBuilder().build(5, 0),
                new NeInfoBuilder().setProxyType("type").build(5, 10, 0),
                new NeSynchronizationBuilder().build(5, 0),
                new NeUserPreferencesBuilder().setName("blah").build(5, 0)
        );

        when(neIdentification.tryIdentifyNe(any(NeCreateDescriptor.class))).thenReturn(Optional.of(entity));
        when(neRoutesRepository.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);
        when(nePreferencesRepository.tryUpdate(any(NeUserPreferencesMutationDescriptor.class))).then(new MutationAnswer<>());
        when(neRepository.queryNe(5)).thenReturn(Optional.of(entity));
        when(domainRepository.queryAllForNE(5)).thenReturn(Collections.emptyList());

        final ChannelInfoData channel = new ChannelInfoBuilder().setType("type").build(10, 0, 100);

        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(1, neType);
        final NeDiscoveredEvent event = new NeDiscoveredEvent(createDescriptor, Collections.emptyMap(), Optional.empty(), 1);

        handler.handleEvent(ImmutablePair.of(Optional.of(channel), event));

        verify(nePreferencesRepository, never()).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));
        verify(neNotifications, never()).notifyChanges(isA(NeUserPreferencesMutationDescriptor.class));
    }

    @Test
    public void testAutomaticCopyOfNeName_withoutPropertyChanges_repoError_doesNothing() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(5, 0),
                new NeOperationBuilder().build(5, 0),
                new NeInfoBuilder().setProxyType("type").build(5, 10, 0),
                new NeSynchronizationBuilder().build(5, 0),
                new NeUserPreferencesBuilder().setName("blah").build(5, 0)
        );

        when(neIdentification.tryIdentifyNe(any(NeCreateDescriptor.class))).thenReturn(Optional.of(entity));
        when(neRoutesRepository.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);
        when(nePreferencesRepository.tryUpdate(any(NeUserPreferencesMutationDescriptor.class))).thenThrow(new RepositoryException());
        when(neRepository.queryNe(5)).thenReturn(Optional.of(entity));
        when(domainRepository.queryAllForNE(5)).thenReturn(Collections.emptyList());

        final ChannelInfoData channel = new ChannelInfoBuilder().setType("type").build(10, 0, 100);

        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(1, neType);
        final NeDiscoveredEvent event = new NeDiscoveredEvent(createDescriptor, Collections.emptyMap(), Optional.of("netName"), 1);

        handler.handleEvent(ImmutablePair.of(Optional.of(channel), event));

        verify(nePreferencesRepository).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));
        verify(neNotifications, never()).notifyChanges(isA(NeUserPreferencesMutationDescriptor.class));
    }

    @Test
    public void testAutomaticCopyOfNeName_withoutPropertyChanges_updateFailed_doesNothing() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(5, 0),
                new NeOperationBuilder().build(5, 0),
                new NeInfoBuilder().setProxyType("type").build(5, 10, 0),
                new NeSynchronizationBuilder().build(5, 0),
                new NeUserPreferencesBuilder().setName("blah").build(5, 0)
        );

        when(neIdentification.tryIdentifyNe(any(NeCreateDescriptor.class))).thenReturn(Optional.of(entity));
        when(neRoutesRepository.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);
        when(nePreferencesRepository.tryUpdate(any(NeUserPreferencesMutationDescriptor.class))).thenReturn(Optional.empty());
        when(neRepository.queryNe(5)).thenReturn(Optional.of(entity));
        when(domainRepository.queryAllForNE(5)).thenReturn(Collections.emptyList());

        final ChannelInfoData channel = new ChannelInfoBuilder().setType("type").build(10, 0, 100);

        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(1, neType);
        final NeDiscoveredEvent event = new NeDiscoveredEvent(createDescriptor, Collections.emptyMap(), Optional.of("netName"), 1);

        handler.handleEvent(ImmutablePair.of(Optional.of(channel), event));

        verify(nePreferencesRepository).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));
        verify(neNotifications, never()).notifyChanges(isA(NeUserPreferencesMutationDescriptor.class));
    }
    
    private BiMap<String, String> buildEmptyControlMap() {
        final Builder<String,String> builder = ImmutableBiMap.builder();
        return builder.build();
    }

}