package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.commands.ne.NeTestBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NeInfoDataChangedEvent;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class UpdateNeInfoDataEventHandlerTest extends NeTestBase{
    private static final int ID = 1;
    private static final int VERSION = 1;
    private static final String ICON_ID = "Icon1";
    private UpdateNeInfoDataEventHandler<CallContext> handler;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();
        handler = new UpdateNeInfoDataEventHandler<>(context, neRepo, notif);
    }

    @Test
    public void updateIconId() throws RepositoryException {
        when(infoRepo.query(ID)).thenReturn(Optional.of(new NeInfoData.NeInfoBuilder().setProxyType("other").setIconId(Optional.of(ICON_ID)).build(ID, 1, VERSION)));
        when(infoRepo.tryUpdate(any(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());
        handler.call(new NeInfoDataChangedEvent(ID, ICON_ID));
        final ArgumentCaptor<NeInfoMutationDescriptor> mutationCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);
        verify(infoRepo).tryUpdate(mutationCaptor.capture());
        verify(notif).notifyChanges(isA(NeInfoMutationDescriptor.class));

        assertThat(mutationCaptor.getValue().getIconId().get(), is(ICON_ID));
    }

    @Test
    public void updateIconIdIgonrNotUpdatedData() throws RepositoryException {

        when(infoRepo.query(ID)).thenReturn(Optional.of(new NeInfoData.NeInfoBuilder().setProxyType("other").build(ID, 1, VERSION)));
        when(infoRepo.tryUpdate(any(NeInfoMutationDescriptor.class))).thenReturn(Optional.<NeInfoData>empty());

        handler.call(new NeInfoDataChangedEvent(ID, ICON_ID));

        verifyZeroInteractions(notif);
    }
}
