package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.outbound.NeInformationRetrieval;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NeConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializingEvent;
import com.ossnms.dcn_manager.core.events.ne.NeConnectionDescriptionChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeConnectedEvent;
import com.ossnms.dcn_manager.core.outbound.Alarms;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class NeAllConnectionEventHandlersTest {

    private static final int MEDIATOR_ID = 3;
    private static final int CHANNEL_ID = 2;
    private static final int NE_ID = 1;
    private static final int NE_INSTANCE_ID = 1000;

    private ChannelEntityRepository channelRepository;
    private ChannelInfoRepository channelInfoRepository;
    private NeEntityRepository neRepository;
    private NeInfoRepository neInfoRepository;
    private NeGatewayRoutesRepository routesRepo;
    private NeUserPreferencesRepository neUserPreferencesRepo;
    private NeConnectionBehavior behavior;
    private Alarms alarms;
    private NeInformationRetrieval neInformationRetrieval;
    private NetworkElementNotifications notifications;

    private NeEntity entity;

    @Before
    public void setUp() throws DcnManagerException {
        channelRepository = mock(ChannelEntityRepository.class);
        channelInfoRepository = mock(ChannelInfoRepository.class);
        neRepository = mock(NeEntityRepository.class);
        neInfoRepository = mock(NeInfoRepository.class);
        behavior = mock(NeConnectionBehavior.class);
        alarms = mock(Alarms.class);
        neInformationRetrieval = mock(NeInformationRetrieval.class);
        notifications = mock(NetworkElementNotifications.class);
        routesRepo = mock(NeGatewayRoutesRepository.class);
        neUserPreferencesRepo = mock(NeUserPreferencesRepository.class);

        final NeType type = MockFactory.mockNeType();
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(CHANNEL_ID, type);
        createDescriptor.getConnection().setActivationState(ActualActivationState.CONNECTED);
        createDescriptor.getPreferences().setName("type_name_99");
        createDescriptor.getPreferences().setUsesGne(true);
        entity = NeEntity.build(NE_ID, 0, createDescriptor);

        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);

        when(neInformationRetrieval.updateNeDataFromMediator(anyInt())).thenReturn(entity);
        when(neRepository.getNeGatewayRoutesRepository()).thenReturn(routesRepo);
        when(neRepository.getNeInfoRepository()).thenReturn(neInfoRepository);
        when(neRepository.getNeUserPreferencesRepository()).thenReturn(neUserPreferencesRepo);
        when(routesRepo.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(neUserPreferencesRepo.query(NE_ID)).thenReturn(Optional.of(entity.getPreferences()));
    }

    @Test
    public void activationFailed() {
        final NeActivationFailedEvent event = new NeActivationFailedEvent(NE_ID, "descr");

        new NeActivationFailedEventHandler<>(null, neRepository, null, alarms)
                .triggerMutation(behavior, event);

        verify(behavior).setFailed(event.getDetailedDescription(), alarms);
    }

    @Test
    public void connectedEvent() throws Exception {
        final NeConnectedEvent event = new NeConnectedEvent(NE_ID, new PhysicalNeConnectedEvent(NE_INSTANCE_ID, NE_ID, true));

        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(channelInfoRepository.query(CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType("type").build(CHANNEL_ID, 0, MEDIATOR_ID)));

        new NeConnectedEventHandler<>(null, neRepository, channelRepository, notifications, neInformationRetrieval, alarms)
                .triggerMutation(behavior, event);

        verify(neInformationRetrieval, never()).updateNeDataFromMediator(NE_INSTANCE_ID);
        verify(behavior).setConnected(alarms, CHANNEL_ID, MEDIATOR_ID);
        verify(notifications).notifyChanges(isA(NeConnectionDescriptionChangedEvent.class));
    }

    @Test
    public void connectedEvent_neNotFound_doesNothing() throws Exception {
        final NeConnectedEvent event = new NeConnectedEvent(NE_ID, new PhysicalNeConnectedEvent(NE_INSTANCE_ID, NE_ID, true));

        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.empty());

        new NeConnectedEventHandler<>(null, neRepository, channelRepository, notifications, neInformationRetrieval, alarms)
                .triggerMutation(behavior, event);

        verify(neInformationRetrieval, never()).updateNeDataFromMediator(NE_INSTANCE_ID);
        verify(notifications).notifyChanges(isA(NeConnectionDescriptionChangedEvent.class));
        verifyZeroInteractions(behavior);
    }

    @Test
    public void connectedEvent_channelNotFound_doesNothing() throws Exception {
        final NeConnectedEvent event = new NeConnectedEvent(NE_ID, new PhysicalNeConnectedEvent(NE_INSTANCE_ID, NE_ID, true));

        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(channelInfoRepository.query(CHANNEL_ID)).thenReturn(Optional.empty());

        new NeConnectedEventHandler<>(null, neRepository, channelRepository, notifications, neInformationRetrieval, alarms)
                .triggerMutation(behavior, event);

        verify(neInformationRetrieval, never()).updateNeDataFromMediator(NE_INSTANCE_ID);
        verify(notifications).notifyChanges(isA(NeConnectionDescriptionChangedEvent.class));
        verifyZeroInteractions(behavior);
    }

    @Test
    public void connectedEvent_neInfoRepoError_doesNothing() throws Exception {
        final NeConnectedEvent event = new NeConnectedEvent(NE_ID, new PhysicalNeConnectedEvent(NE_INSTANCE_ID, NE_ID, true));

        when(neInfoRepository.query(NE_ID)).thenThrow(new RepositoryException());

        new NeConnectedEventHandler<>(null, neRepository, channelRepository, notifications, neInformationRetrieval, alarms)
                .triggerMutation(behavior, event);

        verify(neInformationRetrieval, never()).updateNeDataFromMediator(NE_INSTANCE_ID);
        verify(notifications).notifyChanges(isA(NeConnectionDescriptionChangedEvent.class));
        verifyZeroInteractions(behavior);
    }

    @Test
    public void connectedEvent_channelInfoRepoError_doesNothing() throws Exception {
        final NeConnectedEvent event = new NeConnectedEvent(NE_ID, new PhysicalNeConnectedEvent(NE_INSTANCE_ID, NE_ID, true));

        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(channelInfoRepository.query(CHANNEL_ID)).thenThrow(new RepositoryException());

        new NeConnectedEventHandler<>(null, neRepository, channelRepository, notifications, neInformationRetrieval, alarms)
                .triggerMutation(behavior, event);

        verify(neInformationRetrieval, never()).updateNeDataFromMediator(NE_INSTANCE_ID);
        verify(notifications).notifyChanges(isA(NeConnectionDescriptionChangedEvent.class));
        verifyZeroInteractions(behavior);
    }

    @Test
    public void connectingEvent() {
        final NeConnectingEvent event = new NeConnectingEvent(NE_ID);

        new NeConnectingEventHandler<>(null, neRepository, null)
                .triggerMutation(behavior, event);

        verify(behavior).setConnecting();
    }

    @Test
    public void disconnectedEvent() {
        final NeDisconnectedEvent event = new NeDisconnectedEvent(NE_ID);

        new NeDisconnectedEventHandler<>(null, neRepository, null, alarms)
                .triggerMutation(behavior, event);

        verify(behavior).setDisconnected(alarms);
    }

    @Test
    public void disconnectingEvent() {
        final NeDisconnectingEvent event = new NeDisconnectingEvent(NE_ID);

        new NeDisconnectingEventHandler<>(null, neRepository, null)
                .triggerMutation(behavior, event);

        verify(behavior).setDisconnecting();
    }

    @Test
    public void initializingEvent() {
        final NeInitializingEvent event = new NeInitializingEvent(NE_ID);

        new NeInitializingEventHandler<>(null, neRepository, null)
                .triggerMutation(behavior, event);

        verify(behavior).setInitializing();
    }

}
