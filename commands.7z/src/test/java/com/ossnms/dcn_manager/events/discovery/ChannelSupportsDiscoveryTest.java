package com.ossnms.dcn_manager.events.discovery;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import com.ossnms.dcn_manager.core.test.MockFactory;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ChannelSupportsDiscoveryTest {

    private Types<ChannelType> types;
    private StaticConfiguration config;
    private ChannelType type;

    private NeDiscoveredEvent discovered;

    private final ChannelInfoData info = new ChannelInfoBuilder().setType("channel_type").setCoreId("").setActivationRequired(false).build(1, 1, 1);

    @Before
    public void setUp() {
        config = mock(StaticConfiguration.class);
        types = mock(Types.class);
        type = MockFactory.mockEmType();

        final NeType neType = MockFactory.mockNeType();
        discovered = new NeDiscoveredEvent(new NeCreateDescriptor(2, neType), ImmutableMap.of(), Optional.of("name"), 1);

        when(config.getChannelTypes()).thenReturn(types);
        when(types.get("channel_type")).thenReturn(type);
    }

    @Test
    public void discoverySupported() {
        when(type.supportsDiscovery()).thenReturn(true);

        final Boolean result = new ChannelSupportsDiscovery(config).call(Pair.of(Optional.of(info), discovered));
        assertThat(result, is(true));
    }

    @Test
    public void discoveryNotSupported() {
        when(type.supportsDiscovery()).thenReturn(false);

        final Boolean result = new ChannelSupportsDiscovery(config).call(Pair.of(Optional.of(info), discovered));
        assertThat(result, is(false));
    }

}
