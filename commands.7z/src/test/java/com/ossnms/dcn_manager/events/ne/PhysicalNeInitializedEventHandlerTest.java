package com.ossnms.dcn_manager.events.ne;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.metrics.NeInitializationMetrics;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.*;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeSynchronizationRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.*;

public class PhysicalNeInitializedEventHandlerTest {

    private static final int NE_ID = 1;
    private static final int CHANNEL_ID = 2;
    private static final int ACTIVE_NE_INSTANCE_ID = 10;
    private static final int ACTIVE_CHANNEL_INSTANCE_ID = 20;
    private static final int STANDBY_NE_INSTANCE_ID = 30;
    private static final int STANDBY_CHANNEL_INSTANCE_ID = 40;
    private static final int STANDBY_MEDIATOR_ID = 50;

    private NetworkElementInteractionManager activationManager;
    private NePhysicalConnectionRepository neInstanceRepository;
    private NetworkElementNotifications notifications;
    private ChannelPhysicalConnectionRepository channelInstanceRepository;
    private NeSynchronizationRepository neSynchronizationRepository;
    private NeEntityRepository.NeUserPreferencesRepository nePreferencesRepository;

    private PhysicalNeInitializedEventHandler<CallContext> handler;
    private NetworkElementManagers neManagers;
    private NeInitializationMetrics metrics;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws DcnManagerException {
        final NeEntityRepository neRepository = mock(NeEntityRepository.class);
        final MessageSource<NeEvent> neEvents = mock(MessageSource.class);
        final CallContext context = mock(CallContext.class);

        notifications = mock(NetworkElementNotifications.class);
        activationManager = mock(NetworkElementInteractionManager.class);
        neInstanceRepository = mock(NePhysicalConnectionRepository.class);
        neSynchronizationRepository = mock(NeSynchronizationRepository.class);
        channelInstanceRepository = mock(ChannelPhysicalConnectionRepository.class);
        nePreferencesRepository = mock(NeEntityRepository.NeUserPreferencesRepository.class);
        metrics = mock(NeInitializationMetrics.class);

        when(neRepository.getNeSynchronizationRepository()).thenReturn(neSynchronizationRepository);
        when(neRepository.getNeUserPreferencesRepository()).thenReturn(nePreferencesRepository);

        when(nePreferencesRepository.query(anyInt())).thenReturn(Optional.empty());

        neManagers = new NetworkElementManagers(neRepository, neInstanceRepository, activationManager, notifications, neEvents);

        handler = new PhysicalNeInitializedEventHandler<>(context, neManagers, channelInstanceRepository, metrics);
    }

    @Test
    public void originalEventWithoutCounters_doesNotProduceDifferences() throws Exception {

        final PhysicalNeInitializedEvent physicalEvent =
                new PhysicalNeInitializedEvent(ACTIVE_NE_INSTANCE_ID, NE_ID, true);

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZING)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        final NeInitializedEvent forwardingEvent =
                handler.produceForwardingEvent(physicalEvent, activated);

        assertThat(forwardingEvent.getSynchronizationDataDifferences().isPresent(), is(false));
    }

    @Test
    public void originalEventWithCounters_differentValues_calculatesAndProducesDifferences() throws Exception {
        final NeSynchronizationData newValues =
            new NeSynchronizationBuilder()
                .setAll(Optional.of(1L))
                .setAlarms(Optional.of(2L))
                .setPacket(Optional.of(3L))
                .build(NE_ID, 0);

        final NeSynchronizationData currentValues =
                new NeSynchronizationBuilder()
                        .setAll(Optional.of(10L))
                        .setAlarms(Optional.of(20L))
                        .setPacket(Optional.of(30L))
                        .build(NE_ID, 0);

        final PhysicalNeInitializedEvent physicalEvent =
            new PhysicalNeInitializedEvent(ACTIVE_NE_INSTANCE_ID, NE_ID, true, newValues);

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZING)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(neSynchronizationRepository.query(NE_ID)).thenReturn(Optional.of(currentValues));
        when(neSynchronizationRepository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        final NeInitializedEvent forwardingEvent =
                handler.produceForwardingEvent(physicalEvent, activated);

        assertThat(forwardingEvent.getSynchronizationDataDifferences().isPresent(), is(true));
        assertThat(forwardingEvent.getSynchronizationDataDifferences().get(), is(newValues));
        verify(neSynchronizationRepository, never()).tryUpdate(new NeSynchronizationMutationDescriptor(currentValues)
                .setAll(1L).setAlarms(2L).setPacket(3L));

    }

    @Test
    public void originalEventWithCounters_zeroValues_alwaysProducesDifferences() throws Exception {
        final NeSynchronizationData newValues =
                new NeSynchronizationBuilder()
                        .setAll(Optional.of(0L))
                        .setAlarms(Optional.of(0L))
                        .setPacket(Optional.of(0L))
                        .build(NE_ID, 0);

        final NeSynchronizationData currentValues =
                new NeSynchronizationBuilder()
                        .setAll(Optional.of(0L))
                        .setAlarms(Optional.of(0L))
                        .setPacket(Optional.of(0L))
                        .build(NE_ID, 0);

        final PhysicalNeInitializedEvent physicalEvent =
                new PhysicalNeInitializedEvent(ACTIVE_NE_INSTANCE_ID, NE_ID, true, newValues);

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZING)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(neSynchronizationRepository.query(NE_ID)).thenReturn(Optional.of(currentValues));
        when(neSynchronizationRepository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());
        final NeInitializedEvent forwardingEvent =
                handler.produceForwardingEvent(physicalEvent, activated);

        assertThat(forwardingEvent.getSynchronizationDataDifferences().isPresent(), is(true));
        assertThat(forwardingEvent.getSynchronizationDataDifferences().get(), is(newValues));
        verify(neSynchronizationRepository, never()).tryUpdate(new NeSynchronizationMutationDescriptor(currentValues)
                .setAll(0L).setAlarms(0L).setPacket(0L));
    }

    @Test
    public void originalEventWithCounters_sameValues_calculatesAndProducesNoDifferences() throws Exception {
        final NeSynchronizationData newValues =
                new NeSynchronizationBuilder()
                        .setAll(Optional.of(1L))
                        .setAlarms(Optional.of(2L))
                        .setPacket(Optional.of(3L))
                        .build(NE_ID, 0);

        final NeSynchronizationData currentValues =
                new NeSynchronizationBuilder()
                        .setAll(Optional.of(1L))
                        .setAlarms(Optional.of(2L))
                        .setPacket(Optional.of(3L))
                        .build(NE_ID, 0);

        final NeSynchronizationData differences =
                new NeSynchronizationBuilder()
                        .build(NE_ID, 0);

        final PhysicalNeInitializedEvent physicalEvent =
                new PhysicalNeInitializedEvent(ACTIVE_NE_INSTANCE_ID, NE_ID, true, newValues);

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZING)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(neSynchronizationRepository.query(NE_ID)).thenReturn(Optional.of(currentValues));
        when(neSynchronizationRepository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        final NeInitializedEvent forwardingEvent =
                handler.produceForwardingEvent(physicalEvent, activated);

        assertThat(forwardingEvent.getSynchronizationDataDifferences().isPresent(), is(true));
        assertThat(forwardingEvent.getSynchronizationDataDifferences().get(), is(differences));
        verify(neSynchronizationRepository, never()).tryUpdate(new NeSynchronizationMutationDescriptor(currentValues)
                .setAll(1L).setAlarms(2L).setPacket(3L));

    }

    @Test
    public void originalEventWithCounters_repoError_doesNotProduceDifferences() throws Exception {
        final NeSynchronizationData newValues =
                new NeSynchronizationBuilder()
                        .setAll(Optional.of(1L))
                        .setAlarms(Optional.of(2L))
                        .setPacket(Optional.of(3L))
                        .build(NE_ID, 0);

        final PhysicalNeInitializedEvent physicalEvent =
                new PhysicalNeInitializedEvent(ACTIVE_NE_INSTANCE_ID, NE_ID, true, newValues);

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZING)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(neSynchronizationRepository.query(NE_ID)).thenThrow(new RepositoryException());

        final NeInitializedEvent forwardingEvent =
                handler.produceForwardingEvent(physicalEvent, activated);

        assertThat(forwardingEvent.getSynchronizationDataDifferences().isPresent(), is(false));
    }

    @Test
    public void originalEventWithCounters_noCountersFound_doesNotProduceDifferences() throws Exception {
        final NeSynchronizationData newValues =
                new NeSynchronizationBuilder()
                        .setAll(Optional.of(1L))
                        .setAlarms(Optional.of(2L))
                        .setPacket(Optional.of(3L))
                        .build(NE_ID, 0);

        final PhysicalNeInitializedEvent physicalEvent =
                new PhysicalNeInitializedEvent(ACTIVE_NE_INSTANCE_ID, NE_ID, true, newValues);

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZING)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(neSynchronizationRepository.query(NE_ID)).thenReturn(Optional.empty());

        final NeInitializedEvent forwardingEvent =
                handler.produceForwardingEvent(physicalEvent, activated);

        assertThat(forwardingEvent.getSynchronizationDataDifferences().isPresent(), is(false));
    }

    @Test
    public void activateOtherInstance() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        final NePhysicalConnectionData standingby = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActive(false)
                .build(STANDBY_NE_INSTANCE_ID, NE_ID, STANDBY_CHANNEL_INSTANCE_ID, 0);

        final ChannelPhysicalConnectionData standbyChannel = new ChannelPhysicalConnectionBuilder()
                .setActive(false)
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, CHANNEL_ID, 0);

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(ImmutableList.of(activated, standingby));
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(standbyChannel));
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(activationManager).scheduleActivation(new Activate(NE_ID, STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, STANDBY_NE_INSTANCE_ID, false));
        verify(neInstanceRepository).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void activateOtherInstance_allActive_resynchronizesActiveStandby() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        final NePhysicalConnectionData standingby = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(false)
                .build(STANDBY_NE_INSTANCE_ID, NE_ID, STANDBY_CHANNEL_INSTANCE_ID, 0);

        final ChannelPhysicalConnectionData standbyChannel = new ChannelPhysicalConnectionBuilder()
                .setActive(false)
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, CHANNEL_ID, 0);

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(ImmutableList.of(activated, standingby));
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(standbyChannel));
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, STANDBY_NE_INSTANCE_ID, false));
        verify(activationManager).scheduleSynchronization(new NeSynchronizationEvent(NE_ID, STANDBY_NE_INSTANCE_ID, STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, false));
        verify(neInstanceRepository).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void activateOtherInstance_alreadyStartingUp_doesNothing() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        final NePhysicalConnectionData standingby = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.CONNECTING)
                .setActive(false)
                .build(STANDBY_NE_INSTANCE_ID, NE_ID, STANDBY_CHANNEL_INSTANCE_ID, 0);

        final ChannelPhysicalConnectionData standbyChannel = new ChannelPhysicalConnectionBuilder()
                .setActive(false)
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, CHANNEL_ID, 0);

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(ImmutableList.of(activated, standingby));
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(standbyChannel));
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, STANDBY_NE_INSTANCE_ID, false));
        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void activateOtherInstance_inactiveChannel_doesNothing() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        final NePhysicalConnectionData standingby = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActive(false)
                .build(STANDBY_NE_INSTANCE_ID, NE_ID, STANDBY_CHANNEL_INSTANCE_ID, 0);

        final ChannelPhysicalConnectionData standbyChannel = new ChannelPhysicalConnectionBuilder()
                .setActive(false)
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.INACTIVE)
                .build(STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, CHANNEL_ID, 0);

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(ImmutableList.of(activated, standingby));
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(standbyChannel));

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, STANDBY_NE_INSTANCE_ID, false));
        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void activateOtherInstance_channelNotFound_doesNothing() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        final NePhysicalConnectionData standingby = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActive(false)
                .build(STANDBY_NE_INSTANCE_ID, NE_ID, STANDBY_CHANNEL_INSTANCE_ID, 0);

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(ImmutableList.of(activated, standingby));
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, STANDBY_NE_INSTANCE_ID, false));
        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void activateOtherInstance_instancesNotFound_doesNothing() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(ImmutableList.of());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, STANDBY_NE_INSTANCE_ID, false));
        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void activateOtherInstance_channelRepoError_doesNothing() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        final NePhysicalConnectionData standingby = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActive(false)
                .build(STANDBY_NE_INSTANCE_ID, NE_ID, STANDBY_CHANNEL_INSTANCE_ID, 0);

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(ImmutableList.of(activated, standingby));
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenThrow(new RepositoryException());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, STANDBY_NE_INSTANCE_ID, false));
        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void activateOtherInstance_instanceUpdateError_doesNothing() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        final NePhysicalConnectionData standingby = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActive(false)
                .build(STANDBY_NE_INSTANCE_ID, NE_ID, STANDBY_CHANNEL_INSTANCE_ID, 0);

        final ChannelPhysicalConnectionData standbyChannel = new ChannelPhysicalConnectionBuilder()
                .setActive(false)
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, CHANNEL_ID, 0);

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(ImmutableList.of(activated, standingby));
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(standbyChannel));
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).thenThrow(new RepositoryException());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, STANDBY_NE_INSTANCE_ID, false));
        verify(neInstanceRepository).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void activateOtherInstance_concurrentUpdateError_doesNothing() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        final NePhysicalConnectionData standingby = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActive(false)
                .build(STANDBY_NE_INSTANCE_ID, NE_ID, STANDBY_CHANNEL_INSTANCE_ID, 0);

        final ChannelPhysicalConnectionData standbyChannel = new ChannelPhysicalConnectionBuilder()
                .setActive(false)
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, CHANNEL_ID, 0);

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(ImmutableList.of(activated, standingby));
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(standbyChannel));
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).thenReturn(Optional.empty());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, STANDBY_CHANNEL_INSTANCE_ID, STANDBY_MEDIATOR_ID, STANDBY_NE_INSTANCE_ID, false));
        verify(neInstanceRepository).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void publishesMetrics_forStandaloneNe() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .setInitStartTime(Optional.of(Instant.now()))
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesData.NeUserPreferencesBuilder()
                        .setName("ne")
                        .setUsesGne(false)
                        .build(NE_ID, 1)
        ));

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.emptyList());
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(metrics).publish(isA(Duration.class));
    }

    @Test
    public void publishesMetrics_forRne() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .setInitStartTime(Optional.of(Instant.now()))
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesData.NeUserPreferencesBuilder()
                        .setName("ne")
                        .setUsesGne(true)
                        .build(NE_ID, 1)
        ));

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.emptyList());
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(metrics).publishRne(isA(Duration.class));
    }

    @Test
    public void publishesMetrics_errorOnQuery_skips() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .setInitStartTime(Optional.of(Instant.now()))
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(nePreferencesRepository.query(NE_ID)).thenThrow(new RepositoryException());

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.emptyList());
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(metrics, never()).publishRne(isA(Duration.class));
        verify(metrics, never()).publish(isA(Duration.class));
    }

    @Test
    public void publishesMetrics_noInitStartTimeRecorded_skips() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .setInitStartTime(Optional.empty())
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);


        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesData.NeUserPreferencesBuilder()
                        .setName("ne")
                        .setUsesGne(true)
                        .build(NE_ID, 1)
        ));

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.emptyList());
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(metrics, never()).publishRne(isA(Duration.class));
        verify(metrics, never()).publish(isA(Duration.class));
    }

    @Test
    public void publishesMetrics_noNePreferencesFound_skips() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .setInitStartTime(Optional.of(Instant.now()))
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.empty());

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.emptyList());
        when(channelInstanceRepository.query(STANDBY_CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        handler.onMutationApplied(activated, new NePhysicalConnectionBehavior(activated, notifications), neManagers);

        verify(metrics, never()).publishRne(isA(Duration.class));
        verify(metrics, never()).publish(isA(Duration.class));
    }
}
