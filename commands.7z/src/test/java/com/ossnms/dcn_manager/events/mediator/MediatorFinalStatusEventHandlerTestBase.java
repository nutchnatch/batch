package com.ossnms.dcn_manager.events.mediator;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.QChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.QChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.CollQueryAnswer;

class MediatorFinalStatusEventHandlerTestBase {

    protected static final int CHANNEL_ID = 8;
    protected static final int MEDIATOR_ID = 42;
    protected static final int INSTANCE_ID = 99;
    protected static final int VERSION = 1;
    protected static final int ACTIVE_CHANNEL_ID = 65;
    protected static final int INACTIVE_CHANNEL_ID = 98;
    protected static final int FOREIGN_CHANNEL_ID = 55;

    protected ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    protected ChannelEntityRepository.ChannelConnectionRepository channelConnectionRepository;
    protected ChannelEntityRepository.ChannelInfoRepository channelInfoRepository;
    protected ChannelEntityRepository channelRepository;
    protected ChannelNotifications channelNotifications;
    protected ChannelInteractionManager channelActivationManager;
    protected MessageSource<ChannelEvent> channelEvents;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {

        channelInfoRepository = mock(ChannelEntityRepository.ChannelInfoRepository.class);
        channelConnectionRepository = mock(ChannelEntityRepository.ChannelConnectionRepository.class);
        channelRepository = mock(ChannelEntityRepository.class);
        channelNotifications = mock(ChannelNotifications.class);
        channelActivationManager = mock(ChannelInteractionManager.class);
        channelEvents = mock(MessageSource.class);
        channelPhysicalConnectionRepository = mock(ChannelPhysicalConnectionRepository.class);

        when(channelRepository.getChannelConnectionRepository()).thenReturn(channelConnectionRepository);
        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);

        when(channelPhysicalConnectionRepository.query(any(QChannelPhysicalConnectionData.class))).then(new CollQueryAnswer<>(
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE).build(ACTIVE_CHANNEL_ID, INSTANCE_ID, CHANNEL_ID, VERSION),
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.INACTIVE).build(INACTIVE_CHANNEL_ID, INSTANCE_ID, CHANNEL_ID, VERSION),
                new ChannelPhysicalConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE).build(FOREIGN_CHANNEL_ID, INSTANCE_ID, CHANNEL_ID * 2, VERSION)
            ));

        when(channelConnectionRepository.query(any(QChannelConnectionData.class))).then(new CollQueryAnswer<>(
                new ChannelConnectionBuilder().setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE).build(CHANNEL_ID, VERSION)
            ));
        when(channelInfoRepository.queryChannelIdsUnderMediator(MEDIATOR_ID)).thenReturn(
                ImmutableList.of(CHANNEL_ID));
    }

}
