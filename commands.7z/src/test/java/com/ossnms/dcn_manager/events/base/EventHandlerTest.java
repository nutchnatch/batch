package com.ossnms.dcn_manager.events.base;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import org.junit.Before;
import org.junit.Test;

import javax.annotation.Nonnull;

import static org.mockito.Mockito.*;

public class EventHandlerTest {

    private CallContext context;

    @Before
    public void setUp() throws Exception {
        context = mock(CallContext.class);
    }

    @Test
    public void testFiniteRetriesOnError() throws Exception {

        final EventHandler<CallContext, String> handler =
            spy(new EventHandler<CallContext, String>(context) {
                @Override
                protected void handleEvent(@Nonnull String event) throws DcnManagerException {
                    throw new RuntimeException();
                }
            });

        handler.call("test");

        verify(handler, atLeast(5)).handleEvent("test");
    }

    @Test
    public void testNoRetriesOnSuccess() throws Exception {

        final EventHandler<CallContext, String> handler =
                spy(new EventHandler<CallContext, String>(context) {
                    @Override
                    protected void handleEvent(@Nonnull String event) throws DcnManagerException {

                    }
                });

        handler.call("test");

        verify(handler, times(1)).handleEvent("test"); // for legibility: we just want ONE call.
    }
}