package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.configuration.AppProperties;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.CommissioningMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.OperationalMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.types.WriteAccessMode;
import com.ossnms.dcn_manager.core.events.ne.NeOperationInfoChangedEvent;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeOperationRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class UpdateNeOperationInfoEventHandlerTest {

    private static final int NE_ID = 1;

    private NeEntityRepository neRepository;
    private NeOperationRepository operationRepo;
    private NeInfoRepository infoRepo;
    private NeUserPreferencesRepository preferencesRepo;
    private NetworkElementNotifications notifications;
    private AppProperties appProperties;
    private NeConnectionManager neConnectionManager;
    private NePhysicalConnectionRepository neInstanceRepository;

    @Before
    public void setUp() throws Exception {
        neRepository = mock(NeEntityRepository.class);
        operationRepo = mock(NeOperationRepository.class);
        infoRepo = mock(NeInfoRepository.class);
        preferencesRepo = mock(NeUserPreferencesRepository.class);
        notifications = mock(NetworkElementNotifications.class);
        appProperties = mock(AppProperties.class);
        neConnectionManager = mock(NeConnectionManager.class);
        neInstanceRepository = mock(NePhysicalConnectionRepository.class);

        when(neRepository.getNeOperationRepository()).thenReturn(operationRepo);
        when(neRepository.getNeInfoRepository()).thenReturn(infoRepo);
        when(neRepository.getNeUserPreferencesRepository()).thenReturn(preferencesRepo);
    }


    @Test
    public void testUpdateNeDataFromEvent_noNeOperation_ignores() throws Exception {

        when(operationRepo.query(NE_ID)).thenReturn(Optional.empty());

        new UpdateNeOperationInfoEventHandler<>(null, neRepository, notifications, appProperties, neConnectionManager, neInstanceRepository).call(buildEvent());

        verify(operationRepo, never()).tryUpdate(any(NeOperationMutationDescriptor.class));
        verifyZeroInteractions(notifications, preferencesRepo);
    }

    @Test
    public void testUpdateNeDataFromEvent() throws Exception {
        final NeOperationInfoChangedEvent event = buildEvent();

        final NeOperationData neOperation = new NeOperationBuilder().build(NE_ID, 1);

        when(operationRepo.query(NE_ID)).thenReturn(Optional.of(neOperation));

        // (just return something to indicate success)
        when(operationRepo.tryUpdate(any(NeOperationMutationDescriptor.class))).thenReturn(Optional.of(neOperation));

        new UpdateNeOperationInfoEventHandler<>(null, neRepository, notifications, appProperties, neConnectionManager, neInstanceRepository).call(event);

        final ArgumentCaptor<NeOperationMutationDescriptor> operationMutationCaptor = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);

        verify(infoRepo, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verify(operationRepo).tryUpdate(operationMutationCaptor.capture());
        verify(preferencesRepo, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));

        final NeOperationMutationDescriptor operationMutation = operationMutationCaptor.getValue();

        assertThat(operationMutation.getRealNeName().get(), is("ne_name"));
        assertThat(operationMutation.getNeighbourhoodId().get(), is("tid"));
        assertThat(operationMutation.isEventForwardingActive().get(), is(true));
        assertThat(operationMutation.getTpGroupMask().get(), is(1234L));
        assertThat(operationMutation.getTpGroupMode().get(), is(new TpGroupSettings(true, true, true, true)));
        assertThat(operationMutation.getFamily().get(), is("family"));
        assertThat(operationMutation.getMainRelease().get(), is("main"));
        assertThat(operationMutation.getMaintenanceRelease().get(), is("maintenance"));
        assertThat(operationMutation.getNeSubType().get(), is("subtype"));
        assertThat(operationMutation.getNeType().get(), is("type"));
        assertThat(operationMutation.getNeSpecificType().get(), is("specifictype"));
        assertThat(operationMutation.getOperationalMode().get(), is(OperationalMode.ENABLED));
        assertThat(operationMutation.getWriteAccess().get(), is(WriteAccessMode.NE_PROXY));
        assertThat(operationMutation.getCommissioning().get(), is(CommissioningMode.NOT_COMMISSIONED));
        assertThat(operationMutation.getGatewayMode().get(), is(GatewayMode.PRIMARY));

        operationMutation.apply();
        operationMutation.applied();

        verify(notifications, never()).notifyChanges(any(NeInfoMutationDescriptor.class));
        verify(notifications).notifyChanges(operationMutation);
        verify(notifications, never()).notifyChanges(any(NeUserPreferencesMutationDescriptor.class));
    }

    @Test
    public void testUpdateNeDataFromEvent_withNetworkNameCopy() throws Exception {
        final NeOperationInfoChangedEvent event = buildEvent();
        event.setRealNeName("network name");

        final NeOperationData neOperation = new NeOperationBuilder().build(NE_ID, 1);
        final NeUserPreferencesData nePreferences = new NeUserPreferencesBuilder().setName("blah").build(NE_ID, 0);
        NeEntity neEntity = new NeEntity(null, neOperation, null, null, nePreferences);
        NePhysicalConnectionData connectionData = new NePhysicalConnectionBuilder().build(NE_ID, NE_ID, 1, 1);
        

        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);

        when(operationRepo.query(NE_ID)).thenReturn(Optional.of(neOperation));
        when(preferencesRepo.query(NE_ID)).thenReturn(Optional.of(nePreferences));

        when(operationRepo.tryUpdate(any(NeOperationMutationDescriptor.class))).then(new MutationAnswer<>());
        when(preferencesRepo.tryUpdate(any(NeUserPreferencesMutationDescriptor.class))).then(new MutationAnswer<>());

        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(asList(connectionData));

        new UpdateNeOperationInfoEventHandler<>(null, neRepository, notifications, appProperties, neConnectionManager, neInstanceRepository).call(event);

        final ArgumentCaptor<NeOperationMutationDescriptor> operationMutationCaptor = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> preferencesMutationCaptor = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        verify(infoRepo, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verify(operationRepo).tryUpdate(operationMutationCaptor.capture());
        verify(preferencesRepo).tryUpdate(preferencesMutationCaptor.capture());

        final NeOperationMutationDescriptor operationMutation = operationMutationCaptor.getValue();
        final NeUserPreferencesMutationDescriptor preferencesMutation = preferencesMutationCaptor.getValue();

        assertThat(operationMutation.getRealNeName(), hasValue("network name"));
        assertThat(preferencesMutation.getName(), hasValue("network name"));

        verify(notifications, never()).notifyChanges(any(NeInfoMutationDescriptor.class));
        verify(notifications).notifyChanges(operationMutation);
        verify(notifications).notifyChanges(preferencesMutation);
    }

    @Test
    public void testUpdateNeDataFromEvent_withNetworkNameCopy_noNameReceived_doesNotCopy() throws Exception {
        final NeOperationInfoChangedEvent event = buildEvent();
        event.setRealNeName(null);

        final NeOperationData neOperation = new NeOperationBuilder().build(NE_ID, 1);

        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);

        when(operationRepo.query(NE_ID)).thenReturn(Optional.of(neOperation));

        when(operationRepo.tryUpdate(any(NeOperationMutationDescriptor.class))).then(new MutationAnswer<>());

        final NeUserPreferencesData nePreferences = new NeUserPreferencesBuilder().setName("blah").build(NE_ID, 0);
        when(preferencesRepo.query(NE_ID)).thenReturn(Optional.of(nePreferences));

        new UpdateNeOperationInfoEventHandler<>(null, neRepository, notifications, appProperties, neConnectionManager, neInstanceRepository).call(event);

        final ArgumentCaptor<NeOperationMutationDescriptor> operationMutationCaptor = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);

        verify(infoRepo, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verify(operationRepo).tryUpdate(operationMutationCaptor.capture());
        verify(preferencesRepo, never()).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));

        final NeOperationMutationDescriptor operationMutation = operationMutationCaptor.getValue();
        assertThat(operationMutation.getRealNeName(), is(absent()));

        verify(notifications, never()).notifyChanges(any(NeInfoMutationDescriptor.class));
        verify(notifications).notifyChanges(operationMutation);
        verify(notifications, never()).notifyChanges(any(NeUserPreferencesMutationDescriptor.class));
    }

    @Test(expected = UnknownNetworkElementIdException.class)
    public void testUpdateNeDataFromEvent_withNetworkNameCopy_preferencesNotFound_throwsException() throws Exception {
        final NeOperationInfoChangedEvent event = buildEvent();
        event.setRealNeName("network name");

        final NeOperationData neOperation = new NeOperationBuilder().build(NE_ID, 1);

        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);

        when(operationRepo.query(NE_ID)).thenReturn(Optional.of(neOperation));

        when(operationRepo.tryUpdate(any(NeOperationMutationDescriptor.class))).then(new MutationAnswer<>());

        when(preferencesRepo.query(NE_ID)).thenReturn(Optional.empty());

        new UpdateNeOperationInfoEventHandler<>(null, neRepository, notifications, appProperties, neConnectionManager, neInstanceRepository).handleEvent(event);

    }

    @Test(expected = DataUpdateException.class)
    public void testUpdateNeDataFromEvent_withNetworkNameCopy_preferencesRepoError_throwsException() throws Exception {
        final NeOperationInfoChangedEvent event = buildEvent();
        event.setRealNeName("network name");

        final NeOperationData neOperation = new NeOperationBuilder().build(NE_ID, 1);
        final NeUserPreferencesData nePreferences = new NeUserPreferencesBuilder().setName("blah").build(NE_ID, 0);

        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);

        when(operationRepo.query(NE_ID)).thenReturn(Optional.of(neOperation));
        when(preferencesRepo.query(NE_ID)).thenReturn(Optional.of(nePreferences));

        when(operationRepo.tryUpdate(any(NeOperationMutationDescriptor.class))).then(new MutationAnswer<>());
        when(preferencesRepo.tryUpdate(any(NeUserPreferencesMutationDescriptor.class))).thenThrow(new RepositoryException());

        new UpdateNeOperationInfoEventHandler<>(null, neRepository, notifications, appProperties, neConnectionManager, neInstanceRepository).handleEvent(event);
    }

    @Test public void shouldNotifyMediatorOnRename() throws Exception {
        final NeOperationInfoChangedEvent event = buildEvent();
        event.setRealNeName("network name");

        final NeOperationData neOperation = new NeOperationBuilder().build(NE_ID, 1);
        final NeUserPreferencesData nePreferences = new NeUserPreferencesBuilder().setName("blah").build(NE_ID, 0);
        NeEntity neEntity = new NeEntity(null, neOperation, null, null, nePreferences);
        NePhysicalConnectionData connectionData = new NePhysicalConnectionBuilder().build(NE_ID, NE_ID, 1, 1);

        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);

        when(operationRepo.query(NE_ID)).thenReturn(Optional.of(neOperation));
        when(preferencesRepo.query(NE_ID)).thenReturn(Optional.of(nePreferences));

        when(operationRepo.tryUpdate(any(NeOperationMutationDescriptor.class))).then(new MutationAnswer<>());
        when(preferencesRepo.tryUpdate(any(NeUserPreferencesMutationDescriptor.class))).then(new MutationAnswer<>());

        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(asList(connectionData));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));


        new UpdateNeOperationInfoEventHandler<>(null, neRepository, notifications, appProperties, neConnectionManager, neInstanceRepository).call(event);


        ArgumentCaptor<NeUserPreferencesMutationDescriptor> descriptorCaptor = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(neConnectionManager, atLeastOnce())
                .updateNeProperties(any(NeEntity.class), any(NePhysicalConnectionData.class), descriptorCaptor.capture(), any(Map.class));
        assertThat(descriptorCaptor.getValue().getName(), is(Optional.of("network name")));
    }

    private NeOperationInfoChangedEvent buildEvent() {
        final NeOperationInfoChangedEvent event = new NeOperationInfoChangedEvent(NE_ID);

        event.setRealNeName("ne_name");
        event.setNeighbourhoodId("tid");
        event.setEventForwardingActive(true);
        event.setTpGroupMask(1234L);
        event.setTpGroupMode(new TpGroupSettings(true, true, true, true));
        event.setFamily("family");
        event.setMainRelease("main");
        event.setMaintenanceRelease("maintenance");
        event.setNeSubType("subtype");
        event.setNeType("type");
        event.setNeSpecificType("specifictype");
        event.setOperationalMode(OperationalMode.ENABLED);
        event.setWriteAccess(WriteAccessMode.NE_PROXY);
        event.setCommissioning(CommissioningMode.NOT_COMMISSIONED);
        event.setGatewayMode(GatewayMode.PRIMARY);
        return event;
    }

}
