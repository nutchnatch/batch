package com.ossnms.dcn_manager.events.discovery;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import com.ossnms.dcn_manager.core.test.MockFactory;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ChannelSupportsNeTypeTest {

    private Types<ChannelType> types;
    private StaticConfiguration config;
    private LoggerManager<CallContext> logger;

    private final ChannelInfoData info = new ChannelInfoBuilder().setType("channel_type").setCoreId("").setActivationRequired(false).build(1, 1, 1);
    private NeType neType;
    private ChannelType channelType;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        config = mock(StaticConfiguration.class);
        logger = mock(LoggerManager.class);
        types = mock(Types.class);
        neType = MockFactory.mockNeType();
        channelType = MockFactory.mockEmType();

        when(config.getChannelTypes()).thenReturn(types);
        when(types.get("channel_type")).thenReturn(channelType);
    }

    @Test
    public void supports() {

        when(channelType.getSupportedNeTypes()).thenReturn(Collections.singletonList(neType));

        final NeDiscoveredEvent discovered =
                new NeDiscoveredEvent(new NeCreateDescriptor(2, neType), ImmutableMap.of(), Optional.of("name"), 1);

        final Pair<Optional<ChannelInfoData>, NeDiscoveredEvent> data =
                Pair.of(Optional.of(info), discovered);

        final Boolean result = new ChannelSupportsNeType<>(null, logger, config).call(data);
        assertThat(result, is(true));
    }

    @Test
    public void doesNotSupport() {

        when(channelType.getSupportedNeTypes()).thenReturn(Collections.emptyList());

        final NeDiscoveredEvent discovered =
                new NeDiscoveredEvent(new NeCreateDescriptor(2, neType), ImmutableMap.of(), Optional.of("name"), 1);

        final Pair<Optional<ChannelInfoData>, NeDiscoveredEvent> data =
                Pair.of(Optional.of(info), discovered);

        final Boolean result = new ChannelSupportsNeType<>(null, logger, config).call(data);
        assertThat(result, is(false));

        verify(logger).createNetworkResourceLog(any(CallContext.class), any(LoggerItemNe[].class));
    }

}
