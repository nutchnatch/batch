package com.ossnms.dcn_manager.commands.domain;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NetworkElementActivation;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemDomain;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.events.domain.DomainNeActivationPolicyChanged;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;

import java.util.Optional;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Changes whether newly discovered NEs within a domain are activated automatically,
 * when the global discovery policy is set to Domain.
 *
 * <img src="doc-files/setautomaticneactivationdomainpolicy-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/setautomaticneactivationdomainpolicy-sequence.png
 * loop For each domain ID
 * SetAutomaticNeActivationDomainPolicy --> DomainRepository : query(domainId)
 * activate DomainRepository
 * DomainRepository --> SetAutomaticNeActivationDomainPolicy : domain
 * deactivate DomainRepository
 * SetAutomaticNeActivationDomainPolicy --> SetAutomaticNeActivationDomainPolicy : setPolicy(domain)
 * SetAutomaticNeActivationDomainPolicy --> DomainRepository : tryUpdate(domain)
 * activate DomainRepository
 * DomainRepository --> SetAutomaticNeActivationDomainPolicy : updatedDomain
 * deactivate DomainRepository
 * end
 * @enduml
 */
public class SetAutomaticNeActivationDomainPolicy<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(SetAutomaticNeActivationDomainPolicy.class);

    private final DomainRepository domainRepository;
    private final DomainNotifications domainNotifications;
    private final LoggerManager<C> loggerManager;
    private final Iterable<Integer> affectedDomainIds;
    private final boolean allowActivationPolicy;

    private final NeEntityRepository neRepository;
    private final NetworkElementActivation networkElementActivation;

    /**
     * Creates a new object.
     *
     * @param context Call context, to be passed on to outbound interfaces.
     * @param repository Domain repository instance.
     * @param affectedDomainIds Domain identifiers.
     * @param allowActivationPolicy Whether newly discovered NEs within the domains are activated automatically.
     */
    public SetAutomaticNeActivationDomainPolicy(@Nonnull C context,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull DomainRepository domainRepository,
            @Nonnull DomainNotifications domainNotifications,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull Iterable<Integer> affectedDomainIds,
            boolean allowActivationPolicy) {
        super(context);
        this.domainRepository = domainRepository;
        this.domainNotifications = domainNotifications;
        neRepository = neManagers.getNeRepository();
        networkElementActivation = new NetworkElementActivation(neManagers.getNeNotifications(), neRepository,
                neManagers.getNeActivationManager(), neManagers.getNeInstanceRepository(), channelManagers.getChannelInstanceConnections());
        this.loggerManager = loggerManager;
        this.affectedDomainIds = affectedDomainIds;
        this.allowActivationPolicy = allowActivationPolicy;
    }

    @Override
    public Void call() throws CommandException {
        boolean allChangesOk = true;

        for (final Integer domainId : affectedDomainIds) {
            final boolean result = setPolicy(domainId);
            allChangesOk &= result;
        }

        if (!allChangesOk) {
            throw new CommandException(tr(Message.SOME_DOMAIN_CHANGES_FAILED));
        }

        return null;
    }

    private boolean setPolicy(Integer domainId) {
        final Optional<DomainInfoMutationDescriptor> domain = prepareMutation(domainId);
        if (!domain.isPresent()) {
            return false;
        }

        try {
            final Optional<DomainInfoData> updated = domainRepository.tryUpdate(domain.get());
            if (updated.isPresent()) {
                logResult(updated.get().getName(), true);
                return true;
            } else {
                LOGGER.warn("Failed to update domain with {}: concurrent modification.", domain.get());
                logResult(domain.get().getTarget().getName(), false);
            }
        } catch (final RepositoryException exception) {
            LOGGER.warn("Error while updating domain with {}: {}", domain.get(),
                    getStackTraceAsString(exception));
            logResult(domain.get().getTarget().getName(), false);
        }

        return false;
    }

    private Optional<DomainInfoMutationDescriptor> prepareMutation(Integer domainId) {
        try {
            return domainRepository.query(domainId).
                map(input -> new DomainInfoMutationDescriptor(input)
                        .setAutomaticNeActivationPermitted(allowActivationPolicy)
                        .whenApplied(in -> {
                            domainNotifications.notifyChanges(
                                new DomainNeActivationPolicyChanged(in.getTarget().getId(), allowActivationPolicy));
                            actOnAutomaticNeActivationPolicyChange(in.getTarget());
                        }));
        } catch (final RepositoryException exception) {
            LOGGER.warn("Error while searching for domain {} {}", domainId,
                    getStackTraceAsString(exception));
            return Optional.empty();
        }
    }

    private void logResult(String domainName, boolean operationSucceeded, Object... messageParameters) {
        final String messageText =
            tr(operationSucceeded ? Message.DOMAIN_CHANGED : Message.DOMAIN_CHANGE_FAILED, messageParameters);
        final LoggerItem logItem = new LoggerItemDomain(domainName, messageText,
            operationSucceeded ? MessageSeverity.INFO : MessageSeverity.WARNING);
        loggerManager.createCommandLog(getContext(), logItem);
    }

    private void actOnAutomaticNeActivationPolicyChange(DomainInfoData domain) {
        LOGGER.info("actOnAutomaticNeActivationPolicyChange entry for domain {} with policy {}", domain.getName(), allowActivationPolicy);
        if(allowActivationPolicy) {
            Iterable<Integer> neIdsOnDomain = domainRepository.queryChildrenNEs(domain.getId());
            if(null != neIdsOnDomain) {
                for(Integer neId : neIdsOnDomain) {
                    try {
                        Optional<NeInfoData> neInfo = neRepository.getNeInfoRepository().query(neId);
                        if(neInfo.isPresent()) {
                            LOGGER.debug("Try to activate NE with neId={} due to enable of automatic activation of NEs on domain", neId);
                            tryActivateNetworkElement(neInfo.get());
                        }
                    } catch (RepositoryException e) {
                        LOGGER.warn("Error while searching for ne info from neId {} {}", neId,
                                getStackTraceAsString(e));
                    }
                }
            }
        }
    }
    
    private void tryActivateNetworkElement(NeInfoData neInfo) {

        try {
            networkElementActivation.changeActualStateToStartUp(neInfo.getId());
            networkElementActivation.changeRequiredStateToActive(neInfo);
        } catch (RepositoryException e) {
            LOGGER.warn("Failed to activate, while enabling automatic activation of NEs in domain, for  NE id {}: {}",
                neInfo.getId(), getStackTraceAsString(e));
        }
    }
}
