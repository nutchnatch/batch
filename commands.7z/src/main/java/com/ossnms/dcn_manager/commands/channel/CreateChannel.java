package com.ossnms.dcn_manager.commands.channel;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.channel.ChannelCreationBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;

/**
 * Creates and stores a new Channel, if the creation request is valid.
 * Otherwise an exception will be thrown.
 *
 * <img src="doc-files/createchannelcmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/createchannelcmd-sequence.png
 * CreateChannel --> CreateChannel : validateType
 * activate ChannelEntityRepository
 * CreateChannel --> ChannelEntityRepository : create(ChannelCreateDescriptor)
 * ChannelEntityRepository --> CreateChannel : channel
 * deactivate ChannelEntityRepository
 * CreateChannel --> ChannelNotifications : notifyCreate(channel)
 * CreateChannel --> LoggerManager : createCommandLog
 * CreateChannel --> ChannelSchedulingConfiguration : setMaxOngoingChannelJobCount
 * @enduml
 */
public class CreateChannel<C extends CallContext> extends Command<C, ChannelEntity> {

    private final ChannelCreationBase<C> delegate;
    private final ChannelCreateDescriptor createEvent;

    public CreateChannel(@Nonnull C context,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull ChannelSchedulingConfiguration channelScheduling,
            @Nonnull MediatorEntityRepository mediatorRepository,
            @Nonnull MediatorInstanceEntityRepository mediatorInstanceRepository,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull ChannelCreateDescriptor createEvent) {
        super(context);
        this.createEvent = createEvent;
        delegate = new ChannelCreationBase<C>(context,
                channelManagers.getChannelRepository(), channelManagers.getChannelNotifications(), channelManagers.getChannelInstanceConnections(),
                channelScheduling, mediatorRepository, mediatorInstanceRepository, loggerManager);
    }

    @Override
    public ChannelEntity call() throws CommandException, DuplicatedObjectNameException {
        try {
            return delegate.tryCreateChannel(createEvent);
        }
        catch (RepositoryException | UnknownMediatorIdException e) {
            throw new CommandException("Could not create Channel.", e);
        }
    }

}
