package com.ossnms.dcn_manager.commands.system;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.SystemValidator;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemSystem;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.SystemNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Applies modifications to one or more System Containers.
 */
public class ModifySystems<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(ModifySystems.class);

    private final SystemRepository systemRepository;
    private final LoggerManager<C> loggerManager;
    private final Iterable<SystemInfoMutationDescriptor> changesRequested;
    private final SystemNotifications systemNotifications;
    private final SystemValidator validator;

    /**
     * Creates a new instance.
     *
     * @param context             Call context.
     * @param systemRepository    Container repository instance.
     * @param systemNotifications Connector responsible for propagating notifications
     *                            about container modifications to the outside world.
     * @param loggerManager       System logger manager, for recording action outcomes.
     * @param changes             Collection of changes that should be applied to existing System containers.
     */
    public ModifySystems(@Nonnull C context,
            @Nonnull SystemRepository systemRepository,
            @Nonnull ContainerRepository containerRepository,
            @Nonnull NeUserPreferencesRepository neRepository,
            @Nonnull SystemNotifications systemNotifications,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull Iterable<SystemInfoMutationDescriptor> changes) {
        super(context);
        this.systemRepository = systemRepository;
        this.systemNotifications = systemNotifications;
        this.loggerManager = loggerManager;
        this.changesRequested = changes;
        this.validator = new SystemValidator(neRepository, systemRepository, containerRepository);
    }

    @Override public Void call() throws CommandException {
        boolean allChangesOk = true;

        for (final SystemInfoMutationDescriptor descriptor : changesRequested) {
            validateNewName(descriptor);

            final boolean result = modifyContainer(descriptor);
            allChangesOk &= result;
        }

        if (!allChangesOk) {
            throw new CommandException(tr(Message.SOME_SYSTEM_CHANGES_FAILED));
        }

        return null;
    }

    private void validateNewName(SystemInfoMutationDescriptor descriptor) throws CommandException {
        if (descriptor.getName().isPresent()) {
            try {
                validator.validateNewName(descriptor.getName().get());
            } catch (final DuplicatedObjectNameException | RepositoryException e) {
                throw new CommandException(e);
            }
        }
    }

    private boolean modifyContainer(final SystemInfoMutationDescriptor descriptor) {
        try {
            descriptor.whenApplied(in -> {
                systemNotifications.notifyChanges(in);
                logResult(in.getTarget().getName(), true);
            });

            final Optional<SystemInfo> updatedContainer = systemRepository.tryUpdate(descriptor);
            if (updatedContainer.isPresent()) {
                return true;
            } else {
                LOGGER.warn("Failed to update System container with {}: concurrent modification.", descriptor);
                logResult(descriptor.getTarget().getName(), false);
            }
        } catch (final RepositoryException exception) {
            LOGGER.warn("Error while updating System container with {}: {}", descriptor,
                    Throwables.getStackTraceAsString(exception));
            logResult(descriptor.getTarget().getName(), false);
        }
        return false;
    }

    private void logResult(String containerName, boolean operationSucceeded, Object... messageParameters) {
        final String messageText = tr(operationSucceeded ? Message.SYSTEM_CHANGED : Message.SYSTEM_CHANGE_FAILED,
                messageParameters);
        final LoggerItem logItem = new LoggerItemSystem(containerName, messageText,
                operationSucceeded ? MessageSeverity.INFO : MessageSeverity.WARNING);
        loggerManager.createCommandLog(getContext(), logItem);
    }
}
