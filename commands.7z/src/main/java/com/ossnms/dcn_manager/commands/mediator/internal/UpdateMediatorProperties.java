package com.ossnms.dcn_manager.commands.mediator.internal;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.mediator.UpdateMediatorPropertiesBase;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.outbound.MediatorConnectionManager;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.DuplicatedHostException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorTypeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.StreamSupport;

/**
 * <p>Receives a set of mediator properties that have to be set/updated in the business entity.</p>
 * <p>After validating these and recalculating related dynamic properties, the final set
 * must be propagated to other components as a change notification.</p>
 *
 * <img src="doc-files/updatemediatorcmd-activity.png">
 * <img src="doc-files/updatemediatorcmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/updatemediatorcmd-activity.png
 * start
 * if (Properties changed?) then (yes)
 *  :Change stored mediator entity;
 * note left: Change validations are \ndone on the repository and \nentity classes.
 *  :Produce change notification;
 * endif
 * stop
 * @enduml
 */
/*
 * @startuml doc-files/updatemediatorcmd-sequence.png
 * alt If properties have changed
 *  UpdateMediatorProperties --> MediatorRepository: findMediator
 *  UpdateMediatorProperties --> MediatorRepository: updateMediator
 *  UpdateMediatorProperties --> NotificationManager: mediatorUpdated
 * end
 * @enduml
 */
public class UpdateMediatorProperties<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateMediatorProperties.class);

    private final UpdateMediatorPropertiesBase<C> base;
    private final MediatorConnectionManager connectionManager;
    private final MediatorInstanceEntityRepository mediatorInstanceRepository;
    private final Data newPropertyData;

    public UpdateMediatorProperties(@Nonnull C context,
                                    @Nonnull MediatorManagers mediatorManagers,
                                    @Nonnull MediatorConnectionManager connectionManager,
                                    @Nonnull ChannelManagers channelManagers,
                                    @Nonnull NetworkElementManagers neManagers,
                                    @Nonnull MediatorSchedulingConfiguration mediatorScheduling,
                                    @Nonnull ChannelSchedulingConfiguration channelScheduling, 
                                    @Nonnull StaticConfiguration configuration,
                                    @Nonnull LoggerManager<C> loggerManager,
                                    @Nonnull Data newPropertyData) {
        super(context);
        this.newPropertyData = newPropertyData;
        base = new UpdateMediatorPropertiesBase<>(getContext(),
                new UpdateMediatorPropertiesBase.RepositoriesToUpdate(mediatorManagers.getMediatorRepository(),
                        mediatorManagers.getMediatorInstanceRepository(), channelManagers.getChannelRepository(),
                        channelManagers.getChannelInstanceConnections(), neManagers.getNeRepository(),
                        neManagers.getNeInstanceRepository()),
                new UpdateMediatorPropertiesBase.NotificationsToSend(mediatorManagers.getMediatorNotifications(),
                        channelManagers.getChannelNotifications(), neManagers.getNeNotifications()),
                mediatorScheduling, channelScheduling, configuration, loggerManager, newPropertyData.activeMediatorPriority);
        this.connectionManager = connectionManager;
        this.mediatorInstanceRepository = mediatorManagers.getMediatorInstanceRepository();
    }

    @Override
    public Void call() throws UnknownMediatorIdException, RepositoryException, UnknownMediatorTypeException, DuplicatedObjectNameException, InvalidMutationException, DataUpdateException, DuplicatedHostException {
        Optional<MediatorInfoData> mediatorInfoDataChanged = base.applyUpdate(newPropertyData.mediatorId, newPropertyData.updatedProperties);
        if(mediatorInfoDataChanged.isPresent()) {
            pushMediatorInfoData(newPropertyData);
        }
        return null;
    }

    /**
     * Parameter object with the necessary mediator property data.
     */
    public static final class Data {

        private final int mediatorId;
        private final String mediatorIdName;
        private final Map<String, String> updatedProperties;
        private final int activeMediatorPriority;

        /**
         * @param mediatorId Target Mediator identifier.
         * @param updatedProperties New Mediator properties as (name, value) pairs.
         * @param activeMediatorPriority Mediator instance priority index to be considered active on creation operations.
         */
        public Data(int mediatorId, String mediatorIdName, Map<String, String> updatedProperties, int activeMediatorPriority) {
            this.mediatorId = mediatorId;
            this.mediatorIdName = mediatorIdName;
            this.activeMediatorPriority = activeMediatorPriority;
            // this copy is necessary because the map will be modified to reflect actual changes.
            this.updatedProperties = new HashMap<>(updatedProperties);
        }
    }
    
    private void pushMediatorInfoData(Data mediatorInfoData) throws RepositoryException, UnknownMediatorIdException {

        final Optional<MediatorConnectionData> mediator = base.getMediatorRepository().getMediatorConnectionRepository().query(mediatorInfoData.mediatorId);

        if (!mediator.isPresent()) {
            throw new UnknownMediatorIdException("Mediator {} with id {} is no longer available.", mediatorInfoData.mediatorIdName, mediatorInfoData.mediatorIdName);
        }
        if (!mediator.get().isActive()) {
            return;
        }
        StreamSupport.stream(mediatorInstanceRepository.getMediatorPhysicalDataRepository().queryAll().spliterator(), false).
            filter(m -> m.getLogicalMediatorId() == mediatorInfoData.mediatorId).
            filter(m -> isInstanceActivated(m.getId())).
            forEach(instance -> pushMediatorProperties(instance.getId(), mediatorInfoData.updatedProperties));

    }

    private void pushMediatorProperties(int physicalMediatorId, Map<String, String> properties) {
        try {
            connectionManager.updateMediatorProperties(physicalMediatorId, properties);
        } catch (final ConnectException e) {
            logMediatorPropertyUpdateFailure(newPropertyData.mediatorId, newPropertyData.mediatorIdName);
        }
    }

    private void logMediatorPropertyUpdateFailure(int mediatorId, String mediatorIdName) {
            LOGGER.error("updateProperties: Mediator {} was active but updating the properties failed. ID = {}",
                    mediatorIdName, mediatorId);

            base.getLoggerManager().createCommandLog(getContext(), new LoggerItemMediator( mediatorIdName,
                    "Mediator " + mediatorIdName + " was active but updating the properties failed ID=" + mediatorIdName));
    }

    private boolean isInstanceActivated(int instanceId) {
        Optional<MediatorPhysicalConnectionData> connectionData;
        try {
            connectionData = mediatorInstanceRepository.getMediatorPhysicalConnectionRepository().query(instanceId);
            if(connectionData.isPresent()) {
                return connectionData.get().getActualActivationState() == ActualActivationState.ACTIVE;
            }
            LOGGER.error("Connection information for mediator instance {} does not exist!",
                    instanceId);
        } catch (final RepositoryException e) {
            LOGGER.error("Error looking up mediator instance {}: {}",
                    instanceId, Throwables.getStackTraceAsString(e));
        }        
        return false;
    }
    
}
