package com.ossnms.dcn_manager.commands.container;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownContainerIdException;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Retrieves an existing container from the repository.
 *
 * <img src="doc-files/getcontainer-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getcontainer-sequence.png
 * GetContainer --> ContainerRepository : query(containerId)
 * activate ContainerRepository
 * ContainerRepository --> GetContainer : container
 * deactivate ContainerRepository
 * @enduml
 */
public class GetContainer<C extends CallContext> extends Command<C, ContainerInfo> {

    private final ContainerRepository repository;
    private final int containerId;

    public GetContainer(@Nonnull C context, @Nonnull ContainerRepository repository, int containerId) {
        super(context);
        this.repository = repository;
        this.containerId = containerId;
    }

    @Override
    public ContainerInfo call() throws RepositoryException, UnknownContainerIdException {
        return repository.query(containerId)
                .orElseThrow(() -> new UnknownContainerIdException(tr(Message.CONTAINER_DOES_NOT_EXIST, containerId)));
    }

}
