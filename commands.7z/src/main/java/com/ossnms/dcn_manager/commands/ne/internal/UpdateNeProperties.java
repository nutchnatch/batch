package com.ossnms.dcn_manager.commands.ne.internal;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NeDomainsUpdater;
import com.ossnms.dcn_manager.composables.ne.NePropertiesUpdater;
import com.ossnms.dcn_manager.composables.ne.NePropertiesUpdater.PreprocessedChanges;
import com.ossnms.dcn_manager.composables.ne.UpdateNePropertiesBase;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NePropertiesChangedEvent;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.google.common.collect.Iterables.transform;

/**
 * <p>Receives a set of NE properties that have to be set/updated in the NE entity.</p>
 * <p>After validating these and recalculating related dynamic properties, the final set
 * must be propagated to other components as a change notification.</p>
 * <p>If the NE is online, its mediator must be notified as well.</p>
 *
 * <img src="doc-files/updatenecmd-activity.png">
 * <img src="doc-files/updatenecmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/updatenecmd-activity.png
 * start
 * if (Properties changed?) then (yes)
 *  :Change stored NE entity;
 * note left: Change validations are \ndone on the repository and \nentity classes.
 *  :Produce change notification;
 *  if (NE online?) then (yes)
 *   :Send properties to NE through mediator;
 *  endif
 * endif
 * stop
 * @enduml
 */
/*
 * @startuml doc-files/updatenecmd-sequence.png
 * alt If properties have changed
 *  UpdateNeProperties --> NetworkElementRepository: tryFindNe
 *  UpdateNeProperties --> NetworkElementRepository: updateNe
 *  UpdateNeProperties --> NotificationManager: notifyChanges
 *  UpdateNeProperties --> LoggerManager : createCommandLog
 *  alt If NE is online
 *   UpdateNeProperties --> NeConnectionManager: updateProperties
 *  end
 * end
 * @enduml
 */
public class UpdateNeProperties<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateNeProperties.class);

    private final NePhysicalConnectionRepository neInstanceRepository;
    private final NeGatewayRoutesRepository routeRepository;
    private final NeConnectionManager connectionManager;
    private final UpdateNePropertiesBase<C> base;
    private final Map<String, String> updatedProperties;
    private final int neId;

    private final NePropertiesUpdater<C> propertiesUpdater;

    public UpdateNeProperties(C context,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull SystemRepository systemRepository,
            @Nonnull StaticConfiguration configuration,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull NeConnectionManager connectionManager,
            @Nonnull NeDomainsUpdater domainUpdater,
            @Nonnull NePropertiesChangedEvent changeEvent) {
        super(context);
        routeRepository = neManagers.getNeRepository().getNeGatewayRoutesRepository();
        neInstanceRepository = neManagers.getNeInstanceRepository();
        neId = changeEvent.getNeId();
        // this copy is necessary because the map will be modified to reflect actual changes.
        updatedProperties = new HashMap<>(changeEvent.getPropertiesChanged());
        propertiesUpdater = new NePropertiesUpdater<>(context, neManagers.getNeRepository(), systemRepository, loggerManager,
                neManagers.getNeNotifications(), domainUpdater);
        base = new UpdateNePropertiesBase<>(configuration, neManagers.getNeActivationManager(), propertiesUpdater);
        this.connectionManager = connectionManager;
    }

    @Override
    public Void call() throws DcnManagerException {
        // empty updates are no-ops.
        if (updatedProperties.isEmpty()) {
            return null;
        }

        final NeEntity ne = base.findNe(neId);
        final Iterable<NeGatewayRouteData> neRoutes = routeRepository.queryRoutes(neId);

        final Optional<Integer> gatewayRouteLength = consumeGatewayRouteLength();
        final Iterable<NeGatewayRouteData> gatewayRoutesForProcessing =
                gatewayRouteLength.isPresent()
                    ? Collections.emptyList() // we'll be deleting existing routes, so send nothing to the updater.
                    : neRoutes; // no deletion, but routes may need to be updated if related attributes change.

        final Optional<PreprocessedChanges> update = base.prepareUpdate(ne, gatewayRoutesForProcessing, updatedProperties);
        if (update.isPresent()) {
            if (gatewayRouteLength.isPresent()) {
                /*
                 * A new set of gateway routes has been received. Because we are receiving external bulk
                 * updates, there is no way to determine reliably if any existing route should be removed.
                 * Hence all routes must be present in the update. We now remove existing routes so we
                 * can ensure that no unwanted routes are left behind after the update is committed.
                 */
                transform(neRoutes, NeGatewayRouteData::getKey).forEach(
                    routeKey ->
                        update.get().getUnitOfWork()
                            .addUnit(ctx -> { routeRepository.deleteRoute(ctx, routeKey); return null; })
                );
            }

            Map<String, String> emptyValuesMap = updatedProperties.entrySet().stream()
                    .filter(entry -> Objects.equals(entry.getValue(), ""))
                    .collect(Collectors.toMap(Entry::getKey, Entry::getValue));

            final Optional<NeEntity> updatedNe = base.processUpdate(update.get());
            if (updatedNe.isPresent()) {
                neInstanceRepository.queryAll(neId)
                    .forEach(physicalConnection -> sendPropertiesToMediator(
                            updatedNe.get(), update.get().getPreferencesMutationDescriptor(), physicalConnection, emptyValuesMap));
            }

        }

        return null;
    }

    private void sendPropertiesToMediator(NeEntity ne, NeUserPreferencesMutationDescriptor newPreferences, NePhysicalConnectionData connection, Map<String, String> updatedEmptyProperties) {
        if (!connection.isActiveState()) {
            return;
        }

        try {
            connectionManager.updateNeProperties(ne, connection, newPreferences, updatedEmptyProperties);
        } catch (final ConnectException e) {
            LOGGER.warn("updateProperties: NE instance was connected but updating the properties failed: {}",
                    connection);
            if (connection.isActive()) {
                propertiesUpdater.getLoggerManager().createCommandLog(getContext(), new LoggerItemNe(
                        newPreferences.getResult().getName(),
                        "NE was active but updating the properties failed ID=" + neId,
                        neId));
            }
        }
    }

    /**
     * Obtains, and removes from further processing, the number of rows in the gateway route table received from the client.
     * Ensure to call this method before sending the property bag for processing.
     *
     * @return The number of rows in the gateway route table received from the client.
     *  Will be absent if no route table was received at all.
     */
    private Optional<Integer> consumeGatewayRouteLength() {
        return Optional.
                ofNullable(updatedProperties.remove(WellKnownNePropertyNames.INTERNAL_ROUTE_ROW_COUNT)).
                map(Integer::valueOf);
    }
}
