package com.ossnms.dcn_manager.commands.container.assignment;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.ContainersSystemAssignmentUpdater;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownContainerIdException;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;

import static com.google.common.collect.ImmutableSet.of;
import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Create a new single assignment. Used for new object creation.
 * @param <C> context
 */
public class CreateSingleSystemAssignment<C extends CallContext> extends Command<C, Void> {
    private final ContainersSystemAssignmentUpdater updater;
    private final SystemInfo systemInfo;
    private final ContainerRepository containerRepository;
    private final int containerId;

    public CreateSingleSystemAssignment(
            @Nonnull final C context,
            @Nonnull final ContainerRepository containerRepository,
            @Nonnull final SystemRepository systemRepository,
            @Nonnull final SystemInfo systemInfo,
            final int containerId,
            @Nonnull final ContainerNotifications containerNotifications,
            @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull final SettingsRepository settingsRepository) {
        super(context);
        this.systemInfo = systemInfo;
        this.containerId = containerId;
        this.containerRepository = containerRepository;
        updater = new ContainersSystemAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository,
                containerNotifications, loggerManager, context);
    }

    @Override public Void call() throws CommandException, UnknownContainerIdException {
        try {
            updater.store(of(new SystemAssignmentData(fetchContainer(), systemInfo.getId(), AssignmentType.PRIMARY)),
                    systemInfo);
        } catch (final RepositoryException e) {
            throw new CommandException(e);
        }
        return null;
    }

    private ContainerInfo fetchContainer() throws UnknownContainerIdException, RepositoryException {
        return containerRepository.query(containerId)
                .orElseThrow(() -> new UnknownContainerIdException(tr(Message.CONTAINER_DOES_NOT_EXIST, containerId)));
    }
}
