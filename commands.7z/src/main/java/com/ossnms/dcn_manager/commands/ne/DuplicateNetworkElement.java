package com.ossnms.dcn_manager.commands.ne;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.ContainersNeAssignmentUpdater;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NeCreationBase;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DataCreationException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.DuplicatedRouteException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;

import javax.annotation.Nonnull;

/**
 * Duplicate the NE based on template.
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class DuplicateNetworkElement<C extends CallContext> extends Command<C, NeEntity> {

    private static final int UNDEFINED = 0;

    private final NeCreationBase<C> delegate;
    private final LoggerManager<C> logger;
    private final C context;
    private final NeCreateDescriptor createDescriptor;
    private final SettingsRepository settingsRepository;
    private final ContainerRepository containerRepository;
    private final SystemRepository systemRepository;
    private final ContainerNotifications containerNotifications;
    private final int fromId;

    /**
     * Creates a new command instance.
     *
     * @param context Call context, to be passed on to outbound interfaces.
     * @param neManagers NE resources.
     * @param channelRepository Channel repository instance. Used for validating the parent Channel.
     * @param systemRepository System Containers repository
     * @param createDescriptor NE creation descriptor.
     * @param logger Operations log manager.
     */
    public DuplicateNetworkElement(
            @Nonnull final C context,
            @Nonnull final NetworkElementManagers neManagers,
            @Nonnull final ChannelEntityRepository channelRepository,
            @Nonnull final SystemRepository systemRepository,
            @Nonnull final ChannelPhysicalConnectionRepository channelInstanceRepository,
            @Nonnull final LoggerManager<C> logger,
            @Nonnull final SettingsRepository settingsRepository,
            @Nonnull final ContainerRepository containerRepository,
            @Nonnull final ContainerNotifications containerNotifications,
            @Nonnull final NeCreateDescriptor createDescriptor,
            @Nonnull final int fromId) {
        super(context);
        this.createDescriptor = createDescriptor;
        this.settingsRepository = settingsRepository;
        this.containerRepository = containerRepository;
        this.containerNotifications = containerNotifications;
        this.systemRepository = systemRepository;
        this.logger = logger;
        this.context = context;
        this.fromId = fromId;

        this.delegate = new NeCreationBase<>(context, neManagers.getNeRepository(),
                neManagers.getNeInstanceRepository(), neManagers.getNeNotifications(), channelRepository,
                systemRepository, channelInstanceRepository, logger);
    }

    @Override public NeEntity call() throws CommandException, UnknownChannelIdException, DuplicatedRouteException,
            DuplicatedObjectNameException {
        try {
            final NeEntity neEntity = delegate.tryCreateNe(createDescriptor);

            int systemId = neEntity.getPreferences().getContainerId().orElse(UNDEFINED);

            if (systemId == UNDEFINED) {
                new ContainersNeAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository,
                        containerNotifications, logger, context).duplicate(neEntity.getPreferences(), fromId);
            }
            return neEntity;
        } catch (final DataCreationException | RepositoryException e) {
            throw new CommandException("Could not create NE.", e);
        }
    }
}
