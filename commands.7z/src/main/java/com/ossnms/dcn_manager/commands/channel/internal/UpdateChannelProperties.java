package com.ossnms.dcn_manager.commands.channel.internal;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.channel.UpdateChannelPropertiesBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.outbound.ChannelConnectionManager;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * <p>Receives a set of channel properties that have to be set/updated in the channel entity.</p>
 * <p>After validating these and recalculating related dynamic properties, the final set
 * must be propagated to other components as a change notification.</p>
 * <p>If the channel is online, its mediator must be notified as well.</p>
 *
 * <img src="doc-files/updatechannelcmd-activity.png">
 * <img src="doc-files/updatechannelcmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/updatechannelcmd-activity.png
 * start
 * if (Properties changed?) then (yes)
 *  :Change stored channel entity;
 * note left: Change validations are \ndone on the repository and \nentity classes.
 *  :Produce change notification;
 *  if (Mediator online?) then (yes)
 *   :Include global EM/NE retry definitions in property set;
 *   :Send properties to mediator;
 *  endif
 * endif
 * stop
 * @enduml
 */
/*
 * @startuml doc-files/updatechannelcmd-sequence.png
 * alt If properties have changed
 *  UpdateChannelProperties --> ChannelRepository: findChannel
 *  UpdateChannelProperties --> ChannelRepository: updateChannel
 *  UpdateChannelProperties --> NotificationManager: channelUpdated
 *  UpdateChannelProperties --> ChannelSchedulingConfiguration: setMaxOngoingChannelJobCount
 *  alt If mediator is online
 *   UpdateChannelProperties --> UpdateChannelProperties: overrideProperties
 *   UpdateChannelProperties --> ChannelConnectionManager: updateProperties
 *  end
 * end
 * @enduml
 */
public class UpdateChannelProperties<C extends CallContext> extends Command<C, Void> {

    static final Logger LOGGER = LoggerFactory.getLogger(UpdateChannelProperties.class);

    private final UpdateChannelPropertiesBase<C> base;
    private final ChannelConnectionManager connectionManager;
    private final ChannelPhysicalConnectionRepository channelInstanceConnections;
    private final ChannelSchedulingConfiguration channelScheduling;
    private final int channelId;
    private final Map<String, String> updatedProperties;

    public UpdateChannelProperties(@Nonnull C context,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull ChannelConnectionManager channelConnections,
            @Nonnull ChannelSchedulingConfiguration channelScheduling,
            @Nonnull StaticConfiguration configuration,
            @Nonnull SettingsRepository settings,
            @Nonnull LoggerManager<C> loggerManager,
            int channelId, @Nonnull Map<String, String> updatedProperties) {
        super(context);
        this.channelScheduling = channelScheduling;
        this.channelId = channelId;
        // this copy is necessary because the map will be modified to reflect actual changes.
        this.updatedProperties = new HashMap<>(updatedProperties);
        this.base = new UpdateChannelPropertiesBase<C>(getContext(), channelManagers.getChannelRepository(),
                configuration, settings, loggerManager, channelManagers.getChannelNotifications());
        this.connectionManager = channelConnections;
        this.channelInstanceConnections = channelManagers.getChannelInstanceConnections();
    }

    @Override
    public Void call() throws DcnManagerException {
        final Optional<ChannelUserPreferencesData> preferences = base.applyUpdate(channelId, updatedProperties);
        if (preferences.isPresent()) {
            final int maximumOngoingJobCount = preferences.map(p -> p.isConcurrentActivationsLimited() ? p.getConcurrentActivationsLimit() : Integer.MAX_VALUE)
                .get();
            channelInstanceConnections.queryAll(channelId)
                .forEach(instance -> channelScheduling.setMaxOngoingChannelJobCount(instance.getId(), maximumOngoingJobCount));

            sendPropertiesToMediator(preferences.get().getName());
        }
        return null;
    }

    private void sendPropertiesToMediator(String channelName) throws RepositoryException, UnknownChannelIdException {

        final Optional<ChannelConnectionData> channel = base.getChannelRepository().getChannelConnectionRepository().query(channelId);
        if (!channel.isPresent()) {
            throw new UnknownChannelIdException("Channel {} is no longer available.", channelId);
        }
        if (!channel.get().isActive()) {
            return;
        }

        /*
         * Include global EM/NE properties in this entity and send the entire set to the mediator.
         * Continue using the original property set: it has been changed and validated already.
         */

        final Map<String, String> mergedProperties = base.mergeUpdatedPropertiesWithGlobalSettings(updatedProperties);

        try {
            connectionManager.updateChannelProperties(channelId, mergedProperties);
        } catch (final ConnectException e) {
            logChannelPropertyUpdateFailure(channelName);
        }
    }

    private void logChannelPropertyUpdateFailure(String channelName) {

        LOGGER.warn("updateProperties: Channel was active but updating the properties failed. ID = {}",
                channelId);

        base.getLoggerManager().createCommandLog(getContext(), new LoggerItemChannel(
                channelName,
                "Channel was active but updating the properties failed ID=" + channelId));
    }
}
