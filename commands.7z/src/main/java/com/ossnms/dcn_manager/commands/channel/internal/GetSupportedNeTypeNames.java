package com.ossnms.dcn_manager.commands.channel.internal;

import com.google.common.base.Function;
import com.google.common.collect.FluentIterable;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.exceptions.UnknownChannelTypeException;

import javax.annotation.Nonnull;

import static com.google.common.base.Predicates.notNull;

public class GetSupportedNeTypeNames<C extends CallContext> extends Command<C, Iterable<String>> {

    private final StaticConfiguration configuration;
    private final String typeName;

    public GetSupportedNeTypeNames(C context, @Nonnull String typeName, @Nonnull StaticConfiguration configuration) {
        super(context);
        this.typeName = typeName;
        this.configuration = configuration;
    }

    @Override
    public Iterable<String> call() throws CommandException {
        try {
            final ChannelType channelType = findChannelType();
            return FluentIterable
                    .from(channelType.getSupportedNeTypes())
                    .transform(new GetNeTypeName())
                    .filter(notNull());
        } catch (final UnknownChannelTypeException e) {
            throw new CommandException(e);
        }
    }

    private ChannelType findChannelType() throws UnknownChannelTypeException {
        final ChannelType channelType = configuration.getChannelTypes().get(typeName);
        if (null == channelType) {
            throw new UnknownChannelTypeException(typeName);
        }
        return channelType;
    }

    private static final class GetNeTypeName implements Function<NeType, String> {
        @Override
        public String apply(NeType input) {
            return null != input ? input.getName() : null;
        }
    }

}
