package com.ossnms.dcn_manager.commands.mediator;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.Nonnull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.mediator.MediatorModificationBase;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.IllegalMediatorStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;

/**
 * Deletes an existing Mediator.
 * Exceptions will be thrown upon execution if the mediator can not be deleted.
 *
 * <img src="doc-files/deletemediatorcmd-activity.png">
 * <img src="doc-files/deletemediatorcmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/deletemediatorcmd-activity.png
 * start
 * if (Mediator is active? //OR//\nMediator has Channels?) then (fail)
 * else
 *   :Delete Mediator from repository;
 *   :Produce deletion notifications;
 *   :Produce log entries;
 * endif
 * stop
 * @enduml
 */
/*
 * @startuml doc-files/deletemediatorcmd-sequence.png
 * DeleteMediator --> MediatorRepository : findMediator(mediatorId)
 * activate MediatorRepository
 * MediatorRepository --> DeleteMediator : mediator
 * deactivate MediatorRepository
 * alt If mediator deletion is allowed
 * DeleteMediator --> MediatorRepository : delete(mediator)
 * DeleteMediator --> Notifications : notifyDelete(mediator)
 * DeleteMediator --> LoggerManager : createCommandLog(...)
 * DeleteMediator --> MediatorSchedulingConfiguration : onMediatorRemoved
 * end
 * @enduml
 */
public class DeleteMediator<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = LoggerFactory.getLogger(DeleteMediator.class);

    private final MediatorModificationBase base;
    private final MediatorInstanceEntityRepository mediatorInstanceRepository;
    private final MediatorNotifications notifications;
    private final ChannelEntityRepository channelRepository;
    private final LoggerManager<C> loggerManager;
    private final int mediatorId;

    private final MediatorSchedulingConfiguration mediatorScheduling;


    public DeleteMediator(@Nonnull C context,
            @Nonnull MediatorManagers mediatorManagers,
            @Nonnull MediatorSchedulingConfiguration mediatorScheduling,
            @Nonnull ChannelEntityRepository channelRepository,
            @Nonnull LoggerManager<C> loggerManager,
            int mediatorId) {
        super(context);
        this.mediatorInstanceRepository = mediatorManagers.getMediatorInstanceRepository();
        this.mediatorScheduling = mediatorScheduling;
        this.channelRepository = channelRepository;
        this.mediatorId = mediatorId;
        this.base = new MediatorModificationBase(mediatorManagers.getMediatorRepository());
        this.notifications = mediatorManagers.getMediatorNotifications();
        this.loggerManager = loggerManager;
    }

    @Override
    public Void call() throws UnknownMediatorIdException, RepositoryException, IllegalMediatorStateException {
        final MediatorEntity mediator = base.findMediator(mediatorId);

        throwOnMediatorDeletionForbidden(mediator);

        deleteMediator(mediator);

        logAndNotify(mediator);

        return null;
    }

    private void logAndNotify(MediatorEntity mediator) {
        notifications.notifyDelete(mediator);

        LOGGER.info("Delete Mediator: Mediator Id={} Name={} was deleted.",
                mediatorId, mediator.getInfo().getName());

        loggerManager.createCommandLog(getContext(),
                new LoggerItemMediator(mediator.getInfo().getName(), "Mediator object deleted"));
    }

    private void deleteMediator(MediatorEntity mediator) throws RepositoryException {

        final Set<Integer> mediatorInstanceIds =
            StreamSupport.stream(mediatorInstanceRepository.queryAll(mediatorId).spliterator(), false)
                .map(instance -> instance.getPhysicalInfo().getId())
                .collect(Collectors.toSet());

        base.getMediatorRepository()
            .delete(new MediatorDeleteDescriptor(mediator.getInfo().getId()));

        mediatorInstanceIds.forEach(mediatorScheduling::onMediatorRemoved);
    }

    private void throwOnMediatorDeletionForbidden(MediatorEntity mediator) throws IllegalMediatorStateException, RepositoryException {

        if (mediator.getInfo().isActivationRequired()) {
            throw new IllegalMediatorStateException("Mediator {} with ID {} is still required to be active.",
                    mediator.getInfo().getName(), mediator.getInfo().getId());
        }

        if (mediator.getConnection().getActualActivationState() == ActualActivationState.ACTIVE) {
            throw new IllegalMediatorStateException("Mediator {} with ID {} is still active/connected.",
                    mediator.getInfo().getName(), mediator.getInfo().getId());
        }

        final boolean hasChildChannels = channelRepository.getChannelInfoRepository()
                .channelsExist(mediatorId);
        if (hasChildChannels) {
            throw new IllegalMediatorStateException("Mediator {} with ID {} still has child Channels.",
                    mediator.getInfo().getName(), mediator.getInfo().getId());
        }
    }

}
