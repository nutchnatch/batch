package com.ossnms.dcn_manager.commands.mediator.internal;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.mediator.MediatorModificationBase;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.behavior.MediatorInfoBehavior;
import com.ossnms.dcn_manager.core.entities.mediator.behavior.MediatorPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.IllegalMediatorStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;

import java.util.Optional;

import static com.google.common.collect.Iterables.filter;
import static com.google.common.collect.Iterables.isEmpty;
import static com.google.common.collect.Iterables.transform;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Command that requires the deactivation of a given mediator. As with all other commands, instances are
 * immutable and all dependencies are injected through the constructor. Instances are not to be reused,
 * that is, for each incoming external stimulus an new instance is specifically created to deal with it.</p>
 *
 * <p> The activation state of a mediator represents whether that mediator is required to be active or not, for
 * network management purposes. Whenever a mediator deactivation is required, it is set to the DeactivationRequired
 * state and the mediator connection termination sequence is triggered (a.k.a. actual mediator deactivation).
 * Although this sequence is not completely materialized in this command, due to the sequence's asynchronous nature,
 * it is described herein for clarity and depicted in the following figure. Note that the exact types and method names
 * may differ from the actual implementation: the diagram merely intends to provide an overview of the use-case. </p>
 *
 * <p> <figure>
 * <img src="doc-files/mediator_deactivation_required-sequence.png">
 * <figcaption>Sequence diagram of the mediator deactivation required use case</figcaption>
 * </figure> </p>
 *
 * As depicted, the command is responsible for the following sequence of actions
 * <ul>
 * 		<li> Fetch the data of the mediator info domain object (steps 2 and 3) </li>
 * 		<li> Instantiate the behavioral dimension of the mediator info domain object (steps 2 and 3) </li>
 * 		<li> Verify if all NEs reachable from through the mediator are also in the DeactivationRequired state (steps 4 and 5) </li>
 * 		<li> Require deactivation of the obtained mediator (steps 6 and 7) </li>
 * 		<li> Given the resulting state mutation, apply it to the entity (at the repository) (step 8) </li>
 * 		<li> When the mutation is successfully applied:
 * 			<ul>
 * 				<li> Create the corresponding event (step 9) </li>
 * 				<li> Schedule the mediator's deactivation (step 10)</li>
 * 				<li> Dispatch the created event (send it out-bound) (step 11)</li>
 * 			 </ul>
 * 		</li>
 * </ul>
 *
 * <p>Notice that the depicted sequence assumes correct execution. If any error occurs, an exception is thrown.
 * In particular, if any of the command's pre-conditions fails. This decision is due to the observation that,
 * if any of those conditions fail, then there is a logical error on the application. We are therefore better
 * off reporting that error as soon as it is detected. </p>
 *
 * The command's pre-conditions are:
 * <ul>
 * 		<li> The target mediator exists </li>
 * 		<li> The target mediator is not in the DeactivationRequired state</li>
 * 		<li> All NEs reachable through the target mediator are in the DeactivationRequired state. </li>
 * </ul>
 *
 * <p> A design decision that must be underlined is that the last pre-condition is expressed (and implemented)
 * as a pre-condition to the mediator deactivation use-case, instead of being implemented on the corresponding
 * domain object. This decision is due to the fact that, trying to deactivate a mediator that enables access
 * to activated NEs, is considered a usage error, and therefore it must be prevented at the use-case level.
 * From a domain perspective, it is plausible to admit that it could trigger the deactivation of the NEs. </p>
 *
 * @param <C>
 *            The concrete call context type
 */
/*
 * @startuml doc-files/mediator_deactivation_required-sequence.png

 * !definelong CALL_START(from,to,inMsg)
 * from -> to : inMsg
 * activate to
 * !enddefinelong

 * !definelong CALL_END(from,to,outMsg)
 * from <-- to : outMsg
 * deactivate to
 * !enddefinelong

 * !definelong CALL(from,to,inMsg,outMsg)
 * CALL_START(from,to,inMsg)
 * CALL_END(from,to,outMsg)
 * !enddefinelong

 * !define CALL_ASYNC(from,to,msg) from ->> to :msg

 * !definelong TRIGGER_CALL(from,to,inMsg)
 * from --\\ to : inMsg
 * activate to
 * !enddefinelong

 * hide footbox
 * autonumber
 * boundary Connector

 * participant MediatorDeactivationRequired << command >>
 * participant MediatorRepository << abstraction >>
 * participant "mediatorInfo: MediatorInfoBehavior" as MediatorInfo << domain object >>
 * participant MediatorInteractionManager << domain policy >>
 * participant EventDispatcher << abstraction >>

 * activate Connector

 * CALL_START(Connector,MediatorDeactivationRequired,call)
 * CALL(MediatorDeactivationRequired,MediatorRepository,findMediatorInfo :mediatorId, :mediatorInfo)
 * CALL(MediatorDeactivationRequired,MediatorRepository,verifyNEsState :mediatorId, :ok)
 * CALL(MediatorDeactivationRequired,MediatorInfo,deactivationRequired, :mutation)
 * CALL_START(MediatorDeactivationRequired,MediatorRepository,tryUpdateMediatorInfo :mutation)

 * note right of MediatorInfo
 * The execution of the following sequence is not
 * actually performed on the MediatorInfo domain object
 * instance, although it's specified by it.
 * endnote

 * TRIGGER_CALL(MediatorRepository,MediatorInfo,on_sucess => mutation.applied)

 * CALL_START(MediatorInfo, MediatorInfo,createEvent :mutation\n:deactivationRequiredEvent)
 * CALL_ASYNC(MediatorInfo, MediatorInteractionManager,scheduleMediatorDeactivation :deactivationRequiredEvent)
 * ref over MediatorInteractionManager
 * Asynchronous continuation of the
 * mediator deactivation use case
 * endref
 * CALL_ASYNC(MediatorInfo,EventDispatcher,notifyChanges :deactivationRequiredEvent)
 * ref over EventDispatcher
 * Event dispatching workflow
 * endref
 * deactivate MediatorInfo

 * CALL_END(MediatorRepository,MediatorInfo, )
 * CALL_END(MediatorDeactivationRequired,MediatorRepository, )
 * CALL_END(Connector,MediatorDeactivationRequired, )

 * deactivate Connector
 * deactivate MediatorInteractionManager
 * @enduml
 */
public class MediatorDeactivationRequired<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(MediatorDeactivationRequired.class);


	/**
	 * Holds the target mediator identifier.
	 */
	private final int mediatorId;

    /**
     * Holds a reference to a helper class with common methods.
     */
    private final MediatorModificationBase delegate;

	/**
	 * Holds a reference to the object responsible for triggering the actual mediator connection
	 */
	private final MediatorInteractionManager activationManager;

	/**
	 * Holds the reference to the component's event dispatcher
	 */
	private final MediatorNotifications eventDispatcher;

    /**
     * Holds the reference to the component responsible for logging operator actions
     */
    private final LoggerManager<C> loggerManager;

    /**
     * Holds a reference to the repository of Channel entities.
     */
    private final ChannelEntityRepository channelRepository;

    /**
     * Holds the reference to the repository of physical mediator instances
     */
    private final MediatorInstanceEntityRepository mediatorInstanceRepository;

	/**
	 * Instantiates the command with the given parameters
	 *
	 * @param context The call context
	 * @param mediatorId The mediator identifier
	 * @param activationManager The connection manager instance
	 * @param mediatorRepository The mediator repository to be used
	 * @param dispatcher The component's out-bound event dispatcher
	 * @param channelRepository The channel repository to be used.
	 * @param loggerManager Logger connector.
	 */
	public MediatorDeactivationRequired(@Nonnull C context, int mediatorId,
			@Nonnull MediatorManagers mediatorManagers,
			@Nonnull ChannelEntityRepository channelRepository,
			@Nonnull LoggerManager<C> loggerManager)
	{
		super(context);
        this.mediatorId = mediatorId;
		this.activationManager = mediatorManagers.getMediatorActivationManager();
        this.mediatorInstanceRepository = mediatorManagers.getMediatorInstanceRepository();
		this.eventDispatcher = mediatorManagers.getMediatorNotifications();
        this.channelRepository = channelRepository;
        this.loggerManager = loggerManager;
        this.delegate = new MediatorModificationBase(mediatorManagers.getMediatorRepository());
	}

	/**
	 * {@inheritDoc}
     * @throws RepositoryException When an error occurs while working with the data source.
     * @throws UnknownMediatorIdException When a deactivation is being requested with an invalid mediator ID.
     * @throws IllegalMediatorStateException If the mediator is already inactive.
     * @throws IllegalChannelStateException If there are Channels underneath the Mediator that are still required active.
	 */
	@Override
	public final Void call() throws UnknownMediatorIdException, RepositoryException, IllegalMediatorStateException, IllegalChannelStateException {

    	// Ensure that all Channels associated to the mediator are already in the deactivation required state
		// This is a pre-condition for the execution of the command
    	verifyChannelsState(delegate.findMediator(mediatorId).getConnection());

		mediatorInstanceRepository.getMediatorPhysicalConnectionRepository().queryAll(mediatorId)
		    .forEach(data -> changePhysicalActualStateToShuttingDown(data));

		changeRequiredStateToDeactivated();

		return null;
	}


	private void changeRequiredStateToDeactivated() throws UnknownMediatorIdException, RepositoryException, IllegalMediatorStateException, IllegalChannelStateException {
		// Get the mediator info data instance, if one exists, and instantiate it's behavioral dimension
	    final MediatorEntity mediatorEntity = delegate.findMediator(mediatorId);
		final MediatorInfoBehavior mediator =  new MediatorInfoBehavior(mediatorEntity.getInfo());

		// Is this a valid state transition?
		final Optional<MediatorInfoMutationDescriptor> mutationDesc =
	        mediator.deactivationRequired(eventDispatcher, transform(
			    filter(mediatorInstanceRepository.getMediatorPhysicalDataRepository().queryAll(), m -> m.getLogicalMediatorId() == mediatorId),
			    MediatorPhysicalData::getId));
		if (!mutationDesc.isPresent()) {
			throw new IllegalMediatorStateException(tr(Message.MEDIATOR_ALREADY_INACTIVE));
		}

		// Mark mediator according to the performed mutation
		// Because commands may be executed concurrently, update operations may fail (notice the
		// compound action queryMediator-updateMediatorState). In this use case, though, retry is not required.
		// Instead, we want to report an exception because concurrent mediator activation/deactivation requests should not
		// have been issued in the first place
		final Optional<MediatorInfoData> modifiedMediator = delegate.getMediatorRepository()
		        .getMediatorInfoRepository().tryUpdate(mutationDesc.get());
		if (!modifiedMediator.isPresent()) {
			throw new IllegalMediatorStateException(tr(Message.MEDIATOR_ALREADY_INACTIVE));
		}

		loggerManager.createCommandLog(getContext(), new LoggerItemMediator(
		        mediatorEntity.getInfo().getName(),
		        tr(Message.MEDIATOR_DEACTIVATION)));

	}

	private void changePhysicalActualStateToShuttingDown(MediatorPhysicalConnectionData data) {
	    try {
            final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
                    new MediatorPhysicalConnectionBehavior(data)
                        .setShuttingDown(eventDispatcher, activationManager);
            if (mutation.isPresent()) {
                final Optional<MediatorPhysicalConnectionData> result =
                        mediatorInstanceRepository.getMediatorPhysicalConnectionRepository().tryUpdate(mutation.get());
                if (!result.isPresent()) {
                    LOGGER.warn("Concurrent modification on mediator instance connection {}.", mutation.get());
                }
            } else {
                LOGGER.warn("Could not issue shutdown to physical mediator instance id {}, not a valid state.", data.getId());
            }
	    } catch (final RepositoryException e) {
	        LOGGER.error("Error issuing shutdown on physical mediator instance {}: {}", data, Throwables.getStackTraceAsString(e));
	    }
	}


    /**
     * Helper method that verifies if all the mediator's Channels are in the expected state
     * @throws RepositoryException When an error occurs while working with the data source.
     * @throws IllegalChannelStateException If there are Channels underneath the Mediator that are still required active.
     */
    private void verifyChannelsState(MediatorConnectionData connectionData) throws RepositoryException, IllegalChannelStateException, UnknownMediatorIdException {
		boolean noConnection = !connectionData.isActive() || connectionData.isFailed();
        if (!noConnection && !isEmpty(channelRepository.queryActivationRequiredIs(mediatorId, ChannelInfoData.ACTIVATION_REQUIRED))) {

        	MediatorEntity mediatorEntity = delegate.findMediator(mediatorId);
            LOGGER.warn("Failed to deactivate Mediator {}. {}", mediatorEntity.getInfo().getName(), Message.MEDIATOR_WITH_ACTIVE_CHANNELS);

            loggerManager.createCommandLog(getContext(), new LoggerItemMediator(
    		        mediatorEntity.getInfo().getName(),
    		        tr(Message.MEDIATOR_WITH_ACTIVE_CHANNELS)));

            throw new IllegalChannelStateException(tr(Message.CHANNEL_STILL_ACTIVE));
        }
    }

}
