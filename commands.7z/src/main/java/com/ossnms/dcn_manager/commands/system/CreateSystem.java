package com.ossnms.dcn_manager.commands.system;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.SystemValidator;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemSystem;
import com.ossnms.dcn_manager.core.entities.container.system.SystemCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.SystemNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Creates and stores a new System, if the creationDescriptor request is valid.
 * Otherwise an exception will be thrown.
 * <p>
 * <img src="doc-files/createsystemcmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/createsystemcmd-sequence.png
 * CreateSystem --> SystemRepository : create(SystemCreateDescriptor)
 * activate SystemRepository
 * SystemRepository --> CreateSystem : system
 * deactivate SystemRepository
 * CreateSystem --> SystemNotifications : notifyCreate(system)
 * CreateSystem --> LoggerManager : createCommandLog
 * @enduml
 */
public class CreateSystem<C extends CallContext> extends Command<C, SystemInfo> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateSystem.class);

    private final SystemRepository repository;
    private final SystemCreationDescriptor creationDescriptor;
    private final SystemNotifications notifications;
    private final LoggerManager<C> loggerManager;
    private final SystemValidator validator;

    public CreateSystem(
            @Nonnull C context,
            @Nonnull SystemRepository repository,
            @Nonnull ContainerRepository containerRrepository,
            @Nonnull NeUserPreferencesRepository neRepository,
            @Nonnull SystemNotifications notifications,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull SystemCreationDescriptor creation) {
        super(context);
        this.repository = repository;
        this.notifications = notifications;
        this.loggerManager = loggerManager;
        this.creationDescriptor = creation;

        this.validator = new SystemValidator(neRepository, repository, containerRrepository);
    }

    @Override public SystemInfo call() throws CommandException {

        try {
            final SystemInfo entity = tryCreateSystem();

            notifications.notifyCreate(entity);

            loggerManager
                    .createCommandLog(getContext(), new LoggerItemSystem(entity.getName(), tr(Message.SYSTEM_CREATED)));

            LOGGER.info("Created System '{}' with ID {}.", entity.getName(), entity.getId());

            return entity;
        } catch (final RepositoryException | DuplicatedObjectNameException e) {
            throw new CommandException(e);
        }
    }

    private SystemInfo tryCreateSystem() throws DuplicatedObjectNameException, RepositoryException {
        final String newName = creationDescriptor.getName();

        validator.validateNewName(newName);

        return repository.create(creationDescriptor);
    }
}
