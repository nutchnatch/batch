package com.ossnms.dcn_manager.commands.settings;

import java.util.Map;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.emne.SettingsProperties;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;

public class GetGlobalSettings<C extends CallContext> extends Command<C, Map<String, String>> {
    
    private final SettingsRepository repository;
    
    public GetGlobalSettings(@Nonnull final C context, @Nonnull final SettingsRepository repository) {
        super(context);
        this.repository = repository;
    }

    @Override
    public Map<String, String> call() throws CommandException {
        return SettingsProperties.getProperties(repository.getSettings());
    }
}
