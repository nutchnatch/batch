package com.ossnms.dcn_manager.commands.channel;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.properties.channel.ChannelProperties;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelTypeException;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;

/**
 * Retrieves properties belonging to an existing channel from the repository.
 *
 * <img src="doc-files/getchannelprops-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getchannelprops-sequence.png
 * GetChannel --> ChannelEntityRepository : queryChannel(channelId)
 * activate ChannelEntityRepository
 * ChannelEntityRepository --> GetChannel : channel
 * deactivate ChannelEntityRepository
 * @enduml
 */
public class GetChannelProperties<C extends CallContext> extends Command<C, Optional<Map<String, String>>> {

    private final ChannelEntityRepository repository;
    private final int channelId;
    private final StaticConfiguration configuration;

    public GetChannelProperties(@Nonnull C context,
            @Nonnull ChannelEntityRepository repository,
            @Nonnull StaticConfiguration configuration,
            int channelId) {
        super(context);
        this.repository = repository;
        this.configuration = configuration;
        this.channelId = channelId;
    }

    @Override
    public Optional<Map<String, String>> call() throws CommandException, UnknownChannelTypeException {
        try {
            final Optional<ChannelEntity> channel = repository.queryChannel(channelId);
            return channel.isPresent()
                ? Optional.of(getChannelProperties(channel.get()))
                : Optional.empty();
        } catch (final RepositoryException e) {
            throw new CommandException(e);
        }
    }

    private Map<String, String> getChannelProperties(@Nonnull ChannelEntity channel)
            throws UnknownChannelTypeException {
        final ChannelType type = configuration.getChannelTypes().get(channel.getInfo().getType());
        if (null == type) {
            throw new UnknownChannelTypeException("Stored channel {} references unknown type!",
                    channel.getInfo());
        }
        return new ChannelProperties().getProperties(type, channel.getUserPreferences());
    }
}
