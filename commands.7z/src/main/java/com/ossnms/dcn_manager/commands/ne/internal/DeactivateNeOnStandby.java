package com.ossnms.dcn_manager.commands.ne.internal;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.IllegalNetworkElementStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.stream.StreamSupport;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static org.slf4j.LoggerFactory.getLogger;


public class DeactivateNeOnStandby<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(DeactivateNeOnStandby.class);

    /**
     * Holds the reference to the repository of NE instances
     */
    private final NeEntityRepository neEntityRepository;

    /**
	 * Holds a reference to the object responsible for implementing the NE activation policy
	 */
	private final NetworkElementInteractionManager neActivationManager;

	/**
	 * Holds the reference to the component's event dispatcher
	 */
	private final NetworkElementNotifications neNotifications;

	/**
	 * Holds the target channel identifier.
	 */
    private final int neId;

    /**
     * Holds the reference to the component responsible for logging operator commands
     */
    private final LoggerManager<C> loggerManager;

    /**
     * Holds the reference to the repository of physical NE connection instances
     */
    private final NePhysicalConnectionRepository nePhysicalConnectionRepository;

    /**
     * Holds the reference to the channel repository
     */
    private final ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    

    /**
	 * Instantiates the command with the given parameters
	 *
	 * @param context The call context
	 * @param neId The NE identifier
	 * @param channelManagers object that holds references to all manager/publisher objects that are commonly used together when handling Channel events.
	 * @param loggerManager reference to the component responsible for logging operator commands
	 */
	public DeactivateNeOnStandby(@Nonnull C context, int neId,
            @Nonnull NetworkElementManagers networkElementManagers,
            @Nonnull ChannelManagers channelManagers,
			@Nonnull LoggerManager<C> loggerManager) {
		super(context);
        this.neId = neId;
		this.neActivationManager = networkElementManagers.getNeActivationManager();
        this.nePhysicalConnectionRepository = networkElementManagers.getNeInstanceRepository();
		this.neNotifications = networkElementManagers.getNeNotifications();
        this.loggerManager = loggerManager;
		this.neEntityRepository = networkElementManagers.getNeRepository();
		this.channelPhysicalConnectionRepository = channelManagers.getChannelInstanceConnections();
	}

	/**
	 * {@inheritDoc}
	 * @throws RepositoryException When an error occurs while working with the data source.
	 * @throws UnknownNetworkElementIdException When an activation is being requested with an invalid NE ID.
	 * @throws IllegalNetworkElementStateException If the NE is already activated.
	 */
	@Override
	public final Void call() throws UnknownNetworkElementIdException, RepositoryException, IllegalNetworkElementStateException, CommandException	{


		StreamSupport.stream(nePhysicalConnectionRepository.queryAll(neId).spliterator(), false).
    		filter(data ->  ! data.isActive() ).
    		forEach(this::shutdownPhysicalConnectionInstance);

		return null;
	}
	
    private void shutdownPhysicalConnectionInstance(NePhysicalConnectionData connection) {

    	int mediatorInstanceId;
    	 
    	try {
    	    Optional<String> networkElementName = neEntityRepository.queryNeName(neId);
        	if(! networkElementName.isPresent()) {
        	    LOGGER.warn("Transition to SHUTTING DOWN of Physical NE Connection {} was not possible. Unable to find network element id name.", connection);
                return; 
        	}
    	
        	LOGGER.debug("Deactivate NE on standby mode was called , NE ID={}, name={} ", neId, networkElementName.get() );

        
        	Optional<ChannelPhysicalConnectionData> channelPhysicalConnection = channelPhysicalConnectionRepository.query(connection.getChannelInstanceId());
        	
        	if(channelPhysicalConnection.isPresent()) {
        		mediatorInstanceId = channelPhysicalConnection.get().getMediatorInstanceId();
        	}
        	else {
        		LOGGER.warn("Transition to SHUTTING DOWN of Physical NE Connection {} was not possible. Unable to find mediator Id", connection);
        		return;
        	}
    	
            final Optional<NePhysicalConnectionMutationDescriptor> neMutation =
                new NePhysicalConnectionBehavior(connection, neNotifications)
                    .shutdown(neActivationManager,mediatorInstanceId);
            if (neMutation.isPresent()) {
                final Optional<NePhysicalConnectionData> neUpdatedConnection =
                		nePhysicalConnectionRepository.tryUpdate(neMutation.get());
                if (!neUpdatedConnection.isPresent()) {
                	LOGGER.info("Deactivation of Physical Connection of NE {} was not possible.", connection);
                }

                loggerManager.createCommandLog(getContext(), new LoggerItemNe(networkElementName.get(), "Deactivate NE on hot standby mode.", neId));
    
            } else {
            	LOGGER.info("Transition to SHUTTING DOW of Physical NE Connection {} was not possible.", connection);
            }
        } catch (final RepositoryException exception) {
            LOGGER.error("NE deactivation on {} failed: {} {}", connection,
                    exception.getMessage(), getStackTraceAsString(exception));
        }
    }
}
