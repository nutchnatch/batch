package com.ossnms.dcn_manager.commands.ne.internal;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NeConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.stream.StreamSupport;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * <p>Attempts to trigger resynchronization operations on a collection of network elements.</p>
 *
 * <p>Network elements must be active, i.e., initialized, in order to request a new synchronization (initialization).</p>
 *
 * <p>Successes and most errors are audited in the Command Log for each NE.</p>
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class ResynchronizeNetworkElements<C extends CallContext> extends Command<C, Void> {

    private final Iterable<Integer> neIdentifiers;

    private final NetworkElementNotifications notifications;
    private final NeInfoRepository infoRepository;
    private final NetworkElementInteractionManager activationManager;
    private final NeUserPreferencesRepository preferencesRepository;
    private final NePhysicalConnectionRepository neInstanceRepository;
    private final LoggerManager<C> loggerManager;
    private final ChannelPhysicalConnectionRepository channelInstanceRepository;
    private final NeEntityRepository.NeConnectionRepository connectionRepository;
    private final NeEntityRepository.NeSynchronizationRepository synchronizationRepository;

    /**
     * Creates a new instance.
     *
     * @param context Call context.
     * @param neManagers Parameter object containing all current NE management object instances.
     * @param channelInstanceRepository Repository of physical Channel instance connection information.
     * @param loggerManager Outbound audit logging connector.
     * @param neIdentifiers Collection of identifiers for all NEs that should be resynchronized.
     */
    public ResynchronizeNetworkElements(
            @Nonnull C context,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull ChannelPhysicalConnectionRepository channelInstanceRepository,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull Iterable<Integer> neIdentifiers) {
        super(context);
        this.channelInstanceRepository = channelInstanceRepository;
        this.infoRepository = neManagers.getNeRepository().getNeInfoRepository();
        this.preferencesRepository = neManagers.getNeRepository().getNeUserPreferencesRepository();
        this.connectionRepository = neManagers.getNeRepository().getNeConnectionRepository();
        this.synchronizationRepository = neManagers.getNeRepository().getNeSynchronizationRepository();
        this.notifications = neManagers.getNeNotifications();
        this.activationManager = neManagers.getNeActivationManager();
        this.neInstanceRepository = neManagers.getNeInstanceRepository();
        this.loggerManager = loggerManager;
        this.neIdentifiers = neIdentifiers;
    }

    /**
     * Attempts to trigger resynchronization operations on every NE.
     *
     * @throws RepositoryException When an error occurs while working with the database.
     * @throws CommandException If at least one NE resynchronization request has failed.
     *
     * @return Nothing.
     */
    @Override
    public Void call() throws DcnManagerException {

        boolean allRequestsOk = true;

        for (final Integer neId : neIdentifiers) {

            final boolean requestOk = triggerResynchronization(neId);
            allRequestsOk &= requestOk;

        }

        if (!allRequestsOk) {
            throw new CommandException(tr(Message.SOME_RESYNCHRONIZATIONS_FAILED));
        }

        return null;
    }

    private boolean triggerResynchronization(int neId) throws DcnManagerException {

        final Optional<NeInfoData> info = infoRepository.query(neId);
        final Optional<NeUserPreferencesData> preferences = preferencesRepository.query(neId);
        final Optional<NeConnectionData> connection = connectionRepository.query(neId);
        final Optional<NeSynchronizationData> currentCounters = synchronizationRepository.query(neId);
        if (!info.isPresent() || !preferences.isPresent() || !connection.isPresent() || !currentCounters.isPresent()) {
            audit(neId,
                    preferences.isPresent() ? preferences.get().getName() : "NE="+neId,
                    tr(Message.NE_DOES_NOT_EXIST, neId),
                    MessageSeverity.ERROR);
            return false;
        }

        final String neName = preferences.get().getName();

        clearSynchronizationCounters(currentCounters.get());

        if (!resynchronizeLogicalNe(neId, connection.get(), neName)) {
            return false;
        }

        final Optional<NePhysicalConnectionData> activePhysicalConnection =
                StreamSupport.stream(neInstanceRepository.queryAll(neId).spliterator(), false)
                        .filter(NePhysicalConnectionData::isActive)
                        .findFirst();
        if (activePhysicalConnection.isPresent()) {
            final NePhysicalConnectionData physicalConnectionData = activePhysicalConnection.get();

            final Optional<ChannelPhysicalConnectionData> channelInfo =
                    channelInstanceRepository.query(physicalConnectionData.getChannelInstanceId());
            if (!channelInfo.isPresent()) {
                loggerManager.createCommandLog(getContext(),
                        new LoggerItemChannel("CHANNEL=" + info.get().getChannelId(),
                                tr(Message.CHANNEL_DOES_NOT_EXIST, info.get().getChannelId())));
                return false;
            }

            resynchronizeInstance(physicalConnectionData, channelInfo.get().getMediatorInstanceId(), neName);
        }

        return true;
    }

    private void clearSynchronizationCounters(NeSynchronizationData currentCounters) throws RepositoryException {
        final NeSynchronizationMutationDescriptor counterChanges =
                new NeSynchronizationMutationDescriptor(currentCounters)
                        .clearCounters();
        synchronizationRepository.tryUpdate(counterChanges);
    }

    private boolean resynchronizeLogicalNe(int neId, NeConnectionData connection, String neName) throws RepositoryException {
        final Optional<NeConnectionMutationDescriptor> logicalResynchronization =
                new NeConnectionBehavior(connection, notifications).resynchronize();
        if (logicalResynchronization.isPresent()) {
            final Optional<NeConnectionData> updated = connectionRepository.tryUpdate(logicalResynchronization.get());
            if (updated.isPresent()) {
                return true;
            } else {
                audit(neId,
                        neName,
                        tr(Message.RESYNCHRONIZATION_FAILED),
                        MessageSeverity.ERROR);
            }
        } else {
            audit(neId, neName, tr(Message.NE_NOT_INITIALIZED, neName), MessageSeverity.ERROR);
        }
        return false;
    }

    private void resynchronizeInstance(NePhysicalConnectionData neInstance, int physicalMediatorId, String neName) throws RepositoryException {

        final Optional<NePhysicalConnectionMutationDescriptor> mutation =
            new NePhysicalConnectionBehavior(neInstance, notifications)
                .resynchronize(activationManager, neInstance.getChannelInstanceId(), physicalMediatorId);
        if (!mutation.isPresent()) {
            audit(neInstance.getLogicalNeId(),
                    neName,
                    tr(Message.NE_NOT_INITIALIZED, neName),
                    MessageSeverity.ERROR);
            return;
        }

        onPhysicalInstanceConnectionUpdated(neInstanceRepository.tryUpdate(mutation.get()),
                neName, neInstance.getLogicalNeId());

    }

    private void onPhysicalInstanceConnectionUpdated(Optional<NePhysicalConnectionData> updated, String neName, int neId) {
        if (!updated.isPresent()) {
            audit(neId,
                    neName,
                    tr(Message.RESYNCHRONIZATION_FAILED),
                    MessageSeverity.ERROR);
            return;
        }
        audit(neId,
                neName,
                tr(Message.RESYNCHRONIZATION_REQUESTED),
                MessageSeverity.INFO);
    }

    private void audit(int neId, String neName, String message, MessageSeverity severity) {

        loggerManager.createCommandLog(getContext(),
                new LoggerItemNe(neName, message, neId, severity));

    }

}
