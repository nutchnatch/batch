package com.ossnms.dcn_manager.commands.container.assignment;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.ContainersSystemAssignmentUpdater;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;

/**
 * Create a default Container association.
 * Must be used on creation of new System Containers without specific parent container.
 */
public class CreateDefaultSystemAssignment<C extends CallContext> extends Command<C, Void> {
    private final SystemInfo systemInfo;
    private final ContainersSystemAssignmentUpdater updater;

    public CreateDefaultSystemAssignment(@Nonnull final C context,
            @Nonnull final ContainerRepository containerRepository,
            @Nonnull final SystemRepository systemRepository,
            @Nonnull final SystemInfo systemInfo,
            @Nonnull final ContainerNotifications containerNotifications,
            @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull final SettingsRepository settingsRepository)  {
        super(context);
        this.systemInfo = systemInfo;
        this.updater = new ContainersSystemAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository, containerNotifications,
                loggerManager, context);
    }

    @Override public Void call() throws CommandException {
        try {
            updater.defaultSystemAssignment(systemInfo);
        } catch (RepositoryException e) {
            throw new CommandException(e);
        }
        return null;
    }
}
