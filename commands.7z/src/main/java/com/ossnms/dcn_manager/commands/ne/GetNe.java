package com.ossnms.dcn_manager.commands.ne;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Retrieves an existing NE from the repository.
 *
 * <img src="doc-files/getne-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getne-sequence.png
 * GetNe --> NeEntityRepository : tryFindNe(id)
 * activate NeEntityRepository
 * NeEntityRepository --> GetNe : ne
 * deactivate NeEntityRepository
 * @enduml
 */
public class GetNe<C extends CallContext> extends Command<C, Optional<NeEntity>> {

    private final NeEntityRepository repository;
    private final int id;

    /**
     * Creates a new command instance.
     *
     * @param context Call context, to be passed on to outbound interfaces.
     * @param repository NE repository instance.
     * @param neId Desired NE identifier.
     */
    public GetNe(@Nonnull C context, @Nonnull NeEntityRepository repository, int neId) {
        super(context);
        this.repository = repository;
        id = neId;
    }

    @Override
    public Optional<NeEntity> call() throws CommandException {
        try {
            return repository.queryNe(id);
        } catch (final RepositoryException e) {
            throw new CommandException(e);
        }
    }

}
