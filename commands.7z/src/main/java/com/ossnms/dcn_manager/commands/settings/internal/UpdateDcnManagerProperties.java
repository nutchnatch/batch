package com.ossnms.dcn_manager.commands.settings.internal;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemConfiguration;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettingsMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.emne.SettingsProperties;
import com.ossnms.dcn_manager.core.events.settings.NativeNeNamingSettingChangeEvent;
import com.ossnms.dcn_manager.core.outbound.GlobalSettingsNotifications;
import com.ossnms.dcn_manager.core.policies.SystemSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Processes updates to global DCN Manager settings.
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class UpdateDcnManagerProperties<C extends CallContext> extends Command<C, GlobalSettings> {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateDcnManagerProperties.class);

    private final SettingsRepository settingsRepository;
    private final GlobalSettingsNotifications notifications;
    private final Map<String, String> updatedProperties;
    private final SystemSchedulingConfiguration systemScheduling;
    private final LoggerManager<C> logger;

    public UpdateDcnManagerProperties(@Nonnull C context,
            @Nonnull SettingsRepository settingsRepository,
            @Nonnull GlobalSettingsNotifications notifications,
            @Nonnull SystemSchedulingConfiguration systemScheduling,
            @Nonnull LoggerManager<C> logger,
            @Nonnull Map<String, String> updatedProperties) {
        super(context);
        this.settingsRepository = settingsRepository;
        this.notifications = notifications;
        this.systemScheduling = systemScheduling;
        this.logger = logger;
        this.updatedProperties = updatedProperties;
    }

    /**
     * Applies the changed property values to the DCN Manager global settings.
     * @throws DataUpdateException When a concurrent update to the DCN Manager global settings is detected.
     */
    @Override
    public GlobalSettings call() throws CommandException, DataUpdateException {
        try {
            final GlobalSettingsMutationDescriptor mutation =
                new GlobalSettingsMutationDescriptor(settingsRepository.getSettings())
                    .whenApplied(in -> {
                        if (in.getShowNativeNeNaming().isPresent()) {
                            notifications.notifyChanges(new NativeNeNamingSettingChangeEvent(in.getShowNativeNeNaming().get()));
                        }
                    });

            for (final Entry<String, String> entry : updatedProperties.entrySet()) {
                SettingsProperties.setProperty(mutation, entry.getKey(), entry.getValue());
                logSettingInCommandLog(entry);
            }

            final Optional<GlobalSettings> updatedSettings = settingsRepository.tryUpdateSettings(mutation);
            if (!updatedSettings.isPresent()) {
                throw new DataUpdateException("Concurrent DCN Manager configuration update detected.");
            }

            systemScheduling.setMaxOngoingSystemJobCount(updatedSettings.get().getScaledStartupLimit());

            return updatedSettings.get();

        } catch (final InvalidMutationException | RepositoryException e) {
            LOGGER.error("Failed to update global DCN Manager properties.", e);
            throw new CommandException(e);
        }
    }

    private void logSettingInCommandLog(Entry<String, String> entry) {
        SettingsProperties.of(entry.getKey())
                .map(SettingsProperties::getDescription)
                .ifPresent(description -> logger.createCommandLog(getContext(),
                        new LoggerItemConfiguration(description, tr(Message.GLOBAL_CONFIG_UPDATED, description, entry.getValue())))
        );
    }
}
