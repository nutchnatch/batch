package com.ossnms.dcn_manager.commands.container.assignment;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.NeAssignmentOperations;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;

/**
 * Create a new NE Assignment.
 */
public class AddNeAssignment<C extends CallContext> extends Command<C, Void> {
    private final NeUserPreferencesData neInfoData;
    private final NeAssignmentData assignment;
    private final NeAssignmentOperations<C> operationsBase;

    public AddNeAssignment(
            @Nonnull final C context,
            @Nonnull final ContainerRepository containerRepository,
            @Nonnull final ContainerNotifications containerNotifications,
            @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull final NeUserPreferencesData neInfoData,
            @Nonnull final NeAssignmentData assignment) {
        super(context);
        this.neInfoData = neInfoData;
        this.assignment = assignment;

        this.operationsBase = new NeAssignmentOperations<>(containerRepository, containerNotifications,
                loggerManager, context);
    }

    @Override public Void call() throws CommandException {
        try {
            operationsBase.create(neInfoData, assignment);
        } catch (RepositoryException e) {
            throw new CommandException(e);
        }
        return null;
    }
}
