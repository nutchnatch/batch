package com.ossnms.dcn_manager.commands.container.assignment;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.ContainerValidator;
import com.ossnms.dcn_manager.composables.container.ContainersNeAssignmentUpdater;
import com.ossnms.dcn_manager.composables.container.NeAssignmentOperations;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;
import java.util.stream.StreamSupport;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Delete a NE Assignment.
 */
public class DeleteNeAssignment<C extends CallContext> extends Command<C, Void> {
    private final NeUserPreferencesData neInfoData;
    private final NeAssignmentData assignment;
    private final NeAssignmentOperations<C> operationsBase;
    private final ContainerValidator validator;
    private final ContainerRepository containerRepository;
    private final ContainersNeAssignmentUpdater<C> updater;
    private final SettingsRepository settingsRepository;
    private final LoggerManager<C> loggerManager;
    private final C context;
    public DeleteNeAssignment(
            @Nonnull final C context,
            @Nonnull final ContainerRepository containerRepository,
            @Nonnull final SystemRepository systemRepository,
            @Nonnull final ContainerNotifications containerNotifications,
            @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull final NeUserPreferencesData neInfoData,
            @Nonnull final NeAssignmentData assignment,
            @Nonnull final SettingsRepository settingsRepository) {
        super(context);
        this.neInfoData = neInfoData;
        this.assignment = assignment;
        this.containerRepository = containerRepository;
        this.settingsRepository = settingsRepository;
        this.loggerManager = loggerManager;
        this.context = context;

        this.validator = new ContainerValidator(containerRepository, systemRepository);
        this.updater = new ContainersNeAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository, containerNotifications,
                loggerManager, context);

        this.operationsBase = new NeAssignmentOperations<>(containerRepository, containerNotifications, loggerManager,
                context);
    }

    @Override public Void call() throws CommandException {
        try {
            final boolean lastNeAssignment = validator.isLastNeAssignment(assignment);

            if (lastNeAssignment) {
                defaultIsTheLastAssignment();
            } else {
                if (assignment.getAssignmentType() == AssignmentType.PRIMARY) {
                    tryReassignPrimaryContainer();
                }
                operationsBase.delete(neInfoData, assignment);
            }
        } catch (RepositoryException e) {
            throw new CommandException(e);
        }
        return null;
    }

    private void defaultIsTheLastAssignment() throws RepositoryException {
        if (!settingsRepository.getSettings().getDefaultContainerName().equals(assignment.getContainerInfo().getName())) {
            updater.defaultNeAssignment(neInfoData);
            operationsBase.delete(neInfoData, assignment);
        } else {
            loggerManager.createSystemEventLog(context,
                    new LoggerItemContainer(assignment.getContainerInfo().getName(), tr(Message.CANNOT_DELETE_DEFAULT_ASSOCIATION)));
        }
    }

    private void tryReassignPrimaryContainer() {
        final Iterable<NeAssignmentData> neAssignmentDatas = containerRepository.queryAllByNE(assignment.getNeId());

        StreamSupport.stream(neAssignmentDatas.spliterator(), false)
                .filter(a -> a.getAssignmentType() != AssignmentType.PRIMARY).findFirst().ifPresent(newPrimary -> {
            try {
                operationsBase.update(neInfoData,
                        new NeAssignmentData(newPrimary.getContainerInfo(), newPrimary.getNeId(),
                                AssignmentType.PRIMARY));
            } catch (RepositoryException e) {
                Throwables.propagate(e);
            }
        });
    }
}
