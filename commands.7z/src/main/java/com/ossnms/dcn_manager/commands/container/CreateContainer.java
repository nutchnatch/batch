package com.ossnms.dcn_manager.commands.container;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.container.ContainerCreationBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;

/**
 * Creates and stores a new Container, if the creation request is valid.
 * Otherwise an exception will be thrown.
 *
 * <img src="doc-files/createcontainercmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/createcontainercmd-sequence.png
 * CreateContainer --> ContainerRepository : create(ContainerCreateDescriptor)
 * activate ContainerRepository
 * ContainerRepository --> CreateContainer : container
 * deactivate ContainerRepository
 * CreateContainer --> ContainerNotifications : notifyCreate(container)
 * CreateContainer --> LoggerManager : createCommandLog
 * @enduml
 */
public class CreateContainer<C extends CallContext> extends Command<C, ContainerInfo> {

    private final ContainerCreationBase<C> creationBase;
    private final ContainerCreationDescriptor creationDescriptor;

    public CreateContainer(@Nonnull C context,
            @Nonnull ContainerRepository repository,
            @Nonnull SystemRepository systemRepository,
            @Nonnull ContainerNotifications notifications,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull ContainerCreationDescriptor creationDescriptor) {
        super(context);
        this.creationDescriptor = creationDescriptor;
        this.creationBase = new ContainerCreationBase<>(context, repository, systemRepository, notifications, loggerManager);
    }

    @Override
    public ContainerInfo call() throws RepositoryException, DuplicatedObjectNameException {
        return creationBase.tryCreateContainer(creationDescriptor);
    }
}
