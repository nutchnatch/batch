package com.ossnms.dcn_manager.commands.mediator;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.mediator.MediatorCreationBase;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.DuplicatedHostException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorTypeException;

/**
 * Creates and stores a new Mediator, if the creation request is valid.
 * Otherwise an exception will be thrown.
 *
 * <img src="doc-files/createmediatorcmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/createmediatorcmd-sequence.png
 * CreateMediator --> CreateMediator : validateMediatorType
 * CreateMediator --> MediatorRepository : create(MediatorCreateDescriptor)
 * activate MediatorRepository
 * MediatorRepository --> CreateMediator : mediator
 * deactivate MediatorRepository
 * CreateMediator --> MediatorNotifications : notifyCreate(mediator)
 * CreateMediator --> LoggerManager : createCommandLog
 * CreateMediator --> MediatorSchedulingConfiguration : setMaxOngoingMediatorJobCount
 * @enduml
 */
public class CreateMediator<C extends CallContext> extends Command<C, MediatorEntity> {

    private final MediatorCreationBase<C> delegate;
    private final MediatorCreateDescriptor creation;

    public CreateMediator(@Nonnull C context,
            @Nonnull MediatorManagers mediatorManagers,
            @Nonnull MediatorSchedulingConfiguration mediatorScheduling,
            @Nonnull StaticConfiguration configuration,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull MediatorCreateDescriptor creation) {
        super(context);
        this.creation = creation;
        this.delegate = new MediatorCreationBase<>(context,
                mediatorManagers.getMediatorRepository(), mediatorManagers.getMediatorInstanceRepository(), mediatorManagers.getMediatorNotifications(),
                configuration, mediatorScheduling, loggerManager);
    }

    @Override
    public MediatorEntity call() throws UnknownMediatorTypeException, CommandException, DuplicatedObjectNameException, DuplicatedHostException {
        try {
            return delegate.tryCreateMediator(creation);
        } catch (final RepositoryException e) {
            throw new CommandException("Could not create Mediator.", e);
        }
    }
}
