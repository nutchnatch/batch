package com.ossnms.dcn_manager.commands.container.assignment;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.container.ContainersSystemAssignmentUpdater;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.NonPrimaryContainerSettedException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Set;

/**
 * Update the Assignment System X Container.
 */
public class SyncSystemAssignments<C extends CallContext> extends Command<C, Void> {
    private static final int MAX_PRIMARY_CONTAINER_ALLOWED = 1;

    private final SystemInfo systemInfo;
    private final Set<SystemAssignmentData> assignments;
    private final ContainersSystemAssignmentUpdater updater;

    public SyncSystemAssignments(
            @Nonnull final C context,
            @Nonnull final ContainerRepository containerRepository,
            @Nonnull final SystemRepository systemRepository,
            @Nonnull final SystemInfo systemInfo,
            @Nonnull final Set<SystemAssignmentData> assignments,
            @Nonnull final ContainerNotifications containerNotifications,
            @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull final SettingsRepository settingsRepository) {
        super(context);
        this.systemInfo = systemInfo;
        this.assignments = assignments;
        this.updater = new ContainersSystemAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository,
                containerNotifications, loggerManager, context);
    }

    @Override public Void call() throws RepositoryException, NonPrimaryContainerSettedException {

        final long primaryContainers = assignments.stream()
                .filter(neAssignmentData -> neAssignmentData.getAssignmentType() == AssignmentType.PRIMARY).count();

        if (primaryContainers != MAX_PRIMARY_CONTAINER_ALLOWED) {
            throw new NonPrimaryContainerSettedException(
                    "The SystemContainer={} assignments must have only one Primary Container", systemInfo.getName());
        }

        updater.store(assignments, systemInfo);

        return null;
    }
}
