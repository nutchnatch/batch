package com.ossnms.dcn_manager.commands.ne;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NeCreationBase;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DataCreationException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.DuplicatedRouteException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;

import javax.annotation.Nonnull;

/**
 * Creates and stores a new NE, if the creation request is valid.
 * Otherwise an exception will be thrown.
 *
 * <img src="doc-files/createnecmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/createnecmd-sequence.png
 * CreateNetworkElement --> CreateNetworkElement : validateParentChannelIdentifier
 * activate NeEntityRepository
 * CreateNetworkElement --> NeEntityRepository : create(NeCreateDescriptor)
 * NeEntityRepository --> CreateNetworkElement : ne
 * deactivate NeEntityRepository
 * CreateNetworkElement --> NetworkElementNotifications : notifyCreate(ne)
 * CreateNetworkElement --> LoggerManager : createCommandLog
 * @enduml
 */
public class CreateNetworkElement<C extends CallContext> extends Command<C, NeEntity> {

    private final NeCreationBase<C> delegate;
    private final NeCreateDescriptor createDescriptor;

    /**
     * Creates a new command instance.
     *
     * @param context Call context, to be passed on to outbound interfaces.
     * @param neManagers NE resources.
     * @param channelRepository Channel repository instance. Used for validating the parent Channel.
     * @param systemRepository System Containers repository
     * @param createDescriptor NE creation descriptor.
     * @param logger Operations log manager.
     */
    public CreateNetworkElement(C context,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull ChannelEntityRepository channelRepository,
            @Nonnull SystemRepository systemRepository,
            @Nonnull ChannelPhysicalConnectionRepository channelInstanceRepository,
            @Nonnull LoggerManager<C> logger,
            @Nonnull NeCreateDescriptor createDescriptor) {
        super(context);
        this.createDescriptor = createDescriptor;
        this.delegate = new NeCreationBase<>(context,
                neManagers.getNeRepository(), neManagers.getNeInstanceRepository(), neManagers.getNeNotifications(),
                channelRepository, systemRepository, channelInstanceRepository, logger);
    }

    @Override
    public NeEntity call() throws CommandException, UnknownChannelIdException, DuplicatedRouteException, DuplicatedObjectNameException {
        try {
            return delegate.tryCreateNe(createDescriptor);
        } catch (final DataCreationException | RepositoryException e) {
            throw new CommandException("Could not create NE.", e);
        }
    }
}
