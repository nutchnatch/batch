package com.ossnms.dcn_manager.commands.container;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.INFO;
import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.WARNING;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.Optional.empty;

public class MoveContainersToContainer<C extends CallContext> extends Command<C, Void> {
    private static final Logger LOGGER = LoggerFactory.getLogger(MoveContainersToContainer.class);

    private final Collection<IGenericContainerId> containers;
    private final ContainerRepository containerRepository;
    private final ContainerNotifications containerNotifications;
    @Nonnull private final LoggerManager<C> loggerManager;
    private final IGenericContainerId containerId;

    public MoveContainersToContainer(@Nonnull final C context,
                                     @Nonnull final ContainerRepository containerRepository,
                                     @Nonnull final Collection<IGenericContainerId> containers,
                                     @Nonnull final IGenericContainerId containerId,
                                     @Nonnull final ContainerNotifications containerNotifications,
                                     @Nonnull final LoggerManager<C> loggerManager) {
        super(context);
        this.containers = containers;
        this.containerId = containerId;
        this.containerRepository = containerRepository;
        this.containerNotifications = containerNotifications;
        this.loggerManager = loggerManager;
    }

    @Override public Void call() throws CommandException {
        for (IGenericContainerId id : containers) {
            fetchContainer(id)
                    .map(container -> associateWithContainer(container, containerId));
        }
        return null;
    }

    private Boolean associateWithContainer(ContainerInfo container, IGenericContainerId containerId) {
        ContainerInfoMutationDescriptor mutationDescriptor = new ContainerInfoMutationDescriptor(container)
                .setParentId(containerId.getId())
                .whenApplied(descriptor -> {
                    containerNotifications.notifyChanges(descriptor);
                    loggerManager.createCommandLog(getContext(),
                            new LoggerItemContainer(descriptor.getResult().getName(), tr(Message.CONTAINER_CHANGED), INFO));
                });

        return updateContainer(mutationDescriptor).isPresent();
    }

    private Optional<ContainerInfo> updateContainer(ContainerInfoMutationDescriptor descriptor) {
        try {
            return containerRepository.tryUpdate(descriptor);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to perform update of {}", descriptor, e);
            loggerManager.createCommandLog(getContext(),
                    new LoggerItemContainer(descriptor.getResult().getName(), tr(Message.CONTAINER_CHANGE_FAILED), WARNING));
            return empty();
        }
    }


    private Optional<ContainerInfo> fetchContainer(IGenericContainerId containerId) {
        try {
            return containerRepository.query(containerId.getId());
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch container {}", containerId, e);
            return empty();
        }
    }

}
