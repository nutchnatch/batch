package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.configuration.AppProperties;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.metrics.NeInitializationMetrics;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.NeInformationRetrieval;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.*;
import com.ossnms.dcn_manager.core.events.ne.*;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.*;
import com.ossnms.dcn_manager.core.outbound.Alarms;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.EventDispatcher;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import javax.annotation.Nonnull;

/**
 * Subscribes to an inbound event stream, dispatching each event to its appropriate handler.
 *
 * @param <C> Context instance type, propagated to handlers that need one.
 */
public class NeDispatcher<C extends CallContext> extends EventDispatcher<C> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeDispatcher.class);

    private final NeInformationRetrieval neInformationRetrieval;
    private final Alarms alarms;

    private final DomainRepository domainRepository;

    private final DomainNotifications domainNotifications;

    private final SettingsRepository settingsRepository;

    private final SystemRepository systemRepository;

    private final ChannelEntityRepository channelRepository;

    private final NetworkElementManagers networkElementManagers;
    private final ChannelPhysicalConnectionRepository channelInstancesRepository;

    private final AppProperties appProperties;
    private final NeConnectionManager neConnectionManager;
    private final NeInitializationMetrics metrics;

    public NeDispatcher(
            @Nonnull C context,
            @Nonnull StaticConfiguration configuration,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull NetworkElementManagers networkElementManagers,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull NeInformationRetrieval neInformationRetrieval,
            @Nonnull DomainManagers domainManagers,
            @Nonnull SettingsRepository settingsRepository,
            @Nonnull SystemRepository systemRepository,
            @Nonnull Alarms alarms,
            @Nonnull AppProperties appProperties,
            @Nonnull NeConnectionManager neConnectionManager,
            @Nonnull NeInitializationMetrics metrics) {
        super(context, configuration, loggerManager);
        this.networkElementManagers = networkElementManagers;
        this.appProperties = appProperties;
        this.channelRepository = channelManagers.getChannelRepository();
        this.channelInstancesRepository = channelManagers.getChannelInstanceConnections();
        this.domainRepository = domainManagers.getDomainRepository();
        this.domainNotifications = domainManagers.getDomainNotifications();
        this.settingsRepository = settingsRepository;
        this.systemRepository = systemRepository;
        this.alarms = alarms;
        this.neInformationRetrieval = neInformationRetrieval;
        this.neConnectionManager = neConnectionManager;
        this.metrics = metrics;
    }

    @Override
    public final void initialize(Observable<? extends Event> eventSource) {

        LOGGER.debug("Initializing NE event dispatcher.");

        // *** status events affecting the physical instances

        subscribeToPhysicalStatusEvents(eventSource);

        // *** status events affecting the logical instance

        subscribeToLogicalStatusEvents(eventSource);

        // *** operational events, relevant only to the logical instance

        subscribeToOperationalEvents(eventSource);
    }

    private void subscribeToOperationalEvents(Observable<? extends Event> eventSource) {
        subscribe(eventSource, NePropertiesChangedEvent.class,
                new UpdateNePropertiesEventHandler<>(getContext(), networkElementManagers,
                    getConfiguration(), getLoggerManager(),
                    domainRepository, domainNotifications, systemRepository, settingsRepository));

        subscribe(eventSource, NeOperationInfoChangedEvent.class,
                new UpdateNeOperationInfoEventHandler<>(getContext(), networkElementManagers.getNeRepository(),
                    networkElementManagers.getNeNotifications(), appProperties, neConnectionManager, 
                        networkElementManagers.getNeInstanceRepository()));

        subscribe(eventSource, NeTypeChangedEvent.class,
                new UpdateNeTypeEventHandler<>(getContext(), networkElementManagers.getNeRepository(),
                    networkElementManagers.getNeNotifications(), getConfiguration()));

        subscribe(eventSource, NePhysicalSynchronizationCountersChangedEvent.class,
                new NePhysicalSynchronizationCountersChangedEventHandler<>(getContext(), networkElementManagers.getNeRepository()));

        subscribe(eventSource, NeInfoDataChangedEvent.class,
                new UpdateNeInfoDataEventHandler<>(getContext(), networkElementManagers.getNeRepository(),
                        networkElementManagers.getNeNotifications()));
    }

    private void subscribeToLogicalStatusEvents(Observable<? extends Event> eventSource) {
        subscribe(eventSource, NeActivationFailedEvent.class,
                new NeActivationFailedEventHandler<>(getContext(), networkElementManagers.getNeRepository(),
                    networkElementManagers.getNeNotifications(), alarms));

        subscribe(eventSource, NeConnectingEvent.class,
                new NeConnectingEventHandler<>(getContext(), networkElementManagers.getNeRepository(),
                    networkElementManagers.getNeNotifications()));

        subscribe(eventSource, NeDisconnectingEvent.class,
                new NeDisconnectingEventHandler<>(getContext(), networkElementManagers.getNeRepository(),
                    networkElementManagers.getNeNotifications()));

        subscribe(eventSource, NeInitializingEvent.class,
                new NeInitializingEventHandler<>(getContext(), networkElementManagers.getNeRepository(),
                    networkElementManagers.getNeNotifications()));

        subscribe(eventSource, NeDisconnectedEvent.class,
                new NeDisconnectedEventHandler<>(getContext(), networkElementManagers.getNeRepository(),
                    networkElementManagers.getNeNotifications(), alarms));

        subscribe(eventSource, NeConnectedEvent.class,
                new NeConnectedEventHandler<>(getContext(), networkElementManagers.getNeRepository(), channelRepository,
                    networkElementManagers.getNeNotifications(), neInformationRetrieval, alarms));

        subscribe(eventSource, NeInitializedEvent.class,
                new NeInitializedEventHandler<>(getContext(), networkElementManagers.getNeRepository(),
                    networkElementManagers.getNeNotifications(), neInformationRetrieval, alarms));
    }

    private void subscribeToPhysicalStatusEvents(Observable<? extends Event> eventSource) {
        subscribe(eventSource, PhysicalNeActivationFailedEvent.class,
                new PhysicalNeActivationFailedEventHandler<>(getContext(), networkElementManagers));

        subscribe(eventSource, PhysicalNeSynchronizationLostEvent.class,
                new PhysicalNeSynchronizationLostEventHandler<>(getContext(), networkElementManagers, channelInstancesRepository));

        subscribe(eventSource, PhysicalNeConnectingEvent.class,
                new PhysicalNeConnectingEventHandler<>(getContext(), networkElementManagers));

        subscribe(eventSource, PhysicalNeDisconnectingEvent.class,
                new PhysicalNeDisconnectingEventHandler<>(getContext(), networkElementManagers));

        subscribe(eventSource, PhysicalNeInitializingEvent.class,
                new PhysicalNeInitializingEventHandler<>(getContext(), networkElementManagers));

        subscribe(eventSource, PhysicalNeDisconnectedEvent.class,
                new PhysicalNeDisconnectedEventHandler<>(getContext(), networkElementManagers, channelInstancesRepository));

        subscribe(eventSource, PhysicalNeConnectedEvent.class,
                new PhysicalNeConnectedEventHandler<>(getContext(), networkElementManagers, channelInstancesRepository));

        subscribe(eventSource, PhysicalNeInitializedEvent.class,
                new PhysicalNeInitializedEventHandler<>(getContext(), networkElementManagers, channelInstancesRepository, metrics));

        subscribe(eventSource, PhysicalNeRestartRequestEvent.class,
                new PhysicalNeRestartRequestEventHandler<>(getContext(), networkElementManagers, channelInstancesRepository));
    }

}
