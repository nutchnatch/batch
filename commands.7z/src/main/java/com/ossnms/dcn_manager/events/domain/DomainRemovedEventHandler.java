package com.ossnms.dcn_manager.events.domain;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NeDomainsUpdater;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.events.domain.DomainRemoved;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;

import javax.annotation.Nonnull;
import java.util.Set;

import static com.google.common.collect.Iterables.transform;
import static com.google.common.collect.Sets.newHashSet;

/**
 * Processes events related to removals of existing network domains from the DCN.
 */
class DomainRemovedEventHandler<C extends CallContext> extends EventHandler<C, DomainRemoved> {

    private final DomainManagers domainManagers;
    private final SettingsRepository settings;

    DomainRemovedEventHandler(
            @Nonnull C context, @Nonnull DomainManagers domainManagers,
            @Nonnull SettingsRepository settings) {
        super(context);
        this.domainManagers = domainManagers;
        this.settings = settings;
    }

    @Override
    protected void handleEvent(@Nonnull DomainRemoved event) throws DcnManagerException {

        final DomainRepository repository = domainManagers.getDomainRepository();

        final Set<String> naturalDomainsSet = newHashSet(
            transform(repository.queryNaturalDomainsForNE(event.getNeId()), DomainInfoData::getName)
        );
        final boolean domainExisted = naturalDomainsSet.remove(event.getOldDomainName());

        if (domainExisted) {
            new NeDomainsUpdater(repository, domainManagers.getDomainNotifications(), settings)
                    .storeNaturalDomains(event.getNeId(), naturalDomainsSet);
        }
    }
}
