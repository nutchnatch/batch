package com.ossnms.dcn_manager.events.discovery;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.MessageFormatter;
import rx.functions.Func1;

abstract class DiscoveryFilterBase<C extends CallContext, T> implements Func1<T, Boolean> {

    private static final Logger LOGGER = LoggerFactory.getLogger(DiscoveryFilterBase.class);

    private final C context;
    private final LoggerManager<C> logManager;

    protected DiscoveryFilterBase(C context, LoggerManager<C> logManager) {
        this.context = context;
        this.logManager = logManager;
    }

    protected void reportWarning(NeDiscoveredEvent event, String message, Object... parameters) {
        final String fullMessage = MessageFormatter.arrayFormat(message, parameters).getMessage();
        LOGGER.warn(fullMessage);
        logManager.createNetworkResourceLog(context,
            new LoggerItemNe(event.getNameReceived().orElse(""), fullMessage, event.getIdReceived(), MessageSeverity.WARNING));
    }

}