package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializingEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializingEvent;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Handles events requesting a physical NE connection to switch to the INITIALIZING state.
 */
public class PhysicalNeInitializingEventHandler<C extends CallContext> extends
        PhysicalNeStatusEventHandlerBase<C, PhysicalNeInitializingEvent, NeInitializingEvent> {

    public PhysicalNeInitializingEventHandler(@Nonnull C context,
            @Nonnull NetworkElementManagers neManagers) {
        super(context, neManagers);
    }

    @Override
    protected Optional<NePhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalNeInitializingEvent event, NePhysicalConnectionBehavior state,
            NetworkElementManagers neManagers) {
        return state.setInitializing();
    }

    @Override
    protected NeInitializingEvent produceForwardingEvent(PhysicalNeInitializingEvent event,
            NePhysicalConnectionData neConnectionState) {
        return new NeInitializingEvent(event.getLogicalNeId(), event);
    }

}
