package com.ossnms.dcn_manager.events.base;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;

/**
 * Parameter object that holds references to all manager/publisher objects
 * that are commonly used together when handling Channel events.
 */
public final class ChannelManagers {

    private final ChannelEntityRepository channelRepository;
    private final ChannelNotifications channelNotifications;
    private final ChannelInteractionManager channelActivationManager;
    private final ChannelPhysicalConnectionRepository channelInstanceConnections;
    private final MessageSource<ChannelEvent> channelEvents;

    /**
     * Creates a new object.
     * @param channelRepository Channel repository.
     * @param channelInstanceConnections Repository of channel instance connection information.
     * @param channelNotifications Channel notification publisher.
     * @param channelActivationManager Channel interaction manager.
     */
    public ChannelManagers(
            @Nonnull ChannelEntityRepository channelRepository,
            @Nonnull ChannelPhysicalConnectionRepository channelInstanceConnections,
            @Nonnull ChannelNotifications channelNotifications,
            @Nonnull ChannelInteractionManager channelActivationManager,
            @Nonnull MessageSource<ChannelEvent> channelEvents) {
        this.channelRepository = channelRepository;
        this.channelInstanceConnections = channelInstanceConnections;
        this.channelNotifications = channelNotifications;
        this.channelActivationManager = channelActivationManager;
        this.channelEvents = channelEvents;
    }

    /**
     * @return The Channel repository.
     */
    public ChannelEntityRepository getChannelRepository() {
        return channelRepository;
    }

    /**
     * @return The repository of Channel instance connection information.
     */
    public ChannelPhysicalConnectionRepository getChannelInstanceConnections() {
        return channelInstanceConnections;
    }

    /**
     * @return The Channel notification publisher.
     */
    public ChannelNotifications getChannelNotifications() {
        return channelNotifications;
    }

    /**
     * @return The Channel interaction manager.
     */
    public ChannelInteractionManager getChannelActivationManager() {
        return channelActivationManager;
    }

    /**
     * @return Internal Channel event injection point.
     *  Should be used to queue events for internal processing. These
     *  events represent internal message passing or external stimuli.
     */
    public MessageSource<ChannelEvent> getChannelEvents() {
        return channelEvents;
    }

}
