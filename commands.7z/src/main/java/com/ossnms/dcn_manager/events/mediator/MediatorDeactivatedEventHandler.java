package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.mediator.MediatorModificationBase;
import com.ossnms.dcn_manager.core.entities.mediator.behavior.MediatorConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

public class MediatorDeactivatedEventHandler<C extends CallContext> extends
        EventHandler<C, MediatorDeactivatedEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(MediatorDeactivatedEventHandler.class);

    private final MediatorModificationBase base;
    private final MediatorNotifications notifications;

    public MediatorDeactivatedEventHandler(@Nonnull C context,
            @Nonnull MediatorManagers mediatorManagers) {
        super(context);
        this.notifications = mediatorManagers.getMediatorNotifications();
        this.base = new MediatorModificationBase(mediatorManagers.getMediatorRepository());
    }

    @Override
    protected void handleEvent(MediatorDeactivatedEvent event) throws DcnManagerException {
        final MediatorConnectionData mediatorConnectionState = base.findMediatorConnectionState(event.getMediatorId());
        final MediatorConnectionBehavior state = new MediatorConnectionBehavior(mediatorConnectionState);
        final Optional<MediatorConnectionMutationDescriptor> stateMutation =
                state.setInactive(notifications);
        if (stateMutation.isPresent()) { // state changes to the same state are no-ops
            base.getMediatorRepository().getMediatorConnectionRepository().tryUpdate(stateMutation.get());
        } else {
            LOGGER.warn("Dropping event because Mediator {} is already in state {}.",
                    mediatorConnectionState.getId(), mediatorConnectionState.getActualActivationState());
        }
    }

}
