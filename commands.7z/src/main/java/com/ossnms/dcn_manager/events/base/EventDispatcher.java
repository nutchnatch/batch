package com.ossnms.dcn_manager.events.base;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.events.Event;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;
import rx.Subscription;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>Subscribes to an inbound event stream, dispatching each event to its appropriate handler.</p>
 *
 * <p>It is necessary to ensure that subscriptions by derived classes are called in order.
 * Some threading configurations on the upstream Observable will cause its Subscriptions to be called
 * in parallel. Therefore, in order to ensure independence from the configuration of the upstream
 * Observable, the dispatcher creates only one Subscription on the Observable. This Subscription
 * handler will then call the derived classes handlers according to their event types.</p>
 *
 * <p>The dispatcher allows multiple initializations against different event sources.</p>
 *
 * @param <C> Context instance type, propagated to handlers that need one.
 */
public abstract class EventDispatcher<C extends CallContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(EventDispatcher.class);

    private final C context;
    private final StaticConfiguration configuration;
    private final LoggerManager<C> loggerManager;
    private final Map<Class<?>, EventHandler<C, Event>> eventHandlers;
    private final Map<Observable<? extends Event>, Subscription> subscriptions;

    public EventDispatcher(@Nonnull C context,
            @Nonnull StaticConfiguration configuration,
            @Nonnull LoggerManager<C> loggerManager) {
        this.context = context;
        this.configuration = configuration;
        this.loggerManager = loggerManager;
        this.eventHandlers = new ConcurrentHashMap<>();
        this.subscriptions = new ConcurrentHashMap<>();
    }

    /**
     * Initializes this dispatcher against an Observable. The dispatcher will create
     * only one Subscription on this Observable, which will handle one or more event
     * types.
     *
     * @param eventSource Upstream event source.
     */
    public abstract void initialize(Observable<? extends Event> eventSource);

    protected C getContext() {
        return context;
    }

    protected StaticConfiguration getConfiguration() {
        return configuration;
    }

    protected LoggerManager<C> getLoggerManager() {
        return loggerManager;
    }

    /**
     * Subscribes a handler of events of a specific class. Re-subscribes automatically on errors.
     * Logs any errors found during event processing.
     *
     * @param source Event source.
     * @param ofType Desired event type.
     * @param handler Event handler.
     */
    @SuppressWarnings("unchecked")
    protected final <T extends Event>
    void subscribe(Observable<? extends Event> source, Class<T> ofType, EventHandler<C, T> handler) {

        eventHandlers.putIfAbsent(ofType, (EventHandler<C, Event>) handler);

        subscriptions.computeIfAbsent(source, this::createNewSubscription);

    }

    private Subscription createNewSubscription(Observable<? extends Event> newSource) {
        return newSource
            .retry(this::shouldRetry)
            .subscribe(this::subscriber);
    }

    private void subscriber(Event e) {
        final EventHandler<C, Event> eventHandler = eventHandlers.get(e.getClass());
        if (null != eventHandler) {
            eventHandler.call(e);
        }
    }

    protected boolean shouldRetry(int retryCount, Throwable t) {
        LOGGER.error("An error has occurred whilst dispatching events.", t);
        return true;
    }

}
