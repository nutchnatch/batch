package com.ossnms.dcn_manager.events.domain;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.domain.DomainRenamed;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Objects;
import java.util.Optional;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * Processes events related to changes of existing network domain names.
 */
class DomainRenamedEventHandler<C extends CallContext> extends EventHandler<C, DomainRenamed> {

    private static final Logger LOGGER = getLogger(DomainRenamedEventHandler.class);

    private final DomainManagers domainManagers;
    private final NeGatewayRoutesRepository routesRepository;

    DomainRenamedEventHandler(
            @Nonnull C context, @Nonnull DomainManagers domainManagers,
            @Nonnull NeGatewayRoutesRepository routesRepository) {
        super(context);
        this.domainManagers = domainManagers;
        this.routesRepository = routesRepository;
    }

    @Override
    protected void handleEvent(@Nonnull DomainRenamed event) throws DcnManagerException {

        final DomainRepository repository = domainManagers.getDomainRepository();
        final DomainNotifications notifications = domainManagers.getDomainNotifications();

        final Optional<DomainInfoMutationDescriptor> mutation =
                repository.query(event.getDomainId())
                        .map(DomainInfoMutationDescriptor::new)
                        .map(m -> m.setName(event.getNewName()))
                        .map(m -> m.whenApplied(in -> {
                            renameDomainInRoutes(in.getTarget().getName(), event.getNewName());
                            notifications.notifyChanges(event);
                        }));
        if (mutation.isPresent()) {
            final DomainInfoMutationDescriptor descriptor = mutation.get();
            if (!Objects.equals(descriptor.getName().orElse(null), descriptor.getTarget().getName())) {
                final Optional<DomainInfoData> updated = repository.tryUpdate(descriptor);
                if (!updated.isPresent()) {
                    LOGGER.warn("Could not rename domain {} to {}: concurrent modification!", event.getDomainId(), event.getNewName());
                }
            } else {
                LOGGER.info("Not renaming domain {} to {}: same name.", descriptor.getTarget().getName(), event.getNewName());
            }
        } else {
            LOGGER.warn("Could not rename domain {} to {}: not found!", event.getDomainId(), event.getNewName());
        }
    }

    private void renameDomainInRoutes(String oldName, String newName) {
        try {
            routesRepository.renameRouteDomains(oldName, newName);
        } catch (RepositoryException e) {
            LOGGER.error("Could not rename existing domains in routes from {} to {}", oldName, newName);
        }
    }
}
