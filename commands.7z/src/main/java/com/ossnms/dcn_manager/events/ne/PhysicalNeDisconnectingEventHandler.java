package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectingEvent;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Handles events requesting a physical NE connection to switch to the DISCONNECTING state.
 */
public class PhysicalNeDisconnectingEventHandler<C extends CallContext> extends
        PhysicalNeStatusEventHandlerBase<C, PhysicalNeDisconnectingEvent, NeDisconnectingEvent> {

    public PhysicalNeDisconnectingEventHandler(@Nonnull C context,
            @Nonnull NetworkElementManagers neManagers) {
        super(context, neManagers);
    }

    @Override
    protected Optional<NePhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalNeDisconnectingEvent event, NePhysicalConnectionBehavior state,
            NetworkElementManagers neManagers) {
        return state.setDisconnecting(neManagers.getNeActivationManager());
    }

    /**
     * Allow mediations to request a transition from Initialized or connected to Disconnecting.
     * As per TNMSCM-8254, this transition is valid in cases of GNE switch back.
     * DCN manager needs to be able to cope with this transition outside the scope of connection shutdown by the user.
     * <b>It will consider these as service interruptions (failures).</b>
     */
    @Override
    protected NeEvent produceForwardingEvent(
            PhysicalNeDisconnectingEvent event, NePhysicalConnectionData originalConnectionState) {
        final ActualActivationState originalState = originalConnectionState.getActualActivationState();
        return originalState == ActualActivationState.CONNECTED || originalState == ActualActivationState.INITIALIZED
                ? new ActualNeStateEvent.NeActivationFailedEvent(event.getLogicalNeId(), event, event.getDetailedDescription())
                : new NeDisconnectingEvent(event.getLogicalNeId(), event);
    }

}
