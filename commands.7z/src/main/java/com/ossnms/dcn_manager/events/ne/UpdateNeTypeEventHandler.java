package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NeTypeChangedEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.utils.Consumer;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownNeTypeException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Handles events requesting the NE Type to be updated for a specific NE.
 *
 * @param <C>
 */
public class UpdateNeTypeEventHandler<C extends CallContext> extends
        EventHandler<C, NeTypeChangedEvent> {

    private final NeInfoRepository neRepository;
    private final NetworkElementNotifications notifications;
    private final StaticConfiguration configuration;

    /**
     * Creates a new object.
     *
     * @param context Call context.
     * @param neRepository Network element entity repository.
     * @param notifications Network element notification publisher.
     * @param configuration Static configuration.
     */
    public UpdateNeTypeEventHandler(C context,
            @Nonnull NeEntityRepository neRepository,
            @Nonnull NetworkElementNotifications notifications,
            @Nonnull StaticConfiguration configuration) {
        super(context);
        this.neRepository = neRepository.getNeInfoRepository();
        this.notifications = notifications;
        this.configuration = configuration;
    }

    @Override
    protected void handleEvent(NeTypeChangedEvent event)
            throws UnknownNeTypeException, UnknownNetworkElementIdException, DataUpdateException {

        final NeType neType = configuration.getNeTypes().get(event.getNewNeTypeName());
        if (null == neType) {
            throw new UnknownNeTypeException("Unknown type '{}'", event.getNewNeTypeName());
        }

        try {

            final Optional<NeInfoData> foundNe = neRepository.query(event.getNeId());
            if (!foundNe.isPresent()) {
                throw new UnknownNetworkElementIdException("Unknown NE ID {}", event.getNeId());
            }

            updateNeType(neType, foundNe);

        } catch (final RepositoryException exception) {
            throw new DataUpdateException(exception);
        }
    }

    private void updateNeType(final NeType neType, final Optional<NeInfoData> foundNe)
            throws DataUpdateException, RepositoryException {
        final NeInfoMutationDescriptor mutation = new NeInfoMutationDescriptor(foundNe.get())
            .setProxyType(neType.getName())
            .whenApplied(new Consumer<NeInfoMutationDescriptor>() {
                @Override
                public void accept(NeInfoMutationDescriptor in) {
                    notifications.notifyChanges(in);
                }
            });
        if (!neRepository.tryUpdate(mutation).isPresent()) {
            throw new DataUpdateException("Could not update NE Info to {}", mutation);
        }
    }

}
