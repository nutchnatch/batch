package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NeConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeConnectionRepository;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Base class for NE Actual Connection event handlers.
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 * @param <T> The specific type of the NE event being processed.
 */
abstract class NeConnectionEventHandlerBase<C extends CallContext, T extends NeEvent>
        extends EventHandler<C, T> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeConnectionEventHandlerBase.class);

    private final NeConnectionRepository repository;
    private final NetworkElementNotifications notifications;

    protected NeConnectionEventHandlerBase(@Nonnull C context,
            @Nonnull NeEntityRepository repository,
            @Nonnull NetworkElementNotifications notifications) {
        super(context);
        this.repository = repository.getNeConnectionRepository();
        this.notifications = notifications;
    }

    @Override
    protected final void handleEvent(T event) throws DcnManagerException {

        final Optional<NeConnectionData> connection = repository.query(event.getNeId());
        if (connection.isPresent()) {
            final NeConnectionBehavior behavior = new NeConnectionBehavior(connection.get(), notifications);
            final Optional<NeConnectionMutationDescriptor> mutation =
                triggerMutation(behavior, event);
            if (mutation.isPresent()) {
                final Optional<NeConnectionData> updatedConnection = repository.tryUpdate(mutation.get());
                if (!updatedConnection.isPresent()) {
                    LOGGER.warn("Failed to update connection state for NE {}! Concurrent modification? Mutation was {}.", event.getNeId(), mutation.get());
                }
            } else {
                LOGGER.warn("Dropping {} because NE {} is already in state {}.", event, event.getNeId(), connection.get().getActivationState());
            }
        } else {
            LOGGER.warn("Dropping {} for non existant NE {}.", event, event.getNeId());
        }

    }

    /**
     * Executes the behavior method that triggers a mutation corresponding to the actual
     * event type being handled.
     * @param behavior An instance of {@link NeConnectionBehavior}.
     * @return A present {@link NeConnectionMutationDescriptor} if the change is to be applied.
     */
    protected abstract Optional<NeConnectionMutationDescriptor> triggerMutation(NeConnectionBehavior behavior, T event);

}
