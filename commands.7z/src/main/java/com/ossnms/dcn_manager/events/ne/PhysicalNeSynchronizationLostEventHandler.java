package com.ossnms.dcn_manager.events.ne;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializingEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeSynchronizationLostEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Reacts to a report that the mediator has lost data synchronization against the NE
 * and is therefore likely to be out of date.
 *
 * Will attempt to schedule an automatic NE data resynchronization.
 */
public class PhysicalNeSynchronizationLostEventHandler<C extends CallContext> extends
        PhysicalNeStatusEventHandlerBase<C, PhysicalNeSynchronizationLostEvent, NeInitializingEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(PhysicalNeSynchronizationLostEventHandler.class);

    private final ChannelPhysicalConnectionRepository channelInstances;

    public PhysicalNeSynchronizationLostEventHandler(
            @Nonnull C context, @Nonnull NetworkElementManagers neManagers,
            @Nonnull ChannelPhysicalConnectionRepository channelInstances) {
        super(context, neManagers);
        this.channelInstances = channelInstances;
    }

    @Override
    protected Optional<NePhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalNeSynchronizationLostEvent event, NePhysicalConnectionBehavior state,
            NetworkElementManagers neManagers) {
        try {
            final ChannelPhysicalConnectionData channelInstance =
                    findChannelInstance(channelInstances, neManagers.getNeInstanceRepository(), event.getNeId());
            // When there are counters present on the event and there is at least one that is equal to the last received one then init mode is set delta init.
            final boolean useDeltaInitMode =
                    event.getSynchronizationCounters()
                        .flatMap(this::calculateDifferencesOfCounters)
                        .map(this::atLeastOneEqualCounter)
                        .orElse(false);
            
            return state.resynchronize(neManagers.getNeActivationManager(), channelInstance.getId(), channelInstance.getMediatorInstanceId())
                    .map(m -> m.setActivationMode(useDeltaInitMode ? ActualActivationMode.CONNECT_RECOVER : ActualActivationMode.STANDARD));

        } catch (RepositoryException | UnknownNetworkElementIdException | UnknownChannelIdException e) {
            LOGGER.error("Failed to process physical NE synchronization lost event {}: {}", event, Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    private boolean atLeastOneEqualCounter(NeSynchronizationData neSynchronizationDifferences) {
        return ! neSynchronizationDifferences.getAll().isPresent() ||
                ! neSynchronizationDifferences.getAlarms().isPresent() ||
                ! neSynchronizationDifferences.getPacket().isPresent();
    }
    
    @Override
    protected NeInitializingEvent produceForwardingEvent(
            PhysicalNeSynchronizationLostEvent event, NePhysicalConnectionData neConnectionState) {
        return new NeInitializingEvent(event.getLogicalNeId(), event, event.getDetailedDescription());
    }

}
