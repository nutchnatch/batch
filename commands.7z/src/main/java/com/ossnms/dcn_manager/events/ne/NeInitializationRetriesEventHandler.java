package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.QNePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.periodic.PeriodicEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.time.Duration;
import java.time.Instant;
import java.util.Optional;
import java.util.stream.Stream;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Requests resynchronisation for NEs in FAILED state and INIT_RECOVER activation mode.
 */
public class NeInitializationRetriesEventHandler <C extends CallContext>
        extends EventHandler<C, PeriodicEvent> {

    private static final Logger LOGGER = getLogger(NeInitializationRetriesEventHandler.class);

    private final NePhysicalConnectionRepository neInstanceRepository;
    private final NetworkElementNotifications notifications;
    private final NetworkElementInteractionManager activationManager;
    private final ChannelPhysicalConnectionRepository channelInstanceConnections;
    private final SettingsRepository settingsRepository;

    /**
     * Constructs a new instance.
     */
    public NeInitializationRetriesEventHandler(
            @Nonnull C context,
            @Nonnull NetworkElementManagers networkElementManagers,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull SettingsRepository settingsRepository) {
        super(context);
        this.settingsRepository = settingsRepository;
        this.neInstanceRepository = networkElementManagers.getNeInstanceRepository();
        this.notifications = networkElementManagers.getNeNotifications();
        this.activationManager = networkElementManagers.getNeActivationManager();
        this.channelInstanceConnections = channelManagers.getChannelInstanceConnections();
    }

    @Override
    protected void handleEvent(@Nonnull PeriodicEvent event) throws DcnManagerException {

        queryInitializationFailedNEs()
                .filter(this::retriesNotExpired)
                .filter(this::retryTimeoutElapsed)
                .forEach(this::requestResynchronisation);

    }

    private Stream<NePhysicalConnectionData> queryInitializationFailedNEs() {
        final QNePhysicalConnectionData conn = QNePhysicalConnectionData.nePhysicalConnectionData;
        return neInstanceRepository.query(conn)
                .where(conn.activationState.eq(ActualActivationState.FAILED)
                        .and(conn.activationMode.eq(ActualActivationMode.INIT_RECOVER)))
                .list(conn)
                .stream();
    }

    private boolean retriesNotExpired(NePhysicalConnectionData connectionData) {
        final int neRetries = settingsRepository.getSettings().getNeRetries();
        return 0 == neRetries || connectionData.getRetryCounter() < neRetries;
    }

    private boolean retryTimeoutElapsed(NePhysicalConnectionData conn) {
        final long minutesElapsed =
                conn.getInitStageStartTime().map(instant -> Duration.between(instant, Instant.now()).toMinutes()).orElse(0L);
        return minutesElapsed >= settingsRepository.getSettings().getRetryInterval();
    }

    private void requestResynchronisation(NePhysicalConnectionData connectionData) {

        LOGGER.info("Requesting automatic reactivation of NE id {}", connectionData.getId());

        try {
            final Optional<ChannelPhysicalConnectionData> channelConnection =
                    channelInstanceConnections.query(connectionData.getChannelInstanceId());
            if (isChannelActive(channelConnection)) {
                final Optional<NePhysicalConnectionMutationDescriptor> connectionMutation =
                    new NePhysicalConnectionBehavior(connectionData, notifications)
                        .startUp(
                            activationManager,
                            channelConnection.map(ChannelPhysicalConnectionData::getMediatorInstanceId).get());
                if (connectionMutation.isPresent()) {
                    final Optional<NePhysicalConnectionData> updatedConnection =
                            neInstanceRepository.tryUpdate(
                                connectionMutation.get().setRetryCounter(connectionData.getRetryCounter() + 1));
                    if (!updatedConnection.isPresent()) {
                        LOGGER.warn("Unable to request reactivation of NE id {}: concurrent modification.",
                                connectionData.getId());
                    }
                } else {
                    LOGGER.warn("Unable to request reactivaton of NE id {}: invalid operation in current state.",
                            connectionData.getId());
                }
            } else {
                LOGGER.warn("Could not find physical channel for NE id{}", connectionData.getId());
            }
        } catch (RepositoryException e) {
            LOGGER.error("Unable to request reactivation of NE id {}: {}",
                    connectionData.getId(), getStackTraceAsString(e));
        }
    }

    private boolean isChannelActive(Optional<ChannelPhysicalConnectionData> channelConnection) {
        return channelConnection.map(c -> c.getActualActivationState() == com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE).orElse(false);
    }
}
