package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.channel.UpdateChannelPropertiesBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.events.channel.ChannelPropertiesChangedEvent;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelTypeException;

import javax.annotation.Nonnull;
import java.util.HashMap;

public class UpdateChannelPropertiesEventHandler<C extends CallContext>
        extends EventHandler<C, ChannelPropertiesChangedEvent> {

    private final UpdateChannelPropertiesBase<C> base;

    public UpdateChannelPropertiesEventHandler(C context,
            @Nonnull ChannelManagers channelManagers, @Nonnull StaticConfiguration configuration,
            @Nonnull SettingsRepository settings, @Nonnull LoggerManager<C> loggerManager) {
        super(context);
        this.base = new UpdateChannelPropertiesBase<>(context,
                channelManagers.getChannelRepository(),
                configuration,
                settings,
                loggerManager,
                channelManagers.getChannelNotifications());
    }

    @Override
    public void handleEvent(ChannelPropertiesChangedEvent event) throws
            UnknownChannelIdException, RepositoryException, UnknownChannelTypeException, DuplicatedObjectNameException, InvalidMutationException {
        // Due to the immutable nature of events, we must create a mutable copy of the event's properties 
        base.applyUpdate(event.getChannelId(), new HashMap<>(event.getPropertiesChanged()));
    }

}
