package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelCreatingEvent;
import com.ossnms.dcn_manager.events.base.ChannelManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

public class ChannelCreatingEventHandler<C extends CallContext> extends
        SimpleChannelEventHandlerBase<C, ChannelCreatingEvent> {

    public ChannelCreatingEventHandler(@Nonnull C context, @Nonnull ChannelManagers channelManagers) {
        super(context, channelManagers);
    }

    @Override
    protected Optional<ChannelConnectionMutationDescriptor> produceMutation(ChannelConnectionBehavior state) {
        return state.setCreating();
    }

}
