package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.google.common.base.Throwables.getStackTraceAsString;

/**
 * Base for events affecting the communication state of physical NE instances.
 *
 * @param <L> Concrete type of the event that will be emitted against the logical NE instance as a consequence of
 *           the processing of the physical instance state change.
 */
abstract class PhysicalNeStatusEventHandlerBase<C extends CallContext, P extends PhysicalNeStateEvent, L extends ActualNeStateEvent>
        extends PhysicalNeEventHandlerBase<C, P> {

    private final NeEntityRepository.NeSynchronizationRepository synchronizationRepository;
    
    public PhysicalNeStatusEventHandlerBase(@Nonnull C context,
                                            @Nonnull NetworkElementManagers neManagers) {
        super(context, neManagers);
        this.synchronizationRepository = neManagers.getNeRepository().getNeSynchronizationRepository();

    }

    @Override
    protected final void handleEvent(@Nonnull P event) throws DcnManagerException {
        final NePhysicalConnectionData neConnectionState = findNePhysicalConnectionState(event.getNeId());
        final NePhysicalConnectionBehavior state = new NePhysicalConnectionBehavior(neConnectionState, neManagers.getNeNotifications());
        final Optional<NePhysicalConnectionMutationDescriptor> mutation = produceMutation(event, state, neManagers);
        if (mutation.isPresent()) { // state changes to the same state are no-ops
            getLogger().debug("Handling event on Physical NE {} from state {}.",
                    neConnectionState.getId(), neConnectionState.getActualActivationState());
            final Optional<NePhysicalConnectionData> updatedData = neManagers.getNeInstanceRepository().tryUpdate(mutation.get());
            if (updatedData.isPresent()) {
                if (neConnectionState.isActive()) { // forward event to the logical entity if this is the active instance.
                    neManagers.getNeEvents().push(
                            produceForwardingEvent(event, neConnectionState));
                }
                onMutationApplied(updatedData.get(), state, neManagers);
            } else {
                getLogger().error("Concurrent modification of Physical NE {} state. Not applied: {}", neConnectionState.getId(), mutation.get());
            }
        } else {
            getLogger().warn("Dropping event because Physical NE {} is already in state {}.",
                    neConnectionState.getId(), neConnectionState.getActualActivationState());
        }
    }

    protected abstract Optional<NePhysicalConnectionMutationDescriptor> produceMutation(
            P event, NePhysicalConnectionBehavior state, NetworkElementManagers neManagers);

    protected abstract NeEvent produceForwardingEvent(P event, NePhysicalConnectionData neConnectionState);

    /**
     * Extension point to allow implementing classes to run extra behavior after the entity state has been updated.
     * @param updatedPhysicalConnection Physical connection data as updated by the state change.
     * @param state Physical connection behavioral dimension.
     * @param neManagers Parameter object with all NE entity managers.
     */
    protected void onMutationApplied(NePhysicalConnectionData updatedPhysicalConnection,
            NePhysicalConnectionBehavior state, NetworkElementManagers neManagers) {

    }
    
    /**
     * Calculates counter differences.
     * 
     * @return The calculated differences, or empty when no current values exist or on error condition. 
     */
    protected Optional<NeSynchronizationData> calculateDifferencesOfCounters(NeSynchronizationData newValues) {
        try {
            final Optional<NeSynchronizationData> currentValuesFound =
                    synchronizationRepository.query(newValues.getId());
            if (currentValuesFound.isPresent()) {
                final NeSynchronizationData currentValues = currentValuesFound.get();
                return Optional.of(new NeSynchronizationData.NeSynchronizationBuilder()
                        .setAll(useNewValue(newValues.getAll(), currentValues.getAll()) ? newValues.getAll() : Optional.empty())
                        .setAlarms(useNewValue(newValues.getAlarms(), currentValues.getAlarms()) ? newValues.getAlarms() : Optional.empty())
                        .setPacket(useNewValue(newValues.getPacket(), currentValues.getPacket()) ? newValues.getPacket() : Optional.empty())
                        .build(newValues.getId(), 0));
            }
        } catch (RepositoryException e) {
            getLogger().error("Failed to obtain current synchronization counters for NE {}: {}",
                    newValues.getId(), getStackTraceAsString(e));
        }
        return Optional.empty();
    }

    private boolean useNewValue(Optional<Long> newValue, Optional<Long> currentValue) {
        /*
        Use the new counter value if its different from the current value or if it is zero.
        Zero on a counter value is used to signal a synchronization request for that category.
         */
        return !newValue.equals(currentValue) || newValue.map(val -> 0 == val).orElse(false);
    }


}
