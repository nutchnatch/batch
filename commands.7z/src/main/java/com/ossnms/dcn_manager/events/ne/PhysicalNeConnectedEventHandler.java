package com.ossnms.dcn_manager.events.ne;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeConnectedEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Handles events requesting a physical NE connection to switch to the CONNECTED state.
 */
public class PhysicalNeConnectedEventHandler<C extends CallContext>
        extends PhysicalNeStatusEventHandlerBase<C, PhysicalNeConnectedEvent, NeConnectedEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(PhysicalNeConnectedEventHandler.class);

    private final ChannelPhysicalConnectionRepository channelInstances;

    public PhysicalNeConnectedEventHandler(@Nonnull C context,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull ChannelPhysicalConnectionRepository channelInstances) {
        super(context, neManagers);
        this.channelInstances = channelInstances;
    }

    @Override
    protected Optional<NePhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalNeConnectedEvent event, NePhysicalConnectionBehavior state,
            NetworkElementManagers neManagers) {
        try {
            final ChannelPhysicalConnectionData channelInstance =
                    findChannelInstance(channelInstances, neManagers.getNeInstanceRepository(), event.getNeId());
            return state.setConnected(neManagers.getNeActivationManager(), channelInstance.getId(), channelInstance.getMediatorInstanceId());
        } catch (RepositoryException | UnknownNetworkElementIdException | UnknownChannelIdException e) {
            LOGGER.error("Failed to process physical NE connected event {}: {}", event, Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    @Override
    protected NeConnectedEvent produceForwardingEvent(PhysicalNeConnectedEvent event, NePhysicalConnectionData neConnectionState) {
        return new NeConnectedEvent(event.getLogicalNeId(), event);
    }

}
