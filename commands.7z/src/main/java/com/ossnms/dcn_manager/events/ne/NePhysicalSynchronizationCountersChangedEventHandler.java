package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NePhysicalSynchronizationCountersChangedEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeSynchronizationRepository;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Optional;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * Handles updates to NE configuration/synchronization counters/stamps.
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class NePhysicalSynchronizationCountersChangedEventHandler<C extends CallContext>
        extends EventHandler<C, NePhysicalSynchronizationCountersChangedEvent> {

    private static final Logger LOGGER = getLogger(NePhysicalSynchronizationCountersChangedEventHandler.class);

    private final NeSynchronizationRepository synchronizationRepository;

    /**
     * Creates a new object instance.
     * @param context Call context information.
     * @param repository NE entity repository instance, for updating persisted information.
     */
    protected NePhysicalSynchronizationCountersChangedEventHandler(C context, @Nonnull NeEntityRepository repository) {
        super(context);
        synchronizationRepository = repository.getNeSynchronizationRepository();
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.events.base.EventHandler#handleEvent(java.lang.Object)
     */
    @Override
    protected void handleEvent(@Nonnull NePhysicalSynchronizationCountersChangedEvent event) throws DcnManagerException {
        final Optional<NeSynchronizationData> result = synchronizationRepository.query(event.getLogicalNeId());
        if (!result.isPresent()) {
            throw new UnknownNetworkElementIdException("NE {} was not found.", event.getLogicalNeId());
        }

        final NeSynchronizationMutationDescriptor descriptor = new NeSynchronizationMutationDescriptor(result.get());
        if (event.getAlarms().isPresent()) {
            descriptor.setAlarms(event.getAlarms().get());
        }
        if (event.getAll().isPresent()) {
            descriptor.setAll(event.getAll().get());
        }
        if (event.getPacket().isPresent()) {
            descriptor.setPacket(event.getPacket().get());
        }

        LOGGER.debug("Trying to update NE {} counters with {}.", event.getLogicalNeId(), descriptor);

        final Optional<NeSynchronizationData> updated = synchronizationRepository.tryUpdate(descriptor);
        if (!updated.isPresent()) {
            throw new DataUpdateException("Could not update NE {} counters with {}: concurrent modification.",
                    event.getLogicalNeId(), descriptor);
        }
    }

}
