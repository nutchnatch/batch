package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeRestartRequestEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Behaves similarly to an NE DISCONNECTED event handler, except that it will request
 * a restart from the Behavior component of the NE physical connection state.
 */
public class PhysicalNeRestartRequestEventHandler<C extends CallContext>
        extends PhysicalNeEventHandlerBase<C, PhysicalNeRestartRequestEvent> {

    private final ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;

    /**
     * Constructs a new object.
     */
    public PhysicalNeRestartRequestEventHandler(@Nonnull C context,
                                                @Nonnull NetworkElementManagers neManagers,
                                                @Nonnull ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository) {
        super(context, neManagers);
        this.channelPhysicalConnectionRepository = channelPhysicalConnectionRepository;
    }

    @Override
    protected final void handleEvent(@Nonnull PhysicalNeRestartRequestEvent event) throws DcnManagerException {
        final NePhysicalConnectionData neConnectionState =
                findNePhysicalConnectionState(event.getPhysicalNeId());
        final ChannelPhysicalConnectionData channel =
                findChannelInstance(channelPhysicalConnectionRepository, neConnectionState.getChannelInstanceId());
        final Optional<NePhysicalConnectionMutationDescriptor> mutation =
                new NePhysicalConnectionBehavior(neConnectionState, neManagers.getNeNotifications())
                        .restart(neManagers.getNeActivationManager(), channel.getMediatorInstanceId());
        if (mutation.isPresent()) { // state changes to the same state are no-ops
            getLogger().debug("Handling RESTART event on Physical NE {} from state {}.",
                    neConnectionState.getId(), neConnectionState.getActualActivationState());
            final Optional<NePhysicalConnectionData> updatedData = neManagers.getNeInstanceRepository().tryUpdate(mutation.get());
            if (!updatedData.isPresent()) {
                getLogger().error("Concurrent modification of Physical NE {} state. Not applied: {}", neConnectionState.getId(), mutation.get());
            }
        } else {
            getLogger().warn("Dropping event {} because Physical NE {} is already in state {}.",
                    event, neConnectionState.getId(), neConnectionState.getActualActivationState());
        }
    }

}
