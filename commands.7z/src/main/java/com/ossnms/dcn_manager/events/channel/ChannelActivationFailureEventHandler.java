package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.channel.ChannelModificationBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

import java.util.Optional;

import static com.google.common.collect.Iterables.transform;

public class ChannelActivationFailureEventHandler<C extends CallContext> extends
        EventHandler<C, ChannelActivationFailedEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelActivationFailureEventHandler.class);

    private final ChannelModificationBase base;
    private final ChannelNotifications notifications;
    private final ChannelInteractionManager activationManager;
    private final NetworkElementManagers neManagers;

    public ChannelActivationFailureEventHandler(@Nonnull C context,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull NetworkElementManagers neManagers) {
        super(context);
        this.neManagers = neManagers;
        notifications = channelManagers.getChannelNotifications();
        activationManager = channelManagers.getChannelActivationManager();
        base = new ChannelModificationBase(channelManagers.getChannelRepository());
    }

    @Override
    protected void handleEvent(ChannelActivationFailedEvent event) throws DcnManagerException {
        final ChannelConnectionData channelConnectionState = base.findChannelConnectionState(event.getChannelId());
        final ChannelConnectionBehavior state = new ChannelConnectionBehavior(channelConnectionState, notifications);
        final Optional<ChannelConnectionMutationDescriptor> stateMutation =
                state.setFailed(activationManager, neManagers.getNeEvents(),
                        getChildNesForFailure(event.getChannelId()), event.getDetailedDescription());
        if (stateMutation.isPresent()) { // state changes to the same state are no-ops
            base.getChannelRepository().getChannelConnectionRepository().tryUpdate(stateMutation.get());
        } else {
            LOGGER.warn("Dropping event because Channel {} is already in state {}.",
                    channelConnectionState.getId(), channelConnectionState.getActualActivationState());
        }
    }

    private Iterable<Integer> getChildNesForFailure(int channelId) throws RepositoryException {
        final NeEntityRepository neRepository = neManagers.getNeRepository();
        final Iterable<NeInfoData> disconnectedNes =
                neRepository.queryActualActivationIsDifferentThan(channelId, ActualActivationState.DISCONNECTED);
        return transform(disconnectedNes, NeInfoData.GET_ID);
    }

}
