package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Base for processing events against physical NE instances.
 *
 * @param <P> Concrete type of the event being handled.
 */
abstract class PhysicalNeEventHandlerBase<C extends CallContext, P extends NeEvent>
        extends EventHandler<C, P> {

    protected final Logger logger = LoggerFactory.getLogger(getClass());
    protected final NetworkElementManagers neManagers;

    protected PhysicalNeEventHandlerBase(@Nonnull C context, @Nonnull NetworkElementManagers neManagers) {
        super(context);
        this.neManagers = neManagers;
    }

    /**
     * Tries to find the physical communications state of the target NE in the repository.
     *
     * @return An instance of a physical NE communications state.
     * @throws UnknownNetworkElementIdException If the NE can not be found.
     * @throws RepositoryException If some error occurred while working with the repository.
     */
    protected NePhysicalConnectionData findNePhysicalConnectionState(int instanceId) throws UnknownNetworkElementIdException, RepositoryException {
        final Optional<NePhysicalConnectionData> state = neManagers.getNeInstanceRepository().query(instanceId);
        if (!state.isPresent()) {
            throw new UnknownNetworkElementIdException(tr(Message.NE_DOES_NOT_EXIST, instanceId));
        }
        return state.get();
    }

    /**
     * Tries to find the physical communications state of a Channel in the repository.
     */
    protected ChannelPhysicalConnectionData findChannelInstance(
            ChannelPhysicalConnectionRepository channelInstances, NePhysicalConnectionRepository neInstances,
            int physicalNeId)
            throws RepositoryException, UnknownNetworkElementIdException, UnknownChannelIdException {
        final Optional<Integer> neChannelInstanceId =
                neInstances.query(physicalNeId).map(NePhysicalConnectionData::getChannelInstanceId);
        if (!neChannelInstanceId.isPresent()) {
            throw new UnknownNetworkElementIdException("Unknown NE Instance: {}", physicalNeId);
        }

        return findChannelInstance(channelInstances, neChannelInstanceId.get());
    }

    /**
     * Tries to find the physical communications state of a Channel in the repository.
     */
    protected ChannelPhysicalConnectionData findChannelInstance(
            ChannelPhysicalConnectionRepository channelInstances, int neChannelInstanceId)
            throws RepositoryException, UnknownNetworkElementIdException, UnknownChannelIdException {
        final Optional<ChannelPhysicalConnectionData> channelInstance = channelInstances.query(neChannelInstanceId);
        if (!channelInstance.isPresent()) {
            throw new UnknownChannelIdException("Unknown Channel Instance: {}", neChannelInstanceId);
        }
        return channelInstance.get();
    }

    protected Logger getLogger() {
        return logger;
    }

}
