package com.ossnms.dcn_manager.events.channel;

import com.google.common.base.Throwables;
import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.QNePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeActivationFailedEvent;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.google.common.collect.Iterables.transform;
import static com.ossnms.dcn_manager.i18n.T.tr;

public class PhysicalChannelActivationFailureEventHandler<C extends CallContext> extends
        PhysicalChannelEventHandlerBase<C, PhysicalChannelActivationFailedEvent, ChannelActivationFailedEvent> {

    private final NetworkElementManagers networkElementManagers;

    public PhysicalChannelActivationFailureEventHandler(@Nonnull C context,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull NetworkElementManagers neManagers) {
        super(context, channelManagers);
        this.networkElementManagers = neManagers;
    }

    @Override
    protected Optional<ChannelPhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalChannelActivationFailedEvent event, ChannelPhysicalConnectionBehavior state,
            ChannelManagers channelManagers) {
        return state.setFailed(channelManagers.getChannelActivationManager(), networkElementManagers.getNeEvents(),
                getEventsForChildNes(event.getLogicalChannelId(), event.getChannelId()), event.getDetailedDescription());
    }

    @Override
    protected ChannelActivationFailedEvent produceForwardingEvent(
            PhysicalChannelActivationFailedEvent event,
            ChannelPhysicalConnectionData channelConnectionState) {
        return new ChannelActivationFailedEvent(event.getLogicalChannelId(), event, event.getDetailedDescription());
    }


    private List<PhysicalNeActivationFailedEvent> getEventsForChildNes(int channelId, int channelInstanceId) {
        final ImmutableList<Integer> childRequiredActiveNeIds = ImmutableList.copyOf(
            transform(getChildNEsRequiredActive(channelId), NeInfoData::getId));
        final QNePhysicalConnectionData conn = QNePhysicalConnectionData.nePhysicalConnectionData;
        return networkElementManagers.getNeInstanceRepository().query(conn)
            .where(conn.logicalNeId.in(childRequiredActiveNeIds)
                    .and(conn.channelInstanceId.eq(channelInstanceId))
                    .and(conn.actualActivationState.ne(ActualActivationState.DISCONNECTED)))
            .list(conn)
            .stream()
            .map(connection -> new PhysicalNeActivationFailedEvent(connection.getId(), connection.getLogicalNeId(), connection.isActive(), tr(Message.CHANNEL_FAILED)))
            .collect(Collectors.toList());
    }

    private Iterable<NeInfoData> getChildNEsRequiredActive(int logicalChannelId) {
        try {
            return networkElementManagers.getNeRepository().queryActivationRequiredIs(logicalChannelId, RequiredActivationState.ACTIVE);
        } catch (final RepositoryException e) {
            getLogger().error("Failed to get child NEs required active for channel {} : {}", logicalChannelId,
                    Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

}
