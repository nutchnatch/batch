package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.mediator.PhysicalMediatorModificationBase;
import com.ossnms.dcn_manager.core.entities.mediator.behavior.MediatorPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Base class with all required mechanism for handling physical mediator events. Takes care of
 * finding data, validating and saving mutations and forwarding the event to the logical handler.
 *
 * @param <C> Call context.
 * @param <P> Concrete physical mediator instance event type being handled.
 * @param <L> Concrete logical mediator event type for forwarding to logical handlers.
 */
abstract class PhysicalMediatorEventHandlerBase<C extends CallContext, P extends PhysicalMediatorStateEvent, L extends ActualMediatorStateEvent>
        extends EventHandler<C, P> {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private final PhysicalMediatorModificationBase base;
    private final MediatorManagers mediatorManagers;

    public PhysicalMediatorEventHandlerBase(@Nonnull C context,
            @Nonnull MediatorManagers mediatorManagers) {
        super(context);
        this.mediatorManagers = mediatorManagers;
        base = new PhysicalMediatorModificationBase(mediatorManagers.getMediatorInstanceRepository());
    }

    @Override
    protected final void handleEvent(P event) throws DcnManagerException {
        final MediatorPhysicalConnectionData mediatorConnectionState = base.findMediatorConnectionState(event.getMediatorId());
        final MediatorPhysicalConnectionBehavior state = new MediatorPhysicalConnectionBehavior(mediatorConnectionState);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation = produceMutation(event, state, mediatorManagers);
        if (mutation.isPresent()) { // state changes to the same state are no-ops
            final Optional<MediatorPhysicalConnectionData> updatedConnection =
                    base.getMediatorRepository().getMediatorPhysicalConnectionRepository().tryUpdate(mutation.get());
            if (updatedConnection.isPresent()) {
                if (mediatorConnectionState.isActive()) { // forward event to the logical entity if this is the active instance.
                    mediatorManagers.getMediatorEvents().push(
                            produceForwardingEvent(event, mediatorConnectionState));
                }
                onMutationApplied(updatedConnection.get(), state, mediatorManagers);
            } else {
                logger.error("Concurrent modification of Physical Mediator {} state. Not applied: {}", mediatorConnectionState.getId(), mutation.get());
            }
        } else {
            logger.warn("Dropping event because Physical Mediator {} is already in state {}.",
                    mediatorConnectionState.getId(), mediatorConnectionState.getActualActivationState());
        }
    }

    /**
     * Extension point to allow implementing classes to run extra behavior after the entity state has been updated.
     * @param updatedPhysicalConnection Physical connection data as updated by the state change.
     * @param state Physical connection behavioral dimension.
     * @param mediatorManagers Parameter object with all mediator entity managers.
     */
    protected void onMutationApplied(MediatorPhysicalConnectionData updatedPhysicalConnection,
            MediatorPhysicalConnectionBehavior state, MediatorManagers mediatorManagers) {

    }

    /**
     * @return An instance of a logger for the implementing class.
     */
    protected Logger getLogger() {
        return logger;
    }

    protected abstract Optional<MediatorPhysicalConnectionMutationDescriptor> produceMutation(
            P event, MediatorPhysicalConnectionBehavior state, MediatorManagers mediatorManagers);

    protected abstract L produceForwardingEvent(P event, MediatorPhysicalConnectionData mediatorConnectionState);

}
