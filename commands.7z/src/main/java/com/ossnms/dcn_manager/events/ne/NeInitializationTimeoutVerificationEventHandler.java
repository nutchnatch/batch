package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.QNePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent;
import com.ossnms.dcn_manager.core.events.periodic.PeriodicInitializationVerificationEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.time.Duration;
import java.time.Instant;
import java.util.stream.Stream;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Issue an "activation failed" event should any NE be found in the "initializing" state
 * for longer than the configured initialization time.
 */
public class NeInitializationTimeoutVerificationEventHandler<C extends CallContext>
    extends EventHandler<C, PeriodicInitializationVerificationEvent> {

    private static final Logger LOGGER = getLogger(NeInitializationTimeoutVerificationEventHandler.class);

    private final NePhysicalConnectionRepository neInstanceRepository;
    private final NeEntityRepository.NeUserPreferencesRepository nePreferencesRepository;
    private final MessageSource<NeEvent> neEvents;

    public NeInitializationTimeoutVerificationEventHandler(
            @Nonnull C context,
            @Nonnull NetworkElementManagers networkElementManagers) {
        super(context);
        neInstanceRepository = networkElementManagers.getNeInstanceRepository();
        nePreferencesRepository = networkElementManagers.getNeRepository().getNeUserPreferencesRepository();
        neEvents = networkElementManagers.getNeEvents();
    }

    @Override
    protected void handleEvent(@Nonnull PeriodicInitializationVerificationEvent event)
            throws DcnManagerException {

        /*
        Emit failure events for initializing NEs with a init start timestamp and
        that have been waiting for too long according to their own configuration.
         */
        queryInitializingNEs()
            .filter(connection -> connection.getInitStageStartTime().isPresent()) // (defensive)
            .filter(this::hasInitializationTimeoutElapsed)
            .forEach(this::emitActivationFailureEvent);
    }

    private Stream<NePhysicalConnectionData> queryInitializingNEs() {
        final QNePhysicalConnectionData conn = QNePhysicalConnectionData.nePhysicalConnectionData;
        return neInstanceRepository.query(conn)
            .where(conn.activationState.eq(ActualActivationState.INITIALIZING))
            .list(conn)
            .stream();
    }

    private boolean hasInitializationTimeoutElapsed(NePhysicalConnectionData conn) {
        try {
            final long minutesElapsed = Duration.between(conn.getInitStageStartTime().get(), Instant.now()).toMinutes();
            return nePreferencesRepository.query(conn.getLogicalNeId()).map(prefs -> prefs.getReconnectInterval() > 0 && prefs.getReconnectInterval() <= minutesElapsed).orElse(false);
        } catch (RepositoryException e) {
            LOGGER.error("Error querying NE preferences for connection {}: {}", conn, getStackTraceAsString(e));
            return false;
        }
    }

    private void emitActivationFailureEvent(NePhysicalConnectionData conn) {
        LOGGER.warn("Initialization timeout for NE {}.", conn.getId());
        neEvents.push(new PhysicalNeStateEvent.PhysicalNeActivationFailedEvent(
                conn.getId(), conn.getLogicalNeId(), conn.isActive(), tr(Message.NE_INIT_TIMEOUT)));
    }
}
