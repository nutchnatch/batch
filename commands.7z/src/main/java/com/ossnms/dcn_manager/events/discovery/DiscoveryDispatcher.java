package com.ossnms.dcn_manager.events.discovery;

import com.ossnms.dcn_manager.composables.configuration.AppProperties;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.EventDispatcher;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.identification.ne.NeIdentificationV5;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import javax.annotation.Nonnull;

/**
 * Subscribes to an inbound event stream, dispatching each event to its appropriate handler.
 *
 * @param <C> Context instance type, propagated to handlers that need one.
 */
public class DiscoveryDispatcher<C extends CallContext> extends EventDispatcher<C> {

    private static final Logger LOGGER = LoggerFactory.getLogger(DiscoveryDispatcher.class);

    private final SettingsRepository settings;

    private final NetworkElementManagers neManagers;
    private final AppProperties appProperties;
    private final ChannelManagers channelManagers;
    private final DomainManagers domainManagers;
    private final ContainerRepository containerRepository;
    private final SystemRepository systemRepository;
    private final ContainerNotifications containerNotifications;

    public DiscoveryDispatcher(@Nonnull C context,
            @Nonnull StaticConfiguration configuration,
            @Nonnull AppProperties appProperties,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull SettingsRepository settings,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull DomainManagers domainManagers,
            @Nonnull ContainerRepository containerRepository,
            @Nonnull SystemRepository systemRepository,
            @Nonnull ContainerNotifications containerNotifications) {
        super(context, configuration, loggerManager);
        this.appProperties = appProperties;
        this.channelManagers = channelManagers;
        this.neManagers = neManagers;
        this.domainManagers = domainManagers;
        this.settings = settings;
        this.containerRepository = containerRepository;
        this.systemRepository = systemRepository;
        this.containerNotifications = containerNotifications;
    }

    @Override
    public final void initialize(Observable<? extends Event> eventSource) {

        LOGGER.debug("Initializing NE Discovery event dispatcher.");

        eventSource
            .ofType(NeDiscoveredEvent.class)
            .filter(isDiscoveryEnabled())
            .filter(arePropertiesPresent())
            .map(associateWithChannel())
            .filter(isChannelPresent())
            .filter(channelSupportsDiscovery())
            .filter(channelSupportsDiscoveredNeType())
            .retry(this::shouldRetry)
            .subscribe(
                new NeDiscoveredEventHandler<>(getContext(), neManagers,
                        new NeIdentificationV5(neManagers.getNeRepository(), getConfiguration()),
                        domainManagers, containerRepository, systemRepository, containerNotifications, settings, appProperties,
                        channelManagers.getChannelRepository(), channelManagers.getChannelInstanceConnections(),
                        getLoggerManager()));
    }

    private ChannelSupportsNeType<C> channelSupportsDiscoveredNeType() {
        return new ChannelSupportsNeType<>(getContext(), getLoggerManager(), getConfiguration());
    }

    private ChannelSupportsDiscovery channelSupportsDiscovery() {
        return new ChannelSupportsDiscovery(getConfiguration());
    }

    private ChannelIsPresent<C> isChannelPresent() {
        return new ChannelIsPresent<>(getContext(), getLoggerManager());
    }

    private AssociateWithChannel associateWithChannel() {
        return new AssociateWithChannel(channelManagers.getChannelRepository());
    }

    private HasPropertiesPresent<C> arePropertiesPresent() {
        return new HasPropertiesPresent<>(getContext(), getLoggerManager());
    }

    private DiscoveryIsEnabled isDiscoveryEnabled() {
        return new DiscoveryIsEnabled(settings);
    }

}
