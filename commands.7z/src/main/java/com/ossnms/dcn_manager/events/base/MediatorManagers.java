package com.ossnms.dcn_manager.events.base;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;

/**
 * Parameter object that holds references to all manager/publisher objects
 * that are commonly used together when handling Mediator events.
 */
public final class MediatorManagers {

    private final MediatorEntityRepository mediatorRepository;
    private final MediatorInstanceEntityRepository mediatorInstanceRepository;
    private final MediatorNotifications mediatorNotifications;
    private final MediatorInteractionManager mediatorActivationManager;
    private final MessageSource<MediatorEvent> mediatorEventSource;

    /**
     * Creates a new object.
     * @param mediatorRepository Mediator repository.
     * @param mediatorInstanceRepository Repository of Mediator physical instances.
     * @param mediatorNotifications Mediator notification publisher.
     * @param mediatorActivationManager Mediator interaction manager.
     * @param mediatorEventSource Mediator event source.
     */
    public MediatorManagers(
            @Nonnull MediatorEntityRepository mediatorRepository,
            @Nonnull MediatorInstanceEntityRepository mediatorInstanceRepository,
            @Nonnull MediatorNotifications mediatorNotifications,
            @Nonnull MediatorInteractionManager mediatorActivationManager,
            @Nonnull MessageSource<MediatorEvent> mediatorEventSource) {
        this.mediatorRepository = mediatorRepository;
        this.mediatorInstanceRepository = mediatorInstanceRepository;
        this.mediatorNotifications = mediatorNotifications;
        this.mediatorActivationManager = mediatorActivationManager;
        this.mediatorEventSource = mediatorEventSource;
    }

    /**
     * @return The Mediator repository.
     */
    public MediatorEntityRepository getMediatorRepository() {
        return mediatorRepository;
    }

    /**
     * @return Repository of Mediator physical instances.
     */
    public MediatorInstanceEntityRepository getMediatorInstanceRepository() {
        return mediatorInstanceRepository;
    }

    /**
     * @return The Mediator notification publisher.
     */
    public MediatorNotifications getMediatorNotifications() {
        return mediatorNotifications;
    }

    /**
     * @return The Mediator interaction manager.
     */
    public MediatorInteractionManager getMediatorActivationManager() {
        return mediatorActivationManager;
    }

    /**
     * @return The Mediator event source.
     */
    public MessageSource<MediatorEvent> getMediatorEvents() {
        return mediatorEventSource;
    }
}
