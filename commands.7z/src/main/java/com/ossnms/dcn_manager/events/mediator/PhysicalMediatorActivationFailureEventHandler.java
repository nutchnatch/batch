package com.ossnms.dcn_manager.events.mediator;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.QChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.behavior.MediatorPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class PhysicalMediatorActivationFailureEventHandler<C extends CallContext> extends
        PhysicalMediatorEventHandlerBase<C, PhysicalMediatorActivationFailedEvent, MediatorActivationFailedEvent> {

    private final ChannelManagers channelManagers;

    public PhysicalMediatorActivationFailureEventHandler(@Nonnull C context,
            @Nonnull MediatorManagers mediatorManagers,
            @Nonnull ChannelManagers channelManagers) {
        super(context, mediatorManagers);
        this.channelManagers = channelManagers;
    }

    @Override
    protected Optional<MediatorPhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalMediatorActivationFailedEvent event, MediatorPhysicalConnectionBehavior state, MediatorManagers mediatorManagers) {
        return state.setFailed(mediatorManagers.getMediatorNotifications(), mediatorManagers.getMediatorActivationManager(),
                event.getDetailedDescription(), channelManagers.getChannelEvents(),
                getChildChannelsForFailure(event.getLogicalMediatorId(), event.getMediatorId()));
    }

    @Override
    protected MediatorActivationFailedEvent produceForwardingEvent(PhysicalMediatorActivationFailedEvent event, MediatorPhysicalConnectionData mediatorConnectionState) {
        return new MediatorActivationFailedEvent(mediatorConnectionState.getLogicalMediatorId(), event, event.getDetailedDescription());
    }

    private List<ChannelPhysicalConnectionData> getChildChannelsForFailure(int mediatorId, int instanceId) {
        try {
            final ChannelEntityRepository channelRepository = channelManagers.getChannelRepository();
            final Collection<Integer> childChannels = channelRepository.getChannelInfoRepository()
                    .queryChannelIdsUnderMediator(mediatorId);
            final QChannelPhysicalConnectionData channelConnection = QChannelPhysicalConnectionData.channelPhysicalConnectionData;
            return channelManagers.getChannelInstanceConnections()
                .query(channelConnection)
                    .where(channelConnection.actualActivationState.ne(ActualActivationState.INACTIVE)
                            .and(channelConnection.logicalChannelId.in(childChannels))
                            .and(channelConnection.mediatorInstanceId.eq(instanceId)))
                    .list(channelConnection);
        } catch (final RepositoryException e) {
            getLogger().warn("It was not possible to retrieve child channels for mediator {}, no automatic failure state change. {}",
                    mediatorId, Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

}
