package com.ossnms.dcn_manager.events.discovery;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Optional;

final class ChannelIsPresent<C extends CallContext>
        extends DiscoveryFilterBase<C, Pair<Optional<ChannelInfoData>, NeDiscoveredEvent>> {

    public ChannelIsPresent(C context, LoggerManager<C> logManager) {
        super(context, logManager);
    }

    @Override
    public Boolean call(Pair<Optional<ChannelInfoData>, NeDiscoveredEvent> data) {
        if (data.getLeft().isPresent()) {
            return true;
        } else {
            final NeDiscoveredEvent discoveredNetworkElement = data.getRight();
            reportWarning(discoveredNetworkElement,
                    "New NE was found but parent Channel is unknown. ChannelId={}",
                    discoveredNetworkElement.getCreateDescriptor().getChannelId());
            return false;
        }
    }
}