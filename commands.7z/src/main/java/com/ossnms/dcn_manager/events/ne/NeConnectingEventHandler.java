package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NeConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectingEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;

import javax.annotation.Nonnull;
import java.util.Optional;

public class NeConnectingEventHandler<C extends CallContext> extends
        NeConnectionEventHandlerBase<C, NeConnectingEvent> {

    public NeConnectingEventHandler(@Nonnull C context,
            @Nonnull NeEntityRepository repository,
            @Nonnull NetworkElementNotifications notifications) {
        super(context, repository, notifications);
    }

    @Override
    protected Optional<NeConnectionMutationDescriptor> triggerMutation(NeConnectionBehavior behavior, NeConnectingEvent event) {
        return behavior.setConnecting();
    }

}
