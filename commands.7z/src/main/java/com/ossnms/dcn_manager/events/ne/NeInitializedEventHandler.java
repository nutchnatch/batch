package com.ossnms.dcn_manager.events.ne;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.NeInformationRetrieval;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NeConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent;
import com.ossnms.dcn_manager.core.outbound.Alarms;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.outbound.exception.OutboundException;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Reacts to an NE completing initialization on the active connection.
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class NeInitializedEventHandler<C extends CallContext> extends
        NeConnectionUpdatingEventHandlerBase<C, NeInitializedEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeInitializedEventHandler.class);

    private static final int MAX_UPDATE_ATTEMPTS = 3;

    private final Alarms alarms;

    public NeInitializedEventHandler(@Nonnull C context,
            @Nonnull NeEntityRepository repository,
            @Nonnull NetworkElementNotifications notifications,
            @Nonnull NeInformationRetrieval informationRetrieval,
            @Nonnull Alarms alarms) {
        super(context, repository, notifications, informationRetrieval);
        this.alarms = alarms;
    }

    @Override
    protected final Optional<NeConnectionMutationDescriptor> triggerMutation(NeConnectionBehavior behavior, NeInitializedEvent event) {

        Optional<NeConnectionMutationDescriptor> mutation;
        try {
            event.getOriginatingPhysicalEvent()
                .ifPresent(this::doUpdateDataFromMediator);
            mutation = event.getSynchronizationDataDifferences()
                .map(behavior::setInitialized) // calls NeConnectionBehavior.setInitialized(NeSynchronizationData)
                .orElseGet(behavior::setInitialized); // or else calls NeConnectionBehavior.setInitialized()
        } catch (final RuntimeException e) {
            LOGGER.error("NE information update failed.", e);
            mutation = behavior.setFailed(tr(Message.INITIALIZATION_UPDATE_FAILED), alarms);
        }
        return mutation;

    }

    private void doUpdateDataFromMediator(PhysicalNeStateEvent physicalEvent) {
        int attempt = 1;
        while (true) {
            try {
                updateDataFromMediator(physicalEvent.getLogicalNeId(), physicalEvent.getNeId());
                break;
            } catch (DataUpdateException u) {
                if (attempt < MAX_UPDATE_ATTEMPTS) {
                    LOGGER.warn("NE information update failed, attempt {}/{}. Will retry: {}", attempt, MAX_UPDATE_ATTEMPTS, u.getMessage());
                    attempt++;
                } else {
                    LOGGER.error("NE information update failed, attempt {}/{}.", attempt, MAX_UPDATE_ATTEMPTS);
                    throw Throwables.propagate(u);
                }
            } catch (OutboundException | UnknownNetworkElementIdException
                    | RepositoryException | UnknownChannelIdException e) {
                throw Throwables.propagate(e);
            }
        }
    }
}
