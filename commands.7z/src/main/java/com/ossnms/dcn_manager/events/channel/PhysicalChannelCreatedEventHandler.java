package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelCreatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelCreatedEvent;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

public class PhysicalChannelCreatedEventHandler<C extends CallContext> extends
        PhysicalChannelCascadingActivationEventHandlerBase<C, PhysicalChannelCreatedEvent, ChannelCreatedEvent> {

    public PhysicalChannelCreatedEventHandler(
            @Nonnull C context,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull NetworkElementManagers networkElementManagers,
            @Nonnull MediatorManagers mediatorManagers) {
        super(context, channelManagers, networkElementManagers, mediatorManagers);
    }

    @Override
    protected Optional<ChannelPhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalChannelCreatedEvent event, ChannelPhysicalConnectionBehavior state,
            ChannelManagers channelManagers) {
        return state.setCreated(channelManagers.getChannelActivationManager());
    }

    @Override
    protected ChannelCreatedEvent produceForwardingEvent(PhysicalChannelCreatedEvent event,
            ChannelPhysicalConnectionData channelConnectionState) {
        return new ChannelCreatedEvent(event.getLogicalChannelId(), event);
    }
}
