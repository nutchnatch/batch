package com.ossnms.dcn_manager.events.discovery;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.functions.Func1;

import java.util.Optional;

final class AssociateWithChannel implements
        Func1<NeDiscoveredEvent, Pair<Optional<ChannelInfoData>, NeDiscoveredEvent>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AssociateWithChannel.class);

    private final ChannelEntityRepository channelRepository;

    public AssociateWithChannel(ChannelEntityRepository channelRepository) {
        this.channelRepository = channelRepository;
    }

    @Override
    public Pair<Optional<ChannelInfoData>, NeDiscoveredEvent> call(NeDiscoveredEvent event) {
        final int channelId = event.getCreateDescriptor().getChannelId();
        Optional<ChannelInfoData> channel;
        try {
            channel = channelRepository.getChannelInfoRepository().query(channelId);
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to search the repository for Channel #{}", channelId, e);
            channel = Optional.empty();
        }
        return Pair.of(channel, event);
    }

}