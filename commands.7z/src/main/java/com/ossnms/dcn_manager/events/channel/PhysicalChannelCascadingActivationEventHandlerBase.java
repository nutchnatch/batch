package com.ossnms.dcn_manager.events.channel;

import com.google.common.base.Throwables;
import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.QNePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.google.common.collect.Iterables.transform;

/**
 * <p>Used as the base for Channel event handlers that need to:</p>
 *
 * <ul>
 *     <li>Cascade activations to child NEs.</li>
 *     <li>Trigger the activation of sibling standby Channel instances.</li>
 * </ul>
 */
abstract class PhysicalChannelCascadingActivationEventHandlerBase<C extends CallContext, P extends PhysicalChannelStateEvent, L extends ActualChannelStateEvent>
        extends PhysicalChannelEventHandlerBase<C, P, L> {

    private final NetworkElementManagers networkElementManagers;
    private final MediatorManagers mediatorManagers;

    public PhysicalChannelCascadingActivationEventHandlerBase(
            @Nonnull C context,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull NetworkElementManagers networkElementManagers,
            @Nonnull MediatorManagers mediatorManagers) {
        super(context, channelManagers);
        this.networkElementManagers = networkElementManagers;
        this.mediatorManagers = mediatorManagers;
    }

    @Override
    protected void onMutationApplied(ChannelPhysicalConnectionData updatedPhysicalConnection,
                                     ChannelPhysicalConnectionBehavior state, ChannelManagers channelManagers) {

        cascadeActivationToChildNEs(updatedPhysicalConnection);

        if (updatedPhysicalConnection.isActive()) {
            findStandbyChannelsForActivation(channelManagers, updatedPhysicalConnection)
                    .forEach(instance -> activateChannelInstance(channelManagers, instance));
        }
    }

    /**
     * Cascade physical channel activation to physical NEs.
     * Always cascade if activating the active channel; cascade only to already activated active NEs if activating the standby channel.
     */
    private void cascadeActivationToChildNEs(ChannelPhysicalConnectionData updatedPhysicalConnection) {
        final Stream<NePhysicalConnectionData> neInstancesToActivate;
        final Stream<NePhysicalConnectionData> allChildNes =
            getChildPhysicalNEsRequiredActive(updatedPhysicalConnection.getLogicalChannelId()).stream();
        if (updatedPhysicalConnection.isActive()) {
            neInstancesToActivate =
                allChildNes
                    .filter(NePhysicalConnectionData::isActive)
                    .filter(instance -> instance.getChannelInstanceId() == updatedPhysicalConnection.getId());
        } else {
            neInstancesToActivate =
                allChildNes
                    .collect(Collectors.groupingBy(NePhysicalConnectionData::getLogicalNeId)).values().stream()
                    .filter(this::isNeActiveInstanceActivated)
                    .map(instances -> chooseDeactivatedInactiveInstanceForActivation(instances, updatedPhysicalConnection.getId()))
                    .filter(Optional::isPresent).map(Optional::get);
        }
        neInstancesToActivate
            .forEach(neInstance -> activateNeInstance(updatedPhysicalConnection.getMediatorInstanceId(), neInstance));
    }

    private void activateNeInstance(int mediatorId, NePhysicalConnectionData connection) {
        final Optional<NePhysicalConnectionMutationDescriptor> neMutation =
            new NePhysicalConnectionBehavior(connection, networkElementManagers.getNeNotifications())
                .startUp(networkElementManagers.getNeActivationManager(), mediatorId);
        if (neMutation.isPresent()) {
            try {
                final Optional<NePhysicalConnectionData> neUpdatedConnection =
                        networkElementManagers.getNeInstanceRepository().tryUpdate(neMutation.get());
                if (!neUpdatedConnection.isPresent()) {
                    getLogger().info("Automatic activation of NE Physical Connection {} was not possible.", connection);
                }
            } catch (final RepositoryException exception) {
                getLogger().error("Automatic NE activation on {} failed: {} {}", connection,
                        exception.getMessage(), Throwables.getStackTraceAsString(exception));
            }
        } else {
            getLogger().info("Automatic transition to STARTING UP of Physical NE Connection {} was not possible.", connection);
        }
    }

    private List<NePhysicalConnectionData> getChildPhysicalNEsRequiredActive(int channelId) {
        final ImmutableList<Integer> childRequiredActiveNeIds = ImmutableList.copyOf(
            transform(getChildNEsRequiredActive(channelId), NeInfoData::getId));
        final QNePhysicalConnectionData conn = QNePhysicalConnectionData.nePhysicalConnectionData;
        return networkElementManagers.getNeInstanceRepository().query(conn)
            .where(conn.logicalNeId.in(childRequiredActiveNeIds))
            .list(conn);
    }

    private Iterable<NeInfoData> getChildNEsRequiredActive(int logicalChannelId) {
        try {
            return networkElementManagers.getNeRepository().queryActivationRequiredIs(logicalChannelId, RequiredActivationState.ACTIVE);
        } catch (final RepositoryException e) {
            getLogger().error("Failed to get child NEs required active for channel {} : {}", logicalChannelId,
                    Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

    private boolean isNeActiveInstanceActivated(List<NePhysicalConnectionData> neInstances) {
        return neInstances.stream()
                .filter(NePhysicalConnectionData::isActive)
                .filter(NePhysicalConnectionData::isActiveState)
                .findAny()
                .isPresent();
    }

    private Optional<NePhysicalConnectionData> chooseDeactivatedInactiveInstanceForActivation(List<NePhysicalConnectionData> neInstances, int targetPhysicalChannelId) {
        return neInstances.stream()
                .filter(instance -> !instance.isActive())
                .filter(instance -> instance.getChannelInstanceId() == targetPhysicalChannelId)
                .filter(instance -> instance.getActualActivationState() == ActualActivationState.DISCONNECTED || instance.getActualActivationState() == ActualActivationState.FAILED)
                .findFirst();
    }

    private void activateChannelInstance(
            ChannelManagers channelManagers, ChannelPhysicalConnectionData instanceConnection) {
        final RequiredChannelStateEvent.Activate activationEvent =
                new RequiredChannelStateEvent.Activate(instanceConnection.getLogicalChannelId(),
                        instanceConnection.getMediatorInstanceId(), Collections.singleton(instanceConnection.getId()));
        final Optional<ChannelPhysicalConnectionMutationDescriptor> connectMutation =
                new ChannelPhysicalConnectionBehavior(instanceConnection, channelManagers.getChannelNotifications())
                        .startUp(channelManagers.getChannelActivationManager(), activationEvent);
        if (connectMutation.isPresent()) {
            try {
                final Optional<ChannelPhysicalConnectionData> updatedConnection =
                        channelManagers.getChannelInstanceConnections().tryUpdate(connectMutation.get());
                if (!updatedConnection.isPresent()) {
                    getLogger().warn("Concurrent activation attempt of {} detected.", instanceConnection);
                }
            } catch (RepositoryException e) {
                getLogger().warn("Failed to store automatic activation of {}: {}", instanceConnection,
                        getStackTraceAsString(e));
            }
        }
    }

    private Stream<ChannelPhysicalConnectionData> findStandbyChannelsForActivation(
            ChannelManagers channelManagers, ChannelPhysicalConnectionData activatedInstance) {

        return StreamSupport.stream(
                channelManagers.getChannelInstanceConnections().queryAll(activatedInstance.getLogicalChannelId()).spliterator(),
                false)
                .filter(c -> !c.isActive())
                .filter(c -> c.getId() != activatedInstance.getId())
                .filter(this::isParentPhysicalMediatorActive);

    }

    private boolean isParentPhysicalMediatorActive(ChannelPhysicalConnectionData channelConnection) {
        try {
            return mediatorManagers
                    .getMediatorInstanceRepository()
                    .getMediatorPhysicalConnectionRepository()
                    .query(channelConnection.getMediatorInstanceId())
                    .map(m -> m.getActualActivationState() == com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState.ACTIVE)
                    .orElse(false);
        } catch (RepositoryException e) {
            getLogger().warn("Failed to determine physical mediator for physical channel {}: {}",
                    channelConnection, getStackTraceAsString(e));
            return false;
        }
    }
}
