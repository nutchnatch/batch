package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.mediator.behavior.MediatorPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatingEvent;
import com.ossnms.dcn_manager.events.base.MediatorManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

public class PhysicalMediatorDeactivatingEventHandler<C extends CallContext> extends
        PhysicalMediatorEventHandlerBase<C, PhysicalMediatorDeactivatingEvent, MediatorDeactivatingEvent> {

    public PhysicalMediatorDeactivatingEventHandler(@Nonnull C context,
            @Nonnull MediatorManagers mediatorManagers) {
        super(context, mediatorManagers);
    }

    @Override
    protected Optional<MediatorPhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalMediatorDeactivatingEvent event, MediatorPhysicalConnectionBehavior state, MediatorManagers mediatorManagers) {
        return state.setDeactivating(mediatorManagers.getMediatorNotifications());
    }

    @Override
    protected MediatorDeactivatingEvent produceForwardingEvent(PhysicalMediatorDeactivatingEvent event, MediatorPhysicalConnectionData mediatorConnectionState) {
        return new MediatorDeactivatingEvent(mediatorConnectionState.getLogicalMediatorId(), event);
    }

}
