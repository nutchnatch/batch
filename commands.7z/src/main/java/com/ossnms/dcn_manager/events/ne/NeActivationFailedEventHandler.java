package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NeConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeActivationFailedEvent;
import com.ossnms.dcn_manager.core.outbound.Alarms;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;

import javax.annotation.Nonnull;
import java.util.Optional;

public class NeActivationFailedEventHandler<C extends CallContext> extends
        NeConnectionEventHandlerBase<C, NeActivationFailedEvent> {

    private final Alarms alarms;

    public NeActivationFailedEventHandler(@Nonnull C context,
            @Nonnull NeEntityRepository repository,
            @Nonnull NetworkElementNotifications notifications,
            @Nonnull Alarms alarms) {
        super(context, repository, notifications);
        this.alarms = alarms;
    }

    @Override
    protected Optional<NeConnectionMutationDescriptor> triggerMutation(
            NeConnectionBehavior behavior, NeActivationFailedEvent event) {
        return behavior.setFailed(event.getDetailedDescription(), alarms);
    }

}
