package com.ossnms.dcn_manager.events.ne;

import com.google.common.collect.Maps;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NeDomainsUpdater;
import com.ossnms.dcn_manager.composables.ne.NePropertiesUpdater;
import com.ossnms.dcn_manager.composables.ne.NePropertiesUpdater.OnDuplicateRoutes;
import com.ossnms.dcn_manager.composables.ne.UpdateNePropertiesBase;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NePropertiesChangedEvent;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.properties.EntityPropertyOperations.Scope;
import com.ossnms.dcn_manager.core.properties.ne.NeProperty;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.DuplicatedRouteException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class UpdateNePropertiesEventHandler<C extends CallContext>
        extends EventHandler<C, NePropertiesChangedEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateNePropertiesEventHandler.class);

    private final UpdateNePropertiesBase<C> base;

    private final Set<String> privateNePropertyNames = Arrays.stream(NeProperty.values())
            .filter(property -> property.getScope() == Scope.PRIVATE)
            .map(NeProperty::getName)
            .collect(Collectors.toSet());

    private static final OnDuplicateRoutes DUPLICATE_ROUTE_LOGGER = new OnDuplicateRoutes() {
        @Override
        public void respondToDuplicatedRoutes(@Nonnull Iterable<String> duplicatedRouteKeys, String from, String to)
                throws DuplicatedRouteException {
            LOGGER.warn("Duplicated route keys during update in gateway route: {}", duplicatedRouteKeys);
        }

        @Override
        public void respondToDuplicatedDirectRoute(@Nonnull String duplicatedRouteKey, String from, String to)
                throws DuplicatedRouteException {
            LOGGER.warn("Duplicated route key during update in direct route: {}", duplicatedRouteKey);
        }
    };

    private final NePhysicalConnectionRepository physicalConnectionRepository;

    public UpdateNePropertiesEventHandler(C context,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull StaticConfiguration configuration,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull DomainRepository domainRepository,
            @Nonnull DomainNotifications domainNotifications,
            @Nonnull SystemRepository systemRepository,
            @Nonnull SettingsRepository settingsRepository) {
        super(context);
        this.physicalConnectionRepository = neManagers.getNeInstanceRepository();
        this.base = new UpdateNePropertiesBase<>(configuration, neManagers.getNeActivationManager(),
                new NePropertiesUpdater<>(context, neManagers.getNeRepository(), systemRepository, loggerManager, neManagers.getNeNotifications(),
                        new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository), DUPLICATE_ROUTE_LOGGER));
    }

    @Override
    public void handleEvent(NePropertiesChangedEvent event)
            throws DcnManagerException {
        /* Apply updated properties but ignore those that are private to DCN Manager: these are not meant to
         * be changed through mediation notifications.
         * (due to the immutable nature of events, we must create a mutable copy of the event's properties)
         */
        final HashMap<String, String> updatedProperties = new HashMap<>(
                Maps.filterKeys(event.getPropertiesChanged(), key -> !privateNePropertyNames.contains(key)));
        final Optional<NeEntity> updatedNeEntity = base.applyUpdate(event.getNeId(), updatedProperties);
        if (updatedNeEntity.isPresent()) {
            final NeEntity updatedNe = updatedNeEntity.get();
            StreamSupport.stream(
                        physicalConnectionRepository.queryAll(updatedNe.getInfo().getNeId()).spliterator(),
                        false)
                    .filter(NePhysicalConnectionData::isConnected)
                    .forEach(neInstance -> base.updateNeProperties(updatedNe, neInstance,
                            new NeUserPreferencesMutationDescriptor(updatedNe.getPreferences())
                    ));
        }

    }

}
