package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.mediator.behavior.MediatorPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatingEvent;
import com.ossnms.dcn_manager.events.base.MediatorManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

public class PhysicalMediatorActivatingEventHandler<C extends CallContext> extends
        PhysicalMediatorEventHandlerBase<C, PhysicalMediatorActivatingEvent, MediatorActivatingEvent> {

    public PhysicalMediatorActivatingEventHandler(@Nonnull C context,
            @Nonnull MediatorManagers mediatorManagers) {
        super(context, mediatorManagers);
    }

    @Override
    protected Optional<MediatorPhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalMediatorActivatingEvent event, MediatorPhysicalConnectionBehavior state, MediatorManagers mediatorManagers) {
        return state.setActivating(mediatorManagers.getMediatorNotifications());
    }

    @Override
    protected MediatorActivatingEvent produceForwardingEvent(PhysicalMediatorActivatingEvent event, MediatorPhysicalConnectionData mediatorConnectionState) {
        return new MediatorActivatingEvent(mediatorConnectionState.getLogicalMediatorId(), event);
    }

}
