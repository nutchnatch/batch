package com.ossnms.dcn_manager.events.discovery;

import com.google.common.base.Objects;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Optional;

final class ChannelSupportsNeType<C extends CallContext>
        extends DiscoveryFilterBase<C, Pair<Optional<ChannelInfoData>, NeDiscoveredEvent>> {

    private final StaticConfiguration configuration;

    public ChannelSupportsNeType(C context, LoggerManager<C> logManager,
            StaticConfiguration configuration) {
        super(context, logManager);
        this.configuration = configuration;
    }

    @Override
    public Boolean call(Pair<Optional<ChannelInfoData>, NeDiscoveredEvent> data) {
        final NeDiscoveredEvent event = data.getRight();
        final String proxyType = event.getCreateDescriptor().getTypeName();
        final ChannelInfoData channelInfo = data.getLeft().get();
        if (channelSupportsNeProxyType(proxyType, channelInfo)) {
            return true;
        } else {
            reportWarning(event,
                    "New NE was found but type <{}> is unsupported under Channel of type {} with Id={}",
                    proxyType, channelInfo.getType(), channelInfo.getId());
            return false;
        }
    }

    private Boolean channelSupportsNeProxyType(final String proxyType, ChannelInfoData channelInfoData) {
        final ChannelType channelType = configuration.getChannelTypes().get(channelInfoData.getType());
        final Optional<NeType> neType = channelType.getSupportedNeTypes().stream().filter(input -> Objects.equal(input.getName(), proxyType)).findFirst();
        return neType.isPresent();
    }
}