package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.QNePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectedEvent;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.stream.Collectors;

public class PhysicalChannelDeactivatedEventHandler<C extends CallContext> extends
        PhysicalChannelEventHandlerBase<C, PhysicalChannelDeactivatedEvent, ChannelDeactivatedEvent> {

    private final NetworkElementManagers neManagers;

    public PhysicalChannelDeactivatedEventHandler(@Nonnull C context,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull NetworkElementManagers neManagers) {
        super(context, channelManagers);
        this.neManagers = neManagers;
    }

    @Override
    protected Optional<ChannelPhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalChannelDeactivatedEvent event, ChannelPhysicalConnectionBehavior state,
            ChannelManagers channelManagers) {
        return state.setInactive(channelManagers.getChannelActivationManager(), neManagers.getNeEvents(),
                getChildNesForDeactivation(event.getChannelId()));
    }

    @Override
    protected ChannelDeactivatedEvent produceForwardingEvent(PhysicalChannelDeactivatedEvent event,
            ChannelPhysicalConnectionData channelConnectionState) {
        return new ChannelDeactivatedEvent(event.getLogicalChannelId(), event);
    }

    private Iterable<PhysicalNeDisconnectedEvent> getChildNesForDeactivation(Integer physicalChannelId) {
        final QNePhysicalConnectionData qconn = QNePhysicalConnectionData.nePhysicalConnectionData;
        return neManagers.getNeInstanceRepository().query(qconn)
            .where(qconn.channelInstanceId.eq(physicalChannelId)
                .and(qconn.activationState.ne(ActualActivationState.DISCONNECTED)))
            .list(qconn)
            .stream()
            .map(conn -> new PhysicalNeDisconnectedEvent(conn.getId(), conn.getLogicalNeId(), conn.isActive()))
            .collect(Collectors.toList());
    }
}
