package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectedEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.google.common.base.Throwables.getStackTraceAsString;

/**
 * Handles events requesting a physical NE connection to switch to the DISCONNECTED state.
 */
public class PhysicalNeDisconnectedEventHandler<C extends CallContext> extends
        PhysicalNeStatusEventHandlerBase<C, PhysicalNeDisconnectedEvent, NeDisconnectedEvent> {

    private final ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;

    public PhysicalNeDisconnectedEventHandler(
            @Nonnull C context,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository) {
        super(context, neManagers);
        this.channelPhysicalConnectionRepository = channelPhysicalConnectionRepository;
    }

    @Override
    protected Optional<NePhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalNeDisconnectedEvent event, NePhysicalConnectionBehavior state,
            NetworkElementManagers neManagers) {
        return state.setDisconnected(neManagers.getNeActivationManager());
    }

    @Override
    protected NeDisconnectedEvent produceForwardingEvent(PhysicalNeDisconnectedEvent event,
            NePhysicalConnectionData neConnectionState) {
        return new NeDisconnectedEvent(event.getLogicalNeId(), event);
    }

    @Override
    protected void onMutationApplied(NePhysicalConnectionData updatedPhysicalConnection,
            NePhysicalConnectionBehavior state, NetworkElementManagers neManagers) {

        if (updatedPhysicalConnection.getActualActivationMode() == ActualActivationMode.RESTART) {
            scheduleNeStartUp(updatedPhysicalConnection, neManagers);
        }
    }

    private void scheduleNeStartUp(NePhysicalConnectionData updatedPhysicalConnection, NetworkElementManagers neManagers) {
        try {
            final ChannelPhysicalConnectionData channelInstance =
                    findChannelInstance(channelPhysicalConnectionRepository, updatedPhysicalConnection.getChannelInstanceId());
            final Optional<NePhysicalConnectionMutationDescriptor> restart =
                    new NePhysicalConnectionBehavior(updatedPhysicalConnection, neManagers.getNeNotifications())
                            .startUp(neManagers.getNeActivationManager(), channelInstance.getMediatorInstanceId());
            if (restart.isPresent()) {
                final Optional<NePhysicalConnectionData> result =
                        neManagers.getNeInstanceRepository().tryUpdate(restart.get());
                if (!result.isPresent()) {
                    getLogger().warn("Could not restart the NE after disconnection: concurrent modification on {}", updatedPhysicalConnection);
                }
            }
        } catch (RepositoryException | UnknownChannelIdException | UnknownNetworkElementIdException e) {
            getLogger().error("Could not restart the NE after disconnection: error on {}: {}", updatedPhysicalConnection,
                    getStackTraceAsString(e));
        }
    }
}
