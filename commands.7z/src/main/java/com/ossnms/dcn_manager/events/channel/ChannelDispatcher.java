package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.*;
import com.ossnms.dcn_manager.core.events.channel.ChannelPropertiesChangedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.*;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.EventDispatcher;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import javax.annotation.Nonnull;

/**
 * Subscribes to an inbound event stream, dispatching each event to its appropriate handler.
 *
 * @param <C> Context instance type, propagated to handlers that need one.
 */
public class ChannelDispatcher<C extends CallContext> extends EventDispatcher<C> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelDispatcher.class);

    private final SettingsRepository settings;
    private final ChannelManagers channelManagers;
    private final NetworkElementManagers networkElementManagers;
    private final MediatorManagers mediatorManagers;

    public ChannelDispatcher(
            @Nonnull C context,
            @Nonnull StaticConfiguration configuration,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull SettingsRepository settings,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull NetworkElementManagers networkElementManagers,
            @Nonnull MediatorManagers mediatorManagers) {
        super(context, configuration, loggerManager);
        this.settings = settings;
        this.channelManagers = channelManagers;
        this.networkElementManagers = networkElementManagers;
        this.mediatorManagers = mediatorManagers;
    }

    @Override
    public final void initialize(Observable<? extends Event> eventSource) {

        LOGGER.debug("Initializing Channel event dispatcher.");

        subscribe(eventSource, ChannelPropertiesChangedEvent.class,
                new UpdateChannelPropertiesEventHandler<>(getContext(), channelManagers,
                    getConfiguration(), settings, getLoggerManager()));

        subscribe(eventSource, PhysicalChannelActivatingEvent.class,
                new PhysicalChannelActivatingEventHandler<>(getContext(), channelManagers));

        subscribe(eventSource, PhysicalChannelCreatingEvent.class,
                new PhysicalChannelCreatingEventHandler<>(getContext(), channelManagers));

        subscribe(eventSource, PhysicalChannelCreatedEvent.class,
                new PhysicalChannelCreatedEventHandler<>(getContext(), channelManagers, networkElementManagers,
                        mediatorManagers));

        subscribe(eventSource, PhysicalChannelActivatedEvent.class,
                new PhysicalChannelActivatedEventHandler<>(getContext(), channelManagers, networkElementManagers,
                        mediatorManagers));

        subscribe(eventSource, PhysicalChannelDeactivatingEvent.class,
                new PhysicalChannelDeactivatingEventHandler<>(getContext(), channelManagers));

        subscribe(eventSource, PhysicalChannelDeactivatedEvent.class,
                new PhysicalChannelDeactivatedEventHandler<>(getContext(), channelManagers, networkElementManagers));

        subscribe(eventSource, PhysicalChannelActivationFailedEvent.class,
                new PhysicalChannelActivationFailureEventHandler<>(getContext(), channelManagers, networkElementManagers));

        subscribe(eventSource, ChannelActivatingEvent.class,
                new ChannelActivatingEventHandler<>(getContext(), channelManagers));

        subscribe(eventSource, ChannelCreatingEvent.class,
                new ChannelCreatingEventHandler<>(getContext(), channelManagers));

        subscribe(eventSource, ChannelCreatedEvent.class,
                new ChannelCreatedEventHandler<>(getContext(), channelManagers));

        subscribe(eventSource, ChannelActivatedEvent.class,
                new ChannelActivatedEventHandler<>(getContext(), channelManagers));

        subscribe(eventSource, ChannelDeactivatingEvent.class,
                new ChannelDeactivatingEventHandler<>(getContext(), channelManagers));

        subscribe(eventSource, ChannelDeactivatedEvent.class,
                new ChannelDeactivatedEventHandler<>(getContext(), channelManagers, networkElementManagers));

        subscribe(eventSource, ChannelActivationFailedEvent.class,
                new ChannelActivationFailureEventHandler<>(getContext(), channelManagers, networkElementManagers));

    }

}
