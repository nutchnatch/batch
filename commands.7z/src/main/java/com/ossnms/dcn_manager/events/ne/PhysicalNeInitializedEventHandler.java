package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.metrics.NeInitializationMetrics;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializedEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nonnull;
import java.time.Duration;
import java.time.Instant;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.stream.StreamSupport;

import static com.google.common.base.Throwables.getStackTraceAsString;

/**
 * Reacts to an NE completing initialization on a physical connection.
 *
 * Will attempt to start a connection on another physical connection that has not been
 * connected yet. This is an attempt at cascading NE activations on physical connections
 * one after the other so NEs and DCNs are less loaded.
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class PhysicalNeInitializedEventHandler<C extends CallContext> extends
        PhysicalNeStatusEventHandlerBase<C, PhysicalNeInitializedEvent, NeInitializedEvent> {

    private final ChannelPhysicalConnectionRepository channelInstancesRepository;
    private final NeInitializationMetrics initializationMetrics;
    private final NeEntityRepository.NeUserPreferencesRepository preferencesRepository;


    public PhysicalNeInitializedEventHandler(
             @Nonnull C context,
             @Nonnull NetworkElementManagers neManagers,
             @Nonnull ChannelPhysicalConnectionRepository channelInstancesRepository,
             @Nonnull NeInitializationMetrics metrics) {
        super(context, neManagers);
        this.preferencesRepository = neManagers.getNeRepository().getNeUserPreferencesRepository();
        this.channelInstancesRepository = channelInstancesRepository;
        this.initializationMetrics = metrics;
    }

    @Override
    protected Optional<NePhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalNeInitializedEvent event, NePhysicalConnectionBehavior state,
            NetworkElementManagers neManagers) {
        return state.setInitialized(neManagers.getNeActivationManager());
    }

    @Override
    protected NeInitializedEvent produceForwardingEvent(PhysicalNeInitializedEvent event,
            NePhysicalConnectionData neConnectionState) {
        // if the mediation sent updated counters, calculate their difference against current ones.
        final NeSynchronizationData synchronizationCounterDifferences =
            event.getSynchronizationCounters()
                .flatMap(this::calculateDifferencesOfCounters)
                .orElse(null);
        return new NeInitializedEvent(event.getLogicalNeId(), event, synchronizationCounterDifferences);
    }

    @Override
    protected void onMutationApplied(NePhysicalConnectionData updatedPhysicalConnection,
            NePhysicalConnectionBehavior state, NetworkElementManagers neManagers) {

        final Iterable<NePhysicalConnectionData> neInstances =
                neManagers.getNeInstanceRepository().queryAll(updatedPhysicalConnection.getLogicalNeId());

        // start one inactive NE
        StreamSupport.stream(neInstances.spliterator(), false)
                .filter(data -> data.getActualActivationState() != ActualActivationState.INITIALIZED)
                .map(this::tryMatchWithChannel)
                .filter(Optional::isPresent).map(Optional::get)
                .findFirst()
                .ifPresent(data -> triggerInstanceBehavior(data, neManagers, this::startUpInstance));

        // resynchronize all active NEs if the active NE has just been initialized itself.
        if (updatedPhysicalConnection.isActive()) {
            /*
             * Note that we'll try to resynchronize *all* standby instances at once.
             * In scenarios where there is only one, this is effective. Otherwise it
             * may impose an extraordinary burden on the DCN and must be revised.
             */
            StreamSupport.stream(neInstances.spliterator(), false)
                    .filter(data -> ! data.isActive())
                    .filter(data -> data.getActualActivationState() == ActualActivationState.INITIALIZED)
                    .map(this::tryMatchWithChannel)
                    .filter(Optional::isPresent).map(Optional::get)
                    .forEach(data -> triggerInstanceBehavior(data, neManagers, this::resynchronizeInstance));
        }

        publishMetrics(updatedPhysicalConnection);
    }

    private void publishMetrics(NePhysicalConnectionData physicalConnectionData) {
        try {
            preferencesRepository.query(physicalConnectionData.getLogicalNeId())
                .ifPresent(preferences ->
                    physicalConnectionData.getInitStageStartTime()
                            .map(time -> Duration.between(time, Instant.now()))
                            .ifPresent(duration -> {
                                if (preferences.usesGne()) {
                                    initializationMetrics.publishRne(duration);
                                } else {
                                    initializationMetrics.publish(duration);
                                }
                            })
                );
        } catch (RepositoryException e) {
            getLogger().error("Did not publish metrics because of an error reading NE instance {} data. {}",
                    physicalConnectionData, getStackTraceAsString(e));
        }
    }

    private Optional<Pair<NePhysicalConnectionData, ChannelPhysicalConnectionData>> tryMatchWithChannel(NePhysicalConnectionData neInstance) {
        try {
            final Optional<ChannelPhysicalConnectionData> channelInstance =
                    channelInstancesRepository.query(neInstance.getChannelInstanceId());
            if (channelInstance.isPresent() && channelInstance.get().isStateActive()) {
                return Optional.of(ImmutablePair.of(neInstance, channelInstance.get()));
            } else {
                getLogger().warn("Automatic start of NE instance {} is not possible on channel instance {}.", neInstance, channelInstance);
            }
        } catch (final RepositoryException e) {
            getLogger().warn("Failed to find physical channel for NE instance {}: {}", neInstance, getStackTraceAsString(e));
        }
        return Optional.empty();
    }

    private void triggerInstanceBehavior(
            Pair<NePhysicalConnectionData, ChannelPhysicalConnectionData> instance, NetworkElementManagers neManagers,
            BiFunction<Pair<NePhysicalConnectionData, ChannelPhysicalConnectionData>, NetworkElementManagers, Optional<NePhysicalConnectionMutationDescriptor>> behavior) {
        final NePhysicalConnectionData neInstance = instance.getLeft();
        try {
            final Optional<NePhysicalConnectionMutationDescriptor> instanceMutation = behavior.apply(instance, neManagers);
            if (instanceMutation.isPresent()) {
                final Optional<NePhysicalConnectionData> updatedData =
                        neManagers.getNeInstanceRepository().tryUpdate(instanceMutation.get());
                if (!updatedData.isPresent()) {
                    getLogger().warn("Automatic start of NE instance {} is not possible: concurrent modification of {}.", neInstance, instanceMutation.get());
                }
            } else {
                getLogger().warn("Automatic start of NE instance {} is not possible: inappropriate state.", neInstance);
            }
        } catch (final RepositoryException e) {
            getLogger().warn("Failed to start automatically NE instance {}: {}", neInstance, getStackTraceAsString(e));
        }
    }

    private Optional<NePhysicalConnectionMutationDescriptor> startUpInstance(
            Pair<NePhysicalConnectionData, ChannelPhysicalConnectionData> instance, NetworkElementManagers neManagers) {
        return new NePhysicalConnectionBehavior(instance.getLeft(), neManagers.getNeNotifications())
                        .startUp(neManagers.getNeActivationManager(), instance.getRight().getMediatorInstanceId());
    }

    private Optional<NePhysicalConnectionMutationDescriptor> resynchronizeInstance(
            Pair<NePhysicalConnectionData, ChannelPhysicalConnectionData> instance, NetworkElementManagers neManagers) {
        final NePhysicalConnectionData nePhysicalConnection = instance.getLeft();
        final ChannelPhysicalConnectionData channelPhysicalConnection = instance.getRight();
        return new NePhysicalConnectionBehavior(nePhysicalConnection, neManagers.getNeNotifications())
                .resynchronize(neManagers.getNeActivationManager(), nePhysicalConnection.getChannelInstanceId(),
                        channelPhysicalConnection.getMediatorInstanceId());
    }
}
