package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.mediator.MediatorPhysicalConnectionOperations;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.events.periodic.PeriodicActivationVerificationEvent;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.i18n.Message;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.time.Duration;
import java.time.Instant;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Issue an automatic "start up" request should a Mediator physical connection
 * be found in "activation failed" state.
 *
 * Some rules apply, such as the time elapsed since the last failure and the
 * required activation state of the logical Mediator.
 */
public class MediatorActivationVerificationEventHandler<C extends CallContext>
        extends EventHandler<C, PeriodicActivationVerificationEvent> {

    private static final Logger LOGGER = getLogger(MediatorActivationVerificationEventHandler.class);

    private final MediatorEntityRepository mediatorRepository;
    private final MediatorInstanceEntityRepository mediatorInstancesRepository;
    private final SettingsRepository settingsRepository;
    private final MediatorPhysicalConnectionOperations connectionOperations;
    private final LoggerManager<C> loggerManager;

    public MediatorActivationVerificationEventHandler(@Nonnull C context,
            @Nonnull MediatorManagers mediatorManagers,
            @Nonnull SettingsRepository settingsRepository,
            @Nonnull LoggerManager<C> loggerManager) {
        super(context);
        this.loggerManager = loggerManager;
        this.mediatorRepository = mediatorManagers.getMediatorRepository();
        this.mediatorInstancesRepository = mediatorManagers.getMediatorInstanceRepository();
        this.settingsRepository = settingsRepository;

        this.connectionOperations = new MediatorPhysicalConnectionOperations(
                mediatorRepository,
                mediatorManagers.getMediatorActivationManager(),
                mediatorManagers.getMediatorNotifications(),
                mediatorInstancesRepository);
    }

    @Override
    protected void handleEvent(@Nonnull PeriodicActivationVerificationEvent event)
            throws DcnManagerException {
        final boolean standbyConnectionsAllowed = settingsRepository.areStandbyConnectionsAllowed();

        StreamSupport.stream(mediatorRepository.queryAll().spliterator(), false)
            .filter(mediator -> mediator.getInfo().isActivationRequired())
            .flatMap(mediator -> queryPhysicalConnections(mediator, standbyConnectionsAllowed))
            .filter(pair -> pair.getValue().getActualActivationState() == ActualActivationState.FAILED)
            .filter(pair -> hasFailureRetryIntervalElapsed(pair.getValue()))
            .filter(pair -> isNumberOfRetriesUnderLimit(pair.getValue()))
            .forEach(this::retryMediatorConnection);

    }

    private Stream<Pair<String, MediatorPhysicalConnectionData>> queryPhysicalConnections(MediatorEntity instance, boolean standbyConnectionsAllowed) {
        /*
         Return active physical instances. Include inactive ("standby") physical instances only if
         the system is allowing standby connections.
         */
        return StreamSupport.stream(
            mediatorInstancesRepository.getMediatorPhysicalConnectionRepository()
                    .queryAll(instance.getInfo().getId()).spliterator(), false)
                .filter(physicalConnection -> physicalConnection.isActive() || standbyConnectionsAllowed)
                .map(physicalConnection -> Pair.of(instance.getInfo().getName(), physicalConnection));
    }

    private boolean hasFailureRetryIntervalElapsed(MediatorPhysicalConnectionData physicalConnection) {
        return physicalConnection.getLastFailureTimestamp()
                .map(ts -> Duration.between(ts, Instant.now()).toMinutes())
                .map(durationMinutes -> durationMinutes >= settingsRepository.getSettings().getRetryInterval())
                .orElse(false);
    }

    private boolean isNumberOfRetriesUnderLimit(MediatorPhysicalConnectionData physicalConnection) {
        final int limit = settingsRepository.getSettings().getMediatorRetries();
        return limit == 0 || physicalConnection.getActivationAttemptsCounter() < limit;
    }

    private void retryMediatorConnection(Pair<String, MediatorPhysicalConnectionData> pair) {
        final MediatorPhysicalConnectionData physicalConnection = pair.getValue();

        LOGGER.info("Retrying connection of physical mediator {}.", physicalConnection);

        loggerManager.createSystemEventLog(getContext(),
            new LoggerItemMediator(pair.getKey(), tr(Message.RETRYING_MEDIATOR_NUMBER, physicalConnection.getActivationAttemptsCounter()),
                    MessageSeverity.INFO));

        connectionOperations.triggerMediatorPhysicalConnectionStartingUp(physicalConnection);
    }
}
