package com.ossnms.dcn_manager.events.base;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.functions.Action1;

import javax.annotation.Nonnull;

/**
 * Base class for event handlers. Handlers are invoked with at least one constructor parameter
 * (the context C) and do not produce a return value.
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 * @param <T> The specific type of the event being processed.
 *
 * @see Action1
 */
public abstract class EventHandler<C extends CallContext, T> implements Action1<T> {

    /**
     * Maximum number of times this handler will attempt to process the event upon
     * receiving an exception thrown during processing.
     */
    private static final int MAX_ATTEMPTS = 5;

    private final C context;

    protected EventHandler(@Nonnull C context) {
        this.context = context;
    }

    @Nonnull
    protected C getContext() {
        return context;
    }

    @Override
    public final void call(T event) {
        int attempt = 1;
        final Logger logger = LoggerFactory.getLogger(getClass());
        while (true) {
            try {
                logger.info("Processing event {}.  Attempt {}/{}.", event, attempt, MAX_ATTEMPTS);
                handleEvent(event);
                break;
            } catch (final RuntimeException | DcnManagerException e) {
                if (attempt < MAX_ATTEMPTS) {
                    logger.warn("Failed to apply event {}, will retry. {}.", event, e.getMessage());
                    attempt++;
                } else {
                    logger.error("Failed to apply event {}. {} {}",
                            event, e.getMessage(), Throwables.getStackTraceAsString(e));
                    break;
                }
            }
        }
    }

    protected abstract void handleEvent(@Nonnull T event) throws DcnManagerException;

}
