package com.ossnms.dcn_manager.events.base;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;

/**
 * Parameter object that holds references to all manager/publisher objects
 * that are commonly used together when handling NE events.
 */
public final class NetworkElementManagers {

    private final NeEntityRepository neRepository;
    private final NePhysicalConnectionRepository neInstanceRepository;
    private final NetworkElementInteractionManager neActivationManager;
    private final NetworkElementNotifications neNotifications;
    private final MessageSource<NeEvent> neEvents;

    /**
     * Create a new object.
     * @param neRepository NE repository.
     * @param neInstanceRepository NE physical connections repository.
     * @param neActivationManager NE activation manager.
     * @param neNotifications NE notification publisher.
     * @param neEvents NE event source.
     */
    public NetworkElementManagers(@Nonnull NeEntityRepository neRepository,
            @Nonnull NePhysicalConnectionRepository neInstanceRepository,
            @Nonnull NetworkElementInteractionManager neActivationManager,
            @Nonnull NetworkElementNotifications neNotifications,
            @Nonnull MessageSource<NeEvent> neEvents) {
        this.neRepository = neRepository;
        this.neInstanceRepository = neInstanceRepository;
        this.neActivationManager = neActivationManager;
        this.neNotifications = neNotifications;
        this.neEvents = neEvents;
    }

    /**
     * @return The NE repository.
     */
    public NeEntityRepository getNeRepository() {
        return neRepository;
    }

    /**
     * @return The physical NE connections repository.
     */
    public NePhysicalConnectionRepository getNeInstanceRepository() {
        return neInstanceRepository;
    }

    /**
     * @return The NE activation manager.
     */
    public NetworkElementInteractionManager getNeActivationManager() {
        return neActivationManager;
    }

    /**
     * @return The NE notification publisher.
     *  Should be used to publish notifications to the outside world
     *  about things that have already happened.
     */
    public NetworkElementNotifications getNeNotifications() {
        return neNotifications;
    }

    /**
     * @return Internal NE event injection point.
     *  Should be used to queue events for internal processing. These
     *  events represent internal message passing or external stimuli.
     */
    public MessageSource<NeEvent> getNeEvents() {
        return neEvents;
    }

}
