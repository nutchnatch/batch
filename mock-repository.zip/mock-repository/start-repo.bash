#!/bin/bash

LOCAL_SERVER_PORT=8085
echo "This script will launch the mock."

cd temp

python -m SimpleHTTPServer $LOCAL_SERVER_PORT
