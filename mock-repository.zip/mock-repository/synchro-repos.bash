#!/bin/bash

echo "This script will synchronize the local repository ('mock') in temp folder with remote repository."
export BASE="http://world-tsp-ci-assurance.is.echonet/nexus/repository/raw-internal/"
echo "Remote repository : $BASE"

[ -z "$REPO_AUTH" ] && echo "Error - Need to set REPO_AUTH environment variable. export REPO_AUTH=login:password" && exit 1;

upload_resource () {
  FILE=$1
  FILE=${FILE:2}
  export RESOURCE="$BASE$FILE"
  echo "Resource : $RESOURCE"

  RESPONSE=`curl -I --write-out "%{http_code}" --silent --output /dev/null $RESOURCE`

  if [[ ! $RESPONSE == "404" ]]; then
    echo "- The resource already exist !"
  else
    echo "- The resource doesn't exist !, upload it ..."
    curl --user "${REPO_AUTH}" --upload-file $1 $RESOURCE
  fi
}

cd temp
echo "Resources :"
export -f upload_resource
find . -type f -exec bash -c 'upload_resource "{}"' \;
