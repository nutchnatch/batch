#!/bin/bash

echo "This script will prepare the local directory and then launch it."

PYTHON_VERSION=2.7.13
GIT_VERSION=2.10.2
MAVEN_VERSION=3.5.0
JENKINS_VERSION=2.80
DOCKER_VERSION=18.03.0
DOCKER_COMPOSE_VERSION=1.21.0
PIGZ_VERSION=2.3.3
JENKINS_PLUGINS_VERSION=8
ANSIBLE_VERSION=2.2.2.0
REMOTE_SERVER=http://world-tsp-ci-assurance.is.echonet/nexus/repository/raw-internal

mkdir -p temp/repository/python
cd temp

echo "Prepare install-ansible.bash"
mkdir -p software/ansible
if [ ! -f "software/ansible/install-ansible.bash" ]; then
  if [ ! -f "../../install-ansible/install.bash" ]; then
    curl $REMOTE_SERVER/software/ansible/install-ansible.bash -o software/ansible/install-ansible.bash;
  else
    cp ../../install-ansible/install.bash software/ansible/install-ansible.bash
  fi
fi

echo "Prepare get-pip.py"
mkdir -p software/python
if [ ! -f "software/python/get-pip.py" ]; then
  curl https://bootstrap.pypa.io/get-pip.py -o software/python/get-pip.py;
fi

echo "Prepare Python-$PYTHON_VERSION.tar.xz"
if [ ! -f "software/python/Python-$PYTHON_VERSION.tar.xz" ]; then
  curl https://www.python.org/ftp/python/$PYTHON_VERSION/Python-$PYTHON_VERSION.tar.xz -o software/python/Python-$PYTHON_VERSION.tar.xz;
fi

echo "Prepare git-$GIT_VERSION.tar.xz"
mkdir -p software/git
if [ ! -f "software/git/git-$GIT_VERSION.tar.xz" ]; then
  curl https://www.kernel.org/pub/software/scm/git/git-$GIT_VERSION.tar.xz -o software/git/git-$GIT_VERSION.tar.xz;
fi

echo "Prepare maven-$MAVEN_VERSION.tar.gz"
mkdir -p software/maven
if [ ! -f "software/maven/maven-$MAVEN_VERSION.tar.gz" ]; then
  curl https://mirrors.ircam.fr/pub/apache/maven/maven-3/$MAVEN_VERSION/binaries/apache-maven-$MAVEN_VERSION-bin.tar.gz -o software/maven/maven-$MAVEN_VERSION.tar.gz;
fi

echo "Prepare jenkins-$JENKINS_VERSION.rpm"
mkdir -p software/jenkins
if [ ! -f "software/jenkins/jenkins-$JENKINS_VERSION.rpm" ]; then
  curl https://ftp.icm.edu.pl/packages/jenkins/redhat/jenkins-$JENKINS_VERSION-1.1.noarch.rpm -o software/jenkins/jenkins-$JENKINS_VERSION.rpm;
fi

echo "Prepare jenkins-plugins-$JENKINS_PLUGINS_VERSION.tar.xz"
mkdir -p repository/jenkins
if [ ! -f "repository/jenkins/jenkins-plugins-$JENKINS_PLUGINS_VERSION.tar.xz" ]; then
  curl $REMOTE_SERVER/repository/jenkins/jenkins-plugins-$JENKINS_PLUGINS_VERSION.tar.xz -o repository/jenkins/jenkins-plugins-$JENKINS_PLUGINS_VERSION.tar.xz;
fi

echo "Prepare docker-ce-$DOCKER_VERSION.ce-1.el7.centos.x86_64.rpm"
mkdir -p software/docker
if [ ! -f "software/docker/docker-ce-$DOCKER_VERSION.ce-1.el7.centos.x86_64.rpm" ]; then
  curl https://download.docker.com/linux/centos/7/x86_64/stable/Packages/docker-ce-$DOCKER_VERSION.ce-1.el7.centos.x86_64.rpm -o software/docker/docker-ce-$DOCKER_VERSION.ce-1.el7.centos.x86_64.rpm;
fi

echo "Prepare pigz-$PIGZ_VERSION-1.el7.centos.x86_64.rpm"
mkdir -p software/docker
if [ ! -f "software/docker/pigz-$PIGZ_VERSION-1.el7.centos.x86_64.rpm" ]; then
  curl http://mirror.centos.org/centos/7/extras/x86_64/Packages/pigz-$PIGZ_VERSION-1.el7.centos.x86_64.rpm -o software/docker/pigz-$PIGZ_VERSION-1.el7.centos.x86_64.rpm;
fi

echo "Prepare docker-compose-Linux-$DOCKER_COMPOSE_VERSION-x86_64"
mkdir -p software/docker
if [ ! -f "software/docker/docker-compose-Linux-$DOCKER_COMPOSE_VERSION-x86_64" ]; then
  curl -k -L https://github.com/docker/compose/releases/download/$DOCKER_COMPOSE_VERSION/docker-compose-Linux-x86_64 -o software/docker/docker-compose-Linux-$DOCKER_COMPOSE_VERSION-x86_64;
fi

echo "Mock server preparation finished. You can start the mock."
