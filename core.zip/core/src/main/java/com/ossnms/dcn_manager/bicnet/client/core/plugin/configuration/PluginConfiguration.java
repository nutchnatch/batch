package com.ossnms.dcn_manager.bicnet.client.core.plugin.configuration;

import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.dcn_manager.bicnet.client.service.facade.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.common.servicelocator.ServiceLocator;

/**
 * DCN plug-in configuration.
 */
public class PluginConfiguration {

    public static PluginConfiguration builder() {
        return new PluginConfiguration();
    }
    
    /**
     *  Initialize the configuration.
     */
    public void load() {
        BiCNetServiceLocator.getInstance().registerServiceLocator(BiCNetComponentType.DCN_MANAGER, ServiceLocator.getInstance());

        /* Loads the Types configuration from XML configuration */
        StaticConfigurationSingleton.getInstance();
    }
}
