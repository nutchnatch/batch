/**
 * Contains the core classes for the Bicnet Plugin definition.
 */
package com.ossnms.dcn_manager.bicnet.client.core.plugin;