package com.ossnms.dcn_manager.bicnet.client.core.notification.configuration;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginTopicListener;
import com.ossnms.bicnet.framework.client.listeners.FrameworkAbstractLogonListener;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration.TOPIC_FACTORY_NAME;
import static com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration.TOPIC_NAME;

/**
 * Helps the Notification Manager on Log-on/Log-off events.
 */
public class NotificationLogonListener extends FrameworkAbstractLogonListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationLogonListener.class);
    
    private final DcnPluginHelper pluginHelper;
    private final BiCNetPluginTopicListener topicListener;

    public NotificationLogonListener(@Nonnull final DcnPluginHelper pluginHelper, @Nonnull final BiCNetPluginTopicListener topicListener) {
        this.pluginHelper = pluginHelper;
        this.topicListener = topicListener;
    }

    /**
     * Subscribe the server topic.
     */
    @Override
    protected void eventUserLoggedOn(@Nonnull final ISessionContext sessionContext) {
        try {
            pluginHelper.initialize(sessionContext);
            pluginHelper.getCfPluginSite().subscribeServerTopic(TOPIC_FACTORY_NAME.getName(), TOPIC_NAME.getName(), topicListener);
        } catch (final BiCNetPluginException e) {
            LOGGER.error("Error to subscribe ServerTopic", e);
        }
    }

    /**
     * Unsubscribe the server topic.
     */
    @Override
    protected void eventUserLoggedOff(@Nonnull final ISessionContext sessionContext) {
        pluginHelper.getCfPluginSite().unsubscribeServerTopic(TOPIC_FACTORY_NAME.getName(), TOPIC_NAME.getName(), topicListener);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected BiCNetPluginSite getPluginSite() {
        return pluginHelper.getCfPluginSite();
    }
}
