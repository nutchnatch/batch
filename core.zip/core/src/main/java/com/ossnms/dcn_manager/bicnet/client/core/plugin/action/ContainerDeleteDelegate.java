package com.ossnms.dcn_manager.bicnet.client.core.plugin.action;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobDelete;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Public action for Containers Deletion.
 */
class ContainerDeleteDelegate implements PublicActionDelegate {

    private final RepositoryManager repositoryManager;
    private final CommonServices commonServices;

    ContainerDeleteDelegate(RepositoryManager repositoryManager, CommonServices commonServices) {

        this.commonServices = commonServices;
        this.repositoryManager = repositoryManager;
    }

    @Override public boolean isActionAllowed(@Nonnull final IManagedObject[] managedObjects) {
        return hasPermission(managedObjects) && !filter(managedObjects).isEmpty();
    }

    @Override public void executeJob(final IManagedObject[] managedObjects) throws BiCNetPluginException {
        final List<Integer> keys = filter(managedObjects).stream().map(IGenericContainer::getId).collect(Collectors.toList());

        if (!keys.isEmpty()) {
            ISessionContext context = commonServices.getDcnPluginHelper().getSessionContext();
            BicnetServerFacade bicnetServerFacade = commonServices.getBicnetServerFacade();

            commonServices.getDcnPluginHelper().queueJob(
                    new JobDelete<>(context, bicnetServerFacade, keys, repositoryManager.getContainerRepository()));
        }
    }

    @Override public Collection<String> getElementNames(IManagedObject[] managedObjects) {
        return filter(managedObjects).stream()
                .filter(IGenericContainer.class::isInstance)
                .map(IGenericContainer::getIdName).collect(Collectors.toList());
    }

    private boolean hasPermission(@Nonnull final IManagedObjectId[] managedObjects) {
        return commonServices.getSecureActionValidation().checkPermission(SecureAction.OP_DELETE_SAN, managedObjects);
    }

    private Collection<IGenericContainer> filter(final IManagedObject[] managedObjects) {
        try {
            final List<Integer> keys = Arrays.stream(managedObjects)
                    .filter(IGenericContainer.class::isInstance)
                    .map(IGenericContainer.class::cast)
                    .map(IGenericContainer::getId)
                    .filter(this::hasNoAssignment)
                    .collect(Collectors.toList());

            return repositoryManager.getContainerRepository().get(keys);
        } catch (RepositoryException e) {
            Throwables.propagate(e);
        }
        return Collections.emptyList();
    }

    private boolean hasNoAssignment(final int containerId) {
        try {
            return hasNoContainerAssignments(containerId) &&
                    hasNoSystemAssignments(containerId) &&
                    hasNoNeAssignments(containerId);
        } catch (RepositoryException e) {
            Throwables.propagate(e);
        }
        return false;
    }

    private boolean hasNoNeAssignments(final int containerId) throws RepositoryException {
        return repositoryManager.getNEContainerAssignmentRepository().queries().findByContainerId(containerId)
                .isEmpty();
    }

    private boolean hasNoSystemAssignments(final int containerId) throws RepositoryException {
        return repositoryManager.getSystemContainerAssignmentRepository().queries()
                .findByContainerId(containerId).isEmpty();
    }

    private boolean hasNoContainerAssignments(final int containerId) throws RepositoryException {
        return repositoryManager.getContainerRepository().queries().findByParentId(containerId).isEmpty();
    }
}
