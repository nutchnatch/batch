package com.ossnms.dcn_manager.bicnet.client.core.notification.configuration;

/**
 * Connection Factory configuration. 
 */
public enum NotificationTopicConfiguration {

    TOPIC_FACTORY_NAME("ConnectionFactoryHornetQ"), 
    TOPIC_NAME("topic/client"),
    SENDER_ID("SenderId");
 
    private String name;
    
    private NotificationTopicConfiguration(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
}
