package com.ossnms.dcn_manager.bicnet.client.core.plugin;

import java.util.Collection;

import javax.annotation.Nonnull;

import com.ossnms.bicnet.bcb.facade.security.ILogonListener;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;

/**
 *  Register/unregister the supported DCN log-on listeners.
 *  
 *  @see com.ossnms.dcn_manager.bicnet.client.core.plugin.LogonListenersBuilder
 */
public class LogonListeners {

    private final Collection<ILogonListener> listeners;
    private final IPluginSecurityProvider securityProvider;
    
    public LogonListeners(@Nonnull final Collection<ILogonListener> listeners, @Nonnull final IPluginSecurityProvider securityProvider) {
        super();
        this.listeners = listeners;
        this.securityProvider = securityProvider;
    }

    /**
     *  Register the log-on listeners on Security Manager facade.
     */
    public void register() {
        for (final ILogonListener logonListener : listeners) {
            securityProvider.addLogonListener(logonListener);
        }
    }

    /**
     *  Unregister the log-on listeners on Security Manager facade.
     */
    public void unregister() {
        for (final ILogonListener logonListener : listeners) {
            securityProvider.removeLogonListener(logonListener);
        }       
    }
}
