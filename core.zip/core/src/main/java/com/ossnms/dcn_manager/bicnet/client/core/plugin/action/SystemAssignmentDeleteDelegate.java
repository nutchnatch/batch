package com.ossnms.dcn_manager.bicnet.client.core.plugin.action;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobSystemAssignmentRemove;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;

import static java.util.Arrays.stream;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

/**
 * Public action for System assignment Deletion.
 */
class SystemAssignmentDeleteDelegate implements PublicActionDelegate {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SystemAssignmentDeleteDelegate.class);

	private final RepositoryManager repositoryManager;
    private final CommonServices commonServices;

    SystemAssignmentDeleteDelegate(RepositoryManager repositoryManager, CommonServices commonServices) {
    	this.repositoryManager = repositoryManager;
    	this.commonServices = commonServices;
    }

    @Override public boolean isActionAllowed(@Nonnull final IManagedObject[] managedObjects) {
        return hasPermission(managedObjects) && !filter(managedObjects).isEmpty();
    }

    @Override public void executeJob(final IManagedObject[] managedObjects) throws BiCNetPluginException {
        final Collection<ISystemGenericContainerAssignmentId> assignments = filter(managedObjects)
                .stream()
                .map(ISystemGenericContainerAssignment::getSystemGenericContainerAssignmentId)
                .collect(toList());

        if (!assignments.isEmpty()) {
            ISessionContext context = commonServices.getDcnPluginHelper().getSessionContext();
            BicnetServerFacade bicnetServerFacade = commonServices.getBicnetServerFacade();

            commonServices.getDcnPluginHelper().queueJob(
                    new JobSystemAssignmentRemove(context, bicnetServerFacade, assignments));
        }
    }

    @Override public Collection<String> getElementNames(IManagedObject[] managedObjects) {
        if (filter(managedObjects).stream().anyMatch(ISystemGenericContainerAssignment.class::isInstance)) {
            return Collections.singletonList("System Assignment");
        }
        return emptyList();
    }

    private boolean hasPermission(@Nonnull final IManagedObjectId[] managedObjects) {
        return commonServices.getSecureActionValidation().checkPermission(SecureAction.OP_DELETE_SAN, managedObjects);
    }

    private Collection<ISystemGenericContainerAssignment> filter(final IManagedObject[] managedObjects) {
        return stream(managedObjects)
                .filter(ISystemGenericContainerAssignment.class::isInstance)
                .map(ISystemGenericContainerAssignment.class::cast)
                .filter(this::withOnlyVisibleNes)
                .collect(toList());
    }
    
    private boolean withOnlyVisibleNes(ISystemGenericContainerAssignment systemAssignment) {
        return Optional.ofNullable(systemAssignment)
                .map(ISystemGenericContainerAssignment::getSystemContainer)
                .map(this::nesUnderSystem)
                .filter(this::areVisible)
                .isPresent();
    }

    private Collection<INEId> nesUnderSystem(ISystemContainerId systemContainerId) {
    	try {
    		return repositoryManager.getNeRepository().queries()
    				.findBySystemContainerId(systemContainerId.getId())
    				.stream()
    				.map(FullNeData::getNe)
    				.collect(toList());
    	} catch (RepositoryException e) {
    		LOGGER.error("Failed to access repository", e);
            return emptyList();
        }
    }

    private boolean areVisible(Collection<INEId> ineIds) {
        return commonServices.getSecureActionValidation().checkVisibility(ineIds);
    }
}
