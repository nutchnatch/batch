package com.ossnms.dcn_manager.bicnet.client.core.plugin;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.bicnet.bcb.facade.security.ILogonListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginTopicListener;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationLogonListener;
import com.ossnms.dcn_manager.bicnet.client.core.plugin.configuration.PluginLogonListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.RestoreViews;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ChannelCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ContainerCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.DomainCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.MediatorCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NEContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.SystemContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.SystemContainerCacheManager;

import javax.annotation.Nonnull;
import java.util.Collection;

/**
 * Builds the supported DCN log-on listeners list.
 */
public class LogonListenersBuilder {

    public static LogonListenersBuilder builder() {
        return new LogonListenersBuilder();
    }

    /**
     * Return the supported DCN log-on listeners.
     */
    public LogonListeners build(
            @Nonnull final DcnPluginHelper pluginState, 
            @Nonnull final BiCNetPluginTopicListener topicListener,
            @Nonnull final Iterable<IFrameworkCommand> allRegisteredDCNCommands, 
            @Nonnull final SecureActionValidation secureValidation) {
        return new LogonListeners(listeners(pluginState, topicListener, allRegisteredDCNCommands, secureValidation), pluginState.getSecurityProvider());
    }

    /*
     * WARN: The order of the listeners registration is important because the dependence tree between the log-on/log-off listeners.
     */
    private Collection<ILogonListener> listeners(@Nonnull final DcnPluginHelper pluginState,
                                                 @Nonnull final BiCNetPluginTopicListener topicListener,
                                                 @Nonnull final Iterable<IFrameworkCommand> allRegisteredDCNCommands,
                                                 @Nonnull final SecureActionValidation secureValidation) {

        final Builder<ILogonListener> builder = ImmutableList.builder();
        
        /* Add notification listener to subscribe/unsubscribe the server topic and initialize the session context. */
        builder.add(new NotificationLogonListener(pluginState, topicListener));
            
            /* Add Listeners to initialize/clear the DCN caches  */
        builder.add(MediatorCacheManager.getInstance().buildListener());
        builder.add(ChannelCacheManager.getInstance().buildListener());
        builder.add(ContainerCacheManager.getInstance().buildListener());
        builder.add(SystemContainerCacheManager.getInstance().buildListener());
        builder.add(SystemContainerAssignmentCacheManager.getInstance().buildListener());
        builder.add(NEContainerAssignmentCacheManager.getInstance().buildListener());
        builder.add(DomainCacheManager.getInstance().buildListener());
        builder.add(NeCacheManager.getInstance().buildListener());

            /* Add DNC plug-in listener to restore/save the user opened views */
        builder.add(new PluginLogonListener(pluginState, new RestoreViews(pluginState, allRegisteredDCNCommands, secureValidation), secureValidation));

        return builder.build();
    }
}
