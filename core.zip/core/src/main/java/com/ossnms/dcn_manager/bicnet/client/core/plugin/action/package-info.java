/**
 * Contains the public actions definition.
 */
package com.ossnms.dcn_manager.bicnet.client.core.plugin.action;