package com.ossnms.dcn_manager.bicnet.client.core.plugin.action;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;

import javax.annotation.Nonnull;
import java.util.Collection;

/**
 * Provide public action for the BiCNet plug-ins.
 */
public interface PublicActionDelegate {
    boolean isActionAllowed(@Nonnull IManagedObject[] managedObjects);

    void executeJob(IManagedObject[] managedObjects) throws BiCNetPluginException;

    Collection<String> getElementNames(IManagedObject[] managedObjects);
}
