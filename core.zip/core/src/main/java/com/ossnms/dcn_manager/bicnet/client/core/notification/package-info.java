/**
 * Process the notification from BiCNet Plug-in TopicListener.
 */
package com.ossnms.dcn_manager.bicnet.client.core.notification;