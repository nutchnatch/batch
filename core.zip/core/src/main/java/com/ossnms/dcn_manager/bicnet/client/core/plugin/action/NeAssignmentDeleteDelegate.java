package com.ossnms.dcn_manager.bicnet.client.core.plugin.action;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobNeAssignmentRemove;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.stream.Collectors;

import static java.util.Arrays.stream;

/**
 * Public action for NE assignment Deletion.
 */
class NeAssignmentDeleteDelegate implements PublicActionDelegate {

    private final CommonServices commonServices;

    NeAssignmentDeleteDelegate(CommonServices commonServices) {
        this.commonServices = commonServices;
    }

    @Override public boolean isActionAllowed(@Nonnull final IManagedObject[] managedObjects) {
        return hasPermission(managedObjects) && !filter(managedObjects).isEmpty();
    }

    @Override public void executeJob(final IManagedObject[] managedObjects) throws BiCNetPluginException {
        final Collection<INeGenericContainerAssignmentId> assignments = filter(managedObjects)
                .stream()
                .map(INeGenericContainerAssignment::getNeGenericContainerAssignmentId)
                .collect(Collectors.toList());

        if (!assignments.isEmpty()) {
            ISessionContext context = commonServices.getDcnPluginHelper().getSessionContext();
            BicnetServerFacade bicnetServerFacade = commonServices.getBicnetServerFacade();

            commonServices.getDcnPluginHelper().queueJob(
                    new JobNeAssignmentRemove(context, bicnetServerFacade, assignments));
        }
    }

    @Override public Collection<String> getElementNames(IManagedObject[] managedObjects) {
        if (filter(managedObjects).stream().anyMatch(INeGenericContainerAssignment.class::isInstance)) {
            return Collections.singletonList("NE Assignment");
        }
        return Collections.emptyList();
    }

    private boolean hasPermission(@Nonnull final IManagedObjectId[] managedObjects) {
        return commonServices.getSecureActionValidation().checkPermission(SecureAction.OP_DELETE_SAN, managedObjects);
    }

    private Collection<INeGenericContainerAssignment> filter(final IManagedObject[] managedObjects) {
        return stream(managedObjects)
                .filter(INeGenericContainerAssignment.class::isInstance)
                .map(INeGenericContainerAssignment.class::cast)
                .collect(Collectors.toList());
    }
}
