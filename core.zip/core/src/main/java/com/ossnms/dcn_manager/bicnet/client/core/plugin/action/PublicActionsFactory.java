package com.ossnms.dcn_manager.bicnet.client.core.plugin.action;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionType;
import com.ossnms.dcn_manager.bicnet.client.api.action.PluginAction;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Public actions for the BiCNet plug-ins.
 *
 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPlugin#getObjectTypeActions(com.ossnms.bicnet.bcb.model.ManagedObjectType, com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionType)
 */
public class PublicActionsFactory {

    private final Map<Pair<ManagedObjectType, BiCNetPluginActionType>, Collection<PluginAction>> actions = new HashMap<>();
    private final RepositoryManager repositoryManager;
    private final CommonServices commonServices;

    public PublicActionsFactory(RepositoryManager repositoryManager, CommonServices commonServices) {
        this.repositoryManager = repositoryManager;
        this.commonServices = commonServices;

        this.loadGenericContainerActions();
    }

    public PluginAction[] build(@Nonnull final ManagedObjectType objectType,
            @Nonnull final BiCNetPluginActionType actionType) {
        return this.actions.getOrDefault(ImmutablePair.of(objectType, actionType), Collections.emptyList())
                .stream().toArray(PluginAction[]::new);
    }

    private void loadGenericContainerActions() {
        actions.put(
                ImmutablePair.of(ManagedObjectType.NETWORK_VIEW_OBJECT, BiCNetPluginActionType.DELETE),
                ImmutableList.of(new NetworkViewObjectDeletionPluginAction(repositoryManager, commonServices)));
    }
}
