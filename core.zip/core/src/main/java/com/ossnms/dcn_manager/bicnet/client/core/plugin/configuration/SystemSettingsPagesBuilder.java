 package com.ossnms.dcn_manager.bicnet.client.core.plugin.configuration;

import javax.annotation.Nonnull;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPage;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ConfigurationRepository;
import com.ossnms.dcn_manager.bicnet.client.settings.global.document.GlobalSettingsDocument;
import com.ossnms.dcn_manager.bicnet.client.settings.global.view.GlobalSettingsPageView;

/**
 * Builder for System preferences pages.
 */
public class SystemSettingsPagesBuilder {

    /**
     * Builds the Pages to show on System Preferences, regarding the Plug-in Main Context.
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext
     * 
     * @param pluginState 
     * @param repository The System Settings Repository facade
     * @return A Map that contains the context associated with a BiCNetPluginPropertyPage collection.
     */
    public ImmutableMap<BiCNetPluginMainContext, BiCNetPluginPropertyPage[]> build(@Nonnull final FrameworkPluginHelper helper, @Nonnull final ConfigurationRepository repository) {
      
        final BiCNetPluginPropertyPage[] administrationContextPages = {
                new GlobalSettingsPageView(new GlobalSettingsDocument(helper, repository))
        };
        
        return ImmutableMap.of(BiCNetPluginMainContext.ADMINISTRATION, administrationContextPages);
    }
}
