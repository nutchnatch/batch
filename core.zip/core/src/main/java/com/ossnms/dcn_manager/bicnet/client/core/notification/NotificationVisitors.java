package com.ossnms.dcn_manager.bicnet.client.core.notification;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.IVisitor;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ChannelCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ContainerCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.DomainCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.MediatorCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NEContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.SystemContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.SystemContainerCacheManager;

/**
 * List of visitors for BiCNetPluginTopicListener.
 */
class NotificationVisitors {

    /**
     * @return The list of supported visitors.
     */
    public Iterable<IVisitor> list() {
        return ImmutableList.of(
                NeCacheManager.getInstance(), ChannelCacheManager.getInstance(),
                MediatorCacheManager.getInstance(), DomainCacheManager.getInstance(),
                ContainerCacheManager.getInstance(), SystemContainerCacheManager.getInstance(),
                SystemContainerAssignmentCacheManager.getInstance(), NEContainerAssignmentCacheManager.getInstance());
    }
}
