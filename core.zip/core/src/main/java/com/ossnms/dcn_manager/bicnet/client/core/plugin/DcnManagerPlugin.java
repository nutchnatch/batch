package com.ossnms.dcn_manager.bicnet.client.core.plugin;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.licensing.LicenseStatus;
import com.ossnms.bicnet.bcb.model.topoMgmt.INetworkViewId;
import com.ossnms.bicnet.bcb.plugin.BiCNetPlugin;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginAction;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginEmNeChangeListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMapEventType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPage;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettings;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginStatusIndicator;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginTopicListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginWizardStep;
import com.ossnms.bicnet.bcb.plugin.neobject.BiCNetPluginNEObjectProvider;
import com.ossnms.bicnet.util.versions.ClientComponentVersionInfo;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.core.notification.NotificationManager;
import com.ossnms.dcn_manager.bicnet.client.core.plugin.action.MainActionsBuilder;
import com.ossnms.dcn_manager.bicnet.client.core.plugin.action.PublicActionsFactory;
import com.ossnms.dcn_manager.bicnet.client.core.plugin.configuration.PluginConfiguration;
import com.ossnms.dcn_manager.bicnet.client.core.plugin.configuration.SystemSettingsPagesBuilder;
import com.ossnms.dcn_manager.bicnet.client.import_dcn.ImportExport;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.Actions;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.builder.ContextMenuActionsFactory;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.BicnetChangeListenerManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.DcnPluginLabels;
import com.ossnms.dcn_manager.bicnet.client.settings.GlobalPluginSettings;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.tools.jfx.JfxUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.Icon;
import java.util.Collection;
import java.util.Optional;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Implements the DCN BiCNet Client plug-in.
 */
public class DcnManagerPlugin implements BiCNetPlugin, BiCNetPluginNEObjectProvider  {

    private static final Logger LOGGER = LoggerFactory.getLogger(DcnManagerPlugin.class);
    private static final String PLUGIN_ID = DcnManagerPlugin.class.getName();
    private static final String ACTION_NOT_SUPPORTED = "The DCN Manager Plug-in has no contribution for this action.";

    private final BiCNetPluginTopicListener topicListener;
    private BiCNetPluginSite pluginSite;
    private LogonListeners logonListenerRegistration;
    private final SystemSettingsPagesBuilder systemSettingsBuilder;

    private final MainActionsBuilder mainActions;
    private final RepositoryManager repositoryManager;
    private final CommonServices commonServices;

    private final BicnetChangeListenerManager bicnetChangeListenerManager;
    private final ContextMenuActionsFactory contextMenuActionsFactory;
    private final PublicActionsFactory publicActionsFactory;

    /**
     * Called by BiCNetPlugin manager via reflection on Client initialization
     */
    public DcnManagerPlugin() {
        this(new RepositoryManager(), new CommonServices(), new NotificationManager());
    }

    protected DcnManagerPlugin(@Nonnull final RepositoryManager repositoryManager, @Nonnull final CommonServices commonServices,
            @Nonnull final BiCNetPluginTopicListener topicListener) {
        this.mainActions = new MainActionsBuilder();
        this.systemSettingsBuilder = new SystemSettingsPagesBuilder();
        this.bicnetChangeListenerManager = new BicnetChangeListenerManager();
        this.contextMenuActionsFactory = new ContextMenuActionsFactory(repositoryManager,commonServices);
        this.publicActionsFactory = new PublicActionsFactory(repositoryManager, commonServices);

        this.topicListener = topicListener;
        this.repositoryManager = repositoryManager;
        this.commonServices = commonServices;
    }

    /**
     * @return The {@link LogonListeners}
     */
    public LogonListeners getLogonListener() {
        return logonListenerRegistration;
    }

    /**
     * @return The {@link BiCNetPluginSite}
     */
    public BiCNetPluginSite getPluginSite() {
        return pluginSite;
    }

    /**
     * Sets the site interface of the application for the plug-in. This is the first method called (by TNMS plug-in
     * manager), after the plug-in class instance has been created, like @PostConstruct.
     *
     * @param pluginSite will be initialized by the BiCNet Plug-in manager.
     */
    @Override
    public void setSite(@Nonnull final BiCNetPluginSite pluginSite) {
        this.pluginSite = pluginSite;

        DcnPluginHelper dcnPluginHelper = commonServices.getDcnPluginHelper();
        dcnPluginHelper.setCfPluginSite(pluginSite);
        dcnPluginHelper.setPluginId(PLUGIN_ID);

        logonListenerRegistration = LogonListenersBuilder.builder().build(dcnPluginHelper, topicListener, mainActions.getAllCommands(), commonServices.getSecureActionValidation());
    }

    /**
     * Initializes the plug-in. This method is called after the plug-in class instance has been created and the
     * {@link #setSite(BiCNetPluginSite)} method have been called.
     *
     * @throws BiCNetPluginException if no Security Provider is installed.
     */
    @Override
    public void init() throws BiCNetPluginException {
        PluginConfiguration.builder().load();
        logonListenerRegistration.register();
    }


    /**
     * Destroys the plug-in. This method is called before the application shuts down.
     */
    @Override
    public void destroy() {
        logonListenerRegistration.unregister();
    }

    /**
     * The fully qualified class name.
     */
    @Override
    public String getID() {
        return PLUGIN_ID;
    }

    /**
     * The plug in name.
     */
    @Override
    public String getName() {
        return DcnPluginLabels.PLUGIN_NAME.toString();
    }

    /**
     * The plug-in description.
     */
    @Override
    public String getDescription() {
        return DcnPluginLabels.PLUGIN_DESCRIPTION.toString();
    }

    /**
     * Queries the plug-in for available actions for the main menu or toolbar.
     */
    @Override
    public BiCNetPluginAction[] getMainActions(@Nonnull final BiCNetPluginMainContext context) {
        return mainActions.build().get(context);
    }

    /**
     * Queries the plug-in for available actions for the context menu of managed objects.
     *
     * @param managedObjects Array of objects for which actions are queried.
     * @param environment Environment of objects.
     * @param environmentInfo Additional environment information.
     * @return Array of actions for context.
     */
    @Override
    public BiCNetPluginAction[] getObjectActions(@Nonnull final IManagedObject[] managedObjects,
            @Nullable final IManagedObject environment, @Nullable final String environmentInfo) {
        return contextMenuActionsFactory.build(managedObjects);
    }

    /**
     * Queries the plug-in for available import/export items. Import/export items are listed in the central XML
     * import/export facility of the client frame, so the user can import/export all data at once.
     */
    @Override
    public BiCNetPluginImportExportItem getImportExportItems(final Element root) {
        ImportExport importExport = new ImportExport(repositoryManager, commonServices);
        return importExport.resolveBy(root).buildItems();
    }

    /**
     * Queries the plug-in for available version info items. The plug-in should provide a complete list of all its
     * Client components and their exact versions. The server components should be excluded from this list as their
     * version information is provided by @P SCS. The Client Frame guarantees to call this method in a background
     * thread, so so the plug-in may perform server calls without blocking the user interface.
     */
    @Override
    public ComponentVersionInformation[] getVersionInfoItems() {
        return ClientComponentVersionInfo.getVersionInfo(getClass());
    }

    /**
     * Gets the plug-in configuration settings.
     */
    @Override
    public BiCNetPluginSettings getPluginSettings() {
        return new GlobalPluginSettings(
                getName(),
                commonServices.getDcnPluginHelper().getSessionContext(),
                repositoryManager.getConfigurationRepository()
        ).get();
    }

    /**
     * Queries the plug-in for available actions for the highlight of managed objects in a NetworkView.
     */
    @Override
    public BiCNetPluginAction[] getHighlightActions(@Nonnull final IManagedObject[] managedObjects,
            @Nullable final IManagedObject environment, @Nullable final String environmentInfo) {
        LOGGER.debug(ACTION_NOT_SUPPORTED);
        return null;
    }

    /**
     * Queries the plug-in for available actions for the highlight of managed objects in a NetworkView.
     */
    @Override
    public void notifyUnhighlight(final INetworkViewId networkView) {
        LOGGER.debug(ACTION_NOT_SUPPORTED);
    }

    /**
     * This method is used to notify the plugin of any map event. Implementation should be empty if the plugin is not
     * interested of being informed of the map event.
     */
    @Override
    public void notifyMapEvent(final INetworkViewId networkViewId, final BiCNetPluginMapEventType eventType) {
        LOGGER.debug(ACTION_NOT_SUPPORTED);
    }

    /**
     * Show the DCN Management Plug-in General Settings in "System Settings".
     */
    @Override
    public BiCNetPluginPropertyPage[] getMainPropertyPages(final BiCNetPluginMainContext context) {
        return systemSettingsBuilder.build(commonServices.getFrameworkPluginHelper(), repositoryManager.getConfigurationRepository()).get(context);
    }

    /**
     * Queries the plug-in for available property pages to be displayed in the context of managed objects (e.g.
     * "Log Properties").
     */
    @Override
    public BiCNetPluginPropertyPage[] getObjectPropertyPages(final IManagedObject[] arObjects, final IManagedObject environment,
            final String strEnvironment) {
        LOGGER.debug(ACTION_NOT_SUPPORTED);
        return null;
    }

    /**
     * Queries the plug-in for available status indicators. Indicators are tiny components that are integrated in the
     * status bar of the client frame.
     */
    @Override
    public BiCNetPluginStatusIndicator[] getStatusIndicators() {
        LOGGER.debug(ACTION_NOT_SUPPORTED);
        return null;
    }

    /**
     * Queries the plug-in for available wizard steps. This is for any wizard using FrameworkGenericWizard.
     */
    @Override
    public BiCNetPluginWizardStep[] getObjectWizardSteps(final ManagedObjectType managedObjectType) {
        LOGGER.debug(ACTION_NOT_SUPPORTED);
        return null;
    }

    /**
     * Queries the plug-in for available action type for the object type provided.
     */
    @Override
    public BiCNetPluginAction[] getObjectTypeActions(final ManagedObjectType objectType, final BiCNetPluginActionType actionType) {
        return publicActionsFactory.build(objectType, actionType);
    }

    /*
     * @see com.ossnms.bicnet.bcb.plugin.neobject.BiCNetPluginNEObjectProvider#getEmIcon(com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId)
     */
    @Override
    @Nullable
    public Icon getEmIcon(@Nonnull final IEMId emId) {
        try {
            checkNotNull(emId);
            final Optional<FullChannelData> channel = repositoryManager.getChannelRepository().get(emId.getId());
            if (channel.isPresent()) {
                return commonServices.getIconManager().findNetworkIcon(channel.get().getChannel(), JfxUtils.DEFAULT_ICON_SIZE).orElse(null);
            }
        } catch (final RepositoryException e) {
            LOGGER.error("Repository error for EM={}", emId.getId(), e);
        }

        return null;
    }

    /**
     * @param systemContainerId System Container id for the requested Icon.
     * @return System Container icon (default size of 16x16)
     */
    @Override
    @Nullable
    public Icon getSystemContainerIcon(ISystemContainerId systemContainerId) {
        return commonServices.getIconManager().findNetworkIcon(systemContainerId).orElse(null);
    }

    /**
     * @param genericContainerId Generic Container id for the requested Icon.
     * @return Generic Container icon (default size of 16x16)
     */
    @Override
    @Nullable
    public Icon getGenericContainerIcon(IGenericContainerId genericContainerId) {
        return commonServices.getIconManager().findNetworkIcon(genericContainerId).orElse(null);
    }

    /*
     * @see com.ossnms.bicnet.bcb.plugin.neobject.BiCNetPluginNEObjectProvider#getNeIcon(com.ossnms.bicnet.bcb.model.emObjMgmt.INEId)
     */
    @Override
    @Nullable
    public Icon getNeIcon(@Nonnull final INEId neId) {
        return getNeIcon(neId, JfxUtils.DEFAULT_ICON_SIZE);
    }

    /*
     * @see com.ossnms.bicnet.bcb.plugin.neobject.BiCNetPluginNEObjectProvider#getNeIcon(com.ossnms.bicnet.bcb.model.emObjMgmt.INEId, int)
     */
    @Override
    @Nullable
    public Icon getNeIcon(@Nonnull final INEId neId, final int size) {
        try {
            checkNotNull(neId);
            final Optional<FullNeData> ne = repositoryManager.getNeRepository().get(neId.getId());
            if (ne.isPresent()) {
                return commonServices.getIconManager().findNeOverlayIcon(ne.get(), size).orElse(null);
            }
        } catch (final RepositoryException e) {
            LOGGER.error("Repository error for NE={}", neId.getId(), e);
        }

        return null;
    }

    /*
     * @see com.ossnms.bicnet.bcb.plugin.neobject.BiCNetPluginNEObjectProvider#getSingleNe(com.ossnms.bicnet.bcb.model.emObjMgmt.INEId)
     */
    @Override
    @Nullable
    public INE getSingleNe(@Nonnull final INEId neId) {
        Optional<FullNeData> ne = Optional.empty();

        try {
            checkNotNull(neId);
            ne = repositoryManager.getNeRepository().get(neId.getId());
        } catch (final RepositoryException e) {
            LOGGER.error("Repository error for NE={}", neId.getId(), e);
        }

        return ne.map(FullNeData::getNe).orElse(null);
    }

    /*
     * @see com.ossnms.bicnet.bcb.plugin.neobject.BiCNetPluginNEObjectProvider#showNEObjectView()
     */
    @Override
    public void showNEObjectView() throws BiCNetPluginException {
        throw new UnsupportedOperationException(ACTION_NOT_SUPPORTED);
    }

    /*
     * @see com.ossnms.bicnet.bcb.plugin.neobject.BiCNetPluginNEObjectProvider#getNeList(com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId)
     */
    @Override
    @Nullable
    public INE[] getNeList(final ISystemContainerId containerId) {
        checkNotNull(containerId);
        try {
            return repositoryManager.getNeRepository().queries().findBySystemContainerId(containerId.getId())
                    .stream()
                    .map(FullNeData::getNe)
                    .toArray(INE[]::new);
        } catch (RepositoryException e) {
            LOGGER.error("Repository error for ISystemContainerId={}", containerId.getId(), e);
        }
        return new INE[0];
    }

    @Override
    @Nullable
    public INE[] getNeList(final IEMId emId) {
        checkNotNull(emId);
        try {
            return repositoryManager.getNeRepository().queries().findByChannel(emId.getId())
                    .stream()
                    .map(FullNeData::getNe)
                    .toArray(INE[]::new);
        } catch (RepositoryException e) {
            LOGGER.error("Repository error for IEM={}", emId.getId(), e);
        }
        return new INE[0];
    }
    /**
     * Gets all NEs under a Generic Container including the NEs in the sub-containers recursively.
     *
     * @param genericContainerId The ID of the requested Generic Container.
     * @return An array of INEs or a empty array when the Generic Container has no NEs.
     */
    @Override public INE[] getNeList(IGenericContainerId genericContainerId) {
        checkNotNull(genericContainerId);
        try {
            final Collection<Integer> neIds = Actions.getAllNEsInContainerAndSubContainers(genericContainerId.getId(), repositoryManager);

            return repositoryManager.getNeRepository().get(neIds)
                    .stream()
                    .map(FullNeData::getNe)
                    .toArray(INE[]::new);
        } catch (RepositoryException e) {
            LOGGER.error("Repository error for IGenericContainerId={}", genericContainerId.getId(), e);
        }
        return new INE[0];
    }

    /*
     * @see com.ossnms.bicnet.bcb.plugin.neobject.BiCNetPluginNEObjectProvider#getSystemContainer(com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId)
     */
    @Override
    @Nullable
    public ISystemContainer getSystemContainer(final ISystemContainerId containerId) {
        checkNotNull(containerId);
        try {
            return repositoryManager.getSystemContainerRepository().get(containerId.getId()).orElse(null);
        } catch (final RepositoryException e) {
            LOGGER.error("Repository error for ISystemContainerId={}", containerId.getId(), e);
            return null;
        }
    }

    /*
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPlugin#getLicenseStatus()
     */
    @Override
    @Nonnull
    public LicenseStatus getLicenseStatus() {
        return LicenseStatus.AVAILABLE;
    }

    /*
     * @see com.ossnms.bicnet.bcb.plugin.neobject.BiCNetPluginNEObjectProvider#getEm(com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId)
     */
    @Override
    @Nullable
    public IEM getEm(@Nonnull final IEMId emId) {
        checkNotNull(emId);
        Optional<FullChannelData> channel = Optional.empty();
        try {
            channel = repositoryManager.getChannelRepository().get(emId.getId());
        } catch (final RepositoryException e) {
            LOGGER.error("Repository error for EM={}", emId.getId(), e);
        }
        return channel.map(FullChannelData::getChannel).orElse(null);
    }

    @Override
    public void addEmNeCacheListener(final BiCNetPluginEmNeChangeListener listener) {
        bicnetChangeListenerManager.add(listener);
    }

    @Override
    public void removeEmNeCacheListener(final BiCNetPluginEmNeChangeListener listener) {
        bicnetChangeListenerManager.remove(listener);
    }
}
