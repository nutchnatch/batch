package com.ossnms.dcn_manager.bicnet.client.core.plugin.action;

import static com.ossnms.dcn_manager.bicnet.client.api.DcnStringUtils.formatListOfNames;
import static com.ossnms.dcn_manager.bicnet.client.api.view.MessageBox.OPTION.YES;

import java.util.ArrayList;
import java.util.Collection;

import javax.annotation.Nonnull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.dcn_manager.bicnet.client.api.action.PluginAction;
import com.ossnms.dcn_manager.bicnet.client.api.view.MessageBox;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.tools.jfx.JfxStringTable;

/**
 * Public action for Containers Deletion.
 */
class NetworkViewObjectDeletionPluginAction extends PluginAction {
    private static final Logger LOGGER = LoggerFactory.getLogger(NetworkViewObjectDeletionPluginAction.class);
    private static final String UI_ID = NetworkViewObjectDeletionPluginAction.class.getName();

    private final CommonServices commonServices;
    private final ContainerDeleteDelegate containerDeletion;
    private final SystemAssignmentDeleteDelegate systemAssignmentRemove;
    private final NeAssignmentDeleteDelegate neAssignmentRemove;

    NetworkViewObjectDeletionPluginAction(RepositoryManager repositoryManager, CommonServices commonServices) {
        super(UI_ID, TreeTableLabels.DELETE, TreeTableLabels.DELETE);
        this.commonServices = commonServices;
        this.containerDeletion = new ContainerDeleteDelegate(repositoryManager, commonServices);
        this.systemAssignmentRemove = new SystemAssignmentDeleteDelegate(repositoryManager, commonServices);
        this.neAssignmentRemove = new NeAssignmentDeleteDelegate(commonServices);
    }

    @Override public boolean isPluginActionAllowed(@Nonnull final IManagedObject[] managedObjects) {
        return  containerDeletion.isActionAllowed(managedObjects) ||
                systemAssignmentRemove.isActionAllowed(managedObjects) ||
                neAssignmentRemove.isActionAllowed(managedObjects);
    }

    @Override public void eventPluginActionPerformed(@Nonnull final IManagedObject[] managedObjects)
            throws BiCNetPluginException {
        try {
            final String confirmMessage = TreeTableLabels.DO_YOU_REALLY_WANT_TO_DELETE_PARAM.guiName()
                    .getFormatedMessage(formatListOfNames(getNames(managedObjects)));

            MessageBox.OPTION option = commonServices.getMessageBox()
                    .warnConfirmationBox(TreeTableLabels.CONFIRM_OBJECT_DELETE, confirmMessage);

            if (YES == option) {
                containerDeletion.executeJob(managedObjects);
                systemAssignmentRemove.executeJob(managedObjects);
                neAssignmentRemove.executeJob(managedObjects);
            }
        } catch (final Exception e) {
            LOGGER.error("An error occurred while executing delete", e);
            commonServices.getMessageBox().errorMessage(JfxStringTable.IDS_UNKNOWN_ERROR_DESCRIPTION.toString());
        }
    }

    private Collection<String> getNames(@Nonnull final IManagedObject[] managedObjects) {
        Collection<String> names = new ArrayList<>();
        names.addAll(containerDeletion.getElementNames(managedObjects));
        names.addAll(systemAssignmentRemove.getElementNames(managedObjects));
        names.addAll(neAssignmentRemove.getElementNames(managedObjects));
        return names;
    }
}
