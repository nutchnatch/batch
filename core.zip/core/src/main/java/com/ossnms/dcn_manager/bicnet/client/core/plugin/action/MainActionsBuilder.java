package com.ossnms.dcn_manager.bicnet.client.core.plugin.action;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginAction;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandRegistrar;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.dcn_manager.bicnet.client.presentation.statesummary.StateSummaryCommand;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.dialogs.finder.FindDialogCommand;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listtable.DcnListTableCommand;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.TreeTableCommand;
import org.apache.commons.lang3.builder.Builder;

import java.util.Set;
import java.util.stream.Collectors;

import static java.util.Arrays.asList;

/**
 *  Builds the DCN Main Actions to be available on the BiCNet Plug-in MainContext.
 */
public class MainActionsBuilder implements Builder<ImmutableMap<BiCNetPluginMainContext, BiCNetPluginAction[]>> {

    private final BiCNetPluginAction[] networkContextActions = {
            registered(new TreeTableCommand()),
            registered(new StateSummaryCommand()),
            registered(new DcnListTableCommand())
    };

    private final Set<Class> notReopenable = ImmutableSet.of(FindDialogCommand.class);

    /**
     * Builds the mains actions for the Network menu.
     */
    @Override
    public ImmutableMap<BiCNetPluginMainContext, BiCNetPluginAction[]> build() {
        return ImmutableMap.of(BiCNetPluginMainContext.NETWORK, networkContextActions);
    }
    
    /**
     * Returns all registered DCN commands.
     *
     * @return The list of all commands.
     */
    public Iterable<IFrameworkCommand> getAllCommands() {
        return asList(networkContextActions).stream()
                .filter(IFrameworkCommand.class::isInstance).map(IFrameworkCommand.class::cast)
                .filter(action -> !notReopenable.contains(action.getClass()))
                .collect(Collectors.toList());
    }

    /**
     * Registers command in UI Command Register
     */
    private <T extends IFrameworkCommand> T registered(T command) {
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(command);
        return command;
    }
}