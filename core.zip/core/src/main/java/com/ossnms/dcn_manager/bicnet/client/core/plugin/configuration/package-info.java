/**
 * Contains the configuration for DCN Management works with the BicNet Plug-in architecture.
 */
package com.ossnms.dcn_manager.bicnet.client.core.plugin.configuration;