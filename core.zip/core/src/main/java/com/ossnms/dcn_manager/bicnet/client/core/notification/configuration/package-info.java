/**
 * Contains the configuration for Notifications from the BiCNet Plug-in TopicListener.
 */
package com.ossnms.dcn_manager.bicnet.client.core.notification.configuration;