package com.ossnms.dcn_manager.bicnet.client.core.notification;

import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.DCN_MANAGER;
import static com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration.SENDER_ID;

import java.io.Serializable;
import java.util.Objects;

import javax.annotation.Nonnull;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IVisitor;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginTopicListener;

/**
 * Process the notifications from TNMS server.
 */
public class NotificationManager implements BiCNetPluginTopicListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationManager.class);

    private final Iterable<IVisitor> visitors;

    public NotificationManager() {
        this(new NotificationVisitors().list());
    }

    public NotificationManager(@Nonnull final Iterable<IVisitor> notificationVisitors) {
        this.visitors = notificationVisitors;
    }

    /**
     * Called by plug-in site when message from JMS topic has been received.
     * Note: The call is performed in a background thread.
     */
    @Override
    public void eventPluginTopicMessage(@Nonnull final Message message) {
        try {
            if (isValid(message)) {
                final Serializable obj = ((ObjectMessage) message).getObject();
                processNotification(obj);
            }
        } catch (JMSException | BcbException e) {
            LOGGER.error("Erro to process message from TNMS server", e);
        }
    }

    /**
     * This is just for information, the site will display an error and perform a log-off.
     */
    @Override
    public void eventPluginTopicLost() {
        LOGGER.error("EM/NE Plug-in. Message Lost!");
    }

    /*
     * Verifies if the message is for the EMNE plug-in.
     */
    private boolean isValid(@Nonnull final Message message) throws JMSException {
        final String senderId = message.getStringProperty(SENDER_ID.getName());

        final boolean isFromEMNE = Objects.equals(DCN_MANAGER.toString(), senderId);
        final boolean isObjectMessage = message instanceof ObjectMessage;

        return isObjectMessage && isFromEMNE;
    }

    /*
     * Process the notification for only one message or batch processing.
     */
    private void processNotification(@Nonnull final Serializable obj) throws BcbException {
        if (obj instanceof Notification[]) {
            for (final Notification notification : (Notification[]) obj) {
                dispatch(notification);
            }
        } else if (obj instanceof Notification) {
            dispatch((Notification) obj);
        }
    }

    /*
     * Process notification for all register visitors.
     */
    private void dispatch(@Nonnull final Notification n) throws BcbException {
        for (final IVisitor visitor : visitors) {
            if (n.dispatch(visitor)) {
                break;
            }
        }
    }
}
