package com.ossnms.dcn_manager.bicnet.client.core.plugin.configuration;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.framework.client.listeners.FrameworkAbstractLogonListener;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.RestoreViews;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.DelayedUpdate;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.Properties;

/**
 * Helper to manager Log-on/Log-off events for the DCN Manager plug-in.
 */
public class PluginLogonListener extends FrameworkAbstractLogonListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(PluginLogonListener.class);

    /**
     * Handler to restore/save the opened views in the user security session
     */
    private final RestoreViews restoreViews;

    /**
     * Contains the resources from the BiCNet Plug-in provider
     */
    private final DcnPluginHelper pluginHelper;
    private final DelayedUpdate neCache;
    private final SecureActionValidation secureActionValidation;
    private static final int DELAY_MILLIS = 1000;

    public PluginLogonListener(@Nonnull final DcnPluginHelper pluginState, @Nonnull final RestoreViews restoreViews, @Nonnull final SecureActionValidation secureActionValidation) {
        pluginHelper = pluginState;
        this.restoreViews = restoreViews;
        this.secureActionValidation = secureActionValidation;
        neCache = new DelayedUpdate(NeCacheManager.getInstance(), DELAY_MILLIS);
    }

    /**
     * Initializes the DCN plug-in helper and restore the DCN Opened views in the last session.
     */
    @Override
    protected void eventUserLoggedOn(@Nonnull final ISessionContext sessionContext) {
        secureActionValidation.reloadVisibilityCache();
        try {
            restoreViews.restoreOpenedViews();
        } catch (final RuntimeException e) {
            LOGGER.warn("Cannot possible to restore opened views: {}", e.getMessage());
        }
    }

    /**
     * Save during the logging-off event the DCN opened views in the active user Security Session.
     */
    @Override
    protected void eventUserLoggingOff(@Nonnull final ISessionContext sessionContext) {
        restoreViews.saveOpenedViews();
    }

    /**
     * Store the current user security session profile on the Security profile repository after the logging-off event is completed.
     */
    @Override
    protected void eventUserLoggedOff(@Nonnull final ISessionContext sessionContext) {
        pluginHelper.getClientSession().ifPresent(session -> {
            final Properties props = Optional.ofNullable(session.getUserProfile(pluginHelper.getPluginId())).orElse(new Properties());

            session.setUserProfile(pluginHelper.getPluginId(), props);
            pluginHelper.uninitialize();
        });
    }

    /**
     * Called when user permissions context has changed.
     *
     * @param sessionContext - context of the session
     */
    @Override
    protected void eventUserPermissionsChanged(@Nonnull final ISessionContext sessionContext) {
        pluginHelper.initialize(sessionContext);
        secureActionValidation.reloadVisibilityCache();
        neCache.touchAll();
    }

    /**
     * Access to the plugin's BiCNetPluginSite.
     */
    @Override
    protected BiCNetPluginSite getPluginSite() {
        return pluginHelper.getCfPluginSite();
    }
}