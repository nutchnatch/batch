package com.ossnms.dcn_manager.bicnet.client.core.notification.configuration;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.core.notification.NotificationManager;
import org.junit.Before;
import org.junit.Test;

import javax.jms.JMSException;

import static com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration.TOPIC_FACTORY_NAME;
import static com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration.TOPIC_NAME;
import static org.mockito.Mockito.*;

public class NotificationLogonListenerTest {

    private BiCNetPluginSite pluginSite;
    private ISessionContext context;
    private NotificationManager notificationManager;
    private NotificationLogonListener listener;

    @Before
    public void setup() throws JMSException, BcbException {
        pluginSite = mock(BiCNetPluginSite.class);
        context = mock(ISessionContext.class);
        notificationManager = mock(NotificationManager.class);

        DcnPluginHelperSingleton.getInstance().setCfPluginSite(pluginSite);

        listener = new NotificationLogonListener(DcnPluginHelperSingleton.getInstance(), notificationManager);
    }

    @Test
    public void testEventUserLoggedOn() throws BiCNetPluginException {
        listener.eventUserLoggedOn(context);

        verify(pluginSite, times(1)).subscribeServerTopic(TOPIC_FACTORY_NAME.getName(), TOPIC_NAME.getName(),
                notificationManager);
    }

    @Test
    public void testEventUserLoggedOff() {
        listener.eventUserLoggedOff(context);

        verify(pluginSite, times(1)).unsubscribeServerTopic(TOPIC_FACTORY_NAME.getName(), TOPIC_NAME.getName(),
                notificationManager);
    }
}
