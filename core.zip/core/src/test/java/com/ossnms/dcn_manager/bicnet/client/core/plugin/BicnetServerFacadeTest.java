package com.ossnms.dcn_manager.bicnet.client.core.plugin;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacadeSingleton;
import com.ossnms.dcn_manager.bicnet.connector.common.servicelocator.ServiceLocator;

public class BicnetServerFacadeTest {

    @Before
    public void setup() {
        BiCNetServiceLocator.getInstance().registerServiceLocator(BiCNetComponentType.DCN_MANAGER, ServiceLocator.getInstance());
    }

    @Test
    public void testDcnPublicServices() throws BcbException {
        BicnetServerFacadeSingleton.getInstance().getDcnPublicServices();
    }
    
    @Test
    public void testNeService() throws BcbException {
        BicnetServerFacadeSingleton.getInstance().getNeService();
    }
    
    @Test
    public void testChannelService() throws BcbException {
        BicnetServerFacadeSingleton.getInstance().getChannelService();
    }
    
    @Test
    public void testMediatorService() throws BcbException {
        BicnetServerFacadeSingleton.getInstance().getMediatorService();
    }
    
    @Test
    public void testDomainService() throws BcbException {
        BicnetServerFacadeSingleton.getInstance().getDomainService();
    }    
    
    @Test
    public void testConfigurationService() throws BcbException {
        BicnetServerFacadeSingleton.getInstance().getConfigurationService();
    }
    
    @Test
    public void testContainerService() throws BcbException {
        BicnetServerFacadeSingleton.getInstance().getContainerService();
    }
}
