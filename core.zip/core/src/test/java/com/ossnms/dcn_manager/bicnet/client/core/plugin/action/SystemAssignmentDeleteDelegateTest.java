package com.ossnms.dcn_manager.bicnet.client.core.plugin.action;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.logger.LoggerManager;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.actions.jobs.JobNeAssignmentRemove;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction.OP_DELETE_SAN;
import static java.util.Collections.singleton;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SystemAssignmentDeleteDelegateTest {

    private static final int SYSTEM_ELEMENT_ID = 1;
    private static final int GENERIC_CONTAINER_ID = 2;
    private static final int NE_ID = 1;

    @Mock private RepositoryManager repositoryManager;
    @Mock private CommonServices commonServices;
    @Mock private SecureActionValidation secureActionValidation;
    @Mock private LoggerManager loggerManager;
    @Mock private BicnetServerFacade serverFacade;
    @Mock private DcnPluginHelper dcnPluginHelper;
    @Mock private ISessionContext sessionContext;
    
    @Mock private NeRepository neRepository;
    
    @Mock private NeSearchable neSearchable;

    private SystemAssignmentDeleteDelegate delegate;
    private ISystemGenericContainerAssignment assignmentId;

    @Before public void setUp() throws Exception {
        assignmentId = new SystemGenericContainerAssignmentItem();
        assignmentId.setGenericContainerId(GENERIC_CONTAINER_ID);
        assignmentId.setSystemContainerId(SYSTEM_ELEMENT_ID);

        INE ne = new NEItem();
        ne.setId(NE_ID);

        FullNeData fullNeData = new FullNeData(ne, new NeInfo(ne.getId()), null);

        when(commonServices.getDcnPluginHelper()).thenReturn(dcnPluginHelper);
        when(commonServices.getSecureActionValidation()).thenReturn(secureActionValidation);
        when(commonServices.getLoggerManager()).thenReturn(loggerManager);
        when(commonServices.getBicnetServerFacade()).thenReturn(serverFacade);

        when(dcnPluginHelper.getSessionContext()).thenReturn(sessionContext);

        when(repositoryManager.getNeRepository()).thenReturn(neRepository);
        when(neRepository.queries()).thenReturn(neSearchable);
        when(neSearchable.findBySystemContainerId(SYSTEM_ELEMENT_ID)).thenReturn(singleton(fullNeData));
        
        when(secureActionValidation.checkPermission(OP_DELETE_SAN, assignmentId)).thenReturn(true);
        when(secureActionValidation.checkVisibility(any(Collection.class))).thenReturn(true);

        delegate = new SystemAssignmentDeleteDelegate(repositoryManager, commonServices);
    }

    @Test public void isActionAllowed() throws Exception {
        final boolean actionAllowed = delegate.isActionAllowed(new IManagedObject[] { assignmentId });

        verify(secureActionValidation).checkVisibility(any(Collection.class));
        assertTrue(actionAllowed);
        verify(loggerManager, never()).error(anyString(), anyString());
    }

    @Test public void isActionAllowed_no_permission() throws Exception {
        when(secureActionValidation.checkPermission(OP_DELETE_SAN, assignmentId)).thenReturn(false);

        final boolean actionAllowed = delegate.isActionAllowed(new IManagedObject[] { assignmentId });

        assertFalse(actionAllowed);
        verify(loggerManager, never()).error(anyString(), anyString());
    }
    
    @Test public void isActionAllowedWithInvisibleNes() throws Exception {
    	when(secureActionValidation.checkVisibility(any(Collection.class))).thenReturn(false);
        final boolean actionAllowed = delegate.isActionAllowed(new IManagedObject[] { assignmentId });

        assertFalse(actionAllowed);
        verify(loggerManager, never()).error(anyString(), anyString());
    }

    @Test public void isActionAllowed_wrong_object_type() throws Exception {
        final boolean actionAllowed = delegate.isActionAllowed(new IManagedObject[] { new NEItem() });

        assertFalse(actionAllowed);
        verify(loggerManager, never()).error(anyString(), anyString());
    }

    @Test public void executeJob() throws Exception {
        delegate.executeJob(new IManagedObject[] { assignmentId });

        verify(dcnPluginHelper, atLeastOnce()).getSessionContext();
        verify(commonServices, atLeastOnce()).getBicnetServerFacade();
        verify(dcnPluginHelper, atLeastOnce()).queueJob(any(JobNeAssignmentRemove.class));
    }

    @Test public void executeJob_wrong_obj_type() throws Exception {
        delegate.executeJob(new IManagedObject[] { new NEItem() });

        verify(dcnPluginHelper, never()).getSessionContext();
        verify(commonServices, never()).getBicnetServerFacade();
        verify(dcnPluginHelper, never()).queueJob(any(JobNeAssignmentRemove.class));
    }

    @Test(expected = BiCNetPluginException.class) public void executeJob_error_job() throws Exception {
        doThrow(new BiCNetPluginException()).when(dcnPluginHelper).queueJob(any(JobNeAssignmentRemove.class));

        delegate.executeJob(new IManagedObject[] { assignmentId });
    }

    @Test public void getElementNames() throws Exception {
        final Collection<String> elementNames = delegate.getElementNames(new IManagedObject[] { assignmentId });
        assertThat(elementNames, Matchers.contains("System Assignment"));
    }
}