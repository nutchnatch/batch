package com.ossnms.dcn_manager.bicnet.client.core.plugin.action;

import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionType;
import com.ossnms.dcn_manager.bicnet.client.api.action.PluginAction;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class PublicActionsFactoryTest {

    @Mock private RepositoryManager repositoryManager;
    @Mock private CommonServices commonServices;

    private PublicActionsFactory publicActionsFactory;

    @Before public void setUp() throws Exception {
        publicActionsFactory = new PublicActionsFactory(repositoryManager, commonServices);
    }

    @Test public void build_container_actions() throws Exception {
        final PluginAction[] actions = publicActionsFactory
                .build(ManagedObjectType.NETWORK_VIEW_OBJECT, BiCNetPluginActionType.DELETE);

        assertThat(actions.length, is(1));
        assertThat(actions[0].getClass().getName(), is(NetworkViewObjectDeletionPluginAction.class.getName()));
    }

    @Test public void build_container_no_actions() throws Exception {
        final PluginAction[] actions = publicActionsFactory
                .build(ManagedObjectType.NE, BiCNetPluginActionType.DELETE);

        assertThat(actions.length, is(0));
    }
}