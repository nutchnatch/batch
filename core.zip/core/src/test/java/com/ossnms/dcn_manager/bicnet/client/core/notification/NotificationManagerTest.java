package com.ossnms.dcn_manager.bicnet.client.core.notification;

import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.DCN_MANAGER;
import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.LOG_MANAGER;
import static com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration.SENDER_ID;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;

public class NotificationManagerTest {

    private TextMessage wrongMessageType;
    private ObjectMessage message;
    private ObjectCreation notification;

    @Before
    public void setup() throws JMSException, BcbException {
        wrongMessageType = mock(TextMessage.class);
        message = mock(ObjectMessage.class);
        notification = mock(ObjectCreation.class);

        when(message.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
        when(message.getObject()).thenReturn(notification);
    }

    @Test
    public void testNotification() throws JMSException, BcbException {

        new NotificationManager().eventPluginTopicMessage(message);

        verify(message, times(1)).getStringProperty(SENDER_ID.getName());
        verify(message, times(1)).getObject();
    }

    @Test
    public void testNotificationArray() throws JMSException, BcbException {
        final Notification[] notifications = { notification };

        when(message.getObject()).thenReturn(notifications);

        new NotificationManager().eventPluginTopicMessage(message);

        verify(message, times(1)).getStringProperty(SENDER_ID.getName());
        verify(message, times(1)).getObject();
    }

    @Test
    public void testInvalidComponent() throws JMSException, BcbException {
        when(message.getStringProperty(SENDER_ID.getName())).thenReturn(LOG_MANAGER.name());

        new NotificationManager().eventPluginTopicMessage(message);

        verify(message, times(1)).getStringProperty(SENDER_ID.getName());
        verify(message, never()).getObject();
    }

    @Test
    public void testInvalidMessage() throws JMSException, BcbException {
        new NotificationManager().eventPluginTopicMessage(wrongMessageType);

        verify(wrongMessageType, times(1)).getStringProperty(SENDER_ID.getName());
    }

    @Test
    public void testErrorJMS() throws JMSException, BcbException {

        doThrow(new JMSException("")).when(message).getStringProperty(SENDER_ID.getName());

        new NotificationManager().eventPluginTopicMessage(message);

        verify(message, times(1)).getStringProperty(SENDER_ID.getName());
        verify(message, never()).getObject();
    }

    @Test
    public void testErrorBcb() throws JMSException, BcbException {

        new NotificationManager().eventPluginTopicMessage(message);

        verify(message, times(1)).getStringProperty(SENDER_ID.getName());
        verify(message, times(1)).getObject();
    }
}
