package com.ossnms.dcn_manager.bicnet.client.core.notification.integration;

import com.coriant.widgets.treetable.TreeTable;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IASMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.core.notification.NotificationManager;
import com.ossnms.dcn_manager.bicnet.client.core.plugin.TestsHelper;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.DomainTreeNodeEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomainRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.DomainCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.BicnetChangeListenerManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.DomainGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import java.util.ArrayList;
import java.util.Optional;
import java.util.concurrent.TimeoutException;

import static com.google.code.tempusfugit.temporal.Duration.seconds;
import static com.google.code.tempusfugit.temporal.Timeout.timeout;
import static com.google.code.tempusfugit.temporal.WaitFor.waitOrTimeout;
import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.DCN_MANAGER;
import static com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration.SENDER_ID;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Test the flow from BiCNet message to TreeTable Model for Domains.
 */
@RunWith(MockitoJUnitRunner.class)
public class DomainMessageProcessingIT extends TestsHelper {

    private static final int PROCESS_TIMEOUT_S = 20;
    private static final int DOMAIN_ID = 1;

    private NotificationManager manager;
    private CacheWrapper<Integer, IAS> cache;
    private CacheWrapper<Integer, FullNeData> neCache;

    private ListenersRegistrationManager cacheChangeListener;
    private EventChangeListener<IAS> domainChangeListener;

    private BicnetChangeListenerManager bicnetChangeListenerManager;
    private BiCNetPluginEmNeChangeListenerImpl biCNetPluginEmNeChangeListener;

    private TreeTableViewModel model;
    private NodeDomainRoot rootNode;

    @Mock private TreeTable treeTable;
    @Mock private ObjectMessage messageForCreate;
    @Mock private ObjectMessage messageForUpdate;
    @Mock private ObjectMessage messageForDelete;

    @Before public void setup() throws Exception {
        // Initialize Notification manager
        manager = new NotificationManager();
        cache = DomainCacheManager.getInstance().cache();
        cache.fetch(new ArrayList<>());

        neCache = NeCacheManager.getInstance().cache();
        neCache.fetch(new ArrayList<>());

        // Initialize Domain TreeTable Change listener
        rootNode = new NodeDomainRoot("TNMS");
        model = new TreeTableViewModel(rootNode);

        when(commonServices.getDcnPluginHelper()).thenReturn(dcnPluginHelper);
        when(commonServices.getSecureActionValidation()).thenReturn(secureActionValidation);

        when(secureActionValidation.checkPermission(any(SecureAction.class))).thenReturn(true);
        when(secureActionValidation.checkPermission(any(SecureAction.class), any(IManagedObjectId[].class)))
                .thenReturn(true);

        when(repositoryManager.getNeRepository())
                .thenReturn(new NeRepository(bicnetServerFacade, neCache));

        when(domainSearchable.findByIdName(anyString())).thenReturn(Optional.of(buildDomain()));

        domainChangeListener = new DomainTreeNodeEventListener(new TreeTableModelUpdater(model, treeTable),
                commonServices, repositoryManager, new DomainGraphicalRepresentationBuilder(new IconManager()));

        cacheChangeListener = new CacheListenersRegistrationManager();
        cacheChangeListener.addDomainListener(domainChangeListener);

        biCNetPluginEmNeChangeListener = new BiCNetPluginEmNeChangeListenerImpl();
        bicnetChangeListenerManager = new BicnetChangeListenerManager();
        bicnetChangeListenerManager.add(biCNetPluginEmNeChangeListener);

        when(messageForCreate.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
        when(messageForUpdate.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
        when(messageForDelete.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
    }

    @After public void clear() throws CacheException {
        cache.clear();
        neCache.clear();
        cacheChangeListener.removeDomainListener(domainChangeListener);
        bicnetChangeListenerManager.remove(biCNetPluginEmNeChangeListener);
    }

    @Test public void testCreateObjectListeners() throws Exception {
        final IAS domainFromBcb = buildObjectCreationScenario();

        // Verify if the Root Node was updated
        assertThat(rootNode.getChildCount(), is(1));

        // Verify Bicnet Listener
        assertThat(biCNetPluginEmNeChangeListener.isCreatedCalled(), is(true));


        final NodeDomain domainInModel = (NodeDomain) rootNode.getChildAt(0);


        verifyTableModel(domainInModel);
        verifyNodeDomain(domainFromBcb, domainInModel);
    }

    @Test public void testUpdateObjectListeners() throws Exception {
        final IAS domainForCreate = buildObjectCreationScenario();

        final IASMarkable domainForUpdate = buildAttributeValueChangeScenario(domainForCreate);

        waitOrTimeout(() -> biCNetPluginEmNeChangeListener.isUpdateCalled(), timeout(seconds(PROCESS_TIMEOUT_S)));
        waitOrTimeout(() -> rootNode.getChildCount() == 1, timeout(seconds(PROCESS_TIMEOUT_S)));

        // Verify if the Root Node was updated
        assertThat(rootNode.getChildCount(), is(1));

        // Verify Bicnet Listener
        assertThat(biCNetPluginEmNeChangeListener.isUpdateCalled(), is(true));

        final NodeDomain domainInModel = (NodeDomain) rootNode.getChildAt(0);

        verifyTableModel(domainInModel);
        verifyNodeDomain(domainForUpdate, domainInModel);
    }

    @Test public void testDeleteObjectListeners() throws Exception {

        buildObjectCreationScenario();

        final ObjectDeletion objectDeletion = new ObjectDeletion();
        objectDeletion.setDeletedObject(new ASIdItem(DOMAIN_ID));
        when(messageForDelete.getObject()).thenReturn(objectDeletion);
        manager.eventPluginTopicMessage(messageForDelete);

        // Verify cache
        final Optional<IAS> domainInCache = cache.find(1);
        assertFalse(domainInCache.isPresent());

        // Wait for SwingWorker process the Node deletion
        waitOrTimeout(() -> rootNode.getChildCount() == 0, timeout(seconds(PROCESS_TIMEOUT_S)));

        // Verify if the Root Node was updated
        assertThat(rootNode.getChildCount(), is(0));

        // Verify Bicnet Listener
        assertThat(biCNetPluginEmNeChangeListener.isDeleteCalled(), is(true));
    }

    private IASMarkable buildAttributeValueChangeScenario(final IAS domainForCreate)
            throws JMSException, CacheException, InterruptedException, TimeoutException {
        final IASMarkable domainForUpdate = domainForCreate.toMarkableAS(true);
        domainForUpdate.setIdName("NEW_NAME");
        domainForUpdate.setDiscoveryPermited(false);

        // Process AVC
        final AttributeValueChange attributeValueChange = new AttributeValueChange();
        attributeValueChange.setChangedObject(domainForUpdate);
        when(messageForUpdate.getObject()).thenReturn(attributeValueChange);
        manager.eventPluginTopicMessage(messageForUpdate);

        // Verify cache
        final Optional<IAS> domainInCache = cache.find(1);
        assertTrue(domainInCache.isPresent());

        // Wait for SwingWorker process the Node updater
        waitOrTimeout(
                () -> rootNode.getChildCount() >= 1 && ((Node) rootNode.getChildAt(0)).getValue().getName()
                        .equals(domainForUpdate.getIdName()), timeout(seconds(PROCESS_TIMEOUT_S)));

        return domainForUpdate;
    }

    private IAS buildObjectCreationScenario()
            throws JMSException, CacheException, InterruptedException, TimeoutException {
        final IAS domainFromBcb = buildDomain();

        // Process Object Creation
        final ObjectCreation objectCreation = new ObjectCreation();
        objectCreation.setCreatedObject(domainFromBcb);
        when(messageForCreate.getObject()).thenReturn(objectCreation);
        manager.eventPluginTopicMessage(messageForCreate);

        // Verify cache
        final Optional<IAS> domainInCache = cache.find(1);
        assertTrue(domainInCache.isPresent());

        // Wait for SwingWorker process the Node creation
        waitOrTimeout(() -> rootNode.getChildCount() >= 1, timeout(seconds(PROCESS_TIMEOUT_S)));

        return domainFromBcb;
    }

    private void verifyTableModel(final NodeDomain domainInModel) {
        assertThat(model.getChildCount(rootNode), is(1));
        assertThat(model.getNodeIcon(rootNode), is(rootNode.getValue().getGraphicalRepresentation()));
        assertThat(model.getNodeIcon(domainInModel), is(domainInModel.getValue().getGraphicalRepresentation()));

        assertFalse(model.isToggleButtonVisible(rootNode));
        assertFalse(model.isToggleButtonVisible(domainInModel));

        assertThat(model.getChild(rootNode, 0), is(domainInModel));

        assertThat(model.getColumnName(ColumnId.TREE_MODEL.ordinal()), is(TreeTableLabels.COLUMN_ROOT.toString()));
        assertThat(model.getColumnName(ColumnId.STATE.ordinal()), is(TreeTableLabels.COLUMN_STATE.toString()));
        assertThat(model.getColumnName(ColumnId.NETWORK_NAME.ordinal()),
                is(TreeTableLabels.COLUMN_NETWORK_NAME.toString()));
        assertThat(model.getColumnName(ColumnId.TYPE.ordinal()), is(TreeTableLabels.COLUMN_TYPE.toString()));
        assertThat(model.getColumnName(ColumnId.INFO.ordinal()), is(TreeTableLabels.COLUMN_INFO.toString()));
        assertThat(model.getColumnName(ColumnId.ADDRESS.ordinal()), is(TreeTableLabels.COLUMN_ADDRESS.toString()));
        assertThat(model.getColumnName(ColumnId.CONNECT_VIA.ordinal()),
                is(TreeTableLabels.COLUMN_CONNECT_VIA.toString()));
    }

    private void verifyNodeDomain(final IAS domain, final NodeDomain domainInModel) {
        assertThat(domainInModel.getId(), is(domain.getId()));

        assertThat(domainInModel.getValue().getName(), is(domain.getIdName()));
        assertThat(domainInModel.getValue().isToogleButtonVisible(), is(false));

        assertNotNull(domainInModel.getValue().getGraphicalRepresentation());
    }

    private IAS buildDomain() {
        final IAS domain = new ASItem();
        domain.setId(DOMAIN_ID);
        domain.setIdName("Domain_1");
        domain.setDiscoveryPermited(true);
        return domain;
    }
}
