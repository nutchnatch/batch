package com.ossnms.dcn_manager.bicnet.client.core.plugin.action;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.api.view.MessageBox;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.ContainerSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeContainerAssignmentSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.SystemAssignmentSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ContainerRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NEContainerAssignmentRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.SystemContainerAssignmentRepository;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ContainerDeleteDelegateTest {
    private static final int CONTAINER_ID = 1;

    @Mock private RepositoryManager repositoryManager;
    @Mock private CommonServices commonServices;
    @Mock private SecureActionValidation secureActionValidation;
    @Mock private DcnPluginHelper dcnPluginHelper;

    @Mock private ContainerRepository containerRepository;
    @Mock private NEContainerAssignmentRepository neAssignmentRepository;
    @Mock private SystemContainerAssignmentRepository systemAssignmentRepository;
    @Mock private MessageBox messageBox;

    @Mock private ContainerSearchable containerSearchable;
    @Mock private NeContainerAssignmentSearchable neAssignmentSearchable;
    @Mock private SystemAssignmentSearchable systemAssignmentSearchable;

    private ContainerDeleteDelegate deleteDelegate;
    private IGenericContainer genericContainer;
    @Before public void setUp() throws Exception {
        genericContainer = new GenericContainerItem();
        genericContainer.setId(CONTAINER_ID);
        genericContainer.setIdName("name_c_1");

        when(commonServices.getSecureActionValidation()).thenReturn(secureActionValidation);
        when(commonServices.getDcnPluginHelper()).thenReturn(dcnPluginHelper);
        when(commonServices.getMessageBox()).thenReturn(messageBox);
        when(messageBox.warnConfirmationBox(any(TreeTableLabels.class), anyString())).thenReturn(MessageBox.OPTION.YES);

        when(secureActionValidation.checkPermission(SecureAction.OP_DELETE_SAN, genericContainer)).thenReturn(true);

        when(repositoryManager.getContainerRepository()).thenReturn(containerRepository);
        when(repositoryManager.getNEContainerAssignmentRepository()).thenReturn(neAssignmentRepository);
        when(repositoryManager.getSystemContainerAssignmentRepository()).thenReturn(systemAssignmentRepository);

        when(neAssignmentRepository.queries()).thenReturn(neAssignmentSearchable);
        when(containerRepository.queries()).thenReturn(containerSearchable);
        when(systemAssignmentRepository.queries()).thenReturn(systemAssignmentSearchable);

        when(systemAssignmentSearchable.findByContainerId(CONTAINER_ID)).thenReturn(Collections.emptyList());
        when(neAssignmentSearchable.findByContainerId(CONTAINER_ID)).thenReturn(Collections.emptyList());
        when(containerSearchable.findByParentId(CONTAINER_ID)).thenReturn(Collections.emptyList());

        when(containerRepository.get(Collections.singletonList(CONTAINER_ID))).thenReturn(Collections.singletonList(genericContainer));

        deleteDelegate = new ContainerDeleteDelegate(repositoryManager, commonServices);
    }

    @Test public void isPluginActionAllowed() throws Exception {
        final boolean pluginActionAllowed = deleteDelegate.isActionAllowed(new IGenericContainer[] { genericContainer });

        assertThat(pluginActionAllowed, is(true));
    }

    @Test public void isPluginActionAllowed_no_permission() throws Exception {
        when(secureActionValidation.checkPermission(SecureAction.OP_DELETE_SAN, genericContainer)).thenReturn(false);

        final boolean pluginActionAllowed = deleteDelegate.isActionAllowed(new IGenericContainer[] { genericContainer });

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void isPluginActionAllowed_has_ne_assigned() throws Exception {
        when(neAssignmentSearchable.findByContainerId(CONTAINER_ID)).thenReturn(Collections.singletonList(new NeGenericContainerAssignmentItem()));

        final boolean pluginActionAllowed = deleteDelegate.isActionAllowed(new IGenericContainer[] { genericContainer });

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void isPluginActionAllowed_has_system_assigned() throws Exception {
        when(systemAssignmentSearchable.findByContainerId(CONTAINER_ID)).thenReturn(Collections.singletonList(new SystemGenericContainerAssignmentItem()));

        final boolean pluginActionAllowed = deleteDelegate.isActionAllowed(new IGenericContainer[] { genericContainer });

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void isPluginActionAllowed_has_container_assigned() throws Exception {
        when(containerSearchable.findByParentId(CONTAINER_ID)).thenReturn(Collections.singletonList(new GenericContainerItem()));

        final boolean pluginActionAllowed = deleteDelegate.isActionAllowed(new IGenericContainer[] { genericContainer });

        assertThat(pluginActionAllowed, is(false));
    }

    @Test public void eventPluginActionPerformed() throws Exception {
        deleteDelegate.executeJob(new IGenericContainer[]{genericContainer});

        verify(commonServices, atLeastOnce()).getBicnetServerFacade();
        verify(dcnPluginHelper, atLeastOnce()).getSessionContext();
    }
}