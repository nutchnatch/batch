package com.ossnms.dcn_manager.bicnet.client.core.notification;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorMarkableItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.MediatorCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import net.sf.ehcache.Element;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import java.util.ArrayList;

import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.DCN_MANAGER;
import static com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration.SENDER_ID;
import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MediatorCacheTopicListenerTest {

    private final NotificationManager manager = new NotificationManager();
    private final CacheWrapper<Integer, FullMediatorData> cache = MediatorCacheManager.getInstance().cache();

    private ObjectMessage message;
    private FullMediatorDataCreateNotification objectCreation;
    private ObjectDeletion objectDeletion;
    private AttributeValueChange attributeValueChange;

    private FullMediatorData fullMediatorData;

    @Before
    public void setup() throws JMSException, BcbException {
        message = mock(ObjectMessage.class);

        IMediator mediator = new MediatorItem();
        mediator.setIdName("MEDIATOR_TEST");
        mediator.setActivation(EnableSwitch.ENABLED);
        mediator.setId(1);
        fullMediatorData = new FullMediatorData(mediator, new MediatorInfo(mediator.getId()));

        objectCreation = new FullMediatorDataCreateNotification(fullMediatorData);

        objectDeletion = new ObjectDeletion();
        objectDeletion.setDeletedObject(mediator);

        attributeValueChange = new AttributeValueChange();
        final IMediator changedMediator = new MediatorItem();
        changedMediator.setId(1);
        changedMediator.setActivation(EnableSwitch.DISABLED);
        final IMediatorMarkable markable = MediatorMarkableItem.of(changedMediator);
        markable.setIdName("MEDIATOR_TEST_MARKABLE");
        markable.markActivation(false);
        attributeValueChange.setChangedObject(markable);

        cache.fetch(new ArrayList<Element>());

        when(message.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
    }

    @After
    public void release() throws CacheException {
        cache.clear();
    }

    @Test
    public void testCreateObject() throws JMSException, CacheException {
        when(message.getObject()).thenReturn(objectCreation);

        assertTrue(cache.all().isEmpty());

        manager.eventPluginTopicMessage(message);

        verifyObject();
    }

    @Test
    public void testDeleteObject() throws JMSException, CacheException {
        when(message.getObject()).thenReturn(objectDeletion);

        assertTrue(cache.all().isEmpty());

        cache.put(fullMediatorData.getMediator().getId(), fullMediatorData);

        verifyObject();

        manager.eventPluginTopicMessage(message);

        assertTrue(cache.all().isEmpty());
    }

    @Test
    public void testAvcObject() throws JMSException, CacheException {
        when(message.getObject()).thenReturn(attributeValueChange);

        assertTrue(cache.all().isEmpty());

        cache.put(fullMediatorData.getMediator().getId(), fullMediatorData);

        verifyObject();

        manager.eventPluginTopicMessage(message);

        assertThat("MEDIATOR_TEST_MARKABLE", is(cache.find(fullMediatorData.getMediator().getId()).get().getIdName()));
        assertThat(EnableSwitch.ENABLED, is(cache.find(fullMediatorData.getMediator().getId()).get().getMediator().getActivation()));
    }

    private void verifyObject() throws CacheException {
        assertThat(fullMediatorData.getMediator().getId(), is(cache.find(fullMediatorData.getMediator().getId()).get().getMediator().getId()));
        assertThat(fullMediatorData.getIdName(), is(cache.find(fullMediatorData.getMediator().getId()).get().getIdName()));

        assertThat(cache.all().size(), is(1));
    }
}
