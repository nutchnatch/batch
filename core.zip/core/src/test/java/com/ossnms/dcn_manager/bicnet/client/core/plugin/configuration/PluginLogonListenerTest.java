package com.ossnms.dcn_manager.bicnet.client.core.plugin.configuration;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.view.RestoreViews;
import org.junit.Before;
import org.junit.Test;

import javax.jms.JMSException;
import java.util.Optional;
import java.util.Properties;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class PluginLogonListenerTest {
    private BiCNetPluginSite pluginSite;
    private ISessionContext context;
    private RestoreViews restoreViews;
    private DcnPluginHelper pluginHelper;
    private PluginLogonListener listener;
    private ISecureClientSession clientSession;
    private SecureActionValidation secureActionValidation;

    @Before
    public void setup() throws JMSException, BcbException {
        pluginSite = mock(BiCNetPluginSite.class);
        context = mock(ISessionContext.class);
        restoreViews = mock(RestoreViews.class);
        pluginHelper = mock(DcnPluginHelper.class);
        clientSession = mock(ISecureClientSession.class);
        secureActionValidation = mock(SecureActionValidation.class);

        listener = new PluginLogonListener(pluginHelper, restoreViews, secureActionValidation);
    }

    @Test
    public void testEventUserLoggedOn() {
        listener.eventUserLoggedOn(context);

        verify(restoreViews, times(1)).restoreOpenedViews();
        verify(secureActionValidation, times(1)).reloadVisibilityCache();
    }

    @Test
    public void testEventUserLoggingOff() {
        listener.eventUserLoggingOff(context);

        verify(restoreViews, times(1)).saveOpenedViews();
    }

    @Test
    public void testEventUserLoggedOff() {
        final Properties properties = new Properties();

        when(pluginHelper.getClientSession()).thenReturn(Optional.of(clientSession));
        when(pluginHelper.getPluginId()).thenReturn("plugin_id");
        when(clientSession.getUserProfile("plugin_id")).thenReturn(properties);

        listener.eventUserLoggedOff(context);

        verify(pluginHelper, times(1)).getClientSession();
        verify(clientSession, times(1)).getUserProfile("plugin_id");
        verify(clientSession, times(1)).setUserProfile("plugin_id", properties);
        verify(pluginHelper, times(2)).getPluginId();
    }

    @Test
    public void testEventUserPermissionsChanged() {
        listener.eventUserPermissionsChanged(context);

        verify(pluginHelper, times(1)).initialize(context);
        verify(secureActionValidation, times(1)).reloadVisibilityCache();
    }

    @Test
    public void testGetPluginSite() {
        when(pluginHelper.getCfPluginSite()).thenReturn(pluginSite);

        listener.getPluginSite();

        verify(pluginHelper, times(1)).getCfPluginSite();
    }
}
