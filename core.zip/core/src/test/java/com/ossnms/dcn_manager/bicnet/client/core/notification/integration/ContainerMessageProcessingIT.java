package com.ossnms.dcn_manager.bicnet.client.core.notification.integration;

import com.coriant.widgets.treetable.TreeTable;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.core.notification.NotificationManager;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.ContainerTreeNodeEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainerRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ContainerCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.BicnetChangeListenerManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.ContainerGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import java.util.ArrayList;
import java.util.Optional;
import java.util.concurrent.TimeoutException;

import static com.google.code.tempusfugit.temporal.Duration.seconds;
import static com.google.code.tempusfugit.temporal.Timeout.timeout;
import static com.google.code.tempusfugit.temporal.WaitFor.waitOrTimeout;
import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.DCN_MANAGER;
import static com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration.SENDER_ID;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Test the flow from BiCNet message to TreeTable Model for Containers.
 */
public class ContainerMessageProcessingIT {

    private static final int PROCESS_TIMEOUT_S = 40;
    private static final int CONTAINER_ID = 1;

    private NotificationManager manager;
    private CacheWrapper<Integer, IGenericContainer> cache;

    private ListenersRegistrationManager cacheChangeListener;
    private EventChangeListener<IGenericContainer> changeListener;

    private BicnetChangeListenerManager bicnetChangeListenerManager;
    private BiCNetPluginEmNeChangeListenerImpl biCNetPluginEmNeChangeListener;

    private TreeTableViewModel model;

    private NodeContainerRoot rootNode;

    private ObjectMessage messageForCreate;
    private ObjectMessage messageForUpdate;
    private ObjectMessage messageForDelete;

    @Before @SuppressWarnings("unchecked") public void setup() throws JMSException{
        messageForCreate = mock(ObjectMessage.class);
        messageForUpdate = mock(ObjectMessage.class);
        messageForDelete = mock(ObjectMessage.class);
        BicnetServerFacade facade = mock(BicnetServerFacade.class);
        TreeTable treeTable = mock(TreeTable.class);
        RepositoryManager repositoryManager = mock(RepositoryManager.class);
        CommonServices commonServices = mock(CommonServices.class);
        DcnPluginHelper dcnPluginHelper = mock(DcnPluginHelper.class);
        SecureActionValidation secureActionValidation = mock(SecureActionValidation.class);

        // Initialize Notification manager
        manager = new NotificationManager();
        cache = ContainerCacheManager.getInstance().cache();
        cache.fetch(new ArrayList<>());

        // Initialize Container TreeTable Change listener
        rootNode = new NodeContainerRoot("TNMS");
        model = new TreeTableViewModel(rootNode);

        when(commonServices.getDcnPluginHelper()).thenReturn(dcnPluginHelper);
        when(commonServices.getSecureActionValidation()).thenReturn(secureActionValidation);

        when(secureActionValidation.checkPermission(any(SecureAction.class))).thenReturn(true);
        when(secureActionValidation.checkPermission(any(SecureAction.class), any(IManagedObjectId[].class)))
                .thenReturn(true);

        when(repositoryManager.getNeRepository())
                .thenReturn(new NeRepository(facade, NeCacheManager.getInstance().cache()));

        changeListener = new ContainerTreeNodeEventListener(new TreeTableModelUpdater(model, treeTable),
                new CommonServices(), repositoryManager,
                new ContainerGraphicalRepresentationBuilder(new IconManager()));

        cacheChangeListener = new CacheListenersRegistrationManager();
        cacheChangeListener.addContainerListener(changeListener);

        biCNetPluginEmNeChangeListener = new BiCNetPluginEmNeChangeListenerImpl();
        bicnetChangeListenerManager = new BicnetChangeListenerManager();
        bicnetChangeListenerManager.add(biCNetPluginEmNeChangeListener);

        when(messageForCreate.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
        when(messageForUpdate.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
        when(messageForDelete.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
    }

    @After public void clear() throws CacheException {
        cache.clear();
        cacheChangeListener.removeContainerListener(changeListener);
        bicnetChangeListenerManager.remove(biCNetPluginEmNeChangeListener);
    }

    @Test public void testCreateObjectListeners() throws Exception {
        final IGenericContainer containerFromBcb = buildObjectCreationScenario();

        // Verify if the Root Node was updated
        assertThat(rootNode.getChildCount(), is(1));

        // Verify Bicnet Listener
        assertThat(biCNetPluginEmNeChangeListener.isCreatedCalled(), is(true));

        final NodeContainer containerInModel = (NodeContainer) rootNode.getChildAt(0);

        verifyTableModel(containerInModel);
        verifyNodeContainer(containerFromBcb, containerInModel);
    }

    @Test public void testUpdateObjectListeners() throws Exception {

        final IGenericContainer containerForCreate = buildObjectCreationScenario();
        final IGenericContainerMarkable containerForUpdate = buildAttributeValueChangeScenario(containerForCreate);

        waitOrTimeout(() -> biCNetPluginEmNeChangeListener.isUpdateCalled(), timeout(seconds(PROCESS_TIMEOUT_S)));
        waitOrTimeout(() -> rootNode.getChildCount() == 1, timeout(seconds(PROCESS_TIMEOUT_S)));

        // Verify if the Root Node was updated
        assertThat(rootNode.getChildCount(), is(1));

        // Verify Bicnet Listener
        assertThat(biCNetPluginEmNeChangeListener.isUpdateCalled(), is(true));

        final NodeContainer containerInModel = (NodeContainer) rootNode.getChildAt(0);

        verifyTableModel(containerInModel);
        verifyNodeContainer(containerForUpdate, containerInModel);
    }

    @Test public void testDeleteObjectListeners() throws Exception {

        buildObjectCreationScenario();

        final ObjectDeletion objectDeletion = new ObjectDeletion();
        objectDeletion.setDeletedObject(new GenericContainerIdItem(CONTAINER_ID));
        when(messageForDelete.getObject()).thenReturn(objectDeletion);
        manager.eventPluginTopicMessage(messageForDelete);

        // Verify cache
        final Optional<IGenericContainer> containerInCache = cache.find(1);
        assertFalse(containerInCache.isPresent());

        // Wait for SwingWorker process the Node deletion
        waitOrTimeout(() -> rootNode.getChildCount() == 0, timeout(seconds(PROCESS_TIMEOUT_S)));

        // Verify if the Root Node was updated
        assertThat(rootNode.getChildCount(), is(0));

        // Verify Bicnet Listener
        assertThat(biCNetPluginEmNeChangeListener.isDeleteCalled(), is(true));
    }

    private IGenericContainerMarkable buildAttributeValueChangeScenario(final IGenericContainer containerForCreate)
            throws JMSException, CacheException, InterruptedException, TimeoutException {
        final IGenericContainerMarkable containerForUpdate = containerForCreate.toMarkableGenericContainer(true);
        containerForUpdate.setIdName("NEW_NAME");

        // Process AVC
        final AttributeValueChange attributeValueChange = new AttributeValueChange();
        attributeValueChange.setChangedObject(containerForUpdate);
        when(messageForUpdate.getObject()).thenReturn(attributeValueChange);
        manager.eventPluginTopicMessage(messageForUpdate);

        // Verify cache
        final Optional<IGenericContainer> containerInCache = cache.find(1);
        assertTrue(containerInCache.isPresent());

        // Wait for SwingWorker process the Node updater
        waitOrTimeout(() -> rootNode.getChildCount() >= 1 && ((Node) rootNode.getChildAt(0)).getValue().getName()
                .equals(containerForUpdate.getIdName()), timeout(seconds(PROCESS_TIMEOUT_S)));

        return containerForUpdate;
    }

    private IGenericContainer buildObjectCreationScenario()
            throws JMSException, CacheException, InterruptedException, TimeoutException {
        final IGenericContainer containerFromBcb = buildContainer();

        // Process Object Creation
        final ObjectCreation objectCreation = new ObjectCreation();
        objectCreation.setCreatedObject(containerFromBcb);
        when(messageForCreate.getObject()).thenReturn(objectCreation);
        manager.eventPluginTopicMessage(messageForCreate);

        // Verify cache
        final Optional<IGenericContainer> containerInCache = cache.find(1);
        assertTrue(containerInCache.isPresent());

        // Wait for SwingWorker process the Node creation
        waitOrTimeout(() -> rootNode.getChildCount() >= 1, timeout(seconds(PROCESS_TIMEOUT_S)));

        return containerFromBcb;
    }

    private void verifyTableModel(final NodeContainer containerInModel) {
        assertThat(model.getChildCount(rootNode), is(1));
        assertThat(model.getNodeIcon(rootNode), is(rootNode.getValue().getGraphicalRepresentation()));
        assertThat(model.getNodeIcon(containerInModel), is(containerInModel.getValue().getGraphicalRepresentation()));

        assertFalse(model.isToggleButtonVisible(rootNode));
        assertFalse(model.isToggleButtonVisible(containerInModel));

        assertThat(model.getChild(rootNode, 0), is(containerInModel));

        assertThat(model.getColumnName(ColumnId.TREE_MODEL.ordinal()), is(TreeTableLabels.COLUMN_ROOT.toString()));
        assertThat(model.getColumnName(ColumnId.STATE.ordinal()), is(TreeTableLabels.COLUMN_STATE.toString()));
        assertThat(model.getColumnName(ColumnId.NETWORK_NAME.ordinal()),
                is(TreeTableLabels.COLUMN_NETWORK_NAME.toString()));
        assertThat(model.getColumnName(ColumnId.TYPE.ordinal()), is(TreeTableLabels.COLUMN_TYPE.toString()));
        assertThat(model.getColumnName(ColumnId.INFO.ordinal()), is(TreeTableLabels.COLUMN_INFO.toString()));
        assertThat(model.getColumnName(ColumnId.ADDRESS.ordinal()), is(TreeTableLabels.COLUMN_ADDRESS.toString()));
        assertThat(model.getColumnName(ColumnId.CONNECT_VIA.ordinal()),
                is(TreeTableLabels.COLUMN_CONNECT_VIA.toString()));
    }

    private void verifyNodeContainer(final IGenericContainer container, final NodeContainer containerInModel) {
        assertThat(containerInModel.getId(), is(container.getId()));

        assertThat(containerInModel.getValue().getName(), is(container.getIdName()));
        assertThat(containerInModel.getValue().isToogleButtonVisible(), is(false));

        assertNotNull(containerInModel.getValue().getGraphicalRepresentation());
    }

    private IGenericContainer buildContainer() {
        final IGenericContainer container = new GenericContainerItem();
        container.setId(CONTAINER_ID);
        container.setIdName("NAME_1");
        return container;
    }
}
