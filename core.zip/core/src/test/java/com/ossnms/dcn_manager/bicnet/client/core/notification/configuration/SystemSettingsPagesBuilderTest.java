package com.ossnms.dcn_manager.bicnet.client.core.notification.configuration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import javax.annotation.Nonnull;

import org.junit.Test;
import org.mockito.Mockito;

import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPage;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.core.plugin.configuration.SystemSettingsPagesBuilder;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ConfigurationRepository;
import com.ossnms.dcn_manager.bicnet.client.settings.global.view.GlobalSettingsPageView;

public class SystemSettingsPagesBuilderTest {

    private FrameworkPluginHelper helper;
    private ConfigurationRepository repository;
    
    @Nonnull
    public void setup() {
        helper = Mockito.mock(FrameworkPluginHelper.class);
        repository = Mockito.mock(ConfigurationRepository.class);
    }
    
    @Test
    public void testBuild() {
        final SystemSettingsPagesBuilder builder = new SystemSettingsPagesBuilder();
        final ImmutableMap<BiCNetPluginMainContext, BiCNetPluginPropertyPage[]> map = builder.build(helper, repository);
        
        assertNotNull(map);
        assertFalse(map.isEmpty());
        assertFalse(map.values().isEmpty());
    }
    
    @Test
    public void testValues() {
        final SystemSettingsPagesBuilder builder = new SystemSettingsPagesBuilder();
        final ImmutableMap<BiCNetPluginMainContext, BiCNetPluginPropertyPage[]> map = builder.build(helper, repository);
        final BiCNetPluginPropertyPage[] values = map.get(BiCNetPluginMainContext.ADMINISTRATION);
        
        assertTrue(map.containsKey(BiCNetPluginMainContext.ADMINISTRATION));
        assertNotNull(values);
        assertTrue(FluentIterable.from(ImmutableList.copyOf(values)).filter(GlobalSettingsPageView.class).first().isPresent());
    }
}
