package com.ossnms.dcn_manager.bicnet.client.core.notification.integration;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginEmNeChangeListener;

public class BiCNetPluginEmNeChangeListenerImpl implements BiCNetPluginEmNeChangeListener {

    private boolean createdCalled;
    private boolean updateCalled;
    private boolean deleteCalled;

    /**
     * Invoked when object is created
     *
     * @param object the created object. Expected objects include NE, System Container, EM
     */
    @Override public void onCreate(IManagedObject object) {
        createdCalled = true;
    }

    /**
     * Invoked when object is modified
     *
     * @param object the associated modifications. Expected objects include NE, System Container, EM
     */
    @Override public void onChanged(IManagedObjectMarkable object) {
        updateCalled = true;
    }

    /**
     * Invoked when object is deleted
     *
     * @param object the id of the deleted object. Expected objects include NE, System Container, EM
     */
    @Override public void onDelete(IManagedObjectId object) {
        deleteCalled = true;
    }

    public boolean isCreatedCalled() {
        return createdCalled;
    }

    public boolean isUpdateCalled() {
        return updateCalled;
    }

    public boolean isDeleteCalled() {
        return deleteCalled;
    }
}