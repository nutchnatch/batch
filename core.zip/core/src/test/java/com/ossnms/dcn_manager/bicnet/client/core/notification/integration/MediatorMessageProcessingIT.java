package com.ossnms.dcn_manager.bicnet.client.core.notification.integration;

import com.coriant.widgets.treetable.TreeTable;
import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.core.notification.NotificationManager;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.listener.MediatorTreeNodeEventListener;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.ModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.TreeTableModelUpdater;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.ColumnId;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediatorRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.TreeTableViewModel;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.MediatorCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.BicnetChangeListenerManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.MediatorRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.StaticConfiguration;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.i18n.TreeTableLabels;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder.MediatorGraphicalRepresentationBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.annotation.Nonnull;
import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import java.util.ArrayList;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static com.google.code.tempusfugit.temporal.Duration.seconds;
import static com.google.code.tempusfugit.temporal.Timeout.timeout;
import static com.google.code.tempusfugit.temporal.WaitFor.waitOrTimeout;
import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.DCN_MANAGER;
import static com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.GM;
import static com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration.SENDER_ID;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Test the flow from BiCNet message to TreeTable Model for Mediators.
 */
public class MediatorMessageProcessingIT {

    private static final int PROCESS_TIMEOUT_S = 20;
    private static final int MEDIATOR_ID = 1;

    private NotificationManager manager;
    private CacheWrapper<Integer, FullMediatorData> cache;

    private ListenersRegistrationManager cacheChangeListener;
    private MediatorTreeNodeEventListenerWrapper mediatorChangeListener;

    private BicnetChangeListenerManager bicnetChangeListenerManager;
    private BiCNetPluginEmNeChangeListenerImpl biCNetPluginEmNeChangeListener;

    private TreeTableViewModel model;
    private NodeMediatorRoot rootNode;

    private ObjectMessage messageForCreate;
    private ObjectMessage messageForUpdate;
    private ObjectMessage messageForDelete;

    private static final class MediatorTreeNodeEventListenerWrapper extends MediatorTreeNodeEventListener {

        private final CountDownLatch removeLatch = new CountDownLatch(1);
        private final CountDownLatch addLatch = new CountDownLatch(1);
        private final CountDownLatch updateLatch = new CountDownLatch(1);

        private MediatorTreeNodeEventListenerWrapper(@Nonnull ModelUpdater modelUpdater, CommonServices commonServices,
                RepositoryManager repositoryManager, MediatorGraphicalRepresentationBuilder graphicalRepresentation) {
            super(modelUpdater, commonServices, repositoryManager, graphicalRepresentation);
        }

        @Override protected void remove(@Nonnull FullMediatorData fullMediatorData) {
            super.remove(fullMediatorData);
            removeLatch.countDown();
        }

        @Override protected void add(@Nonnull FullMediatorData fullMediatorData) {
            super.add(fullMediatorData);
            addLatch.countDown();
        }

        @Override protected void update(@Nonnull FullMediatorData fullMediatorData) {
            super.update(fullMediatorData);
            updateLatch.countDown();
        }
    }

    @Before @SuppressWarnings("unchecked") public void setup() throws JMSException {
        final TreeTable<Node> treeTable = mock(TreeTable.class);
        messageForCreate = mock(ObjectMessage.class);
        messageForUpdate = mock(ObjectMessage.class);
        messageForDelete = mock(ObjectMessage.class);
        final BicnetServerFacade facade = mock(BicnetServerFacade.class);
        final RepositoryManager repositoryManager = mock(RepositoryManager.class);
        final CommonServices commonServices = mock(CommonServices.class);
        final DcnPluginHelper dcnPluginHelper = mock(DcnPluginHelper.class);
        final SecureActionValidation secureActionValidation = mock(SecureActionValidation.class);
        final IconManager iconManager = mock(IconManager.class);
        final StaticConfiguration staticConfiguration = mock(StaticConfiguration.class);

        // Initialize Notification manager
        manager = new NotificationManager();
        cache = MediatorCacheManager.getInstance().cache();
        cache.fetch(new ArrayList<>());

        // Initialize Mediator TreeTable Change listener
        rootNode = new NodeMediatorRoot("TNMS");
        model = new TreeTableViewModel(rootNode);

        when(commonServices.getDcnPluginHelper()).thenReturn(dcnPluginHelper);
        when(commonServices.getSecureActionValidation()).thenReturn(secureActionValidation);
        when(commonServices.getStaticConfiguration()).thenReturn(staticConfiguration);

        when(secureActionValidation.checkPermission(any(SecureAction.class))).thenReturn(true);
        when(secureActionValidation.checkPermission(any(SecureAction.class), any(IManagedObjectId[].class)))
                .thenReturn(true);

        when(repositoryManager.getMediatorRepository())
                .thenReturn(new MediatorRepository(facade, MediatorCacheManager.getInstance().cache()));
        when(iconManager.findNetworkIcon(any(IMediator.class), anyInt())).thenReturn(Optional.empty());

        mediatorChangeListener = new MediatorTreeNodeEventListenerWrapper(new TreeTableModelUpdater(model, treeTable),
                commonServices, repositoryManager, new MediatorGraphicalRepresentationBuilder(new IconManager()));

        cacheChangeListener = new CacheListenersRegistrationManager();
        cacheChangeListener.addMediatorListener(mediatorChangeListener);

        biCNetPluginEmNeChangeListener = new BiCNetPluginEmNeChangeListenerImpl();
        bicnetChangeListenerManager = new BicnetChangeListenerManager();
        bicnetChangeListenerManager.add(biCNetPluginEmNeChangeListener);

        when(messageForCreate.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
        when(messageForUpdate.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
        when(messageForDelete.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());

        MediatorType gmType = mock(MediatorType.class);
        when(gmType.guiLabel()).thenReturn(Optional.of("Generic Mediator"));
        when(staticConfiguration.findMediatorType("GM")).thenReturn(Optional.of(gmType));
    }

    @After public void clear() throws CacheException {
        cache.clear();
        cacheChangeListener.removeMediatorListener(mediatorChangeListener);
        bicnetChangeListenerManager.remove(biCNetPluginEmNeChangeListener);
    }

    @Test public void testCreateObjectListeners() throws Exception {
        final FullMediatorData mediatorFromBcb = buildObjectCreationScenario();

        // Verify TreeTable Listener
        assertThat(rootNode.getChildCount(), is(1));

        // Verify Bicnet Listener
        assertThat(biCNetPluginEmNeChangeListener.isCreatedCalled(), is(true));

        final NodeMediator mediatorInModel = (NodeMediator) rootNode.getChildAt(0);

        verifyTableModel(mediatorInModel);
        verifyNodeMediator(mediatorFromBcb.getMediator(), mediatorInModel);
    }

    @Test public void testUpdateObjectListeners() throws Exception {
        final FullMediatorData mediatorForCreate = buildObjectCreationScenario();
        final IMediatorMarkable mediatorForUpdate = buildAttributeValueChangeScenario(mediatorForCreate.getMediator());

        waitOrTimeout(() -> biCNetPluginEmNeChangeListener.isUpdateCalled(), timeout(seconds(PROCESS_TIMEOUT_S)));
        waitOrTimeout(() -> rootNode.getChildCount() == 1, timeout(seconds(PROCESS_TIMEOUT_S)));

        // Verify if the Root Node was updated
        assertThat(rootNode.getChildCount(), is(1));

        // Verify Bicnet Listener
        assertThat(biCNetPluginEmNeChangeListener.isUpdateCalled(), is(true));

        final NodeMediator mediatorInModel = (NodeMediator) rootNode.getChildAt(0);

        verifyTableModel(mediatorInModel);
        verifyNodeMediator(mediatorForUpdate, mediatorInModel);
    }

    @Test public void testDeleteObjectListeners() throws Exception {

        buildObjectCreationScenario();

        final ObjectDeletion objectDeletion = new ObjectDeletion();
        objectDeletion.setDeletedObject(new MediatorIdItem(MEDIATOR_ID));
        when(messageForDelete.getObject()).thenReturn(objectDeletion);
        manager.eventPluginTopicMessage(messageForDelete);

        // Verify cache
        final Optional<FullMediatorData> mediatorInCache = cache.find(1);
        assertFalse(mediatorInCache.isPresent());

        // Wait for SwingWorker process the Node deletion
        boolean removalCompleted = mediatorChangeListener.removeLatch.await(PROCESS_TIMEOUT_S, TimeUnit.SECONDS);
        assertThat(removalCompleted, is(true));

        // Verify if the Root Node was updated
        assertThat(rootNode.getChildCount(), is(0));

        // Verify Bicnet Listener
        assertThat(biCNetPluginEmNeChangeListener.isDeleteCalled(), is(true));
    }

    private IMediatorMarkable buildAttributeValueChangeScenario(final IMediator mediatorForCreate)
            throws JMSException, CacheException, InterruptedException, TimeoutException {
        final IMediatorMarkable mediatorForUpdate = mediatorForCreate.toMarkableMediator(true);
        mediatorForUpdate.setIdName("NEW_NAME");
        mediatorForUpdate.setActivation(EnableSwitch.ENABLED);
        mediatorForUpdate.setDisplayAddress("NEW_DISPLAY");
        mediatorForUpdate.setIconIdId("EM-GM");
        mediatorForUpdate.setMediatorType(GM);
        mediatorForUpdate.setDisplayAddress("127.0.0.1");
        mediatorForUpdate.setDisplayState("Active");

        // Process AVC
        final AttributeValueChange attributeValueChange = new AttributeValueChange();
        attributeValueChange.setChangedObject(mediatorForUpdate);
        when(messageForUpdate.getObject()).thenReturn(attributeValueChange);
        manager.eventPluginTopicMessage(messageForUpdate);

        // Verify cache
        final Optional<FullMediatorData> mediatorInCache = cache.find(1);
        assertTrue(mediatorInCache.isPresent());

        // Wait for SwingWorker process the Node updater
        boolean updateCompleted = mediatorChangeListener.updateLatch.await(PROCESS_TIMEOUT_S, TimeUnit.SECONDS);
        assertThat(updateCompleted, is(true));

        return mediatorForUpdate;
    }

    private FullMediatorData buildObjectCreationScenario()
            throws JMSException, CacheException, InterruptedException, TimeoutException {
        // Process Object Creation
        final FullMediatorDataCreateNotification objectCreation = new FullMediatorDataCreateNotification(
                buildMediator());

        when(messageForCreate.getObject()).thenReturn(objectCreation);
        manager.eventPluginTopicMessage(messageForCreate);

        // Verify cache
        final Optional<FullMediatorData> mediatorInCache = cache.find(1);
        assertTrue(mediatorInCache.isPresent());

        // Wait for SwingWorker process the Node creation
        boolean completed = mediatorChangeListener.addLatch.await(PROCESS_TIMEOUT_S, TimeUnit.SECONDS);
        assertThat(completed, is(true));

        return objectCreation.getFullMediatorData();
    }

    private void verifyTableModel(final NodeMediator mediatorInModel) {
        assertThat(model.getChildCount(rootNode), is(1));
        assertThat(model.getNodeIcon(rootNode), is(rootNode.getValue().getGraphicalRepresentation()));
        assertThat(model.getNodeIcon(mediatorInModel), is(mediatorInModel.getValue().getGraphicalRepresentation()));

        assertFalse(model.isToggleButtonVisible(rootNode));
        assertTrue(model.isToggleButtonVisible(mediatorInModel));
        assertTrue(model.isToggleButtonEnabled(mediatorInModel));

        assertThat(model.getToggleButtonsModifiable(ImmutableList.of(mediatorInModel)).get(0).getId(), is(MEDIATOR_ID));

        assertThat(model.getChild(rootNode, 0), is(mediatorInModel));

        assertThat(model.getColumnName(ColumnId.TREE_MODEL.ordinal()), is(TreeTableLabels.COLUMN_ROOT.toString()));
        assertThat(model.getColumnName(ColumnId.STATE.ordinal()), is(TreeTableLabels.COLUMN_STATE.toString()));
        assertThat(model.getColumnName(ColumnId.NETWORK_NAME.ordinal()),
                is(TreeTableLabels.COLUMN_NETWORK_NAME.toString()));
        assertThat(model.getColumnName(ColumnId.TYPE.ordinal()), is(TreeTableLabels.COLUMN_TYPE.toString()));
        assertThat(model.getColumnName(ColumnId.INFO.ordinal()), is(TreeTableLabels.COLUMN_INFO.toString()));
        assertThat(model.getColumnName(ColumnId.ADDRESS.ordinal()), is(TreeTableLabels.COLUMN_ADDRESS.toString()));
        assertThat(model.getColumnName(ColumnId.CONNECT_VIA.ordinal()),
                is(TreeTableLabels.COLUMN_CONNECT_VIA.toString()));
    }

    private void verifyNodeMediator(final IMediator mediator, final NodeMediator mediatorInModel) {
        assertThat(mediatorInModel.getId(), is(mediator.getId()));

        assertThat(mediatorInModel.getValue().getName(), is(mediator.getIdName()));
        assertThat(mediatorInModel.getValue().isToogleButtonUnChecked(),
                is(mediator.getActivation() == EnableSwitch.DISABLED));
        assertThat(mediatorInModel.getValue().isToogleButtonChecked(),
                is(mediator.getActivation() == EnableSwitch.ENABLED));
        assertThat(mediatorInModel.getValue().isToogleButtonEnable(), is(true));
        assertThat(mediatorInModel.getValue().isToogleButtonVisible(), is(true));

        assertTrue(mediatorInModel.getColumns().valueOf(ColumnId.INFO).isPresent());
        assertThat(mediatorInModel.getColumns().valueOf(ColumnId.INFO).get().getValue(),
                is(mediator.getAdditionalInfo()));

        assertTrue(mediatorInModel.getColumns().valueOf(ColumnId.STATE).isPresent());
        assertThat(mediatorInModel.getColumns().valueOf(ColumnId.STATE).get().getValue(),
                is(mediator.getDisplayState()));

        assertTrue(mediatorInModel.getColumns().valueOf(ColumnId.ADDRESS).isPresent());
        assertThat(mediatorInModel.getColumns().valueOf(ColumnId.ADDRESS).get().getValue(),
                is(mediator.getDisplayAddress()));

        assertTrue(mediatorInModel.getColumns().valueOf(ColumnId.TYPE).isPresent());
        assertThat(mediatorInModel.getColumns().valueOf(ColumnId.TYPE).get().getValue(),
                is(mediator.getMediatorType().guiLabel()));

        assertNotNull(mediatorInModel.getValue().getGraphicalRepresentation());
    }

    private FullMediatorData buildMediator() {
        final IMediator mediator = new MediatorItem();
        mediator.setId(MEDIATOR_ID);
        mediator.setIdName("GM_1");
        mediator.setActivation(EnableSwitch.ENABLED);
        mediator.setDisplayAddress("test");
        mediator.setIconIdId("EM-GM");
        mediator.setMediatorType(GM);
        mediator.setDisplayAddress("127.0.0.1");
        mediator.setDisplayState("Active");

        FullMediatorData fullMediatorData = new FullMediatorData(mediator, new MediatorInfo(mediator.getId()));
        fullMediatorData.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);
        fullMediatorData.getInfo().setUserText("user_text");

        return fullMediatorData;
    }

}
