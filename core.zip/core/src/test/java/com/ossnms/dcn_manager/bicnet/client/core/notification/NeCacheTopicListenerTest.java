package com.ossnms.dcn_manager.bicnet.client.core.notification;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEMarkableItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NEContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import java.util.ArrayList;

import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.DCN_MANAGER;
import static com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration.SENDER_ID;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NeCacheTopicListenerTest {

    private final NotificationManager manager = new NotificationManager();
    private final CacheWrapper<Integer, FullNeData> cache = NeCacheManager.getInstance().cache();

    private ObjectMessage message;
    private FullNeDataCreateNotification objectCreation;
    private ObjectDeletion objectDeletion;
    private AttributeValueChange attributeValueChange;

    private FullNeData ne;

    @Before
    public void setup() throws JMSException, BcbException {
        message = mock(ObjectMessage.class);

        final INE neItem = new NEItem();
        neItem.setIdName("NE_TEST");
        neItem.setActivation(EnableSwitch.ENABLED);
        neItem.setId(1);

        ne = new FullNeData(neItem, new NeInfo(neItem.getId()), null);

        objectCreation = new FullNeDataCreateNotification(ne);

        objectDeletion = new ObjectDeletion();
        objectDeletion.setDeletedObject(neItem);

        attributeValueChange = new AttributeValueChange();
        final INE changedNe = new NEItem();
        changedNe.setId(1);
        changedNe.setActivation(EnableSwitch.DISABLED);
        final INEMarkable markable = NEMarkableItem.of(changedNe);
        markable.setIdName("NE_TEST_MARKABLE");
        markable.markActivation(false);
        attributeValueChange.setChangedObject(markable);

        cache.fetch(new ArrayList<>());
        NEContainerAssignmentCacheManager.getInstance().cache().fetch(new ArrayList<>());

        when(message.getStringProperty(SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
    }

    @After
    public void release() throws CacheException {
        cache.clear();
    }

    @Test
    public void testCreateObject() throws JMSException, CacheException {
        when(message.getObject()).thenReturn(objectCreation);

        assertTrue(cache.all().isEmpty());

        manager.eventPluginTopicMessage(message);

        verifyObject();
    }

    @Test
    public void testDeleteObject() throws JMSException, CacheException {
        when(message.getObject()).thenReturn(objectDeletion);

        assertTrue(cache.all().isEmpty());

        cache.put(ne.getNe().getId(), ne);

        verifyObject();

        manager.eventPluginTopicMessage(message);

        assertTrue(cache.all().isEmpty());
    }

    @Test
    public void testAvcObject() throws JMSException, CacheException {
        when(message.getObject()).thenReturn(attributeValueChange);

        assertTrue(cache.all().isEmpty());

        cache.put(ne.getNe().getId(), ne);

        verifyObject();

        manager.eventPluginTopicMessage(message);

        assertThat("NE_TEST_MARKABLE", is(cache.find(ne.getNe().getId()).get().getNe().getIdName()));
        assertThat(EnableSwitch.ENABLED, is(cache.find(ne.getNe().getId()).get().getNe().getActivation()));
    }

    private void verifyObject() throws CacheException {
        assertThat(ne.getNe().getId(), is(cache.find(ne.getNe().getId()).get().getNe().getId()));
        assertThat(ne.getNe().getIdName(), is(cache.find(ne.getNe().getId()).get().getNe().getIdName()));

        assertThat(cache.all().size(), is(1));
    }
}
