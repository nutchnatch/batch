package com.ossnms.dcn_manager.bicnet.client.core.notification.configuration;

import static org.junit.Assert.assertThat;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration;

public class NotificationTopicConfigurationTest {

    @Test
    public void testConfiguration() {
        assertThat(NotificationTopicConfiguration.SENDER_ID.getName(), CoreMatchers.is("SenderId"));
        assertThat(NotificationTopicConfiguration.TOPIC_FACTORY_NAME.getName(), CoreMatchers.is("ConnectionFactoryHornetQ"));
        assertThat(NotificationTopicConfiguration.TOPIC_NAME.getName(), CoreMatchers.is("topic/client"));
    }
}
