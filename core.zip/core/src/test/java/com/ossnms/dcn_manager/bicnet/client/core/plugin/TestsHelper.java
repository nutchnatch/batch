package com.ossnms.dcn_manager.bicnet.client.core.plugin;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.facade.common.IconPairIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorActivationState;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.logger.LoggerManager;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.api.view.MessageBox;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.Node;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeChannel;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeContainer;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeDomain;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediator;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeMediatorRoot;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeNe;
import com.ossnms.dcn_manager.bicnet.client.presentation.views.treetable.node.NodeSystemContainer;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.ChannelSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.ContainerSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.DomainSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeContainerAssignmentSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.SystemAssignmentSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ChannelRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ContainerRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.DomainRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.MediatorRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NEContainerAssignmentRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryManager;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.SystemContainerAssignmentRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.SystemContainerRepository;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.StaticConfiguration;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;

import java.awt.Component;
import java.util.HashSet;

import static com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.MVM;
import static java.util.Comparator.comparing;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SuppressWarnings("unchecked") public abstract class TestsHelper {
    protected static final int ID_1 = 1;
    protected static final int ID_2 = 2;
    protected static final int ID_3 = 3;
    protected static final int ID_4 = 4;
    protected static final int ID_5 = 5;

    protected static final String CONTAINER_NAME = "container";
    protected static final String SYS_CONTAINER_NAME = "sys_container";
    protected static final String MEDIATOR_NAME = "mediator";
    protected static final String CHANNEL_NAME = "channel";
    protected static final String DOMAIN_NAME = "domain";
    protected static final String NE_NAME = "ne_name";

    protected RepositoryManager repositoryManager;
    protected NeRepository neRepository;
    protected MediatorRepository mediatorRepository;
    protected ChannelRepository channelRepository;
    protected DomainRepository domainRepository;
    protected ContainerRepository containerRepository;
    protected SystemContainerRepository systemContainerRepository;
    protected SystemContainerAssignmentRepository systemContainerAssignmentRepository;
    protected NEContainerAssignmentRepository neContainerAssignmentRepository;

    protected NeSearchable neSearchable;
    protected ChannelSearchable channelSearchable;
    protected DomainSearchable domainSearchable;
    protected ContainerSearchable containerSearchable;
    protected SystemAssignmentSearchable systemAssignmentSearchable;
    protected NeContainerAssignmentSearchable neAssignmentSearchable;
    

    protected CommonServices commonServices;
    protected DcnPluginHelper dcnPluginHelper;
    protected BicnetServerFacade bicnetServerFacade;
    protected ISessionContext sessionContext;
    protected SecureActionValidation secureActionValidation;
    protected LoggerManager loggerManager;
    protected IconManager iconManager;
    protected MessageBox messageBox;
    protected StaticConfiguration staticConfiguration;
    protected FrameworkPluginHelper frameworkPluginHelper;

    public TestsHelper() {
        try {
            initBasicWhens();
        } catch (Exception e) {
            Throwables.propagate(e);
        }
    }

    private void initBasicWhens() throws Exception {
        repositoryManager = mock(RepositoryManager.class);
        neRepository = mock(NeRepository.class);
        mediatorRepository = mock(MediatorRepository.class);
        channelRepository = mock(ChannelRepository.class);
        domainRepository = mock(DomainRepository.class);
        containerRepository = mock(ContainerRepository.class);
        systemContainerRepository = mock(SystemContainerRepository.class);
        systemContainerAssignmentRepository = mock(SystemContainerAssignmentRepository.class);
        neContainerAssignmentRepository = mock(NEContainerAssignmentRepository.class);

        neSearchable = mock(NeSearchable.class);
        channelSearchable = mock(ChannelSearchable.class);
        domainSearchable = mock(DomainSearchable.class);
        containerSearchable = mock(ContainerSearchable.class);
        systemAssignmentSearchable = mock(SystemAssignmentSearchable.class);
        neAssignmentSearchable = mock(NeContainerAssignmentSearchable.class);

        commonServices = mock(CommonServices.class);
        dcnPluginHelper = mock(DcnPluginHelper.class);
        bicnetServerFacade = mock(BicnetServerFacade.class);
        sessionContext = mock(ISessionContext.class);
        secureActionValidation = mock(SecureActionValidation.class);
        loggerManager = mock(LoggerManager.class);
        iconManager = mock(IconManager.class);
        messageBox = mock(MessageBox.class);
        staticConfiguration = mock(StaticConfiguration.class);
        frameworkPluginHelper = mock(FrameworkPluginHelper.class);

        when(repositoryManager.getNeRepository()).thenReturn(neRepository);
        when(repositoryManager.getMediatorRepository()).thenReturn(mediatorRepository);
        when(repositoryManager.getDomainRepository()).thenReturn(domainRepository);
        when(repositoryManager.getChannelRepository()).thenReturn(channelRepository);
        when(repositoryManager.getContainerRepository()).thenReturn(containerRepository);
        when(repositoryManager.getSystemContainerRepository()).thenReturn(systemContainerRepository);
        when(repositoryManager.getSystemContainerAssignmentRepository()).thenReturn(systemContainerAssignmentRepository);
        when(repositoryManager.getNEContainerAssignmentRepository()).thenReturn(neContainerAssignmentRepository);

        when(neRepository.queries()).thenReturn(neSearchable);
        when(channelRepository.queries()).thenReturn(channelSearchable);
        when(domainRepository.queries()).thenReturn(domainSearchable);
        when(containerRepository.queries()).thenReturn(containerSearchable);
        when(systemContainerAssignmentRepository.queries()).thenReturn(systemAssignmentSearchable);
        when(neContainerAssignmentRepository.queries()).thenReturn(neAssignmentSearchable);

        when(commonServices.getDcnPluginHelper()).thenReturn(dcnPluginHelper);
        when(commonServices.getFrameworkPluginHelper()).thenReturn(frameworkPluginHelper);
        when(commonServices.getBicnetServerFacade()).thenReturn(bicnetServerFacade);
        when(commonServices.getSecureActionValidation()).thenReturn(secureActionValidation);
        when(commonServices.getLoggerManager()).thenReturn(loggerManager);
        when(commonServices.getIconManager()).thenReturn(iconManager);
        when(commonServices.getMessageBox()).thenReturn(messageBox);
        when(commonServices.getStaticConfiguration()).thenReturn(staticConfiguration);

        when(dcnPluginHelper.getSessionContext()).thenReturn(sessionContext);

        when(messageBox.setComponent(any(Component.class))).thenReturn(messageBox);
    }

    protected final NodeMediatorRoot buildNodeMediatorRoot() {
        return new NodeMediatorRoot("TNMS");
    }

    protected final FullMediatorData buildFullMediatorData(final int id) {
        MediatorInfo mediatorInfo = new MediatorInfo(id);
        mediatorInfo.setGuiActualActivationState(GuiActualActivationState.ACTIVE);
        mediatorInfo.setGuiStandbyActualActivationState(GuiActualActivationState.INACTIVE);
        mediatorInfo.setStandbyMediatorConfigured(false);
        mediatorInfo.setUserText("userText");
        mediatorInfo.setStandbyDisplayState("inactive");

        IMediator mediatorBcb = new MediatorItem();
        mediatorBcb.setId(id);
        mediatorBcb.setIdName(MEDIATOR_NAME + id);
        mediatorBcb.setActivation(EnableSwitch.ENABLED);
        mediatorBcb.setStandbyDisplayState("inactive");
        mediatorBcb.setMediatorHost("127.0.0.1");
        mediatorBcb.setDisplayAddress("127.0.0.1");
        mediatorBcb.setAdditionalInfo("addInfo");
        mediatorBcb.setActualActivationState(MediatorActivationState.ACTIVE);
        IconPairIdItem iconPairIdItem = new IconPairIdItem();
        iconPairIdItem.setId("icon");
        mediatorBcb.setIconId(iconPairIdItem);
        mediatorBcb.setIconIdId("icon");

        mediatorBcb.setMediatorType(MVM);
        MediatorType mvmType = mock(MediatorType.class);
        when(mvmType.guiLabel()).thenReturn(of(MVM.guiLabel()));
        when(staticConfiguration.findMediatorType("MVM")).thenReturn(of(mvmType));

        return new FullMediatorData(mediatorBcb, mediatorInfo);
    }

    protected IGenericContainer buildContainer(final int id) {
        IGenericContainer genericContainer = new GenericContainerItem();
        genericContainer.setId(id);
        genericContainer.setIdName(CONTAINER_NAME + id);
        return genericContainer;
    }

    protected IGenericContainer buildContainer(final int id, final int parent) {
        IGenericContainer genericContainer = new GenericContainerItem();
        genericContainer.setId(id);
        genericContainer.setIdName(CONTAINER_NAME + id);
        genericContainer.setParentId(parent);
        return genericContainer;
    }

    protected ISystemContainer buildSystemContainer(final int id) {
        ISystemContainer container = new SystemContainerItem();
        container.setId(id);
        container.setIdName(SYS_CONTAINER_NAME + id);
        return container;
    }

    protected IAS buildDomain(final int id, INEId[] nes) {
        IAS domain = new ASItem();
        domain.setId(id);
        domain.setIdName(DOMAIN_NAME + id);
        domain.setNeList(nes);

        return domain;
    }

    protected IAS buildDomain(final int id) {
        IAS domain = new ASItem();
        domain.setId(id);
        domain.setIdName(DOMAIN_NAME + id);
        domain.setNeList(new INEId[0]);

        return domain;
    }

    protected NodeContainer buildNodeNeContainer(Node parent, final int id) {
        NodeContainer nodeContainer = new NodeContainer(id, parent);
        nodeContainer.getValue().setName(CONTAINER_NAME + id);
        return nodeContainer;
    }

    protected NodeSystemContainer buildNodeSystemContainer(Node parent, final int id) {
        NodeSystemContainer nodeContainer = new NodeSystemContainer(id, parent);
        nodeContainer.getValue().setName(SYS_CONTAINER_NAME + id);
        return nodeContainer;
    }

    protected NodeMediator buildNodeMediator(Node parent, final int id) {
        NodeMediator nodeMediator = new NodeMediator(id, parent);
        nodeMediator.getValue().setName(MEDIATOR_NAME + id);
        return nodeMediator;
    }

    protected NodeDomain buildNodeDomain(Node parent, final int id) {
        NodeDomain nodeDomain = new NodeDomain(id, parent, comparing(Object::toString, String::compareToIgnoreCase));
        nodeDomain.getValue().setName(DOMAIN_NAME + id);
        return nodeDomain;
    }

    protected ISystemGenericContainerAssignment buildSystemAssigment(int systemId, int containerId) {
        ISystemGenericContainerAssignment assignmentItem = new SystemGenericContainerAssignmentItem();
        assignmentItem.setGenericContainerId(containerId);
        assignmentItem.setSystemContainerId(systemId);
        return assignmentItem;
    }

    protected INeGenericContainerAssignment buildNeAssigment(int neId, int containerId) {
        INeGenericContainerAssignment assignmentItem = new NeGenericContainerAssignmentItem();
        assignmentItem.setGenericContainerId(containerId);
        assignmentItem.setNetworkElementId(neId);
        return assignmentItem;
    }

    protected NodeChannel buildNodeChannel(Node parent, final int id) {
        NodeChannel nodeChannel = new NodeChannel(id, parent);
        nodeChannel.getValue().setName(CHANNEL_NAME + id);
        return nodeChannel;
    }

    protected NodeNe buildNodeNe(Node parent, final int id) {
        NodeNe nodeNe = new NodeNe(id, parent);
        nodeNe.getValue().setName(NE_NAME + id);
        return nodeNe;
    }

    protected final FullChannelData buildFullChannelData(final int id, final int mediatorId) {
        ChannelInfo channelInfo = new ChannelInfo(id);
        channelInfo.setGuiActualActivationState(GuiActualActivationState.ACTIVE);
        channelInfo.setUserText("userText");
        channelInfo.setGuiStandbyActualActivationState(GuiActualActivationState.INACTIVE);
        channelInfo.setStandbyDisplayState("inactive");

        IEM channelBcb = new EMItem();
        channelBcb.setId(id);
        channelBcb.setIdName(CHANNEL_NAME + id);
        channelBcb.setAdditionalInfo("info");
        channelBcb.setAssociatedMediatorId(mediatorId);
        channelBcb.setActivation(EnableSwitch.ENABLED);
        channelBcb.setDisplayAddress("127.0.0.1");

        channelBcb.setEmType("EM-GM");
        ChannelType emType = mock(ChannelType.class);
        when(emType.guiLabel()).thenReturn(empty());
        when(staticConfiguration.findChannelType("EM-GM")).thenReturn(of(emType));

        return new FullChannelData(channelBcb, channelInfo);
    }

    protected final FullNeData buildFullNeData(final int id, final int channelId, final String syncMessage) {
        return buildFullNeData(id, channelId, syncMessage, ScsSyncState.SYNCHRONIZED);
    }

    protected final FullNeData buildFullNeData(final int id, final int channelId, final String syncMessage, ScsSyncState scsSyncState) {
        NeInfo neInfo = new NeInfo(id);
        neInfo.setGuiActualActivationState(GuiActualActivationState.ACTIVE);
        neInfo.setUserText("userText");
        neInfo.setGuiStandbyActualActivationState(GuiActualActivationState.INACTIVE);
        neInfo.setStandbyDisplayState("inactive");
        neInfo.setNeRouteInfo(new HashSet<>());

        INE neBcb = new NEItem();
        neBcb.setId(id);
        neBcb.setIdName(NE_NAME + id);
        neBcb.setAdditionalInfo("info");
        neBcb.setAssociatedEmId(channelId);
        neBcb.setActivation(EnableSwitch.ENABLED);
        neBcb.setNeProxyType("7300");
        neBcb.setDisplayAddress("127.0.0.1");
        neBcb.setRealNeName("realNames");
        neBcb.setConnectedVia("connectVia");
        neBcb.setOperationalState(OperationalState.ENABLED);
        neBcb.setCommissioningStatus(CommissioningStatusSummary.COMMISSIONED);
        neBcb.setEventForwarding(EnableSwitch.ENABLED);

        ScsSynchronizationState scsSynchronizationState = new ScsSynchronizationState(id, scsSyncState, syncMessage);

        return new FullNeData(neBcb, neInfo, scsSynchronizationState);
    }
}
