package com.ossnms.dcn_manager.bicnet.client.core.notification;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMMarkableItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.client.core.notification.configuration.NotificationTopicConfiguration;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ChannelCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import net.sf.ehcache.Element;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import java.util.ArrayList;

import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.DCN_MANAGER;
import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class EmCacheTopicListenerTest {

    private final NotificationManager manager = new NotificationManager();
    private final CacheWrapper<Integer, FullChannelData> cache = ChannelCacheManager.getInstance().cache();

    private ObjectMessage message;
    private FullChannelDataCreateNotification objectCreation;
    private ObjectDeletion objectDeletion;
    private AttributeValueChange attributeValueChange;

    private FullChannelData channel;

    @Before
    public void setup() throws JMSException, BcbException {
        message = mock(ObjectMessage.class);

        IEM em = new EMItem();
        em.setIdName("EM_TEST");
        em.setActivation(EnableSwitch.ENABLED);
        em.setId(1);

        channel = new FullChannelData(em, new ChannelInfo(em.getId()).setGuiActualActivationState(
                GuiActualActivationState.ACTIVE).setUserText("text"));

        objectCreation = new FullChannelDataCreateNotification(channel);

        objectDeletion = new ObjectDeletion();
        objectDeletion.setDeletedObject(em);

        attributeValueChange = new AttributeValueChange();
        final IEM changedEm = new EMItem();
        changedEm.setId(1);
        changedEm.setActivation(EnableSwitch.DISABLED);
        final IEMMarkable markable = EMMarkableItem.of(changedEm);
        markable.setIdName("EM_TEST_MARKABLE");
        markable.markActivation(false);
        attributeValueChange.setChangedObject(markable);

        cache.fetch(new ArrayList<Element>());

        when(message.getStringProperty(NotificationTopicConfiguration.SENDER_ID.getName())).thenReturn(DCN_MANAGER.name());
    }

    @After
    public void release() throws CacheException {
        cache.clear();
    }

    @Test
    public void testCreateObject() throws JMSException, CacheException {
        when(message.getObject()).thenReturn(objectCreation);

        assertTrue(cache.all().isEmpty());

        manager.eventPluginTopicMessage(message);

        verifyObject();
    }

    @Test
    public void testDeleteObject() throws JMSException, CacheException {
        when(message.getObject()).thenReturn(objectDeletion);

        assertTrue(cache.all().isEmpty());

        cache.put(channel.getInfo().getChannelId(), channel);

        verifyObject();

        manager.eventPluginTopicMessage(message);

        assertTrue(cache.all().isEmpty());
    }

    @Test
    public void testAvcObject() throws JMSException, CacheException {
        when(message.getObject()).thenReturn(attributeValueChange);

        assertTrue(cache.all().isEmpty());

        cache.put(channel.getInfo().getChannelId(), channel);

        verifyObject();

        manager.eventPluginTopicMessage(message);

        assertThat("EM_TEST_MARKABLE", is(cache.find(channel.getChannel().getId()).get().getChannel().getIdName()));
        assertThat(EnableSwitch.ENABLED, is(cache.find(channel.getChannel().getId()).get().getChannel().getActivation()));
    }

    private void verifyObject() throws CacheException {
        assertThat(channel.getChannel().getId(), is(cache.find(channel.getChannel().getId()).get().getChannel().getId()));
        assertThat(channel.getChannel().getIdName(), is(cache.find(channel.getChannel().getId()).get().getChannel().getIdName()));

        assertThat(cache.all().size(), is(1));
    }
}
