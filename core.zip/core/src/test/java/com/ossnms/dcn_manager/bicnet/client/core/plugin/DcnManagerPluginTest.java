package com.ossnms.dcn_manager.bicnet.client.core.plugin;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.licensing.LicenseStatus;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPage;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.framework.client.listeners.FrameworkAbstractLogonListener;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.core.notification.NotificationManager;
import com.ossnms.dcn_manager.bicnet.client.service.facade.CommonServices;
import com.ossnms.dcn_manager.bicnet.client.settings.global.view.GlobalSettingsPageView;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ChannelService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.NeService;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.swing.ImageIcon;
import java.util.Collections;
import java.util.Optional;

import static java.util.Collections.singletonList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DcnManagerPluginTest extends TestsHelper {
    
    private DcnManagerPlugin plugin;

    @Mock private BiCNetPluginSite pluginSite;
    @Mock private IPluginSecurityProvider securityProvider;
    @Mock private IEMObjectMgrFacade publicFacade;
    @Mock private NeService neService;
    @Mock private ChannelService channelService;
    @Mock private NotificationManager notification;

    @Mock private CommonServices commonServices;
    @Mock private ImageIcon icon;

    @Before
    public void setup() throws BiCNetPluginException, BcbException {
        when(commonServices.getIconManager()).thenReturn(iconManager);
        when(commonServices.getBicnetServerFacade()).thenReturn(bicnetServerFacade);

        when(bicnetServerFacade.getDcnPublicServices()).thenReturn(publicFacade);
        when(bicnetServerFacade.getChannelService()).thenReturn(channelService);
        when(bicnetServerFacade.getNeService()).thenReturn(neService);
        when(bicnetServerFacade.getNeService()).thenReturn(neService);

        plugin = new DcnManagerPlugin(repositoryManager, commonServices, notification);
        
        DcnPluginHelperSingleton.getInstance().setCfPluginSite(null);
        
        when(pluginSite.getSecurityProvider()).thenReturn(securityProvider);
        when(commonServices.getDcnPluginHelper()).thenReturn(DcnPluginHelperSingleton.getInstance());
    }

    @Test
    public void testSetSite() {
        plugin.setSite(pluginSite);

        assertNotNull(DcnPluginHelperSingleton.getInstance().getCfPluginSite());
        assertNotNull(plugin.getPluginSite());
        assertNotNull(plugin.getLogonListener());
    }

    @Test
    public void testInit() throws BiCNetPluginException {
        plugin.setSite(pluginSite);
        plugin.init();

        verify(securityProvider, atLeastOnce()).addLogonListener(any(FrameworkAbstractLogonListener.class));
    }

    @Test
    public void testContainerIcon() throws BiCNetPluginException {
        final GenericContainerIdItem genericContainerIdItem = new GenericContainerIdItem(1);
        when(iconManager.findNetworkIcon(any(IGenericContainerId.class))).thenReturn(Optional.of(icon));

        plugin.getGenericContainerIcon(genericContainerIdItem);

        verify(iconManager, atLeastOnce()).findNetworkIcon(genericContainerIdItem);
    }

    @Test
    public void testSystemIcon() throws BiCNetPluginException {
        final SystemContainerIdItem systemContainerIdItem = new SystemContainerIdItem(1);
        when(iconManager.findNetworkIcon(any(ISystemContainerId.class))).thenReturn(Optional.of(icon));
        plugin.getSystemContainerIcon(systemContainerIdItem);

        verify(iconManager, atLeastOnce()).findNetworkIcon(systemContainerIdItem);
    }

    @Test
    public void testDestroy() throws BiCNetPluginException {
        plugin.setSite(pluginSite);
        plugin.destroy();

        verify(securityProvider, atLeastOnce()).removeLogonListener(any(FrameworkAbstractLogonListener.class));
    }
    
    @Test
    public void testGetMainPropertyPages() {
        final BiCNetPluginPropertyPage[] pages = plugin.getMainPropertyPages(BiCNetPluginMainContext.ADMINISTRATION);
        
        assertNotNull(pages);
        assertTrue(ImmutableList.copyOf(pages).stream().filter(GlobalSettingsPageView.class::isInstance).findFirst().isPresent());
    }
    
    @Test
    public void testGetMainPropertyPages_notSupporteContext() {
        final BiCNetPluginPropertyPage[] pages = plugin.getMainPropertyPages(BiCNetPluginMainContext.CONFIGURATION);
        
        assertNull(pages);
    }
    
    @Test
    public void testLicence() {
        assertThat(plugin.getLicenseStatus(), CoreMatchers.is(LicenseStatus.AVAILABLE));
    }
    
    @Test(expected=SecurityException.class)
    public void testDestroyError() throws BiCNetPluginException {
        doThrow(new BiCNetPluginException()).when(pluginSite).getSecurityProvider();
        
        plugin.setSite(pluginSite);
        plugin.destroy();
        
        verify(securityProvider, never()).removeLogonListener(any(FrameworkAbstractLogonListener.class));
    }

    @Test
    public void testGetId() {
        final String id = plugin.getID();

        assertThat(id, is(DcnManagerPlugin.class.getName()));
    }

    @Test
    public void getNEsByContainerId() throws Exception {
        final IGenericContainer container = buildContainer(1, 0);
        final FullNeData fullNeData = buildFullNeData(2, 1, "");

        when(neContainerAssignmentRepository.getNeIdList(container.getId())).thenReturn(Collections.singletonList(2));
        when(systemContainerAssignmentRepository.getSystemIdList(container.getId())).thenReturn(Collections.emptyList());
        when(neRepository.get(singletonList(fullNeData.getNe().getId()))).thenReturn(singletonList(fullNeData));

        final INE[] neList = plugin.getNeList(container.getGenericContainerId());

        assertThat(neList, notNullValue());
        assertThat(neList.length, is(1));
        assertThat(neList[0], is(fullNeData.getNe()));
    }
}
