package com.ossnms.dcn_manager.identification.ne;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.PropertyBag;
import com.ossnms.dcn_manager.core.test.MockFactory;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class GlobalNeIdV4Test {

    private final GlobalNeIdV4 gid = new GlobalNeIdV4();

    private NeType type;
    private PropertyBag bag;

    @Before
    public void setUp() {
        type = MockFactory.mockNeType();
        bag = mock(PropertyBag.class);
    }

    @Test(expected=IllegalArgumentException.class)
    public void unknownProtocolWithBag_throws() {
        when(type.getProtocol()).thenReturn("blah");

        gid.generate(type, bag);
    }

    @Test(expected=IllegalArgumentException.class)
    public void unknownProtocolWithMap_throws() {
        when(type.getProtocol()).thenReturn("blah");

        gid.generate(type, Collections.emptyMap());
    }

    @Test
    public void generateId() {
        when(type.getProtocol()).thenReturn("TL1");

        final Optional<String> id = gid.generate(type, ImmutableMap.of("TL1_NE_TARGET_ID", "TL1_ID_NAME_1"));

        assertThat(id, is(present()));
        assertThat(id.get(), is("bVRMMV9JRF9OQU1FXzEgICAgICAgICAE"));
    }

    @Test
    public void noId_returnsAbsent() {
        when(type.getProtocol()).thenReturn("TL1");

        final Optional<String> id = gid.generate(type, ImmutableMap.of("TL1_NE_TARGET_ID", ""));

        assertThat(id, is(absent()));
    }
}
