package com.ossnms.dcn_manager.identification.ne;

import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import java.util.Optional;

public interface NeIdentification {

    /**
     * Attempts to identify an existing NE based on information that can be extracted
     * from a NE Create Descriptor. Usually this is the same information that is exposed
     * as properties.
     *
     * @param createDescriptor NE creation descriptor that contains all information available
     *  about a new NE.
     * @return An instance of the existing NE, if present.
     * @throws RepositoryException When an error occurs while dealing with the underlying repository.
     */
    Optional<NeEntity> tryIdentifyNe(NeCreateDescriptor createDescriptor)
            throws RepositoryException;

    /**
     * @return The repository instance in use by this object.
     */
    NeEntityRepository getRepository();

}