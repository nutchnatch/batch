package com.ossnms.dcn_manager.identification.ne.globalneid;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.Map;

import static com.google.common.base.Strings.isNullOrEmpty;

/**
 * Generates GlobalNeId to protocols which must be unique: NSAP address and T-Selector.
 */
abstract class NsapGenerator extends GlobalNeIdGenerator {

    private static final Logger LOGGER = LoggerFactory.getLogger(NsapGenerator.class);

    private static final int INDEX = 20;
    private static final int _256 = 256;
    private static final int _0xFF = 0xFF;
    private static final int SEL_SHIFT = 8;
    private static final int QST_NSAP = 9;
    private static final int QD2_QST_SYNEC = 7;
    private static final int Q3_TSE = 8;
    private static final int BASE_SHIFT = 32;
    private static final int MAX_NSAP_LENGHT = 20;

    private static final int PROTOCOL_NOT_DEFINED = 0;
    private static final int QD2 = 1;
    private static final int QST = 2;
    private static final int Q3 = 3;
    private static final int QST2 = 2;

    protected abstract String getAddress(Map<String, String> properties);

    protected abstract String getTsel(Map<String, String> properties);

    /**
     * Generates GlobalNeId for Q3 and QST2 protocols.
     *
     * @param neType
     * @param properties
     * @return
     */
    @Override
    protected String generateGlobalNeId(String protocol, String neType, Map<String, String> properties) {

        LOGGER.debug("generateGlobalNeId::{}::Entry", protocol);

        String globalNeId = null;

        try {
            final String address = getAddress(properties);
            if (isNullOrEmpty(address)) {
                LOGGER.error("generateGlobalNeId::address == null");
                return null;
            }

            final String tsel = getTsel(properties);
            if (isNullOrEmpty(tsel)) {
                LOGGER.error("generateGlobalNeId::tsel == null");
                return null;
            }

            globalNeId = createGlobalNeIdBased64ForNSAP(address, tsel, protocol);

        } catch (final Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        LOGGER.debug("generateGlobalNeId::{}::Exit", protocol);

        return globalNeId;
    }

    /**
     * Creates As Base64 For QB3M Algorithm equal to the QB3NecClassInfoObject.cpp used by the NEC.
     *
     * @param address
     * @param tsel
     * @param protocol
     * @return
     * @throws IllegalArgumentException
     */
    private String createGlobalNeIdBased64ForNSAP(String address, String tsel, String protocol) {

        LOGGER.debug("generateGlobalNeId: before conversion nsap={} TSel={} protocol={}", address, tsel, protocol);

        final String addressRFC1277 = convertIPtoRFC1277(address);

        final byte[] bysNSAP = AddressUtil.convertHexStringToByteArray(addressRFC1277);

        if (bysNSAP.length > MAX_NSAP_LENGHT) {
            final String errorMessage = "NSAP must not be longer than 20 bytes";
            LOGGER.error(errorMessage);
            throw new IllegalArgumentException(errorMessage);
        }

        final Base64 encoder = new Base64();
        final byte[] rawData = new byte[MAX_RANGE_DEFAULT];

        Arrays.fill(rawData, (byte) INIT_WITH_SPACE_CHAR);

        rawData[0] = (byte) (bysNSAP.length | BASE_SHIFT);
        System.arraycopy(bysNSAP, 0, rawData, 1, bysNSAP.length);

        int sel = selectProtocol(tsel, protocol);

        if (sel == PROTOCOL_NOT_DEFINED) {
            int iC = 0;

            while(iC < tsel.length() && !Character.isDigit(tsel.charAt(iC))) {
                ++iC;
            }

            if (iC < tsel.length()) {
                try {
                    sel = Integer.parseInt(tsel.substring(iC));
                } catch (final Exception ex) {
                    throw new IllegalArgumentException("Invalid T-selector: ", ex);
                }
            }

            if (sel > PROTOCOL_NOT_DEFINED) {
                sel += _256;
            }
        }

        int index = INDEX;

        rawData[++index] = (byte) (sel & _0xFF);
        rawData[++index] = (byte) (sel >> SEL_SHIFT);
        rawData[++index] = (byte) convertProtocolToInt(protocol);

        return new String(encoder.encode(rawData));
    }

    private int selectProtocol(String tsel, String protocol) {

        if (protocol.toUpperCase().contains("Q3") && "tse".equals(tsel)) {
            return Q3_TSE;
        }

        if ((protocol.toUpperCase().contains("QD2") || protocol.toUpperCase().contains("QST")) && "SYNEC-OS".equals(tsel)) {
            return QD2_QST_SYNEC;
        }

        if ("QST".equals(tsel)) {
            return QST_NSAP;
        }

        return PROTOCOL_NOT_DEFINED;
    }

    /**
     * Converts protocol to int
     *
     * @param protocol
     * @return int
     */
    protected final int convertProtocolToInt(String protocol) {
        if (protocol.toUpperCase().contains("QD2")) {
            return QD2;
        }

        if (protocol.toUpperCase().contains("QST")) {
            return QST;
        }

        if (protocol.toUpperCase().contains("Q3")) {
            return Q3;
        }

        if (protocol.toUpperCase().contains("QST2")) {
            return QST2;
        }

        return PROTOCOL_NOT_DEFINED;
    }

    /**
     * Converts a IP Address to a RFC1277 NSAP. If it is no full IP Address it will returned unchanged.
     *
     * @param nsap NSAP
     * @return NSAP or IP
     */
    protected final String convertIPtoRFC1277(final String nsap) {
        String nsapLocal = nsap;
        if (AddressUtil.isValidIPandPort(nsapLocal, false)) {
            try {
                final AddressUtil addr = new AddressUtil(nsapLocal);
                nsapLocal = AddressUtil.convertByteArrayToHexString(addr.getNSAP());
            } catch (final MalformedURLException exMalformedURL) {
                LOGGER.error("convertIPtoRFC1277: exception " + exMalformedURL);
            }
        }

        return nsapLocal;
    }
}
