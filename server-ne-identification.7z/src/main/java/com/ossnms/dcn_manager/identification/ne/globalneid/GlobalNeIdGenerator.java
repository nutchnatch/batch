package com.ossnms.dcn_manager.identification.ne.globalneid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.util.Map;

abstract class GlobalNeIdGenerator {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalNeIdGenerator.class);

    protected static final int MAX_RANGE_DEFAULT = 24;
    protected static final int INIT_WITH_SPACE_CHAR = 32;
    protected static final int ENDOFLINE = 4;

    /**
     * Generates Global NE id for each different protocol.
     *
     * @param protocol
     * @param neType
     * @param properties
     * @return
     */
    protected abstract String generateGlobalNeId(String protocol, String neType, Map<String, String> properties);

    /**
     * Converts String to byte array
     *
     * @param str String to be converted
     * @return byte array converted from String or null in case of error
     */
    protected final byte[] convertStringToByteArray(final String str) {
        byte[] arrayResult = null;

        try {
            arrayResult = str.getBytes("ASCII");
        } catch (final UnsupportedEncodingException e) {
            LOGGER.warn("convertStringToByteArray: ", e);
        }

        return arrayResult;
    }

}
