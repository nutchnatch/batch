package com.ossnms.dcn_manager.identification.ne.globalneid;

import javax.annotation.Nonnull;
import java.util.Map;

/**
 * Generates GlobalNeId for each supported protocols.
 */
public enum GlobalNeId {

    SNMP(new IpPortGenerator() {

            @Override
            protected String getAddress(Map<String, String> properties) {
                return properties.get("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP");
            }

            @Override
            protected String getPort(Map<String, String> properties) {
                return properties.get("snmpPort");
            }

        }),

    RMT(new IpPortGenerator() {

            @Override
            protected String getAddress(Map<String, String> properties) {
                return properties.get("com.ossnms.mvm.hit7090.ip");
            }

            @Override
            protected String getPort(Map<String, String> properties) {
                return properties.get("com.ossnms.mvm.hit7090.port");
            }

        }),

    NETCONF(new IpPortGenerator() {

        @Override
        protected String getAddress(Map<String, String> properties) {
            return properties.get("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP");
        }

        @Override
        protected String getPort(Map<String, String> properties) {
            return properties.get("com.coriant.bicnet.mvm.providers.coriantos.connection.port");
        }

    }),

    Q3(new NsapGenerator() {

            @Override
            protected String getAddress(Map<String, String> properties) {
                return properties.get("369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP");
            }

            @Override
            protected String getTsel(Map<String, String> properties) {
                return properties.get("369AB9C2-B597-49BA-9190-7D1CEA0C924F/TSEL");
            }

        }),

    QST2(new NsapGenerator() {

            @Override
            protected String getAddress(Map<String, String> properties) {
                return properties.get("E02A2D18-CAF9-48FB-8B1E-E2F5D16BEF87/NSAP");
            }

            @Override
            protected String getTsel(Map<String, String> properties) {
                return properties.get("E02A2D18-CAF9-48FB-8B1E-E2F5D16BEF87/TSEL");
            }

        }),

    TL1(new TargetIdGenerator());

    private final GlobalNeIdGenerator generator;

    private GlobalNeId(@Nonnull GlobalNeIdGenerator generator) {
        this.generator = generator;
    }

    /**
     * Generates globalNeId for all supported protocols.
     *
     * @param neType
     * @param properties
     * @return
     */
    public String generateGlobalNeId(String neType, Map<String, String> properties) {
        return generator.generateGlobalNeId(name(), neType, properties);
    }

}
