package com.ossnms.dcn_manager.identification.ne;

import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.PropertyBag;
import com.ossnms.dcn_manager.identification.ne.globalneid.GlobalNeId;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;

public class GlobalNeIdV4 {

    /**
     * Given a set of NE information, generate its globally unique identifier.
     *
     * @param type NE type metadata.
     * @param properties NE entity properties.
     * @return A new identifier. May be absent if it could not be generated for some reason,
     *  such as insufficient information in the property bag.
     * @throws IllegalArgumentException If the NE protocol is unknown.
     */
    public Optional<String> generate(@Nonnull NeType type, @Nonnull PropertyBag properties) {
        return generate(type, properties.getAllOpaqueProperties());
    }

    /**
     * Given a set of NE information, generate its globally unique identifier.
     *
     * @param type NE type metadata.
     * @param properties Opaque NE property map.
     * @return A new identifier. May be absent if it could not be generated for some reason,
     *  such as insufficient information in the property bag.
     * @throws IllegalArgumentException If the NE protocol is unknown.
     */
    public Optional<String> generate(@Nonnull NeType type, @Nonnull Map<String, String> properties) {
        final String protocol = type.getProtocol();
        final GlobalNeId globalNeId = GlobalNeId.valueOf(protocol);
        final String identifier = globalNeId.generateGlobalNeId(type.getName(), properties);
        return Optional.ofNullable(identifier);
    }

}
