package com.bpc.sesame.saf.services;

/**
 * Convenient Services which can be implemented with different behavior for each environment.
 * For now only 2 implementations : 'mock' and 'not mock'
 * @author 483838
 */
public interface EnvironmentServices {

	/**
	 * Get the Sesame Base URL without the context ex : http://localhost:8080
	 * @return
	 */
	public String getSesameBaseURL();
	
	/**
	 * Setting the Sesame Base URL without the context ex : http://localhost:8080
	 * @param sesameBaseURL
	 */
	public void setSesameBaseURL(String sesameBaseURL);
}
