package com.bpc.sesame.saf.services;

import java.io.Serializable;
import java.security.cert.X509Certificate;

import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel;
import com.bpc.sesame.saf.exception.RequesterException;
import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.util.AuditFilter;
import com.bpc.sesame.saf.util.CryptographicTools;

/**
 * This Authenticator is simplified version which manage only HIGH authentication level.
 * @author 483838
 */
@Service
public class AuthenticatorServices {
	
	private static final Logger log = LoggerFactory.getLogger(AuthenticatorServices.class);
	
	@Autowired
	private SesameServices sesameServices;
	
	@Value("${sesame.saf.certificates.must-have-client-auth-role}")
	private boolean certificateMustHaveClientAuthRole;
	
	/**
	 * Authenticate a user-agent with its certificate, looks for a smart-card certificate.<br>
	 * <br>
	 * Important, failed authentication are managed by unchecked exception, please read
	 * Exception Strategy in developers guide.
	 * 
	 * @param request 
	 * @param SAFAuthLevelRequired is useless in this implementation (always HIGH)
	 * @return never Null
	 */
	public AuthenticatedUser authenticate(HttpServletRequest request, SAFAuthLevel SAFAuthLevelRequired) {

		//watch for a certificate
		String login = checkCertificateAndExtractLogin(request, SAFAuthLevel.HIGH);
		if (login==null || login.equals("")) {
			throw new RequesterException("An illegal certificate was provided, impossible to extract login.");
		}
		
		String sesameToken = sesameServices.getTokenFromLogin(login);
		if (sesameToken==null || sesameToken.equals("")) {
			throw new TechnicalException("An illegal empty sesame token was provided.");
		}
		
		return new AuthenticatedUser(login, sesameToken);
	}
	
	/**
	 * Authenticate SOAP request with its certificate, looks for a smart-card certificate.<br>
	 * <br>
	 * Important, failed authentication are managed by unchecked exception, please read
	 * Exception Strategy in developers guide.
	 * 
	 * @param context
	 * @param SAFAuthLevelRequired is useless in this implementation (always HIGH)
	 * @return never Null
	 */
	public AuthenticatedUser authenticateForSoap(WebServiceContext context, SAFAuthLevel SAFAuthLevelRequired) {
		
		//First watch for a certificate
		HttpServletRequest request = (HttpServletRequest) context.getMessageContext().get(MessageContext.SERVLET_REQUEST);
		return authenticate(request, SAFAuthLevelRequired);
	}
	
	/**
	 * Check if the request contains a certificate.<br>
	 * Check if this certificate SAFAuthLevel is stronger or equal to the Required SAFAuthLevel.<br>
	 * Then, extract the uid from the Certificate.
	 * @param request
	 * @param SAFAuthLevelRequired
	 * @return the uid from the certificate or null if the certificate SAFAuthLevel is too weak.
	 */
	private String checkCertificateAndExtractLogin(HttpServletRequest request, SAFAuthLevel SAFAuthLevelRequired) {
		
		if (!request.isSecure()) {
			throw new RequesterException("Failed to log user : request isn't secure.");
		}

		X509Certificate[] certificates = (X509Certificate[]) request.getAttribute("javax.servlet.request.X509Certificate"); 
		if (certificates==null||certificates.length==0) {
			throw new RequesterException("Failed to log user : no certificate found.");
		}
		
		X509Certificate certificate = certificates[0];
		
		SAFAuthLevel SAFAuthLevelExtracted = CryptographicTools.extractSAFAuthLevelFromCertificate(certificate, certificateMustHaveClientAuthRole);
		
		//If the SAFAuthLevel Required is Stronger than the one extracted
		if (SAFAuthLevelRequired.stronger(SAFAuthLevelExtracted)) {
			throw new RequesterException("Failed to log user : certificate too weak.");
		}
		
		//certificate is OK with good SAFAuthLevel, we can extract the uid from DNSName
		String login = CryptographicTools.extractDNSNameFromCertificate(certificate);
		MDC.put(AuditFilter.USER_LOGIN, login);
		log.info("Successfully log user : " + login );
		return login;
	}
	
	/**
	 * Object created when the user is authenticated
	 * This object is Immutable.
	 */
	public final class AuthenticatedUser implements Serializable {
		
		private static final long serialVersionUID = 1L;
		
		private final String login;
		private final String sesameToken;
		
		public AuthenticatedUser(String login) {
			this.login = login;
			this.sesameToken = null;
		}
		public AuthenticatedUser(String login, String sesameToken) {
			this.login = login;
			this.sesameToken = sesameToken;
		}
		public String getSesameToken() {
			return sesameToken;
		}
		public String getLogin() {
			return login;
		}
	}
}
