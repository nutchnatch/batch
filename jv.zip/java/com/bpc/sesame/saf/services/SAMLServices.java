package com.bpc.sesame.saf.services;

import gentypes.saml.assertion.v20.AssertionType;
import gentypes.saml.assertion.v20.AttributeStatementType;
import gentypes.saml.assertion.v20.AttributeType;
import gentypes.saml.assertion.v20.AudienceRestrictionType;
import gentypes.saml.assertion.v20.AuthnContextType;
import gentypes.saml.assertion.v20.AuthnStatementType;
import gentypes.saml.assertion.v20.ConditionsType;
import gentypes.saml.assertion.v20.NameIDType;
import gentypes.saml.assertion.v20.SubjectConfirmationDataType;
import gentypes.saml.assertion.v20.SubjectConfirmationType;
import gentypes.saml.assertion.v20.SubjectType;
import gentypes.saml.metadata.v20.AttributeConsumingServiceType;
import gentypes.saml.protocol.v20.AuthnRequestType;
import gentypes.saml.protocol.v20.ResponseType;
import gentypes.saml.protocol.v20.StatusCodeType;
import gentypes.saml.protocol.v20.StatusType;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.PublicKey;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

import com.bpc.sesame.saf.exception.RequesterException;
import com.bpc.sesame.saf.model.CertificatePK;
import com.bpc.sesame.saf.model.ResponseStatus;
import com.bpc.sesame.saf.model.ServiceProviderLocal;
import com.bpc.sesame.saf.services.AuthenticatorServices.AuthenticatedUser;
import com.bpc.sesame.saf.statistics.Profiled;
import com.bpc.sesame.saf.util.XmlDigitalEncrypter;
import com.bpc.sesame.saf.util.XmlDigitalSigner;
import com.bpc.sesame.saf.util.XmlTools;

/**
 * Main Business Service to manage SAML operation 
 * @author 483838
 */
@Service
public class SAMLServices {
	
	private static final Logger logger = LoggerFactory.getLogger(SAMLServices.class);
	
	@Autowired
	private AttributesServices attributesServices;
	
	@Autowired
	private ServiceProvidersServicesLocal metadataServicesLocal;
	
	@Value("${sesame.saf.identity-provider.id}")
	private String entityIdIDP;
	
	@Value("${sesame.saf.service-providers.request.max-age.seconds}")
	private int requestMaxAge; 
	
	@Value("${sesame.saf.identity-provider.time.condition.not-before.seconds}")
	private int notBeforeSeconds;
	
	@Value("${sesame.saf.identity-provider.time.condition.not-after.seconds}")
	private int notAfterSeconds;
	
	@Value("${sesame.saf.identity-provider.encryption.symmetric.algorithm}")
	private String encryptionSymmetricAlgo;
	
	@Value("${sesame.saf.identity-provider.encryption.asymmetric.algorithm}")
	private String encryptionAsymmetricAlgo;
	
	@Value("${sesame.saf.identity-provider.encryption.digest.method}")
	private String digestMethod;
	
	@Value("${sesame.saf.identity-provider.signature.algorithm}")
	private String signatureAlgo;
	
	/**
	 * Create a successful saml response in DOM for the given user and the given request.
	 * This response will not be signed.
	 * @param user
	 * @param authnRequest
	 * @return
	 */
	public Document createSuccessfulSamlResponse(AuthenticatedUser user, AuthnRequestType authnRequest)  {
		
		//parameters
		String requestId = authnRequest.getID();
		String acsURL = authnRequest.getAssertionConsumerServiceURL();
		XMLGregorianCalendar now = XmlTools.createXmlGregorianCalendar(0);
		XMLGregorianCalendar notBefore = XmlTools.createXmlGregorianCalendar(notBeforeSeconds);
		XMLGregorianCalendar notAfter = XmlTools.createXmlGregorianCalendar(notAfterSeconds);
		String destination = authnRequest.getAssertionConsumerServiceURL();
		String responseId = XmlTools.createID();
		String assertionId = XmlTools.createID();
		String serviceProviderId = authnRequest.getIssuer().getValue();
		String identityProviderId = entityIdIDP;
        
		//Response
		ResponseType response = new ResponseType();
		response.setDestination(destination);
		response.setInResponseTo(requestId);
		response.setID(responseId);
        response.setIssueInstant(now);
		response.setVersion("2.0");
		
		//Status
		StatusType status = new StatusType();
		response.setStatus(status);
		StatusCodeType statusCode = new StatusCodeType();
		status.setStatusCode(statusCode);
		statusCode.setValue(ResponseStatus.SUCCESS.getUri());
		
		//Assertion
		AssertionType assertion = new AssertionType();
		response.getAssertionOrEncryptedAssertion().add(assertion);
		assertion.setID(assertionId);
		assertion.setIssueInstant(now);
		assertion.setVersion("2.0");
		
		//Assertion//Issuer
		NameIDType issuer = new NameIDType();
		assertion.setIssuer(issuer);
		issuer.setValue(identityProviderId);
		response.setIssuer(issuer);
		
		//Assertion//Subject
		SubjectType subject = new SubjectType();
		assertion.setSubject(subject);
		NameIDType subjectId = new NameIDType();
		subject.getContent().add(new gentypes.saml.assertion.v20.ObjectFactory().createNameID(subjectId));
		subjectId.setFormat("urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified");
		subjectId.setValue(user.getLogin());
		SubjectConfirmationType subjectConfirmation = new SubjectConfirmationType();
		subject.getContent().add(new gentypes.saml.assertion.v20.ObjectFactory().createSubjectConfirmation(subjectConfirmation));
		subjectConfirmation.setMethod("urn:oasis:names:tc:SAML:2.0:cm:bearer");
		SubjectConfirmationDataType subjectConfirmationData = new SubjectConfirmationDataType();
		subjectConfirmation.setSubjectConfirmationData(subjectConfirmationData);
		subjectConfirmationData.setInResponseTo(requestId);
		subjectConfirmationData.setNotOnOrAfter(notAfter);
		subjectConfirmationData.setRecipient(acsURL);
		
		//Assertion//Conditions
		ConditionsType conditions = new ConditionsType();
		assertion.setConditions(conditions);
		conditions.setNotBefore(notBefore);
		conditions.setNotOnOrAfter(notAfter);
		AudienceRestrictionType audienceRestriction = new AudienceRestrictionType();
		conditions.getConditionOrAudienceRestrictionOrOneTimeUse().add(audienceRestriction);
		audienceRestriction.getAudience().add(serviceProviderId);
		
		//Assertion//AuthnStatement
		AuthnStatementType authnStatement = new AuthnStatementType();
		assertion.getStatementOrAuthnStatementOrAuthzDecisionStatement().add(authnStatement);
		authnStatement.setAuthnInstant(now);
		AuthnContextType authnContext = new AuthnContextType();
		authnStatement.setAuthnContext(authnContext);
		
		authnContext.getContent().add(new gentypes.saml.assertion.v20.ObjectFactory().createAuthnContextClassRef("urn:bnpparibas:cardif:saml:sesame:auth-type:1.0:group"));
		
		//Attributes Manager
		Set<AttributeType> attributes = attributesServices.retrieveAttributes(authnRequest, user);
		
		//AttributeStatement
		if (attributes!=null && attributes.size()>0) {
			AttributeStatementType attributeStatement = new AttributeStatementType();
			assertion.getStatementOrAuthnStatementOrAuthzDecisionStatement().add(attributeStatement);
			attributeStatement.getAttributeOrEncryptedAttribute().addAll(attributes);
		}

		return XmlTools.responseTypeToDom(response);
	}

	/**
	 * Search for an human readable name for the service provider of this request.
	 * TODO implement label from safadmin
	 * @param authnRequest
	 * @return
	 */
	public String computeApplicationName(AuthnRequestType authnRequest) {
		if (authnRequest.getProviderName()!=null&&authnRequest.getProviderName().length()>0) {
			return authnRequest.getProviderName();
		}
		if (authnRequest.getAttributeConsumingServiceIndex()==null) {
			return null;
		}
		
		ServiceProviderLocal spMetadata = null;
		try {
			spMetadata = metadataServicesLocal.getServiceProviderWithCache(authnRequest.getIssuer().getValue());
		} catch (Exception e) {
			return null;
		}
		for (AttributeConsumingServiceType attributes: spMetadata.getDescription().getAttributeConsumingService()) {
			if (attributes.getIndex() == authnRequest.getAttributeConsumingServiceIndex()) {
				if (attributes.getServiceName().size()>0) {
					return attributes.getServiceName().get(0).getValue();
				} else {
					return null;
				}
			}
		}
		
		return null;
	}
	
	/**
	 * SAML validation of the request.(issueInstant and known issuer)
	 * @param authnRequest
	 */
	public void validateAuthnRequest(AuthnRequestType authnRequest) {
		
		//Validate the issueInstant 
		if (authnRequest.getIssueInstant()==null) {
			throw new RequesterException("The request must have an IssueInstant.");
		}
		Calendar requestTime  = authnRequest.getIssueInstant().toGregorianCalendar();
		Calendar oldestTime = Calendar.getInstance();
		oldestTime.add(Calendar.SECOND, - requestMaxAge);
		if (requestTime.before(oldestTime)) {
			logger.error("The request have expired : \n" +
						"Request Time (IssueInstant) : " + new SimpleDateFormat("yyyy.MM.dd 'at' HH:mm:ss",Locale.FRENCH).format(requestTime.getTime()) + "\n" +
						"Max Time Allowed for this request : " + new SimpleDateFormat("yyyy.MM.dd 'at' HH:mm:ss",Locale.FRENCH).format(oldestTime.getTime()));
			throw new RequesterException("The request have expired.");
		}
		Calendar mostRecentTime = Calendar.getInstance();
		mostRecentTime.add(Calendar.SECOND, + requestMaxAge);
		if (requestTime.after(mostRecentTime)) {
			logger.error("The request is too recent : \n" +
						"Request Time (IssueInstant) : " + new SimpleDateFormat("yyyy.MM.dd 'at' HH:mm:ss",Locale.FRENCH).format(requestTime.getTime()) + "\n" +
						"Max Time Allowed for this request : " + new SimpleDateFormat("yyyy.MM.dd 'at' HH:mm:ss",Locale.FRENCH).format(oldestTime.getTime()));
			throw new RequesterException("The request is too recent.");
		}
		
		//Validate the issuer
		if (authnRequest.getIssuer()==null) {
			throw new RequesterException("The request must have an issuer.");
		}
		metadataServicesLocal.checkRegistration(authnRequest.getIssuer().getValue());
			
	}
	
	/**
	 * Validate the signature of the an authnRequest in DOM document. (SOAP, POST Bindings)
	 * @param requestDocument
	 * @param publicKey
	 */
	@Profiled(name="compute-validateRequestSignature")
	public void validateAuthnRequestSignature(Document requestDocument, PublicKey publicKey) {
		if (!XmlDigitalSigner.getInstance().verifySignatureInDocument(requestDocument, publicKey)) {
			throw new RequesterException("Could not verify the signature of the request.");
		}
	}
	
	/**
	 * Validate the signature of the an authnRequest in Jaxb object. (Request Binding)
	 * @param authnRequest
	 * @param request
	 * @param publicKey
	 */
	@Profiled(name="compute-validateRequestSignatureForRedirect")
	public void validateAuthnRequestSignatureForRedirect(AuthnRequestType authnRequest, HttpServletRequest request, PublicKey publicKey) {
		//Validate the signature
		String sigAlg = request.getParameter("SigAlg");
		String signature = request.getParameter("Signature");
		if (sigAlg==null || sigAlg.length()==0 || signature==null || signature.length()==0) {
			throw new RequesterException("No signature found in this message.");
		}
		
		String relayState = request.getParameter("RelayState");
		String samlRequest = request.getParameter("SAMLRequest");
		
		String textWhichIsSigned = "";
		
		try {
			if (relayState == null || relayState.length() == 0) {
				textWhichIsSigned = "SAMLRequest=" + URLEncoder.encode(samlRequest, "UTF-8") + "&SigAlg=" + URLEncoder.encode(sigAlg, "UTF-8");
			} else {
				textWhichIsSigned = "SAMLRequest=" + URLEncoder.encode(samlRequest, "UTF-8") + "&RelayState="+URLEncoder.encode(relayState, "UTF-8")+"&SigAlg="+ URLEncoder.encode(sigAlg, "UTF-8");
			}
		} catch (UnsupportedEncodingException e) {
			throw new RequesterException("Error when trying to decode parameters of request :", e);
		}
		
		boolean valid = XmlDigitalSigner.getInstance(sigAlg).verifySignatureFromText(textWhichIsSigned, DatatypeConverter.parseBase64Binary(signature), publicKey);
		
		if (!valid) {
			throw new RequesterException("Could not verify the signature of the request.");
		}
	}
	
	/**
	 * Create a failed saml response in DOM for the given user and the given request.
	 * @param authnRequest
	 * @param reason
	 * @return
	 */
	public ResponseType createFailedSamlResponse(AuthnRequestType authnRequest, ResponseStatus reason) {
		//parameters
		String requestId = authnRequest!=null?authnRequest.getID():"";
		XMLGregorianCalendar now = XmlTools.createXmlGregorianCalendar(0);
		String destination = authnRequest!=null?authnRequest.getAssertionConsumerServiceURL():"";
		String responseId = XmlTools.createID();
        
		//Response
		ResponseType response = new ResponseType();
		response.setDestination(destination);
		response.setInResponseTo(requestId);
		response.setID(responseId);
        response.setIssueInstant(now);
		response.setVersion("2.0");
		
		//Status
		StatusType status = new StatusType();
		response.setStatus(status);
		StatusCodeType statusCode = new StatusCodeType();
		status.setStatusCode(statusCode);
		statusCode.setValue(reason.getUri());
		return response;
	}

	/**
	 * Sign an assertion in a DOM document which must be an AuthnRequest 
	 * @param response
	 * @param cert
	 */
	@Profiled(name="compute-signAssertion")
	public void signAssertionInDocument(Document response, CertificatePK cert) {
		XmlDigitalSigner.getInstance(signatureAlgo).signAssertionInDocument(response, cert);
	}
	
	/**
	 * Encrypt an assertion in a DOM document which must be an AuthnRequest 
	 * @param request
	 * @param response
	 * @param publicKey
	 */
	@Profiled(name="compute-encryptAssertion")
	public void encryptAssertion(AuthnRequestType request, Document response, PublicKey publicKey)  {
		XmlDigitalEncrypter.getInstance(encryptionSymmetricAlgo, encryptionAsymmetricAlgo, digestMethod).encryptAssertion(response, publicKey);
	}
}
