package com.bpc.sesame.saf.services;

import static java.nio.file.StandardCopyOption.ATOMIC_MOVE;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.annotation.PostConstruct;
import javax.naming.Context;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.bpc.sesame.saf.exception.ConfigurationException;
import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.statistics.Profiled;
import com.bpc.sesame.saf.util.CryptographicTools;

/**
 * SAF is able to download one or more CRLs from ldap/http/file locations.
 * SAF then construct a single CRL file on local hard drive. This local file
 * will contains all the remote CRLs in PEM format.<br>
 * These download can be scheduled. Please read the developer guide for more information.
 * @author 483838
 */
@Service
public class CRLServices {
	
	private static final Logger log = LoggerFactory.getLogger(CRLServices.class);
	
    @Autowired
    private ApplicationContext applicationContext;
    
    @Value("${sesame.saf.crl-download.enable}")
    private boolean crlDownloadEnable;
    
    @Value("${sesame.saf.crl-download.job.timeout}")
    private long jobTimeout;
    
    private String destination;
    private Path destinationFile;
    private Path destinationTempFile;
    
    private List<String> urls = new ArrayList<>();
    
	@PostConstruct
	public void init() {
		
		if (crlDownloadEnable) {
			
			destination = applicationContext.getEnvironment().getProperty("sesame.saf.crl-download.destination.file");
			destinationFile = Paths.get(destination);
			destinationTempFile = Paths.get(destination+".temp");
			
			//Must check if the crl file and crl temp file are writable.
			checkFileIsWritable(destinationFile);
			checkFileIsWritable(destinationTempFile);
			
			//init an check urls
			int i = 1;
			String pfx = "sesame.saf.crl-download.url"; 
			String url = null;
			while ((url = applicationContext.getEnvironment().getProperty(pfx + i++))!=null) {
				if (!url.startsWith("ldap://") &&  !url.startsWith("ldaps://")) {
					throw new ConfigurationException("SAF can refresh CRL only with ldap:// or ldaps:// urls.");
				}
				urls.add(url);
			}
			
			//Must check if the crl temp files are writable
			for (int urlIndex = 1; urlIndex <= urls.size(); urlIndex++) {
				Path destinationTempIndexedFile = Paths.get(destination + "." + urlIndex);
				checkFileIsWritable(destinationTempIndexedFile);
			}

		}
	}
	
	/**
	 * Entry point for the scheduler 
	 */
	@Scheduled(initialDelayString="${sesame.saf.crl-download.initialDelay}", fixedRateString="${sesame.saf.crl-download.fixedRate}")
	public void scheduleCRLsDownload() {
		
		if (!crlDownloadEnable) {
			return;
		}
		
		log.debug("scheduleCRLsDownload start");
		
		CRLServices self = applicationContext.getBean(CRLServices.class);
		
		Future<Void> future = null;
		try {
			future = self.downloadAllCRLs();
            future.get(jobTimeout, TimeUnit.MILLISECONDS);
            log.debug("scheduleCRLsDownload end");
		} catch (TimeoutException e) {
			//The child thread didn't finished we must cancel it.
			if (future!=null) {
				future.cancel(true);
			}
			throw new TechnicalException("Error while downloading the CRLs", e);
		} catch (InterruptedException e) {
			//The current thread is interrupted we must cancel the child also.
			if (future!=null && !future.isDone()) {
				future.cancel(true);
			}
			throw new TechnicalException("Error while downloading the CRLs", e);
		} catch (ExecutionException e) {
			//The child thread throw an exception
			throw new TechnicalException("Error while downloading the CRLs", e);
		} 
	}
	
	/**
	 * This method downloads ALL the crls asynchronously.
	 * @return
	 */
	@Async
	public Future<Void> downloadAllCRLs() {
		
		log.debug("downloadAllCRLs start");
		
		CRLServices self = applicationContext.getBean(CRLServices.class);
		
		for (int i = 0; i < urls.size(); i++) {
			try {
				self.downloadCRLToTempFile(urls.get(i), (i+1));
			} catch (Exception e) {
				log.error("Error while downloading CRL number " + (i+1), e);
			}
		}
		
		log.debug("All crl was downloaded to their temp file, now concat into one file.");
		
		try {
			Files.deleteIfExists(destinationTempFile);
		} catch (IOException e) {
			throw new TechnicalException("Impossible to delete the CRL temps file.", e);
		}
		
		for (int urlIndex = 1; urlIndex <= urls.size(); urlIndex++) {
			Path destinationTempIndexedFile = Paths.get(destination + "." + urlIndex);
			if (Files.exists(destinationTempIndexedFile)) {
				try {
					concatFile(destinationTempIndexedFile, destinationTempFile);
				} catch (IOException e) {
					throw new TechnicalException("Impossible to copy CRL file.", e);
				}
			}
		}
		
		
		
		try {
			Files.move(destinationTempFile, destinationFile, ATOMIC_MOVE, REPLACE_EXISTING);
		} catch (IOException e) {
			throw new TechnicalException("Impossible to move the temp CRL file to its final name.", e);
		}

		log.debug("downloadAllCRLs end");
		
		return new AsyncResult<Void>(null);
	}
	
	/**
	 * Download an CRL url  with a protocol in ldap/ldaps/http/https/file<br>
	 * <br>
	 * ldap/ldapsldap/http/https CRL must be binary CRL<br>
	 * CRL on the filesystem must be PEM formated<br>
	 * 
	 * @param url
	 */
	@Profiled(name = "out-crl-url#{args[1]}")
	public void downloadCRLToTempFile(String url, int urlIndex) {
		log.debug("downloadCRL {} start with {}", urlIndex, url );
		
		Path tempWithIndex = Paths.get(destinationFile + "." + urlIndex);
		
		if (url.startsWith("ldap://") || url.startsWith("ldaps://")) {
			byte[] crl = downloadCRLFromLDAP(url);
			simplecheckCRL(crl, url);
			CryptographicTools.crlBytesToPemFile(crl, tempWithIndex, false);
			
		} else if (url.startsWith("http://") || url.startsWith("https://")) {
			byte[] crl = downloadCRLFromHttp(url);
			simplecheckCRL(crl, url);
			CryptographicTools.crlBytesToPemFile(crl, tempWithIndex, false);
			
		} else {
			Path crlAsPEM = Paths.get(url);
			if (Files.notExists(crlAsPEM)) {
				throw new ConfigurationException("The CRL file doesn't exist on filesystem : " + url );
			}
			try {
				Files.deleteIfExists(tempWithIndex);
				concatFile(crlAsPEM, tempWithIndex);
			} catch (Exception e) {
				throw new TechnicalException("Cannot retrieve CRL from local filesystem.", e);
			}
		}
		
		log.debug("downloadCRL {} end", urlIndex);
	}
	
	private void simplecheckCRL(byte[] crl, String url) {
		if (crl ==null) {
			throw new TechnicalException("The downloaded crl is empty from " + url);
		}
		if (crl.length < 500) {
			log.error("The CRL length is under 500 bytes, it seems incorrect.");
			throw new TechnicalException("The downloaded crl is incorrect from " + url);
		}
	}

	private byte[] downloadCRLFromHttp(String url) {
		
		try (ByteArrayOutputStream baos = new ByteArrayOutputStream(); InputStream is = new URL(url).openStream();) {
			byte[] byteChunk = new byte[4096];
			int n;

			while ((n = is.read(byteChunk)) > 0) {
				baos.write(byteChunk, 0, n);
			}
			return baos.toByteArray();
		} catch (IOException e) {
			throw new TechnicalException("Impossible to download the CRL from " + url, e);
		}
	}

	public boolean isInitialized() {
		try {
			return Files.size(destinationFile)>0;
		} catch (IOException e) {
			throw new TechnicalException("Impossible to get the size of the CRLs file.", e);
		}
	}
	
	public List<String> getUrls() {
		return urls;
	}

	public void setUrls(List<String> urls) {
		this.urls = urls;
	}
	
	private byte[] downloadCRLFromLDAP(String ldapURL)  {
		Map<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, ldapURL);

		//Download to the temp path
		DirContext ctx = null;
		try {
			ctx = new InitialDirContext((Hashtable<?,?>) env);
			Attributes avals = ctx.getAttributes("");
			Attribute aval = avals.get("certificateRevocationList;binary");
			byte[] val = (byte[]) aval.get();
			if ((val == null) || (val.length == 0)) {
				throw new TechnicalException("Empty CRL from : " + ldapURL);
			} 
			return val;
		} catch (Exception e) {
			throw new TechnicalException("Impossible to download CRL from ldap : " + ldapURL, e);
		} finally {
			if (ctx!=null) {
				try {
					ctx.close();
				} catch (Exception e) {
					log.warn("Impossible to close the javax.naming.directory.DirContext object.", e);
				}
			}
		}
	}
	
	private void checkFileIsWritable(Path path) {
		//Due to a bug we make a direct test if the files doesn't exists
		if (Files.exists(path)) {
			if (!Files.isWritable(path)) {
				log.error("No write access for " + path.toAbsolutePath());
				throw new ConfigurationException(path.toString() + "should be a path with write permission for SAF.");
			}
		} else {
			try {
				Files.write(path, "test".getBytes());
				Files.delete(path);
			} catch (Exception e) {
				log.error("No write access for " + path.toAbsolutePath());
				throw new ConfigurationException(path.toString() + "should be a path with write permission for SAF.", e);
			}
		}
	}
	
	protected void concatFile(Path source, Path dest) throws IOException {
		try (
				FileInputStream in = new FileInputStream(source.toFile());
				FileOutputStream out = new FileOutputStream(dest.toFile(),true);) {
			
			FileChannel inputChannel = in.getChannel();
			FileChannel outputChannel = out.getChannel();

			inputChannel.transferTo(0, inputChannel.size(), outputChannel);
		} 
	}
}
