package com.bpc.sesame.saf.services;

import com.bpc.sesame.saf.exception.RequesterException;
import gentypes.saml.metadata.v20.EntityDescriptorType;
import gentypes.saml.metadata.v20.KeyTypes;
import gentypes.saml.metadata.v20.SPSSODescriptorType;

import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.bnppa.sesame.services.internal.exception.v2.UnauthorizedActionException;
import com.bnppa.sesame.services.internal.model.v2.ServiceProvider;
import com.bnppa.sesame.services.internal.v2.ServiceProvidersServices;
import com.bpc.sesame.saf.exception.ConfigurationException;
import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.model.ServiceProviderLocal;
import com.bpc.sesame.saf.statistics.Profiled;
import com.bpc.sesame.saf.util.CryptographicTools;
import com.bpc.sesame.saf.util.XmlTools;

/**
 * Local version of the Services to manage the different service providers.
 * Local version = cache management
 * @author 483838
 */
@Service
public class ServiceProvidersServicesLocal {
	
	//private static final Logger log = LoggerFactory.getLogger(ServiceProviderServicesLocal.class);

	@Value("${sesame.saf.service-providers.signing-keys.minimum-rsa-size}")
	private int signingKeyMinimumSize;
	
	@Value("${sesame.saf.service-providers.encryption-keys.minimum-rsa-size}")
	private int encryptionKeyMinimumSize;
			
	@Autowired
	private ServiceProvidersServices serviceProviderServices;
	
	@Autowired
	private SesameServices sesameServices;
	
	private ServiceProvidersServicesLocal self;
	
    @Autowired
    private ApplicationContext applicationContext;

    @PostConstruct
    private void init() {
        self = applicationContext.getBean(ServiceProvidersServicesLocal.class);
    }
	
	/**
	 * This method check if the Service Provider have been registered.
	 * This method is based on getMetadata so it will also use the cache.
	 * 
	 * if the 
	 * @param entityId
	 */
	public void checkRegistration(String entityId) {
		try {
			//use self to re-use the cache mecanism
			self.getServiceProviderWithCache(entityId);
		} catch (Exception e) {
			throw new RequesterException("The issuer of this request is unknown : '" + entityId+ "'", e);
		}
	}
	
	/**
	 * Get service provider informations with cache mechanism
	 * @param entityId
	 * @return
	 */
	@Cacheable(cacheNames="serviceProvidersCache")
	public ServiceProviderLocal getServiceProviderWithCache(String entityId) {
		ServiceProvider remote = self.getServiceProviderFromRemote(entityId);
		
		//Convert Metadata object use for transport and storage to MetadataLocal use by SAF
		ServiceProviderLocal local = new ServiceProviderLocal();
		
		//EntityId
		local.setEntityId(remote.getEntityId());
		
		//Sesame Application Domain
		local.setApplicationDomain(remote.getApplicationDomain());
		
		//AuthLevel
		if (remote.getAuthLevelDerogation()!=null) {
			local.setAuthLevel(remote.getAuthLevelDerogation());
		} else {
			if (remote.getAuthLevel()!=null) {
				local.setAuthLevel(remote.getAuthLevel());
			} else {
				throw new TechnicalException("Impossible to find an AuthLevel for : " + remote.getEntityId());
			}
		}
		
		//Description
		EntityDescriptorType description = XmlTools.stringToEntityDescriptorType(remote.getMetaData());
		if (description.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor() == null ||
				description.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor().size()!=1 ||
				!(description.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor().get(0) instanceof SPSSODescriptorType)) {
			throw new TechnicalException("Sesame SAF manage only one declaration of type SPSSODescriptor.");
		}
		SPSSODescriptorType spDescription = (SPSSODescriptorType) description.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor().get(0);
		local.setDescription(spDescription);
		
		//Signing Certificate
		List<X509Certificate> certificates = CryptographicTools.extractCertificateFromEntityDescriptorType(spDescription, KeyTypes.SIGNING);
		if (certificates.size()!=1 ) {
			throw new ConfigurationException("The service provider '"+entityId+"' doesn't have a unique key for signing, but : " + certificates.size());
		}
		X509Certificate signingCertificate = certificates.get(0);
		if (!(signingCertificate.getPublicKey() instanceof RSAPublicKey)) {
			throw new ConfigurationException("The service provider '"+entityId+"' doesn't have a key for signing of type RSA.");
		}

		if (((RSAPublicKey)signingCertificate.getPublicKey()).getModulus().bitLength()<signingKeyMinimumSize) {
			throw new ConfigurationException("The service provider '"+entityId+"' doesn't have a RSA key of "+signingKeyMinimumSize+" bits (minimum) for signing.");
		}
		local.setSigningCertificate(signingCertificate);
		
		//Encryption Certificate
		certificates = CryptographicTools.extractCertificateFromEntityDescriptorType(spDescription, KeyTypes.ENCRYPTION);
		if (certificates.size()!=1 ) {
			throw new ConfigurationException("The service provider '"+entityId+"' doesn't have a unique key for encryption, but : " + certificates.size());
		}
		X509Certificate encryptionCertificate = certificates.get(0);
		if (!(encryptionCertificate.getPublicKey() instanceof RSAPublicKey)) {
			throw new ConfigurationException("The service provider '"+entityId+"' doesn't have a key for encryption of type RSA.");
		}
		
		if (((RSAPublicKey)encryptionCertificate.getPublicKey()).getModulus().bitLength()<encryptionKeyMinimumSize) {
			throw new ConfigurationException("The service provider '"+entityId+"' doesn't have a RSA key of "+encryptionKeyMinimumSize+" bits (minimum) for encryption.");
		}
		local.setEncryptionCertificate(encryptionCertificate);
		
		
		//like the certificate are load we can unreference their declaration to save memory
		spDescription.getKeyDescriptor().clear();
		
		return local;
	}

	/**
	 * Get service provider informations without cache mechanism
	 * @param entityId
	 * @return
	 */
	@Profiled(name="out-spring-getServiceProvider")
	public ServiceProvider getServiceProviderFromRemote(String entityId) {
		ServiceProvider meta = null;
		try {
			meta = serviceProviderServices.getServiceProviderWithoutToken(entityId);
		} catch (UnauthorizedActionException e) {
			throw new ConfigurationException("Error while trying to retrieve the service metadata." , e);
		} catch (com.bnppa.sesame.services.internal.exception.v2.TechnicalException e) {
			throw new TechnicalException("Remote error while get ServiceProvider from Sesame.",e);
		}
		return meta;
	}
}
