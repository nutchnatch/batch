package com.bpc.sesame.saf.services;

import gencl.sesame.services.standard.proxy.*;
import gentypes.sesame.services.common.model.Joining;
import gentypes.sesame.services.common.model.KeyValue;
import gentypes.sesame.services.common.model.UserIdentity;
import gentypes.sesame.services.common.model.UsingRight;

import java.util.List;

import javax.xml.ws.BindingProvider;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.statistics.Profiled;
import com.bpc.sesame.saf.util.AuditFilter;

/**
 * Service wrapper around Sesame Services with profiling
 * @author 483838
 */
@Service
public class SesameServices {

	//Sesame Jaxws Client
	private AuthenticationServicesWSPService authenticationService = new AuthenticationServicesWSPService();
	private AuthorizationServicesWSPService authorizationService = new AuthorizationServicesWSPService();
	private IdentityServicesWSPService identityService = new IdentityServicesWSPService();
	private SecuredAuthenticationServicesWSPService securedAuthenticationService = new SecuredAuthenticationServicesWSPService();
	
	@Autowired
	private EnvironmentServices environmentServices;
	
	@Value("${sesame.saf.identity-provider.sesame-username}")
	private String sesameBasicAuthenticationUsername;
	
	@Value("${sesame.saf.identity-provider.sesame-password}")
	private String sesameBasicAuthenticationPassword;
	
	@Value("${sesame.saf.identity-provider.request.loginInUserRef.timeout}")
	private long loginInUserRefTimeout;
	
	@Value("${sesame.saf.identity-provider.request.logout.timeout}")
	private long logoutTimeout;
	
	@Value("${sesame.saf.identity-provider.request.getTokenFromLogin.timeout}")
	private long getTokenFromLoginTimeout;
	
	@Value("${sesame.saf.identity-provider.request.getUserIdentity.timeout}")
	private long getUserIdentityTimeout;
	
	@Value("${sesame.saf.identity-provider.request.getExtendedAttributes.timeout}")
	private long getExtendedAttributesTimeout;
	
	@Value("${sesame.saf.identity-provider.request.getJoinings.timeout}")
	private long getJoiningsTimeout;
	
	@Value("${sesame.saf.identity-provider.request.getPermissions.timeout}")
	private long getPermissionsTimeout;
	
	@Value("${sesame.saf.identity-provider.request.getRoles.timeout}")
	private long getRolesTimeout;
	
	@Value("${sesame.saf.identity-provider.request.getUsingRight.timeout}")
	private long getUsingRightTimeout;

	/**
	 * ChangePassword operation timeout.
	 */
	@Value("${sesame.saf.identity-provider.request.changePassword.timeout}")
	private long changePasswordTimeout;

    /**
     * Authentication services WSP endpoint.
     */
    private static final String AUTHENTICATION_SERVICES_WSP = "AuthenticationServicesWSP";
	/**
	 * Authorization services WSP endpoint.
	 */
	private static final String AUTHORIZATION_SERVICES_WSP = "AuthorizationServicesWSP";

	/**
	 * init the client for each request (jax-ws is not thread safe)
	 * @param bp
	 * @param endpoint
	 * @param authent
	 * @param responseTimeout
	 */
	private void initClient(BindingProvider bp, String endpoint, boolean authent, long responseTimeout) {
		
		String sesameBaseURL = environmentServices.getSesameBaseURL();
		
		bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, sesameBaseURL + "/sesame_services/services/" + endpoint);
		if (authent) {
			bp.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, sesameBasicAuthenticationUsername);
			bp.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, sesameBasicAuthenticationPassword);
		}
		
		if (Thread.currentThread().getContextClassLoader().getResource("org/apache/cxf/transport/servlet/CXFNonSpringServlet.class") != null) {
			
			//Tomcat/CXF Timeout configuration
			Client cl = ClientProxy.getClient(bp);
			HTTPConduit http = (HTTPConduit) cl.getConduit();
			HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
			httpClientPolicy.setReceiveTimeout(responseTimeout);
			http.setClient(httpClientPolicy);
		} else {
			//Websphere Timeout configuration :
			bp.getRequestContext().put("timeout", Long.toString(responseTimeout));
		}
	}

	@Profiled(name="out-soap-loginInUserRef")
	public String getTokenFromLoginPassword(String login, String password) {
		AuthenticationServicesWSP auth = authenticationService.getAuthenticationServicesWSP();
		initClient((BindingProvider)auth, AUTHENTICATION_SERVICES_WSP, false, loginInUserRefTimeout);
		try {
			String token = auth.loginInUserRef(login, password, "TIERS");
			MDC.put(AuditFilter.TOKEN_SESAME, token);
			return token;
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	@Profiled(name="out-soap-logout")
	public void logout(String token) {
		AuthenticationServicesWSP auth = authenticationService.getAuthenticationServicesWSP();
		initClient((BindingProvider)auth, AUTHENTICATION_SERVICES_WSP, false, logoutTimeout);
		try {
			auth.logout(token);
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}

	@Profiled(name="out-soap-getTokenFromLogin")
	public String getTokenFromLogin(String login) {
		SecuredAuthenticationServicesWSP auth = securedAuthenticationService.getSecuredAuthenticationServicesWSP();
		initClient((BindingProvider)auth, "SecuredAuthenticationServicesWSP", true, getTokenFromLoginTimeout);
		try {
			String token = auth.getTokenFromLogin(login, 1);
			MDC.put(AuditFilter.TOKEN_SESAME, token);
			return token;
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	@Profiled(name="out-soap-getUserIdentity")
	public UserIdentity getUserIdentity(String token) {
		IdentityServicesWSP auth = identityService.getIdentityServicesWSP();
		initClient((BindingProvider)auth, "IdentityServicesWSP", false, getUserIdentityTimeout);
		try {
			return auth.getUserIdentity(token);
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	@Profiled(name="out-soap-getExtendedAttributes")
	public List<KeyValue> getExtendedAttributes(String token) {
		IdentityServicesWSP auth = identityService.getIdentityServicesWSP();
		initClient((BindingProvider)auth, "IdentityServicesWSP", false, getExtendedAttributesTimeout);
		try {
			return auth.getExtendedAttributes(token).getKeyValue();
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	@Profiled(name="out-soap-getJoinings")
	public List<Joining> getJoinings(String token, String appDomain) {
		AuthorizationServicesWSP auth = authorizationService.getAuthorizationServicesWSP();
		initClient((BindingProvider)auth, AUTHORIZATION_SERVICES_WSP, false, getJoiningsTimeout);
		try {
			return auth.getJoinings(token, appDomain).getJoining();
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	@Profiled(name="out-soap-getPermissions")
	public List<String> getPermissions(String token, String appDomain) {
		AuthorizationServicesWSP auth = authorizationService.getAuthorizationServicesWSP();
		initClient((BindingProvider)auth, AUTHORIZATION_SERVICES_WSP, false, getPermissionsTimeout);
		try {
			return auth.getPermissions(token, appDomain).getString();
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	@Profiled(name="out-soap-getRoles")
	public List<String> getRoles(String token, String appDomain) {
		AuthorizationServicesWSP auth = authorizationService.getAuthorizationServicesWSP();
		initClient((BindingProvider)auth, AUTHORIZATION_SERVICES_WSP, false, getRolesTimeout);
		try {
			return auth.getRoles(token, appDomain).getString();
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	@Profiled(name="out-soap-getUsingRight")
	public UsingRight getUsingRight(String token, String appDomain) {
		AuthorizationServicesWSP auth = authorizationService.getAuthorizationServicesWSP();
		initClient((BindingProvider)auth, AUTHORIZATION_SERVICES_WSP, false, getUsingRightTimeout);
		try {
			return auth.getUsingRight(token, appDomain);
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}

	/**
	 *
	 * Change the password for a given login.
	 *
	 * @param login         The login of the user for whom the password is to be changed
	 * @param oldPassword   The current user password
	 * @param newPassword   The new password
	 */
	@Profiled(name="out-soap-changePassword")
	public void changePassword(final String login, final String oldPassword, final String newPassword) {
		final AuthenticationServicesWSP authenticationServicesWSP = authenticationService.getAuthenticationServicesWSP();
		initClient((BindingProvider)authenticationServicesWSP, AUTHENTICATION_SERVICES_WSP, false, changePasswordTimeout);
		try {
			authenticationServicesWSP.changePassword(login, oldPassword, newPassword);
		} catch (final Exception e) {
			throw new TechnicalException(getErrorCode(e.getMessage()), e);
		}
	}



	/**
	 *
	 * Returns the error code of the message. The expected format is <error_code> : <description>.
	 *
	 * @param msg   The full error message
	 * @return      The error code
	 */
	private String getErrorCode(final String msg) {
		final int errorEndPosition = msg.indexOf(':');
		if(errorEndPosition > -1) {
			return msg.substring(0, errorEndPosition).trim();
		}
		return msg;
	}
}
