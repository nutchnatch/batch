package com.bpc.sesame.saf.services;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.bnppa.sesame.services.internal.exception.v2.UnauthorizedActionException;
import com.bnppa.sesame.services.internal.model.v2.IdentityProviderCertificate;
import com.bnppa.sesame.services.internal.v2.IdentityProviderServices;
import com.bpc.sesame.saf.exception.ConfigurationException;
import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.model.CertificatePK;
import com.bpc.sesame.saf.statistics.Profiled;
import com.bpc.sesame.saf.util.CryptographicTools;

/**
 * Services to manager the identity provider.<br> 
 * Basically, it is a wrapper around the remote IdentityProviderServices
 * Which add a cache functionality.
 * @author 483838
 */
@Service
public class IdentityProviderServicesLocal {
	
	private static final Logger log = LoggerFactory.getLogger(IdentityProviderServicesLocal.class);
	
	@Autowired
	private IdentityProviderServices identityProviderServices;
	
	@Autowired
	private SesameServices sesameServices;
	
	@Value("${sesame.saf.identity-provider.private-key.passphrase}")
	private char[] privateKeyPassphrase;
	
	private IdentityProviderServicesLocal self;
	
    @Autowired
    private ApplicationContext applicationContext;

    @PostConstruct
    private void init() {
        self = applicationContext.getBean(IdentityProviderServicesLocal.class);
    }
	
    /**
     * 
     * @return
     */
	@Cacheable(cacheNames="identityProviderCache")
	public CertificatePK getCurrentCertificateWithCache() {
		IdentityProviderCertificate certificate = self.getCurrentCertificateFromRemote();
		if (certificate == null) {
			throw new ConfigurationException("No Certificate are available for the IDP.");
		}
		CertificatePK currentCertificateCache = CryptographicTools.pemStringToCertificatePK(certificate.getCertificate(), privateKeyPassphrase);
		return currentCertificateCache;
	}

	@Profiled(name="out-spring-getCurrentCertificate")
	public IdentityProviderCertificate getCurrentCertificateFromRemote() {
		IdentityProviderCertificate certificate = null;
		try {
			certificate = identityProviderServices.getCurrentIdentityProviderCertificateWithoutToken();
		} catch (UnauthorizedActionException e) {
			log.info("UnauthorizedActionException when calling getCurrentCertificatePEM." + e.getMessage());
			throw new ConfigurationException(e);
		} catch (com.bnppa.sesame.services.internal.exception.v2.TechnicalException e) {
			log.info("TechnicalException when calling getCurrentCertificatePEM." + e.getMessage());
			throw new TechnicalException(e);
		}
		return certificate;
	}


}
