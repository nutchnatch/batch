package com.bpc.sesame.saf.services;

import gentypes.saml.assertion.v20.AttributeType;
import gentypes.saml.metadata.v20.AttributeConsumingServiceType;
import gentypes.saml.metadata.v20.RequestedAttributeType;
import gentypes.saml.metadata.v20.SPSSODescriptorType;
import gentypes.saml.protocol.v20.AuthnRequestType;
import gentypes.sesame.services.common.model.Joining;
import gentypes.sesame.services.common.model.KeyValue;
import gentypes.sesame.services.common.model.UserIdentity;
import gentypes.sesame.services.common.model.UsingRight;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bpc.sesame.saf.model.Attribute;
import com.bpc.sesame.saf.model.ServiceProviderLocal;
import com.bpc.sesame.saf.services.AuthenticatorServices.AuthenticatedUser;

/**
 * Service to manage <Attributes> from SAML specifications.
 * @author 483838
 */
@Service
public class AttributesServices {
	
	private static final Logger log = LoggerFactory.getLogger(AuthenticatorServices.class);
	
	@Autowired
	private ServiceProvidersServicesLocal serviceProvidersServicesLocal;
	
	@Autowired
	private SesameServices sesameServices;
	
	/**
	 * Retrieve the attributes for the given request and user.
	 * 
	 * Mechanism is :
	 * <li> The service provider emits a <AuthnRequest> with an attribute AttributeConsumingServiceIndex (a number).
	 * <li> The identity provider look for <AttributeConsumingService> in the metadata of the service provider with the good index.
	 * <li> Inside <AttributeConsumingService> each element is a <RequestedAttribute> which will be transform in <Attribute> for the response.
	 * @param authnRequest
	 * @param user
	 * @return
	 */
	public Set<AttributeType> retrieveAttributes(AuthnRequestType authnRequest, AuthenticatedUser user) {
		
		String entityIdIssuer = authnRequest.getIssuer().getValue();
		ServiceProviderLocal metadata = serviceProvidersServicesLocal.getServiceProviderWithCache(entityIdIssuer);
		
		Set<AttributeType> requestedAttributes = retrieveRequestedAttributes(authnRequest, metadata.getDescription());
		
		return populateAttributesWithUserValue(user, requestedAttributes, metadata.getApplicationDomain());
	}
	
	private Set<AttributeType> getDefaultAttributes() {
		Set<AttributeType> attributes = new HashSet<>();
		return attributes;
	}
	
	
	/**
	 * Return the requested attributes for this request / user
	 * 
	 * @param authnRequest
	 * @param user
	 * @return
	 */
	private Set<AttributeType> retrieveRequestedAttributes(AuthnRequestType authnRequest, SPSSODescriptorType descriptor) {
		
		//If no <AttributeConsumingService> in metadata
		if (descriptor.getAttributeConsumingService()==null) {
			return getDefaultAttributes();
		
		//If no AttributeConsumingServiceIndex="X" in request 
		} else if (authnRequest.getAttributeConsumingServiceIndex()==null) {
			return getDefaultAttributes();
			
		//If minimum one <AttributeConsumingService> and an AttributeConsumingServiceIndex in request :
		//choose the one with good index
		//Use default otherwise (no index or index not found) with a warning on the log	
		} else {
		
			AttributeConsumingServiceType selectedAttributes = null;
			for (AttributeConsumingServiceType attributes : descriptor.getAttributeConsumingService()) {
				if (Integer.valueOf(attributes.getIndex()).equals(authnRequest.getAttributeConsumingServiceIndex())) {
					selectedAttributes = attributes;
					break;
				}
			}
			
			if (selectedAttributes == null) {
				log.warn("The index of RequestAttributes '{}' cannot be found in metadata of {}. The default Attributes will be used.", 
						authnRequest.getAttributeConsumingServiceIndex(), authnRequest.getIssuer().getValue());
				return getDefaultAttributes();
			}
			
			return cloneAttributes(selectedAttributes);
		}
		
	}
	
	/**
	 * Because the SPSSODescriptorType exist in memory for all users we cannot use the attributes as is. 
	 * @param source
	 * @return
	 */
	private Set<AttributeType> cloneAttributes(AttributeConsumingServiceType source) {
		Set<AttributeType> destination = new HashSet<>();
		for (RequestedAttributeType s : source.getRequestedAttribute()) {
			AttributeType d = new AttributeType();
			d.setFriendlyName(s.getFriendlyName());
			d.setName(s.getName());
			d.setNameFormat(s.getNameFormat());
			destination.add(d);
		}
		return destination;
	}
	
	/**
	 * Populate eache attribute with the data of the current AuthenticatedUser
	 * @param user
	 * @param requestedAttributes
	 * @param applicationDomain
	 * @return
	 */
	private Set<AttributeType> populateAttributesWithUserValue(AuthenticatedUser user, Set<AttributeType> requestedAttributes, String applicationDomain) {
		Set<AttributeType> response = new HashSet<>();
		AttributesCollector ac = new AttributesCollector(user);
		boolean requestToken = false;
		for (AttributeType s : requestedAttributes) {
			
			//Display Name
			if (s.getName().equals(Attribute.DISPLAY_NAME.getName())) {
				s.getAttributeValue().add(ac.getDisplayName());
				response.add(s);
				
			//Sesame Token
			} else if (s.getName().equals(Attribute.TOKEN.getName())) {
				s.getAttributeValue().add(ac.getSesameToken());
				requestToken = true;
				response.add(s);
				
			//UserIdentity
			} else if (s.getName().equals(Attribute.USER_IDENTITY.getName())) {
				s.getAttributeValue().add(ac.getUserIdentity());
				response.add(s);
				
			//Permissions
			} else if (s.getName().equals(Attribute.PERMISSIONS_ID.getName())) {
				List<String> perms = ac.getPermissionsId(applicationDomain);
				s.getAttributeValue().addAll(perms);
				response.add(s);
				
			//Roles
			} else if (s.getName().equals(Attribute.ROLES_ID.getName())) {
				List<String> roles = ac.getRolesId(applicationDomain);
				s.getAttributeValue().addAll(roles);
				response.add(s);
				
			//UsingRight
			} else if (s.getName().equals(Attribute.USING_RIGHT.getName())) {
				s.getAttributeValue().add(ac.getUsingRight(applicationDomain));
				response.add(s);
				
			//Joinings
			} else if (s.getName().equals(Attribute.JOININGS.getName())) {
				List<Joining> joinings = ac.getJoinings(applicationDomain);
				s.getAttributeValue().addAll(joinings);
				response.add(s);
				
			//Extended Attributes
			} else if (s.getName().equals(Attribute.EXTENDED_ATTRIBUTES.getName())) {
				List<KeyValue> kv = ac.getExtendedAttributes();
				s.getAttributeValue().addAll(kv);
				response.add(s);
				
			} else {
				log.info("The attribute name '"+ s.getName() + "' is unknown for Sesame SAF.");
			}
		}
		
		//The requester doesn't need the sesame token but we created it : we can logout
		String sesameToken = ac.getSesameTokenCreated();
		if (!requestToken && sesameToken!=null) {
			try {
				sesameServices.logout(sesameToken);
			} catch(Exception e) {
				//none blocking error
				log.error("Error while logout from sesame :", e);
			}
		}
		return response;
	}
	
	/**
	 * Smart attribute collector, which can be request in any order without performance impact.
	 * The idea is to avoid to call the same sesame service twice.
	 * @author 483838
	 */
	private class AttributesCollector {
		
		protected AttributesCollector(AuthenticatedUser user) {
			this.login = user.getLogin();
			this.sesameToken = user.getSesameToken();
		}
		
		private String login;
		private String sesameToken;
		private UserIdentity userIdentity;
		
		public String getSesameToken() {
			if (sesameToken!=null) {
				return sesameToken;
			}
			sesameToken = sesameServices.getTokenFromLogin(login);
			return sesameToken;
		}
		
		public String getSesameTokenCreated() {
			return sesameToken;
		}
		
		public UserIdentity getUserIdentity() {
			if (userIdentity!=null) {
				return userIdentity;
			}
			String token = getSesameToken();
			userIdentity = sesameServices.getUserIdentity(token);
			return userIdentity;
		}
		
		public String getDisplayName() {
			UserIdentity user = getUserIdentity();
			return user.getFirstName() + " " + user.getLastName();
		}
		
		public List<String> getPermissionsId(String appDomain) {
			String token = getSesameToken();
			return sesameServices.getPermissions(token, appDomain);
		}
		
		public List<String> getRolesId(String appDomain) {
			String token = getSesameToken();
			return sesameServices.getRoles(token, appDomain);
		}
		
		public List<Joining> getJoinings(String appDomain) {
			String token = getSesameToken();
			return sesameServices.getJoinings(token, appDomain);
		}
		
		public UsingRight getUsingRight(String appDomain) {
			String token = getSesameToken();
			return sesameServices.getUsingRight(token, appDomain);
		}
		
		public List<KeyValue> getExtendedAttributes() {
			String token = getSesameToken();
			return sesameServices.getExtendedAttributes(token);
		}
	}
}
