package com.bpc.sesame.saf;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.services.EnvironmentServices;

/**
 * This class declare the spring configuration in the web scenario.
 * @see Application
 * @author 483838
 */
@Configuration
@PropertySource(value={"classpath:properties/sesame-saf.properties"}, ignoreResourceNotFound=true)
public class ApplicationWeb {
	
	@Configuration
	@Import({Application.class})
	static class innerConfig {
		
	}
	
	@Value("${sesame.saf.identity-provider.sesame-base-url}")
	private String sesameBaseURL;
	
	@Bean
	public EnvironmentServices getEnvironmentServicesForNonMock() {
		return new EnvironmentServices() {
			@Override
			public String getSesameBaseURL() {
				return sesameBaseURL;
			}

			@Override
			public void setSesameBaseURL(String sesameBaseURL) {
				throw new TechnicalException("Not implemented service, only saf mock can dynamically change url.");
			}
		};
	}
}
