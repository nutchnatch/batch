package com.bpc.sesame.saf.servlets;

import java.io.IOException;
import java.io.InputStream;
import java.util.jar.Manifest;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * A simple welcome page which display the application name and its version.
 * The version is find in the MANIFEST.MF at startup. So it is not working in dev mode.
 * @author 483838
 */
@WebServlet("/index.html")
public class IndexServlet extends HttpServlet {
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		try (InputStream inputStream = getServletContext().getResourceAsStream("/META-INF/MANIFEST.MF")) {
			if (inputStream==null) {
				return;
			}
			this.safVersion = new Manifest(inputStream).getMainAttributes().getValue("Implementation-Version");
		} catch (IOException e) {
			this.safVersion = "ersion not found (error)";
		}
	}
	
	private String safVersion = "ersion not found";

	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// String safVersion = IndexServlet.class.getPackage().getImplementationVersion(); < doesn't work on websphere
		response.setContentType("text/html");
		response.getWriter().write("<h1>Sesame SAF <span style=\"font-size:10pt;\">v"+ safVersion+"</span></h1>");
	}
}