package com.bpc.sesame.saf.servlets;

import com.bpc.sesame.saf.WebConstants;
import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.services.SesameServices;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 *
 * Servlet for treating the request for the changePassword page.
 *
 * @author a20257
 * @since 1.0.0
 * @see HttpServlet
 */
@WebServlet(name="ChangePasswordServlet", urlPatterns={"/changePassword"})
public class ChangePasswordServlet extends HttpServlet{

    /**
     * Change password JSP page to forward/redirect after completing the request.
     */
    private static final String CHANGE_PASS_PAGE = "/changePassword.jsp";

    /**
     * The application web context path.
     */
    @Value("${server.context-path}")
    private String context;
    
    /**
     * Logger for the class ChangePasswordServlet.
     */
    private static final Logger LOG = LoggerFactory.getLogger(ChangePasswordServlet.class);
    
    @Autowired
    private SesameServices sesameServices;

    @Override
    protected void doPost(final HttpServletRequest req, final HttpServletResponse resp)
            throws ServletException, IOException {
        final String help = req.getParameter(WebConstants.ATTRIBUTE_HELP);
        req.setAttribute(WebConstants.ATTRIBUTE_HELP, help);
        final String login = req.getParameter(WebConstants.PARAMETER_LOGIN);
        final String oldPassword = req.getParameter(WebConstants.PARAMETER_OLD_PASS);
        final String newPassword = req.getParameter(WebConstants.PARAMETER_NEW_PASS);
        if (oldPassword == null || oldPassword.isEmpty()) {
            req.getRequestDispatcher(CHANGE_PASS_PAGE).forward(req, resp);
            return;
        }
        try {
            sesameServices.changePassword(login, oldPassword, newPassword);
        } catch (final TechnicalException e) {
            LOG.warn("Technical Exception occurred with message {}", e.getMessage(), e);
            req.setAttribute(WebConstants.ATTRIBUTE_ERROR, e.getMessage());
            req.getRequestDispatcher(CHANGE_PASS_PAGE).forward(req, resp);
            return;
        }
        resp.sendRedirect(context + CHANGE_PASS_PAGE + "?" + WebConstants.PARAMETER_SUCCESS +
                ((help!=null && !help.isEmpty())? ("&" + WebConstants.ATTRIBUTE_HELP + "=" + help):""));
    }

    @Override
    protected void doGet(final HttpServletRequest req, final HttpServletResponse resp)
            throws ServletException, IOException {
        final String help = req.getParameter(WebConstants.ATTRIBUTE_HELP);
        req.setAttribute(WebConstants.ATTRIBUTE_HELP, help);
        req.getRequestDispatcher(CHANGE_PASS_PAGE).forward(req, resp);
    }

    @Override
    public void init(final ServletConfig config) throws ServletException {
        super.init(config);
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, config.getServletContext());
    }
}
