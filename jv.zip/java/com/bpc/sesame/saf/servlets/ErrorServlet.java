package com.bpc.sesame.saf.servlets;

import gentypes.saml.protocol.v20.AuthnRequestType;
import gentypes.saml.protocol.v20.ResponseType;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import org.springframework.web.util.HtmlUtils;

import com.bpc.sesame.saf.exception.RequesterException;
import com.bpc.sesame.saf.model.ResponseStatus;
import com.bpc.sesame.saf.services.SAMLServices;
import com.bpc.sesame.saf.util.XmlTools;

/**
 * This Servlet declared in the web.xml manage the Unchecked Exceptions for the POST and Redirect Bindings.
 * Please read the Exception strategy in the developer guide.
 * @author 483838
 */
@WebServlet("/error")
public class ErrorServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private static final Logger log = LoggerFactory.getLogger(ErrorServlet.class);

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processError(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processError(request, response);
	}
	
	@Value("${sesame.saf.identity-provider.debug.stacktrace-on-error-page}")
	private boolean stacktraceOnErrorPage;
	
	@Autowired
	private SAMLServices samlServices;

	public void init(ServletConfig config) throws ServletException {
	    super.init(config);
	    SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, config.getServletContext());
	}
	
	/**
	 * Process the error in 2 parts : Controller Part then View part.
	 * 
	 * This Error page manage 3 types of errors :
	 * - Http ones (if statusCode is not 500) ex 404
	 * - Authentication ones (RequesterException)
	 * - Technical ones (others)
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	private void processError(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		/////////////////////
		// CONTROLLER PART //
		/////////////////////
		Throwable throwable = (Throwable) request.getAttribute("javax.servlet.error.exception");
		Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
		AuthnRequestType authnRequestType = (AuthnRequestType) request.getAttribute("SAMLRequestAttribute");
		String samlResponseToSP = null;
		String applicationName = null;
		String errorCode = null;
		if (throwable instanceof ServletException) {
			errorCode = throwable.getMessage();
			throwable = throwable.getCause();
		}
		String errorAuthenticationMessage = null;
		String relayState = (String) request.getAttribute("RelayState");
		
		if (authnRequestType!=null) {
			applicationName = samlServices.computeApplicationName(authnRequestType);
		}
		
		if (throwable instanceof RequesterException) {
			errorAuthenticationMessage = "Authentication Failed.";
			samlResponseToSP = createErrorSamlResponse(authnRequestType, ResponseStatus.REQUESTER);
		} else if (throwable instanceof RuntimeException) {
			samlResponseToSP = createErrorSamlResponse(authnRequestType, ResponseStatus.RESPONDER);
		}
		
		///////////////
		// View PART // TODO use a jsp instead
		///////////////
	    response.setContentType("text/html");
	 
		PrintWriter out = response.getWriter();
		out.write("<!DOCTYPE html>\n");
		out.write("<html>\n");
		out.write("	<head>\n");
		out.write("		<title>Sesame Exception/Error</title>\n");
		out.write("		<link rel=\"stylesheet\" href=\""+ request.getContextPath() +"/css/style.css\">\n");
		out.write(" </head>\n");
		out.write(" <body>\n");
		out.write("		<div class=\"saf-card\">\n");
		out.write("	    <h1><image src=\"" + request.getContextPath() + "/images/logo.png\" width=\"40\" height=\"40\" /> Sesame </h1>");
	      		

		if (applicationName != null) {
			out.write("<p><strong>Application : </strong>" + HtmlUtils.htmlEscape(applicationName) + "</p>");
		}

	    
	    if(statusCode!=null && statusCode != 500){
	    	//HTTP ERROR
	    	out.write("<p>An unexpected error has occurred</p>\n");
		    out.write("<p><strong>Status Code</strong>:"+statusCode+"</p>");

	    } else if (errorAuthenticationMessage!=null) {
	    	//Authentication ERROR
	    	out.write("<p id=\"error\"><strong>Message : </strong>"+errorAuthenticationMessage+"</p>");
	    	log.warn("Error : " +errorCode + " > " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
	    	
	    } else{
	    	//Technical ERROR
	    	out.write("<p>An unexpected error has occurred</p>\n");
			log.error("Error : " +errorCode + " >", throwable);
			out.write("<p id=\"error\"><strong>Error : </strong>"+errorCode+"</p>");
	    }
	    
	    //Display the link to return to the application
	    if (samlResponseToSP!=null) {
	    	String url = authnRequestType.getAssertionConsumerServiceURL();
	    	if (validateURL(url)) {
				out.write("<form name=\"acsForm\" action=\""+url+"\" method=\"post\" style=\"display:none;\">");
				out.write("	<textarea id=\"fromError\" name=\"SAMLResponse\">"+samlResponseToSP+"</textarea>");
	            if (relayState!=null) { 
	            	out.write("<input name=\"RelayState\" type=\"text\" value=\""+relayState+"\" />");
	            }
				out.write("</form>");
				out.write("<a href=\"javascript:document.acsForm.submit();\">Return to the application</a>");
	    	}
	    }
	    
	    out.write("</div>");
	    
		if (stacktraceOnErrorPage && throwable != null) {
			out.write("<script>");
			out.write(" function displayError() { document.querySelector('.saf-card').style.display='none';document.querySelector('pre').style.display='block'; }");
			out.write("</script>");
			out.write("<a href=\"javascript:displayError();\">display error</a>");
			out.write("<pre style=\"display:none;\">Error : " + errorCode +" >\n");
			throwable.printStackTrace(out);
			out.write("</pre>");
		}
	
	    
	    out.write("</body></html>");
	}
	
	private String createErrorSamlResponse(AuthnRequestType authnRequestType, ResponseStatus errorStatus) throws UnsupportedEncodingException {
		if (authnRequestType!=null) {
			ResponseType re = samlServices.createFailedSamlResponse(authnRequestType, errorStatus);
			String finalSamlResponseXml = XmlTools.responseTypeToString(re, false);
			if (log.isDebugEnabled()) {
				log.debug("\n###### FINAL RESPONSE ######\n" + XmlTools.domToStringPretty(XmlTools.stringToDom(finalSamlResponseXml)));
			}
			return DatatypeConverter.printBase64Binary(finalSamlResponseXml.getBytes("UTF-8"));
		}
		return null;
	}
	
	/**
	 * Cheap URL validator. Use common validator or ESAPI instead ?
	 * @param url
	 * @return
	 */
	private static boolean validateURL(String url) {
		try {
			new URL(url).toURI();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}