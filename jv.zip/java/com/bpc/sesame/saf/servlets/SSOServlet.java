package com.bpc.sesame.saf.servlets;

import gentypes.saml.metadata.v20.EntityDescriptorType;
import gentypes.saml.protocol.v20.AuthnRequestType;
import gentypes.saml.protocol.v20.ResponseType;
import gentypes.sesame.services.common.model.Joining;
import gentypes.sesame.services.common.model.KeyValue;
import gentypes.sesame.services.common.model.UserIdentity;
import gentypes.sesame.services.common.model.UsingRight;
import gentypes.xmldsig.SignatureType;
import gentypes.xmlenc.EncryptedDataType;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Random;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import org.springframework.web.util.HtmlUtils;
import org.w3c.dom.Document;

import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.model.CertificatePK;
import com.bpc.sesame.saf.model.ServiceProviderLocal;
import com.bpc.sesame.saf.services.AuthenticatorServices;
import com.bpc.sesame.saf.services.AuthenticatorServices.AuthenticatedUser;
import com.bpc.sesame.saf.services.IdentityProviderServicesLocal;
import com.bpc.sesame.saf.services.SAMLServices;
import com.bpc.sesame.saf.services.ServiceProvidersServicesLocal;
import com.bpc.sesame.saf.statistics.ServiceStatistics;
import com.bpc.sesame.saf.util.AuditFilter;
import com.bpc.sesame.saf.util.XmlTools;

/**
 * 
 */
@WebServlet(name="SSOServlet", urlPatterns={"/redirect/sso/*","/post/sso/*"})
public class SSOServlet extends HttpServlet {
	
	private static final Logger logger = LoggerFactory.getLogger(SSOServlet.class);
	
	private static final Random random = new Random();

	private static final long serialVersionUID = 1L;
	
	@Value("${sesame.saf.identity-provider.response.validation}")
	private Boolean xmlValidationOfResponse;
	
	private Boolean persistAuthenticationSuccessInSession = false;
	
	private static Schema samlProtocolSchema = XmlTools.getSchemaFromXsd("xsd/saml-schema-protocol-2.0.xsd");
	
	@Autowired
	private ServiceProvidersServicesLocal serviceProvidersServicesLocal;
	
	@Autowired
	private AuthenticatorServices authenticatorServices;
	
	@Autowired
	private IdentityProviderServicesLocal identityProviderServicesLocal;
	
	@Autowired
	private SAMLServices samlServices;
	
	@Autowired
	private ServiceStatistics redirectStatistics;

	@Autowired
	private ServiceStatistics postStatistics;

	@Value("${sesame.saf.service-providers.request.max-age.seconds}")
	private int requestMaxAge; 
	
	@Value("${sesame.saf.service-providers.request.relaystate.max-size}")
	private int requestRelayStateMaxSize; 
	
	public void init(ServletConfig config) throws ServletException {
	    super.init(config);
	    SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, config.getServletContext());
	}
	
	/**
	 * Monitored endpoint for Redirect Binding
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long nanosBefore = System.nanoTime();
		redirectStatistics.incrementCurrentActiveCount();
		MDC.put(AuditFilter.BINDING, "REDIRECT");
		try {
			processSSO(request, response, false);
		} catch (Throwable t) {
			redirectStatistics.incrementExceptionCount(t);
		    throw wrapException(t);
		} finally {
			redirectStatistics.decrementCurrentActiveCount();
			redirectStatistics.incrementInvocationCounterAndTotalDurationWithNanos(System.nanoTime() - nanosBefore);
		}
	}
	
	/**
	 * Monitored endpoint for Post Binding
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long nanosBefore = System.nanoTime();
		postStatistics.incrementCurrentActiveCount();
		MDC.put(AuditFilter.BINDING, "POST");
		try {
			processSSO(request, response, true);
		} catch (Throwable t) {
			postStatistics.incrementExceptionCount(t);
			throw wrapException(t);
		} finally {
			postStatistics.decrementCurrentActiveCount();
			postStatistics.incrementInvocationCounterAndTotalDurationWithNanos(System.nanoTime() - nanosBefore);
		}
	}
	
	/**
	 * Business Logic of SSO (threw POST or Redirect Bindings)
	 * 
	 * @param request
	 * @param response
	 * @param postBinding
	 * @throws IOException
	 * @throws ServletException
	 */
	private void processSSO(HttpServletRequest request, HttpServletResponse response, boolean postBinding) throws IOException, ServletException  {
		
		response.setHeader("Content-Type", "text/html; charset=utf-8");
		response.setHeader("Cache-Control", "no-cache, no-store");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("X-Frame-Options", "DENY");
		
		String SAMLRequest = request.getParameter("SAMLRequest");

		if (SAMLRequest == null || SAMLRequest.equals("null")) {
			throw new IllegalArgumentException("SAMLRequest not found.");
		}

		// Parse the SAML request
		String requestXmlString = decodeHttpAuthnRequest(SAMLRequest, postBinding);
		if (logger.isDebugEnabled()) {
			logger.debug("\n######"+(postBinding?"POST":"GET")+" ENCODED REQUEST######\nSAMLRequest="+SAMLRequest);
			logger.debug("\n######"+(postBinding?"POST":"GET")+" XML REQUEST######\n"+ XmlTools.prettyXml(requestXmlString));
		}
		
		//Validate the request (XML Validation)
		XmlTools.validateRequest(requestXmlString);
		
		Document requestDocument = XmlTools.stringToDom(requestXmlString);
		AuthnRequestType authnRequest = unmarshallRequest(requestDocument);
		request.setAttribute("SAMLRequestAttribute", authnRequest);
		
		//Validate the request (SAML Validation)
		samlServices.validateAuthnRequest(authnRequest);
		
		//Validate the relayState parameter
		validateRelayState(request);
		
		ServiceProviderLocal spLocal = serviceProvidersServicesLocal.getServiceProviderWithCache(authnRequest.getIssuer().getValue());
		MDC.put(AuditFilter.SP_ENTITY_ID, spLocal.getEntityId());
		
		//Validate the request signature
		if (postBinding) {
			samlServices.validateAuthnRequestSignature(requestDocument, spLocal.getSigningCertificate().getPublicKey());
		} else {
			samlServices.validateAuthnRequestSignatureForRedirect(authnRequest, request, spLocal.getSigningCertificate().getPublicKey());
		}
		
		//Check that the request holds an Authentication Information compatible with SP AuthLevel
		AuthenticatedUser user = authenticatorServices.authenticate(request, spLocal.getAuthLevel());
		
		////////////////////////////////////////
		// From here the Authentication is OK //
		////////////////////////////////////////
			
		//Store the AuthenticatedUser in Session ?
		if (persistAuthenticationSuccessInSession) {
			request.getSession().setAttribute("AuthenticatedUser", user);
		}
		
		//Create the SAML Response
		Document domResponse = samlServices.createSuccessfulSamlResponse(user, authnRequest);

		//Sign the SAML response XML
		if (logger.isDebugEnabled()) {
			logger.debug("\n###### RESPONSE BEFORE SIGNING ######\n" + XmlTools.domToStringPretty(domResponse));
		}
		
		CertificatePK cert = identityProviderServicesLocal.getCurrentCertificateWithCache();
		samlServices.signAssertionInDocument(domResponse, cert);

		// Encryption the Assertion
		if (logger.isDebugEnabled()) {
			logger.debug("\n###### RESPONSE BEFORE ENCRYPTION ######\n" + XmlTools.domToStringPretty(domResponse));
		}
		samlServices.encryptAssertion(authnRequest, domResponse, spLocal.getEncryptionCertificate().getPublicKey());

		//Validate the response
		if (xmlValidationOfResponse) {
			XmlTools.validateResponse(domResponse);
		}
		
		//Prepare the final response with a POST Binding
		if (logger.isDebugEnabled()) {
			logger.debug("\n###### FINAL RESPONSE ######\n" + XmlTools.domToStringPretty(domResponse));
		}
		String finalSamlResponseXml = XmlTools.domToString(domResponse);
		MDC.put(AuditFilter.RESULT, AuditFilter.RESULT_OK);
		writeSuccessfullResponse(request, response,  authnRequest.getAssertionConsumerServiceURL(), finalSamlResponseXml);
	}
	
	private void writeSuccessfullResponse(HttpServletRequest request, HttpServletResponse response, String acsUrl, String finalSamlResponseXml)throws IOException, ServletException {
		String base64 = DatatypeConverter.printBase64Binary(finalSamlResponseXml.getBytes("UTF-8"));
		request.setAttribute("samlResponse", base64);
		
		// Forward SAML response to ACS
		request.setAttribute("acsURL", acsUrl);
		request.getRequestDispatcher("/responseForm.jsp").include(request, response);
	}

	private void validateRelayState(HttpServletRequest request) {
		String relayState = request.getParameter("RelayState");
		if (relayState==null || relayState.length() == 0) {
			return;
		}
		
		if (relayState.length()>requestRelayStateMaxSize) {
			throw new TechnicalException("The SAML specification indicates that the RelayState must have only 80 bytes. Here : " + relayState.length());
		}
		
		request.setAttribute("RelayState", HtmlUtils.htmlEscape(relayState, "UTF-8"));
	}
	
	private ServletException wrapException(Throwable t) {
		String errorCode = "E" + ((100000 + random.nextInt(100000)) +"").substring(1);
		MDC.put(AuditFilter.RESULT, errorCode);
		return new ServletException(errorCode, t);
	}
	
	private AuthnRequestType unmarshallRequest(Document requestDocument) {
		try {
			JAXBContext jaxbContext = XmlTools.createJaxbContext(new Class[]{AuthnRequestType.class, SignatureType.class});
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			jaxbUnmarshaller.setSchema(samlProtocolSchema);
			@SuppressWarnings("unchecked")
			JAXBElement<AuthnRequestType> el = (JAXBElement<AuthnRequestType>) jaxbUnmarshaller.unmarshal(requestDocument);
			return el.getValue();
		}catch(Exception e) {
			throw new IllegalArgumentException("The SAML Request is invalid.", e);
		}
	}

	/**
	 * Retrieves the AuthnRequest in 2 cases :
	 * <h3>Redirect Bindings :</h3>
	 * The method from the encoded and compressed String
	 * extracted from the URL. The AuthnRequest XML is retrieved in the
	 * following order: <p> 1. URL decode <br> 2. Base64 decode <br> 3. Inflate
	 * <br> Returns the String format of the AuthnRequest XML.
	 * <h3>Post Bindings :</h3>
	 * The method from the encoded String extracted from the URL. The AuthnRequest XML is retrieved in the
	 * following order: <p> 1. URL decode <br> 2. Base64 decode
	 * <br> Returns the String format of the AuthnRequest XML.
	 */
	private String decodeHttpAuthnRequest(String encodedRequestXmlString, boolean postBinding) {
		try {
			
			
			// URL decode
			// No need to URL decode: auto decoded by request.getParameter()

			// Base64 decode
			byte[] base64DecodedByteArray = DatatypeConverter.parseBase64Binary(encodedRequestXmlString);
			
			if (postBinding) {
				return new String(base64DecodedByteArray, "UTF-8");
			}

			// Uncompress the AuthnRequest data
			// First attempt to unzip the byte array according to DEFLATE (rfc
			// 1951)
			try {

				Inflater inflater = new Inflater(true);
				inflater.setInput(base64DecodedByteArray);
				// since we are decompressing, it's impossible to know how much
				// space we
				// might need; hopefully this number is suitably big
				byte[] xmlMessageBytes = new byte[5000];
				int resultLength = inflater.inflate(xmlMessageBytes);

				if (!inflater.finished()) {
					throw new TechnicalException("didn't allocate enough space to hold " + "decompressed data");
				}

				inflater.end();
				return new String(xmlMessageBytes, 0, resultLength, "UTF-8");

			} catch (DataFormatException e) {

				// if DEFLATE fails, then attempt to unzip the byte array
				// according to
				// zlib (rfc 1950)
				ByteArrayInputStream bais = new ByteArrayInputStream(base64DecodedByteArray);
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				InflaterInputStream iis = new InflaterInputStream(bais);
				byte[] buf = new byte[1024];
				int count = iis.read(buf);
				while (count != -1) {
					baos.write(buf, 0, count);
					count = iis.read(buf);
				}
				iis.close();
				return new String(baos.toByteArray(), "UTF-8");
			}

		} catch (UnsupportedEncodingException e) {
			throw new TechnicalException("Error decoding AuthnRequest: " + "Check decoding scheme - " + e.getMessage(), e);
		} catch (IOException e) {
			throw new TechnicalException("Error decoding AuthnRequest: " + "Check decoding scheme - " + e.getMessage(), e);
		}
	}
	
	@Override
	public void init() throws ServletException {
		super.init();
		try {
			//JAXB (ibm and RI) implementations creates inner classes of JAXB annoted classes to improve performance.
			//The code below allow JAXB RI to creates inner classes at startup (and before) JAXB IBM.
			//It avoid potentials errors at runtime, and make the first call quicker.
			XmlTools.createJaxbContext(new Class[]{
					ResponseType.class, 
					KeyValue.class, 
					UserIdentity.class, 
					UsingRight.class, 
					Joining.class, 
					AuthnRequestType.class, 
					SignatureType.class,
					EncryptedDataType.class,
					EntityDescriptorType.class});
		} catch (JAXBException e) {
			throw new TechnicalException("Impossible to init the JAXB classes",e);
		}
	}
	
}
