package com.bpc.sesame.saf.exception;

/**
 * This unchecked exception must be thrown when a configuration problem occurred from SAF.
 * Don't try to catch this exception, please consult the exception strategy guide of the 
 * technical documentation.
 * @author 483838
 */
public class ConfigurationException extends TechnicalException {

	private static final long serialVersionUID = 1L;

	public ConfigurationException() {
		super();
	}

	public ConfigurationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public ConfigurationException(String message, Throwable cause) {
		super(message, cause);
	}

	public ConfigurationException(String message) {
		super(message);
	}

	public ConfigurationException(Throwable cause) {
		super(cause);
	}

}
