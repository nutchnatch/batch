package com.bpc.sesame.saf.exception;

/**
 * This unchecked exception must be thrown when a problem occurred from the client (the requester).
 * This Exception will cancel the authentication due to the requester.
 * Don't try to catch this exception, please consult the exception strategy guide of the 
 * technical documentation.
 * @author 483838
 */
public class RequesterException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public RequesterException() {
		super();
	}

	public RequesterException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public RequesterException(String message, Throwable cause) {
		super(message, cause);
	}

	public RequesterException(String message) {
		super(message);
	}

	public RequesterException(Throwable cause) {
		super(cause);
	}

}
