package com.bpc.sesame.saf.exception;

/**
 * This unchecked exception must be thrown when a problem occurred from SAF.
 * This Exception will cancel the authentication due to the responder (SAF).
 * Don't try to catch this exception, please consult the exception strategy guide of the 
 * technical documentation.
 * @author 483838
 *
 */
public class TechnicalException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public TechnicalException() {
		super();
	}

	public TechnicalException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public TechnicalException(String message, Throwable cause) {
		super(message, cause);
	}

	public TechnicalException(String message) {
		super(message);
	}

	public TechnicalException(Throwable cause) {
		super(cause);
	}
}
