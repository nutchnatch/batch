package com.bpc.sesame.saf.util;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

/**
 * This servlet filter enables an audit logging based on SLF4J
 * @author 483838
 */
@WebFilter(urlPatterns={"/redirect/sso/*","/post/sso/*","/soap/sso/*"})
public class AuditFilter implements Filter {

	private static final Logger log = LoggerFactory.getLogger("AUDIT_LOGGER");

	public final static String RESULT = "result";
	public final static String RESULT_OK = "success";
	public final static String TOKEN_SESAME = "tokenSesame";
	public final static String BINDING = "binding"; //REDIRECT/POST/SOAP
	public final static String SP_ENTITY_ID = "spEntityId";
	public final static String USER_LOGIN = "userLogin";
	//The idp certificates serials numbers known by the service providers are
	//always at the end of the url extract them to audit them.
	public final static String SP_KNOWN_IDP_CERT = "spKnownIdbCert";
    public static final String REQUEST_REMOTE_HOST = "reqRemoteHost";
    public static final String REQUEST_USER_AGENT = "reqUserAgent";
    public static final String REQUEST_X_FORWARDED_FOR = "reqXForwardedFor";

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		long start = System.currentTimeMillis();
		try {
			chain.doFilter(request, response);
		} finally {
			insertRequestInformationIntoMDC(request);
			// the audit log
			log.info(Long.toString(System.currentTimeMillis() - start));
			MDC.clear();
		}
	}

	void insertRequestInformationIntoMDC(ServletRequest request) {

		MDC.put(REQUEST_REMOTE_HOST, request.getRemoteHost());
		if (request instanceof HttpServletRequest) {
			HttpServletRequest httpServletRequest = (HttpServletRequest) request;
			String uri = httpServletRequest.getRequestURI();
			int index = 0;
			if (uri!=null && (index = uri.lastIndexOf("/sso/"))>0) {
				MDC.put(SP_KNOWN_IDP_CERT, uri.substring(index + 5));
			}
			MDC.put(REQUEST_USER_AGENT, httpServletRequest.getHeader("User-Agent"));
			MDC.put(REQUEST_X_FORWARDED_FOR, httpServletRequest.getHeader("X-Forwarded-For"));
		}

	}

	public void init(FilterConfig arg0) throws ServletException {
	}

}