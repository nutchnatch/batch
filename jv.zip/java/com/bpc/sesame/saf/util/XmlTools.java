package com.bpc.sesame.saf.util;

import gentypes.saml.metadata.v20.EntityDescriptorType;
import gentypes.saml.protocol.v20.AuthnRequestType;
import gentypes.saml.protocol.v20.ObjectFactory;
import gentypes.saml.protocol.v20.ResponseType;
import gentypes.sesame.services.common.model.Joining;
import gentypes.sesame.services.common.model.KeyValue;
import gentypes.sesame.services.common.model.UserIdentity;
import gentypes.sesame.services.common.model.UsingRight;
import gentypes.xmldsig.SignatureType;
import gentypes.xmlenc.EncryptedDataType;

import java.io.FileInputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.TimeZone;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;

import com.bpc.sesame.saf.exception.TechnicalException;
import com.sun.xml.bind.v2.ContextFactory;

/**
 * This utility class is used across the various class in SAF to help transform xml data.
 */
public class XmlTools {
	
	private XmlTools() {
	}
	
	private static final Logger log = LoggerFactory.getLogger(XmlTools.class);

	// used for creating a randomly generated string
	private static Random random = new SecureRandom();
	private static final char[] charMapping = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p' };

	/**
	 * Creates a JDOM Document from a string containing XML
	 * 
	 * @param samlRequestString
	 *            String version of XML
	 * @return JDOM Document if file contents converted successfully, null
	 *         otherwise
	 */
	public static Document stringToDom(String xmlString) {
		try {
			DocumentBuilderFactory domFact = DocumentBuilderFactory.newInstance();
			// This is the PRIMARY defense. If DTDs (doctypes) are disallowed, almost all XML entity attacks are prevented
			domFact.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
			// Disable external DTDs as well
			domFact.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
			// and these as well, per Timothy Morgan's 2014 paper: "XML Schema, DTD, and Entity Attacks" (see reference below)
			domFact.setXIncludeAware(false);
			domFact.setExpandEntityReferences(false);
		      
			domFact.setNamespaceAware(true);
			DocumentBuilder builder = domFact.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlString)));
			return doc;
		} catch (Exception e) {
			throw new IllegalArgumentException("The xml String cannot be parse to Document.", e);
		}
	}
	
	/**
	 * Creates a JDOM Document from a string containing XML
	 * 
	 * @param samlRequestString
	 *            String version of XML
	 * @return JDOM Document if file contents converted successfully, null
	 *         otherwise
	 */
	public static Document sourceToDom(Source source) {
		try {
			//Source to Node with https://www.owasp.org/index.php/XML_External_Entity_(XXE)_Prevention_Cheat_Sheet
			TransformerFactory tf = TransformerFactory.newInstance();
			try {
				tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
			} catch (Exception e) {
				log.info("Your jaxp implementation (ibm?) doesn't support '"+XMLConstants.ACCESS_EXTERNAL_DTD+"'.");
				log.info("Your jaxp implementation (ibm?) may be subject to XXE attack.");
			}
			try {
				tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
			} catch (Exception e) {
				log.info("Your jaxp implementation (ibm?) doesn't support '"+XMLConstants.ACCESS_EXTERNAL_STYLESHEET+"'.");
				log.info("Your jaxp implementation (ibm?) may be subject to XXE attack.");
			}
			Transformer transformer = tf.newTransformer();
			DOMResult result = new DOMResult();
			transformer.transform(source, result);
			Node node = result.getNode();
			
			if (node instanceof Document) {
				return (Document) node;
			} else if (node.getOwnerDocument()!=null) {
				return node.getOwnerDocument();
			} else {
				DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document newDocument = builder.newDocument();
				newDocument.appendChild(node);
				return newDocument;
			}
		} catch (Exception e) {
			throw new IllegalArgumentException("The xml source cannot be parse to Document.", e);
		}
	}
	
	/**
	 * Creates a JDOM Document from a string containing XML and a schema
	 * 
	 * @param samlRequestString
	 *            String version of XML
	 * @return JDOM Document if file contents converted successfully, null
	 *         otherwise
	 */
	public static Document stringToDomWithSchema(String xmlString, Schema schema) {
		try {
			DocumentBuilderFactory domFact = DocumentBuilderFactory.newInstance();
			// This is the PRIMARY defense. If DTDs (doctypes) are disallowed, almost all XML entity attacks are prevented
			domFact.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
			// Disable external DTDs as well
			domFact.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
			// and these as well, per Timothy Morgan's 2014 paper: "XML Schema, DTD, and Entity Attacks" (see reference below)
			domFact.setXIncludeAware(false);
			domFact.setExpandEntityReferences(false);
		      
			domFact.setNamespaceAware(true);
			domFact.setIgnoringElementContentWhitespace(true);
			domFact.setSchema(schema);
			DocumentBuilder builder = domFact.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlString)));
			return doc;
		} catch (Exception e) {
			throw new IllegalArgumentException("The xml String cannot be parse to Document.", e);
		}
	}
	
	/**
	 * Transform a DOM Document to its xml text representation
	 * @param document
	 * @return
	 */
	public static String domToString(Document document) {
		try {
			DOMSource domSource = new DOMSource(document);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			transformer.transform(domSource, result);
			return writer.toString();
		} catch (Exception e) {
			throw new IllegalArgumentException("The dom document cannot be marshalled to String.", e);
		}
	}
	
	/**
	 * XML Validation of a <AuthnRequest> in text format
	 * @param xml
	 */
	public static void validateRequest(String xml) {
		try (StringReader reader = new StringReader(xml);) {
			StreamSource source = new StreamSource(reader);
			validateRequest(source);
		}
		
	}

	/**
	 * XML Validation of a <AuthnRequest>
	 * @param xmlSource
	 */
	public static void validateRequest(Source xmlSource) {
		try {
			URL schemaFile = Thread.currentThread().getContextClassLoader().getResource("xsd/saml-schema-protocol-2.0.xsd");
			SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema schema = schemaFactory.newSchema(schemaFile);
			Validator validator = schema.newValidator();
			validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			//Protection against XXE https://www.owasp.org/index.php/XML_External_Entity_(XXE)_Prevention_Cheat_Sheet
			//These properties should works on all JDK7+ but in fact they don't work on IBM one 
			try {
				validator.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
			} catch (SAXNotRecognizedException e) {
				log.info("Your jaxp implementation (ibm?) doesn't support '"+XMLConstants.ACCESS_EXTERNAL_DTD+"'.");
				log.info("Your jaxp implementation (ibm?) may be subject to XXE attack.");
			} 
			try {
				validator.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
			} catch (SAXNotRecognizedException e) {
				log.info("Your jaxp implementation (ibm?) doesn't support '"+XMLConstants.ACCESS_EXTERNAL_SCHEMA+"'.");
				log.info("Your jaxp implementation (ibm?) may be subject to XXE attack.");
			} 
			validator.validate(xmlSource);
		} catch (Exception e) {
			throw new TechnicalException("Invalid xml saml request.",e);
		}
	}
	
	/**
	 * XML Validation of a <Response>
	 * @param xml
	 * @return
	 */
	public static boolean validateResponse(Document xml) {
		Source xmlFile = null;
		try {
			URL schemaFile = Thread.currentThread().getContextClassLoader().getResource("xsd/saml-schema-protocol-2.0.xsd");
			xmlFile = new DOMSource(xml);
			SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema schema = schemaFactory.newSchema(schemaFile);
			Validator validator = schema.newValidator();

			validator.validate(xmlFile);
			return true;
		} catch (Exception e) {
			throw new TechnicalException("Invalid xml.",e);
		}
	}
	
	/**
	 * Create a randomly generated string conforming to the xsd:ID datatype.
	 * containing 160 bits of non-cryptographically strong pseudo-randomness, as
	 * suggested by SAML 2.0 core 1.2.3. This will also apply to version 1.1
	 * 
	 * @return the randomly generated string
	 */
	public static String createID() {
		byte[] bytes = new byte[20]; // 160 bits
		random.nextBytes(bytes);

		char[] chars = new char[40];

		for (int i = 0; i < bytes.length; i++) {
			int left = (bytes[i] >> 4) & 0x0f;
			int right = bytes[i] & 0x0f;
			chars[i * 2] = charMapping[left];
			chars[i * 2 + 1] = charMapping[right];
		}

		return String.valueOf(chars);
	}
	
	/**
	 * Create a XMLGregorianCalendar with a date relative to now. 
	 * @param timeshifting
	 * @return
	 */
	public static XMLGregorianCalendar createXmlGregorianCalendar(int timeshifting) {

		GregorianCalendar cal = new GregorianCalendar();
		cal.add(GregorianCalendar.SECOND, timeshifting);
		cal.setTimeZone(TimeZone.getTimeZone("GMT"));//TimeZone.getTimeZone(ZoneId.of("Europe/Paris")));
		try {
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		}catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	/**
	 * Format XML text
	 * @param xml
	 * @return
	 */
	public static String prettyXml(String xml) {
	    try {
	        Source xmlInput = new StreamSource(new StringReader(xml));
	        StringWriter stringWriter = new StringWriter();
	        StreamResult xmlOutput = new StreamResult(stringWriter);
	        TransformerFactory transformerFactory = TransformerFactory.newInstance();
	        transformerFactory.setAttribute("indent-number", 2);
	        Transformer transformer = transformerFactory.newTransformer(); 
	        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
	        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	        transformer.transform(xmlInput, xmlOutput);
	        return xmlOutput.getWriter().toString();
	    } catch (Exception e) {
	        throw new IllegalArgumentException("This xml cannot be prettified.",e);
	    }
	}
	
	/**
	 * Dom document to string text formatted
	 * @param node
	 * @return
	 */
	public static String domToStringPretty(Node node) {
		try {
			DOMSource domSource = new DOMSource(node);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			TransformerFactory tf = TransformerFactory.newInstance();
			tf.setAttribute("indent-number", 2);
			Transformer transformer = tf.newTransformer();
	        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
	        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(domSource, result);
			return writer.toString();
		} catch (Exception e) {
			throw new IllegalArgumentException("This dom document cannot be marshalled to String.", e);
		}
	}

	/**
	 * Return a Schema from an the path of a xsd in the classpath
	 * @param xsdPath
	 * @return
	 */
	public static Schema getSchemaFromXsd(String xsdPath) {
		SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		URL schemaURL = Thread.currentThread().getContextClassLoader().getResource(xsdPath);
		try {
			return schemaFactory.newSchema(schemaURL);
		} catch (SAXException e) {
			throw new IllegalArgumentException("The file " + xsdPath + " canno't be loaded as a Schema", e);
		} 
	}

	/**
	 * Dom Document to JAXB ResponseType
	 * @param document
	 * @return
	 */
	public static ResponseType domToResponseType(Document document) {
		try {
			JAXBContext jaxbContext = createJaxbContext(new Class[]{ResponseType.class, SignatureType.class, EncryptedDataType.class});
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			@SuppressWarnings("unchecked")
			JAXBElement<ResponseType> el = (JAXBElement<ResponseType>) jaxbUnmarshaller.unmarshal(document);
			return el.getValue();
		}catch(Exception e) {
			throw new IllegalArgumentException("The Document file is invalid.", e);
		}
	}
	
	/**
	 * Dom Document to JAXB AuthnRequestType
	 * @param document
	 * @return
	 */
	public static AuthnRequestType domToAuthnRequestType(Document document) {
		try {
			JAXBContext jaxbContext = createJaxbContext(new Class[]{AuthnRequestType.class, SignatureType.class});
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			@SuppressWarnings("unchecked")
			JAXBElement<AuthnRequestType> el = (JAXBElement<AuthnRequestType>) jaxbUnmarshaller.unmarshal(document);
			return el.getValue();
		}catch(Exception e) {
			throw new IllegalArgumentException("The Document file is invalid.", e);
		}
	}
	
	/**
	 * JAXB ResponseType to DOM Document
	 * @param response
	 * @return
	 */
	public static Document responseTypeToDom(ResponseType response) {
		try {
		    // Create the Document from JAXB Object
	        JAXBContext jc = XmlTools.createJaxbContext(new Class[]{ResponseType.class, UserIdentity.class, Joining.class, KeyValue.class, UsingRight.class});
	        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	        dbf.setNamespaceAware(true);
	        Document document = dbf.newDocumentBuilder().newDocument();
	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapper());
	        marshaller.marshal(new ObjectFactory().createResponse(response), document);
			
	        //Need to mark the ID attribute of <assertion> Element as an Id Attribute
			NodeList list = document.getDocumentElement().getElementsByTagNameNS("urn:oasis:names:tc:SAML:2.0:assertion", "Assertion");
			if (list != null && list.getLength() > 1) {
				throw new IllegalArgumentException("Bad xml document need one Assertion block");
			} else if (list != null && list.getLength()==1) {
				Element assertionElement = (Element) list.item(0);
				assertionElement.setIdAttribute("ID", true);
			}
			return document;
		} catch (Exception e) {
			throw new TechnicalException("Impossible to create Reponse Document.",e);
		}
	}
	
	/**
	 * JAXB ResponseType to text format.
	 * @param response
	 * @param pretty
	 * @return
	 */
	public static String responseTypeToString(ResponseType response, boolean pretty) {
		try {
			JAXBContext jaxbContext = createJaxbContext(new Class[]{ResponseType.class, UserIdentity.class, Joining.class, KeyValue.class, UsingRight.class});
			Marshaller jaxbmarshaller = jaxbContext.createMarshaller();
			if (pretty) {
				jaxbmarshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapper());
				jaxbmarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			}
			StringWriter writer = new StringWriter();
			JAXBElement<ResponseType> jaxb = new gentypes.saml.protocol.v20.ObjectFactory().createResponse(response);
			jaxbmarshaller.marshal(jaxb, writer);
			return writer.getBuffer().toString();
		}catch(Exception e) {
			throw new IllegalArgumentException("The Document file is invalid.", e);
		}
	}
	
	/**
	 * JAXB AuthnRequestType to DOM Document
	 * @param authnRequest
	 * @return
	 */
	public static Document authnRequestTypeToDom(AuthnRequestType authnRequest) {
		try {
		    // Create the Document from JAXB Object
	        JAXBContext jc = createJaxbContext(new Class[]{AuthnRequestType.class, SignatureType.class});
	        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	        dbf.setNamespaceAware(true);
	        Document document = dbf.newDocumentBuilder().newDocument();
	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapper());
	        marshaller.marshal(new gentypes.saml.protocol.v20.ObjectFactory().createAuthnRequest(authnRequest), document);
			return document;
		} catch (Exception e) {
			throw new TechnicalException("Impossible to create Request Document.",e);
		}
	}
	
	/**
	 * JAXB AuthnRequestType to text format
	 * @param authnRequest
	 * @return
	 */
	public static String authnRequestTypeToString(AuthnRequestType authnRequest) {
		try {
			JAXBContext jc = createJaxbContext(new Class[]{AuthnRequestType.class, SignatureType.class});
	        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	        dbf.setNamespaceAware(true);
	        Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapper());
	        StringWriter sw = new StringWriter();
	        marshaller.marshal(new gentypes.saml.protocol.v20.ObjectFactory().createAuthnRequest(authnRequest), sw);
	        return sw.getBuffer().toString();
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	/**
	 * Metadata in text format to JAXB EntityDescriptorType
	 * @param xml
	 * @return
	 */
	public static EntityDescriptorType stringToEntityDescriptorType(String xml) {
		try {
			JAXBContext jaxbContext = createJaxbContext(new Class[]{EntityDescriptorType.class, SignatureType.class});
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			@SuppressWarnings("unchecked")
			JAXBElement<EntityDescriptorType> el = (JAXBElement<EntityDescriptorType>) jaxbUnmarshaller.unmarshal(new StringReader(xml));
			return el.getValue();
		}catch(Exception e) {
			throw new IllegalArgumentException("The Metadata file is invalid.", e);
		}
	}
	
	/**
	 * <AuthnRequest> in text format to JAXB AuthnRequestType 
	 * @param xml
	 * @return
	 */
	public static AuthnRequestType stringToAuthnRequestType(String xml) {
		try {
			JAXBContext jaxbContext = createJaxbContext(new Class[]{AuthnRequestType.class, SignatureType.class});
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			@SuppressWarnings("unchecked")
			JAXBElement<AuthnRequestType> el = (JAXBElement<AuthnRequestType>) jaxbUnmarshaller.unmarshal(new StringReader(xml));
			return el.getValue();
		}catch(Exception e) {
			throw new IllegalArgumentException("The Metadata file is invalid.", e);
		}
	}
	
	/**
	 * Read a xml file on filesystem and return its content. This implementation is encoding aware.
	 * @param p
	 * @return
	 */
	public static String pathWithXmlToString(Path p) {
		try (FileInputStream inputStream = new FileInputStream( p.toFile() )) {
			XMLStreamReader xmlStreamReader = XMLInputFactory.newInstance().createXMLStreamReader(inputStream);
			String encodingFromXMLDeclaration = xmlStreamReader.getCharacterEncodingScheme(); 
			if (encodingFromXMLDeclaration==null||encodingFromXMLDeclaration.length()==0) {
				encodingFromXMLDeclaration = "UTF-8";
			}
			return new String(Files.readAllBytes(p), encodingFromXMLDeclaration);
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	/**
	 * Central method to create a JAXBContext
	 * SAF works with JAXB RI wich is forced with the coded below
	 * @param classes
	 * @return
	 * @throws JAXBException
	 */
	public static JAXBContext createJaxbContext(Class<?>[] classes) throws JAXBException {
		//Generic code : return JAXBContext.newInstance(classes);
		return ContextFactory.createContext(classes,  null);
	}
	
	/**
	 * Transform an entityId (urn) to a key which is correct to create a path in a file system.
	 * @param entityId
	 * @return
	 */
	public static String entityIdToKey(String entityId) {
		return entityId.replaceAll("[^a-zA-Z0-9.-]", "_");
	}
}
