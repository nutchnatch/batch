package com.bpc.sesame.saf.util;

import java.io.IOException;
import java.security.cert.X509Certificate;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.model.CertificatePK;

/**
 * Use to transform request from reverse proxies where the certificate is in a header.
 * With this filter enabled, the servlet behind this filter could use this kind of code :
 * request.isSecure(); //will return true
 * request.getAttribute("javax.servlet.request.X509Certificate"); //will return an array with the client certificate in first position.
 */
@WebFilter(urlPatterns={"/redirect/sso/*","/post/sso/*","/soap/sso/*"})
public class HttpsNormalizeFilter implements Filter {
	
	private static final Logger log = LoggerFactory.getLogger(HttpsNormalizeFilter.class);
	
	private static final String ATTR_SSL_CERTIFICATE = "javax.servlet.request.X509Certificate";
	private static final Pattern HEADER_TO_CERTIFICATE = Pattern.compile("(?! CERTIFICATE)(?= ) ");

	
	@Value("${sesame.saf.https-normalize.enable}")
	private boolean filterEnable;
	
	@Value("${sesame.saf.https-normalize.certificate.header.name}")
	private String certificateHeaderName;
	
	@Value("${sesame.saf.https-normalize.tls-ckeck.header.name}")
	private String tlsHeaderName;
	
	@Value("${sesame.saf.https-normalize.tls-ckeck.header.value}")
	private String tlsHeaderValue;
	
	@Autowired
	private ApplicationContext context;

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, filterConfig.getServletContext());
		log.info("HttpsNormalizeFilter enabled == {}", filterEnable);
	}

	/**
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
        HttpServletRequest httpReq = (HttpServletRequest) request;
        HttpServletResponse httpResp = (HttpServletResponse) response;

		if (filterEnable) {
			//The TLS-check header is a header which is sent by some reverse proxy to declare that the TLS authent is successful
			//Note : all the reverse proxies are not able to sent it, so this verification should be optional.
			// > This Check is disable when this header is empty in the configuration
			boolean disableTLSCheckHeaderVerification = (tlsHeaderName == null) || tlsHeaderName.isEmpty();

			// The check should be disable or OK
			boolean disableOrOK = disableTLSCheckHeaderVerification || tlsHeaderValue.equalsIgnoreCase(httpReq.getHeader(tlsHeaderName));

			if (disableOrOK) {
				log.debug("This request will be managed by HttpsNormalizeFilter.");
				httpReq = new HttpsRequest(httpReq);
			}
		}
		
        chain.doFilter(httpReq, httpResp);
	}

	@Override
	public void destroy() {
		
	}
	
	class HttpsRequest extends HttpServletRequestWrapper {

		public HttpsRequest(HttpServletRequest request) {
			super(request);
			//Convert the certificate as Header to a certificate as attributes
			String certificateHeaderValue = request.getHeader(certificateHeaderName);
			if (certificateHeaderValue == null || certificateHeaderValue.length() == 0) {
				throw new TechnicalException("Impossible to found the certificate in the request headers. Check the configuration.");
			}
			String clientCertAsPem = HEADER_TO_CERTIFICATE.matcher(certificateHeaderValue).replaceAll("\r\n");
			CertificatePK certPK = CryptographicTools.pemStringToCertificatePK(clientCertAsPem, null);
			
			if (certPK==null || certPK.getCertificate()==null) {
				throw new TechnicalException("Cannot extract the client certificate from request header.");
			}
			
			request.setAttribute(ATTR_SSL_CERTIFICATE, new X509Certificate[]{certPK.getCertificate()});
		}
		
		@Override
	    public String getScheme()
	    {
	        return "https";
	    }

	    @Override
	    public boolean isSecure()
	    {
	        return true;
	    }

	    @Override
	    public StringBuffer getRequestURL()
	    {
	        StringBuffer tmp = new StringBuffer(super.getRequestURL());
	        if (tmp.indexOf("http://") == 0)
	        {
	            tmp.insert(4, 's');
	        }
	        return tmp;
	    }
		
	}
}
