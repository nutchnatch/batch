package com.bpc.sesame.saf.util;

import java.security.Key;
import java.security.PublicKey;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.apache.xml.security.encryption.EncryptedData;
import org.apache.xml.security.encryption.EncryptedKey;
import org.apache.xml.security.encryption.XMLCipher;
import org.apache.xml.security.keys.KeyInfo;
import org.apache.xml.security.utils.Constants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.bpc.sesame.saf.exception.ConfigurationException;
import com.bpc.sesame.saf.exception.TechnicalException;

/**
 * Use the project http://santuario.apache.org/ to encrypt xml document
 */
public class XmlDigitalEncrypter {

	static {
		org.apache.xml.security.Init.init();
	}
	
	public static XmlDigitalEncrypter getInstance(String symetricAlgo, String AsymmetricAlgo, String digestMethod) {
		return new XmlDigitalEncrypter(symetricAlgo, AsymmetricAlgo, digestMethod);
	}
	
	private String symmetricAlgo, asymmetricAlgo, digestMethod;
	
	private XmlDigitalEncrypter(String symmetricAlgo, String asymmetricAlgo, String digestMethod) {
		this.symmetricAlgo = symmetricAlgo;
		this.asymmetricAlgo = asymmetricAlgo;
		this.digestMethod = digestMethod;
	}

	private SecretKey generateDataEncryptionKey()  {
		int size = 0;
		if (XMLCipher.AES_128.equals(symmetricAlgo)) {
			size=128;
		} else if (XMLCipher.AES_192.equals(symmetricAlgo)) {
			size=192;
		} else if (XMLCipher.AES_256.equals(symmetricAlgo)) {
			size=256;
		} else {
			throw new ConfigurationException("Sesame SAF manage only AES"); 
		}
		
		try {
			String jceAlgorithmName = "AES";
			KeyGenerator keyGenerator = KeyGenerator.getInstance(jceAlgorithmName);
			keyGenerator.init(size);
			return keyGenerator.generateKey();
		} catch (Exception e) {
			throw new TechnicalException("Error when generating a symmetric AES key.",e);
		}
	}

	private void encryptElementInDocument(Document document, Element element, PublicKey publicKey) throws Exception {
		
		//key encryption
		XMLCipher keyCipher = XMLCipher.getInstance(asymmetricAlgo, null, "".equals(digestMethod)?null:digestMethod);
		keyCipher.init(XMLCipher.WRAP_MODE, publicKey);
		
		Key symmetricKey  = generateDataEncryptionKey();
		EncryptedKey encryptedKey = keyCipher.encryptKey(document, symmetricKey);

		//xml encryption
		XMLCipher xmlCipher = XMLCipher.getInstance(symmetricAlgo);
		xmlCipher.init(XMLCipher.ENCRYPT_MODE, symmetricKey);

		EncryptedData encryptedData = xmlCipher.getEncryptedData();
		KeyInfo keyInfo = new KeyInfo(document);
		keyInfo.add(encryptedKey);
		encryptedData.setKeyInfo(keyInfo);
		
		xmlCipher.doFinal(document, element, false);
	}
	
	/**
	 * Encrypt an Assertion in a <Response> DOM Document
	 * @param request
	 * @param response
	 * @param publicKey
	 */
	public void encryptAssertion(Document response, PublicKey publicKey)  {
		
		//Search the Assertion in response
		NodeList list = response.getElementsByTagNameNS("urn:oasis:names:tc:SAML:2.0:assertion", "Assertion");
		if (list == null || list.getLength() != 1) {
			throw new IllegalArgumentException("Bad xml document need one Assertion block");
		}
		Element assertion = (Element) list.item(0);
		
		//The 2 following lines are necessary for opensaml bug decryption 
		//which try to validate the assertion without the rest of document
		//So the Element must be valid alone.
		assertion.setAttributeNS(Constants.NamespaceSpecNS, "xmlns:saml", "urn:oasis:names:tc:SAML:2.0:assertion");
		assertion.setAttributeNS(Constants.NamespaceSpecNS, "xmlns:ds", "http://www.w3.org/2000/09/xmldsig#");

		//Encryption
		try {
			encryptElementInDocument(response, assertion, publicKey);
		} catch (Exception e) {
			throw new TechnicalException("Error during encryption of the Assertion.", e);
		}
		
		//Move the EncryptedData just created into a new EncryptedAssertion Element
		list = response.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "EncryptedData");
		if (list == null || list.getLength() != 1) {
			throw new IllegalArgumentException("Bad encoding no EncryptedData where found.");
		}
		Element encryptedData = (Element) list.item(0);
		encryptedData.getParentNode().removeChild(encryptedData);
		
		Element encryptedAssertion = response.createElementNS("urn:oasis:names:tc:SAML:2.0:assertion", "saml:EncryptedAssertion");
		response.getDocumentElement().appendChild(encryptedAssertion);
		encryptedAssertion.appendChild(encryptedData);
	}
}
