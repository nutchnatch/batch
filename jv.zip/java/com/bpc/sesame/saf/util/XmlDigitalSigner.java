package com.bpc.sesame.saf.util;

import java.security.InvalidAlgorithmParameterException;
import java.security.KeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Signature;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.XMLValidateContext;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.bpc.sesame.saf.exception.RequesterException;
import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.model.CertificatePK;

/**
 * This helper class, part of the SAML-based Single Sign-On Reference Tool,
 * serves to digitally sign XML files, given the contents of the XML file, and a
 * pair of public and private keys. The file is signed as per the specifications
 * defined by SAML 2.0.
 */
public class XmlDigitalSigner {
	
	private static final Logger logger = LoggerFactory.getLogger(XmlDigitalSigner.class);

	//With JDK
	//private static final String JSR_105_PROVIDER_CLASS_NAME = "org.jcp.xml.dsig.internal.dom.XMLDSigRI";
	//With Santuario
	private static final String JSR_105_PROVIDER_CLASS_NAME = "org.apache.jcp.xml.dsig.internal.dom.XMLDSigRI";
	private static Provider JSR_105_PROVIDER = null;

	private static final Map<String,String> algoSupported = new HashMap<String, String>();
	private static final Map<String,String> algoDeprecated = new HashMap<String, String>();
	static {
		algoSupported.put("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256", "SHA256withRSA");
		algoSupported.put("http://www.w3.org/2001/04/xmldsig-more#rsa-sha512", "SHA512withRSA");
		
		algoDeprecated.put("http://www.w3.org/2000/09/xmldsig#rsa-sha1", "SHA1withRSA");
		
		try {
			JSR_105_PROVIDER = (Provider) Class.forName(JSR_105_PROVIDER_CLASS_NAME).newInstance();
		} catch (Exception e) {
			throw new TechnicalException("Impossible to load JSR_105_PROVIDER", e);
		}
	}
	
	
	public static XmlDigitalSigner getInstance() {
		return new XmlDigitalSigner();
	}
	
	public static XmlDigitalSigner getInstance(String signatureAlgo) {
		return new XmlDigitalSigner(signatureAlgo, false);
	}
	public static XmlDigitalSigner getInstance(String signatureAlgo, boolean authorizeDeprecated) {
		return new XmlDigitalSigner(signatureAlgo, authorizeDeprecated);
	}
	
	private String signAlgo;
	private String javaAlgo;
	
	private XmlDigitalSigner() {
		
	}

	private XmlDigitalSigner(String signatureAlgo, boolean authorizeDeprecated) {
		this.signAlgo = signatureAlgo;
		this.javaAlgo = algoSupported.get(signAlgo);
		if (this.javaAlgo==null && authorizeDeprecated) {
			this.javaAlgo = algoDeprecated.get(signAlgo);
		}
		if (javaAlgo==null) {
			logger.error("List of supported algorithm for the requests signatures : " + Arrays.toString(algoSupported.keySet().toArray(new String[algoSupported.size()])));
			throw new RequesterException("Unknown Algorithm for request signature : " + signAlgo);
		}
	}
	
    /**
     * Sign the specified context element, and insert the signature <i>right
     * before</i> the specified sibling.
     * @throws KeyException 
     * @throws ClassNotFoundException 
     * @throws IllegalAccessException 
     * @throws InstantiationException 
     */
    private void sign(Element context, PrivateKey privateKey, PublicKey publicKey, Element nextSibling)
    throws MarshalException, XMLSignatureException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InstantiationException, IllegalAccessException, ClassNotFoundException {
    	
    	XMLSignatureFactory signatureFactory = XMLSignatureFactory.getInstance("DOM", JSR_105_PROVIDER);
		
        /* Initialize the basics... */
        CanonicalizationMethod canonicalizationMethod = signatureFactory.newCanonicalizationMethod(CanonicalizationMethod.EXCLUSIVE, (C14NMethodParameterSpec) null);

        Transform transform1 = signatureFactory.newTransform(Transform.ENVELOPED, (TransformParameterSpec) null);
        Transform transform2 = signatureFactory.newTransform(CanonicalizationMethod.EXCLUSIVE, (TransformParameterSpec) null);
        List<Transform> transforms = Arrays.asList(transform1, transform2);

        SignatureMethod signatureMethod = signatureFactory.newSignatureMethod(signAlgo, null);

        DigestMethod digestMethod = signatureFactory.newDigestMethod(DigestMethod.SHA1, null);

        /* Create a DOMSignContext, specify the RSA PrivateKey and samlpResponse (root element) */
        DOMSignContext domSignContext = null;
        if (nextSibling == null) {
        	domSignContext = new DOMSignContext(privateKey, context);
        } else {
        	domSignContext = new DOMSignContext(privateKey, context, nextSibling);
        }
        domSignContext.setDefaultNamespacePrefix("ds");

        /* If this is the "root" element we're signing, no ID */
        String id = context.equals(context.getOwnerDocument().getDocumentElement()) ?
                              "" : "#" + context.getAttribute("ID");

        /* Create the XMLSignature and sign the enveloped signature */
        Reference reference = signatureFactory.newReference(id, digestMethod, transforms, null, null);
        SignedInfo signedInfo = signatureFactory.newSignedInfo(canonicalizationMethod, signatureMethod, Collections.singletonList(reference));
        XMLSignature signature = signatureFactory.newXMLSignature(signedInfo, null);
        signature.sign(domSignContext);

    }
    
    /**
     * For the POST and SOAP Bindings, verify a signature in a Document if the signature exists
     * @param document
     * @param publicKey
     * @return
     */
    public boolean verifySignatureInDocument(Document document, PublicKey publicKey) {
    	try {
	    	NodeList nl = document.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
	    	if (nl.getLength() > 1) {
	    		//security reason
	    		throw new RequesterException("Multiple signatures founds in this message.");
	    	}
	    	if (nl.getLength() == 0) {
	    		logger.info("Cannot find Signature element");
    			throw new RequesterException("No signature found in this message.");
	    	}
	    	
	    	Element element = (Element) nl.item(0).getParentNode();
	    	//Verification The signature must be enveloped : the parent must have the ID attribute
	    	if (element.getAttributeNode("ID")==null) {
	    		throw new RequesterException("Signed element must have an ID attribute.");
	    	}
	    	element.setIdAttribute("ID", true);
	    	
	    	//Security checks
	    	if (element.getLocalName().equals("Assertion")) {
	    		if (element.getParentNode() != document.getDocumentElement()) {
	    			throw new RequesterException("The signed Assertion must be a child of parent node.");
	    		}
	    	} else if (element.getLocalName().equals("AuthnRequest")) {
	    		if (element != document.getDocumentElement()) {
	    			throw new RequesterException("The signed AuthnRequest must be the parent node.");
	    		}
	    	} else {
	    		throw new RequesterException("This signed element '"+element.getLocalName()+"' is unknown.");
	    	}
	
	    	
	    	
	    	// Create a DOMValidateContext and specify a KeySelector
	    	// and document context.
	    	XMLValidateContext valContext = new DOMValidateContext(publicKey, nl.item(0));
	
	    	// Unmarshal the XMLSignature.
	    	XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM", JSR_105_PROVIDER);
	    	XMLSignature signature = fac.unmarshalXMLSignature(valContext);
	
	    	String algoOfDocument = signature.getSignedInfo().getSignatureMethod().getAlgorithm();
	    	if (!algoSupported.containsKey(algoOfDocument)) {
				logger.error("List of supported algorithm for the requests signatures : " + Arrays.toString(algoSupported.keySet().toArray(new String[algoSupported.size()])));
				throw new RequesterException("Unknown Algorithm for request signature : " + algoOfDocument);
	    	}
	    	
	    	// Validate the XMLSignature.
	    	return signature.validate(valContext);
    	} catch (RequesterException e) {
    		throw e;
    	} catch (Exception e) {
    		throw new TechnicalException(e);
    	}
    }
    
	/**
	 * For the POST and SOAP Bindings, create a signature of the assertion in the assertion.
	 */
	public void signAssertionInDocument(Document response, CertificatePK cert) {
		
		PublicKey publicKey = cert.getCertificate().getPublicKey();
		PrivateKey privateKey = cert.getPrivateKey();

		NodeList list = response.getElementsByTagNameNS("urn:oasis:names:tc:SAML:2.0:assertion", "Assertion");
		if (list == null || list.getLength() != 1) {
			throw new IllegalArgumentException("Bad xml document need one Assertion block");
		}
		
		NodeList nodeList2 = response.getElementsByTagNameNS("urn:oasis:names:tc:SAML:2.0:assertion", "Subject");
		if (nodeList2.getLength() != 1) {
			throw new IllegalArgumentException("Need a Subject in Assertion.");
		}
		Element nextSibling = (Element) nodeList2.item(0);
		
		try {
			sign((Element)list.item(0), privateKey, publicKey, nextSibling);
		} catch (Exception e) {
			throw new TechnicalException("Impossible to sign the SAML Response.", e);
		}
	}

	/**
	 * For the Redirect Binding, create a signature for the request 
	 * @param signAlgo
	 * @param textToSigned
	 * @param privateKey
	 * @return
	 */
	public byte[] createSignatureFromText(String textToSigned, PrivateKey privateKey) {
		try {
			Signature sig = Signature.getInstance(javaAlgo, new BouncyCastleProvider());
			sig.initSign(privateKey);
			sig.update(textToSigned.getBytes("UTF-8"));
			return sig.sign();
		} catch (Exception e) {
			throw new TechnicalException("Error when check the signature : ", e);
		}
	}
	
	/**
	 * For the Redirect Binding, verify the signature of the request
	 * @param signAlgo
	 * @param textWhichIsSigned
	 * @param signatureValue
	 * @param publicKey
	 * @return
	 */
	public boolean verifySignatureFromText(String textWhichIsSigned, byte[] signatureValue, PublicKey publicKey) {
		try {
			Signature sig = Signature.getInstance(javaAlgo, new BouncyCastleProvider());
			sig.initVerify(publicKey);
			sig.update(textWhichIsSigned.getBytes("UTF-8"));
			return sig.verify(signatureValue);
		} catch (Exception e) {
			throw new TechnicalException("Error when check the signature : ", e);
		}
	}

	/**
	 * For the Post and SOAP binding, create a signature of the request in the request.
	 * @param requestDocument
	 * @param cert
	 */
	public void signAuthnRequestInDocument(Document requestDocument, CertificatePK cert) {
		PublicKey publicKey = cert.getCertificate().getPublicKey();
		PrivateKey privateKey = cert.getPrivateKey();

		NodeList list = requestDocument.getElementsByTagNameNS("urn:oasis:names:tc:SAML:2.0:protocol", "AuthnRequest");
		if (list == null || list.getLength() != 1) {
			throw new IllegalArgumentException("Bad xml document need one AuthnRequest element");
		}
		
		try {
			sign((Element) list.item(0), privateKey, publicKey, null);
		} catch (Exception e) {
			throw new TechnicalException("Impossible to sign the SAML Request.", e);
		}
		
	}
}
