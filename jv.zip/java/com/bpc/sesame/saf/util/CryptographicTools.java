package com.bpc.sesame.saf.util;

import static com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel.HIGH;
import static com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel.MEDIUM;
import static com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel.NO_AUTH;
import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;
import gentypes.saml.metadata.v20.KeyDescriptorType;
import gentypes.saml.metadata.v20.KeyTypes;
import gentypes.saml.metadata.v20.RoleDescriptorType;
import gentypes.xmldsig.X509DataType;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509CRLEntry;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.xml.bind.JAXBElement;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dom.DOMStructure;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.codec.binary.Base64OutputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.CRLNumber;
import org.bouncycastle.asn1.x509.CRLReason;
import org.bouncycastle.asn1.x509.ExtendedKeyUsage;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.KeyPurposeId;
import org.bouncycastle.cert.X509CRLHolder;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.X509v2CRLBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CRLConverter;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509ExtensionUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMDecryptorProvider;
import org.bouncycastle.openssl.PEMEncryptedKeyPair;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.openssl.jcajce.JcaPEMWriter;
import org.bouncycastle.openssl.jcajce.JcePEMDecryptorProviderBuilder;
import org.bouncycastle.openssl.jcajce.JcePEMEncryptorBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel;
import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.model.CertificatePK;
import com.bpc.sesame.safadmin.api.IdentityProviderTasks;

/**
 * Multiple tools around cryptography. This tools massively use Bouncycastle.
 * @author 483838
 */
public class CryptographicTools {
	
	private CryptographicTools() {
	}
	
	private static final Logger log = LoggerFactory.getLogger(CryptographicTools.class);
	
	public static final Provider B = new BouncyCastleProvider();
	
	public static CertificatePK certificateForIDP(BigInteger serialNumber, java.sql.Date notBefore, java.sql.Date notAfter,
			String signatureAlgorithm, int keySize) {
		com.bpc.sesame.safadmin.api.CertificatePK certPkApi = null;
		certPkApi = IdentityProviderTasks.certificateForIDP(serialNumber, notBefore, notAfter, signatureAlgorithm, keySize);
		return new CertificatePK(certPkApi.getCertificate(), certPkApi.getPrivateKey());
	}

	/**
	 * Create a X509 CRL Object with bouncycastle
	 * @param ca
	 * @param existingEntries
	 * @param newEntries
	 * @param signatureAlgorithm
	 * @param currentCRLDate
	 * @param update
	 * @return
	 */
	public static X509CRL crl(CertificatePK ca, List<X509CRLEntry> existingEntries, List<CertificatePK> newEntries, String signatureAlgorithm, Date currentCRLDate, Date update) {
		try {
			X500Name issuerName = new X500Name(ca.getCertificate().getSubjectDN().getName());
			X509v2CRLBuilder crlBuilder = new X509v2CRLBuilder(issuerName, currentCRLDate);
			
			if (existingEntries!=null) {
				for (X509CRLEntry entry : existingEntries) {
					crlBuilder.addCRLEntry(entry.getSerialNumber(), entry.getRevocationDate(), CRLReason.keyCompromise);
				}
			}
			
			if (newEntries!=null) {
				for (CertificatePK cert : newEntries) {
					crlBuilder.addCRLEntry(cert.getCertificate().getSerialNumber(), currentCRLDate, CRLReason.keyCompromise);
				}
			}

			crlBuilder.setNextUpdate(update);
			
			crlBuilder.addExtension(Extension.authorityKeyIdentifier, false, new JcaX509ExtensionUtils().createAuthorityKeyIdentifier(ca.getCertificate()));
			crlBuilder.addExtension(Extension.cRLNumber,false, new CRLNumber(BigInteger.valueOf(1)));
			
			JcaContentSignerBuilder builder = new JcaContentSignerBuilder(signatureAlgorithm).setProvider(new BouncyCastleProvider());
			ContentSigner signer = builder.build(ca.getPrivateKey());
			X509CRLHolder crlHolder = crlBuilder.build(signer);
			JcaX509CRLConverter converter = new JcaX509CRLConverter().setProvider(new BouncyCastleProvider());
			X509CRL crl = converter.getCRL(crlHolder);
			return crl;
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	/**
	 * Transform an object (certificate/crl) to its pem version
	 * @param o
	 * @return
	 */
	public static String objectToPemString(Object o) {
		StringWriter sw = new StringWriter();
	    try (JcaPEMWriter pw = new JcaPEMWriter(sw)) {
	    	pw.writeObject(o);
	    } catch (IOException e) {
			throw new TechnicalException("Impossible to create String from this object of class " + o.getClass(), e);
		}
	    return sw.getBuffer().toString();
	}
	
	/**
	 * Transform a CertificatePK to its pem version the certificate + private key are concatenate in the string
	 * @param cert
	 * @param passphrase
	 * @return
	 */
	public static String certificatePKToPemString(CertificatePK cert, char[] passphrase) {
		StringWriter sw = new StringWriter();
		try (JcaPEMWriter pw = new JcaPEMWriter(sw)) {
			pw.writeObject(cert.getCertificate());
			JcePEMEncryptorBuilder builder = new JcePEMEncryptorBuilder("AES-256-CFB").setProvider(new BouncyCastleProvider()).setSecureRandom(new SecureRandom());
			pw.writeObject(cert.getPrivateKey(), builder.build(passphrase));
	    } catch (Exception e) {
			throw new TechnicalException("Impossible to create String from this CertificatePK.", e);
		}
		return sw.getBuffer().toString();
	}
	
	private static PrivateKey toPrivateKey(PEMEncryptedKeyPair encryptedKeyPair, char[] passphrase) {
		try {
			JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider(new BouncyCastleProvider());
			PEMDecryptorProvider decryptionProv = new JcePEMDecryptorProviderBuilder().setProvider(new BouncyCastleProvider()).build(passphrase);
			PEMKeyPair decryptedKeyPair = encryptedKeyPair.decryptKeyPair(decryptionProv);
			return converter.getPrivateKey(decryptedKeyPair.getPrivateKeyInfo());
		} catch (Exception e) {
			throw new TechnicalException("Impossible to create PrivateKey from content.", e);
		}
	}
	
	/**
	 * Return a CertificatePK based on a pem String. <br>
	 * if the pem doesn't contains private key the object doesn't contains private key. <br>
	 * if the pem doesn't contains certificate the object doesn't contains certificate.
	 * 
	 * @param content
	 * @param passphrase
	 * @return
	 */
	public static CertificatePK pemStringToCertificatePK(String content, char[] passphrase) {
		PrivateKey privateKey = null;
		X509Certificate certificate = null;
		try (PEMParser parser = new PEMParser(new StringReader(content))) {
			Object o = null;
			while((o = parser.readObject())!=null) {
				if (o instanceof PEMEncryptedKeyPair && passphrase!=null) {
					privateKey = toPrivateKey((PEMEncryptedKeyPair) o, passphrase);
				}
				if (o instanceof X509CertificateHolder) {
					certificate = toCertificate((X509CertificateHolder) o);
				}
			}
		} catch (IOException e) {
			throw new TechnicalException("Impossible to create object from this content.", e);
		}
		return new CertificatePK(certificate, privateKey);
	}
	
	/**
	 * PEM content with private key without passphrase to a PrivateKey
	 * @param content
	 * @return
	 */
	public static PrivateKey pemStringToPrivateKey(String content) {
		PrivateKey privateKey = null;
		try (PEMParser parser = new PEMParser(new StringReader(content))) {
			Object o = null;
			while ((o = parser.readObject()) != null) {
				if (o instanceof PrivateKeyInfo) {
					JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider(new BouncyCastleProvider());
					privateKey = converter.getPrivateKey((PrivateKeyInfo) o);
					break;
				}
			}
		} catch (IOException e) {
			throw new TechnicalException("Impossible to create privateKey from this pem content.", e);
		}
		if (privateKey==null) {
			throw new TechnicalException("Impossible to found a privateKey in this pem content.");
		}
		return privateKey;
	}
	
	private static X509Certificate toCertificate(X509CertificateHolder holder) {
		try {
			JcaX509CertificateConverter converter = new JcaX509CertificateConverter().setProvider(new BouncyCastleProvider());
			return converter.getCertificate(holder);
		} catch (Exception e) {
			throw new TechnicalException("Impossible to create PrivateKey from content.", e);
		}
	}
	
	/**
	 * Extract a Certificate from a Saml Metadata file
	 * @param path
	 * @param forSigning
	 * @return
	 */
	public static X509Certificate extractCertificateFromMetadataFile(Path path, String type) {

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setNamespaceAware(true);

		Node node = null;

		if ("signing".equals(type)) {
			type = "[@use='signing']";
		} else if ("encryption".equals(type)) {
			type = "[@use='encryption']";
		} else {
			type = "";
		}

		try {
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(path.toFile());
			XPath xPath = XPathFactory.newInstance().newXPath();
			node = (Node) xPath.evaluate("//*[local-name()='KeyDescriptor']"+type+"/*[local-name()='KeyInfo']",
					doc.getDocumentElement(), XPathConstants.NODE);
		} catch (Exception e) {
			throw new TechnicalException(e);
		}

		XMLStructure keyInfoStructure = new DOMStructure(node);
		KeyInfoFactory kif = KeyInfoFactory.getInstance("DOM");
		javax.xml.crypto.dsig.keyinfo.KeyInfo keyInfo = null;
		try {
			keyInfo = kif.unmarshalKeyInfo(keyInfoStructure);
		} catch (MarshalException e) {
			throw new TechnicalException(e);
		}

		X509Data x509Data = null;
		for (Object data : keyInfo.getContent()) {
			if (data instanceof X509Data) {
				x509Data = (X509Data) data;
				break;
			}
		}

		if (x509Data == null)
			return null;

		X509Certificate certificate = null;
		for (Object content : x509Data.getContent()) {
			if (content instanceof X509Certificate) {
				certificate = (X509Certificate) content;
				break;
			}
		}

		return certificate;
	}
	
	/**
	 * Extract a Certificate from a Metadata JAXB object : RoleDescriptorType
	 * @param roleDescriptorType
	 * @param keyTypes
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<X509Certificate> extractCertificateFromEntityDescriptorType(RoleDescriptorType roleDescriptorType, KeyTypes keyTypes) {
		
		List<X509Certificate> certificates = new ArrayList<>();
		
		for (KeyDescriptorType keyDescriptorType : roleDescriptorType.getKeyDescriptor()) {
			if (keyDescriptorType.getUse() != keyTypes) {
				continue;
			}
			
			for (Object content : keyDescriptorType.getKeyInfo().getContent()) {
				if (content instanceof JAXBElement<?>) {
					JAXBElement<X509DataType> dataType = (JAXBElement<X509DataType>) content;
					for (Object subContent : dataType.getValue().getX509IssuerSerialOrX509SKIOrX509SubjectName()) {
						if (subContent instanceof JAXBElement<?>) {
							JAXBElement<byte[]> bytes = (JAXBElement<byte[]>) subContent;
							certificates.add(extractCertificateFromByteArray(bytes.getValue()));
						}
					}
				}
			}
			

		}
		return certificates;
	}
	
	/**
	 * Extract X509 from a byte array
	 * @param bytes
	 * @return
	 */
	public static X509Certificate extractCertificateFromByteArray(byte[] bytes) {
		try {
			CertificateFactory certFactory = CertificateFactory.getInstance("X.509", B);
			InputStream in = new ByteArrayInputStream(bytes);
			X509Certificate cert = (X509Certificate)certFactory.generateCertificate(in);
			if (cert==null) {
				throw new TechnicalException("Impossible to extract the certificate from the bytes array.");
			}
			return cert;
		} catch(Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	/**
	 * Extract X509 certificate from a binary certificate in the classpath
	 * @param path
	 * @return
	 * @throws CertificateException
	 */
	public static X509Certificate extractCertificateFromClasspath(String path) throws CertificateException {
		InputStream fis = Thread.currentThread().getContextClassLoader().getResourceAsStream(path);
		CertificateFactory cf = CertificateFactory.getInstance("X.509");
		Collection<?> c = cf.generateCertificates(fis);
		X509Certificate certificate = (X509Certificate) c.iterator().next();
		return certificate;
	}
	
	/**
	 * Extract the DNSName from a certificate, in BNP DNSName == uid
	 * @param certificate
	 * @return
	 */
	public static String extractDNSNameFromCertificate(X509Certificate certificate) {

		String oid = Extension.subjectAlternativeName.getId();
		byte[] extensionValue = certificate.getExtensionValue(oid);
		
		if (extensionValue == null) {
			throw new IllegalArgumentException("An incorrect certificate : No SubjectAlternativeName");
		}
		
		ASN1OctetString akiOc = ASN1OctetString.getInstance(extensionValue);
		GeneralNames gn = GeneralNames.getInstance(akiOc.getOctets());

		if (gn == null ||gn.getNames() == null) {
			throw new IllegalArgumentException("An incorrect certificate : Null or Invalid GeneralNames");
		}
		
		for (int i = 0; i < gn.getNames().length; i++) {
			GeneralName name = gn.getNames()[i];
			if (name.getTagNo() == GeneralName.dNSName) {
				return name.getName().toString();
			}
		}
		throw new IllegalArgumentException("An incorrect certificate : No DNSName found in SubjectAlternativeName.");
	}

	
	/**
	 * Extract the AuthLevel from a certificate
	 * @param certificate
	 * @param certificateMustHaveClientAuthRole
	 * @return
	 * AuthLevel.NO_AUTH, 	if the client roles is required and the certificate doesn't have it<br>
	 * AuthLevel.HIGH, 		if roles smartcard was found <br>
	 * AuthLevel.MEDIUM	,	otherwise<br>
	 */
	public static SAFAuthLevel extractSAFAuthLevelFromCertificate(X509Certificate certificate, boolean certificateMustHaveClientAuthRole) {
		String oid = Extension.extendedKeyUsage.getId();
		byte[] extensionValue = certificate.getExtensionValue(oid);
		
		if (extensionValue == null) {
			log.warn("An incorrect certificate was passed : No ExtendedKeyUsage");
			if (certificateMustHaveClientAuthRole) {
				return NO_AUTH;
			} else {
				return MEDIUM;
			}
		}
		
		ASN1OctetString akiOc = ASN1OctetString.getInstance(extensionValue);
		ExtendedKeyUsage eu = ExtendedKeyUsage.getInstance(akiOc.getOctets());
		
		if (eu == null ||eu.getUsages() == null) {
			log.warn("An incorrect certificate was passed : Null or Invalid ExtendedKeyUsage");
			if (certificateMustHaveClientAuthRole) {
				return NO_AUTH;
			} else {
				return MEDIUM;
			}
		}
		
		Set<String> roles = new HashSet<>();
		
		for (int i = 0; i < eu.getUsages().length; i++) {
			KeyPurposeId kp = eu.getUsages()[i];
			roles.add(kp.getId());
		}
		
		if (certificateMustHaveClientAuthRole && !roles.contains(KeyPurposeId.id_kp_clientAuth.getId())) {
			return NO_AUTH;
		}
		
		if (roles.contains(KeyPurposeId.id_kp_smartcardlogon.getId())) {
			return HIGH;
		} else {
			return MEDIUM;
		}
	}
	
	/**
	 * Transform a crl as bytes array to its pem form in the given file.
	 * @param crl
	 * @param path
	 * @param append
	 */
	public static void crlBytesToPemFile(byte[] crl, Path path, boolean append) {
		try {
			
			//Write header
			if (append) {
				Files.write(path, "-----BEGIN X509 CRL-----\r\n".getBytes("UTF-8"), APPEND, CREATE);
			} else {
				Files.write(path, "-----BEGIN X509 CRL-----\r\n".getBytes("UTF-8"));
			}
			
			//Write base64
			try (OutputStream fw = new BufferedOutputStream(new Base64OutputStream(new FileOutputStream(path.toFile(), true)))) {
				fw.write(crl);
			}
			
			//Writer footer
			Files.write(path, "-----END X509 CRL-----\r\n".getBytes("UTF-8"), APPEND);
		} catch (Exception e) {
			throw new TechnicalException("Impossible to add CRL to file.", e);
		}
	}
	
	/**
	 * Extract entries from the given CRL file
	 * @param file
	 * @return
	 * @throws Exception
	 */
	public static List<X509CRLEntry> extractEntriesFromCRL(Path file) throws Exception {
		List<X509CRLEntry> result = new ArrayList<>();
		try (FileInputStream in = new FileInputStream(file.toFile())) {
		    CertificateFactory cf = CertificateFactory.getInstance("X.509");
		    X509CRL crl = (X509CRL) cf.generateCRL(in);
		    Set<? extends X509CRLEntry> s = crl.getRevokedCertificates();
		    if (s != null && s.isEmpty() == false) {
		      Iterator<? extends X509CRLEntry> t = s.iterator();
		      while (t.hasNext()) {
		        X509CRLEntry entry = t.next();
		        result.add(entry);
		      }
		    }
		}

		return result;
	}
	
	/**
	 * Extract CertificatePK with given alias from the given keystore file (PKCS12 format)
	 * @param p
	 * @param alias
	 * @param keystorePassword
	 * @param privateKeyPassword
	 * @return
	 * @throws Exception
	 */
	public static CertificatePK extractCertificatePKFromKeystore(Path p, String alias, char[] keystorePassword, char[] privateKeyPassword) throws Exception {
		KeyStore keystore = KeyStore.getInstance("PKCS12", new BouncyCastleProvider());
		try (InputStream inputStream = new FileInputStream(p.toFile());) {
			keystore.load(inputStream, keystorePassword);
		}
		PrivateKey privateKey = (PrivateKey)keystore.getKey(alias, privateKeyPassword);
		if (privateKey==null) {
			throw new TechnicalException("PrivateKey '"+alias+"' not found keystore " + p.toAbsolutePath());
		}
		X509Certificate c = (X509Certificate) keystore.getCertificate(alias);
		if (c==null) {
			throw new TechnicalException("Certificate '"+alias+"' not found keystore " + p.toAbsolutePath());
		}
		CertificatePK certPK = new CertificatePK(c, privateKey);
		return certPK;
	}
}