package com.bpc.sesame.saf.util;

/**
 * JAXB NamespacePrefixMapper which use pretty namespace for saml namespace
 * @author 483838
 *
 */
public class NamespacePrefixMapper extends com.sun.xml.bind.marshaller.NamespacePrefixMapper {
	@Override
	public String getPreferredPrefix(String namespaceUri, String suggestion, boolean arg2) {
		
		if ("urn:oasis:names:tc:SAML:2.0:assertion".equals(namespaceUri)) {
			return "saml";
		} else if ("urn:oasis:names:tc:SAML:2.0:protocol".equals(namespaceUri)) {
			return "samlp";
		} else if ("http://www.w3.org/2000/09/xmldsig#".equals(namespaceUri)) {
			return "ds";
		} else if ("http://www.w3.org/2001/04/xmlenc#".equals(namespaceUri)) {
			return "xenc";
		}
		
		return suggestion;
	}
}
