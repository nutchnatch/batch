package com.bpc.sesame.saf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;

/**
 *
 * Application boot for running SAF in Spring boot.
 *
 * @author a20257
 * @since 1.0.0
 */
@ComponentScan({"com.bpc.sesame.saf"})
@Import({ApplicationWeb.class})
@ServletComponentScan({"com.bpc.sesame.saf.servlets"})
@SpringBootApplication
public class ApplicationBoot extends SpringBootServletInitializer {

    /**
     * Entry point for the spring-boot
     * @param args  The arguments
     */
    public static void main(final String[] args) {
        SpringApplication.run(ApplicationBoot.class, args);
    }
}
