package com.bpc.sesame.saf.soap;

import gentypes.saml.protocol.v20.AuthnRequestType;
import gentypes.saml.protocol.v20.ResponseType;

import java.util.Random;

import javax.annotation.Resource;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.ws.Provider;
import javax.xml.ws.Service;
import javax.xml.ws.ServiceMode;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.WebServiceProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import org.w3c.dom.Document;

import com.bpc.sesame.saf.exception.RequesterException;
import com.bpc.sesame.saf.model.CertificatePK;
import com.bpc.sesame.saf.model.ResponseStatus;
import com.bpc.sesame.saf.model.ServiceProviderLocal;
import com.bpc.sesame.saf.services.AuthenticatorServices;
import com.bpc.sesame.saf.services.AuthenticatorServices.AuthenticatedUser;
import com.bpc.sesame.saf.services.IdentityProviderServicesLocal;
import com.bpc.sesame.saf.services.SAMLServices;
import com.bpc.sesame.saf.services.ServiceProvidersServicesLocal;
import com.bpc.sesame.saf.statistics.ServiceStatistics;
import com.bpc.sesame.saf.util.AuditFilter;
import com.bpc.sesame.saf.util.XmlTools;

/**
 * Implementation of the SAML SOAP binding, this implementation use the API javax.xml.ws.Provider.
 * The usual javax.xml.ws.Endpoint API cannot be used because SAML need a low-level control on the xml message.
 * For example, the namespace prefix, the end-of-line, the whitespaces must be preserved in order to have a successful signature check. 
 * 
 * This implementation never return SOAP Fault but return SAML Fault response when errors occured
 * 
 * @author 483838 
 */

@WebServiceProvider (
		serviceName = "SingleSignOnService", 
		portName = "SingleSignOnServicePort", 
		targetNamespace = "urn:oasis:names:tc:SAML:2.0:protocol:wsdl")
@ServiceMode(value=Service.Mode.PAYLOAD)
public class SSOService extends SpringBeanAutowiringSupport implements Provider<Source> {

	private static final Logger logger = LoggerFactory.getLogger(SSOService.class);
	
	@Autowired
	private SAMLServices samlServices;

	@Resource(name = "wsContext")
	private WebServiceContext wsContext;

	@Autowired
	private AuthenticatorServices authenticatorServices;

	@Autowired
	private IdentityProviderServicesLocal identityProviderServicesLocal;

	@Value("${sesame.saf.identity-provider.response.validation}")
	private Boolean xmlValidationOfResponse;

	@Autowired
	private ServiceProvidersServicesLocal spServicesLocal;
	
	@Autowired
	private ServiceStatistics soapStatistics;

	/**
	 * log management encapsulation
	 */
	@Override
	public Source invoke(Source authnRequest) {
		MDC.put(AuditFilter.BINDING, "SOAP");
		try {
			return statistic(authnRequest);
		} catch (Throwable t) {
			String errorCode = "E" + ((100000 + random.nextInt(100000)) + "").substring(1);
			MDC.put(AuditFilter.RESULT, errorCode);
			logger.error("Error : " +errorCode, t);
			ResponseType failedResponse = samlServices.createFailedSamlResponse(null, ResponseStatus.RESPONDER);
			return new DOMSource(XmlTools.responseTypeToDom(failedResponse));
		}
	}
	
	/**
	 * Statistic encapsulation
	 */
	public Source statistic(Source authnRequest) {
		long nanosBefore = System.nanoTime();
		soapStatistics.incrementCurrentActiveCount();
		try {
			Document requestDocument = XmlTools.sourceToDom(authnRequest);
			return authentication(requestDocument);
		} catch (Throwable t) {
			soapStatistics.incrementExceptionCount(t);
		    throw t;
		} finally {
			soapStatistics.decrementCurrentActiveCount();
			soapStatistics.incrementInvocationCounterAndTotalDurationWithNanos(System.nanoTime() - nanosBefore);
		}
	}

	private static final Random random = new Random();
	
	/**
	 * Business implementation, Because SAML SOAP doesn't definded a SOAPFault for error this
	 * method should never failed. Instead a <Response> Message with failed ResponseStatus is sent.
	 * @param authnRequest
	 * @return
	 */
	private Source authentication(Document requestDocument) {

		AuthnRequestType authnRequest = null;
		try {
			
			//Validate the request (XML Validation)
			XmlTools.validateRequest(new DOMSource(requestDocument));
			
			authnRequest = XmlTools.domToAuthnRequestType(requestDocument);
			
			if (logger.isDebugEnabled()) {
				logger.debug("\n######SOAP XML REQUEST PAYLOAD######\n"+ XmlTools.prettyXml(XmlTools.domToString(requestDocument)));
			}

			// Validate the request (SAML Validation)
			samlServices.validateAuthnRequest(authnRequest);

			ServiceProviderLocal serviceProvider = spServicesLocal.getServiceProviderWithCache(authnRequest.getIssuer().getValue());
			MDC.put(AuditFilter.SP_ENTITY_ID, serviceProvider.getEntityId());
			
			//Validate the request signature
			samlServices.validateAuthnRequestSignature(requestDocument, serviceProvider.getSigningCertificate().getPublicKey());
			
			// Manage Authentication
			AuthenticatedUser user = authenticatorServices.authenticateForSoap(wsContext, serviceProvider.getAuthLevel());

			// Create the SAML Response
			Document domResponse = samlServices.createSuccessfulSamlResponse(user, authnRequest);

			// Sign the SAML response XML
			if (logger.isDebugEnabled()) {
				logger.debug("\n###### RESPONSE BEFORE SIGNING ######\n" + XmlTools.domToStringPretty(domResponse));
			}

			CertificatePK cert = identityProviderServicesLocal.getCurrentCertificateWithCache();
			samlServices.signAssertionInDocument(domResponse, cert);

			// Encryption the Assertion
			if (logger.isDebugEnabled()) {
				logger.debug("\n###### RESPONSE BEFORE ENCRYPTION ######\n" + XmlTools.domToStringPretty(domResponse));
			}
			samlServices.encryptAssertion(authnRequest, domResponse, serviceProvider.getEncryptionCertificate().getPublicKey());

			// Validate the response
			if (xmlValidationOfResponse) {
				XmlTools.validateResponse(domResponse);
			}

			// Prepare the final response with a SOAP Binding
			if (logger.isDebugEnabled()) {
				logger.debug("\n###### FINAL RESPONSE ######\n" + XmlTools.domToStringPretty(domResponse));
			}

			DOMSource response = new DOMSource(domResponse);
			MDC.put(AuditFilter.RESULT, AuditFilter.RESULT_OK);
			return response;
		} catch (RequesterException e) {
			String errorCode = "E" + ((100000 + random.nextInt(100000)) + "").substring(1);
			MDC.put(AuditFilter.RESULT, errorCode);
			logger.error("Error : " +errorCode, e);
			ResponseType failedResponse = samlServices.createFailedSamlResponse(authnRequest, ResponseStatus.REQUESTER);
			return new DOMSource(XmlTools.responseTypeToDom(failedResponse));
		} catch (Exception e) {
			String errorCode = "E" + ((100000 + random.nextInt(100000)) + "").substring(1);
			MDC.put(AuditFilter.RESULT, errorCode);
			logger.error("Error : " +errorCode, e);
			ResponseType failedResponse = samlServices.createFailedSamlResponse(authnRequest, ResponseStatus.RESPONDER);
			return new DOMSource(XmlTools.responseTypeToDom(failedResponse));
		}
	}


}
