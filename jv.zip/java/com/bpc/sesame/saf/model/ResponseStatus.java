package com.bpc.sesame.saf.model;

/**
 * SAML specifications defines 4 types of ResponseStatus. 
 * For now, SAF use only 3 of the 4 which are below.
 * @author 483838
 */
public enum ResponseStatus {
		
	SUCCESS("urn:oasis:names:tc:SAML:2.0:status:Success"),
	RESPONDER("urn:oasis:names:tc:SAML:2.0:status:Responder"),
	REQUESTER("urn:oasis:names:tc:SAML:2.0:status:Requester");

	private String uri;

	ResponseStatus(String uri) {
		this.uri=uri;
	}
	public String getUri() {
		return uri;
	}
	
	public static ResponseStatus from(String uri) {
		if (uri != null) {
			for (ResponseStatus b : ResponseStatus.values()) {
				if (uri.equals(b.uri)) {
					return b;
				}
			}
		}
		return null;
	}
}
