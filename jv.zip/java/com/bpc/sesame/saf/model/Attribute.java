package com.bpc.sesame.saf.model;

/**
 * SAF is a SAML identity provider which manage the following Attributes.
 * These attributes are specific to SAF except the DISPLAY_NAME which seems to
 * be a convention to store use this specific urn to get the display name.
 * Please consult SAML specifications to have more informations about the Attributes.
 * @author 483838
 */
public enum Attribute {
	
	DISPLAY_NAME("urn:oid:2.16.840.1.113730.3.1.241"),
	TOKEN("urn:bnpparibas:cardif:saml:sesame:attribute:token"),
	USER_IDENTITY("urn:bnpparibas:cardif:saml:sesame:attribute:user-identity"),
	PERMISSIONS_ID("urn:bnpparibas:cardif:saml:sesame:attribute:permissions-id"),
	ROLES_ID("urn:bnpparibas:cardif:saml:sesame:attribute:roles-id"),
	USING_RIGHT("urn:bnpparibas:cardif:saml:sesame:attribute:using-right"),
	JOININGS("urn:bnpparibas:cardif:saml:sesame:attribute:joinings"),
	EXTENDED_ATTRIBUTES("urn:bnpparibas:cardif:saml:sesame:attribute:extended-attributes");
	
	private String name;
	
	Attribute(String name) {
		this.name=name;
	}
	public String getName() {
		return name;
	}
}
