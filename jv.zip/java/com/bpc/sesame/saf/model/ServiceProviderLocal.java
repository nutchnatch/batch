package com.bpc.sesame.saf.model;

import gentypes.saml.metadata.v20.SPSSODescriptorType;

import java.io.Serializable;
import java.security.cert.X509Certificate;

import com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel;

/**
 * A service provider to use locally in SAF. These objects are construct from
 * the com.bnppa.sesame.services.internal.model.v2.ServiceProvider which come from Sesame Services.
 * 
 * These objects are Serializable because they can be cached.
 * @author 483838
 */
public class ServiceProviderLocal implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String entityId;
	private SPSSODescriptorType description;
	private String applicationDomain;
	private SAFAuthLevel authLevel;
	private X509Certificate signingCertificate;
	private X509Certificate encryptionCertificate;
	
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}	
	
	public SPSSODescriptorType getDescription() {
		return description;
	}
	public void setDescription(SPSSODescriptorType description) {
		this.description = description;
	}
	public String getApplicationDomain() {
		return applicationDomain;
	}
	public void setApplicationDomain(String applicationDomain) {
		this.applicationDomain = applicationDomain;
	}
	public SAFAuthLevel getAuthLevel() {
		return authLevel;
	}
	public void setAuthLevel(SAFAuthLevel authLevel) {
		this.authLevel = authLevel;
	}
	public X509Certificate getSigningCertificate() {
		return signingCertificate;
	}
	public void setSigningCertificate(X509Certificate signingCertificate) {
		this.signingCertificate = signingCertificate;
	}
	public X509Certificate getEncryptionCertificate() {
		return encryptionCertificate;
	}
	public void setEncryptionCertificate(X509Certificate encryptionCertificate) {
		this.encryptionCertificate = encryptionCertificate;
	}
}
