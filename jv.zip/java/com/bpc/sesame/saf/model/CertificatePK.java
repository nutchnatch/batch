package com.bpc.sesame.saf.model;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;

/**
 * Convenient class to store a certificate and private key.
 * @author 483838
 */
public class CertificatePK {

	private X509Certificate certificate;
	private PrivateKey privateKey;

	public CertificatePK(X509Certificate certificate, PrivateKey privateKey) {
		this.certificate = certificate;
		this.privateKey = privateKey;
	}
	
	public X509Certificate getCertificate() {
		return certificate;
	}

	public PrivateKey getPrivateKey() {
		return privateKey;
	}
}