package com.bpc.sesame.saf.mock;


import java.io.IOException;
import java.net.ServerSocket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bpc.sesame.mock.SesameMock;
import com.bpc.sesame.saf.services.EnvironmentServices;

/**
 * Start/Stop the Sesame mock with this web context. <br> 
 * This class works only within a webapp <br>
 * If you need the Sesame Mock outside the webapp you can also launch the class {@link SesameMockServer} manually. 
 */
@WebListener
public class SesameMockBootstrap implements ServletContextListener {
	
	private static final Logger log = Logger.getLogger(SesameMockBootstrap.class.getName());

	private SesameMock sesameMockServer = null;
	
	protected Boolean startSesameMock = true;
	
	@Autowired
	private EnvironmentServices environmentServices;
	
	@Override
	public void contextInitialized(ServletContextEvent event) {
		
		SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, event.getServletContext());
		
		long start = System.currentTimeMillis();
		if (startSesameMock) {
			try {
				int openPort = findRandomOpenPortOnAllLocalInterfaces();
				environmentServices.setSesameBaseURL("http://localhost:"+openPort);
				sesameMockServer = new SesameMock();
				Path p = Paths.get(ApplicationBoot.getConfigDirectory()).resolve("sesameMock");
				sesameMockServer.start("0.0.0.0",openPort,p.toFile());
			} catch (Exception e) {
				log.info("Error while bootstraping SESAME Mock " + e.getMessage());
				if (log.isLoggable(Level.FINE)) {
					log.log(Level.FINE, "Error while bootstraping SESAME Mock full stack :", e);
				}
			}  
		}
		log.info("The Mock(s) starting in " + (System.currentTimeMillis()-start) + " ms.");
	}

	private Integer findRandomOpenPortOnAllLocalInterfaces() throws IOException {
		try (ServerSocket socket = new ServerSocket(0);) {
			return socket.getLocalPort();
		}
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent event) {
		try {
			if (sesameMockServer!=null) {
				sesameMockServer.stop();
				sesameMockServer=null;
			}
			log.info("SESAME Mock stopping...");
		} catch (Exception e) {
			log.info("Error while stopping SESAME Mock " + e.getMessage());
			if (log.isLoggable(Level.FINE)) {
				log.log(Level.FINE, "Error while stopping SESAME Mock full stack :", e);
			}
		}
	}


}
