package com.bpc.sesame.saf.mock;

import com.bpc.sesame.saf.Application;
import com.bpc.sesame.saf.exception.ConfigurationException;
import com.bpc.sesame.saf.mock.servlets.MockAdminServlet;
import com.bpc.sesame.saf.services.EnvironmentServices;
import com.bpc.sesame.saf.servlets.ErrorServlet;
import com.bpc.sesame.saf.servlets.IndexServlet;
import com.bpc.sesame.saf.servlets.SSOServlet;
import com.bpc.sesame.saf.soap.SSOService;
import com.bpc.sesame.saf.util.AuditFilter;
import com.bpc.sesame.saf.util.HttpsNormalizeFilter;
import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;

import javax.crypto.Cipher;
import javax.servlet.annotation.WebFilter;
import javax.xml.ws.Endpoint;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.Security;

/**
 * This class declare the spring configuration in the spring boot scenario.
 * @see Application
 * 
 * This class is also responsible of bootstrap the CLI tools of SAF, please watch the main method.
 * @author 483838
 */
@Configuration
@ComponentScan({"com.bpc.sesame.saf.mock"})
@Import({Application.class})
@SpringBootApplication
public class ApplicationBoot {
	
	private static String configDirectory;

	static {
		Security.addProvider(new BouncyCastleProvider());
		if (Files.exists(Paths.get("./src/test/config-mock/"))) {
			configDirectory = "./src/test/config-mock/";
		} else if (Files.exists(Paths.get("./config-mock/"))) {
			configDirectory = "./config-mock/";
		} else {
			throw new ConfigurationException("Cannot find the configuration Directory.");
		}
	}
	
	public static String getConfigDirectory() {
		return configDirectory;
	}

	/**
	 * This will launch the mock as a spring boot application or one of the CLI tools embedded in the mock
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
	    boolean unlimited = Cipher.getMaxAllowedKeyLength("RC5") >= 256;
	    if (!unlimited) {
	    	System.out.println("Unlimited cryptography not installed on this JRE : " +System.getProperty("java.home"));
	    	System.out.println("Please install install Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy Files");
	    	return;
	    }
	    
	    if (args==null || args.length == 0 || args[0]==null) {
	    	System.out.println("ERROR: Need one argument minimum");
	    	return;
	    }
	    
	    if (args[0].equals("run-mock")) {
			System.setProperty("logging.config", "file:"+configDirectory+"logback.xml");
			System.setProperty("spring.config.location",configDirectory);
	    	SpringApplication.run(ApplicationBoot.class, args);
	    	
	    } else if (args[0].equals("cert-gen")) {
	    	String[] args2 = new String[args.length-1]; 
	    	System.arraycopy(args, 1, args2, 0, args.length-1);
			System.setProperty("logback.configurationFile", "file:"+ configDirectory+ "logback.xml");
	    	CertificateGeneratorCLI.main(args2);
	    	
	    } else if (args[0].equals("admin")) {
	    	String[] args2 = new String[args.length-1]; 
			System.setProperty("logback.configurationFile", "file:"+ configDirectory+ "logback.xml");
	    	System.arraycopy(args, 1, args2, 0, args.length-1);
	    	AdministrationCLI.main(args2);
	    	
	    } else if (args[0].equals("client")) {
	    	String[] args2 = new String[args.length-1]; 
			System.setProperty("logback.configurationFile", "file:"+ configDirectory+ "logback.xml");
			System.arraycopy(args, 1, args2, 0, args.length-1);
	    	ServiceProviderCLI.main(args2);
	    } else {
	    	System.out.println("ERROR: First argument must be 'run-mock', 'cert-gen', 'admin' or 'client'");
	    	
	    }
    }
	
	@Autowired
    private ApplicationContext applicationContext;
	
	@Value("${sesame.saf.identity-provider.sesame-base-url}")
	private String sesameBaseURL;
	
	/**
	 * Implement the EnvironmentServices for mock scenario.
	 * In mock the scenario the sesameBaseURL is dynamic that's why it's called a sesameDynamicBaseURL
	 * @return
	 */
	@Bean
	public EnvironmentServices getEnvironmentServicesForMock() {
		return new EnvironmentServices() {
			
			private String sesameDynamicBaseURL;
			@Override
			public String getSesameBaseURL() {
				if ("<EMBEDDED>".equals(sesameBaseURL)) {
					return sesameDynamicBaseURL;
				} else {
					return sesameBaseURL;
				}
			}

			@Override
			public void setSesameBaseURL(String sesameBaseURL) {
				this.sesameDynamicBaseURL = sesameBaseURL;
			}
		};
	}
	
    //Sesame MOCK
    @Bean
    public SesameMockBootstrap executorListener() {
       return new SesameMockBootstrap();
    }
    
    //HttpsNormalizeFilter
    @Bean
    public FilterRegistrationBean httpsNormalizeFilter(){
    	FilterRegistrationBean filter = new FilterRegistrationBean(new HttpsNormalizeFilter());
    	filter.addUrlPatterns(HttpsNormalizeFilter.class.getAnnotation(WebFilter.class).urlPatterns());
    	return filter;
    }
    
    //AuditFilter
    @Bean
    public FilterRegistrationBean auditFilter(){
    	FilterRegistrationBean filter = new FilterRegistrationBean(new AuditFilter());
    	filter.addUrlPatterns(AuditFilter.class.getAnnotation(WebFilter.class).urlPatterns());
    	return filter;
    }
    
    //Redirect Servlet
    @Bean
    public ServletRegistrationBean ssoRedirectServlet(){
        return new ServletRegistrationBean(new SSOServlet(),"/redirect/sso/*","/post/sso/*");
    }
    
    //ErrorServlet
    @Bean
    public ServletRegistrationBean errorServlet(){
        return new ServletRegistrationBean(new ErrorServlet(),"/error");
    }
    
	@Value("${sesame.saf.identity-provider.url}")
	private String urlIDP;
    
    //MockAdminServlet
    @Bean
    public ServletRegistrationBean mockAdminServlet(){
        return new ServletRegistrationBean(new MockAdminServlet(),"/admin/*");
    }

    //IndexServlet
    @Bean
    public ServletRegistrationBean indexServlet(){
        return new ServletRegistrationBean(new IndexServlet(),"/","/index.html");
    }
    
    //JAXWS - IMPLEMENTOR
    @Bean
    public SSOService ssoService() {
    	return new SSOService();
    }
    
    //JAXWS - SERVLET
    @Bean
    public ServletRegistrationBean jaxws() {
        return new ServletRegistrationBean(new CXFServlet(), "/soap/*");
    }
    
    //JAXWS - ENDPOINT
    @DependsOn("jaxws")
    @Bean
    public Endpoint jaxwsEndpoint(){
       Bus bus = (Bus) applicationContext.getBean(Bus.DEFAULT_BUS_ID);
       EndpointImpl endpoint = new EndpointImpl(bus, ssoService());
       endpoint.publish("/sso");
       return endpoint;
    }
}
