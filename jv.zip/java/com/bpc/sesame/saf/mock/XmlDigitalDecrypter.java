package com.bpc.sesame.saf.mock;

import java.security.PrivateKey;

import org.apache.xml.security.encryption.XMLCipher;
import org.apache.xml.security.utils.EncryptionConstants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.bpc.sesame.saf.exception.TechnicalException;

/**
 * Use the project http://santuario.apache.org/ to decrypt encrypted xml document 
 * @author 483838
 */
public class XmlDigitalDecrypter {

    static org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(XmlDigitalDecrypter.class.getName());

    static {
        org.apache.xml.security.Init.init();
    }
    
    /**
     * Search in a xml document for <EncryptedAssertion> and replace it with <Assertion> unencrypted.
     * If no <EncryptedAssertion> the document is returned as is.
     * @param document
     * @return
     */
	public static Document decryptAssertionInResponse(Document document, PrivateKey privateKey)  {
		
		//Search for an encrypted assertion
		NodeList list = document.getElementsByTagNameNS("urn:oasis:names:tc:SAML:2.0:assertion", "EncryptedAssertion");
		//No EncryptedAssertion we could return the document as is.
		if (list.getLength()==0) {
			return document;
		}
		
		//Decrypt The document
		Document unencrypted = decrypt(document, privateKey);
		
		//Search for Assertion Element and move the assertion as a direct child of the document
		list = unencrypted.getElementsByTagNameNS("urn:oasis:names:tc:SAML:2.0:assertion", "Assertion");
		Element assertion = (Element) list.item(0);
		unencrypted.getDocumentElement().appendChild(assertion);
		
		//Remove the EncryptedAssertion which is useless
		list = unencrypted.getElementsByTagNameNS("urn:oasis:names:tc:SAML:2.0:assertion", "EncryptedAssertion");
		Element encryptedAssertion  = (Element) list.item(0);
		unencrypted.getDocumentElement().removeChild(encryptedAssertion);
		return unencrypted;
	}
	
	
	/**
	 * 
	 * @param document
	 * @param privateKey
	 * @return
	 */
    private static Document decrypt(Document document, PrivateKey privateKey)  {
    	try {
	        Element encryptedDataElement =
	            (Element) document.getElementsByTagNameNS(
	                EncryptionConstants.EncryptionSpecNS,
	                EncryptionConstants._TAG_ENCRYPTEDDATA).item(0);
	
	        XMLCipher xmlCipher = XMLCipher.getInstance();
	        /*
	         * The key to be used for decrypting xml data would be obtained
	         * from the keyinfo of the EncrypteData using the kek.
	         */
	        xmlCipher.init(XMLCipher.DECRYPT_MODE, null);
	        xmlCipher.setKEK(privateKey);
	        /*
	         * The following doFinal call replaces the encrypted data with
	         * decrypted contents in the document.
	         */
	        xmlCipher.doFinal(document, encryptedDataElement);
	
	        return document;
		} catch (Exception e) {
			throw new TechnicalException("Impossible to decrypt <EncryptedAssertion>", e);
		}
    }
}
