package com.bpc.sesame.saf.mock;

/**
 * All the TLSClient which can be used by the ServiceProviderImpl
 * @author 483838
 */
public enum TLSClient {
	/**
	 * TLSClient with Certificate from SmartCard, issued by the good CA  with role User Authent + SmartCard
	 */
	SMARTCARD("Good SmartCard Client"), 
	
	/**
	 * TLSClient with Certificate from SoftwarePKI, issued by the good CA with role User Authent
	 */
	SOFTPKI("Good SoftPKI Client"),
	
	/**
	 * TLSClient with Certificate from SoftwarePKI, issued by the good CA without roles
	 */
	NO_ROLES("Good No Roles Client"),
	
	/**
	 * TLSClient with Certificate from SoftwarePKI, issued by the Unknown CA without roles
	 */
	UNKNOWN("Unknown Client"),
	
	/**
	 * TLSClient with Certificate from SmartCard, issued by the good CA without role User Authent + SmartCard but which is revoked
	 */
	REVOKE("Revoke Client"),
	
	/**
	 * TLSClient without Certificate
	 */
	WITHOUT("No certificate"),
	
	/**
	 * TLSClient with Certificate from SmartCard, issued by the good CA  with role User Authent + SmartCard BUT without a DNSNAME attribute
	 */
	WITHOUT_DNSNAME("Without DNSNAME");
	
	private String name;
	
	TLSClient(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
}