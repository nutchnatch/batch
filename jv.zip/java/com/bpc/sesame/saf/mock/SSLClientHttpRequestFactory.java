package com.bpc.sesame.saf.mock;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;

import org.springframework.http.client.SimpleClientHttpRequestFactory;

/**
 * This class was necessary because ServiceProviderImpl need to make https request in TLS authentication.
 * So this class inject a custom SSLSocketFactory in the each connection.
 * @see TLSClientTools
 * @author 483838
 */
public class SSLClientHttpRequestFactory extends SimpleClientHttpRequestFactory {

	private SSLContext sslcontext;
	
	public SSLClientHttpRequestFactory(SSLContext sslcontext) {
		this.sslcontext = sslcontext;
	}
	
	@Override
	protected HttpURLConnection openConnection(URL url, Proxy proxy) throws IOException {
		HttpURLConnection connection = super.openConnection(url, proxy);
		if (connection instanceof HttpsURLConnection) {
			((HttpsURLConnection)connection).setSSLSocketFactory(sslcontext.getSocketFactory());
		}
		return connection;
	}
	
}
