package com.bpc.sesame.saf.mock;

import gencl.saml.protocol.wsdl.v20.SingleSignOnService;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509KeyManager;
import javax.security.auth.x500.X500Principal;
import javax.xml.namespace.QName;
import javax.xml.transform.dom.DOMSource;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;

import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.jaxws.DispatchImpl;
import org.apache.cxf.transport.http.HTTPConduit;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.asn1.x509.ExtendedKeyUsage;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.KeyPurposeId;
import org.bouncycastle.asn1.x509.KeyUsage;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509ExtensionUtils;
import org.bouncycastle.crypto.params.RSAKeyParameters;
import org.bouncycastle.crypto.util.SubjectPublicKeyInfoFactory;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import com.bpc.sesame.saf.exception.ConfigurationException;
import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.model.CertificatePK;

/**
 * This class is used in 2 scenarios :
 * <li> Creates a RestClient or SOAPClient for the ServiceProviderImpl calls
 * <li> Creates certificates for CA, Server or Client
 * Differents tools related to TLS and ServiceProviderImpl
 * @author 483838
 */
public class TLSClientTools {
	
	private static Logger log = LoggerFactory.getLogger(TLSClientTools.class);
	
	private Map<TLSClient, SSLContext> contexts = new HashMap<>();
	
	private Path clientKeyStore;
	private Path clientTrustStore;
	
	/**
	 * Create a TLSClientTools if you need a  RestClient or SOAPClient
	 * @param clientConfigDir directory where the *.p12 find can be found 
	 * @param clientUid provide a specific clientUID if multiple are available (optionnal).
	 */
	public TLSClientTools(Path clientConfigDir, String clientUid) {
		
		Path keystoresDir = clientConfigDir.resolve("keystoresForTLS");
		
		if (clientUid==null) {
			//No specific clientUid ask will use the first one found
			try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(keystoresDir, "ClientKeyStore-*.p12")) {
				for (Path entry : dirStream) {
					clientKeyStore = entry;
					break;
				}
			} catch (IOException e) {
				throw new TechnicalException("Impossible to load the ClientKeyStore", e);
			}
			if (clientKeyStore == null) {
				throw new ConfigurationException("Impossible to find a ClientKeyStore");
			}
		} else {
			//Specific clientUid
			clientKeyStore = keystoresDir.resolve("ClientKeyStore-"+clientUid+".p12");
			if (Files.notExists(clientKeyStore)) {
				throw new ConfigurationException("File not found " + clientKeyStore.toAbsolutePath().toString());
			}
		}
		
		clientTrustStore = keystoresDir.resolve("ClientTrustStore.p12");
		if (Files.notExists(clientTrustStore)) {
			throw new ConfigurationException("File not found " + clientTrustStore.toAbsolutePath().toString());
		}
	}

	private SSLContext createSSLContext(TLSClient client) {
		try {
			final KeyStore keyStore = KeyStore.getInstance("pkcs12", new BouncyCastleProvider());
			try (final InputStream is = new FileInputStream(clientKeyStore.toFile())) {
				keyStore.load(is, "pass".toCharArray());
			}
			final KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(keyStore, "pass".toCharArray());
			
			final KeyStore truststore = KeyStore.getInstance("pkcs12", new BouncyCastleProvider());
			try (final InputStream is = new FileInputStream(clientTrustStore.toFile())) {
				truststore.load(is, "pass".toCharArray());
			}
			final TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			tmf.init(truststore);
	
			final SSLContext sc = SSLContext.getInstance("TLS");
			
			KeyManager km = new CustomX509KeyManager((X509KeyManager) kmf.getKeyManagers()[0], client);
			sc.init(new KeyManager[]{km}, tmf.getTrustManagers(), new java.security.SecureRandom());
			return sc;
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	private SSLContext getSSLContext(TLSClient client) {
		SSLContext context = contexts.get(client);
		if (context != null) {
			return context;
		}
		context = createSSLContext(client);
		contexts.put(client, context);
		return context;
	}
	
	
	static class CustomX509KeyManager implements X509KeyManager {
		
		private X509KeyManager parent;
		private String defaultClientAlias;
		
		public CustomX509KeyManager(X509KeyManager parent, TLSClient client) {
			this.parent = parent;
			this.defaultClientAlias = client.toString();
		}

		@Override
		public String chooseClientAlias(String[] arg0, Principal[] arg1, Socket arg2) {
			return defaultClientAlias;
		}

		@Override
		public String chooseServerAlias(String arg0, Principal[] arg1, Socket arg2) {
			return parent.chooseServerAlias(arg0, arg1, arg2);
		}

		@Override
		public X509Certificate[] getCertificateChain(String arg0) {
			return parent.getCertificateChain(arg0);
		}

		@Override
		public String[] getClientAliases(String arg0, Principal[] arg1) {
			return parent.getClientAliases(arg0, arg1);
		}

		@Override
		public PrivateKey getPrivateKey(String arg0) {
			return parent.getPrivateKey(arg0);
		}

		@Override
		public String[] getServerAliases(String arg0, Principal[] arg1) {
			return parent.getServerAliases(arg0, arg1);
		}
		
	}
	
    public RestTemplate getRestClient(TLSClient client)  {
		SSLContext sslcontext = getSSLContext(client);
		return new RestTemplate(new SSLClientHttpRequestFactory(sslcontext));
    }
	
    public Dispatch<DOMSource> getSOAPClient(TLSClient client, String baseAddress) {

		//Init the CXF Client		
		QName singleSignOnServicePort = new QName("urn:oasis:names:tc:SAML:2.0:protocol:wsdl", "SingleSignOnServicePort");
		Dispatch<DOMSource> dispatch = new SingleSignOnService().createDispatch(singleSignOnServicePort, DOMSource.class, Service.Mode.PAYLOAD);
		
    	//Init the CXF Client : set address
    	((BindingProvider)dispatch).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, baseAddress);
    	
    	//Init the CXF Client : set TLS config
    	Client cl = ((DispatchImpl<DOMSource>)dispatch).getClient();
		HTTPConduit http = (HTTPConduit) cl.getConduit();
		TLSClientParameters parameters = new TLSClientParameters();
		SSLContext sslcontext = getSSLContext(client);
		parameters.setSSLSocketFactory(sslcontext.getSocketFactory());
		//parameters.setHostnameVerifier((h, s)-> true);
		
		http.setTlsClientParameters(parameters);
		
		return dispatch;
    }
    
	/**
	 * Create a Self-Signed Certificate to Testing Certificate Authority
	 * @param serial
	 * @param notBefore
	 * @param notAfter
	 * @param signatureAlgorithm
	 * @return
	 */
	public static CertificatePK certificateForTestingCA(String name, long serial, Date notBefore, Date notAfter, String signatureAlgorithm, int keySize) {
		try {
			KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA",new BouncyCastleProvider());
	        keyGen.initialize(keySize);
	        KeyPair keys = keyGen.generateKeyPair();
			RSAPublicKey publicKey = (RSAPublicKey) keys.getPublic();
	
			RSAKeyParameters params = new RSAKeyParameters(false, publicKey.getModulus(), publicKey.getPublicExponent());
			SubjectPublicKeyInfo publicKeyInfo = SubjectPublicKeyInfoFactory.createSubjectPublicKeyInfo(params);
			
			X500Name issuer = new X500Name(new X500Principal("CN = " + name+ ", O=00 SAF Testing").getName());
			X500Name subject = issuer;
			
			X509v3CertificateBuilder certBuilder = new X509v3CertificateBuilder(issuer, BigInteger.valueOf(serial), notBefore, notAfter, subject, publicKeyInfo);
			//Extension
			JcaX509ExtensionUtils extUtils = new JcaX509ExtensionUtils();
			certBuilder	.addExtension(Extension.basicConstraints, true, new BasicConstraints(0))
						.addExtension(Extension.subjectKeyIdentifier, false, extUtils.createSubjectKeyIdentifier(publicKey))
						.addExtension(Extension.subjectAlternativeName, false, new GeneralNames(new GeneralName(GeneralName.dNSName, name)))
						.addExtension(Extension.keyUsage, false, new KeyUsage(KeyUsage.keyCertSign
											                                    | KeyUsage.digitalSignature
											                                    | KeyUsage.keyEncipherment
											                                    | KeyUsage.dataEncipherment
											                                    | KeyUsage.cRLSign));
			
			JcaContentSignerBuilder builder = new JcaContentSignerBuilder(signatureAlgorithm).setProvider(new BouncyCastleProvider());
			ContentSigner signer = builder.build(keys.getPrivate());
			X509CertificateHolder certificateHolder = certBuilder.build(signer);
			JcaX509CertificateConverter converter = new JcaX509CertificateConverter().setProvider(new BouncyCastleProvider());
			
			log.info("Certificate for " + name + " finished.");
			
			return new CertificatePK(converter.getCertificate(certificateHolder), keys.getPrivate());
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	/**
	 * Create a certificate for testing Server over TLS
	 * @param issuer
	 * @param name
	 * @param serial
	 * @param notBefore
	 * @param notAfter
	 * @param signatureAlgorithm
	 * @return
	 */
	public static CertificatePK certificateForTestingServer(
				CertificatePK issuer, 
				String name, 
				long serial, 
				Date notBefore, 
				Date notAfter, 
				String signatureAlgorithm, 
				int keySize) {
		try {
			KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA",new BouncyCastleProvider());
	        keyGen.initialize(keySize);
	        KeyPair keys = keyGen.generateKeyPair();
			RSAPublicKey publicKey = (RSAPublicKey) keys.getPublic();
	
			RSAKeyParameters params = new RSAKeyParameters(false, publicKey.getModulus(), publicKey.getPublicExponent());
			SubjectPublicKeyInfo publicKeyInfo = SubjectPublicKeyInfoFactory.createSubjectPublicKeyInfo(params);
			
			X500Name issuerName = new JcaX509CertificateHolder(issuer.getCertificate()).getSubject();
			X500Name subject = new X500Name(new X500Principal("CN = "+name+",O=00 SAF Testing").getName());
			
			X509v3CertificateBuilder certBuilder = new X509v3CertificateBuilder(issuerName, BigInteger.valueOf(serial), notBefore, notAfter, subject, publicKeyInfo);
			
			//Extensions Preparation
			GeneralName[] names = new GeneralName[]{new GeneralName(GeneralName.dNSName, name),new GeneralName(GeneralName.dNSName, "localhost")};
			JcaX509ExtensionUtils extUtils = new JcaX509ExtensionUtils();
			List<KeyPurposeId> usages = new ArrayList<>();
			usages.add(KeyPurposeId.id_kp_serverAuth);
			
			//Extensions Construction			
			certBuilder	.addExtension(Extension.basicConstraints, true, new BasicConstraints(false))
						.addExtension(Extension.subjectAlternativeName, false, new GeneralNames(names))
						.addExtension(Extension.authorityKeyIdentifier, false, extUtils.createAuthorityKeyIdentifier(issuer.getCertificate().getPublicKey()))
						.addExtension(Extension.subjectKeyIdentifier, false, extUtils.createSubjectKeyIdentifier(publicKey))
						.addExtension(Extension.extendedKeyUsage, true, new ExtendedKeyUsage(usages.toArray(new KeyPurposeId[usages.size()])));
			
			JcaContentSignerBuilder builder = new JcaContentSignerBuilder(signatureAlgorithm).setProvider(new BouncyCastleProvider());
			ContentSigner signer = builder.build(issuer.getPrivateKey());
			X509CertificateHolder certificateHolder = certBuilder.build(signer);
			JcaX509CertificateConverter converter = new JcaX509CertificateConverter().setProvider(new BouncyCastleProvider());
			
			log.info("Certificate for " + name + " finished.");
			
			return new CertificatePK(converter.getCertificate(certificateHolder), keys.getPrivate());
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
	
	/**
	 * Create a certificate for testing User Authentication over TLS
	 * @param issuer
	 * @param name
	 * @param serial
	 * @param notBefore
	 * @param notAfter
	 * @param signatureAlgorithm
	 * @return
	 */
	public static CertificatePK certificateForTestingClient(
				CertificatePK issuer, 
				TLSClient client, 
				String uid,
				long serial, 
				Date notBefore, 
				Date notAfter, 
				String signatureAlgorithm,
				int keySize,
				boolean addRoleClientAuth, 
				boolean addRoleSmartCard,
				boolean addDnsName) {
		try {
			KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA",new BouncyCastleProvider());
	        keyGen.initialize(keySize);
	        KeyPair keys = keyGen.generateKeyPair();
			RSAPublicKey publicKey = (RSAPublicKey) keys.getPublic();
	
			RSAKeyParameters params = new RSAKeyParameters(false, publicKey.getModulus(), publicKey.getPublicExponent());
			SubjectPublicKeyInfo publicKeyInfo = SubjectPublicKeyInfoFactory.createSubjectPublicKeyInfo(params);
			
			X500Name issuerName = new X500Name(issuer.getCertificate().getSubjectDN().getName());
			X500Name subject = new X500Name(new X500Principal("CN = "+client.getName()+" for " + uid +",O=00 SAF Testing").getName());
			
			X509v3CertificateBuilder certBuilder = new X509v3CertificateBuilder(issuerName, BigInteger.valueOf(serial), notBefore, notAfter, subject, publicKeyInfo);
			//Extensions
			JcaX509ExtensionUtils extUtils = new JcaX509ExtensionUtils();
			List<KeyPurposeId> usages = new ArrayList<>();
			if (addRoleClientAuth) usages.add(KeyPurposeId.id_kp_clientAuth);
			if (addRoleSmartCard) usages.add(KeyPurposeId.id_kp_smartcardlogon);
			
			certBuilder	.addExtension(Extension.basicConstraints, true, new BasicConstraints(false))
						.addExtension(Extension.authorityKeyIdentifier, false, extUtils.createAuthorityKeyIdentifier(issuer.getCertificate().getPublicKey()))
						.addExtension(Extension.subjectKeyIdentifier, false, extUtils.createSubjectKeyIdentifier(publicKey))
						.addExtension(Extension.extendedKeyUsage, true, new ExtendedKeyUsage(usages.toArray(new KeyPurposeId[usages.size()])));
			
			if (addDnsName) {
				certBuilder.addExtension(Extension.subjectAlternativeName, false, new GeneralNames(new GeneralName(GeneralName.dNSName, uid)));
			}
			
			JcaContentSignerBuilder builder = new JcaContentSignerBuilder(signatureAlgorithm).setProvider(new BouncyCastleProvider());
			ContentSigner signer = builder.build(issuer.getPrivateKey());
			X509CertificateHolder certificateHolder = certBuilder.build(signer);
			JcaX509CertificateConverter converter = new JcaX509CertificateConverter().setProvider(new BouncyCastleProvider());
			
			log.info("Certificate for " + client + " finished.");
			
			return new CertificatePK(converter.getCertificate(certificateHolder), keys.getPrivate());
		} catch (Exception e) {
			throw new TechnicalException(e);
		}
	}
}
