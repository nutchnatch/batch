package com.bpc.sesame.saf.mock;

import gentypes.saml.protocol.v20.ResponseType;

/**
 * A convenient object to store a response from SAF for testing purpose, with these informations :
 * <li>html : the raw response from SAF
 * <li>response : the JAXB response from SAF
 * <li>responseHttpCode : the http code from SAF
 * <li>relayState : the relayState value from SAF (please consult SAML spec if you don't know relayState feature)
 * @author 483838
 */
public class ResponseHolder {
	
	private String html;
	private ResponseType response;
	private int responseHttpCode;
	private String relayState;
	
	public String getHtml() {
		return html;
	}
	public void setHtml(String html) {
		this.html = html;
	}
	public ResponseType getResponse() {
		return response;
	}
	public void setResponse(ResponseType response) {
		this.response = response;
	}
	public int getResponseHttpCode() {
		return responseHttpCode;
	}
	public void setResponseHttpCode(int responseHttpCode) {
		this.responseHttpCode = responseHttpCode;
	}
	public String getRelayState() {
		return relayState;
	}
	public void setRelayState(String relayState) {
		this.relayState = relayState;
	}
}
