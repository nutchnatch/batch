package com.bpc.sesame.saf.mock;

import gentypes.saml.assertion.v20.NameIDType;
import gentypes.saml.metadata.v20.EndpointType;
import gentypes.saml.metadata.v20.EntityDescriptorType;
import gentypes.saml.metadata.v20.IDPSSODescriptorType;
import gentypes.saml.metadata.v20.KeyTypes;
import gentypes.saml.protocol.v20.AuthnRequestType;
import gentypes.saml.protocol.v20.ResponseType;
import gentypes.sesame.services.common.model.Joining;
import gentypes.sesame.services.common.model.KeyValue;
import gentypes.sesame.services.common.model.UserIdentity;
import gentypes.sesame.services.common.model.UsingRight;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.Deflater;

import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.transform.dom.DOMSource;
import javax.xml.ws.Dispatch;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.HtmlUtils;
import org.springframework.web.util.UriComponentsBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.bpc.sesame.saf.exception.ConfigurationException;
import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.model.CertificatePK;
import com.bpc.sesame.saf.util.CryptographicTools;
import com.bpc.sesame.saf.util.XmlDigitalSigner;
import com.bpc.sesame.saf.util.XmlTools;

/**
 * SamlServiceProvider is a class design to be a SAML Service Provider for Testing purpose. If you 
 * need examples on how to use this class please watch the unit test com.bpc.sesame.saf.functional.SSORedirectTest
 * @author 483838
 */
public class ServiceProviderImpl {
	
	private static final Logger logger = LoggerFactory.getLogger(ServiceProviderImpl.class);
	
	private static final Path DEFAULT_CLIENTS_CONFIG_DIR = Paths.get("config-clients/");
	
	//IDP info
	public IDPSSODescriptorType idpMetadata;
	public List<PublicKey> idpCurrentPublicKeys;
	
	//SP info
	public Path clientConfigDir;
	public String spEntityId;
	public CertificatePK spSigningCertificatePK;
	public CertificatePK spEncryptionCertificatePK;
	public TLSClientTools tlsClientTools;
	
	//Request params with their default value
	public int timeshifting 				= 0;
	public Binding binding 					= Binding.REDIRECT;
	public TLSClient clientCertificate 		= TLSClient.SMARTCARD;
	public SignatureAlgo signatureAlgo 		= SignatureAlgo.SHA_256;
	public Integer attributesIndex			= null;
	public String relayState				= null;
	public String clientUid					= null;
	public String rawRequest				= null;
	public SignatureState signatureState	= SignatureState.NORMAL;
	
	public static enum SignatureState { NORMAL, MISSING, CORRUPT };
	public static enum SignatureAlgo {
		
		SHA1 ("http://www.w3.org/2000/09/xmldsig#rsa-sha1"),
		SHA_256("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"), 
		SHA_512("http://www.w3.org/2001/04/xmldsig-more#rsa-sha512");
		
		private String ns;
		
		SignatureAlgo(String ns) {
			this.ns = ns;
		}
		
		public String getNs() {
			return ns;
		}
	}
	public static enum Binding {
		REDIRECT("urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect"), 
		POST("urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"), 
		SOAP("urn:oasis:names:tc:SAML:2.0:bindings:SOAP");
		
		Binding(String urn) {
			this.urn = urn;
		}
		
		String urn;

		public String getUrn() {
			return urn;
		}
	}
	
	public ServiceProviderImpl(File clientConfigDir, String serviceProviderId) {
		this.clientConfigDir = clientConfigDir.toPath();
		loadSPFiles(serviceProviderId);
	}
	
	public ServiceProviderImpl(String serviceProviderId) {
		
		this.clientConfigDir = DEFAULT_CLIENTS_CONFIG_DIR;
		
		if (Files.exists(this.clientConfigDir)) {
			loadSPFiles(serviceProviderId);
		} else {
			this.clientConfigDir = Paths.get("src/test").resolve(DEFAULT_CLIENTS_CONFIG_DIR);
			if (Files.exists(this.clientConfigDir)) {
				loadSPFiles(serviceProviderId);
			} else {
				throw new ConfigurationException("The directory for your clients configuration cannot be found.");
			}
		}
		
	}

	public ServiceProviderImpl init() {
		
		if (idpMetadata==null) {
			this.idpMetadata(clientConfigDir.resolve("idp.xml").toFile());
		}
		tlsClientTools = new TLSClientTools(clientConfigDir, clientUid);
		return this;
	}
	
	
	private void loadSPFiles(String spEntityId) {

		if (spEntityId==null) {
			return;
		}
		
		this.spEntityId = spEntityId;
		
		if (Files.notExists(this.clientConfigDir)) {
			throw new ConfigurationException("The directory for your clients configuration cannot be found : " + this.clientConfigDir);
		}
		
		String key = XmlTools.entityIdToKey(spEntityId);
		Path spMetadata = clientConfigDir.resolve(key + ".xml");
		Path spEncryptionKey = clientConfigDir.resolve(key + ".encryption.pem");
		Path spSigningKey = clientConfigDir.resolve(key + ".signing.pem");
		
		if (Files.notExists(spMetadata) || Files.notExists(spEncryptionKey) || Files.notExists(spSigningKey)) {
			throw new ConfigurationException("Missing one of the following files : " + spMetadata + " " + spEncryptionKey + " " + spSigningKey);
		}
		
		try {
			X509Certificate spSigningCertificate = CryptographicTools.extractCertificateFromMetadataFile(spMetadata, "signing");
			String spSigningPrivateKey = new String(Files.readAllBytes(spSigningKey),"UTF-8");
			this.spSigningCertificatePK = new CertificatePK(spSigningCertificate, CryptographicTools.pemStringToPrivateKey(spSigningPrivateKey));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
			
		try {
			X509Certificate spEncryptionCertificate = CryptographicTools.extractCertificateFromMetadataFile(spMetadata, "encryption");
			String spEncryptionPrivateKey = new String(Files.readAllBytes(spEncryptionKey),"UTF-8");
			this.spEncryptionCertificatePK = new CertificatePK(spEncryptionCertificate, CryptographicTools.pemStringToPrivateKey(spEncryptionPrivateKey));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public ServiceProviderImpl idpMetadata(File idpMetadataFile) {
		
		if (!idpMetadataFile.exists()) {
			throw new ConfigurationException("Unable to find the idp metadata : " + idpMetadataFile);
		}
		
		try {
			String content = new String(Files.readAllBytes(idpMetadataFile.toPath()),"UTF-8");
			return idpMetadata(content);
		} catch (Exception e) {
			throw new TechnicalException("Error reading the idp metadata.", e);
		}
	}
	
	
	public ServiceProviderImpl idpMetadata(URL metadataUrl) {
        return idpMetadata(downloadIdpMetadata(metadataUrl));
	}
	
	public ServiceProviderImpl idpMetadata(String content) {
        EntityDescriptorType description = XmlTools.stringToEntityDescriptorType(content);
		if (description.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor() == null ||
				description.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor().size()!=1 ||
				!(description.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor().get(0) instanceof IDPSSODescriptorType)) {
			throw new TechnicalException("Sesame SAF manage only one declaration of type IDPSSODescriptorType.");
		}
		
		this.idpMetadata = (IDPSSODescriptorType) description.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor().get(0);
		List<X509Certificate> certificates = CryptographicTools.extractCertificateFromEntityDescriptorType(description.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor().get(0), KeyTypes.SIGNING);
		List<PublicKey> publicKeys = new ArrayList<>();
		for (X509Certificate certificate : certificates) {
			publicKeys.add(certificate.getPublicKey());
		}
		this.idpCurrentPublicKeys = publicKeys;
		return this;
	}
	
	public ServiceProviderImpl binding(Binding binding) {
		this.binding = binding;
		return this;
	}
	
	public ServiceProviderImpl clientCertificate(TLSClient client) {
		this.clientCertificate = client;
		return this;
	}
	
	public ServiceProviderImpl relayState(String relayState) {
		this.relayState = relayState;
		return this;
	}
	
	public ServiceProviderImpl signatureAlgo(SignatureAlgo signatureAlgo) {
		this.signatureAlgo = signatureAlgo;
		return this;
	}
		
	public ServiceProviderImpl attributesIndex(Integer attributesIndex) {
		this.attributesIndex = attributesIndex;
		return this;
	}
	
	public ServiceProviderImpl timeshifting(Integer timeshifting) {
		this.timeshifting = timeshifting;
		return this;
	}
	
	public ServiceProviderImpl clientUid(String clientUid) {
		this.clientUid = clientUid;
		return this;
	}
	
	public ServiceProviderImpl rawRequest(String rawRequest) {
		this.rawRequest = rawRequest;
		return this;
	}
	
	public ServiceProviderImpl signatureState(SignatureState signatureState) {
		this.signatureState = signatureState;
		return this;
	}
	
	private AuthnRequestType createJaxbRequest() {

		
		AuthnRequestType request = new AuthnRequestType();
		request.setAssertionConsumerServiceURL("http://localhost:8080/sci-sp/saml/SSO");
		request.setDestination(computeIdpEndpointUrl());
		request.setForceAuthn(false);
		request.setID(XmlTools.createID());
		request.setIssueInstant(XmlTools.createXmlGregorianCalendar(timeshifting));
		if (this.binding == Binding.SOAP) {
			request.setProtocolBinding(Binding.SOAP.getUrn());
		} else {
			request.setProtocolBinding(Binding.POST.getUrn());
		}
		if (attributesIndex!=null) {
			request.setAttributeConsumingServiceIndex(this.attributesIndex);
		}
		request.setVersion("2.0");
		
		NameIDType issuer = new NameIDType();
		issuer.setValue(this.spEntityId);
		request.setIssuer(issuer);
		
		return request;
	}
	
	private String encodeAuthnGETRequestXML(String xml) {

		try {
			String encoded = DatatypeConverter.printBase64Binary(compress(xml.getBytes("UTF-8")));
			return encoded;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	private String encodeAuthnPOSTRequestXML(Document requestDocument) {
		try {
			String xml = XmlTools.domToString(requestDocument);
			String encoded = DatatypeConverter.printBase64Binary(xml.getBytes("UTF-8"));
			return encoded;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	private static byte[] compress(byte[] data) throws IOException {

		Deflater deflater = new Deflater();
		deflater.setInput(data);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
		deflater.finish();
		byte[] buffer = new byte[1024];
		while (!deflater.finished()) {
			int count = deflater.deflate(buffer); // returns the generated
													// code... index
			outputStream.write(buffer, 0, count);
		}

		outputStream.close();

		byte[] output = outputStream.toByteArray();

		return output;

	}

	private static Pattern RESPONSE_FINDER = Pattern.compile("<textarea (id=\"fromError\" )?name=\"SAMLResponse\">(.+?)</textarea>", Pattern.MULTILINE);
	private static Pattern RELAY_STATE_FINDER = Pattern.compile("<input name=\"RelayState\" type=\"text\" value=\"(.+?)\" />", Pattern.MULTILINE);
	
	private void parseResponseHolderHtml(ResponseHolder responseHolder) {
        
        Matcher matcher = RESPONSE_FINDER.matcher(responseHolder.getHtml());
        if (matcher.find()) {
	        String base64 = matcher.group(2);
	        String decoded = new String(DatatypeConverter.parseBase64Binary(base64.trim()));
	        responseHolder.setResponse(decryptResponse(decoded));
        }         
        
        matcher = RELAY_STATE_FINDER.matcher(responseHolder.getHtml());
        if (matcher.find()) {
	        String rs = matcher.group(1);
	        rs = HtmlUtils.htmlUnescape(rs);
	        responseHolder.setRelayState(rs);
        }
	}
	
	private ResponseType decryptResponse(String responseXmlString) {
		try {
			
			Document encrypted = XmlTools.stringToDom(responseXmlString); 
			Document unencrypted = null;
			logger.debug("\n###### RESPONSE CLIENT SIDE BEFORE UNENCRYPTION ######\n" + XmlTools.domToStringPretty(encrypted));
			if (spEncryptionCertificatePK!=null) {
				unencrypted = XmlDigitalDecrypter.decryptAssertionInResponse(encrypted, spEncryptionCertificatePK.getPrivateKey());
				logger.debug("\n###### RESPONSE CLIENT SIDE AFTER UNENCRYPTION ######\n" + XmlTools.domToStringPretty(unencrypted));
			} else {
				logger.debug("Cannot unencrypt no requester information");
				unencrypted = encrypted;
			}
			
	    	NodeList nl = unencrypted.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
			boolean signaturePresent = nl.getLength() > 0;
			
			if (signaturePresent) {
				boolean signatureFromIdpValid = false;
				for (PublicKey publicKey : idpCurrentPublicKeys) {
					if (!XmlDigitalSigner.getInstance().verifySignatureInDocument(unencrypted, publicKey)) {
						signatureFromIdpValid = true;
						break;
					}
				}
				if (!signatureFromIdpValid) {
					throw new TechnicalException("Signature is not valid");
				}
			}
			
			JAXBContext jaxbContext = XmlTools.createJaxbContext(new Class[]{ResponseType.class, KeyValue.class, UserIdentity.class, UsingRight.class, Joining.class});
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			@SuppressWarnings("unchecked")
			JAXBElement<ResponseType> el = (JAXBElement<ResponseType>) jaxbUnmarshaller.unmarshal(unencrypted);
			
			return el.getValue();
		}catch(Exception e) {
			throw new IllegalArgumentException("The SAML Request is invalid.", e);
		}
	}
	
	
	public ResponseHolder execute() {
		
		AuthnRequestType request = this.createJaxbRequest();
		
		ResponseHolder responseHolder = null;
		
		if (Binding.REDIRECT == binding) {
			if (rawRequest==null) {
				rawRequest = XmlTools.authnRequestTypeToString(request);
			}
			String encoded = this.encodeAuthnGETRequestXML(rawRequest);
			responseHolder = this.executeGetRequest(encoded);
			parseResponseHolderHtml(responseHolder);
			
		} else if (Binding.POST == binding) {
			Document requestDocument = null;
			if (rawRequest==null) {
				requestDocument = XmlTools.authnRequestTypeToDom(request);
			} else {
				requestDocument = XmlTools.stringToDom(rawRequest);
			}
			if (signatureState != SignatureState.MISSING) {
				XmlDigitalSigner.getInstance(signatureAlgo.getNs(), true).signAuthnRequestInDocument(requestDocument, spSigningCertificatePK);
				if (signatureState == SignatureState.CORRUPT) {
					corruptDocumentSignature(requestDocument);
				}
			}
			String encoded = this.encodeAuthnPOSTRequestXML(requestDocument);
			responseHolder = this.executePostRequest(encoded);
			parseResponseHolderHtml(responseHolder);
			
		} else if (Binding.SOAP == binding) {
			Document requestDocument = null;
			if (rawRequest==null) {
				requestDocument = XmlTools.authnRequestTypeToDom(request);
			} else {
				requestDocument = XmlTools.stringToDom(rawRequest);
			}
			if (signatureState != SignatureState.MISSING) {
				XmlDigitalSigner.getInstance(signatureAlgo.getNs(), true).signAuthnRequestInDocument(requestDocument, spSigningCertificatePK);
				if (signatureState == SignatureState.CORRUPT) {
					corruptDocumentSignature(requestDocument);
				}
			}
			responseHolder = new ResponseHolder();
			try {
				DOMSource reqMsg = new DOMSource(requestDocument);
				Dispatch<DOMSource> dispatchClient = tlsClientTools.getSOAPClient(this.clientCertificate, computeIdpEndpointUrl());
				DOMSource resMsg = dispatchClient.invoke(reqMsg);
				ResponseType response = XmlTools.domToResponseType((Document)resMsg.getNode());
				
				String responseXml = XmlTools.responseTypeToString(response, false);
				responseHolder.setResponse(decryptResponse(responseXml));
				responseHolder.setResponseHttpCode(200);
			} catch(Exception e) {
				addExceptionInresponseHolder(responseHolder, e);
			}
		}
		
		return responseHolder;
	}
	
	private void addExceptionInresponseHolder(ResponseHolder responseHolder, Exception e) {
		responseHolder.setResponseHttpCode(500);
		try (StringWriter sw = new StringWriter();) {
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			responseHolder.setHtml(sw.toString());
		} catch (IOException e1) {
			throw new RuntimeException(e1);
		}
	}

	private String computeIdpEndpointUrl() {
		for (EndpointType endpoint : idpMetadata.getSingleSignOnService()) {
			if (this.binding.getUrn().equals(endpoint.getBinding())) {
				return endpoint.getLocation();
			}
		}
		throw new ConfigurationException("Binding '"+this.binding+ "' not found for this IDP");
	}

	private ResponseHolder executePostRequest(String samlRequest) {
    	//Choose a Client
    	RestTemplate restTemplate = tlsClientTools.getRestClient(this.clientCertificate);
    	
    	//Create the request
    	MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    	params.add("SAMLRequest", samlRequest);
    	if (relayState != null) {
    		params.add("RelayState", relayState);
    	}
    	
    	ResponseHolder responseHolder = new ResponseHolder();
    	try {
    		responseHolder.setHtml(restTemplate.postForObject(computeIdpEndpointUrl(), params, String.class));
    		responseHolder.setResponseHttpCode(200);
		} catch (HttpServerErrorException e) {
			responseHolder.setHtml(e.getResponseBodyAsString());
			responseHolder.setResponseHttpCode(e.getStatusCode().value());
		} catch (Exception e) {
			addExceptionInresponseHolder(responseHolder, e);
		}
    	
		return responseHolder;
		
	}
	
	private ResponseHolder executeGetRequest(String samlRequest) {
		
		//Sign the request
		String textToSigned = "";
		
		try {
			if (relayState == null || relayState.length() == 0) {
				textToSigned = "SAMLRequest=" + URLEncoder.encode(samlRequest, "UTF-8") + "&SigAlg=" + URLEncoder.encode(this.signatureAlgo.getNs(), "UTF-8");
			} else {
				textToSigned = "SAMLRequest=" + URLEncoder.encode(samlRequest, "UTF-8") + "&RelayState="+URLEncoder.encode(relayState, "UTF-8")+"&SigAlg="+ URLEncoder.encode(signatureAlgo.getNs(), "UTF-8");
			}
		} catch (UnsupportedEncodingException e) {
			throw new TechnicalException("Error when trying to decode parameters of requet :", e);
		}
		byte[] signature = null;
		String signatureAsString = null;
		if (spSigningCertificatePK!=null) {
			signature = XmlDigitalSigner.getInstance(this.signatureAlgo.getNs(), true).createSignatureFromText(textToSigned, spSigningCertificatePK.getPrivateKey());
			signatureAsString = DatatypeConverter.printBase64Binary(signature);
		}
		
    	//Choose a Client
    	RestTemplate restTemplate = tlsClientTools.getRestClient(this.clientCertificate);
    	
    	//Create the request
    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(computeIdpEndpointUrl())
    	        .queryParam("SAMLRequest", samlRequest)
    	        .queryParam("RelayState", relayState);
    	
    	if (signatureState != SignatureState.MISSING) {
        	builder.queryParam("SigAlg", this.signatureAlgo.getNs());
        	if (signatureState == SignatureState.NORMAL) {
        		builder.queryParam("Signature", signatureAsString);
        	} else {
        		builder.queryParam("Signature", 
        				"g4uwBbn4lVjsmpr8ZPPNQA6lfU749zRm9t2VAqhiB/pYooyU+vYleyMRTKp+Fzgd4cdxwHa+/HB7yzfhkO3kUIJN/iWw"
        				+ "TVB2v8qITFBq94Ga2ieK2q3i0c5P+inmUc/heyI9ntdwIp7qR1WUJrkB6gEC6B+VL8yHqUMRMoo2Kofb1Tvly2LYqD"
        				+ "LRUVdYN5OaLZTfLNkwjyrSvcsP5u0+W/cmnv8aKIt7pImjJh63pENiQ1WxqVnNgpwnJwBUxPRZw+MtTi0wxFjSFu8l"
        				+ "q08CKcmUaQjbavrhK8QD9ZVvcvQ3KQbP3sE0BmQwL9mYNEDeDIBFrdM3bmn8hlGDa90F4A==");
        	}
    	}
    	
    	ResponseHolder responseHolder = new ResponseHolder();
    	try {
    		responseHolder.setHtml(restTemplate.getForObject(builder.build().encode().toUri(), String.class));
    		responseHolder.setResponseHttpCode(200);
		} catch (HttpServerErrorException e) {
			responseHolder.setHtml(e.getResponseBodyAsString());
			responseHolder.setResponseHttpCode(e.getStatusCode().value());
		} catch (Exception e) {
			addExceptionInresponseHolder(responseHolder, e);
		}
		return responseHolder;
	}
	
	public String downloadIdpMetadata(URL metadataUrl) {
		RestTemplate restTemplate = tlsClientTools.getRestClient(TLSClient.SMARTCARD);
    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(metadataUrl.toString());
        String xml = restTemplate.getForObject(builder.build().encode().toUri(), String.class);
        return xml;
	}
	
	private void corruptDocumentSignature(Document doc) {
		XPath xPath = XPathFactory.newInstance().newXPath();
		try {
			Node signature = (Node) xPath.evaluate("//*[local-name()='Signature']/*[local-name()='SignatureValue']",
					doc.getDocumentElement(), XPathConstants.NODE);
			if (signature == null) {
				throw new TechnicalException("Impossible to corrupt this document no signature founds.");
			}
			
			signature.setTextContent("QRW7ycRL08YSWUecxaHr2kChVua3DdlxoYUo3dutgMC+hw53w7N/kRg/NU0mgM4WEadcWPbXxdhi\n" + 
					"OpLhdOVaDmYZbkaQN/0/gpStz/awTEWdWmekeEsRs3DX5Jl4rCjWfIjuNZPv5o37jqhHzpfUYG5a\n" + 
					"7sMST3b3H3QOYluTzq4twbtBZPtv2wg6m2SvHa8x7mM4k+m7y53zCePcTjZCTOUVzCTbmBvVVsHJ\n" + 
					"K6kDGoupyyaXV7Bhz1dujuRMgj/jPrxh9XzuxaFwjCMYNkg0cXdFIpk9PTZeCsWpnTpbbpcAR2UJ\n" + 
					"IEtvFhG0I17xhc3B0azBeG1yy/5vx+4XIq11YA==");
		} catch (XPathExpressionException e) {
			throw new TechnicalException(e);
		}
	}
}
