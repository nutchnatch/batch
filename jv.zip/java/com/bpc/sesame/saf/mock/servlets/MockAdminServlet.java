package com.bpc.sesame.saf.mock.servlets;

import java.io.IOException;
import java.io.Writer;
import java.math.BigInteger;
import java.sql.Date;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bnppa.sesame.services.internal.exception.v2.InvalidParameterException;
import com.bnppa.sesame.services.internal.exception.v2.UnauthorizedActionException;
import com.bnppa.sesame.services.internal.model.v2.IdentityProviderCertificate;
import com.bnppa.sesame.services.internal.model.v2.ServiceProvider;
import com.bnppa.sesame.services.internal.v2.IdentityProviderServices;
import com.bnppa.sesame.services.internal.v2.ServiceProvidersServices;
import com.bpc.sesame.saf.exception.TechnicalException;
import com.bpc.sesame.saf.model.CertificatePK;
import com.bpc.sesame.saf.services.EnvironmentServices;
import com.bpc.sesame.saf.services.SesameServices;
import com.bpc.sesame.saf.util.CryptographicTools;
import com.bpc.sesame.safadmin.api.IdentityProviderTasks;

/**
 * This servlet generates a quick and dirty admin console for the mock
 * Please, launch the mock and go the adminServlet http://localhost:8080/sesame_saf/admin.
 * To view the usage of this simple console. 
 * @author 483838
 */
@WebServlet("/admin")
public class MockAdminServlet extends HttpServlet {
	
	private static final Logger log = LoggerFactory.getLogger(MockAdminServlet.class);

	private static final long serialVersionUID = 1L;
	
	private static final String SIGNATURE_ALGORITHM = "SHA256withRSA";
	private static final Date NOT_AFTER = Date.valueOf("2037-01-01");
	private static final Date NOT_BEFORE = Date.valueOf("2016-01-01");
	private static final int KEY_SIZE = 2048;

	@Autowired
	private IdentityProviderServices identityProviderServices;
	
	@Autowired
	private ServiceProvidersServices serviceProviderServices;
	
	@Value("${sesame.saf.identity-provider.id}")
	private String entityIdIDP;
	
	@Value("${sesame.saf.identity-provider.url}")
	private String urlIDP;
	
	@Value("${sesame.saf.identity-provider.private-key.passphrase}")
	private char[] privateKeyPassphrase;
	
	@Autowired
	private SesameServices sesameServices;
	
	@Autowired
	private EnvironmentServices environmentServices;

	public void init(ServletConfig config) throws ServletException {
	    super.init(config);
	    SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, config.getServletContext());
	}

	public String computeUrlIDP(HttpServletRequest req) {
		if (urlIDP!=null && urlIDP.length()>0) {
			return urlIDP;
		}
		return
		req.getScheme()
	      + "://"
	      + req.getServerName()
	      + ":"
	      + req.getServerPort()
	      + req.getContextPath() + "/";
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	//simple MVC pattern
		
	//Controller start
		//When clic on addCertificate
		if ("true".equals(req.getParameter("addCertificate"))) {
			addCertificate();
			//Relative redirect
			resp.setStatus(HttpServletResponse.SC_MOVED_TEMPORARILY);
			resp.setHeader("Location", req.getContextPath() + "/admin");
			resp.flushBuffer();
			return;
		}

		//Retrieve the current and next certificate
		IdentityProviderCertificate current=null, next = null;
		try {
			current = identityProviderServices.getCurrentIdentityProviderCertificate(null);
			next = identityProviderServices.getNextIdentityProviderCertificate(null);
		} catch (UnauthorizedActionException | com.bnppa.sesame.services.internal.exception.v2.TechnicalException e) {
			throw new TechnicalException(e);
		}
		CertificatePK currentCertificate = current==null?null:CryptographicTools.pemStringToCertificatePK(current.getCertificate(), privateKeyPassphrase);
		CertificatePK nextCertificate = next==null?null:CryptographicTools.pemStringToCertificatePK(next.getCertificate(), privateKeyPassphrase);
		
		if ("true".equals(req.getParameter("getMetadata"))&&currentCertificate!=null) {
			resp.setContentType("text/xml; charset=utf-8");
			try {
				String metadata = IdentityProviderTasks.generateMetadata(entityIdIDP, computeUrlIDP(req), currentCertificate.getCertificate(), nextCertificate.getCertificate());
				resp.getWriter().write(metadata);
			} catch (Exception e) {
				throw new TechnicalException(e);
			} finally {
				resp.getWriter().flush();
				resp.getWriter().close();
			}
			return;
		}
		List<IdentityProviderCertificate> certificates = null;
		List<ServiceProvider> providers = null;
		try {
			certificates = identityProviderServices.getIdentityProviderCertificatesInfo(null);
			providers = serviceProviderServices.getServiceProvidersWithoutMetadata(null);
		} catch (UnauthorizedActionException | com.bnppa.sesame.services.internal.exception.v2.TechnicalException e) {
			throw new TechnicalException(e);
		}
	//Controller end
		
	//View start
		String html = "<!DOCTYPE html>\r\n" +
						"<title>Sesame SAF Mock : Administration</title>\r\n" + 
						"<style>\r\n" + 
						"   body{background:#F0F0F0;color:#555;font:0.8em Verdana}\r\n" + 
						"   div{margin-bottom:5px}\r\n" + 
						"   pre{display:inline-block; margin:0;font-size:1.2em}\r\n" + 
						"   .block {margin:10px;padding:10px;background:#fff;box-shadow: 2px 2px 3px #999;}\r\n" + 
						"   .params {font-size:0.9em;color:#999}\r\n" + 
						"   .params label {color:#555}\r\n" + 
						"   .block h1 {font-size:1em;padding:0 0 5px 0;margin:0 0 5px 0;border-bottom:1px solid #ddd;}\r\n" + 
						"   label {padding-right:15px;display:inline-block;width:200px;color:#333;vertical-align:top;text-align:right;}\r\n" + 
						"   button {background:#fff;border:1px solid #007f50;color:#007f50;padding:0px 15px;margin-right:20px;cursor:pointer;width:150px;}\r\n" + 
						"   button:hover {background:#007f50;color:#fff;}\r\n" +
						"	td,th {text-align:left;padding-right:20px;}\r\n" +
						"	th {color:#555}\r\n" + 
						"</style>\r\n" +
						"<h3>Sesame SAF Mock : Administration</h3>";
		
	//View Identity Provider
				html += "<div class=\"block\"><h1>Identity Provider &nbsp;" +
						"<button onclick=\"window.location='?addCertificate=true'\">Create Certificate</button> ";
				
				if (currentCertificate!=null) {
					html +=	"<button onclick=\"window.location='?getMetadata=true'\">Display Metadata</button>";
				} else {
					html +=	"<span style=\"color:red;\">You need to create at least one certificate.</span>";
				}
				html +=	"</h1>" +
						"<div class=\"params\">" + 
						"<h1>Documentation</h1>" +
						"<p>In this part, you can manage the identity provider certificates/private keys. These certificates are ordered by their serial numbers," + 
						"the latest is always tags as NEXT and the penultimate is always tags as CURRENT. Sesame SAF will always include the next and current certificates "+ 
						"in its metadata file and Sesame SAF will always use the current certificate to sign its assertions.</p>" +
						"<p>In the config directory you can : " + 
						"<li>Edit the parameters below with the files <strong>config/application.properties</strong>." + 
						"<li>View and delete certificates in the subdirectory <strong>config/identityProvider/</strong>.</p>" +
						"</div>" +
						"<div class=\"params\">" + 
						"<h1>Parameters</h1>" +
						"<div><label>EntityId:</label> "+entityIdIDP+"</div>" +
						"<div><label>URL:</label> "+computeUrlIDP(req)+"</div>" +
						"<div><label>Sesame Services URL:</label> "+environmentServices.getSesameBaseURL()+"/sesame_services/</div>" +
						"</div>" +
						"<div class=\"params\">" + 
						"<h1>Certificates list (Serial Numbers / Tags):</h1>";
						for(IdentityProviderCertificate sn : certificates) {
							html += "<div><label>" + sn.getSerialNumber().longValue() +"</label>";
							if (sn.getSerialNumber().longValue()==currentCertificate.getCertificate().getSerialNumber().longValue()) {
								html += "CURRENT ";
							}
							if (nextCertificate!=null && sn.getSerialNumber().longValue()==nextCertificate.getCertificate().getSerialNumber().longValue()) {
								html += "NEXT";
							}
							html += "</div>";
						}
				html += "</div></div>";
		
	//View Service Providers
				html += "<div class=\"block\"><h1>Service Providers</h1>" +
						"<div class=\"params\">" + 
						"<h1>Documentation</h1>" +
						"<p>In this part, you can view the service providers which are register for this identity provider. To declare a new service provider," + 
						"you just need to add its metadata file in the subdirectory <strong>config/serviceProviders/</strong>." + 
						"Important, the metadata file must be named equals to the entityId, replacing all specific characheters by underscore '_'. The normal characters are" +
						" the letters, the numbers, the symbol dot '.' and the symbol minus '-'." +
						"<p>With the file <strong>config/serviceProviders/service-providers.properties</strong>, you can also customize : " + 
						"<li>The requested authentication level (LOW/MEDIUM/HIGH) of each SP." + 
						"<li>The sesame application domain of each SP. The application domain is used when retrieving users permissions, roles, joinings and using rights.</p>" +
						"</div>" +
						"<div class=\"params\">" + 
						"<h1>Service Providers List :</h1>" +
						"<table><tr><th>EntityId</th><th>Application Domain</th><th>Authentication Level</th></tr>";
						for(ServiceProvider meta : providers) {
							html += "<tr><td>"+meta.getEntityId()+"</td><td>"+meta.getApplicationDomain()+"</td><td>"+meta.getAuthLevel().toString()+"</td></tr>";
						}
		
			  html +=  "</table>"
			  		+ "</div></div>";
		Writer w = resp.getWriter();
		w.write(html);
		w.flush();
		w.close();
	//View end
	}	
	
	private void addCertificate() {
		//find the new serial number
		List<IdentityProviderCertificate> certificates = null;
		try {
			certificates = identityProviderServices.getIdentityProviderCertificatesInfo(null);
		} catch (UnauthorizedActionException | com.bnppa.sesame.services.internal.exception.v2.TechnicalException e) {
			throw new TechnicalException(e);
		}
		BigInteger serialNumber = BigInteger.valueOf(1);
		if (certificates.size()>0) {
			//Add one to the latest serial number
			serialNumber = certificates.get(certificates.size()-1).getSerialNumber().add( BigInteger.valueOf(1));
		}
		
		log.info("Create and Store a Certificate for Mock with serial number :" + serialNumber);
	
		//creation
		CertificatePK cert = CryptographicTools.certificateForIDP(serialNumber, NOT_BEFORE, NOT_AFTER, SIGNATURE_ALGORITHM, KEY_SIZE);
		
		//transformation
		String content = CryptographicTools.certificatePKToPemString(cert, privateKeyPassphrase);
		
		try {
			IdentityProviderCertificate certificate = new IdentityProviderCertificate();
			certificate.setSerialNumber(serialNumber);
			certificate.setCertificate(content);
			certificate.setCreationDate(new java.util.Date());
			
			identityProviderServices.storeIdentityProviderCertificate(null ,certificate);
		} catch (UnauthorizedActionException | com.bnppa.sesame.services.internal.exception.v2.TechnicalException | InvalidParameterException e) {
			throw new TechnicalException(e);
		}
	}
}
