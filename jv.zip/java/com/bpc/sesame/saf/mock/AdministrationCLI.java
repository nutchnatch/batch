package com.bpc.sesame.saf.mock;

import gencl.sesame.services.standard.proxy.AuthenticationServicesWSP;
import gencl.sesame.services.standard.proxy.AuthenticationServicesWSPService;
import gentypes.saml.metadata.v20.EntityDescriptorType;

import java.io.File;
import java.math.BigInteger;
import java.nio.file.Files;
import java.sql.Date;
import java.util.Arrays;
import java.util.List;

import javax.xml.ws.BindingProvider;

import joptsimple.OptionException;
import joptsimple.OptionParser;
import joptsimple.OptionSet;
import joptsimple.OptionSpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean;

import com.bnppa.sesame.services.internal.model.v2.IdentityProviderCertificate;
import com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel;
import com.bnppa.sesame.services.internal.model.v2.ServiceProvider;
import com.bnppa.sesame.services.internal.v2.IdentityProviderServices;
import com.bnppa.sesame.services.internal.v2.ServiceProvidersServices;
import com.bpc.sesame.saf.model.CertificatePK;
import com.bpc.sesame.saf.util.CryptographicTools;
import com.bpc.sesame.saf.util.XmlTools;
import com.bpc.sesame.safadmin.api.IdentityProviderTasks;

/**
 * CLI interface for the admin tool based on https://pholser.github.io/jopt-simple/ 
 * A Description of the tools is available with the string GLOBAL_DESCRIPTION below.
 * @author 483838
 */
public class AdministrationCLI {
	
	private static final Logger log = LoggerFactory.getLogger(AdministrationCLI.class);
	
	private static final String SIGNATURE_ALGORITHM = "SHA256withRSA";
	private static final Date NOT_AFTER = Date.valueOf("2037-01-01");
	private static final Date NOT_BEFORE = Date.valueOf("2016-01-01");
	private static final int DEFAULT_KEY_SIZE = 2048;
	
	private static final String GLOBAL_DESCRIPTION = 
			"\nGlobal Description\n------------------\nAllow simples administration tasks when SAFADMIN is not available."
			+ "\n\nAvailable actions\n-----------------\n"
			+ "initIdpCerts   : If the idp has no certificates this action will create the current and the next ones.\n"
			+ "addSP          : Add (Declare, register) a service provider in SAF.\n"
			+ "getIDPMetadata : Get the IDP metadata of SAF.\n"
			+ "getIDPInfo     : Get the IDP information from Sesame Services.\n";
	
	public static  enum Action { initIdpCerts, addSP, getIDPMetadata, getIDPInfo;	}
	
	public static void main(String[] args) {
		try {
			boolean success = new AdministrationCLI().launch(args);
			if (!success) {
				System.exit(-1);
			}
		} catch (Exception e) {
			log.error("Fatal Error on admin command :", e);
			System.exit(-1);
		}
	}
	
	/**
	 * Default Constructor
	 */
	private AdministrationCLI() {}
	
	/**
	 * Constructor for testing purpose
	 * @param authenticationService
	 * @param identityProviderService
	 * @param serviceProvidersService
	 */
	protected AdministrationCLI(
			AuthenticationServicesWSP authenticationService, 
			IdentityProviderServices identityProviderService,
			ServiceProvidersServices serviceProvidersService) {
		this.authenticationService = authenticationService;
		this.identityProviderService = identityProviderService;
		this.serviceProvidersService = serviceProvidersService;
	}
	
	//Endpoint
	private AuthenticationServicesWSP authenticationService;
	private IdentityProviderServices identityProviderService;
	private ServiceProvidersServices serviceProvidersService;
	

	protected boolean launch(String[] args) throws Exception {
		
		OptionParser parser = new OptionParser();
		
		//help
		OptionSpec<Void> helpOption= parser.accepts( "h", "show help" ).forHelp();
		
		//Action
		OptionSpec<Action> actionOption = parser
				.accepts("action", "Which action to execute. Available values " + Arrays.toString(Action.values()))
				.withRequiredArg()
				.ofType( Action.class )
				.required();
		
		//Admin Login
		OptionSpec<String> adminLoginOption = parser
				.accepts("login", "The login of the SAF adminstrator.")
				.withRequiredArg()
				.ofType( String.class )
				.required();
		
		//Admin Password
		OptionSpec<String> adminPasswordOption = parser
				.accepts("password", "The password of the SAF adminstrator.")
				.withRequiredArg()
				.ofType( String.class )
				.required();
		
		//Sesame Service URL
		OptionSpec<String> sesameURLOption = parser
				.accepts("sesame-url", "The base url of sesame services")
				.withRequiredArg()
				.ofType( String.class )
				.defaultsTo("http://localhost:8080");
		
		//keySize
		OptionSpec<Integer> keySizeOption = parser
				.accepts("key-size", "The RSA key size for the IDP certificates. (use with action : " + Action.initIdpCerts + ")")
				.withRequiredArg()
				.ofType( Integer.class )
				.defaultsTo(DEFAULT_KEY_SIZE);
		
		//passphrase
		OptionSpec<String> passphraseOption = parser
				.accepts("passphrase", "The passphrase used to store the private key of the certificates IDP.")
				.withRequiredArg()
				.ofType( String.class );
		
		//sp metadata
		OptionSpec<File> spMetadataOption = parser
				.accepts( "sp-metadata", "The path to the metadata of the service provider. (use with action : " + Action.initIdpCerts + ")")
				.withRequiredArg()
				.ofType( File.class )
				.defaultsTo(new File("sp.xml"));
		
		//application domain
		OptionSpec<String> applicationDomainOption = parser
				.accepts( "application-domain", "The sesame application domain of the service provider. (use with action : " + Action.initIdpCerts + ")")
				.withRequiredArg()
				.ofType( String.class )
				.defaultsTo("SAF");
		
		//idp entityID
		OptionSpec<String> idpEntityIdOption = parser
				.accepts( "idp-entity-id", "The entityID of the SAF identity provider. (use with action : " + Action.getIDPMetadata + ")")
				.withRequiredArg()
				.ofType( String.class )
				.defaultsTo("urn:cardif:saf:idp:sesame");
		
		//idp entityID
		OptionSpec<String> idpURLOption = parser
				.accepts( "idp-url", "The base URL of the SAF identity provider, for example http://localhost:8080/sesame_saf/. (use with action : " + Action.getIDPMetadata + ")")
				.withRequiredArg()
				.ofType( String.class );

		//sp metadata
		OptionSpec<File> idpMetadataOption = parser
				.accepts( "idp-metadata", "The path to the metadata of the SAF identity provider. (use with action : " + Action.getIDPMetadata + ")")
				.withRequiredArg()
				.ofType( File.class )
				.defaultsTo(new File("idp.xml"));
		
		//PARSE THE ARGUMENTS
		OptionSet options = null;
		try {
			options = parser.parse(args);
		} catch (OptionException e) {
			System.out.println("Error : " + e.getMessage());
			System.out.println(GLOBAL_DESCRIPTION);
			parser.printHelpOn(System.out);
			return false;
		}
		
		if (options.has(helpOption)) {
			System.out.println(GLOBAL_DESCRIPTION);
			parser.printHelpOn(System.out);
			return true;
		}
		
		//Valid the arguments
		String errors = "";
		Action action = options.valueOf(actionOption);
		String login = options.valueOf(adminLoginOption).trim();
		String password = options.valueOf(adminPasswordOption).trim();
		String sesameURL = options.valueOf(sesameURLOption).trim();
		Integer keySize = options.valueOf(keySizeOption);
		String passphrase = options.has(passphraseOption)?options.valueOf(passphraseOption).trim():null;
		String applicationDomain = options.valueOf(applicationDomainOption).trim();
		String idpEntityId = options.valueOf(idpEntityIdOption).trim();
		File idpMetadata = options.valueOf(idpMetadataOption);
		
		
		//sp metadata
		File spMetadata = options.valueOf(spMetadataOption);
		if (action == Action.addSP && !spMetadata.exists()) {
			errors += "\nError : The sp file '" + spMetadata.toString() + "' doesn't exists.";
		}
		
		//passphrase
		if (action == Action.initIdpCerts && (passphrase == null || passphrase.length()==0)) {
			errors += "\nError : The passphrase is mandatory with the action " + Action.initIdpCerts;
		}
		
		//idp url
		String idpURL =  options.has(idpURLOption)?options.valueOf(idpURLOption).trim():null;
		if (action == Action.getIDPMetadata) {
			if ((idpURL == null || idpURL.length()==0)) {
				errors += "\nError : The idp-url is mandatory with the action " + Action.getIDPMetadata;
			} else if (!idpURL.endsWith("/")) {
				idpURL = idpURL + "/";
			}
		}
		
		//display error
		errors = errors.trim();
		if (errors.length() > 0) {
			System.out.println(errors);
			return false;
		}
		
		if (action == Action.initIdpCerts) {
			initializeIDPCertificates(sesameURL, login, password, keySize, passphrase);
		} else if (action == Action.addSP) {
			createServiceProvider(sesameURL, login, password, spMetadata, applicationDomain);
		} else if (action == Action.getIDPMetadata) {
			getIDPMetadata(sesameURL, login, password, idpEntityId, idpURL, idpMetadata);
		} else if (action == Action.getIDPInfo) {
			getIDPInfo(sesameURL, login, password);
		}
		
		return true;
	}
	
	private void createServiceProvider(String sesameURL, String login, String password, File spMetadata, String applicationDomain) throws Exception {

		String token = loginAdmin(sesameURL, login, password);

		try {
			System.out.println("Step 1 - validate the metadata File");
			String metadataXml = new String(Files.readAllBytes(spMetadata.toPath()),"UTF-8");
			EntityDescriptorType metadata = XmlTools.stringToEntityDescriptorType(metadataXml);
			System.out.println("Step 1 - OK");
			
			System.out.println("Step 2 - add the service provider");
			ServiceProvider serviceProvider = new ServiceProvider();
			serviceProvider.setApplicationDomain(applicationDomain);
			serviceProvider.setAuthLevel(SAFAuthLevel.HIGH);
			serviceProvider.setEntityId(metadata.getEntityID());
			serviceProvider.setLabel("TO_CHANGE");
			serviceProvider.setId("TO_CHANGE");
			serviceProvider.setMetaData(metadataXml);
			getServiceProvidersServices(sesameURL).createServiceProvider(token, serviceProvider);
			System.out.println("Step 2 - OK");
		} finally {
			logoutAdmin(sesameURL, token);
		}
	}

	private void initializeIDPCertificates(String sesameURL, String login, String password, Integer keySize, String passphrase) throws Exception {
		
		String token = loginAdmin(sesameURL, login, password);

		try {
			System.out.println("Step 1 - check that the IDP has no certificates.");
			
			List<IdentityProviderCertificate> certs = getIdentityProviderServices(sesameURL).getIdentityProviderCertificatesInfo(token);
			if (certs != null && certs.size() > 0) {
				System.out.println("Step 1 - Failed, IDP has already " + certs.size() + " certificates.");
				return;
			}
			System.out.println("Step 1 - OK");

			System.out.println("Step 2 - create the current certificate.");
			createIDPCertificate(sesameURL, token, BigInteger.ONE, keySize, passphrase);
			getIdentityProviderServices(sesameURL).setCurrentIdentityProviderCertificate(token, BigInteger.ONE);
			System.out.println("Step 2 - OK");

			System.out.println("Step 3 - create the next certificate.");
			createIDPCertificate(sesameURL, token, BigInteger.valueOf(2), keySize, passphrase);
			getIdentityProviderServices(sesameURL).setNextIdentityProviderCertificate(token, BigInteger.valueOf(2));
			System.out.println("Step 3 - OK");

		} finally {
			logoutAdmin(sesameURL, token);
		}
	}
	
	private void getIDPMetadata(String sesameURL, String login, String password, String entityIdIDP, String safURL, File metatadataFile) throws Exception {
		
		String token = loginAdmin(sesameURL, login, password);

		try {
			IdentityProviderServices identityProviderServices = getIdentityProviderServices(sesameURL);
			
			System.out.println("Step 1 - Retrieve Current Certifificate.");
			IdentityProviderCertificate current = identityProviderServices.getCurrentIdentityProviderCertificate(token);
			if (current == null) {
				System.out.println("Step 1 - Error : current certificate is null.");
				return;
			}
			System.out.println("Step 1 - OK");
			
			System.out.println("Step 2 - Retrieve Next Certifificate.");
			IdentityProviderCertificate next = identityProviderServices.getNextIdentityProviderCertificate(token);
			if (next == null) {
				System.out.println("Step 1 - Error : next certificate is null.");
				return;
			}
			System.out.println("Step 2 - OK");

			System.out.println("Step 3 - Generates the IDP metadata to file " + metatadataFile.getName());
			CertificatePK currentCertificate = CryptographicTools.pemStringToCertificatePK(current.getCertificate(), null);
			CertificatePK nextCertificate = CryptographicTools.pemStringToCertificatePK(next.getCertificate(), null);
			String metadata = IdentityProviderTasks.generateMetadata(entityIdIDP, safURL, currentCertificate.getCertificate(), nextCertificate.getCertificate());
			Files.write(metatadataFile.toPath(), metadata.getBytes("UTF-8"));
			System.out.println("Step 3 - OK");

		} finally {
			logoutAdmin(sesameURL, token);
		}
	}

	private void getIDPInfo(String sesameURL, String login, String password) throws Exception {

		String token = loginAdmin(sesameURL, login, password);

		try {
			IdentityProviderServices identityProviderServices = getIdentityProviderServices(sesameURL);

			System.out.println("Step 1 - Retrieve Current Certifificate.");
			IdentityProviderCertificate current = identityProviderServices.getCurrentIdentityProviderCertificate(token);
			if (current == null) {
				System.out.println("Step 1 - Error : current certificate is null.");
				return;
			}
			System.out.println("Step 1 - Current Certificate : \n" + current.getCertificate());
			System.out.println("Step 1 - Current SerialNumber : " + current.getSerialNumber());
			System.out.println("Step 1 - Current CreationDate : " + current.getCreationDate());

			System.out.println("Step 2 - Retrieve Next Certifificate.");
			IdentityProviderCertificate next = identityProviderServices.getNextIdentityProviderCertificate(token);
			if (next == null) {
				System.out.println("Step 2 - Error : next certificate is null.");
				return;
			}
			System.out.println("Step 2 - Next Certificate : \n" + next.getCertificate());
			System.out.println("Step 2 - Next SerialNumber : " + next.getSerialNumber());
			System.out.println("Step 2 - Next CreationDate : " + next.getCreationDate());
		} finally {
			logoutAdmin(sesameURL, token);
		}
	}
	
    private String loginAdmin(String sesameURL, String login, String password) throws Exception {
		System.out.println("Login the admin");
		String token = getAuthenticationServices(sesameURL).loginInUserRef(login, password, "GROUP");
		System.out.println("Login the admin - OK");
		return token;
	}
    
    private void logoutAdmin(String sesameURL, String token) throws Exception {
		System.out.println("Logout the administrator");
		getAuthenticationServices(sesameURL).logout(token);
		System.out.println("Logout the administrator - OK");
	}

	private void createIDPCertificate(String sesameURL, String token, BigInteger serialNumber, Integer keySize, String passphrase) throws Exception {
    	CertificatePK certificatePK = CryptographicTools.certificateForIDP(serialNumber, NOT_BEFORE, NOT_AFTER, SIGNATURE_ALGORITHM, keySize);
		IdentityProviderCertificate certificate = new IdentityProviderCertificate();
		String pem = CryptographicTools.certificatePKToPemString(certificatePK, passphrase.toCharArray());
		certificate.setCertificate(pem);
		certificate.setCreationDate(new java.util.Date());
		certificate.setSerialNumber(serialNumber);
		getIdentityProviderServices(sesameURL).storeIdentityProviderCertificate(token, certificate);
	}

	private AuthenticationServicesWSP getAuthenticationServices(String sesameURL) {
		if (authenticationService!=null) {
			return authenticationService;
		}
		authenticationService = new AuthenticationServicesWSPService().getAuthenticationServicesWSP();
		((BindingProvider)authenticationService).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, sesameURL + "/sesame_services/services/AuthenticationServicesWSP");
		return authenticationService;
	}

	private ServiceProvidersServices getServiceProvidersServices(String sesameURL) throws Exception {
		if (serviceProvidersService!=null) {
			return serviceProvidersService;
		}
		HttpInvokerProxyFactoryBean factory = new HttpInvokerProxyFactoryBean();
		factory.setServiceUrl(sesameURL + "/sesame_services/Remote/RemoteHttpBean/ServiceProvidersServices");
		factory.setServiceInterface(ServiceProvidersServices.class);
		factory.afterPropertiesSet();
		return (ServiceProvidersServices) factory.getObject();
    }

	private IdentityProviderServices getIdentityProviderServices(String sesameURL) throws Exception {
		if (identityProviderService!=null) {
			return identityProviderService;
		}
		HttpInvokerProxyFactoryBean factory = new HttpInvokerProxyFactoryBean();
		factory.setServiceUrl(sesameURL + "/sesame_services/Remote/RemoteHttpBean/IdentityProviderServices");
		factory.setServiceInterface(IdentityProviderServices.class);
		factory.afterPropertiesSet();
		return (IdentityProviderServices) factory.getObject();
    }
}