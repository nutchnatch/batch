package com.bpc.sesame.saf.mock;

import static com.bpc.sesame.saf.mock.TLSClient.NO_ROLES;
import static com.bpc.sesame.saf.mock.TLSClient.REVOKE;
import static com.bpc.sesame.saf.mock.TLSClient.SMARTCARD;
import static com.bpc.sesame.saf.mock.TLSClient.SOFTPKI;
import static com.bpc.sesame.saf.mock.TLSClient.UNKNOWN;
import static com.bpc.sesame.saf.mock.TLSClient.WITHOUT_DNSNAME;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.X509CRL;
import java.security.cert.X509CRLEntry;
import java.security.cert.X509Certificate;
import java.sql.Date;
import java.util.Arrays;
import java.util.List;

import joptsimple.OptionException;
import joptsimple.OptionParser;
import joptsimple.OptionSet;
import joptsimple.OptionSpec;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bpc.sesame.saf.exception.ConfigurationException;
import com.bpc.sesame.saf.model.CertificatePK;
import com.bpc.sesame.saf.util.CryptographicTools;

/**
 * CLI interface for the cert-gen tool based on https://pholser.github.io/jopt-simple/ 
 * A Description of the tools is available with the string GLOBAL_DESCRIPTION below.
 * @author 483838
 */
public class CertificateGeneratorCLI {
	
	private static final Logger log = LoggerFactory.getLogger(CertificateGeneratorCLI.class);
	
	private static final String GOOD_SERVER_CA		= "00 Good Server CA";
	private static final String GOOD_CLIENT_CA 		= "00 Good Client CA";
	private static final String UNKNOWN_CLIENT_CA	= "00 Unknown Client CA";
	private static final String GOOD_SERVER			= "safserver.local";
	
	private static final String DEFAULT_SIGNATURE_ALGORITHM = "SHA256withRSA";
	private static final Date DEFAULT_NOT_AFTER = Date.valueOf("2037-01-01");
	private static final Date DEFAULT_NOT_BEFORE = Date.valueOf("2016-01-01");
	private static final int DEFAULT_KEY_SIZE = 2048;
	
	public static final String CASERVER_KEYSTORE_NAME = "CAServerKeyStore.p12";
	public static final String SERVER_KEYSTORE_NAME = "ServerKeyStore.p12";
	public static final String SERVER_TRUSTSTORE_NAME = "ServerTrustStore.p12";
	public static final String CLIENT_TRUSTSTORE_NAME = "ClientTrustStore.p12";
	public static final String CACLIENT_KEYSTORE_NAME = "CAClientKeyStore.p12";
	public static final String CRL_NAME = "crl.pem";
	public static final String CLIENT_KEYSTORE_NAME_PRE = "ClientKeyStore-";
	public static final String CLIENT_KEYSTORE_NAME_SUF = ".p12";
	
	public static final String GOOD_SERVERCA_CERT_PEM 	= "goodServerCA_certificate.pem";
	public static final String GOOD_SERVER_CERT_PEM 	= "goodServer_certificate.pem";
	public static final String GOOD_SERVER_PK_PEM 		= "goodServer_privatekey.pem";
	public static final String GOOD_CLIENTCA_CERT_PEM 	= "goodClientCA_certificate.pem";
	
	
	private static final char[] KEYSTORE_PASSWORD = "pass".toCharArray();
	private static final char[] PRIVATEKEY_PASSWORD = "pass".toCharArray();
	
	private static final String GLOBAL_DESCRIPTION = 
			"\nGlobal Description\n------------------\nGenerates TLS Certificates and Keystores for SAF mock and SAF clients."
			+ "\n\nAvailable actions\n-----------------\n"
			+ "caServer    : Generates the certificate for CA of server.\n"
			+ "server      : Generates the 2 certificates for both CA of clients.\n"
			+ "caClient    : Generates the 2 certificates for both CA of clients.\n"
			+ "client      : Generates the 5 certificates for a given client.\n"
			+ "crl         : Create an empty CRL file.\n"
			+ "crlUpdate   : Update the CRL file with a given client.\n";
	
	public static  enum Action { caServer, server, caClient,	client,	crl, crlUpdate;	}
	
	public static void main(String[] args) {
		try {
			boolean success = new CertificateGeneratorCLI().launch(args);
			if (!success) {
				System.exit(-1);
			}
		} catch (Exception e) {
			log.error("Fatal Error on cert-gen command :", e);
			System.exit(-1);
		}
	}
	
	public boolean launch(String[] args) throws Exception {
		OptionParser parser = new OptionParser();
		
		//help
		OptionSpec<Void> helpOption= parser.accepts( "h", "show help" ).forHelp();
		
		//Action
		OptionSpec<Action> actionOption = parser
				.accepts("action", "Which action to execute. Available values " + Arrays.toString(Action.values()))
				.withRequiredArg()
				.ofType( Action.class )
				.required();
		
		//Signature Algorithm
		OptionSpec<String> signatureAlgoOption = parser
				.accepts("signature-algo", "The Signature alogorithm used to create the certificates (must be RSA one).")
				.withRequiredArg()
				.ofType( String.class )
				.defaultsTo(DEFAULT_SIGNATURE_ALGORITHM);
		
		//client uid
		OptionSpec<String> clientUidOption = parser
				.accepts("client-uid", "The client uid.")
				.withRequiredArg()
				.ofType( String.class );
		
		//keySize
		OptionSpec<Integer> keySizeOption = parser
				.accepts("key-size", "The RSA key size for the certificate.")
				.withRequiredArg()
				.ofType( Integer.class )
				.defaultsTo(DEFAULT_KEY_SIZE);
		

		//PARSE THE ARGUMENTS
		OptionSet options = null;
		try {
			options = parser.parse(args);
		} catch (OptionException e) {
			System.out.println("Error : " + e.getMessage());
			System.out.println(GLOBAL_DESCRIPTION);
			parser.printHelpOn(System.out);
			return false;
		}
		
		if (options.has(helpOption)) {
			System.out.println(GLOBAL_DESCRIPTION);
			parser.printHelpOn(System.out);
			return true;
		}
		
		//Valid the arguments
		String errors = "";
		Action action = options.valueOf(actionOption);
		String signatureAlgo = options.valueOf(signatureAlgoOption).trim();
		String clientUid = options.has(clientUidOption)?options.valueOf(clientUidOption).trim():null;
		Integer keySize = options.valueOf(keySizeOption);
		
		//client uid mandatory with client
		if ((action == Action.client || action == Action.crlUpdate) && clientUid==null) {
			errors += "\nError : the client-uid is mandatory with this action.";
		}
		
		//display error
		errors = errors.trim();
		if (errors.length() > 0) {
			System.out.println(errors);
			return false;
		}


		if (action == Action.caServer) {
			generateCAServer(signatureAlgo, keySize);
			System.out.println("Action 'caServer' done.");
			
		} else if (action == Action.server) {
			generateServer(signatureAlgo, keySize);
			System.out.println("Action 'server' done.");
			
		} else if (action == Action.caClient) {
			generateCAClient(signatureAlgo, keySize);
			System.out.println("Action 'caClient' done.");
			
		} else if (action == Action.client) {
			generateClient(clientUid, signatureAlgo, keySize);
			System.out.println("Action 'client' done.");
			
		} else if (action == Action.crl) {
			crlempty(signatureAlgo);
			System.out.println("Action 'crl' done.");
			
		} else if (action == Action.crlUpdate) {
			crlUpdate(clientUid, signatureAlgo);
			System.out.println("Action 'crlUpdate' done.");
			
		}
		
		return true;
	}
	
	private Path configMockDirectory;
	private Path configClientsDirectory;
	
	public static final Path TEST_DIR				= Paths.get("./target/_test/keystoresForTLS/");
	public static final Path MOCK_EMBED_DIR			= Paths.get("./src/test/config-mock/keystoresForTLS/");
	public static final Path MOCK_DIR				= Paths.get("./config-mock/keystoresForTLS/");
	public static final Path CLIENTS_EMBED_DIR		= Paths.get("./src/test/config-clients/keystoresForTLS/");
	public static final Path CLIENTS_DIR			= Paths.get("./config-clients/keystoresForTLS/");

	/**
	 * 
	 */
	public CertificateGeneratorCLI() {
		//Select the directories for storing the keystores
		if (Files.exists(TEST_DIR)) {
			configMockDirectory = TEST_DIR;
		} else if (Files.exists(MOCK_EMBED_DIR)) {
			configMockDirectory = MOCK_EMBED_DIR;
		} else if (Files.exists(MOCK_DIR)) {
			configMockDirectory = MOCK_DIR;
		} else {
			throw new ConfigurationException("Cannot found the configuration Directory for mock.");
		}
		
		if (Files.exists(TEST_DIR)) {
			configClientsDirectory = TEST_DIR;
		} else if (Files.exists(CLIENTS_EMBED_DIR)) {
			configClientsDirectory = CLIENTS_EMBED_DIR;
		} else if (Files.exists(CLIENTS_DIR)) {
			configClientsDirectory = CLIENTS_DIR;
		} else {
			throw new ConfigurationException("Cannot found the configuration Directory for clients.");
		}
	}
	
	public void generateCAServer(String signatureAlgorithm, int keySize) throws Exception {
		
		CertificatePK goodServerCA    = TLSClientTools.certificateForTestingCA(GOOD_SERVER_CA	, 1, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, signatureAlgorithm, keySize);

		//Keystore
		Path keystorePath = configMockDirectory.resolve(CASERVER_KEYSTORE_NAME);
		KeyStore serverKeyStore = KeyStore.getInstance("PKCS12", new BouncyCastleProvider());
		serverKeyStore.load( null, null );
		serverKeyStore.setKeyEntry(GOOD_SERVER_CA, goodServerCA.getPrivateKey(), PRIVATEKEY_PASSWORD, new Certificate[]{goodServerCA.getCertificate()});
		try (OutputStream outputStream = new FileOutputStream(keystorePath.toFile());) {
			serverKeyStore.store(outputStream, KEYSTORE_PASSWORD);
		}
		log.info(keystorePath.toAbsolutePath() + " created.");
		
		//clientTrustStore
		Path trustStorePath = configClientsDirectory.resolve(CLIENT_TRUSTSTORE_NAME);
		KeyStore clientTrustStore = KeyStore.getInstance("PKCS12", new BouncyCastleProvider());
		clientTrustStore.load( null, null );
		clientTrustStore.setCertificateEntry(GOOD_SERVER_CA, goodServerCA.getCertificate());
		try (OutputStream outputStream = new FileOutputStream(trustStorePath.toFile());) {
			clientTrustStore.store(outputStream, KEYSTORE_PASSWORD);
		}
		log.info(trustStorePath.toAbsolutePath()+" created.");
		
		//specific
		String pemContent = CryptographicTools.objectToPemString(goodServerCA.getCertificate());
		Path pemFile = configMockDirectory.resolve(GOOD_SERVERCA_CERT_PEM);
		Files.write(pemFile, pemContent.getBytes());
		log.info(pemFile.toAbsolutePath() + " created.");
	}
	
	public void generateServer(String signatureAlgorithm, int keySize) throws Exception {
		Path caKeystorePath = configMockDirectory.resolve(CASERVER_KEYSTORE_NAME);
		if (Files.notExists(caKeystorePath)) {
			throw new ConfigurationException("The CA keystore doesn't exists : " + caKeystorePath.toAbsolutePath());
		}
		
		CertificatePK goodServerCA = CryptographicTools.extractCertificatePKFromKeystore(caKeystorePath, GOOD_SERVER_CA, KEYSTORE_PASSWORD, PRIVATEKEY_PASSWORD);
		CertificatePK goodServer = TLSClientTools.certificateForTestingServer(goodServerCA, GOOD_SERVER, 2, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, signatureAlgorithm, keySize);
		
		Path keystorePath = configMockDirectory.resolve(SERVER_KEYSTORE_NAME);
		KeyStore serverKeyStore = KeyStore.getInstance("PKCS12", new BouncyCastleProvider());
		serverKeyStore.load( null, null );
		serverKeyStore.setKeyEntry(GOOD_SERVER, goodServer.getPrivateKey(), PRIVATEKEY_PASSWORD, new Certificate[]{goodServer.getCertificate(),goodServerCA.getCertificate()});
		try (OutputStream outputStream = new FileOutputStream(keystorePath.toFile());) {
			serverKeyStore.store(outputStream, KEYSTORE_PASSWORD);
		}
		log.info(keystorePath.toAbsolutePath() + " created.");
		
		//specific
		String pemContent = CryptographicTools.objectToPemString(goodServer.getCertificate());
		Path pemFile = configMockDirectory.resolve(GOOD_SERVER_CERT_PEM);
		Files.write(pemFile, pemContent.getBytes());
		log.info(pemFile.toAbsolutePath()+" created.");
		pemContent = CryptographicTools.objectToPemString(goodServer.getPrivateKey());
		pemFile = configMockDirectory.resolve(GOOD_SERVER_PK_PEM);
		Files.write(pemFile, pemContent.getBytes());
		log.info(pemFile.toAbsolutePath()+" created.");
	}
	
	public void generateCAClient(String signatureAlgorithm, int keySize) throws Exception {
		
		
		CertificatePK goodClientCA    = TLSClientTools.certificateForTestingCA(GOOD_CLIENT_CA		, 1, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, signatureAlgorithm, keySize);
		CertificatePK unknownClientCA = TLSClientTools.certificateForTestingCA(UNKNOWN_CLIENT_CA	, 1, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, signatureAlgorithm, keySize);

		//KeyStore
		Path keystorePath = configClientsDirectory.resolve(CACLIENT_KEYSTORE_NAME);
		KeyStore clientCAKeyStore = KeyStore.getInstance("PKCS12", new BouncyCastleProvider());
		clientCAKeyStore.load( null, null );
		clientCAKeyStore.setKeyEntry(GOOD_CLIENT_CA, 	goodClientCA.getPrivateKey(), PRIVATEKEY_PASSWORD, new Certificate[]{goodClientCA.getCertificate()});
		clientCAKeyStore.setKeyEntry(UNKNOWN_CLIENT_CA, unknownClientCA.getPrivateKey(), PRIVATEKEY_PASSWORD, new Certificate[]{unknownClientCA.getCertificate()});
		try (OutputStream outputStream = new FileOutputStream(keystorePath.toFile());) {
			clientCAKeyStore.store(outputStream, KEYSTORE_PASSWORD);
		}
		log.info(keystorePath.toAbsolutePath() + " created.");
		
		//Official BNPP certificate
		X509Certificate bnppRoot = CryptographicTools.extractCertificateFromClasspath("certificates/2014-2044_bnpp_root.pem");
		X509Certificate bnppUsers = CryptographicTools.extractCertificateFromClasspath("certificates/2014-2029_bnpp_users_authentication.pem");
		
		//TrustStore
		Path trustStorePath = configMockDirectory.resolve(SERVER_TRUSTSTORE_NAME);
		KeyStore serverTrustStore = KeyStore.getInstance("PKCS12", new BouncyCastleProvider());
		serverTrustStore.load( null, null );
		serverTrustStore.setCertificateEntry(GOOD_CLIENT_CA, goodClientCA.getCertificate());
		serverTrustStore.setCertificateEntry("bnppRoot", bnppRoot);
		serverTrustStore.setCertificateEntry("bnppUsers", bnppUsers);
		try (OutputStream outputStream = new FileOutputStream(trustStorePath.toFile());) {
			serverTrustStore.store(outputStream, KEYSTORE_PASSWORD);
		}
		log.info(trustStorePath.toAbsolutePath() + " created.");
		
		//specific
		String pemContent = CryptographicTools.objectToPemString(goodClientCA.getCertificate());
		Path pemFile = configClientsDirectory.resolve(GOOD_CLIENTCA_CERT_PEM);
		Files.write(pemFile, pemContent.getBytes());
		pemContent = CryptographicTools.objectToPemString(bnppRoot);
		Files.write(pemFile, pemContent.getBytes(), StandardOpenOption.APPEND);
		pemContent = CryptographicTools.objectToPemString(bnppUsers);
		Files.write(pemFile, pemContent.getBytes(), StandardOpenOption.APPEND);
		log.info(pemFile.toAbsolutePath() + " created.");
	}
	
	
	
	public void generateClient(String uid, String signatureAlgorithm, int keySize) throws Exception {
		
		Path caKeystorePath = configClientsDirectory.resolve(CACLIENT_KEYSTORE_NAME);
		if (Files.notExists(caKeystorePath)) {
			throw new ConfigurationException("The CA keystore doesn't exists : " + caKeystorePath.toAbsolutePath());
		}
		Path keystorePath = configClientsDirectory.resolve(CLIENT_KEYSTORE_NAME_PRE + uid + CLIENT_KEYSTORE_NAME_SUF);
		
		CertificatePK goodClientCA = CryptographicTools.extractCertificatePKFromKeystore(caKeystorePath, GOOD_CLIENT_CA, KEYSTORE_PASSWORD, PRIVATEKEY_PASSWORD);
		CertificatePK unknownClientCA = CryptographicTools.extractCertificatePKFromKeystore(caKeystorePath, UNKNOWN_CLIENT_CA, KEYSTORE_PASSWORD, PRIVATEKEY_PASSWORD);
		
		//milliseconds from 11/07/2016 to emulate a serial number without collision
		long nextSerialNumber = System.currentTimeMillis() - 1468256937543l;
		
		CertificatePK smartCardClient = TLSClientTools.certificateForTestingClient(goodClientCA,    SMARTCARD, uid, nextSerialNumber, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, signatureAlgorithm, keySize, true, true, true);
		CertificatePK softClient      = TLSClientTools.certificateForTestingClient(goodClientCA,    SOFTPKI,   uid,   nextSerialNumber+1, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, signatureAlgorithm, keySize, true, false, true);
		CertificatePK noRolesClient   = TLSClientTools.certificateForTestingClient(goodClientCA,    NO_ROLES, uid,  nextSerialNumber+2, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, signatureAlgorithm, keySize, false, false, true);
		CertificatePK unknownClient   = TLSClientTools.certificateForTestingClient(unknownClientCA, UNKNOWN, uid,   nextSerialNumber, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, signatureAlgorithm, keySize, true, true, true);
		CertificatePK revokeClient    = TLSClientTools.certificateForTestingClient(goodClientCA,   	REVOKE, uid,    nextSerialNumber+3, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, signatureAlgorithm, keySize, true, true, true);
		CertificatePK withoutDnsClient = TLSClientTools.certificateForTestingClient(goodClientCA,   WITHOUT_DNSNAME, uid, nextSerialNumber+4, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER, signatureAlgorithm, keySize, true, true, true);
		
		
		KeyStore clientKeyStore = KeyStore.getInstance("PKCS12", new BouncyCastleProvider());
		clientKeyStore.load( null, null );
		clientKeyStore.setKeyEntry(SMARTCARD.toString(), smartCardClient.getPrivateKey(), PRIVATEKEY_PASSWORD, new Certificate[]{smartCardClient.getCertificate(), goodClientCA.getCertificate()});
		clientKeyStore.setKeyEntry(SOFTPKI.toString(), softClient.getPrivateKey(), PRIVATEKEY_PASSWORD, new Certificate[]{softClient.getCertificate(), goodClientCA.getCertificate()});
		clientKeyStore.setKeyEntry(NO_ROLES.toString(), noRolesClient.getPrivateKey(), PRIVATEKEY_PASSWORD, new Certificate[]{noRolesClient.getCertificate(), goodClientCA.getCertificate()});
		clientKeyStore.setKeyEntry(REVOKE.toString(), revokeClient.getPrivateKey(), PRIVATEKEY_PASSWORD, new Certificate[]{revokeClient.getCertificate(), goodClientCA.getCertificate()});
		clientKeyStore.setKeyEntry(UNKNOWN.toString(), unknownClient.getPrivateKey(), PRIVATEKEY_PASSWORD, new Certificate[]{unknownClient.getCertificate(), unknownClientCA.getCertificate()});
		clientKeyStore.setKeyEntry(WITHOUT_DNSNAME.toString(), withoutDnsClient.getPrivateKey(), PRIVATEKEY_PASSWORD, new Certificate[]{withoutDnsClient.getCertificate(), goodClientCA.getCertificate()});
		try (OutputStream outputStream = new FileOutputStream(keystorePath.toFile());) {
			clientKeyStore.store(outputStream, KEYSTORE_PASSWORD);
		}
		log.info(keystorePath.toAbsolutePath() + " created.");
	}
	
	public void crlempty(String signatureAlgo) throws Exception {
		
		Path caKeystorePath = configClientsDirectory.resolve(CACLIENT_KEYSTORE_NAME);
		if (Files.notExists(caKeystorePath)) {
			throw new ConfigurationException("The CA keystore doesn't exists : " + caKeystorePath.toAbsolutePath());
		}
		Path crlPem = configClientsDirectory.resolve(CRL_NAME);
		
		CertificatePK goodClientCA = CryptographicTools.extractCertificatePKFromKeystore(caKeystorePath, GOOD_CLIENT_CA, KEYSTORE_PASSWORD, PRIVATEKEY_PASSWORD);

		X509CRL crlempty = CryptographicTools.crl(goodClientCA, null, null, signatureAlgo, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER);
		String crlemptyContent = CryptographicTools.objectToPemString(crlempty);
		Files.write(crlPem, crlemptyContent.getBytes());
		log.info(crlPem.toAbsolutePath() + " created");
	}
	
	public void crlUpdate(String uid, String signatureAlgo) throws Exception {
		
		Path caKeystorePath = configClientsDirectory.resolve(CACLIENT_KEYSTORE_NAME);
		if (Files.notExists(caKeystorePath)) {
			throw new ConfigurationException("The CA keystore doesn't exists : " + caKeystorePath.toAbsolutePath());
		}
		Path crlPem = configClientsDirectory.resolve(CRL_NAME);
		if (Files.notExists(crlPem)) {
			throw new ConfigurationException("The CRL pem file doesn't exists : " + crlPem.toAbsolutePath());
		}
		Path revokedClientKeystore = configClientsDirectory.resolve(CLIENT_KEYSTORE_NAME_PRE + uid + CLIENT_KEYSTORE_NAME_SUF);
		if (Files.notExists(revokedClientKeystore)) {
			throw new ConfigurationException("The user '" +uid + "' keystore doesn't exists : " + revokedClientKeystore.toAbsolutePath());
		}
		
		CertificatePK goodClientCA = CryptographicTools.extractCertificatePKFromKeystore(caKeystorePath, GOOD_CLIENT_CA, KEYSTORE_PASSWORD, PRIVATEKEY_PASSWORD);
		CertificatePK revokeClient = CryptographicTools.extractCertificatePKFromKeystore(revokedClientKeystore, TLSClient.REVOKE.toString(), KEYSTORE_PASSWORD, PRIVATEKEY_PASSWORD);
		
		List<X509CRLEntry> existingEntries = CryptographicTools.extractEntriesFromCRL(crlPem);
		
		//CRL - with one entry
		X509CRL crl = CryptographicTools.crl(goodClientCA, existingEntries, Arrays.asList(revokeClient), signatureAlgo, DEFAULT_NOT_BEFORE, DEFAULT_NOT_AFTER);
		String crlContent = CryptographicTools.objectToPemString(crl);
		Files.write(crlPem, crlContent.getBytes());
		log.info(crlPem.toAbsolutePath() + " updated");
	}
}
