package com.bpc.sesame.saf.mock;

import gentypes.saml.protocol.v20.AuthnRequestType;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.security.Security;
import java.util.Arrays;

import joptsimple.OptionException;
import joptsimple.OptionParser;
import joptsimple.OptionSet;
import joptsimple.OptionSpec;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bpc.sesame.saf.mock.ServiceProviderImpl.Binding;
import com.bpc.sesame.saf.mock.ServiceProviderImpl.SignatureAlgo;
import com.bpc.sesame.saf.mock.ServiceProviderImpl.SignatureState;
import com.bpc.sesame.saf.util.XmlTools;

/**
 * CLI interface for the client tool based on https://pholser.github.io/jopt-simple/ 
 * This interface encapsulate ServiceProviderImpl. So, if you need the client : 
 * <li> use ServiceProviderImpl if you are a java program
 * <li> use ServiceProviderCLI, with client.cmd in command line in other cases.
 * @author 483838
 */
public class ServiceProviderCLI {
	
	private static final Logger log = LoggerFactory.getLogger(ServiceProviderCLI.class);
	
	static {
		Security.addProvider(new BouncyCastleProvider());
	}
	
	public static void main(String[] args) {
		try {
			boolean success = new ServiceProviderCLI().launch(args);
			if (!success) {
				System.exit(-1);
			}
		} catch (Exception e) {
			log.error("Fatal Error on admin command :", e);
			System.exit(-1);
		}
	}
	
	protected ServiceProviderCLI() {
	}
	
	protected boolean launch(String[] args) throws IOException {
		OptionParser parser = new OptionParser();
		
		//help
		OptionSpec<Void> helpOption = parser.accepts( "h", "show help" ).forHelp();
		
		//config Directory
		OptionSpec<File> configDirOption = parser
				.accepts( "config-dir", "The path to a directory containing the clients (sp) configuration files." )
				.withRequiredArg()
				.ofType( File.class )
				.defaultsTo(new File("config-clients/"));
		
		//idp metadata
		OptionSpec<File> idpMetadataOption = parser
				.accepts( "idp-metadata", "The path to the metadata of the identity provider." )
				.withRequiredArg()
				.ofType( File.class )
				.defaultsTo(new File("config-clients/idp.xml"));
		
		//sp entityId
		OptionSpec<String> serviceProviderEntityIdOption = parser
				.accepts("sp-entity-id", "The entityId of the serviceProvider.")
				.withRequiredArg()
				.ofType( String.class );
		
		//binding
		OptionSpec<Binding> bindingOption = parser
				.accepts("binding", "The bindings use by the serviceProvider to make "
						+ "the authentication request. Available values " + Arrays.toString(Binding.values()))
				.withRequiredArg()
				.ofType( Binding.class )
				.defaultsTo(Binding.REDIRECT);
		
		//signatureAlgo
		OptionSpec<SignatureAlgo> signatureAlgoOption = parser
				.accepts("signature-algo", "The signature algorithm use by the serviceProvider to make the "
						+ "authentication request. Available values " + Arrays.toString(SignatureAlgo.values()))
				.withRequiredArg()
				.ofType( SignatureAlgo.class )
				.defaultsTo(SignatureAlgo.SHA_256);
		
		//signatureState
		OptionSpec<SignatureState> signatureStateOption = parser
				.accepts("signature-state", "The state of the signature of the authentication request. "
						+ "Available values " + Arrays.toString(SignatureState.values()))
				.withRequiredArg()
				.ofType( SignatureState.class )
				.defaultsTo(SignatureState.NORMAL);
		
		//attributesIndex
		OptionSpec<Integer> attributesIndexOption = parser
				.accepts("attributes-index", "Define the attribute AttributeConsumingServiceIndex in the request.")
				.withRequiredArg()
				.ofType( Integer.class );
		
		//clientCertificate
		OptionSpec<TLSClient> clientCertificateOption = parser
				.accepts("client-certificate", "The kind of certificate use by. Available values " + Arrays.toString(TLSClient.values()))
				.withRequiredArg()
				.ofType( TLSClient.class )
				.defaultsTo(TLSClient.SMARTCARD);
		
		//clientUid
		OptionSpec<String> clientUidOption = parser
				.accepts("client-uid", "The uid of the client, the client keystore must be available.")
				.withRequiredArg()
				.ofType( String.class );
		
		//timeshifting
		OptionSpec<Integer> timeShiftingOption = parser
				.accepts("time-shifting", "Create the request with a different time from now. The value is in "
						+ "seconds a can be positive or negative")
				.withRequiredArg()
				.ofType( Integer.class )
				.defaultsTo(0);
		
		//inputFile
		OptionSpec<File> inputFileOption = parser
				.accepts( "input-file", "The path were the request will be readen. The content should be a saml request" )
				.withRequiredArg()
				.ofType( File.class );

		
		//outputFile
		OptionSpec<File> outputFileOption = parser
				.accepts( "output-file", "The path were the response will be written (HTML content). File encoding will be UTF-8." )
				.withRequiredArg()
				.ofType( File.class )
				.defaultsTo(new File("out.raw"));
		
		//samlOutputFile
		OptionSpec<File> samlOutputFileOption = parser
				.accepts( "saml-output-file", "The path were the response will be written (SAML Response). File encoding will be UTF-8." )
				.withRequiredArg()
				.ofType( File.class )
				.defaultsTo(new File("out.xml"));
		
		
		//PARSE THE ARGUMENTS
		OptionSet options = null;
		try {
			options = parser.parse(args);
		} catch (OptionException e) {
			System.out.println("Error : " + e.getMessage());
			parser.printHelpOn(System.out);
			return false;
		}
		
		if (options.has(helpOption)) {
			parser.printHelpOn(System.out);
			return true;
		}
		
		//Valid the arguments
		String errors = "";
		
		//config directory
		File configDir = options.valueOf(configDirOption);
		if (!configDir.exists()) {
			errors += "\nError : The config Dir file '" + configDir.toString() + "' doesn't exists.";
		}
		
		//idp metadata
		File idpMetadata = options.valueOf(idpMetadataOption);
		if (!idpMetadata.exists()) {
			errors += "\nError : The idp file '" + idpMetadata.toString() + "' doesn't exists.";
		}
		// clientidOption
		String clientUid = options.has(clientUidOption)?options.valueOf(clientUidOption).trim():null;
		
		//'input-file' vs 'sp-entity-id'
		String rawRequest = null;
		String entityId = null;
		if ((!options.has(serviceProviderEntityIdOption)&&!options.has(inputFileOption)) ||
				(options.has(serviceProviderEntityIdOption)&&options.has(inputFileOption))) {
			errors += "\nError : One of the two options : 'input-file' or 'sp-entity-id' must be present, but not both.";
		}
		//input file is set
		if (errors.length() == 0) {
			if (options.has(inputFileOption)) {
				File inputFile = options.valueOf(inputFileOption);
				if (inputFile == null || !inputFile.exists()) {
					errors += "\nError : The input-file file '" + inputFile + "' doesn't exists.";
				} else {
					rawRequest = new String(Files.readAllBytes(inputFile.toPath()),"UTF-8");
					if (rawRequest == null || rawRequest.length()==0) {
						errors += "\nError : The input-file file '" + inputFile + "' seems empty.";
					} else {
						AuthnRequestType request = XmlTools.stringToAuthnRequestType(rawRequest);
						entityId = request.getIssuer()!=null?request.getIssuer().getValue():null;
					}
				}
				
			} else {
				entityId = options.valueOf(serviceProviderEntityIdOption).trim();
			}
		}
		
		//display error
		errors = errors.trim();
		if (errors.length() > 0) {
			System.out.println(errors);
			return false;
		}
		
		//Prepare the service provider with the arguments
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl(entityId)
		.idpMetadata(options.valueOf(idpMetadataOption))
		.binding(options.valueOf(bindingOption))
		.signatureAlgo(options.valueOf(signatureAlgoOption))
		.signatureState(options.valueOf(signatureStateOption))
		.attributesIndex(options.valueOf(attributesIndexOption))
		.clientCertificate(options.valueOf(clientCertificateOption))
		.timeshifting(options.valueOf(timeShiftingOption))
		.clientUid(clientUid)
		.rawRequest(rawRequest)
		.init();
		
		//Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();
		
		//Write the response to the output files
		if (responseHolder.getResponse() != null) {
			File samlOutputFile = options.valueOf(samlOutputFileOption);
			String xml = XmlTools.responseTypeToString(responseHolder.getResponse(), true);
			Files.write(samlOutputFile.toPath(), xml.getBytes("UTF-8"));
		}
		if (responseHolder.getHtml()!=null) {
			File outputFile = options.valueOf(outputFileOption);
			Files.write(outputFile.toPath(), responseHolder.getHtml().getBytes("UTF-8"));
		}
		
		return true;
	}
}
