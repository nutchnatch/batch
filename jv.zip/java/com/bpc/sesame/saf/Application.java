package com.bpc.sesame.saf;

import java.io.IOException;
import java.net.HttpURLConnection;

import javax.management.MalformedObjectNameException;
import javax.xml.bind.DatatypeConverter;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.config.CacheConfiguration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean;
import org.springframework.remoting.httpinvoker.SimpleHttpInvokerRequestExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.bnppa.sesame.services.internal.v2.IdentityProviderServices;
import com.bnppa.sesame.services.internal.v2.ServiceProvidersServices;
import com.bpc.sesame.saf.exception.ConfigurationException;
import com.bpc.sesame.saf.services.EnvironmentServices;
import com.bpc.sesame.saf.statistics.ProfileAspect;
import com.bpc.sesame.saf.statistics.ServiceStatistics;

/**
 * Base Spring configuration class. This class declare the spring beans + the spring configuration 
 * which are common in all scenarios. The two scenarios are :
 * - SAF launch as a webapp in java server (in tomcat, in websphere etc ...)
 * - SAF launch as a SpringBoot application for testing purpose.
 * @author 483838
 */
@Configuration
@ComponentScan({"com.bpc.sesame.saf.services"})
@PropertySource(value={"classpath:properties/sesame-saf-default.properties"})
@ImportResource({"classpath:META-INF/cxf/cxf.xml" })
@EnableAspectJAutoProxy
@EnableMBeanExport(registration=RegistrationPolicy.REPLACE_EXISTING)
@EnableCaching
@EnableScheduling
@EnableAsync()
public class Application {
	
	@Value("${sesame.saf.identity-provider.cache.certificate.time-to-live-seconds}")
	private long identityProviderCacheTimeToLive;
	
	@Value("${sesame.saf.service-providers.cache.metadata.time-to-live-seconds}")
	private long serviceProvidersCacheTimeToLive;
	
	@Bean 
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}
	
    @Bean
    public net.sf.ehcache.CacheManager ehCacheManager() {
        CacheConfiguration cacheConfigurationForIDP = new CacheConfiguration()
        .name("identityProviderCache")
        .memoryStoreEvictionPolicy("LRU")
        .timeToIdleSeconds(0)
        .timeToLiveSeconds(identityProviderCacheTimeToLive)
        .maxEntriesLocalHeap(1);
        
        CacheConfiguration cacheConfigurationForSP = new CacheConfiguration()
        .name("serviceProvidersCache")
        .memoryStoreEvictionPolicy("LRU")
        .timeToIdleSeconds(0)
        .timeToLiveSeconds(serviceProvidersCacheTimeToLive)
        .maxEntriesLocalHeap(500);

        net.sf.ehcache.config.Configuration config = new net.sf.ehcache.config.Configuration();
        config.setName("SAFCacheManager");
        config.addCache(cacheConfigurationForIDP);
        config.addCache(cacheConfigurationForSP);

        return CacheManager.create(config);
    }

	@Bean
	public org.springframework.cache.CacheManager cacheManager() {
		return new EhCacheCacheManager(ehCacheManager());
	}

    @Bean
    public ProfileAspect profileAspect() {
    	return new ProfileAspect();
    }
    
	@Value("${sesame.saf.identity-provider.sesame-username}")
	private String sesameUsername;
	
	@Value("${sesame.saf.identity-provider.sesame-password}")
	private String sesamePassword;
	
	@Autowired
	private EnvironmentServices environmentServices;
    
    @Bean
    public IdentityProviderServices getIdentityProviderServices() throws Exception
    {
        HttpInvokerProxyFactoryBean factory = new HttpInvokerProxyFactoryBean();
        factory.setHttpInvokerRequestExecutor(new SimpleHttpInvokerRequestExecutor(){
            @Override
            protected void prepareConnection(HttpURLConnection con, int contentLength) throws IOException {
                String key = sesameUsername + ":" + sesamePassword;
                key =  DatatypeConverter.printBase64Binary(key.getBytes("UTF-8"));
                con.addRequestProperty("Authorization", "Basic " + key);
                super.prepareConnection(con, contentLength);
            }
        });
        factory.setServiceUrl(environmentServices.getSesameBaseURL() + "/sesame_services/Remote/RemoteHttpBean/IdentityProviderServices");
        factory.setServiceInterface(IdentityProviderServices.class);
        factory.afterPropertiesSet();
        return (IdentityProviderServices) factory.getObject();
    }

    @Bean
    public ServiceProvidersServices getServiceProvidersServices() throws Exception
    {
        HttpInvokerProxyFactoryBean factory = new HttpInvokerProxyFactoryBean();
        factory.setHttpInvokerRequestExecutor(new SimpleHttpInvokerRequestExecutor(){
            @Override
            protected void prepareConnection(HttpURLConnection con, int contentLength) throws IOException {
                String key = sesameUsername + ":" + sesamePassword;
                key =  DatatypeConverter.printBase64Binary(key.getBytes("UTF-8"));
                con.addRequestProperty("Authorization", "Basic " + key);
                super.prepareConnection(con, contentLength);
            }
        });
        factory.setServiceUrl(environmentServices.getSesameBaseURL() + "/sesame_services/Remote/RemoteHttpBean/ServiceProvidersServices");
        factory.setServiceInterface(ServiceProvidersServices.class);
        factory.afterPropertiesSet();
        return (ServiceProvidersServices) factory.getObject();
    }
    
    @Bean(name="redirectStatistics")
    public ServiceStatistics serviceStatisticsForRedirect() {
    	try {
			return new ServiceStatistics("in-redirect",new Class[]{}, new Class[]{});
		} catch (MalformedObjectNameException e) {
			throw new ConfigurationException(e);
		}
    }
    
    @Bean(name="postStatistics")
    public ServiceStatistics serviceStatisticsForPost() {
    	try {
			return new ServiceStatistics("in-post",new Class[]{}, new Class[]{});
		} catch (MalformedObjectNameException e) {
			throw new ConfigurationException(e);
		}
    }
    
    @Bean(name="soapStatistics")
    public ServiceStatistics serviceStatisticsForSoap() {
    	try {
			return new ServiceStatistics("in-soap",new Class[]{}, new Class[]{});
		} catch (MalformedObjectNameException e) {
			throw new ConfigurationException(e);
		}
    }

}
