package com.bpc.sesame.saf;

/**
 *
 * Contains all constants to be used by the servlets and pages.
 *
 * @author a20257
 * @since 1.0.0
 */
public final class WebConstants {

    /**
     * Request parameter for the login field.
     */
    public static final String PARAMETER_LOGIN = "login";
    /**
     * Request parameter for the old password field.
     */
    public static final String PARAMETER_OLD_PASS = "oldPassword";
    /**
     * Request parameter for the new password field.
     */
    public static final String PARAMETER_NEW_PASS = "newPassword";
    /**
     * Request parameter for the success information.
     */
    public static final String PARAMETER_SUCCESS = "success";
    /**
     * Request/session attribute for the error information.
     */
    public static final String ATTRIBUTE_ERROR = "error";
    /**
     * Request/session attribute for the help information.
     */
    public static final String ATTRIBUTE_HELP = "help";

    /**
     * Private constructor to prevent class instantiation since it's to be used in a static way only.
     */
    private WebConstants(){
        // nothing to do
    }
}
