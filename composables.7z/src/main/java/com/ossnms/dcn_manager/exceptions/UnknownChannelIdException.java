package com.ossnms.dcn_manager.exceptions;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * Exception thrown whenever the given identifier does not correspond to
 * an existing channel.
 */
public class UnknownChannelIdException extends DcnManagerException {

	private static final long serialVersionUID = 3916671200572975916L;

    /** @see DcnManagerException#DcnManagerException() */
	public UnknownChannelIdException() { }

    /** @see DcnManagerException#DcnManagerException(String) */
	public UnknownChannelIdException(String message)
	{
		super(message);
	}

    /** @see DcnManagerException#DcnManagerException(Throwable) */
	public UnknownChannelIdException(Throwable cause)
	{
		super(cause);
	}

    /** @see DcnManagerException#DcnManagerException(String, Throwable) */
	public UnknownChannelIdException(String message, Throwable cause)
	{
		super(message, cause);
	}

    /** @see DcnManagerException#DcnManagerException(String, Throwable, boolean, boolean) */
	public UnknownChannelIdException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

    /** @see DcnManagerException#DcnManagerException(String, Object[]) */
    public UnknownChannelIdException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    /** @see DcnManagerException#DcnManagerException(String, Throwable, Object[]) */
    public UnknownChannelIdException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }
}
