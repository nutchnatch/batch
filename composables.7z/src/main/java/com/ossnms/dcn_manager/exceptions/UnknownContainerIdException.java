package com.ossnms.dcn_manager.exceptions;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * Exception thrown whenever the given identifier does not correspond to
 * an existing system container.
 */
public class UnknownContainerIdException extends DcnManagerException {

	private static final long serialVersionUID = 3916671200572975916L;

    /** @see DcnManagerException#DcnManagerException() */
	public UnknownContainerIdException() { }

    /** @see DcnManagerException#DcnManagerException(String) */
	public UnknownContainerIdException(String message)
	{
		super(message);
	}

    /** @see DcnManagerException#DcnManagerException(Throwable) */
	public UnknownContainerIdException(Throwable cause)
	{
		super(cause);
	}

    /** @see DcnManagerException#DcnManagerException(String, Throwable) */
	public UnknownContainerIdException(String message, Throwable cause)
	{
		super(message, cause);
	}

    /** @see DcnManagerException#DcnManagerException(String, Throwable, boolean, boolean) */
	public UnknownContainerIdException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

    /** @see DcnManagerException#DcnManagerException(String, Object[]) */
    public UnknownContainerIdException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    /** @see DcnManagerException#DcnManagerException(String, Throwable, Object[]) */
    public UnknownContainerIdException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }
}
