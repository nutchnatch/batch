package com.ossnms.dcn_manager.exceptions;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * Thrown when it was not possible to create a domain object.
 */
public class DataCreationException extends DcnManagerException {

    private static final long serialVersionUID = -4062129733975571048L;

    /** @see DcnManagerException#DcnManagerException() */
    public DataCreationException() {

    }

    /** @see DcnManagerException#DcnManagerException(String) */
    public DataCreationException(String message) {
        super(message);
    }

    /** @see DcnManagerException#DcnManagerException(Throwable) */
    public DataCreationException(Throwable cause) {
        super(cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable) */
    public DataCreationException(String message, Throwable cause) {
        super(message, cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,boolean,boolean) */
    public DataCreationException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /** @see DcnManagerException#DcnManagerException(String,Object[]) */
    public DataCreationException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,Object[]) */
    public DataCreationException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }

}
