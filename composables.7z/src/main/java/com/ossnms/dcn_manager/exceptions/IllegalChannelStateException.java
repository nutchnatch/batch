package com.ossnms.dcn_manager.exceptions;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * Exception thrown by commands whenever the command has no meaning for the current
 * channel state.
 */
public class IllegalChannelStateException extends DcnManagerException {

	private static final long serialVersionUID = -9049277992680856893L;

	/** @see CommandException#CommandException() */
	public IllegalChannelStateException() { }

    /** @see CommandException#CommandException(String) */
	public IllegalChannelStateException(String message)
	{
		super(message);
	}

    /** @see CommandException#CommandException(Throwable) */
	public IllegalChannelStateException(Throwable cause)
	{
		super(cause);
	}

    /** @see CommandException#CommandException(String, Throwable) */
	public IllegalChannelStateException(String message, Throwable cause)
	{
		super(message, cause);
	}

    /** @see CommandException#CommandException(String, Throwable, boolean, boolean) */
	public IllegalChannelStateException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

	/** @see CommandException#CommandException(String, Object[]) */
    public IllegalChannelStateException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }
}
