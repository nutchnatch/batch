package com.ossnms.dcn_manager.composables.ne;


import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NeGatewayRouteMerging.SortMode;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySource;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.RouteSortingMode;
import com.ossnms.dcn_manager.core.events.ne.NeConnectionDescriptionChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeGatewayRoutesChangedEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.properties.ne.NeDirectRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeGatewayRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeOperationalProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeProperty;
import com.ossnms.dcn_manager.core.properties.ne.NePropertySourceWithFallback;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.uow.UnitOfWork;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.DuplicatedRouteException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import com.ossnms.dcn_manager.identification.ne.GlobalNeIdV4;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.google.common.collect.Iterables.addAll;
import static com.google.common.collect.Iterables.concat;
import static com.google.common.collect.Iterables.filter;
import static com.google.common.collect.Iterables.isEmpty;
import static com.google.common.collect.Iterables.tryFind;
import static com.google.common.collect.Lists.newLinkedList;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.Collections.emptyList;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Receives a set of NE properties that have to be set/updated in the NE entity.</p>
 * <p>After validating these and recalculating related dynamic properties, the final set
 * must be propagated to other components as a change notification.</p>
 * <p>If the NE is online, its mediator must be notified as well.</p>
 *
 * <img src="doc-files/updatenecmd-activity.png">
 * <img src="doc-files/updatenecmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/updatenecmd-activity.png
 * start
 * if (Properties changed?) then (yes)
 *  :Change stored NE entity;
 * note left: Change validations are \ndone on the repository and \nentity classes.
 *  :Produce change notification;
 *  if (NE online?) then (yes)
 *   :Send properties to NE through mediator;
 *  endif
 * endif
 * stop
 * @enduml
 */
/*
 * @startuml doc-files/updatenecmd-sequence.png
 * alt If properties have changed
 *  UpdateNeProperties --> NetworkElementRepository: updateNe
 *  UpdateNeProperties --> NotificationManager: notifyChanges
 *  UpdateNeProperties --> LoggerManager : createCommandLog
 *  alt If NE is online
 *   UpdateNeProperties --> NeConnectionManager: updateProperties
 *  end
 * end
 * @enduml
 */
public class NePropertiesUpdater<C extends CallContext> {

    private static final Logger LOGGER = getLogger(NePropertiesUpdater.class);

    private final C context;
    private final NeEntityRepository neRepository;
    private final SystemRepository systemRepository;
    private final LoggerManager<C> loggerManager;
    private final NetworkElementNotifications neNotifications;
    private final NeProperties neProperties;
    private final NeOperationalProperties neOperationalProperties;
    private final NeDirectRouteProperties routeProperties;
    private final OnDuplicateRoutes duplicateRouteHandler;
    private final NeGatewayRouteInspection routeInspection;
    private final NeDomainsUpdater domainUpdater;

    public interface OnDuplicateRoutes {

        void respondToDuplicatedRoutes(@Nonnull Iterable<String> duplicatedRouteKeys, String from, String to)
                throws DuplicatedRouteException;

        void respondToDuplicatedDirectRoute(@Nonnull String duplicatedRouteKey, String from, String to)
                throws DuplicatedRouteException;

    }

    private static final OnDuplicateRoutes THROW_ON_DUPLICATE_ROUTE = new OnDuplicateRoutes() {
        @Override
        public void respondToDuplicatedRoutes(@Nonnull Iterable<String> duplicatedRouteKeys, String from, String to)
                throws DuplicatedRouteException {
            LOGGER.error("Found duplicated routes with keys {}", duplicatedRouteKeys);
            throw new DuplicatedRouteException(tr(Message.DUPLICATED_ROUTES_INFO, from, to));
        }
        @Override
        public void respondToDuplicatedDirectRoute(@Nonnull String duplicatedRouteKey, String from, String to)
                throws DuplicatedRouteException {
            LOGGER.error("Found duplicated direct route with key <{}>", duplicatedRouteKey);

            throw new DuplicatedRouteException(tr(Message.DUPLICATED_DIRECT_ROUTE_INFO, from, to));
        }
    };

    /**
     * Builds a new object.
     */
    public NePropertiesUpdater(
            @Nonnull C context,
            @Nonnull NeEntityRepository neRepository,
            @Nonnull SystemRepository systemRepository,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull NetworkElementNotifications neNotifications,
            @Nonnull NeDomainsUpdater domainUpdater,
            @Nonnull OnDuplicateRoutes duplicateRouteHandler) {
        this.context = context;
        this.neRepository = neRepository;
        this.systemRepository = systemRepository;
        this.loggerManager = loggerManager;
        this.neNotifications = neNotifications;
        neProperties = new NeProperties();
        neOperationalProperties = new NeOperationalProperties();
        routeProperties = new NeDirectRouteProperties();
        routeInspection = new NeGatewayRouteInspection(neRepository);
        this.domainUpdater = domainUpdater;
        this.duplicateRouteHandler = duplicateRouteHandler;
    }

    /**
     * Builds a new object. Throws an exception when detecting duplicate routes.
     */
    public NePropertiesUpdater(C context, @Nonnull NeEntityRepository neRepository, @Nonnull SystemRepository systemRepository,
            @Nonnull LoggerManager<C> loggerManager, @Nonnull NetworkElementNotifications neNotifications,
            @Nonnull NeDomainsUpdater domainUpdater) {
        this(context, neRepository, systemRepository, loggerManager, neNotifications, domainUpdater, THROW_ON_DUPLICATE_ROUTE);
    }

    /**
     * Runs a pre-processing step on the new NE properties. Produces a set of information that allows users
     * to determine most changes being requested. Does not attempt to commit any changes. An initial set of
     * validations is run.
     *
     * @param neType NE type, as configured.
     * @param ne NE instance.
     * @param existingGatewayRoutes Current NE gateway routes.
     * @param updatedProperties New NE properties.
     *
     * @return An instance of {@link PreprocessedChanges} with all changes requested if the properties could
     *  be parsed and initial validations passed.
     *
     * @throws InvalidMutationException If an invalid property copy is attempted.
     * @throws RepositoryException If a repository error occurs.
     * @throws DuplicatedRouteException If duplicated routes were found and the callback decided that
     *  such a situation represents an error.
     */
    public Optional<PreprocessedChanges> prepareUpdate(@Nonnull NeType neType, @Nonnull NeEntity ne,
                                                                 @Nonnull Iterable<NeGatewayRouteData> existingGatewayRoutes, @Nonnull Map<String, String> updatedProperties)
            throws DuplicatedRouteException, InvalidMutationException, RepositoryException, DuplicatedObjectNameException {

        final Optional<Map<String, String>> properties = preprocessProperties(neType, ne, existingGatewayRoutes, updatedProperties);
        if (!properties.isPresent()) {
            return Optional.empty();
        }

        final NeUserPreferencesMutationDescriptor preferencesMutationDescriptor =
                preparePreferences(neType, ne, properties.get());

        final NeOperationMutationDescriptor  neOperationMutationDescriptor =
                prepareOperationData( neType, ne, properties.get());
        final NePropertySourceWithFallback propertySource = new NePropertySourceWithFallback(preferencesMutationDescriptor, ne);
        final Iterable<NeGatewayRouteMutationDescriptor> gatewayRoutes =
                preprocessGatewayRoutes(neType, ne.getInfo().getNeId(), propertySource, existingGatewayRoutes, properties.get());

        return Optional.of(new PreprocessedChanges(neType, ne.getInfo().getNeId(), existingGatewayRoutes,
                gatewayRoutes, preferencesMutationDescriptor, neOperationMutationDescriptor,
                neRepository));
    }

    private <V> Optional<V> throwIfAbsent(Optional<V> value) throws DataUpdateException {
        if (!value.isPresent()) {
            throw new DataUpdateException("Concurrent modification detected.");
        }
        return value;
    }

    public Optional<NeEntity> processUpdate(@Nonnull PreprocessedChanges update)
            throws DcnManagerException {
        final UnitOfWork<UpdateResults> uow = update.getUnitOfWork();

        /*
         * Prepare to commit NE User Preference changes to the repository.
         */
        uow.addUnit(
                (ctx, m) -> throwIfAbsent(neRepository.getNeUserPreferencesRepository().tryUpdate(ctx, m)),
                update.getPreferencesMutationDescriptor(),
                r -> onPreferencesCommitted(update.getPreferencesMutationDescriptor(), r)
        );

        /*
         * Prepare to commit NE Operational Properties changes to the repository.
         */
        uow.addUnit(
                (ctx, m) -> throwIfAbsent(neRepository.getNeOperationRepository().tryUpdate(ctx, m)),
                update.getNeOperationMutationDescriptor(),
                this::onNeOperationDataCommitted
        );

        /*
         * Calculate and prepare to commit NE Gateway Route changes to the repository.
         */
        final Optional<GatewayRouteChanges> routeChanges = prepareGatewayRoutes(update);
        if (routeChanges.isPresent()) {
            addGatewayRouteChangesToUnitOfWork(uow, update.getNeId(), routeChanges.get());
        } else {
            // this step is added just to ensure that the collection of gateway routes committed is filled.
            uow.addUnit(ctx -> null,
                (r, results) -> { addAll(results.commitedGatewayRoutes, update.getOriginalGatewayRoutes()); return results; });
        }

        /*
         * Calculate and prepare to commit NE Domain associations to the repository.
         *
         * Note that the domains updater class does not support integration in Units of Work.
         * This should not be a problem because it has been designed with concurrency in mind.
         */
        addDomainChangesfromRoutesToUnitOfWork(uow, update.getNeId(), update.getOriginalGatewayRoutes(),
                routeChanges.orElse(new GatewayRouteChanges(emptyList(), emptyList())));

        /*
         * Apply changes and retrieve the updated NE entity.
         */
        final UpdateResults updateResults = uow.apply();
        final Optional<NeEntity> updatedNe = neRepository.queryNe(update.getNeId());
        if (updatedNe.isPresent()) {
            updateConnectionDescription(update.getNeType(), updatedNe.get(), updateResults.commitedGatewayRoutes);
            if (routeChanges.isPresent()) {
                notifyGatewayRoutesChanges(updatedNe.get(), updateResults.commitedGatewayRoutes);
            }
        }

        return updatedNe;
    }

    /**
     * <p>Update and commit the NE with the new properties to the repository.
     * Produce all relevant logs and notifications.</p>
     *
     * <p>Equivalent to calling {@link #prepareUpdate(NeType, NeEntity, Iterable, Map)} and {@link #processUpdate(PreprocessedChanges)}
     * in succession.</p>
     *
     * @param neType NE type, as configured.
     * @param ne NE instance.
     * @param existingGatewayRoutes Current NE gateway routes.
     * @param updatedProperties New NE properties.
     *
     * @return An instance of the NE entity with the new properties if the update was successful.
     *         An empty optional will also be returned if no changes resulted from the new property set.
     *
     * @throws DcnManagerException If an invalid property copy is attempted,
     *                             a repository error occurs or
     *                             duplicated routes were found and the callback decided that such a situation represents an error.
     */
    public Optional<NeEntity> applyUpdate(@Nonnull NeType neType, @Nonnull NeEntity ne,
                                             @Nonnull Iterable<NeGatewayRouteData> existingGatewayRoutes, @Nonnull Map<String, String> updatedProperties)
            throws DcnManagerException {
        final Optional<PreprocessedChanges> update = prepareUpdate(neType, ne, existingGatewayRoutes, updatedProperties);
        return update.isPresent() ? processUpdate(update.get()) : Optional.empty();
    }

    private Optional<Map<String, String>> preprocessProperties(
            @Nonnull NeType neType, @Nonnull NeEntity ne,
            @Nonnull Iterable<NeGatewayRouteData> existingRoutes, @Nonnull Map<String, String> updatedProperties) {

        /*
         * We don't care anymore about rebuilding dynamic properties here. Dynamic properties will
         * be calculated on demand.
         * Also, the property set we have just received already contains the final property values
         * so no further tweaking on them should be required.
         */

        injectNeIdentificationControlData(neType, updatedProperties);
        
        injectNeAdditionalTypeInfoControlData(neType, updatedProperties);

        
        /*
         * Ensure that default property values are set for any properties that are not present.
         */
        missingDefaultProperties(ne, neType).forEach(updatedProperties::putIfAbsent);

        /*
         * Remove properties that will not cause any updates.
         */
        removeEqualProperties(updatedProperties, neProperties.getProperties(neType, ne));
        removeEqualProperties(updatedProperties, routeProperties.toProperties(ne));

        /*
         * Validate changes in routes that will not cause any updates.
         * Note that if we find just one property different in the set of updated properties, we must
         * not remove the others as they may be essential to find any routes being updated.
         * Hence we check this on a copy of the original map.
         */
        final HashMap<String, String> remainingUpdates = new HashMap<>(updatedProperties);
        removeEqualProperties(remainingUpdates, new NeGatewayRouteProperties(neType).toProperties(ne, existingRoutes));

        if (remainingUpdates.isEmpty()) {
            getLogger(getClass()).debug("NE {} with ID {} has no changes. Cancelling NE Property Change use case.",
                    ne.getPreferences().getName(), ne.getInfo().getNeId());
            return Optional.empty();
        }

        return Optional.of(updatedProperties);
    }

    private Map<String, String> missingDefaultProperties(final NePropertySource propertySource, final NeType neType) {
        return Maps.filterKeys(neType.getSupportedPropertyDefaultValues(),
                input -> !neProperties.getProperty(neType, propertySource, input).isPresent() &&
                         !routeProperties.get(neType, propertySource, input).isPresent());
    }

    private Map<String, String> injectNeIdentificationControlData(NeType neType, Map<String, String> updatedProperties) {

        BiMap<String, String> neIdentificationControlMap = neType.getIdentificationControlMap();
        LOGGER.debug("Got Identification Control Map: {}", neIdentificationControlMap);
        for (final Entry<String, String> idControlEntry: neIdentificationControlMap.entrySet() ) {
            if (updatedProperties.containsKey(idControlEntry.getValue())) {
                updatedProperties.put(idControlEntry.getKey(), updatedProperties.get(idControlEntry.getValue()));
            }
        }
        
        return updatedProperties;
    }

    private Map<String, String> injectNeAdditionalTypeInfoControlData(NeType neType, Map<String, String> updatedProperties) {

        BiMap<String, String> neAdditionalTypeInfoControlMap = neType.getAdditionalTypeInfoControlMap();
        LOGGER.debug("Got additional type info Control Map: {}", neAdditionalTypeInfoControlMap);
        for (final Entry<String, String> idControlEntry: neAdditionalTypeInfoControlMap.entrySet() ) {
            if (updatedProperties.containsKey(idControlEntry.getValue())) {
                updatedProperties.put(idControlEntry.getKey(), updatedProperties.get(idControlEntry.getValue()));
            }
        }
        
        return updatedProperties;
    }
    

    public void notifyGatewayRoutesChanges(NeEntity updatedEntity, Iterable<NeGatewayRouteData> gatewayRoutes) {
        final NeGatewayRoutesChangedEvent gatewayRoutesChangedEvent = new NeGatewayRoutesChangedEvent(
                updatedEntity.getInfo().getNeId());
        gatewayRoutesChangedEvent.setGatewayRoutes(Optional.of(gatewayRoutes));
        neNotifications.notifyChanges(gatewayRoutesChangedEvent);
    }

    /**
     * Produces a notification with a message describing the current physical connection to an NE.
     * This is used in the GUI.
     *
     * @param neType NE type.
     * @param updatedEntity NE entity instance.
     * @param gatewayRoutes Currently known NE gateway routes.
     */
    public void updateConnectionDescription(NeType neType, NeEntity updatedEntity, Iterable<NeGatewayRouteData> gatewayRoutes) {

        final NeConnectionDescriptionChangedEvent descriptionChangedEvent =
                new NeConnectionDescriptionChangedEvent(updatedEntity.getInfo().getNeId());
        descriptionChangedEvent.setTargetDescription(
                neProperties.getProperty(neType, updatedEntity, NeProperty.DISPLAY_ADDRESS));
        descriptionChangedEvent.setRouteDescription(
                neProperties.buildCurrentRouteDescription(updatedEntity, gatewayRoutes));

        neNotifications.notifyChanges(descriptionChangedEvent);
    }

    private void removeEqualProperties(Map<String, String> updatedProperties, Map<String, String> existingProperties) {
        final Iterator<Entry<String, String>> updatedIterator = updatedProperties.entrySet().iterator();
        while (updatedIterator.hasNext()) {
            final Entry<String, String> updatedEntry = updatedIterator.next();
            if (Objects.equals(updatedEntry.getValue(), existingProperties.get(updatedEntry.getKey()))) {
                updatedIterator.remove();
            }
        }
    }

    private void onNeOperationDataCommitted(Optional<NeOperationData> neOperationDataUpdated) {

        if (!neOperationDataUpdated.isPresent()) {
            LOGGER.warn("Could not update NE Operation Data Properties.");
        }

    }

    private void onPreferencesCommitted(
            NeUserPreferencesMutationDescriptor preferencesMutationDescriptor,
            Optional<NeUserPreferencesData> preferencesUpdated) {

        if (!preferencesUpdated.isPresent()) {
            LOGGER.warn("Could not update NE Preference Properties.");
            return;
        }

        final NeUserPreferencesData newPreferences = preferencesUpdated.get();
        final int neId = newPreferences.getId();

        if (preferencesMutationDescriptor.getName().isPresent()) {
            loggerManager.createCommandLog(context,
                    new LoggerItemNe(newPreferences.getName(),
                            "NE " + preferencesMutationDescriptor.getTarget().getName() +
                                    " was renamed to " + newPreferences.getName(),
                            neId));
        }

        loggerManager.createCommandLog(context,
                new LoggerItemNe(newPreferences.getName(),
                        "NE properties changed", neId));
    }

    private void addGatewayRouteChangesToUnitOfWork(UnitOfWork<UpdateResults> uow, int neId, GatewayRouteChanges gatewayRouteChanges) {
        gatewayRouteChanges.routesToCreate.forEach(descriptor ->
                uow.addUnit(
                        (ctx, m) -> neRepository.getNeGatewayRoutesRepository().createRoute(ctx, neId, m),
                        descriptor,
                        (newRoute, results) -> { results.commitedGatewayRoutes.add(newRoute); return results; }
                )
        );
        gatewayRouteChanges.routesToUpdate.forEach(descriptor ->
                uow.addUnit(
                        (ctx, m) -> neRepository.getNeGatewayRoutesRepository().updateRoute(ctx, neId, m),
                        descriptor,
                        (updatedRoute, results) -> { results.commitedGatewayRoutes.add(updatedRoute); return results; }
                )
        );

    }

    private void addDomainChangesfromRoutesToUnitOfWork(UnitOfWork<?> uow, int neId, Iterable<NeGatewayRouteData> originalGatewayRoutes, GatewayRouteChanges gatewayRouteChanges) {

        final Iterable<String> changedDomainNames =
                StreamSupport.stream(concat(gatewayRouteChanges.routesToCreate, gatewayRouteChanges.routesToUpdate).spliterator(), false)
                        .map(NeGatewayRouteMutationDescriptor.GET_DOMAIN_NAME)
                        .filter(Optional::isPresent).map(Optional::get)
                        .collect(Collectors.toList());

        final Iterable<NeGatewayRouteData> originalUnchangedRoutes =
                StreamSupport.stream(originalGatewayRoutes.spliterator(), false)
                        .filter(or -> !tryFind(gatewayRouteChanges.routesToUpdate, ur -> Objects.equals(ur.getTarget().getKey(), or.getKey())).isPresent())
                        .collect(Collectors.toList());

        final ImmutableSet<String> allDomainNames = ImmutableSet.<String>builder()
                .addAll(changedDomainNames)
                .addAll(domainUpdater.extractDomainNamesFromRoutes(originalUnchangedRoutes))
                .build();

        uow.addUnit(ctx -> domainUpdater.storeTransitiveDomains(neId, allDomainNames));
    }

    private NeUserPreferencesMutationDescriptor preparePreferences(NeType type, NeEntity ne, Map<String, String> updatedProperties)
            throws InvalidMutationException, RepositoryException, DuplicatedRouteException, DuplicatedObjectNameException {

        final NeUserPreferencesMutationDescriptor mutation =
                new NeUserPreferencesMutationDescriptor(ne.getPreferences())
                    .whenApplied(neNotifications::notifyChanges);

        /*
         * Fill the NE mutation with new property values.
         */
        final NePropertySourceWithFallback propertySource = new NePropertySourceWithFallback(mutation, ne);
        neProperties.setProperties(type, mutation, updatedProperties);

        /*
         * Check if has User preferences mutation values is in conflict.
         */
        userPreferencesInspection(mutation);

        routeProperties.set(type, propertySource, mutation, updatedProperties);
        routeProperties.refreshRouteKey(type, propertySource, mutation);

        /*
         * Check whether the direct route is not in conflict.
         */
        final Optional<String> directRouteKey = mutation.getDirectRouteAdapter().getKey();
        if (directRouteKey.isPresent()) {
            final Set<String> duplicatedRoutes =
                routeInspection.validateRoutes(ImmutableSet.of(directRouteKey.get()), ne.getInfo().getNeId());
            if (!duplicatedRoutes.isEmpty()) {
                final Set<Pair<String, Integer>> route = neRepository.getNeGatewayRoutesRepository()
                        .tryFindRouteKeys(ImmutableSet.of(duplicatedRoutes.stream().findFirst().get()));

                final String duplicatedNeName = neRepository
                        .queryNeName(route.stream().findFirst().map(Pair::getRight).orElse(0)).orElse(EMPTY);

                duplicateRouteHandler.respondToDuplicatedDirectRoute(directRouteKey.get(),
                        ne.getPreferences().getName(), duplicatedNeName);
            }
        }

        /*
         * Recalculate the Global NE ID based on current and new properties.
         * Update it if it could be generated (because the property set may be insufficient for generation)
         * and is not the same as the previous ID.
         */
        final Map<String, String> mergedProperties = new HashMap<>(ne.getAllOpaqueProperties());
        mergedProperties.putAll(updatedProperties);
        final Optional<String> globalNeId = new GlobalNeIdV4().generate(type, mergedProperties);
        if (globalNeId.isPresent() && !globalNeId.equals(mutation.getTarget().getGlobalId())) {
            mutation.setGlobalId(globalNeId);
        }

        /*
         * Log updates.
         */
        getLogger(getClass()).info("Prepared NE properties changes for id {}, name {}: {}",
                ne.getInfo().getNeId(), ne.getPreferences().getName(), mutation);

        return mutation;
    }

    private void userPreferencesInspection(NeUserPreferencesMutationDescriptor mutation)
            throws DuplicatedObjectNameException, RepositoryException {

        Optional<String> newName = mutation.getName();

        if (newName.isPresent()) {
            boolean nameExists = neRepository.getNeUserPreferencesRepository()
                    .query(newName.get())
                    .isPresent();

            if (nameExists) {
                throw new DuplicatedObjectNameException(tr(Message.NE_DUPLICATED_NAME, newName.get()));
            }

            nameExists = systemRepository.queryByName(newName.get()).isPresent();

            if (nameExists) {
                throw new DuplicatedObjectNameException(tr(Message.DUPLICATED_SYSTEM_NAME, newName.get()));
            }
        }
    }

    private NeOperationMutationDescriptor prepareOperationData(NeType neType, NeEntity ne, Map<String, String> updatedProperties) throws InvalidMutationException, DuplicatedObjectNameException, RepositoryException {

        final NeOperationMutationDescriptor mutation =
                new NeOperationMutationDescriptor(ne.getOperation())
                        .whenApplied(neNotifications::notifyChanges);
        
        neOperationalProperties.setProperties(neType, mutation, updatedProperties);

        validateUniqueNetworkNameBetweenNEs(mutation);
        
        /*
         * Log updates.
         */
        getLogger(getClass()).info("Prepared NE Operational properties changes for id {}, name {}: {}",
                ne.getInfo().getNeId(), ne.getPreferences().getName(), mutation);

        return mutation;
    }

    private void validateUniqueNetworkNameBetweenNEs(NeOperationMutationDescriptor descriptor)
            throws DuplicatedObjectNameException, RepositoryException {

        final Optional<String> newNeighbourhoodId = descriptor.getNeighbourhoodId();

        if(newNeighbourhoodId.isPresent()) {
            
            final Optional<NeOperationData> matchingOperationData = neRepository.getNeOperationRepository()
                    .queryByNeighbourhoodId(newNeighbourhoodId.get());

            if(matchingOperationData.isPresent() && (descriptor.getTarget().getId() != matchingOperationData.get().getId())) {
                throw new DuplicatedObjectNameException(tr(Message.DUPLICATED_NETWORK_ID_NAME, newNeighbourhoodId.get()));
            }
        }
    }

    private Optional<GatewayRouteChanges> prepareGatewayRoutes(PreprocessedChanges update)
            throws RepositoryException, DuplicatedRouteException {
        final Iterable<NeGatewayRouteMutationDescriptor> routes = update.getGatewayRouteUpdates();
        if (!isEmpty(routes)) {
            final NeUserPreferencesMutationDescriptor preferencesMutation = update.getPreferencesMutationDescriptor();

            // TODO: manage delete operations on routes

            final RouteSortingMode routeSortingMode =
                    preferencesMutation.getRouteSortingMode().orElse(preferencesMutation.getTarget().getRouteSortingMode());
            final Optional<SortMode> sortMode = routeSortingMode == RouteSortingMode.NONE
                    ? Optional.empty()
                    : Optional.of(routeSortingMode == RouteSortingMode.AUTO_PRIORITY ? SortMode.AUTO_PRIORITY_ORDER : SortMode.LILO_ORDER);
            final NeGatewayRouteMerging routeMerging =
                new NeGatewayRouteMerging(sortMode, update.getOriginalGatewayRoutes(), routes);

            final Iterable<NeGatewayRouteMutationDescriptor> routesToUpdate = routeMerging.routesToUpdate();
            final Iterable<NeGatewayRouteMutationDescriptor> routesToCreate = routeMerging.routesToCreate();

            final Set<String> duplicatedRouteKeys = routeInspection.validateRoutes(routeMerging.routeKeysToCreate(), update.getNeId());
            if (!duplicatedRouteKeys.isEmpty()) {
                final Set<Pair<String, Integer>> route = neRepository.getNeGatewayRoutesRepository()
                        .tryFindRouteKeys(ImmutableSet.of(duplicatedRouteKeys.stream().findFirst().get()));

                final Optional<String> neName = neRepository.queryNeName(update.getNeId());
                final Optional<String> duplicatedNeName = neRepository
                        .queryNeName(route.stream().findFirst().map(Pair::getRight).orElse(0));

                if (neName.isPresent() && duplicatedNeName.isPresent()) {
                    duplicateRouteHandler.respondToDuplicatedRoutes(duplicatedRouteKeys, neName.get(), duplicatedNeName.get());
                } else {
                    throw new DuplicatedRouteException(tr(Message.DUPLICATED_ROUTES));
                }
            }

            final GatewayRouteChanges changes = new GatewayRouteChanges(
                    routesToUpdate,
                    filter(routesToCreate,
                           input -> !duplicatedRouteKeys.contains(input.getKey().orElse(input.getTarget().getKey())))
                );

            LOGGER.info("Prepared NE gateway routes changes for ID {}, name {}.\n\tCreated: {}\n\tUpdated: {}\n\tDuplicated: {}",
                    update.getNeId(), preferencesMutation.getName().orElse(preferencesMutation.getTarget().getName()),
                    changes.routesToCreate, changes.routesToUpdate, duplicatedRouteKeys);

            return Optional.of(changes);
        }

        return Optional.empty();
    }

    private Iterable<NeGatewayRouteMutationDescriptor> preprocessGatewayRoutes(NeType type,
                                                                               int neId, @Nonnull NePropertySource contextEntity, @Nonnull Iterable<NeGatewayRouteData> existingGatewayRoutes,
                                                                               Map<String, String> updatedProperties) {
        // Hydrate gateway routes from properties provided.
        // Replace existing routes in the NE entity if any were found.
        final NeGatewayRouteProperties gatewayRouteProperties = new NeGatewayRouteProperties(type);

        Iterable<NeGatewayRouteMutationDescriptor> routes =
                gatewayRouteProperties.parseProperties(updatedProperties, neId, contextEntity, existingGatewayRoutes);
        if (isEmpty(routes)) {
            /*
             * We did not receive a new set of gateway routes. However other NE properties or attributes
             * may have been changed. Because we don't (want to) know how gateway route keys are generated
             * for this particular NE, we need to recalculate them in order to maintain data consistency.
             */
            routes = gatewayRouteProperties.refreshRouteKeys(contextEntity, existingGatewayRoutes);
        }

        return routes;
    }

    /** @return The instance of the NE Repository currently in use. */
    public NeEntityRepository getRepository() {
        return neRepository;
    }

    /** @return The instance of the Logger Manager currently in use. */
    public LoggerManager<C> getLoggerManager() {
        return loggerManager;
    }

    private static final class GatewayRouteChanges {

        private final Iterable<NeGatewayRouteMutationDescriptor> routesToUpdate;
        private final Iterable<NeGatewayRouteMutationDescriptor> routesToCreate;

        private GatewayRouteChanges(Iterable<NeGatewayRouteMutationDescriptor> routesToUpdate,
                Iterable<NeGatewayRouteMutationDescriptor> routesToCreate) {
            this.routesToUpdate = routesToUpdate;
            this.routesToCreate = routesToCreate;
        }

    }

    /**
     * Accumulates results during execution of the Unit of Work that will commit
     * all changes to data structures related to the NE. For internal use only.
     */
    public static final class UpdateResults {

        private final Collection<NeGatewayRouteData> commitedGatewayRoutes = new LinkedList<>();

    }

    /**
     * Contains the result of an initial processing step of a map of properties against
     * an NE instance. Allows user code to see and make changes to the update context.
     *
     * @see NePropertiesUpdater#prepareUpdate(NeType, NeEntity, Iterable, Map)
     */
    public static final class PreprocessedChanges {

        private final Iterable<NeGatewayRouteMutationDescriptor> gatewayRouteUpdates;
        private final NeUserPreferencesMutationDescriptor preferencesMutationDescriptor;
        private final NeOperationMutationDescriptor neOperationMutationDescriptor;
        private final NeType neType;
        private final int neId;
        private final Iterable<NeGatewayRouteData> originalGatewayRoutes;
        private final UnitOfWork<UpdateResults> unitOfWork;

        private PreprocessedChanges(@Nonnull NeType neType, int neId,
                                    @Nonnull Iterable<NeGatewayRouteData> existingGatewayRoutes,
                                    @Nonnull Iterable<NeGatewayRouteMutationDescriptor> gatewayRoutes,
                                    @Nonnull NeUserPreferencesMutationDescriptor preferencesMutationDescriptor,
                                    @Nonnull NeOperationMutationDescriptor neOperationMutationDescriptor,
                                    @Nonnull NeEntityRepository neRepository) {

            this.neType = neType;
            this.neId = neId;
            originalGatewayRoutes = existingGatewayRoutes;
            gatewayRouteUpdates = newLinkedList(gatewayRoutes);
            this.preferencesMutationDescriptor = preferencesMutationDescriptor;
            this.neOperationMutationDescriptor = neOperationMutationDescriptor;
            unitOfWork = neRepository.unitOfWork(new UpdateResults());
        }

        /**
         * @return The Unit of Work that will commit all changes to data structures related to the NE.
         */
        public UnitOfWork<UpdateResults> getUnitOfWork() {
            return unitOfWork;
        }

        /**
         * @return A collection of route mutation descriptors representing those routes that
         *  were included in the property set. No route merging has been performed yet.
         */
        @Nonnull
        public Iterable<NeGatewayRouteMutationDescriptor> getGatewayRouteUpdates() {
            return gatewayRouteUpdates;
        }

        /**
         * @return An instance of a {@link NeUserPreferencesMutationDescriptor} containing
         *  all modifications derived from the original property set.
         */
        @Nonnull
        public NeUserPreferencesMutationDescriptor getPreferencesMutationDescriptor() {
            return preferencesMutationDescriptor;
        }

        /**
         * @return An instance of a {@link NeOperationMutationDescriptor} containing
         *  all modifications derived from the original property set.
         */
        public NeOperationMutationDescriptor getNeOperationMutationDescriptor() {
            return neOperationMutationDescriptor;
        }

        /**
         * @return An instance of the {@link NeType} with the target NE configuration.
         */
        @Nonnull
        public NeType getNeType() {
            return neType;
        }

        /**
         * @return The current set of NE gateway routes that will be taken into consideration
         *  when calculating the necessary update operations during
         *  {@link NePropertiesUpdater#processUpdate(PreprocessedChanges)}.
         */
        @Nonnull
        public Iterable<NeGatewayRouteData> getOriginalGatewayRoutes() {
            return originalGatewayRoutes;
        }

        /**
         * @return The identifier of the NE that will be affected by these modifications.
         */
        public int getNeId() {
            return neId;
        }

    }

}
