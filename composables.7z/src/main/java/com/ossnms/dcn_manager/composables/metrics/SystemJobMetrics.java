package com.ossnms.dcn_manager.composables.metrics;

import com.ossnms.dcn_manager.core.policies.PartitionedJobsInfo;
import com.ossnms.dcn_manager.core.policies.impl.NetworkElementInteractionManagerSystemStage;


public class SystemJobMetrics extends PartitionedJobMetrics implements SystemJobMetricsMXBean {


    public SystemJobMetrics(PartitionedJobsInfo mediationInteractionManager, String name) {
        super(mediationInteractionManager, name);
    }

    @Override
    public int getActiveOngoingJobCount() {
        return getOngoingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID);
    }

    @Override
    public int getStandByOngoingJobCount() {
        return getOngoingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID);
    }

    @Override
    public int getActivePendingJobCount() {
        return getPendingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID);
    }

    @Override
    public int getStandByPendingJobCount() {
        return getPendingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID);
    }
}
