package com.ossnms.dcn_manager.composables.metrics;


import com.ossnms.dcn_manager.core.policies.PartitionedJobMetrics;

import javax.management.MXBean;

/**
 * JMX MBean interface that exposes operations and attributes related
 * of metrics about jobs running/pending for a partitioned system
 */
@MXBean
public interface PartitionedJobMetricsMXBean extends PartitionedJobMetrics {

    /**
     * @return format ongoings jobs for the given partition identifier as a string
     */
    String dumpOngoingAsString(int partitionId);

    /**
     * dumps ongoing jobs to LOG
     */
    void dumpOngoingToLog(int partitionId);

    /**
     * @return format pending jobs for the given partition identifier as a string
     */
    String dumpPendingAsString(int partitionId);

    /**
     * Dumps pending jobs for the given identifier to LOG
     */
    void dumpPendingToLog(int partitionId);

    /**
     * @return format ongoings jobs as a string
     */
    String dumpOngoingAsString();

    /**
     * Dumps ongoing jobs to LOG
     */
    void dumpOngoingToLog();

    /**
     * @return format pending jobs as a string
     */
    String dumpPendingAsString();

    /**
     * Dumps pending jobs to LOG
     */
    void dumpPendingToLog();

}
