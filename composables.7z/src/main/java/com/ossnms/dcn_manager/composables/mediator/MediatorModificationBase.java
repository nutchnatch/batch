package com.ossnms.dcn_manager.composables.mediator;

import com.ossnms.dcn_manager.composables.shared.PropertiesModificationBase;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPropertySetters;
import com.ossnms.dcn_manager.core.properties.mediator.MediatorProperties;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;

import javax.annotation.Nonnull;

/**
 * Base class for commands that modify mediator information.
 * Provides methods for these commands, such as finding mediators in the repository.
 */
public class MediatorModificationBase extends PropertiesModificationBase<MediatorType, MediatorEntity, MediatorPropertySetters<?>> {

    private final MediatorEntityRepository repository;

    public MediatorModificationBase(@Nonnull MediatorEntityRepository repository) {
        super(new MediatorProperties());
        this.repository = repository;
    }

    /**
     * Tries to find the target mediator in the repository.
     *
     * @return An instance of a mediator.
     * @throws UnknownMediatorIdException If the mediator can not be found.
     * @throws RepositoryException If some error occurred while working with the repository.
     */
    public MediatorEntity findMediator(int mediatorId) throws UnknownMediatorIdException, RepositoryException {
        return getMediatorRepository().query(mediatorId)
                .orElseThrow(() -> new UnknownMediatorIdException("Mediator {} does not exist.", mediatorId));
    }

    /**
     * Tries to find the communications state of the target mediator in the repository.
     *
     * @return An instance of a mediator.
     * @throws UnknownMediatorIdException If the mediator can not be found.
     * @throws RepositoryException If some error occurred while working with the repository.
     */
    public MediatorConnectionData findMediatorConnectionState(int mediatorId) throws UnknownMediatorIdException, RepositoryException {
        return getMediatorRepository().getMediatorConnectionRepository().query(mediatorId)
                .orElseThrow(() -> new UnknownMediatorIdException("Mediator {} does not exist.", mediatorId));
    }

    public MediatorEntityRepository getMediatorRepository() {
        return repository;
    }

}
