package com.ossnms.dcn_manager.composables.mediator;

import com.ossnms.dcn_manager.composables.channel.PhysicalChannelModification;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalDataMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.core.properties.mediator.MediatorInstanceProperties;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceUpdates;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.DuplicatedHostException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorTypeException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

public class UpdateMediatorPropertiesBase<C extends CallContext> extends
        MediatorModificationBase {

    private static final Logger LOGGER = getLogger(UpdateMediatorPropertiesBase.class);

    private final MediatorInstanceEntityRepository physicalMediatorRepository;
    private final MediatorNotifications mediatorNotifications;
    private final MediatorSchedulingConfiguration mediatorScheduling;
    private final StaticConfiguration configuration;
    private final LoggerManager<C> loggerManager;
    private final C context;
    private final int activeMediatorPriority;
    private final ChannelPhysicalConnectionRepository physicalChannelRepository;
    private final ChannelEntityRepository channelEntityRepository;
    private final PhysicalChannelModification physicalChannelModification;

    public UpdateMediatorPropertiesBase(@Nonnull C context,
                                        @Nonnull RepositoriesToUpdate repositories,
                                        @Nonnull NotificationsToSend notifications,
                                        @Nonnull MediatorSchedulingConfiguration mediatorScheduling,
                                        @Nonnull ChannelSchedulingConfiguration channelScheduling,
                                        @Nonnull StaticConfiguration configuration,
                                        @Nonnull LoggerManager<C> loggerManager,
                                        int activeMediatorPriority) {
        super(repositories.logicalMediatorRepository);
        this.context = context;
        physicalMediatorRepository = repositories.physicalMediatorRepository;
        channelEntityRepository = repositories.channelEntityRepository;
        physicalChannelRepository = repositories.physicalChannelRepository;
        this.configuration = configuration;
        this.loggerManager = loggerManager;
        mediatorNotifications = notifications.mediatorNotifications;
        this.mediatorScheduling = mediatorScheduling;
        this.activeMediatorPriority = activeMediatorPriority;
        physicalChannelModification = new PhysicalChannelModification(
                repositories.physicalNeRepository,
                repositories.neEntityRepository,
                notifications.neNotifications,
                notifications.channelNotifications,
                channelEntityRepository,
                physicalChannelRepository,
                channelScheduling);
    }

    /**
     * Parameter object containing all repositories that will potentially be modified
     * by an update of mediator properties.
     */
    public static final class RepositoriesToUpdate {

        private final MediatorEntityRepository logicalMediatorRepository;
        private final MediatorInstanceEntityRepository physicalMediatorRepository;
        private final ChannelEntityRepository channelEntityRepository;
        private final ChannelPhysicalConnectionRepository physicalChannelRepository;
        private final NeEntityRepository neEntityRepository;
        private final NePhysicalConnectionRepository physicalNeRepository;

        public RepositoriesToUpdate(
                @Nonnull MediatorEntityRepository logicalMediatorRepository,
                @Nonnull MediatorInstanceEntityRepository physicalMediatorRepository,
                @Nonnull ChannelEntityRepository channelEntityRepository,
                @Nonnull ChannelPhysicalConnectionRepository physicalChannelRepository,
                @Nonnull NeEntityRepository neEntityRepository,
                @Nonnull NePhysicalConnectionRepository physicalNeRepository) {
            this.logicalMediatorRepository = logicalMediatorRepository;
            this.physicalMediatorRepository = physicalMediatorRepository;
            this.channelEntityRepository = channelEntityRepository;
            this.physicalChannelRepository = physicalChannelRepository;
            this.neEntityRepository = neEntityRepository;
            this.physicalNeRepository = physicalNeRepository;
        }
    }

    /**
     * Parameter object containing all outbound notification connectors that will
     * potentially be used in consequence of an update of mediator properties.
     */
    public static final class NotificationsToSend {
        private final MediatorNotifications mediatorNotifications;
        private final ChannelNotifications channelNotifications;
        private final NetworkElementNotifications neNotifications;

        public NotificationsToSend(
                @Nonnull MediatorNotifications mediatorNotifications,
                @Nonnull ChannelNotifications channelNotifications,
                @Nonnull NetworkElementNotifications neNotifications) {
            this.mediatorNotifications = mediatorNotifications;
            this.channelNotifications = channelNotifications;
            this.neNotifications = neNotifications;
        }
    }

    /**
     * Updates the mediator entity if any properties have changed.
     *
     * @param mediatorId        Target mediator ID.
     * @param updatedProperties The new list of properties. <b>Must be mutable</b> - unchanged properties will be removed.
     * @return The updated mediator preferences, or an absent entity if no update was necessary.
     * @throws UnknownMediatorIdException   If the mediator can not be found.
     * @throws UnknownMediatorTypeException If the configured mediator type is unknown.
     * @throws InvalidMutationException     If an invalid property copy is attempted.
     * @throws RepositoryException          when a repository error occurs.
     */
    public Optional<MediatorInfoData> applyUpdate(int mediatorId, @Nonnull Map<String, String> updatedProperties)
            throws UnknownMediatorIdException, RepositoryException, UnknownMediatorTypeException, InvalidMutationException, DataUpdateException, DuplicatedObjectNameException, DuplicatedHostException {

        final MediatorEntity mediator = findMediator(mediatorId);
        final MediatorType mediatorType = findMediatorType(mediator.getInfo());
        final MediatorInstanceProperties instanceProperties = processInstanceProperties(mediatorId, updatedProperties);

        if (arePropertiesEqual(updatedProperties, mediatorType, mediator) && instanceProperties.noChanges()) {
            getLogger(getClass()).debug("Mediator {} with ID {} has no changes. Cancelling Mediator Property Change use case.",
                    mediator.getInfo().getName(), mediatorId);
            return Optional.empty();
        }

        updateMediatorInstances(mediatorId, mediatorType.getName(), instanceProperties);

        final Optional<MediatorInfoData> updatedInfo = updateMediator(mediatorType, mediator, updatedProperties);

        if (updatedInfo.isPresent()) {
            final MediatorInfoData info = updatedInfo.get();
            final int maximumOngoingJobCount = info.isConcurrentActivationsLimited() ? info.getConcurrentActivationsLimit() : Integer.MAX_VALUE;
            physicalMediatorRepository.queryAll(mediatorId)
                    .forEach(instance -> mediatorScheduling.setMaxOngoingMediatorJobCount(instance.getPhysicalInfo().getId(), maximumOngoingJobCount));
        }

        return updatedInfo;
    }

    private MediatorType findMediatorType(MediatorInfoData mediator) throws UnknownMediatorTypeException {
        final MediatorType type = configuration.getMediatorTypes().get(mediator.getTypeName());
        if (null == type) {
            throw new UnknownMediatorTypeException("Mediator with ID {} references unknown type '{}'.",
                    mediator.getId(), mediator.getTypeName());
        }
        return type;
    }

    private MediatorInstanceProperties processInstanceProperties(int mediatorId,
                                                                 Map<String, String> updatedProperties) throws RepositoryException, DataUpdateException {
        final MediatorInstanceProperties instanceProperties =
                new MediatorInstanceProperties(physicalMediatorRepository.queryAll(mediatorId), activeMediatorPriority);
        for (Map.Entry<String, String> entry : updatedProperties.entrySet()) {
            instanceProperties.setProperty(entry.getKey(), entry.getValue());
        }
        return instanceProperties;
    }

    private void updateMediatorInstances(int mediatorId, String mediatorType, MediatorInstanceProperties instanceProperties)
            throws DuplicatedHostException, RepositoryException {

        for (final Integer id : instanceProperties.getDataRemovals()) {
            physicalMediatorRepository.deleteInstance(id);
            onMediatorInstanceDeleted(mediatorId, id);
        }

        for (final MediatorPhysicalDataMutationDescriptor instanceDataMutationDescriptor : instanceProperties.getDataMutations()) {
            if (instanceDataMutationDescriptor.getHost().isPresent()) {
                validateUniqueHost(mediatorType, instanceDataMutationDescriptor.getHost().get(), mediatorId);
            }
        }

        final MediatorInstanceUpdates instanceUpdates =
                physicalMediatorRepository.updateInstance(mediatorId, instanceProperties.getDataMutations(), instanceProperties.getDataCreations());
        instanceUpdates.getCreatedInstances().forEach(this::onMediatorInstanceCreated);
        instanceUpdates.getUpdatedInstances().forEach(mediatorNotifications::notifyUpdateInstance);
    }

    private void onMediatorInstanceDeleted(int logicalMediatorId, int physicalMediatorInstanceId) {
        tryGetChannelPhysicalConnectionDataStream(physicalMediatorInstanceId)
                .forEach(channel -> physicalChannelModification.remove(channel.getLogicalChannelId(), channel.getId()));

        mediatorScheduling.onMediatorRemoved(physicalMediatorInstanceId);

        // tell the world that this mediator instance was deleted.
        mediatorNotifications.notifyDeleteInstance(logicalMediatorId, physicalMediatorInstanceId);
    }

    private void onMediatorInstanceCreated(MediatorInstance mediatorInstance) {
        mediatorNotifications.notifyCreateInstance(mediatorInstance);

        // create a new physical channel instance for each child channel.
        tryGetChannelIdsUnderMediatorStream(mediatorInstance.getPhysicalInfo().getLogicalMediatorId())
                .forEach(channelId -> physicalChannelModification.create(channelId, 
                        mediatorInstance.getConnection().isActive(), 
                        mediatorInstance.getPhysicalInfo().getId()));
    }

    private Stream<Integer> tryGetChannelIdsUnderMediatorStream(int logicalMediatorId) {
        try {
            return channelEntityRepository.getChannelInfoRepository()
                    .queryChannelIdsUnderMediator(logicalMediatorId)
                    .stream();
        } catch (RepositoryException e) {
            LOGGER.error("Failed to load physical channel identifiers from repository: {}", e);
            return Stream.empty();
        }
    }

    private Stream<ChannelPhysicalConnectionData> tryGetChannelPhysicalConnectionDataStream(int physicalMediatorInstanceId) {
        try {
            return StreamSupport.stream(physicalChannelRepository.queryAll().spliterator(), false)
                    .filter(data -> data.getMediatorInstanceId() == physicalMediatorInstanceId);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to load physical channel instances from repository: {}", e);
            return Stream.empty();
        }
    }

    /**
     * Update and commit the mediator with the new properties to the repository.
     * Produce all relevant logs and notifications.
     *
     * @param type     Mediator type, as configured.
     * @param mediator Mediator instance.
     * @return An optional instance of MediatorInfoData with the result of the update.
     * @throws InvalidMutationException If an invalid property copy is attempted.
     * @throws RepositoryException      when a repository error occurs.
     */
    private Optional<MediatorInfoData> updateMediator(MediatorType type, final MediatorEntity mediator, Map<String, String> updatedProperties)
            throws InvalidMutationException, DuplicatedObjectNameException, RepositoryException {
        final Logger logger = getLogger(getClass());
        final int mediatorId = mediator.getInfo().getId();
        final MediatorInfoMutationDescriptor mutation = new MediatorInfoMutationDescriptor(mediator.getInfo());
        mutation.whenApplied(mediatorNotifications::notifyUpdate);

        getPropertyManager().setProperties(type, mutation, updatedProperties);

        throwOnDuplicatedName(mutation);

        final Optional<MediatorInfoData> updatedInfoOptional =
                getMediatorRepository().getMediatorInfoRepository().tryUpdate(mutation);

        if (updatedInfoOptional.isPresent()) {
            final MediatorInfoData updatedInfo = updatedInfoOptional.get();

            if (mutation.getName().isPresent()) {
                loggerManager.createCommandLog(context,
                        new LoggerItemMediator(mediator.getInfo().getName(),
                                "Mediator " + mediator.getInfo().getName() +
                                        " was renamed to " + updatedInfo.getName()));
            }

            loggerManager.createCommandLog(context,
                    new LoggerItemMediator(updatedInfo.getName(),
                            "Mediator properties changed"));

            logger.info("Mediator properties changed for id {}, name {}: {}",
                    mediator,
                    updatedInfo.getName(),
                    mutation);

        } else {
            logger.warn("Could not update mediator properties for id {}, name {}: {}", mediatorId,
                    mediator.getInfo().getName(), mutation);
        }
        return updatedInfoOptional;
    }

    /**
     * @return the loggerManager
     */
    public LoggerManager<C> getLoggerManager() {
        return loggerManager;
    }

    private void throwOnDuplicatedName(MediatorInfoMutationDescriptor updateEvent)
            throws DuplicatedObjectNameException, RepositoryException {
        final Optional<String> newMediatorName = updateEvent.getName();

        if (newMediatorName.isPresent()) {
            final boolean nameExists = getMediatorRepository().getMediatorInfoRepository().query(newMediatorName.get()).isPresent();

            if (nameExists) {
                throw new DuplicatedObjectNameException(tr(Message.DUPLICATED_MEDIATOR_NAME, newMediatorName.get()));
            }
        }
    }

    private void validateUniqueHost(@Nonnull String mediatorType, @Nonnull String newHostName, int mediatorId)
            throws DuplicatedHostException, RepositoryException {

        if (configuration.getMediatorTypes().get(mediatorType).allowManyOnSameHost()) {
            // do not check anything if many mediators are allowed on the same host.
            return;
        }

        final Optional<MediatorInfoData> existingMediator =
                getMediatorRepository().getMediatorInfoRepository().queryByHost(mediatorType, newHostName);
        final boolean hostNameExists = existingMediator.isPresent();

        if (hostNameExists && mediatorId != existingMediator.get().getId()) {
            throw new DuplicatedHostException(tr(Message.DUPLICATED_MEDIATOR_HOST,
                    mediatorType, newHostName, existingMediator.get().getName()));
        }
    }

}