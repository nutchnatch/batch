package com.ossnms.dcn_manager.composables.context;

public interface CallContext {

}
