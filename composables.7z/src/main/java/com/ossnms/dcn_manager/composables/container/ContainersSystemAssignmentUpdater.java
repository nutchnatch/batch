package com.ossnms.dcn_manager.composables.container;

import com.google.common.collect.Sets;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import static com.google.common.collect.Iterables.tryFind;

public class ContainersSystemAssignmentUpdater<C extends CallContext> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ContainersSystemAssignmentUpdater.class);

    private final ContainerRepository containerRepository;
    private final DefaultContainerAssignment<C> defaultContainerAssignment;
    private final SystemAssignmentOperations<C> operations;

    public ContainersSystemAssignmentUpdater(
            SettingsRepository settingsRepository,
            ContainerRepository containerRepository,
            SystemRepository systemRepository,
            ContainerNotifications notifications,
            LoggerManager<C> loggerManager,
            C context) {
        this.containerRepository = containerRepository;

        this.operations = new SystemAssignmentOperations<>(containerRepository, notifications, loggerManager, context);

        ContainerCreationBase<C> containerCreation = new ContainerCreationBase<>(context, containerRepository, systemRepository,
                notifications, loggerManager);
        this.defaultContainerAssignment = new DefaultContainerAssignment<>(settingsRepository, containerRepository,
                containerCreation);
    }

    /**
     * Store the associations between System Containers and Containers.
     *
     * @param changedAssignments All associations between System Containers and Containers.
     * @param systemInfo         The system container id
     * @throws RepositoryException if a Repository error occurs.
     */
    public void store(@Nonnull final Set<SystemAssignmentData> changedAssignments, @Nonnull final SystemInfo systemInfo)
            throws RepositoryException {

        final Set<SystemAssignmentData> currentAssignments = Sets
                .newHashSet(containerRepository.queryAllBySystem(systemInfo.getId()));

        update(changedAssignments, systemInfo, currentAssignments);
        add(changedAssignments, systemInfo, currentAssignments);
        remove(changedAssignments, systemInfo, currentAssignments);
    }

    /**
     * Store a new default association between System Containers and Containers.
     *
     * @param systemInfo The system container id
     * @throws RepositoryException
     */
    public void defaultSystemAssignment(final SystemInfo systemInfo) throws RepositoryException {
        final ContainerInfo defaultContainer = defaultContainerAssignment.get();

        SystemAssignmentData assignment = new SystemAssignmentData(defaultContainer, systemInfo.getId(),
                AssignmentType.PRIMARY);

        store(Collections.singleton(assignment), systemInfo);
    }

    private void remove(@Nonnull Set<SystemAssignmentData> changedAssignments, final SystemInfo systemInfo,
            Set<SystemAssignmentData> currentAssignments) {
        final Set<SystemAssignmentData> removedAssignments = Sets.difference(currentAssignments, changedAssignments);

        removedAssignments.forEach(assignment -> {
            try {
                operations.delete(systemInfo, assignment);
            } catch (RepositoryException e) {
                LOGGER.error("Error to remove assignment for System Container=" + systemInfo.getId(), e);
            }
        });
    }

    private void add(@Nonnull Set<SystemAssignmentData> changedAssignments, final SystemInfo systemInfo,
            Set<SystemAssignmentData> currentAssignments) {
        final Set<SystemAssignmentData> addedAssignments = Sets.difference(changedAssignments, currentAssignments);

        addedAssignments.forEach(assignment -> {
            try {
                operations.create(systemInfo, assignment);
            } catch (RepositoryException e) {
                LOGGER.error("Error to add assignment for System Container=" + systemInfo.getId(), e);
            }
        });
    }

    private void update(@Nonnull Set<SystemAssignmentData> changedAssignments, final SystemInfo systemInfo,
            Set<SystemAssignmentData> currentAssignments) {
        currentAssignments.stream().filter(changedAssignments::contains)
                .map(current -> {
                    SystemAssignmentData found = tryFind(changedAssignments, current::equals).orNull();
                    if (null != found && found.getAssignmentType() != current.getAssignmentType()) {
                        return Optional.of(found);
                    }
                    return Optional.<SystemAssignmentData>empty();
                })
                .filter(Optional::isPresent).map(Optional::get)
                .forEach(changedAssignmentType -> {
                    try {
                        operations.update(systemInfo, changedAssignmentType);
                    } catch (RepositoryException e) {
                        LOGGER.error("Error to update assignment for System Container=" + systemInfo.getId(), e);
                    }
                });
    }
}
