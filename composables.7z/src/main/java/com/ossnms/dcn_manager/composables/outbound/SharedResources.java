package com.ossnms.dcn_manager.composables.outbound;

import com.ossnms.dcn_manager.composables.context.CallContext;

/**
 * Manages the Resources associated to the NEs and Channels with other system components.
 *
 * @param <C> Current Context.
 */
public interface SharedResources<C extends CallContext>  {

    /**
     * Acquire external resources associated to the NE.
     *
     * @param context Execution context.
     * @param neId Network Element identifier.
     * @param channelId Channel identifier.
     */
    void acquireNeResources(C context, int neId, int channelId);

    /**
     * Release external resources associated to the NE.
     *
     * @param context Execution context.
     * @param neId Network Element identifier.
     */
    void releaseNeResources(C context, int neId);

    /**
     * Release external resources associated to the Channel.
     *
     * @param context Execution context.
     * @param channelId Channel identifier.
     */
    void releaseChannelResources(C context, int channelId);
}
