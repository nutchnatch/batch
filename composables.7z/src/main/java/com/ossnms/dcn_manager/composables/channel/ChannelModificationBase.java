package com.ossnms.dcn_manager.composables.channel;

import com.ossnms.dcn_manager.composables.shared.PropertiesModificationBase;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPropertySetters;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.properties.channel.ChannelProperties;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.GET_NAME;
import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Base class for commands that modify channel information.
 * Provides methods for these commands, such as finding channels in the repository.
 */
public class ChannelModificationBase
        extends PropertiesModificationBase<ChannelType, ChannelUserPreferencesData, ChannelPropertySetters<?>> {

    private final ChannelEntityRepository channelRepository;

    public ChannelModificationBase(@Nonnull ChannelEntityRepository channelRepository) {
        super(new ChannelProperties());
        this.channelRepository = channelRepository;
    }

    /**
     * Tries to find the target channel in the repository.
     *
     * @return An instance of a channel.
     * @throws UnknownChannelIdException If the channel can not be found.
     * @throws RepositoryException       If some error occurred while working with the repository.
     */
    public ChannelEntity findChannel(int channelId) throws UnknownChannelIdException, RepositoryException {
        return getChannelRepository().queryChannel(channelId)
                .orElseThrow(() -> new UnknownChannelIdException(tr(Message.CHANNEL_DOES_NOT_EXIST, channelId)));
    }

    /**
     * Tries to find the communications state of the target channel in the repository.
     *
     * @return An instance of a channel communications state.
     * @throws UnknownChannelIdException If the channel can not be found.
     * @throws RepositoryException       If some error occurred while working with the repository.
     */
    public ChannelConnectionData findChannelConnectionState(int channelId) throws UnknownChannelIdException, RepositoryException {
        return getChannelRepository().getChannelConnectionRepository().query(channelId)
                .orElseThrow(() -> new UnknownChannelIdException(tr(Message.CHANNEL_DOES_NOT_EXIST, channelId)));
    }

    /**
     * Tries to find the target channel required state in the repository.
     *
     * @return An instance representing the channel's required state.
     * @throws UnknownChannelIdException If the channel cannot be found.
     * @throws RepositoryException       If some error occurred while working with the repository.
     */
    public ChannelInfoData findRequiredChannelState(int channelId) throws RepositoryException, UnknownChannelIdException {
        return getChannelRepository().getChannelInfoRepository().query(channelId)
                .orElseThrow(() -> new UnknownChannelIdException(tr(Message.CHANNEL_DOES_NOT_EXIST, channelId)));
    }

    /**
     * Tries to find the target channel name in the repository.
     *
     * @return An instance representing the channel name, if found.
     * @throws RepositoryException If some error occurred while working with the repository.
     */
    public Optional<String> tryFindChannelName(int channelId) throws RepositoryException {
        return getChannelRepository().getChannelUserPreferencesRepository().query(channelId).map(GET_NAME);
    }

    /**
     * @return The current instance of the Channel repository.
     */
    public ChannelEntityRepository getChannelRepository() {
        return channelRepository;
    }

}
