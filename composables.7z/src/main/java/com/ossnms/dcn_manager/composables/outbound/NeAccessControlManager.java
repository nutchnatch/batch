package com.ossnms.dcn_manager.composables.outbound;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.exception.AccessControlException;

/**
 * Manages the NE Access and Control.
 *
 * @param <C> Current context
 */
public interface NeAccessControlManager<C extends CallContext> {

    /**
     * Get write access on the selected NE.
     * 
     * @param context
     * @param neId
     * @throws AccessControlException
     */
    void requestWriteAccess(@Nonnull C context, int neId) throws AccessControlException;

    /**
     * Allow other resource to get write access on the selected NE.
     * 
     * @param context
     * @param neId
     * @throws AccessControlException
     */
    void releaseWriteAccess(@Nonnull C context, int neId) throws AccessControlException;

    /**
     * Forces to obtain writings permissions on the selected NE.
     * 
     * @param context
     * @param neId
     * @throws AccessControlException
     */
    void enforceWriteAccess(@Nonnull C context, int neId) throws AccessControlException;

    /**
     * Change the NE state mode from Idle to Active.
     * 
     * During the upgrade an after Swap operation, the NE comes up in idle mode.
     * 
     * @param context
     * @param neId
     * @throws AccessControlException
     */
    void toActiveStateMode(@Nonnull C context, int neId) throws AccessControlException;

    /**
     * Sets the selected NE to enter in operation mode.
     * 
     * @param context
     * @param neId
     * @throws AccessControlException
     */
    void toOperationalMode(@Nonnull C context, int neId) throws AccessControlException;
    
    /**
     * Sets the selected NE to enter in maintenance mode (suppress new alarms).
     * 
     * @param context
     * @param neId
     * @throws AccessControlException
     */
    void toMaitenanceMode(@Nonnull C context, int neId) throws AccessControlException;
}
