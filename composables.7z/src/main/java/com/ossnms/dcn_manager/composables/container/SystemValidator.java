package com.ossnms.dcn_manager.composables.container;

import com.google.common.base.Joiner;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Validator for Systems.
 */
public class SystemValidator extends ValidatorBase {
    private final NeUserPreferencesRepository neRepository;

    public SystemValidator(@Nonnull final NeUserPreferencesRepository neRepository,
            @Nonnull final SystemRepository systemRepository, @Nonnull final ContainerRepository containerRepository) {
        super(containerRepository, systemRepository);
        this.neRepository = neRepository;
    }

    /**
     * Validate the system container name
     *
     * @param newName The new name to be checked.
     * @throws DuplicatedObjectNameException If the name is duplicated between Systems or NEs.
     * @throws RepositoryException
     */
    @Override public void validateNewName(final String newName)
            throws DuplicatedObjectNameException, RepositoryException {
        validateEmptyName(newName, Message.SYSTEM_NAME_EMPTY);
        validateNeUniqueName(newName);
        validateSystemUniqueName(newName);
        validateContainerUniqueName(newName);
    }

    /*
    * The System container name must be unique between System containers.
    */
    @Override void validateSystemUniqueName(@Nonnull final String newName)
            throws DuplicatedObjectNameException, RepositoryException {

        final boolean nameExists = getSystemRepository().queryByName(newName).isPresent();

        if (nameExists) {
            throw new DuplicatedObjectNameException(
                    tr(Message.DUPLICATED_SYSTEM_NAME_BETWEEN_SYSTEM, newName, systemNameTip(newName)));
        }
    }

    /*
     * The container name must be unique between containers.
     */
    @Override public void validateContainerUniqueName(@Nonnull final String newName)
            throws DuplicatedObjectNameException, RepositoryException {

        final boolean nameExists = getContainerRepository().queryByName(newName).isPresent();

        if (nameExists) {
            throw new DuplicatedObjectNameException(
                    tr(Message.DUPLICATED_SYSTEM_NAME_BETWEEN_CONTAINER, newName, addTip(newName)));
        }
    }

    private String systemNameTip(String newName) throws RepositoryException {
        Optional<SystemInfo> info;
        int count = 1;
        String generatedIdName;

        do {
            generatedIdName = Joiner.on('_').join(newName, count++);
            info = getSystemRepository().queryByName(generatedIdName);
        } while (info.isPresent());

        return generatedIdName;
    }

    /*
     * The System container name must be unique between NEs also.
     */
    private void validateNeUniqueName(@Nonnull final String newName)
            throws DuplicatedObjectNameException, RepositoryException {
        final boolean nameExists = neRepository.query(newName).isPresent();

        if (nameExists) {
            throw new DuplicatedObjectNameException(
                    tr(Message.DUPLICATED_SYSTEM_NAME_BETWEEN_NE, newName, addTip(newName)));
        }
    }

    private String addTip(String newName) {
        return Joiner.on("_").join(newName, "SYS");
    }
}
