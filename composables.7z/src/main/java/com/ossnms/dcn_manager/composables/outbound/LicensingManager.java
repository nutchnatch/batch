package com.ossnms.dcn_manager.composables.outbound;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.exception.LicenseException;

/** 
 * Manages the License associated with NEs.  
 * 
 * @param <C> Current Context.
 */
public interface LicensingManager<C extends CallContext> {

    /**
     * Release the license associated with the NE.
     * 
     * @param context
     * @param moKey
     */
    void releaseLicense(@Nonnull C context, @Nonnull String moKey) throws LicenseException;
}
