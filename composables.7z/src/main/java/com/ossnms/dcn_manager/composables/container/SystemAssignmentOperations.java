package com.ossnms.dcn_manager.composables.container;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentUpdatedEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Delegate the System assignment CRUD operations.
 */
public class SystemAssignmentOperations<C extends CallContext> {
    private static final Logger LOGGER = LoggerFactory.getLogger(SystemAssignmentOperations.class);

    private final ContainerRepository containerRepository;
    private final ContainerNotifications notifications;
    private final LoggerManager<C> loggerManager;
    private final C context;

    public SystemAssignmentOperations(ContainerRepository containerRepository,
            ContainerNotifications notifications, LoggerManager<C> loggerManager, C context) {
        this.containerRepository = containerRepository;
        this.notifications = notifications;
        this.loggerManager = loggerManager;
        this.context = context;
    }

    /**
     * Create a New Assignment.
     *
     * @param systemInfo The System to be associated.
     * @param assignment The new assignment to be save.
     */
    public void create(@Nonnull final SystemInfo systemInfo, @Nonnull final SystemAssignmentData assignment)
            throws RepositoryException {
        containerRepository.addSystemAssignment(assignment);

        LOGGER.info("Notifying entry of System Container {} in container {}", systemInfo.getId(),
                assignment.getContainerInfo().getId());

        notifications.notifyChanges(
                new ContainerSystemAssignmentAddedEvent(assignment.getContainerInfo().getId(), systemInfo.getId(),
                        assignment.getAssignmentType()));

        createCommandLog(Message.CONTAINER_ADDED_ASSIGNMENT, systemInfo, assignment);
    }

    /**
     * Update a existing assignment.
     *
     * @param systemInfo            The associated System.
     * @param changedAssignmentType The assignment to be updated.
     */
    public void update(@Nonnull final SystemInfo systemInfo, @Nonnull final SystemAssignmentData changedAssignmentType)
            throws RepositoryException {
        if (containerRepository.tryUpdateSystemAssignment(changedAssignmentType)) {
            LOGGER.info("Notifying update info of System Container {} in container {}", systemInfo.getId(),
                    changedAssignmentType.getContainerInfo().getId());

            notifications.notifyChanges(
                    new ContainerSystemAssignmentUpdatedEvent(changedAssignmentType.getContainerInfo().getId(),
                            systemInfo.getId(), changedAssignmentType.getAssignmentType()));

            createCommandLog(Message.CONTAINER_UPDATED_ASSIGNMENT, systemInfo, changedAssignmentType);
        }
    }

    /**
     * Remove a existing assignment.
     *
     * @param systemInfo The associated System
     * @param assignment The assignment to be removed.
     */
    public void delete(@Nonnull final SystemInfo systemInfo, @Nonnull final SystemAssignmentData assignment)
            throws RepositoryException {
        if (containerRepository.tryRemoveSystemAssignment(assignment)) {
            LOGGER.info("Notifying removal of System Container {} from container {}", systemInfo.getId(),
                    assignment.getContainerInfo().getId());

            notifications.notifyChanges(new ContainerSystemAssignmentRemovedEvent(assignment.getContainerInfo().getId(),
                    systemInfo.getId()));

            createCommandLog(Message.CONTAINER_REMOVED_ASSIGNMENT, systemInfo, assignment);
        }
    }

    private void createCommandLog(Message message, SystemInfo infoData, SystemAssignmentData assignment) {
        loggerManager.createCommandLog(context, new LoggerItemContainer(assignment.getContainerInfo().getName(),
                tr(message, "System Container", infoData.getName())));
    }
}
