package com.ossnms.dcn_manager.composables.outbound.dtos;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.google.common.base.Joiner;
import com.google.common.base.MoreObjects;
import com.google.common.collect.ComparisonChain;

/**
 * Immutable {@link LoggerItemNe} implementation to log NE activities.
 */
public final class LoggerItemNe extends LoggerItemWithAffectedObject implements Comparable<LoggerItemNe>{

    private final int affectedObjectId;

    /**
     * Creates a Immutable {@link LoggerItemNe} instance initializing all attributes.
     *
     * @param affectedObject
     * @param message
     * @param affectedObjectId
     * @param severity
     */
    public LoggerItemNe(@Nonnull final String affectedObject, @Nonnull final String message, final int affectedObjectId, @Nonnull final MessageSeverity severity) {
        super(affectedObject, message, severity);
        this.affectedObjectId = affectedObjectId;
    }

    /**
     * Creates a Immutable {@link LoggerItemNe} instance for Channels with the default Severity {@link #DEFAULT_SEVERITY}.
     *
     * @param affectedObject
     * @param message
     * @param affectedObjectId
     */
    public LoggerItemNe(@Nonnull final String affectedObject, @Nonnull final String message, final int affectedObjectId) {
        super(affectedObject, message);
        this.affectedObjectId = affectedObjectId;
    }

    /**
     * @return The Affected Object Id.
     */
    public int getAffectedObjectId() {
        return affectedObjectId;
    }

    /**
     * Compares with {@link #getAffectedObjectId()}
     */
    @Override
    public int compareTo(@Nonnull  LoggerItemNe input) {
        return ComparisonChain
                .start()
                .compare(this.getAffectedObjectId(), input.getAffectedObjectId())
                .result();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .appendSuper(super.hashCode())
            .append(affectedObjectId)
            .toHashCode();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        final LoggerItemNe other = (LoggerItemNe) obj;

        return new EqualsBuilder()
            .appendSuper(super.equals(obj))
            .append(affectedObjectId, other.affectedObjectId)
            .isEquals();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return Joiner.on("").join(
                    MoreObjects.toStringHelper(this)
                        .omitNullValues()
                        .add("AffectedObjectId", affectedObjectId)
                        .toString(),
                    super.toString());
    }

    @Override
    protected String getAffectedObjectPrefix() {
        return "NE";
    }
}
