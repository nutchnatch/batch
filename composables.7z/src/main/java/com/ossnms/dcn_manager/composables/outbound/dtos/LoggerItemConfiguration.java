package com.ossnms.dcn_manager.composables.outbound.dtos;

import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Immutable {@link LoggerItemConfiguration} implementation for Global Configuration activities.
 */
public final class LoggerItemConfiguration extends LoggerItemWithAffectedObject {

    /**
     * Creates a Immutable {@link LoggerItemConfiguration} instance for Global Configuration with the default Severity {@link #DEFAULT_SEVERITY}.
     *
     * @param affectedObject
     * @param message
     */
    public LoggerItemConfiguration(@Nonnull final String affectedObject, @Nonnull final String message) {
        super(affectedObject, message);
    }

    /**
     * Creates a Immutable {@link LoggerItemConfiguration} instance for Global Configuration.
     *
     * @param affectedObject
     * @param message
     * @param severity
     */
    public LoggerItemConfiguration(@Nonnull final String affectedObject, @Nonnull final String message, @Nonnull final MessageSeverity severity) {
        super(affectedObject, message, severity);
    }

    @Override
    protected String getAffectedObjectPrefix() {
        return tr(Message.GLOBAL_CONFIG);
    }

}
