package com.ossnms.dcn_manager.composables.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.emne.SettingsProperties;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelTypeException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.Message.CHANNEL_ALREADY_EXISTS;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

public class UpdateChannelPropertiesBase<C extends CallContext> extends
        ChannelModificationBase {

    private final StaticConfiguration configuration;
    private final SettingsRepository settings;
    private final LoggerManager<C> loggerManager;
    private final ChannelNotifications entityNotifications;
    private final C context;

    public UpdateChannelPropertiesBase(@Nonnull C context,
            @Nonnull ChannelEntityRepository repository, @Nonnull StaticConfiguration configuration,
            @Nonnull SettingsRepository settings, @Nonnull LoggerManager<C> loggerManager,
            @Nonnull ChannelNotifications entityNotifications) {
        super(repository);
        this.context = context;
        this.configuration = configuration;
        this.settings = settings;
        this.loggerManager = loggerManager;
        this.entityNotifications = entityNotifications;
    }

    /**
     * Updates the channel entity if any properties have changed.
     *
     * @param channelId Target channel ID.
     * @param updatedProperties The new list of properties. <b>Must be mutable</b> - unchanged properties will be removed.
     * @return The updated channel preferences, or an absent entity if no update was necessary.
     *
     * @throws UnknownChannelIdException If the channel can not be found.
     * @throws UnknownChannelTypeException  If the configured channel type is unknown.
     * @throws InvalidMutationException If an invalid property copy is attempted.
     * @throws RepositoryException when a repository error occurs.
     */
    public Optional<ChannelUserPreferencesData> applyUpdate(int channelId, @Nonnull Map<String, String> updatedProperties)
            throws UnknownChannelIdException, RepositoryException, UnknownChannelTypeException, DuplicatedObjectNameException, InvalidMutationException {

        final ChannelEntity channel = findChannel(channelId);
        final ChannelType channelType = findChannelType(channel, channelId);

        /*
         * We don't care anymore about rebuilding dynamic properties here. Dynamic properties will
         * be calculated on demand.
         * Also, the property set we have just received already contains the final property values
         * so no further tweaking on them should be required.
         */

        if (arePropertiesEqual(updatedProperties, channelType, channel.getUserPreferences())) {
            getLogger(getClass()).debug("Channel {} with ID {} has no changes. Cancelling Channel Property Change use case.",
                    channel.getUserPreferences().getName(), channelId);
            return Optional.empty();
        }

        return updateChannel(channelType, channel, updatedProperties);
    }

    protected ChannelType findChannelType(ChannelEntity channel, int channelId) throws UnknownChannelTypeException {
        final String channelTypeName = channel.getInfo().getType();
        final ChannelType channelType = configuration.getChannelTypes().get(channelTypeName);
        if (null == channelType) {
            throw new UnknownChannelTypeException("Channel with ID {} references unknown type '{}'.", channelId, channelTypeName);
        }
        return channelType;
    }

    /**
     * Update and commit the channel with the new properties to the repository.
     * Produce all relevant logs and notifications.
     * @param type Channel type, as configured.
     * @param channel Channel instance.
     * @return An optional instance of ChannelUserPreferencesData with the result of the update.
     * @throws InvalidMutationException If an invalid property copy is attempted.
     * @throws RepositoryException when a repository error occurs.
     */
    protected Optional<ChannelUserPreferencesData> updateChannel(ChannelType type, final ChannelEntity channel, Map<String, String> updatedProperties)
            throws InvalidMutationException, DuplicatedObjectNameException, RepositoryException {
        final Logger logger = getLogger(getClass());
        final int channelId = channel.getUserPreferences().getId();
        final ChannelUserPreferencesMutationDescriptor mutation = new ChannelUserPreferencesMutationDescriptor(channel.getUserPreferences());
        mutation.whenApplied(in -> entityNotifications.notifyChanges(in, channel.getInfo().getType()));

        getPropertyManager().setProperties(type, mutation, updatedProperties);

        throwOnDuplicatedName(mutation);

        final Optional<ChannelUserPreferencesData> updatedPreferencesOptional =
                getChannelRepository().getChannelUserPreferencesRepository().tryUpdate(mutation);
        

        if (updatedPreferencesOptional.isPresent()) {
            final ChannelUserPreferencesData updatedPreferences = updatedPreferencesOptional.get();

            if (mutation.getName().isPresent()) {
                loggerManager.createCommandLog(context,
                        new LoggerItemChannel(channel.getUserPreferences().getName(),
                                "Channel " + channel.getUserPreferences().getName() +
                                " was renamed to " + updatedPreferences.getName()));
            }

            loggerManager.createCommandLog(context,
                    new LoggerItemChannel(updatedPreferences.getName(),
                            "Channel properties changed"));

            logger.info("Channel properties changed for id {}, name {}: {}",
                    channelId,
                    updatedPreferences.getName(),
                    mutation);

        } else {
            logger.warn("Could not update channel properties for id {}, name {}: {}", channelId,
                    channel.getUserPreferences().getName(), mutation);
        }
        return updatedPreferencesOptional;
    }

    /**
     * Provides a property map with both the updated properties received and the global EM/NE settings.
     * This is only used to send a complete set of properties to mediators.
     *
     * @return A new property map with all properties set.
     */
    public Map<String, String> mergeUpdatedPropertiesWithGlobalSettings(Map<String, String> updatedProperties) {
        final Map<String, String> mergedProperties = new HashMap<>(updatedProperties);
        mergedProperties.putAll(SettingsProperties.getProperties(settings.getSettings()));
        return mergedProperties;
    }

    /**
     * @return the loggerManager
     */
    public LoggerManager<C> getLoggerManager() {
        return loggerManager;
    }
    
    private void throwOnDuplicatedName(ChannelUserPreferencesMutationDescriptor updateEvent)
            throws DuplicatedObjectNameException, RepositoryException {
        final Optional<String> newChannelName = updateEvent.getName();

        if(newChannelName.isPresent()) {
            final boolean nameExists = getChannelRepository().getChannelUserPreferencesRepository().query(newChannelName.get()).isPresent();

            if (nameExists) {
                throw new DuplicatedObjectNameException(tr(CHANNEL_ALREADY_EXISTS, newChannelName.get()));
            }
        }
    }


}