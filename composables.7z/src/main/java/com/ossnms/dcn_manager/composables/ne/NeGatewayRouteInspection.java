package com.ossnms.dcn_manager.composables.ne;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nonnull;
import java.util.Set;
import java.util.stream.StreamSupport;

import static java.util.stream.Collectors.toSet;

public class NeGatewayRouteInspection {

    private static final class ExcludeEntriesFromNe implements Predicate<Pair<String, Integer>> {
        private final int targetNe;

        private ExcludeEntriesFromNe(int i) {
            this.targetNe = i;
        }

        @Override
        public boolean apply(@Nonnull Pair<String, Integer> input) {
            return input.getValue() != targetNe;
        }
    }

    private static final class ConvertRoutePairToRouteName implements
            Function<Pair<String, Integer>, String> {
        @Override
        public String apply(@Nonnull Pair<String, Integer> input) {
            return input.getKey();
        }
    }

    private final NeGatewayRoutesRepository repository;

    public NeGatewayRouteInspection(@Nonnull NeEntityRepository repository) {
        this.repository = repository.getNeGatewayRoutesRepository();
    }

    /**
     * Checks which route keys from a set are duplicated with respect to existing route
     * keys in all known NEs and specifically in a target NE.
     *
     * @param routeKeysToValidate The set of route keys that are being verified.
     * @param neId The target NE identifier.
     * @param targetNeRoutes Current target NE routes.
     *
     * @return The set of duplicated route keys found.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    public Set<String> validateRoutes(@Nonnull Set<String> routeKeysToValidate, int neId, @Nonnull Set<NeGatewayRouteData> targetNeRoutes)
            throws RepositoryException {
        final Set<String> targetNeRouteKeys = targetNeRoutes.stream().map(NeGatewayRouteData.GET_ROUTE_KEY).collect(toSet());
        final Set<String> keysInOtherNes =
                FluentIterable.from(repository.tryFindRouteKeys(routeKeysToValidate))
                    .filter(new ExcludeEntriesFromNe(neId))
                    .transform(new ConvertRoutePairToRouteName())
                    .toSet();
        return ImmutableSet.<String>builder()
                .addAll(Sets.intersection(routeKeysToValidate, targetNeRouteKeys))
                .addAll(keysInOtherNes)
                .build();
    }

    /**
     * Checks which route keys from a set are duplicated with respect to existing route
     * keys in all known NEs.
     *
     * @param routesToValidate The set of route keys that are being verified.
     * @return The set of duplicated route keys found.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    public Set<String> validateRoutes(@Nonnull Iterable<NeGatewayRouteData> routesToValidate)
            throws RepositoryException {
        final Set<String> routeKeysToValidate = buildGatewayRouteKeys(routesToValidate);
        return FluentIterable.from(repository.tryFindRouteKeys(routeKeysToValidate))
                .transform(new ConvertRoutePairToRouteName())
                .toSet();
    }

    /**
     * Checks which route keys from a set are duplicated with respect to existing route
     * keys in all known NEs, <b>except</b> a specific NE.
     *
     * @param routeKeysToValidate The set of route keys that are being verified.
     * @param neIdToIgnore The identifier of the NE whose route keys must not be checked.
     * @return The set of duplicated route keys found.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    public Set<String> validateRoutes(@Nonnull Set<String> routeKeysToValidate, int neIdToIgnore)
            throws RepositoryException {
        return FluentIterable.from(repository.tryFindRouteKeys(routeKeysToValidate))
                .filter(new ExcludeEntriesFromNe(neIdToIgnore))
                .transform(new ConvertRoutePairToRouteName())
                .toSet();
    }

    private Set<String> buildGatewayRouteKeys(Iterable<NeGatewayRouteData> routesToValidate) {
        return StreamSupport.stream(routesToValidate.spliterator(), false)
                .map(NeGatewayRouteData.GET_ROUTE_KEY)
                .collect(toSet());
    }

}
