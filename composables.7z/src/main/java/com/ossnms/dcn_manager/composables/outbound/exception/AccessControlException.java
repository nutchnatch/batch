package com.ossnms.dcn_manager.composables.outbound.exception;

import com.ossnms.dcn_manager.core.outbound.exception.OutboundException;

public class AccessControlException extends OutboundException {

    private static final long serialVersionUID = 5791747405988064312L;

    /**
     * @see Exception#Exception()
     */
    public AccessControlException() {

    }

    /**
     * @see Exception#Exception(String)
     */
    public AccessControlException(String message) {
        super(message);
    }

    /**
     * @see Exception#Exception(Throwable)
     */
    public AccessControlException(Throwable cause) {
        super(cause);
    }

    /**
     * @see Exception#Exception(String,Throwable)
     */
    public AccessControlException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @see Exception#Exception(String,Throwable,boolean,boolean)
     */
    public AccessControlException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
