package com.ossnms.dcn_manager.composables.shared;

import com.ossnms.dcn_manager.core.configuration.model.Type;
import com.ossnms.dcn_manager.core.entities.PropertyBag;
import com.ossnms.dcn_manager.core.properties.EntityProperties;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;

public class PropertiesModificationBase<T extends Type, E extends PropertyBag, M> {

    private final EntityProperties<?, T, E, M> properties;

    public PropertiesModificationBase(EntityProperties<?, T, E, M> propertyManager) {
        this.properties = propertyManager;
    }

    /**
     * <p>Compares the updated property map with the current entity properties.</p>
     *
     * <p>Also modifies the updated property map, removing properties that have not changed.
     * The purpose is to avoid committing unnecessary changes.</p>
     *
     * @return True if the updated property set contains different values than the current.
     */
    public boolean arePropertiesEqual(Map<String, String> updatedProperties,
                                      T type, E entity) {
        final Iterator<Entry<String, String>> entryIterator = updatedProperties.entrySet().iterator();
        while (entryIterator.hasNext()) {
            final Map.Entry<String, String> updatedProperty = entryIterator.next();
            final String updatedValue = updatedProperty.getValue();
            final Optional<String> existingValue = getPropertyManager().getProperty(type, entity, updatedProperty.getKey());
            if (Objects.equals(updatedValue, existingValue.orElse(null))) {
                entryIterator.remove();
            }
        }
        return updatedProperties.isEmpty();
    }

    /**
     * @return A property manager instance.
     */
    public EntityProperties<?, T, E, M> getPropertyManager() {
        return properties;
    }

}
