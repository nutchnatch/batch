package com.ossnms.dcn_manager.composables.configuration;

/**
 * Describes the contract that needs to be respected by implementations of a connector that
 * provides component configuration options and values set at install time, as opposed to
 * settings changeable in runtime by the user.
 */
public interface AppProperties {

    /**
     * @return Hostname of the server running the component.
     */
    String getServerHost();

    /**
     * @return True if the discovery algorithm should attempt to enforce equality between
     * the TNMS NE ID Name and the NE Name as reported by the network.
     */
    Boolean isAutoCopyNeNameEnabled();

    /**
     * @return True if there is an instance of Node Manager depending on values provided
     * by DCN Manager.
     */
    Boolean isNodeManagerSelected();
    
    /**
     * @return HW configuration of the installation.
     * @return
     */
    HardwareConfigurationType getHWConfiguration();
}
