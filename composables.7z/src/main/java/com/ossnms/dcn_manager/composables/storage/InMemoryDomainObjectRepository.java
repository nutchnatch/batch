package com.ossnms.dcn_manager.composables.storage;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.storage.BusinessObjectRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>A generic implementation of a non persistent domain object repository. This 
 * implementation is located in the composables layer because it does not make any assumptions 
 * regarding deployment decisions.</p>
 * 
 * <p>Insert and deletion operations are not part of the general Domain Object Repository contract
 * (@see {@link BusinessObjectRepository}) because these operations are only to be used by Domain Entity
 * Repository implementations, that is, the repository of Domain Object aggregates. This is due to the 
 * fact that Domain Object instances must always be created and removed within the context of an 
 * insertion or removal of the Domain Entity instance (i.e. creation or removal of the aggregate). </p>
 * 
 * @param <T> The domain object concrete type (i.e. its data dimension)
 * @param <M> The domain object's mutation descriptor concrete type
 */
public class InMemoryDomainObjectRepository<T extends BusinessObjectData, M extends MutationDescriptor<T, M>> 
				implements BusinessObjectRepository<T, M> {

	/** Holds the domain object instances */
    private final ConcurrentHashMap<Integer, T> repo = new ConcurrentHashMap<>();

    /** {@inheritDoc} */
    public Iterable<T> queryAll() {
    	return repo.values();
    }
    
    /** {@inheritDoc} */
    public Optional<T> query(int id) {
    	return Optional.ofNullable(repo.get(id));
    }
    
    /** {@inheritDoc} */
	@Override
	public Optional<T> tryUpdate(M mutation) {
		T result = mutation.apply();
		if(repo.replace(mutation.getTarget().getId(), mutation.getTarget(), result)) {
			// If the mutation has been successfully applied on the repository, trigger continuation
			mutation.applied();
			return Optional.of(result);
		}
		return Optional.<T>empty();
	}

    @Override
    public Optional<T> tryUpdate(@Nonnull UowContext context, @Nonnull M mutation) {
        throw new UnsupportedOperationException("In-memory repositories do not support Units of Work.");
    }

    /**
	 * Inserts the given domain object instance (i.e. its data dimension) in the repository.
	 * @param instance The domain object instance to be inserted
	 */
	public void insert(T instance)
	{
		repo.put(instance.getId(), instance);
	}
	
	/**
	 * Removes the given domain object instance (i.e. its data dimension) from the repository.
	 * @param id The domain object identifier.
	 */
	public void remove(int id)
	{
		repo.remove(id);
	}
}
