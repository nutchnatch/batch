package com.ossnms.dcn_manager.composables.outbound;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;

import javax.annotation.Nonnull;

/**
 * Exposes an abstraction layer over the Security Manager API.
 * The Security Manager is a TNMS component that needs to be informed
 * about a set of DCN Manager operations.
 */
public interface SecurityManager {

    /**
     * Reports updates done on a System.
     * @param systemInfo The System being updated.
     */
    void updateSystem(@Nonnull final SystemInfo systemInfo);

    /**
     * Reports updates done on a System.
     * @param systemId The System being updated.
     */
    void updateSystem(@Nonnull final int systemId);

    /**
     * Reports updates done on a Container.
     * @param containerInfo The Container being updated.
     */
    void updateContainer(@Nonnull final ContainerInfo containerInfo);

    /**
     * Reports updates done on a Mediator.
     * @param mediatorEntity The Mediator being updated.
     */
    void updateMediator(@Nonnull MediatorEntity mediatorEntity);

    /**
     * Reports updates done on a Mediator.
     * @param preferences Preferences set on the Mediator being updated.
     */
    void updateMediator(@Nonnull MediatorInfoData preferences);

    /**
     * Reports updates done on a Channel.
     * @param channelEntity The Channel being updated.
     */
    void updateChannel(@Nonnull ChannelEntity channelEntity);

    /**
     * Reports updates done on a Channel.
     * @param preferences User preferences set on the Channel being updated.
     */
    void updateChannel(@Nonnull ChannelUserPreferencesData preferences);

    /**
     * Reports creation of a NE.
     * @param neEntity The NE being created.
     */
    void createNe(@Nonnull NeEntity neEntity);

    /**
     * Reports deletion of a NE.
     * @param neEntity The NE being removed.
     */
    void deleteNe(@Nonnull NeEntity neEntity);

    /**
     * Reports updates done on a NE.
     * @param neEntity The NE being updated.
     */
    void updateNe(@Nonnull NeEntity neEntity);

    /**
     * Reports updates done on a NE.
     * @param preferences User preferences set on the NE being updated.
     */
    void updateNe(@Nonnull NeUserPreferencesData preferences);

    /**
     * Reports updates done on a NE.
     * @param neId Network Element identifier.
     */
    void updateNe(int neId);

}
