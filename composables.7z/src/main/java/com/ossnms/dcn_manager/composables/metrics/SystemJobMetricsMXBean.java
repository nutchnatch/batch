package com.ossnms.dcn_manager.composables.metrics;

import javax.management.MXBean;

/**
 * JMX MBean interface that exposes operations and attributes of the jobs running/pending in the system
 */
@MXBean
public interface SystemJobMetricsMXBean extends PartitionedJobMetricsMXBean {

    int getActiveOngoingJobCount();

    int getStandByOngoingJobCount();

    int getActivePendingJobCount();

    int getStandByPendingJobCount();

}
