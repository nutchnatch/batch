package com.ossnms.dcn_manager.composables.metrics;

import com.ossnms.dcn_manager.core.policies.common.PolicyJob;
import com.ossnms.dcn_manager.core.utils.Consumer;

import javax.annotation.Nonnull;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Function;
import java.util.stream.Stream;

import static java.util.stream.Collectors.joining;

/**
 * Utility class to help formatting the output of jobs running in the system
 */
public class JobMetricsOutputFormatter {

    private static final AtomicLong idGenerator = new AtomicLong(0L);


    //example: "********Start System Ongoing Jobs(PartitionId: 1) dumpId: 1********"
    static final String JOBS_START = "********Start %s %s Jobs%s dumpId: %s********";

    static final String JOBS_END = "********End %s %s Jobs%s dumpId: %s********";

    //example: "SystemOngoingJob-1: activation job ...."
    static final String JOBS_PREFIX = "%s%sJob-%s: %s";

    static final String PARTITION_ID_FORMAT = "(PartitionId: %s)";

    private final Stream<PolicyJob<?>> jobs;

    private final String jobIdentifier;

    private final String jobState;

    private final String dumpId;

    private final String partitionId;

    public JobMetricsOutputFormatter(@Nonnull Stream<PolicyJob<?>> jobs, @Nonnull String jobIdentifier, @Nonnull String jobState) {
        this(jobs, jobIdentifier, jobState, null);
    }

    public JobMetricsOutputFormatter(@Nonnull Stream<PolicyJob<?>> jobs,@Nonnull String jobIdentifier,
                                     @Nonnull String jobState, String partitionId) {
        Objects.requireNonNull(jobs);
        Objects.requireNonNull(jobIdentifier);
        Objects.requireNonNull(jobState);
        this.jobs = jobs;
        this.jobIdentifier = jobIdentifier;
        this.jobState = jobState;
        this.dumpId = String.valueOf(idGenerator.incrementAndGet());
        this.partitionId = partitionId != null? String.format(PARTITION_ID_FORMAT, partitionId):"";
    }


    private Stream<String> getStreamToDump(final Function<PolicyJob<?>,String> jobFormatter){

        final Stream<String> firstLine = Stream.of(String.format(JOBS_START, jobIdentifier, jobState, partitionId, dumpId));

        final Stream<String> endLine = Stream.of(String.format(JOBS_END, jobIdentifier, jobState, partitionId, dumpId));

        final Stream<String> jobsAsStringStream =
                jobs.map(job -> String.format(JOBS_PREFIX, jobIdentifier, jobState, dumpId, jobFormatter.apply(job)));

        return Stream.of(firstLine, jobsAsStringStream, endLine).flatMap(Function.identity());
    }


    public void dumpTo(@Nonnull final Consumer<String> consumer){
        dumpTo(consumer, PolicyJob::toString);
    }


    public void dumpTo(@Nonnull final Consumer<String> consumer,
                       @Nonnull final Function<PolicyJob<?>,String> jobFormatter){
        final Stream<String> streamToDump = getStreamToDump(jobFormatter);
        streamToDump.forEach(consumer::accept);
    }

    public String getAsString(@Nonnull final Function<PolicyJob<?>,String> jobFormatter){
        return getStreamToDump(jobFormatter).collect(joining("\n", "", "\n"));
    }

    public String getAsString(){
        return getAsString(PolicyJob::toString);
    }

    /**
     * for test purposes only
     * @return the generated id for the dump
     */
    String getDumpId(){
        return dumpId;
    }


}
