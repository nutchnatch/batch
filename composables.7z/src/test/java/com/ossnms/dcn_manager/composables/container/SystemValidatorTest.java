package com.ossnms.dcn_manager.composables.container;

import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SystemValidatorTest {
    private static final String EXISTS = "exists";

    @Mock private SystemRepository systemRepository;
    @Mock private ContainerRepository containerRepository;
    @Mock private NeUserPreferencesRepository neEntityRepository;

    private SystemValidator validator;

    @Before public void setUp() throws Exception {
        validator = new SystemValidator(neEntityRepository, systemRepository, containerRepository);
    }

    @Test(expected = IllegalStateException.class)
    public void testEmptyName() throws Exception {
        validator.validateNewName(EMPTY);
    }

    @Test(expected = IllegalStateException.class)
    public void testNullName() throws Exception {
        validator.validateNewName(null);
    }

    @Test(expected = DuplicatedObjectNameException.class)
    public void testDuplicatedSystemName() throws Exception {
        final SystemInfo exists = new SystemInfo(1, 1, EXISTS);
        when(neEntityRepository.query(EXISTS)).thenReturn(Optional.empty());
        when(systemRepository.queryByName(EXISTS)).thenReturn(Optional.of(exists));
        when(systemRepository.queryByName(EXISTS + "_1")).thenReturn(Optional.empty());

        validator.validateNewName(EXISTS);
    }

    @Test(expected = DuplicatedObjectNameException.class)
    public void testDuplicatedNeName() throws Exception {
        NeUserPreferencesData exists = new NeUserPreferencesBuilder().setName(EXISTS).build(1, 2);

        when(systemRepository.queryByName(EXISTS)).thenReturn(Optional.empty());
        when(neEntityRepository.query(EXISTS)).thenReturn(Optional.of(exists));

        validator.validateNewName(EXISTS);
    }
}