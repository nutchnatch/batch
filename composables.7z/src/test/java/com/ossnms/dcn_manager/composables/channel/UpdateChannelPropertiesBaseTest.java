package com.ossnms.dcn_manager.composables.channel;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.properties.channel.ChannelProperty;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelTypeException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasEntry;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class UpdateChannelPropertiesBaseTest {

    private static final String CHANNEL_NAME = "Channel name";
    private static final int ID = 1;
    private static final int VERSION = 1;
    private CallContext context;
    private SettingsRepository settingsRepo;
    private GlobalSettings settings;
    private LoggerManager<CallContext> loggerManager;
    private ChannelNotifications entityNotifications;
    private StaticConfiguration staticConfig;
    private Types<ChannelType> channelTypes;
    private ChannelEntityRepository repo;
    private ChannelEntityRepository.ChannelConnectionRepository connectionRepo;
    private ChannelEntityRepository.ChannelUserPreferencesRepository prefsRepo;

    private ChannelType type;

    private ChannelEntity entity;
    private ChannelInfoData state;
    private ChannelUserPreferencesData prefs;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws RepositoryException {

        channelTypes = mock(Types.class);
        staticConfig = mock(StaticConfiguration.class);
        repo = mock(ChannelEntityRepository.class);
        prefsRepo = mock(ChannelEntityRepository.ChannelUserPreferencesRepository.class);

        context = mock(CallContext.class);
        settings = GlobalSettings.build()
                        .setMediatorRetries(42)
                        .setNeRetries(24)
                        .setRetryInterval(12)
                        .setScaledStartupLimit(98)
                        .setDiscoveryPolicy(DiscoveryPolicy.NO_DISCOVERY)
                        .setEnableScheduledStartup(false)
                        .toGlobalSettings(1,1);
        loggerManager = mock(LoggerManager.class);
        entityNotifications = mock(ChannelNotifications.class);
        settingsRepo = mock(SettingsRepository.class);
        connectionRepo = mock(ChannelEntityRepository.ChannelConnectionRepository.class);
        prefsRepo = mock(ChannelEntityRepository.ChannelUserPreferencesRepository.class);

        type = MockFactory.mockEmType();

        state = new ChannelInfoBuilder().setType("channelType").build(ID, VERSION, 1);
        prefs = new ChannelUserPreferencesBuilder().setName(CHANNEL_NAME).build(ID, VERSION);
        entity = new ChannelEntity(state, null, prefs);

        when(staticConfig.getChannelTypes()).thenReturn(channelTypes);

        when(channelTypes.get("channelType")).thenReturn(type);
        when(repo.queryChannel(1)).thenReturn(Optional.of(entity));
        when(repo.getChannelConnectionRepository()).thenReturn(connectionRepo);
        when(repo.getChannelUserPreferencesRepository()).thenReturn(prefsRepo);
        when(settingsRepo.getSettings()).thenReturn(settings);
        when(prefsRepo.query("New Name")).thenReturn(Optional.empty());
    }

    @Test
    public void testNameChange() throws DcnManagerException, ConnectException {
        runPropertyChange(true, ImmutableMap.of(ChannelProperty.ID_NAME.getName(), "New Name"));

        final ArgumentCaptor<ChannelUserPreferencesMutationDescriptor> channelCaptor = ArgumentCaptor.forClass(ChannelUserPreferencesMutationDescriptor.class);
        verify(prefsRepo).tryUpdate(channelCaptor.capture());

        final ChannelUserPreferencesMutationDescriptor mutated = channelCaptor.getValue();
        assertThat(mutated.getName().get(), is("New Name"));

        verify(loggerManager).createCommandLog(context, new LoggerItemChannel(CHANNEL_NAME, "Channel " +  CHANNEL_NAME + " was renamed to New Name"));
        verify(loggerManager).createCommandLog(context, new LoggerItemChannel("New Name", "Channel properties changed"));
    }

    @Test(expected=InvalidMutationException.class)
    public void testPropertyChangeInvalidMutationError() throws DcnManagerException {

        runPropertyChange(false, ImmutableMap.of(ChannelProperty.ID_NAME.getName(), "")); // empty names are not allowed

    }

    public void runPropertyChange(boolean online) throws DcnManagerException {
        final Map<String, String> mutatedProperties = runPropertyChange(online, ImmutableMap.of("A", "vA", "B", "vB", "C", "CHANGE"));

        assertThat(mutatedProperties.size(), is(1));
        assertThat(mutatedProperties, hasEntry("C", "CHANGE"));
    }

    public Map<String, String> runPropertyChange(boolean online, Map<String, String> properties)
            throws DcnManagerException {

        final ChannelConnectionData connState = new ChannelConnectionBuilder()
            .setActivation(online ? ActualActivationState.ACTIVE : ActualActivationState.INACTIVE)
            .build(ID, VERSION);

        final ChannelUserPreferencesData prefs = new ChannelUserPreferencesBuilder()
            .setReconnectInterval(600)
            .setName(CHANNEL_NAME)
            .setProperties(ImmutableMap.of("A", "vA", "B", "vB"))
            .build(ID, VERSION);

        entity = new ChannelEntity(state, null, prefs);
        when(repo.queryChannel(1)).thenReturn(Optional.of(entity));

        when(connectionRepo.query(ID)).thenReturn(Optional.of(connState));
        when(prefsRepo.tryUpdate(any(ChannelUserPreferencesMutationDescriptor.class))).then(invocation -> {
            final ChannelUserPreferencesMutationDescriptor m = (ChannelUserPreferencesMutationDescriptor)invocation.getArguments()[0];
            if (null != m) {
                final ChannelUserPreferencesData data = m.apply();
                m.applied();
                return Optional.of(data);
            }
            return null;
        });

        buildBase().applyUpdate(ID, properties);

        final ArgumentCaptor<ChannelUserPreferencesMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(ChannelUserPreferencesMutationDescriptor.class);
        final ArgumentCaptor<ChannelUserPreferencesMutationDescriptor> mutationNotif = ArgumentCaptor.forClass(ChannelUserPreferencesMutationDescriptor.class);

        verify(prefsRepo).tryUpdate(mutationRepo.capture());
        verify(entityNotifications).notifyChanges(mutationNotif.capture(), any(String.class));

        final ChannelUserPreferencesMutationDescriptor repoDescriptor = mutationRepo.getValue();
        final ChannelUserPreferencesMutationDescriptor notifDescriptor = mutationNotif.getValue();

        assertThat(repoDescriptor, is(notifDescriptor));
        final Map<String, String> mutatedProperties = repoDescriptor.getProperties();

        return mutatedProperties;
    }

    @Test
    public void testSameProperties() throws DcnManagerException {

        final ImmutableMap<String, String> properties = ImmutableMap.of("A", "vA", "B", "vB");
        final ChannelUserPreferencesData prefs = new ChannelUserPreferencesBuilder()
            .setReconnectInterval(600)
            .setName(CHANNEL_NAME)
            .setProperties(properties)
            .build(ID, VERSION);

        entity = new ChannelEntity(state, null, prefs);
        when(repo.queryChannel(1)).thenReturn(Optional.of(entity));

        final UpdateChannelPropertiesBase<CallContext> cmd = buildBase();

        cmd.applyUpdate(ID, new HashMap<>(properties));

        verify(prefsRepo, never()).tryUpdate(any(ChannelUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, entityNotifications);
    }

    @Test
    public void testEmptyChangedProperties() throws DcnManagerException {

        final UpdateChannelPropertiesBase<CallContext> cmd = buildBase();

        cmd.applyUpdate(ID, Collections.<String, String>emptyMap());

        verify(prefsRepo, never()).tryUpdate(any(ChannelUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, entityNotifications);
    }

    @Test(expected=RepositoryException.class)
    public void testRepositoryErrorOnChannel() throws DcnManagerException {

        when(repo.queryChannel(anyInt())).thenThrow(new RepositoryException());

        buildBase().applyUpdate(ID, Collections.<String, String>emptyMap());
    }

    @Test(expected=UnknownChannelIdException.class)
    public void testInvalidChannelId() throws DcnManagerException {

        when(repo.queryChannel(anyInt())).thenReturn(Optional.<ChannelEntity>empty());

        final UpdateChannelPropertiesBase<CallContext> cmd = new UpdateChannelPropertiesBase<>(context,
                repo, staticConfig, settingsRepo, loggerManager, entityNotifications);

        cmd.applyUpdate(-1, Collections.<String, String>emptyMap());
    }

    @Test(expected=UnknownChannelTypeException.class)
    public void testInvalidChannelType() throws DcnManagerException {

        state = new ChannelInfoBuilder().setType("badType").build(ID, VERSION, 1);
        entity = new ChannelEntity(state, null, prefs);

        when(repo.queryChannel(1)).thenReturn(Optional.of(entity));

        final UpdateChannelPropertiesBase<CallContext> cmd = buildBase();

        cmd.applyUpdate(ID, Collections.<String, String>emptyMap());
    }

    private UpdateChannelPropertiesBase<CallContext> buildBase() {
        final UpdateChannelPropertiesBase<CallContext> cmd = new UpdateChannelPropertiesBase<>(context,
                repo, staticConfig, settingsRepo, loggerManager, entityNotifications);
        return cmd;
    }

}
