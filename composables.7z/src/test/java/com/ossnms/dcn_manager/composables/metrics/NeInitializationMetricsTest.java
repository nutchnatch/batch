package com.ossnms.dcn_manager.composables.metrics;

import com.codahale.metrics.Metric;
import com.codahale.metrics.MetricRegistry;
import org.junit.Test;

import java.time.Duration;

import static com.ossnms.dcn_manager.composables.metrics.NeInitializationMetrics.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.*;

public class NeInitializationMetricsTest {

	@Test
	public void metrics_registration() throws Exception {

		final MetricRegistry registry = mock(MetricRegistry.class);

		new NeInitializationMetrics(registry);

		verify(registry, atLeastOnce()).register(anyString(), isA(Metric.class));
	}

	@Test
	public void publication() throws Exception {

		final MetricRegistry registry = new MetricRegistry();

		final NeInitializationMetrics metrics = new NeInitializationMetrics(registry);

		metrics.publish(Duration.ofSeconds(200));
		metrics.publish(Duration.ofSeconds(10));

		metrics.publishRne(Duration.ofSeconds(200));
		metrics.publishRne(Duration.ofSeconds(10));

		final Object rneRatio = registry.getGauges().get(NE_INITIALIZATION_RNE_OPM).getValue();
		final Object standaloneRatio = registry.getGauges().get(NE_INITIALIZATION_STANDALONE_OPM).getValue();

		assertThat(rneRatio, is(0.5));
		assertThat(standaloneRatio, is(0.5));
	}

	@Test
	public void clear() throws Exception {

		final MetricRegistry registry = new MetricRegistry();

		final NeInitializationMetrics metrics = new NeInitializationMetrics(registry);

		metrics.publish(Duration.ofSeconds(10));

		metrics.publishRne(Duration.ofSeconds(10));

		Object rneRatio = registry.getGauges().get(NE_INITIALIZATION_RNE_OPM).getValue();
		Object standaloneRatio = registry.getGauges().get(NE_INITIALIZATION_STANDALONE_OPM).getValue();

		assertThat(rneRatio, is(1.0));
		assertThat(standaloneRatio, is(1.0));

		metrics.clear();

		rneRatio = registry.getGauges().get(NE_INITIALIZATION_RNE_OPM).getValue();
		standaloneRatio = registry.getGauges().get(NE_INITIALIZATION_STANDALONE_OPM).getValue();

		assertThat(rneRatio, is(Double.NaN));
		assertThat(standaloneRatio, is(Double.NaN));
	}

	@Test
	public void changeThresholds() throws Exception {

		final MetricRegistry registry = new MetricRegistry();

		final NeInitializationMetrics metrics = new NeInitializationMetrics(registry);

		assertThat(metrics.getRneThresholdInSeconds(), is(DEFAULT_RNE_THRESHOLD));
		assertThat(metrics.getStandaloneThresholdInSeconds(), is(DEFAULT_STANDALONE_THRESHOLD));

		metrics.publish(Duration.ofSeconds(10));
		assertThat(registry.getGauges().get(NE_INITIALIZATION_STANDALONE_OPM).getValue(), is(1.0));

		metrics.setStandaloneThresholdInSeconds(DEFAULT_STANDALONE_THRESHOLD * 2);

		assertThat(registry.getGauges().get(NE_INITIALIZATION_STANDALONE_OPM).getValue(), is(Double.NaN));
		assertThat(metrics.getStandaloneThresholdInSeconds(), is(DEFAULT_STANDALONE_THRESHOLD * 2));

		metrics.setRneThresholdInSeconds(DEFAULT_RNE_THRESHOLD * 2);

		assertThat(registry.getGauges().get(NE_INITIALIZATION_RNE_OPM).getValue(), is(Double.NaN));
		assertThat(metrics.getRneThresholdInSeconds(), is(DEFAULT_RNE_THRESHOLD * 2));
	}
}
