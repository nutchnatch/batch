package com.ossnms.dcn_manager.composables.ne;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.core.entities.domain.DomainCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.events.domain.DomainChildrenChanged;
import com.ossnms.dcn_manager.core.events.domain.DomainParticipationAdded;
import com.ossnms.dcn_manager.core.events.domain.DomainParticipationDeleted;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class NeDomainsUpdaterTest {

    private static final int NE_ID = 1;
    private static final int VERSION = 1;

    private DomainRepository domainRepository;
    private DomainNotifications domainNotifications;
    private SettingsRepository settingsRepository;

    private final DomainInfoData daInfo = new DomainInfoData(1, 0, "DA");
    private final DomainInfoData dbInfo = new DomainInfoData(2, 0, "DB");
    private final DomainInfoData dcInfo = new DomainInfoData(3, 0, "DC");
    private final DomainInfoData ddInfo = new DomainInfoData(4, 0, "DD");
    
    
    @Before
    public void setUp() throws RepositoryException {
        domainRepository = mock(DomainRepository.class);
        domainNotifications = mock(DomainNotifications.class);
        settingsRepository = mock(SettingsRepository.class);

        final GlobalSettings globalSettings = GlobalSettings.build().setDiscoveryPolicy(DiscoveryPolicy.DISCOVERY_BY_DOMAIN).toGlobalSettings(NE_ID, VERSION);

        when(domainRepository.queryByName("DA")).thenReturn(Optional.of(daInfo));
        when(domainRepository.queryByName("DC")).thenReturn(Optional.of(dcInfo));
        when(domainRepository.queryByName("DD")).thenReturn(Optional.of(ddInfo));
        when(domainRepository.queryByName("DB")).thenReturn(Optional.empty());

        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(Collections.emptyList());
        when(settingsRepository.getSettings()).thenReturn(globalSettings);
    }

    @Test
    public void testDeleteDomainIfEmpty_domainHasChildren_doesNothing_returnsFalse() throws Exception {

        when(domainRepository.queryChildrenNEs(dcInfo.getId())).thenReturn(Collections.singletonList(NE_ID));

        final boolean result = new NeDomainsUpdater(domainRepository, domainNotifications,settingsRepository)
            .tryDeleteDomainIfEmpty(dcInfo);

        assertThat(result, is(false));
        verify(domainRepository, never()).delete(isA(DomainDeletionDescriptor.class));
        verify(domainNotifications, never()).notifyDelete(isA(DomainInfoData.class));
    }

    @Test
    public void testDeleteDomainIfEmpty_noDomainChildren_repoFails_doesNothing_returnsFalse() throws Exception {

        when(domainRepository.queryChildrenNEs(dcInfo.getId())).thenReturn(Collections.emptyList());

        doThrow(new RepositoryException()).when(domainRepository).delete(isA(DomainDeletionDescriptor.class));

        final boolean result = new NeDomainsUpdater(domainRepository, domainNotifications,settingsRepository)
            .tryDeleteDomainIfEmpty(dcInfo);

        assertThat(result, is(false));
        verify(domainRepository).delete(new DomainDeletionDescriptor(dcInfo.getId()));
        verify(domainNotifications, never()).notifyDelete(isA(DomainInfoData.class));
    }

    @Test
    public void testDeleteDomainIfEmpty_noDomainChildren_deletes_returnsTrue() throws Exception {

        when(domainRepository.queryChildrenNEs(dcInfo.getId())).thenReturn(Collections.emptyList());

        final boolean result = new NeDomainsUpdater(domainRepository, domainNotifications,settingsRepository)
            .tryDeleteDomainIfEmpty(dcInfo);

        assertThat(result, is(true));
        verify(domainRepository).delete(new DomainDeletionDescriptor(dcInfo.getId()));
        verify(domainNotifications).notifyDelete(dcInfo);
    }

    @Test
    public void testStoreDomainsFromRoutes() throws RepositoryException {

        when(domainRepository.queryTransitiveDomainsForNE(NE_ID)).thenReturn(ImmutableList.of(daInfo, dcInfo));
        when(domainRepository.queryAllForNE(NE_ID))
                .thenReturn(ImmutableList.of(daInfo, dcInfo))
                .thenReturn(ImmutableList.of(daInfo, dbInfo));

        when(domainRepository.tryAddTransitiveNE(anyInt(), anyInt())).thenReturn(true);
        when(domainRepository.tryRemoveTransitiveNE(anyInt(), anyInt())).thenReturn(true);
        when(domainRepository.tryCreate(eq(new DomainCreationDescriptor("DB")))).thenReturn(Optional.of(dbInfo));
        when(domainRepository.queryChildrenNEs(dcInfo.getId())).thenReturn(Collections.singletonList(NE_ID));

        new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository)
            .storeTransitiveDomains(NE_ID, ImmutableList.of(
                    new NeGatewayRouteBuilder().setKey("ka").setDomain(Optional.of("DA")).build(NE_ID, 1),
                    new NeGatewayRouteBuilder().setKey("kb").setDomain(Optional.of("DB")).build(NE_ID, 1),
                    new NeGatewayRouteBuilder().setKey("kd").setDomain(Optional.of("DD")).build(NE_ID, 1)));

        verify(domainRepository).tryCreate(eq(new DomainCreationDescriptor("DB")));
        verify(domainRepository).tryAddTransitiveNE(dbInfo.getId(), NE_ID);
        verify(domainRepository).tryRemoveTransitiveNE(dcInfo.getId(), NE_ID);

        verify(domainNotifications).notifyCreate(isA(DomainInfoData.class));
        verify(domainNotifications, times(3)).notifyChanges(isA(DomainChildrenChanged.class));

        verify(domainNotifications).notifyChanges(new DomainParticipationAdded(dbInfo.getId(), NE_ID));
        verify(domainNotifications).notifyChanges(new DomainParticipationDeleted(dcInfo.getId(), NE_ID));
    }

    @Test
    public void testStoreTransitiveDomains() throws RepositoryException {

        final ImmutableSet<String> currentNames = ImmutableSet.of("DA", "DB", "DD");

        when(domainRepository.queryTransitiveDomainsForNE(NE_ID)).thenReturn(ImmutableList.of(daInfo, dcInfo));
        when(domainRepository.queryChildrenNEs(dcInfo.getId())).thenReturn(Collections.singletonList(NE_ID));

        when(domainRepository.queryAllForNE(NE_ID))
                .thenReturn(ImmutableList.of(daInfo, dcInfo))
                .thenReturn(ImmutableList.of(daInfo, dbInfo));

        when(domainRepository.tryAddTransitiveNE(anyInt(), anyInt())).thenReturn(true);
        when(domainRepository.tryRemoveTransitiveNE(anyInt(), anyInt())).thenReturn(true);
        when(domainRepository.tryCreate(eq(new DomainCreationDescriptor("DB")))).thenReturn(Optional.of(dbInfo));

        new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository)
            .storeTransitiveDomains(NE_ID, currentNames);

        verify(domainRepository).tryCreate(eq(new DomainCreationDescriptor("DB")));
        verify(domainRepository).tryAddTransitiveNE(dbInfo.getId(), NE_ID);
        verify(domainRepository).tryRemoveTransitiveNE(dcInfo.getId(), NE_ID);

        verify(domainNotifications).notifyCreate(isA(DomainInfoData.class));
        verify(domainNotifications, times(3)).notifyChanges(isA(DomainChildrenChanged.class));

        verify(domainNotifications).notifyChanges(new DomainParticipationAdded(dbInfo.getId(), NE_ID));
        verify(domainNotifications).notifyChanges(new DomainParticipationDeleted(dcInfo.getId(), NE_ID));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testStoreTransitiveDomains_retries() throws RepositoryException {

        final ImmutableSet<String> currentNames = ImmutableSet.of("DA");

        /*
         * Test scenario:
         *
         * 1. Domain does not exist;
         * 2. Domain creation fails - some other thread created it;
         * 3. Domain exists;
         * 4. Association failed - some other thread deleted the domain and recreated it;
         * 5. Domain exists;
         * 6. Association succeeds.
         *
         * Result : 3 queries by name, 1 creation attempt and 2 association attempts.
         */

        when(domainRepository.queryTransitiveDomainsForNE(NE_ID)).thenReturn(Collections.emptyList());

        when(domainRepository.queryAllForNE(NE_ID))
                .thenReturn(Collections.emptyList())
                .thenReturn(ImmutableList.of(daInfo));

        when(domainRepository.queryByName("DA")).thenReturn(Optional.empty(), Optional.of(daInfo), Optional.of(daInfo));
        when(domainRepository.tryCreate(eq(new DomainCreationDescriptor("DA")))).thenReturn(Optional.empty());
        when(domainRepository.tryAddTransitiveNE(anyInt(), anyInt())).thenReturn(false, true);

        new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository)
            .storeTransitiveDomains(NE_ID, currentNames);

        verify(domainRepository, times(3)).queryByName("DA");
        verify(domainRepository).tryCreate(eq(new DomainCreationDescriptor("DA")));
        verify(domainRepository, times(2)).tryAddTransitiveNE(daInfo.getId(), NE_ID);

        verify(domainNotifications, never()).notifyCreate(isA(DomainInfoData.class));
        verify(domainNotifications).notifyChanges(isA(DomainChildrenChanged.class));

        verify(domainNotifications).notifyChanges(new DomainParticipationAdded(daInfo.getId(), NE_ID));
        verify(domainNotifications, never()).notifyChanges(isA(DomainParticipationDeleted.class));
    }

    @Test
    public void testStoreTransitiveDomains_hasFiniteRetries() throws RepositoryException {

        final ImmutableSet<String> currentNames = ImmutableSet.of("DA");

        /*
         * Test scenario: nothing ever succeeds, with recoverable errors,
         * until we give up and do nothing.
         *
         * Result: no infinite loop and no notifications.
         */

        when(domainRepository.queryTransitiveDomainsForNE(NE_ID)).thenReturn(Collections.emptyList());
        when(domainRepository.queryAllForNE(NE_ID)).thenReturn(Collections.emptyList());

        when(domainRepository.queryByName("DA")).thenReturn(Optional.empty());
        when(domainRepository.tryCreate(eq(new DomainCreationDescriptor("DA")))).thenReturn(Optional.empty());
        when(domainRepository.tryAddTransitiveNE(anyInt(), anyInt())).thenReturn(false);

        new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository)
            .storeTransitiveDomains(NE_ID, currentNames);

        verify(domainNotifications, never()).notifyCreate(isA(DomainInfoData.class));
        verify(domainNotifications, never()).notifyChanges(isA(DomainChildrenChanged.class));
        verify(domainNotifications, never()).notifyChanges(isA(DomainParticipationAdded.class));
        verify(domainNotifications, never()).notifyChanges(isA(DomainParticipationDeleted.class));
    }

    @Test
    public void testStoreTransitiveDomains_withRepositoryExceptions_ignoresErrors() throws RepositoryException {

        final ImmutableSet<String> currentNames = ImmutableSet.of("DA", "DB");

        when(domainRepository.queryTransitiveDomainsForNE(NE_ID)).thenReturn(ImmutableList.of(daInfo, dcInfo));
        when(domainRepository.queryChildrenNEs(dcInfo.getId())).thenReturn(Collections.singletonList(NE_ID));

        when(domainRepository.queryAllForNE(NE_ID))
                .thenReturn(ImmutableList.of(daInfo, dcInfo))
                .thenReturn(ImmutableList.of(daInfo));

        when(domainRepository.tryRemoveTransitiveNE(anyInt(), anyInt())).thenReturn(true);
        when(domainRepository.tryCreate(eq(new DomainCreationDescriptor("DB")))).thenThrow(new RepositoryException());
        doThrow(new RepositoryException()).when(domainRepository).tryAddTransitiveNE(anyInt(), anyInt());

        new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository)
            .storeTransitiveDomains(NE_ID, currentNames);

        verify(domainNotifications, never()).notifyCreate(isA(DomainInfoData.class));

        verify(domainRepository).tryRemoveTransitiveNE(dcInfo.getId(), NE_ID);
        verify(domainNotifications, times(1)).notifyChanges(isA(DomainChildrenChanged.class)); // no creation
        verify(domainNotifications).notifyChanges(new DomainParticipationDeleted(dcInfo.getId(), NE_ID));
        verify(domainNotifications, never()).notifyChanges(isA(DomainParticipationAdded.class));
    }

    @Test
    public void testStoreTransitiveDomains_removalFails_isIgnored() throws RepositoryException {

        final ImmutableSet<String> currentNames = ImmutableSet.of();

        when(domainRepository.queryTransitiveDomainsForNE(NE_ID)).thenReturn(ImmutableList.of(daInfo));
        when(domainRepository.queryAllForNE(NE_ID)).thenReturn(ImmutableList.of(daInfo));

        when(domainRepository.tryRemoveTransitiveNE(anyInt(), anyInt())).thenReturn(false);

        new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository)
            .storeTransitiveDomains(NE_ID, currentNames);

        verify(domainRepository).tryRemoveTransitiveNE(daInfo.getId(), NE_ID);
        verify(domainNotifications, never()).notifyChanges(isA(DomainChildrenChanged.class)); // no removal
        verify(domainNotifications, never()).notifyChanges(isA(DomainParticipationAdded.class));
        verify(domainNotifications, never()).notifyChanges(isA(DomainParticipationDeleted.class));
    }

    @Test
    public void testStoreTransitiveDomains_removesEmptyDomain_notifies() throws RepositoryException {

        final ImmutableSet<String> currentNames = ImmutableSet.of();

        when(domainRepository.queryTransitiveDomainsForNE(NE_ID)).thenReturn(ImmutableList.of(daInfo));
        when(domainRepository.tryRemoveTransitiveNE(anyInt(), anyInt())).thenReturn(true);
        when(domainRepository.queryChildrenNEs(daInfo.getId())).thenReturn(Collections.emptyList());

        when(domainRepository.queryAllForNE(NE_ID))
                .thenReturn(ImmutableList.of(daInfo))
                .thenReturn(ImmutableList.of());

        new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository)
            .storeTransitiveDomains(NE_ID, currentNames);

        verify(domainRepository).tryRemoveTransitiveNE(daInfo.getId(), NE_ID);
        verify(domainNotifications).notifyChanges(isA(DomainChildrenChanged.class));
        verify(domainNotifications, never()).notifyChanges(isA(DomainParticipationAdded.class));
        verify(domainNotifications).notifyChanges(isA(DomainParticipationDeleted.class));
        verify(domainNotifications).notifyDelete(daInfo);
    }

    @Test
    public void testExtractDomainNamesFromRoutes() {
        final ImmutableList<NeGatewayRouteData> routes = ImmutableList.of(
            new NeGatewayRouteBuilder().setKey("ka0").setDomain(Optional.of("da")).build(NE_ID, 1),
            new NeGatewayRouteBuilder().setKey("ka1").setDomain(Optional.of("da")).build(NE_ID, 1),
            new NeGatewayRouteBuilder().setKey("kb0").setDomain(Optional.of("db")).build(NE_ID, 1),
            new NeGatewayRouteBuilder().setKey("kb1").setDomain(Optional.empty()).build(NE_ID, 1));

        final ImmutableSet<String> names = new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository)
            .extractDomainNamesFromRoutes(routes);

        assertThat(names, is(Matchers.iterableWithSize(2)));
        assertThat(names, allOf(hasItem("da"), hasItem("db")));
    }

}
