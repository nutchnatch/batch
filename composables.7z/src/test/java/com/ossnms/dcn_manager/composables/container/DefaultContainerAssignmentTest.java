package com.ossnms.dcn_manager.composables.container;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DefaultContainerAssignmentTest {

    @Mock private SettingsRepository settingsRepository;
    @Mock private ContainerRepository containerRepository;
    @Mock private SystemRepository systemRepository;
    @Mock private ContainerNotifications containerNotifications;
    @Mock private LoggerManager<CallContext> loggerManager;
    @Mock private CallContext context;

    private DefaultContainerAssignment defaultContainerAssignment;
    private GlobalSettings globalSettings;

    @Before public void setUp() throws Exception {
        globalSettings = GlobalSettings.build().toGlobalSettings(1, 1);
        ContainerCreationBase<CallContext> containerCreation = new ContainerCreationBase<>(context, containerRepository,
                systemRepository, containerNotifications, loggerManager);
        defaultContainerAssignment = new DefaultContainerAssignment<>(settingsRepository, containerRepository, containerCreation);
        when(systemRepository.queryByName(anyString())).thenReturn(Optional.empty());

        when(settingsRepository.getSettings()).thenReturn(globalSettings);
    }

    @Test public void testGet() throws Exception {
        when(containerRepository.queryByName(globalSettings.getDefaultContainerName())).thenReturn(Optional.of(new ContainerInfo(1,1,"c")));

        final ContainerInfo containerInfo = defaultContainerAssignment.get();

        assertThat(containerInfo.getName(), is("c"));

        verify(settingsRepository, times(1)).getSettings();
        verify(containerRepository, times(1)).queryByName(globalSettings.getDefaultContainerName());
        verify(containerRepository, never()).create(any(ContainerCreationDescriptor.class));
    }

    @Test public void testGet_with_creation() throws Exception {
        when(containerRepository.queryByName(anyString())).thenReturn(Optional.empty());
        when(containerRepository.create(any(ContainerCreationDescriptor.class))).thenReturn(new ContainerInfo(1,1,"c"));

        final ContainerInfo containerInfo = defaultContainerAssignment.get();

        verify(settingsRepository, times(1)).getSettings();
        verify(containerRepository, times(2)).queryByName(globalSettings.getDefaultContainerName());
        verify(containerRepository, times(1)).create(any(ContainerCreationDescriptor.class));

        assertThat(containerInfo.getName(), is("c"));
    }
}