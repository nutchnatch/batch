package com.ossnms.dcn_manager.composables.outbound.dtos;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

public class LoggerItemSystemTest {

    private static final String MESSAGE2 = "message2";
    private static final String MESSAGE = "message";
    private static final String OBJECT1 = "object1";

    @Test
    public void testCreate() {
        final LoggerItemSystem itemEm = new LoggerItemSystem(OBJECT1, MESSAGE, MessageSeverity.INFO);

        assertNotNull(itemEm);
        assertThat(itemEm.getAffectedObject(), is("System: object1"));
        assertThat(itemEm.getMessage(), is(MESSAGE));
        assertThat(itemEm.getSeverity(), is(MessageSeverity.INFO));
    }

    @Test
    public void testCreateWithDefaultSeverity() {
        final LoggerItemSystem itemNe = new LoggerItemSystem(OBJECT1, MESSAGE);

        assertNotNull(itemNe);
        assertThat(itemNe.getAffectedObject(), is("System: object1"));
        assertThat(itemNe.getMessage(), is(MESSAGE));
        assertThat(itemNe.getSeverity(), is(LoggerItem.DEFAULT_SEVERITY));
    }

    @Test
    public void testHashCodeEquals() {
        final LoggerItemSystem itemEm1 = new LoggerItemSystem(OBJECT1, MESSAGE);
        final LoggerItemSystem itemEm2 = new LoggerItemSystem(OBJECT1, MESSAGE);

        assertThat(itemEm1.hashCode(), is(itemEm2.hashCode()));
    }

    @Test
    public void testHashCodeDiferentMessage() {
        LoggerItemSystem itemEm1 = new LoggerItemSystem(OBJECT1, MESSAGE);
        LoggerItemSystem itemEm2 = new LoggerItemSystem(OBJECT1, MESSAGE2);

        assertNotSame(itemEm1.hashCode(), itemEm2.hashCode());

        itemEm1 = new LoggerItemSystem(OBJECT1, MESSAGE);
        itemEm2 = new LoggerItemSystem("object2", MESSAGE);

        assertThat(itemEm1.hashCode(), not(equalTo(itemEm2.hashCode())));
    }

    @Test
    public void testHashCodeDiferentAffectedObject() {
        final LoggerItemSystem itemEm1 = new LoggerItemSystem(OBJECT1, MESSAGE);
        final LoggerItemSystem itemEm2 = new LoggerItemSystem("object2", MESSAGE);

        assertThat(itemEm1.hashCode(), not(equalTo(itemEm2.hashCode())));
    }

    @Test
    public void testEquals() {
        final LoggerItemSystem itemEm1 = new LoggerItemSystem(OBJECT1, MESSAGE);
        final LoggerItemSystem itemEm2 = new LoggerItemSystem(OBJECT1, MESSAGE);

        assertEquals(itemEm1, itemEm2);
    }

    @Test
    public void testNotEqualsAffected() {
        final LoggerItemSystem itemEm1 = new LoggerItemSystem(OBJECT1, MESSAGE);
        final LoggerItemSystem itemEm2 = new LoggerItemSystem("object2", MESSAGE);

        assertThat(itemEm1, not(equalTo(itemEm2)));
    }

    @Test
    public void testNotEqualsMessage() {
        final LoggerItemSystem itemEm1 = new LoggerItemSystem(OBJECT1, MESSAGE);
        final LoggerItemSystem itemEm2 = new LoggerItemSystem(OBJECT1, MESSAGE2);

        assertThat(itemEm1, not(equalTo(itemEm2)));
    }

    @Test
    public void testNotEqualsNull() {
        final LoggerItemSystem itemEm1 = new LoggerItemSystem(OBJECT1, MESSAGE);

        assertThat(itemEm1, not(equalTo(null)));
    }

    @Test
    public void testNotEqualsOtherObjectType() {
        final LoggerItemSystem itemEm1 = new LoggerItemSystem(OBJECT1, MESSAGE);

        assertThat(itemEm1, not(equalTo(new Object())));
    }

    @Test
    public void testToString() {
        final LoggerItemSystem itemEm1 = new LoggerItemSystem(OBJECT1, MESSAGE);

        assertThat(itemEm1.toString(), CoreMatchers.containsString(OBJECT1));
        assertThat(itemEm1.toString(), CoreMatchers.containsString(MESSAGE));
        assertThat(itemEm1.toString(), CoreMatchers.containsString("1"));
    }
}
