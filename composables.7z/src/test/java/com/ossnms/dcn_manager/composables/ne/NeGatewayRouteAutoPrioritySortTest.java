package com.ossnms.dcn_manager.composables.ne;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.Comparator;

import org.junit.Test;

import com.ossnms.dcn_manager.composables.ne.NeGatewayRouteMerging.RoutePair;
import com.ossnms.dcn_manager.composables.ne.NeGatewayRouteMerging.SortMode;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;

public class NeGatewayRouteAutoPrioritySortTest {

    private static final int NE_ID = 12;
    private static final int VERSION = 5;

    private final Comparator<RoutePair> comparator = SortMode.AUTO_PRIORITY_ORDER.getComparator();

    @Test
    public void testDifferentCostsOnKeys() {
        final NeGatewayRouteData routeData1 = new NeGatewayRouteBuilder().setKey("a").setCost(1).build(NE_ID, VERSION);
        final NeGatewayRouteData routeData2 = new NeGatewayRouteBuilder().setKey("a").setCost(2).build(NE_ID, VERSION);

        int order;

        order = comparator.compare(
                new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1)),
                new RoutePair(routeData2, new NeGatewayRouteMutationDescriptor(routeData2))
            );
        assertThat(order, is(-1));

        order = comparator.compare(
                new RoutePair(routeData2, new NeGatewayRouteMutationDescriptor(routeData2)),
                new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1))
            );
        assertThat(order, is(1));

        order = comparator.compare(
                new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1)),
                new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1))
            );
        assertThat(order, is(0));
    }

    @Test
    public void testDifferentCostsOnMutations() {
        final NeGatewayRouteData routeData = new NeGatewayRouteBuilder().setKey("a").build(NE_ID, VERSION);

        int order;

        order = comparator.compare(
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setCost(1)),
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setCost(2))
            );
        assertThat(order, is(-1));

        order = comparator.compare(
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setCost(2)),
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setCost(1))
            );
        assertThat(order, is(1));

        order = comparator.compare(
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setCost(1)),
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setCost(1))
            );
        assertThat(order, is(0));
    }

    @Test
    public void testDifferentCostsOnMutations_withoutKeys() {
        final NeGatewayRouteData routeData = new NeGatewayRouteBuilder().setKey("a").build(NE_ID, VERSION);

        int order;

        order = comparator.compare(
                new RoutePair(new NeGatewayRouteMutationDescriptor(routeData).setCost(1)),
                new RoutePair(new NeGatewayRouteMutationDescriptor(routeData).setCost(2))
            );
        assertThat(order, is(-1));

        order = comparator.compare(
                new RoutePair(new NeGatewayRouteMutationDescriptor(routeData).setCost(2)),
                new RoutePair(new NeGatewayRouteMutationDescriptor(routeData).setCost(1))
            );
        assertThat(order, is(1));

        order = comparator.compare(
                new RoutePair(new NeGatewayRouteMutationDescriptor(routeData).setCost(1)),
                new RoutePair(new NeGatewayRouteMutationDescriptor(routeData).setCost(1))
            );
        assertThat(order, is(0));
    }

    @Test
    public void testMutationsWithoutCost_withoutKeys() {
        final NeGatewayRouteData routeData = new NeGatewayRouteBuilder().setKey("a").build(NE_ID, VERSION);

        int order;

        order = comparator.compare(
                new RoutePair(new NeGatewayRouteMutationDescriptor(routeData)),
                new RoutePair(new NeGatewayRouteMutationDescriptor(routeData))
            );
        assertThat(order, is(0));
    }

    @Test
    public void testSameCost_differentUsageOnKeys() {
        final NeGatewayRouteData routeData1 = new NeGatewayRouteBuilder().setKey("a").setUsed(true).build(NE_ID, VERSION);
        final NeGatewayRouteData routeData2 = new NeGatewayRouteBuilder().setKey("a").setUsed(false).build(NE_ID, VERSION);

        int order;

        order = comparator.compare(
                new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1)),
                new RoutePair(routeData2, new NeGatewayRouteMutationDescriptor(routeData2))
            );
        assertThat(order, is(-1));

        order = comparator.compare(
                new RoutePair(routeData2, new NeGatewayRouteMutationDescriptor(routeData2)),
                new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1))
            );
        assertThat(order, is(1));

        order = comparator.compare(
                new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1)),
                new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1))
            );
        assertThat(order, is(0));
    }

    @Test
    public void testSameCost_differentUsageOnMutations() {
        final NeGatewayRouteData routeData = new NeGatewayRouteBuilder().setKey("a").build(NE_ID, VERSION);

        int order;

        order = comparator.compare(
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setUsed(true)),
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setUsed(false))
            );
        assertThat(order, is(-1));

        order = comparator.compare(
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setUsed(false)),
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setUsed(true))
            );
        assertThat(order, is(1));

        order = comparator.compare(
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setUsed(true)),
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setUsed(true))
            );
        assertThat(order, is(0));

        order = comparator.compare(
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setUsed(false)),
                new RoutePair(routeData, new NeGatewayRouteMutationDescriptor(routeData).setUsed(false))
            );
        assertThat(order, is(0));
    }

}
