package com.ossnms.dcn_manager.composables.ne;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;

import java.util.Set;

import static org.hamcrest.Matchers.emptyCollectionOf;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SuppressWarnings("unchecked")
public class NeGatewayRouteInspectionTest {

    private NeEntityRepository repository;
    private NeGatewayRoutesRepository routesRepo;
    private NeGatewayRouteInspection inspection;

    @Before
    public void setUp() {
        repository = mock(NeEntityRepository.class);
        routesRepo = mock(NeGatewayRoutesRepository.class);

        when(repository.getNeGatewayRoutesRepository()).thenReturn(routesRepo);

        inspection = new NeGatewayRouteInspection(repository);
    }

    @Test
    public void testValidateRoutes_noDuplication_noDirectKey() throws RepositoryException {

        final Set<String> routeKeysToValidate = ImmutableSet.of("key");

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of());

        final Set<String> routes = inspection.validateRoutes(routeKeysToValidate, 2, ImmutableSet.of(new NeGatewayRouteBuilder().setKey("k1").build(0, 0)));
        assertThat(routes, is(emptyCollectionOf(String.class)));
    }

    @Test
    public void testValidateRoutes_duplicationOnNeGatewayRoutes() throws RepositoryException {

        final Set<String> routeKeysToValidate = ImmutableSet.of("key");

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(
                ImmutableSet.of());

        final Set<String> routes = inspection.validateRoutes(routeKeysToValidate, 2,
                ImmutableSet.of(
                        new NeGatewayRouteBuilder().setKey("k1").build(0, 0),
                        new NeGatewayRouteBuilder().setKey("key").build(0, 0)));
        assertThat(routes.size(), is(1));
        assertThat(routes, hasItem("key"));
    }

    @Test
    public void testValidateRoutes_noDuplicationAgainstSameNeDirectRoute() throws RepositoryException {

        final Set<String> routeKeysToValidate = ImmutableSet.of("key");

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(
                ImmutableSet.of());

        final Set<String> routes = inspection.validateRoutes(routeKeysToValidate, 2, ImmutableSet.of(new NeGatewayRouteBuilder().setKey("k1").build(0, 0)));
        assertThat(routes, is(emptyCollectionOf(String.class)));
    }

    @Test
    public void testValidateRoutes_duplicationOnOtherNes() throws RepositoryException {

        final Set<String> routeKeysToValidate = ImmutableSet.of("key");

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(
                ImmutableSet.of(new ImmutablePair<>("key", 1)));

        final Set<String> routes = inspection.validateRoutes(routeKeysToValidate, 2, ImmutableSet.of());
        assertThat(routes.size(), is(1));
        assertThat(routes, hasItem("key"));
    }

    @Test
    public void testValidateRoutes_directToRepository_noDuplications() throws RepositoryException {

        final ImmutableList<NeGatewayRouteData> routeKeys = ImmutableList.of(
                new NeGatewayRouteBuilder().setKey("k1").build(0, 0), new NeGatewayRouteBuilder()
                        .setKey("key").build(0, 0));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(
                ImmutableSet.of());

        final Set<String> routes = inspection.validateRoutes(routeKeys);
        assertThat(routes, is(emptyCollectionOf(String.class)));
    }

    @Test
    public void testValidateRoutes_directToRepository_withDuplications() throws RepositoryException {

        final ImmutableList<NeGatewayRouteData> routeKeys = ImmutableList.of(
                new NeGatewayRouteBuilder().setKey("k1").build(0, 0), new NeGatewayRouteBuilder()
                        .setKey("key").build(0, 0));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(
                ImmutableSet.of(new ImmutablePair<>("key", 1)));

        final Set<String> routes = inspection.validateRoutes(routeKeys);
        assertThat(routes.size(), is(1));
        assertThat(routes, hasItem("key"));
    }

}
