package com.ossnms.dcn_manager.composables.mediator;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.mediator.UpdateMediatorPropertiesBase.NotificationsToSend;
import com.ossnms.dcn_manager.composables.mediator.UpdateMediatorPropertiesBase.RepositoriesToUpdate;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalDataMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionInitialData;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorInfoRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceUpdates;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorTypeException;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static java.util.Optional.empty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class UpdateMediatorPropertiesBaseTest {

    private static final int RECONNECT_ATTEMPT_INTERVAL = 66;
    private static final String MEDIATOR_DESCRIPTION = "Mediator description";
    private static final int CONCURRENT_ACTIVATIONS_LIMIT = 77;

    private static final int ID = 1;
    private static final int PRIMARY_CHANNEL_ID = 2200;
    private static final int SECONDARY_CHANNEL_ID = 3300;
    private static final int PRIMARY_NE_ID = 4400;
    private static final int SECONDARY_NE_ID = 5500;

    private StaticConfiguration configuration;
    private MediatorEntityRepository mediatorRepository;
    private MediatorInfoRepository mediatorInfoRepository;
    private MediatorInstanceEntityRepository mediatorInstanceRepository;
    private MediatorNotifications mediatorNotifications;
    private MediatorSchedulingConfiguration mediatorScheduling;
    private ChannelPhysicalConnectionRepository physicalChannelRepository;
    private NePhysicalConnectionRepository physicalNeRepository;
    private ChannelNotifications channelNotifications;
    private NetworkElementNotifications neNotifications;
    private ChannelEntityRepository channelEntityRepository;
    private ChannelInfoRepository channelInfoRepository;
    private NeEntityRepository neEntityRepository;
    private NeInfoRepository neInfoRepository;
    private LoggerManager<CallContext> loggerManager;
    private Types<MediatorType> types;

    private UpdateMediatorPropertiesBase<CallContext> update;
    private ChannelSchedulingConfiguration channelScheduling;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws RepositoryException {
        configuration = mock(StaticConfiguration.class);
        mediatorRepository = mock(MediatorEntityRepository.class);
        mediatorInfoRepository = mock(MediatorInfoRepository.class);
        mediatorInstanceRepository = mock(MediatorInstanceEntityRepository.class);
        mediatorNotifications = mock(MediatorNotifications.class);
        mediatorScheduling = mock(MediatorSchedulingConfiguration.class);
        channelScheduling = mock(ChannelSchedulingConfiguration.class);
        loggerManager = mock(LoggerManager.class);
        types = mock(Types.class);
        physicalChannelRepository = mock(ChannelPhysicalConnectionRepository.class);
        physicalNeRepository = mock(NePhysicalConnectionRepository.class);
        channelNotifications = mock(ChannelNotifications.class);
        neNotifications = mock(NetworkElementNotifications.class);
        channelEntityRepository = mock(ChannelEntityRepository.class);
        neEntityRepository = mock(NeEntityRepository.class);
        neInfoRepository = mock(NeInfoRepository.class);
        channelInfoRepository = mock(ChannelInfoRepository.class);

        final MediatorType type = MockFactory.mockMediatorType();

        when(types.values()).thenReturn(ImmutableList.of(type));
        when(types.get(anyString())).thenReturn(type);

        when(configuration.getMediatorTypes()).thenReturn(types);

        when(mediatorInfoRepository.queryByHost(anyString(), anyString())).thenReturn(empty());
        when(mediatorInfoRepository.query(anyString())).thenReturn(empty());
        when(mediatorRepository.getMediatorInfoRepository()).thenReturn(mediatorInfoRepository);

        when(neEntityRepository.getNeInfoRepository()).thenReturn(neInfoRepository);
        when(channelEntityRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
        when(channelEntityRepository.queryChannel(anyInt())).thenReturn(empty());

        update = new UpdateMediatorPropertiesBase<>(mock(CallContext.class),
                new RepositoriesToUpdate(mediatorRepository, mediatorInstanceRepository,
                        channelEntityRepository, physicalChannelRepository, neEntityRepository, physicalNeRepository),
                new NotificationsToSend(mediatorNotifications, channelNotifications, neNotifications),
                mediatorScheduling, channelScheduling, configuration, loggerManager,
                MediatorInstance.PRIMARY_PRIORITY_LEVEL);
    }

    private MediatorEntity buildEntity(int id) {
        return buildEntity(id, false);
    }

    private MediatorEntity buildEntity(int id, boolean activationRequired) {
        return buildEntity(id, activationRequired, ActualActivationState.INACTIVE);
    }

    private MediatorEntity buildEntity(int id, boolean activationRequired, ActualActivationState actualActivationState) {
        return new MediatorEntity(
                new MediatorInfoBuilder()
                    .setName("mediator#" + id)
                    .setTypeName("typeName")
                    .setActivationRequired(activationRequired)
                    .setConcurrentActivationsLimit(CONCURRENT_ACTIVATIONS_LIMIT)
                    .setConcurrentActivationsLimited(true)
                    .setActivationRequired(true)
                    .setDescription(Optional.of(MEDIATOR_DESCRIPTION))
                    .setReconnectAttemptInterval(RECONNECT_ATTEMPT_INTERVAL)
                    .build(id, 1),
                new MediatorConnectionBuilder()
                    .setActualActivationState(actualActivationState)
                    .build(id, 1));
    }

    private MediatorInstance buildInstance(int instanceId, int mediatorId) {
        return new MediatorInstance(
                new MediatorPhysicalDataBuilder().build(instanceId, mediatorId, 0),
                new MediatorPhysicalConnectionBuilder().build(instanceId, mediatorId, 0)
            );
    }

    private MediatorInstance buildInstance(int instanceId, int mediatorId, int priority, boolean active) {
        return new MediatorInstance(
                new MediatorPhysicalDataBuilder().setPriority(priority).build(instanceId, mediatorId, 0),
                new MediatorPhysicalConnectionBuilder().setActive(active).build(instanceId, mediatorId, 0)
            );
    }

    @SuppressWarnings("unchecked")
    @Test
    public void updateProperties() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT, "99");
        final MediatorInstance updatedInstance = buildInstance(777, 34);
        final MediatorInstance createdInstance = buildInstance(888, 34);

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
            .thenReturn(new MediatorInstanceUpdates(Collections.singleton(updatedInstance), Collections.singleton(createdInstance)));

        when(mediatorInstanceRepository.queryAll(34)).thenReturn(
                Collections.emptyList(),
                ImmutableList.of(updatedInstance, createdInstance));

        final Optional<MediatorInfoData> result = update.applyUpdate(34, newProps);

        assertThat(result, is(present()));
        assertThat(result.get().getConcurrentActivationsLimit(), is(99));

        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorNotifications).notifyUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorNotifications).notifyUpdateInstance(updatedInstance);
        verify(mediatorNotifications).notifyCreateInstance(createdInstance);
        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemMediator.class));
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(777, 99);
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(888, 99);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void updateProperties_withInstanceRemoval() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "");
        final MediatorInstance primaryInstance = buildInstance(777, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL, true);
        final MediatorInstance secondaryInstance = buildInstance(888, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1, false);

        final ChannelPhysicalConnectionData primaryChannel = new ChannelPhysicalConnectionBuilder()
                .build(PRIMARY_CHANNEL_ID, 777, 99, 1);
        final ChannelPhysicalConnectionData secondaryChannel = new ChannelPhysicalConnectionBuilder()
                .build(SECONDARY_CHANNEL_ID, 888, 99, 1);

        final NePhysicalConnectionData primaryNe = new NePhysicalConnectionBuilder()
                .build(PRIMARY_NE_ID, 88, PRIMARY_CHANNEL_ID, 1);
        final NePhysicalConnectionData secondaryNe = new NePhysicalConnectionBuilder()
                .build(SECONDARY_NE_ID, 88, SECONDARY_CHANNEL_ID, 1);

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
            .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), Collections.emptyList()));

        when(mediatorInstanceRepository.queryAll(34)).thenReturn(
                ImmutableList.of(primaryInstance, secondaryInstance),
                ImmutableList.of(primaryInstance));

        when(physicalChannelRepository.queryAll()).thenReturn(ImmutableList.of(primaryChannel, secondaryChannel));
        when(physicalNeRepository.queryAll()).thenReturn(ImmutableList.of(primaryNe, secondaryNe));

        final Optional<MediatorInfoData> result = update.applyUpdate(34, newProps);

        assertThat(result, is(present()));

        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorInstanceRepository).deleteInstance(888);
        verify(physicalChannelRepository, never()).remove(PRIMARY_CHANNEL_ID);
        verify(physicalChannelRepository).remove(SECONDARY_CHANNEL_ID);
        verify(physicalNeRepository, never()).remove(PRIMARY_NE_ID);
        verify(physicalNeRepository).remove(SECONDARY_NE_ID);

        verify(mediatorNotifications).notifyUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorNotifications).notifyDeleteInstance(34, 888);
        verify(channelNotifications).notifyDeleteInstance(99, SECONDARY_CHANNEL_ID);
        verify(channelNotifications, never()).notifyDeleteInstance(99, PRIMARY_CHANNEL_ID);
        verify(neNotifications).notifyDeleteInstance(88, SECONDARY_NE_ID);
        verify(neNotifications, never()).notifyDeleteInstance(88, PRIMARY_NE_ID);

        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemMediator.class));

        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(777, 77);
        verify(mediatorScheduling).onMediatorRemoved(888);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void updateProperties_withInstanceRemoval_activeInstance_fails() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "");
        final MediatorInstance primaryInstance = buildInstance(777, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL, false);
        final MediatorInstance secondaryInstance = buildInstance(888, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1, true);

        final NePhysicalConnectionData primaryNe = new NePhysicalConnectionBuilder()
                .build(PRIMARY_NE_ID, 88, PRIMARY_CHANNEL_ID, 1);
        final NePhysicalConnectionData secondaryNe = new NePhysicalConnectionBuilder()
                .build(SECONDARY_NE_ID, 88, SECONDARY_CHANNEL_ID, 1);

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
                .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), Collections.emptyList()));

        when(mediatorInstanceRepository.queryAll(34)).thenReturn(
                ImmutableList.of(primaryInstance, secondaryInstance),
                ImmutableList.of(primaryInstance));

        when(physicalChannelRepository.queryAll()).thenThrow(new RepositoryException());

        when(physicalNeRepository.queryAll()).thenReturn(ImmutableList.of(primaryNe, secondaryNe));

        try {
            update.applyUpdate(34, newProps);
            fail("Did not throw on deletion of active instance.");
        } catch (DataUpdateException e) {
            // ok
        }

        verify(mediatorInfoRepository, never()).tryUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorInstanceRepository, never()).deleteInstance(888);
        verify(physicalChannelRepository, never()).remove(anyInt());
        verify(physicalNeRepository, never()).remove(anyInt());

        verifyZeroInteractions(mediatorNotifications, channelNotifications, neNotifications, mediatorScheduling);

        verify(loggerManager, never()).createCommandLog(isA(CallContext.class), isA(LoggerItemMediator.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void updateProperties_withInstanceRemoval_physicalChannelRepoError_continues() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "");
        final MediatorInstance primaryInstance = buildInstance(777, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL, true);
        final MediatorInstance secondaryInstance = buildInstance(888, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1, false);

        final NePhysicalConnectionData primaryNe = new NePhysicalConnectionBuilder()
                .build(PRIMARY_NE_ID, 88, PRIMARY_CHANNEL_ID, 1);
        final NePhysicalConnectionData secondaryNe = new NePhysicalConnectionBuilder()
                .build(SECONDARY_NE_ID, 88, SECONDARY_CHANNEL_ID, 1);

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
                .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), Collections.emptyList()));

        when(mediatorInstanceRepository.queryAll(34)).thenReturn(
                ImmutableList.of(primaryInstance, secondaryInstance),
                ImmutableList.of(primaryInstance));

        when(physicalChannelRepository.queryAll()).thenThrow(new RepositoryException());

        when(physicalNeRepository.queryAll()).thenReturn(ImmutableList.of(primaryNe, secondaryNe));

        final Optional<MediatorInfoData> result = update.applyUpdate(34, newProps);

        assertThat(result, is(present()));

        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorInstanceRepository).deleteInstance(888);
        verify(physicalChannelRepository, never()).remove(anyInt());
        verify(physicalNeRepository, never()).remove(anyInt());

        verify(mediatorNotifications).notifyUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorNotifications).notifyDeleteInstance(34, 888);
        verify(channelNotifications, never()).notifyDeleteInstance(anyInt(), anyInt());
        verify(neNotifications, never()).notifyDeleteInstance(anyInt(), anyInt());

        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemMediator.class));

        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(777, 77);
        verify(mediatorScheduling).onMediatorRemoved(888);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void updateProperties_withInstanceRemoval_physicalNeRepoError_continues() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "");
        final MediatorInstance primaryInstance = buildInstance(777, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL, true);
        final MediatorInstance secondaryInstance = buildInstance(888, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1, false);

        final ChannelPhysicalConnectionData primaryChannel = new ChannelPhysicalConnectionBuilder()
                .build(PRIMARY_CHANNEL_ID, 777, 99, 1);
        final ChannelPhysicalConnectionData secondaryChannel = new ChannelPhysicalConnectionBuilder()
                .build(SECONDARY_CHANNEL_ID, 888, 99, 1);

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
                .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), Collections.emptyList()));

        when(mediatorInstanceRepository.queryAll(34)).thenReturn(
                ImmutableList.of(primaryInstance, secondaryInstance),
                ImmutableList.of(primaryInstance));

        when(physicalChannelRepository.queryAll()).thenReturn(ImmutableList.of(primaryChannel, secondaryChannel));
        when(physicalNeRepository.queryAll()).thenThrow(new RepositoryException());

        final Optional<MediatorInfoData> result = update.applyUpdate(34, newProps);

        assertThat(result, is(present()));

        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorInstanceRepository).deleteInstance(888);
        verify(physicalChannelRepository, never()).remove(PRIMARY_CHANNEL_ID);
        verify(physicalChannelRepository).remove(SECONDARY_CHANNEL_ID);
        verify(physicalNeRepository, never()).remove(anyInt());

        verify(mediatorNotifications).notifyUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorNotifications).notifyDeleteInstance(34, 888);
        verify(channelNotifications).notifyDeleteInstance(99, SECONDARY_CHANNEL_ID);
        verify(channelNotifications, never()).notifyDeleteInstance(99, PRIMARY_CHANNEL_ID);
        verify(neNotifications, never()).notifyDeleteInstance(anyInt(), anyInt());

        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemMediator.class));

        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(777, 77);
        verify(mediatorScheduling).onMediatorRemoved(888);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void updateProperties_withNewInstance() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "1.2.3.4");
        final MediatorInstance primaryInstance = buildInstance(777, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL, true);
        final MediatorInstance secondaryInstance = buildInstance(888, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1, false);

        final ChannelPhysicalConnectionData primaryChannel = new ChannelPhysicalConnectionBuilder()
                .build(PRIMARY_CHANNEL_ID, 777, 99, 1);
        final ChannelPhysicalConnectionData secondaryChannel = new ChannelPhysicalConnectionBuilder()
                .build(SECONDARY_CHANNEL_ID, 888, 99, 1);

        final NeInfoData neInfo = new NeInfoBuilder().setProxyType("type").build(88, 99, 1);
        final NePhysicalConnectionData primaryNe = new NePhysicalConnectionBuilder()
                .build(PRIMARY_NE_ID, 88, PRIMARY_CHANNEL_ID, 1);
        final NePhysicalConnectionData secondaryNe = new NePhysicalConnectionBuilder()
                .build(SECONDARY_NE_ID, 88, SECONDARY_CHANNEL_ID, 1);

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
                .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), ImmutableList.of(secondaryInstance)));

        when(mediatorInstanceRepository.queryAll(34)).thenReturn(
                ImmutableList.of(primaryInstance),
                ImmutableList.of(primaryInstance, secondaryInstance));

        when(channelInfoRepository.queryChannelIdsUnderMediator(34)).thenReturn(Collections.singleton(99));

        when(physicalChannelRepository.queryAll()).thenReturn(ImmutableList.of(primaryChannel));
        when(physicalChannelRepository.insert(isA(ChannelConnectionInitialData.class), eq(99), eq(888)))
                .thenReturn(secondaryChannel);

        when(neInfoRepository.queryAll(99)).thenReturn(Collections.singleton(neInfo));

        when(physicalNeRepository.queryAll()).thenReturn(ImmutableList.of(primaryNe));
        when(physicalNeRepository.insert(isA(NePhysicalConnectionInitialData.class), eq(88), eq(SECONDARY_CHANNEL_ID)))
                .thenReturn(secondaryNe);

        final Optional<MediatorInfoData> result = update.applyUpdate(34, newProps);

        assertThat(result, is(present()));

        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorInstanceRepository, never()).deleteInstance(anyInt());
        verify(physicalChannelRepository, never()).remove(anyInt());
        verify(physicalNeRepository, never()).remove(anyInt());

        verify(mediatorNotifications).notifyUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorNotifications).notifyCreateInstance(secondaryInstance);
        verify(channelNotifications).notifyCreateInstance(secondaryChannel);
        verify(neNotifications).notifyCreateInstance(secondaryNe);

        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemMediator.class));

        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(777, 77);
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(888, 77);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void updateProperties_withNewInstance_channelRepoError_continues() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "1.2.3.4");
        final MediatorInstance primaryInstance = buildInstance(777, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL, true);
        final MediatorInstance secondaryInstance = buildInstance(888, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1, false);

        final ChannelPhysicalConnectionData primaryChannel = new ChannelPhysicalConnectionBuilder()
                .build(PRIMARY_CHANNEL_ID, 777, 99, 1);
        final ChannelPhysicalConnectionData secondaryChannel = new ChannelPhysicalConnectionBuilder()
                .build(SECONDARY_CHANNEL_ID, 888, 99, 1);

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
                .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), ImmutableList.of(secondaryInstance)));

        when(mediatorInstanceRepository.queryAll(34)).thenReturn(
                ImmutableList.of(primaryInstance),
                ImmutableList.of(primaryInstance, secondaryInstance));

        when(channelInfoRepository.queryChannelIdsUnderMediator(34)).thenThrow(new RepositoryException());

        final Optional<MediatorInfoData> result = update.applyUpdate(34, newProps);

        assertThat(result, is(present()));

        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorInstanceRepository, never()).deleteInstance(anyInt());
        verify(physicalChannelRepository, never()).remove(anyInt());
        verify(physicalNeRepository, never()).remove(anyInt());

        verify(mediatorNotifications).notifyUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorNotifications).notifyCreateInstance(secondaryInstance);
        verify(channelNotifications, never()).notifyCreateInstance(any(ChannelPhysicalConnectionData.class));
        verify(neNotifications, never()).notifyCreateInstance(any(NePhysicalConnectionData.class));

        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemMediator.class));

        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(777, 77);
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(888, 77);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void updateProperties_withNewInstance_neRepoError_continues() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "1.2.3.4");
        final MediatorInstance primaryInstance = buildInstance(777, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL, true);
        final MediatorInstance secondaryInstance = buildInstance(888, 34, MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1, false);

        final ChannelPhysicalConnectionData primaryChannel = new ChannelPhysicalConnectionBuilder()
                .build(PRIMARY_CHANNEL_ID, 777, 99, 1);
        final ChannelPhysicalConnectionData secondaryChannel = new ChannelPhysicalConnectionBuilder()
                .build(SECONDARY_CHANNEL_ID, 888, 99, 1);

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
                .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), ImmutableList.of(secondaryInstance)));

        when(mediatorInstanceRepository.queryAll(34)).thenReturn(
                ImmutableList.of(primaryInstance),
                ImmutableList.of(primaryInstance, secondaryInstance));

        when(channelInfoRepository.queryChannelIdsUnderMediator(34)).thenReturn(Collections.singleton(99));

        when(physicalChannelRepository.queryAll()).thenReturn(ImmutableList.of(primaryChannel));
        when(physicalChannelRepository.insert(isA(ChannelConnectionInitialData.class), eq(99), eq(888)))
                .thenReturn(secondaryChannel);

        when(neInfoRepository.queryAll(99)).thenThrow(new RepositoryException());

        final Optional<MediatorInfoData> result = update.applyUpdate(34, newProps);

        assertThat(result, is(present()));

        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorInstanceRepository, never()).deleteInstance(anyInt());
        verify(physicalChannelRepository, never()).remove(anyInt());
        verify(physicalNeRepository, never()).remove(anyInt());

        verify(mediatorNotifications).notifyUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorNotifications).notifyCreateInstance(secondaryInstance);
        verify(channelNotifications).notifyCreateInstance(secondaryChannel);
        verify(neNotifications, never()).notifyCreateInstance(isA(NePhysicalConnectionData.class));

        verify(loggerManager).createCommandLog(isA(CallContext.class), isA(LoggerItemMediator.class));

        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(777, 77);
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(888, 77);
    }

    @Test
    public void updateProperties_withName_logs() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.ID_NAME, "new name");

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
            .then(new MutationAnswer<>());

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
            .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), Collections.emptyList()));

        when(mediatorInstanceRepository.queryAll(34)).thenReturn(Collections.emptyList());

        final Optional<MediatorInfoData> result = update.applyUpdate(34, newProps);

        assertThat(result, is(present()));
        assertThat(result.get().getName(), is("new name"));

        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorNotifications).notifyUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(loggerManager, times(2)).createCommandLog(isA(CallContext.class), isA(LoggerItemMediator.class));
    }

    @Test
    public void update_emptyProperties_doesNothing() throws Exception {

        final MediatorEntity entity = buildEntity(ID);
        when(mediatorRepository.query(ID)).thenReturn(Optional.of(entity));

        final Optional<MediatorInfoData> result = update.applyUpdate(ID, Collections.emptyMap());

        assertThat(result, is(absent()));

        verify(mediatorInfoRepository, never()).tryUpdate(isA(MediatorInfoMutationDescriptor.class));
        verifyZeroInteractions(mediatorNotifications, loggerManager, mediatorScheduling);
    }

    @Test
    public void update_sameProperties_doesNothing() throws Exception {

        final MediatorEntity entity = buildEntity(ID);
        when(mediatorRepository.query(ID)).thenReturn(Optional.of(entity));

        final Map<String, String> newProperties = new HashMap<>();
        newProperties.put(WellKnownMediatorPropertyNames.ID_NAME, entity.getInfo().getName());
        newProperties.put(WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT, String.valueOf(entity.getInfo().getConcurrentActivationsLimit()));
        newProperties.put(WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMITED, String.valueOf(entity.getInfo().isConcurrentActivationsLimited()));
        newProperties.put(WellKnownMediatorPropertyNames.DESCRIPTION, entity.getInfo().getDescription().get());
        newProperties.put(WellKnownMediatorPropertyNames.RECONNECT_INTERVAL, String.valueOf(entity.getInfo().getReconnectAttemptInterval()));

        final Optional<MediatorInfoData> result = update.applyUpdate(ID, newProperties);

        assertThat(result, is(absent()));

        verify(mediatorInfoRepository, never()).tryUpdate(isA(MediatorInfoMutationDescriptor.class));
        verifyZeroInteractions(mediatorNotifications, loggerManager, mediatorScheduling);
    }

    @Test
    public void updateProperties_noChanges_reportsAbsent() throws Exception {

        final MediatorEntity entity = buildEntity(34);

        final Map<String, String> newProps = new HashMap<>();
        newProps.put(WellKnownMediatorPropertyNames.ID_NAME, entity.getInfo().getName());

        when(mediatorRepository.query(34)).thenReturn(Optional.of(entity));

        final Optional<MediatorInfoData> result = update.applyUpdate(34, newProps);

        assertThat(result, is(absent()));
        verifyZeroInteractions(mediatorInfoRepository, mediatorNotifications, loggerManager, mediatorScheduling);
    }

    @Test
    public void updateProperties_emptyMap_reportsAbsent() throws Exception {

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        final Optional<MediatorInfoData> result = update.applyUpdate(34, ImmutableMap.of());

        assertThat(result, is(absent()));
        verifyZeroInteractions(mediatorInfoRepository, mediatorNotifications, loggerManager, mediatorScheduling);
    }

    @Test
    public void updateProperties_updateFails_reportsAbsent() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.ID_NAME, "new name");

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class))).thenReturn(empty());

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
            .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), Collections.emptyList()));

        final Optional<MediatorInfoData> result = update.applyUpdate(34, newProps);

        assertThat(result, is(absent()));
        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorNotifications, never()).notifyUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(loggerManager, never()).createCommandLog(isA(CallContext.class), isA(LoggerItemMediator.class));
        verifyZeroInteractions(mediatorScheduling);
    }

    @Test(expected=UnknownMediatorTypeException.class)
    public void updateProperties_unknownType_throws() throws Exception {

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));
        when(types.get("typeName")).thenReturn(null);

        update.applyUpdate(34, Collections.emptyMap());
    }

    @Test(expected=UnknownMediatorIdException.class)
    public void updateProperties_unknownMediator_throws() throws Exception {

        when(mediatorRepository.query(anyInt())).thenReturn(empty());

        update.applyUpdate(34, Collections.emptyMap());
    }

    @Test(expected=RepositoryException.class)
    public void updateProperties_repoErrorOnQuery_throws() throws Exception {

        when(mediatorRepository.query(anyInt())).thenThrow(new RepositoryException());

        update.applyUpdate(34, Collections.emptyMap());
    }

    @Test(expected=RepositoryException.class)
    public void updateProperties_repoErrorOnUpdate_throws() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT, "99");

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
            .thenThrow(new RepositoryException());

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
            .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), Collections.emptyList()));

        update.applyUpdate(34, newProps);
    }

    @Test(expected=InvalidMutationException.class)
    public void updateProperties_badValue_throws() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT, "xpto");

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInstanceRepository.updateInstance(eq(34), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
            .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), Collections.emptyList()));

        update.applyUpdate(34, newProps);
    }

}
