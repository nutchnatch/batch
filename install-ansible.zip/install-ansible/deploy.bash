#!/bin/bash

REPOSITORY=http://world-tsp-ci-assurance.is.echonet/nexus/repository/raw-internal
RESOURCE="$REPOSITORY/software/ansible/install-ansible.bash"

echo "This script will install-ansible.bash in the repository."

[ -z "$REPO_AUTH" ] && echo "Error - Need to set REPO_AUTH environment variable. export REPO_AUTH=login:password" && exit 1;
echo "- Deploy the script"

curl -v --user "${REPO_AUTH}" --upload-file install-ansible.bash $RESOURCE
