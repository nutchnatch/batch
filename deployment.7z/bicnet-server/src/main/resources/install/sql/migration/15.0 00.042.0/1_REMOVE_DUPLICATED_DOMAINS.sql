CREATE OR REPLACE PROCEDURE emne_remove_AS_dupl AS 
    var_domain_name         EMNE_AS.name%type;
    var_em_id               EMNE_AS.em_id%type;
    var_count               number;
    var_domain_id           EMNE_AS.id%type;
    
    var_verify_dupl_sql     varchar2(700);  
    TYPE C_VERIFY_DUPL      IS REF CURSOR;
    record_verify_dupl      C_VERIFY_DUPL;
    
    var_domain_dupl_sql     varchar2(700);  
    TYPE C_DOMAIN_DUPL      IS REF CURSOR;
    record_domain_dupl      C_DOMAIN_DUPL;
    
    var_domain_to_save      EMNE_AS.id%type;
    
BEGIN    
    var_verify_dupl_sql := 'SELECT   domain.name, domain.em_id, COUNT(*)                            
                            FROM     EMNE_AS domain
                            GROUP BY domain.name, domain.em_id
                            HAVING   COUNT(*) > 1';
    
    OPEN record_verify_dupl FOR var_verify_dupl_sql;
  
    LOOP
        FETCH record_verify_dupl INTO var_domain_name, var_em_id, var_count;
        EXIT WHEN record_verify_dupl%NOTFOUND;
                
        var_domain_dupl_sql := ' SELECT   domain.id 
                                 FROM     EMNE_AS domain 
                                 WHERE    domain.em_id = '   || var_em_id ||
                               ' AND      domain.name  = ''' || var_domain_name || '''' ||
                               ' ORDER BY domain.id';
      
        OPEN record_domain_dupl FOR var_domain_dupl_sql;
      
        LOOP
            FETCH record_domain_dupl INTO var_domain_id;
            EXIT WHEN record_domain_dupl%NOTFOUND;
            
            IF (var_domain_to_save IS NULL) THEN
                var_domain_to_save := var_domain_id;        
                CONTINUE;
            END IF;
            
            IF (var_domain_to_save != var_domain_id) THEN            
                EXECUTE IMMEDIATE 'DELETE FROM EMNE_AS_NE WHERE AS_ID = ' || var_domain_id;
                EXECUTE IMMEDIATE 'DELETE FROM EMNE_AS    WHERE ID    = ' || var_domain_id;                
            END IF;
                                    
        END LOOP;

		var_domain_to_save := null;
        CLOSE record_domain_dupl;       
    END LOOP;

    CLOSE record_verify_dupl;    
    
EXCEPTION
    WHEN OTHERS THEN
        IF( record_domain_dupl%ISOPEN ) THEN
            CLOSE record_domain_dupl;
        END IF;
        
        IF( record_verify_dupl%ISOPEN ) THEN
            CLOSE record_verify_dupl;
        END IF;
  
END emne_remove_AS_dupl;
/
CALL emne_remove_AS_dupl();

DROP PROCEDURE emne_remove_AS_dupl;