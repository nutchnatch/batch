BEGIN
	DECLARE
		addPermissionItemVar NUMBER;
	BEGIN
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Mediator Properties - Read Only','Open Mediator properties in read-only mode');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->EM Properties - Read Only','Open Channel properties in read-only mode');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Properties - Read Only','Open NE properties in read-only mode');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Container Properties - Read Only','Open Container properties in read-only mode');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Permissions for mediators objects already exists');

	END;
END;
/
BEGIN
	DECLARE
		vboolean BOOLEAN;
	BEGIN
    vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Object Context Menu->Mediator Properties - Read Only');
    vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Object Context Menu->EM Properties - Read Only');
    vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Object Context Menu->Properties - Read Only');
    vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Object Context Menu->Container Properties - Read Only');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Permissions for mediators objects already exists');
	END;
END;
/