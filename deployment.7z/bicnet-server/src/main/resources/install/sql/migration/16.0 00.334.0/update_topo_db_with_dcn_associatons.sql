UPDATE topo_topological_container topo
   SET topo.dcn_container_id =
       NVL((SELECT dcn.container_id
              FROM dcn_container dcn
             WHERE dcn.container_type = 'GENERIC'
               AND dcn.container_name = topo.name), -1)
 WHERE topo.system_container_id = 0
   AND topo.id != 0;

UPDATE DCN_CONTAINER SET PARENT_CONTAINER_ID = 0 WHERE PARENT_CONTAINER_ID IS NULL AND CONTAINER_ID != 0;