BEGIN
	DECLARE
		vboolean BOOLEAN;
	BEGIN
    vboolean := USMPERMISSIONITEMUNASSIGN('Network Supervision','Object Context Menu->Properties');
    vboolean := USMPERMISSIONITEMUNASSIGN('Network Supervision','Object Context Menu->EM Properties');
    vboolean := USMPERMISSIONITEMUNASSIGN('Network Administration','Object Context Menu->Mediator Properties');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Unassign Permissions from Supervision threw exception.');
	END;
END;
/

BEGIN
	DECLARE
		vboolean BOOLEAN;
	BEGIN
    vboolean := USMPERMISSIONITEMASSIGN('Network Configuration','Object Context Menu->Properties');
    vboolean := USMPERMISSIONITEMASSIGN('Network Configuration','Object Context Menu->EM Properties');
    vboolean := USMPERMISSIONITEMASSIGN('Network Configuration','Object Context Menu->Mediator Properties');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Permissions assign trew exceptions.');
	END;
END;
/