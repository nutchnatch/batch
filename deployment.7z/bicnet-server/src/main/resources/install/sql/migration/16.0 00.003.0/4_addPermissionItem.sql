BEGIN
	DECLARE
		addPermissionItemVar NUMBER;
	BEGIN
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Activate Mediators','Activate Mediators');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Deactivate Mediators','Deactivate Mediators');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->New (Mediator)','New Mediator');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Mediator Properties','Open Mediator Properties');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Move Channel','Move Channel');
    addPermissionItemVar := USMPERMISSIONITEMADD('DCN-Manager->System Preferences','DCN System Preferences');
    
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Permissions for mediators objects already exists');

	END;
END;
/
BEGIN
	DECLARE
		vboolean BOOLEAN;
	BEGIN
    vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Activate Mediators');
    vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Deactivate Mediators');
    vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->New (Mediator)');
    vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Object Context Menu->Mediator Properties');
    vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Move Channel');
    vboolean := USMPERMISSIONITEMASSIGN('Network Configuration','DCN-Manager->System Preferences');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Permissions for mediators objects already exists');
	END;
END;
/