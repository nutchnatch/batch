DECLARE
		vboolean BOOLEAN;
BEGIN
	BEGIN
    vboolean := USMPERMISSIONITEMRENAME('Object Context Menu->Mediator Properties', 'Network->DCN->Mediator Properties');
    DBMS_OUTPUT.PUT_LINE('Success renaming permission item Object Context Menu->Mediator Properties to Network->DCN->Mediator Properties. ');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to rename permission item Object Context Menu->Mediator Properties to Network->DCN->Mediator Properties.');
	END;
	BEGIN
    vboolean := USMPERMISSIONITEMRENAME('Object Context Menu->EM Properties', 'Network->DCN->EM Properties');
    DBMS_OUTPUT.PUT_LINE('Success renaming permission item Object Context Menu->EM Properties to Network->DCN->EM Properties');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to rename permission item Object Context Menu->EM Properties to Network->DCN->EM Properties');
	END;
	BEGIN
    vboolean := USMPERMISSIONITEMRENAME('Object Context Menu->Container Properties', 'Network->DCN->Container Properties');
    DBMS_OUTPUT.PUT_LINE('Success renaming permission item Object Context Menu->Container Properties to Network->DCN->Container Properties');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to rename permission item Object Context Menu->Container Properties to Network->DCN->Container Properties.');
	END;
	BEGIN
	vboolean := USMPERMISSIONITEMRENAME('Object Context Menu->Mediator Properties - Read Only', 'Network->DCN->Mediator Properties - Read Only');
    DBMS_OUTPUT.PUT_LINE('Success renaming permission item Object Context Menu->Mediator Properties - Read Only to Network->DCN->Mediator Properties - Read Only');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to rename permission item Object Context Menu->Mediator Properties - Read Only to Network->DCN->Mediator Properties - Read Only.');
	END;
	BEGIN
    vboolean := USMPERMISSIONITEMRENAME('Object Context Menu->EM Properties - Read Only', 'Network->DCN->EM Properties - Read Only');
    DBMS_OUTPUT.PUT_LINE('Success renaming permission item Object Context Menu->EM Properties - Read Only to Network->DCN->EM Properties - Read Only');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to rename permission item Object Context Menu->EM Properties - Read Only to Network->DCN->EM Properties - Read Only');
	END;
	BEGIN
    vboolean := USMPERMISSIONITEMRENAME('Object Context Menu->Container Properties - Read Only', 'Network->DCN->Container Properties - Read Only');
    DBMS_OUTPUT.PUT_LINE('Success renaming permission item Object Context Menu->Container Properties - Read Only to Network->DCN->Container Properties - Read Only');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to rename permission item Object Context Menu->Container Properties - Read Only to Network->DCN->Container Properties - Read Only.');
	END;
	BEGIN
    vboolean := USMPERMISSIONITEMRENAME('Object Context Menu->Properties - Read Only', 'Network->DCN->Properties - Read Only');
    DBMS_OUTPUT.PUT_LINE('Success renaming permission item Object Context Menu->Properties - Read Only to Network->DCN->Properties - Read Only');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to rename permission item Object Context Menu->Properties - Read Only to Network->DCN->Properties - Read Only');
	END;
  
	BEGIN
	vboolean := USMPERMISSIONITEMUNASSIGN('Network Configuration','Network->DCN->Mediator Properties');
    DBMS_OUTPUT.PUT_LINE('Success unassigning permission item Network->DCN->Mediator Properties.');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to unassign permission item Network->DCN->Mediator Properties.');
	END;
	BEGIN
	vboolean := USMPERMISSIONITEMUNASSIGN('Network Configuration','Network->DCN->EM Properties');
    DBMS_OUTPUT.PUT_LINE('Success unassigning permission item Network->DCN->EM Properties.');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to unassign permission item Network->DCN->EM Properties.');
	END;
	BEGIN
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Mediator Properties');
    DBMS_OUTPUT.PUT_LINE('Success assigning permission item Network->DCN->Mediator Properties.');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to assign permission item Network->DCN->Mediator Properties.');
	END;
	BEGIN
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->EM Properties');
    DBMS_OUTPUT.PUT_LINE('Success assigning permission item Network->DCN->EM Properties.');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to assign permission item Network->DCN->EM Properties.');
	END;
	BEGIN
	vboolean := USMPERMISSIONITEMUNASSIGN('Network Configuration','DCN-Manager->System Preferences');
    DBMS_OUTPUT.PUT_LINE('Success unassigning permission item DCN-Manager->System Preferences.');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to unassign permission item DCN-Manager->System Preferences.');
	END;
	BEGIN
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','DCN-Manager->System Preferences');
    DBMS_OUTPUT.PUT_LINE('Success assigning permission item DCN-Manager->System Preferences.');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to assign permission item DCN-Manager->System Preferences.');
	END;
	BEGIN
	vboolean := USMPERMISSIONITEMUNASSIGN('Network Configuration','Object Context Menu->Properties');
    DBMS_OUTPUT.PUT_LINE('Success unassigning permission item Object Context Menu->Properties.');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to unassign permission item Object Context Menu->Properties.');
	END;
	BEGIN
	vboolean := USMPERMISSIONITEMREMOVE('Object Context Menu->Properties');
    DBMS_OUTPUT.PUT_LINE('Success removing permission item Object Context Menu->Properties.');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Failed to remove permission item Object Context Menu->Properties.');
	END;
END;
/
