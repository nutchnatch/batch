/*
 * Migrate all Topological Containers to DCN manager.
 */
CREATE OR REPLACE PROCEDURE migrate_topo_containers IS
BEGIN

   -- insert topo containers in dcn
   INSERT INTO dcn_container 
         (container_id, container_name, container_description, version, container_type, parent_container_id)
   SELECT DCN_SEQ_CONTAINER_ID.nextval,
          topo.name, 
          topo.additional_info,
          0,
          'GENERIC',
          0 -- Set all to Root Container parent first.
     FROM topo_topological_container topo
    WHERE topo.system_container_id = 0
      AND topo.id                 != 0
      AND (SELECT COUNT(dcn.container_name)
             FROM dcn_container dcn
            WHERE dcn.container_name = topo.name
              AND dcn.container_type = 'GENERIC') = 0;

   -- update parent container id
   UPDATE dcn_container dcn
      SET dcn.parent_container_id = 
         (SELECT NVL((SELECT dc.container_id
                        FROM dcn_container dc, topo_topological_container tc
                       WHERE dc.container_name       = tc.name
                         AND dc.container_type       = 'GENERIC'
                         AND topo.owned_by_container = tc.id), 0) container_id
            FROM topo_topological_container topo
           WHERE topo.system_container_id = 0
             AND dcn.container_type       = 'GENERIC'
             AND dcn.container_name       = topo.name);
   COMMIT;
EXCEPTION
   WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('ERROR ON MIGRATE TOPO CONTAINERS');
      DBMS_OUTPUT.PUT_LINE( SUBSTR(SQLERRM, 1, 999) );      
END migrate_topo_containers;
/

/*
 * Migrate all Topological Containers x NE assignments to DCN manager.
 */
CREATE OR REPLACE PROCEDURE migrate_tc_ne_assignments IS
BEGIN
   -- Query all NE assignments
   INSERT INTO dcn_container_ne (ne_id, container_id, assignment)
   SELECT (ne.ne_id) ne_id,
           
           NVL((SELECT dcn.container_id
                  FROM dcn_container dcn, topo_topological_container topo
                 WHERE dcn.container_name    = topo.name
                   AND dcn.container_type    = 'GENERIC'
                   AND association.parent_tc = topo.id), 0) container_id,
           
           CASE WHEN (association.marked_as_owner = 1)
                     THEN 'PRIMARY'
                     ELSE 'LOGICAL' 
           END assignment_type
     FROM topo_symbol_container_a association, topo_topological_symbol symbol, dcn_ne_info ne
    WHERE symbol.id = association.child_ts
      AND ne.ne_id  = symbol.network_element_id;
   COMMIT;
EXCEPTION
   WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('ERROR ON MIGRATE TOPO NE x CONTAINERS assignments');
      DBMS_OUTPUT.PUT_LINE( SUBSTR(SQLERRM, 1, 999) );      
END migrate_tc_ne_assignments;
/

/*
 * Migrate all Topological Containers x System assignments to DCN manager.
 */
CREATE OR REPLACE PROCEDURE migrate_system_assignments IS
BEGIN
   -- Query all systems
   INSERT INTO dcn_container_system (system_id, container_id, assignment)
   SELECT topo.system_container_id,
   
          NVL((SELECT dcn.container_id
                 FROM dcn_container dcn, topo_topological_container tc
                WHERE dcn.container_name    = tc.name
                  AND dcn.container_type    = 'GENERIC'
                  AND topo.owned_by_container = tc.id), 0) container_id,
                  
          'PRIMARY'
     FROM topo_topological_container topo
    WHERE topo.system_container_id != 0
      AND topo.id                  != 0;
   
   COMMIT;
EXCEPTION
   WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('ERROR ON MIGRATE SYSTEM x CONTAINERS assignments');
      DBMS_OUTPUT.PUT_LINE( SUBSTR(SQLERRM, 1, 999) );      
END migrate_system_assignments;
/

/*
 * Migrate all NEs and System, those not have assigments, to a Default Ne Container.
 */
CREATE OR REPLACE PROCEDURE associate_default_container IS
   default_container_id NUMBER := NULL;
BEGIN
   -- CREATE DEFAULT CONTAINER
   INSERT INTO DCN_CONTAINER
               (CONTAINER_ID, CONTAINER_TYPE, VERSION, CONTAINER_NAME, PARENT_CONTAINER_ID)
        VALUES (DCN_SEQ_CONTAINER_ID.nextval, 'GENERIC', 0, 'Default Ne Container', 0);
   
   SELECT container_id 
     INTO default_container_id 
     FROM DCN_CONTAINER
    WHERE container_name = 'Default Ne Container';
   
   INSERT INTO dcn_container_ne (ne_id, container_id, assignment)   
   SELECT DISTINCT ne_id, default_container_id, 'PRIMARY' FROM dcn_ne_info
   MINUS
   SELECT DISTINCT ne_id, default_container_id, 'PRIMARY' FROM dcn_container_ne;
   
   INSERT INTO dcn_container_system (system_id, container_id, assignment)
   SELECT DISTINCT container_id, default_container_id, 'PRIMARY' FROM dcn_container where container_type = 'SYSTEM'
   MINUS
   SELECT DISTINCT system_id, default_container_id, 'PRIMARY' FROM dcn_container_system;
   
   COMMIT;
EXCEPTION
   WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('ERROR ON ASSOCIATE NES TO THE DEFAULT CONTAINER');
      DBMS_OUTPUT.PUT_LINE( SUBSTR(SQLERRM, 1, 999) );      
END associate_default_container;
/

CALL migrate_topo_containers();
CALL migrate_tc_ne_assignments();
CALL migrate_system_assignments();
CALL associate_default_container();

DROP PROCEDURE migrate_topo_containers;
DROP PROCEDURE migrate_tc_ne_assignments;
DROP PROCEDURE migrate_system_assignments;
DROP PROCEDURE associate_default_container;
