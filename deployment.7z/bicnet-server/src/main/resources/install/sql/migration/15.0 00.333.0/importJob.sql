   update EMNE_CORE_IMPORT_JOB_DETAILS set SFTP_SETTINGS = 1 where SFTP_SETTINGS is null;
   commit;