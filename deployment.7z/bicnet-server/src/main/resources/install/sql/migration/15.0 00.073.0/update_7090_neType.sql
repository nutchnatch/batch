DECLARE
   c_id emne_icon.id%type := 'icon_pair_7090_default';
   c_emne_type_id emne_ne_type.id%type := 'hiT 7090 1.00';
   icon_ID VARCHAR2(255);
   neType_ID VARCHAR2(255);
   
   emneType_ID EMNE_NE_TYPE.ID%type := '7090 2.00';
   emneType_PROPERTIES_XML EMNE_NE_TYPE.PROPERTIES_XML%type := null;
   emneType_GUI_LABEL_SHORT EMNE_NE_TYPE.GUI_LABEL_SHORT%type := '7090 2.00 NE';
   emneType_GUI_LABEL_LONG EMNE_NE_TYPE.GUI_LABEL_LONG%type := '7090 2.00 Network Element';
   emneType_ICON_ID EMNE_NE_TYPE.ICON_ID%type := 'icon_pair_7090_default';
   emneType_SUPPORTED_LAYERS EMNE_NE_TYPE.SUPPORTED_LAYERS%type := '101111011000000000001111000110001111000110000111100011110000011011001000000000000000000000001111101100010000000000000000';
   emneType_CAPABILITIES EMNE_NE_TYPE.CAPABILITIES%type := '100111000010010000000000111';
   emneType_PASSW_POLICY EMNE_NE_TYPE.PASSW_POLICY%type := 'validatePassword';
   emneType_PROTOCOL EMNE_NE_TYPE.PROTOCOL%type := 'RMT';
   emneType_NE_CONTROLLER_ID EMNE_NE_TYPE.NE_CONTROLLER_ID%type := 'com.ossnms.mvm.hit7090';
   emneType_MO_VERSION EMNE_NE_TYPE.MO_VERSION%type := 4;
   emneType_LAST_UPDATED EMNE_NE_TYPE.LAST_UPDATED%type := null;
BEGIN  
    BEGIN
        SELECT id INTO icon_ID
        FROM emne_icon
        WHERE id = c_id;
    
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                icon_ID := NULL;
    END;
    
    BEGIN
        SELECT ID INTO neType_ID
        FROM emne_ne_type
        WHERE ID = c_emne_type_id;
    
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                neType_ID := NULL;
    END;

    BEGIN
       IF(icon_ID IS NOT NULL) THEN
           IF(neType_ID IS NOT NULL) THEN
              INSERT INTO EMNE_NE_TYPE VALUES (emneType_ID,emneType_PROPERTIES_XML,emneType_GUI_LABEL_SHORT,emneType_GUI_LABEL_LONG,emneType_ICON_ID,emneType_SUPPORTED_LAYERS,emneType_CAPABILITIES,emneType_PASSW_POLICY,emneType_PROTOCOL,emneType_NE_CONTROLLER_ID,emneType_MO_VERSION,emneType_LAST_UPDATED);
              UPDATE EMNE_NE set ne_type_id = '7090 2.00' WHERE ne_type_id='hiT 7090 1.00';
              UPDATE EMNE_NE_Properties SET value = '7090 2.00' WHERE value='hiT 7090 1.00' and key_='Type';
              UPDATE EMNE_NE_TYPE_Properties SET ne_type_id = '7090 2.00' WHERE ne_type_id='hiT 7090 1.00';
              UPDATE EMNE_NE_TYPE_PROPERTY_PAGE_MAP SET ne_type_id = '7090 2.00' WHERE ne_type_id='hiT 7090 1.00';
              UPDATE EMNE_EM_TYPE_SUP_NE_TYPES SET ne_type_id = '7090 2.00' where ne_type_id='hiT 7090 1.00';
              DELETE FROM EMNE_NE_TYPE WHERE ID = 'hiT 7090 1.00';
           END IF;
       END IF;
    END;
END;
/