-- MVM
UPDATE EMNE_EM_PROPERTIES prop
   SET prop.VALUE = (SELECT 'remote://' || em.DISPLAY_ADDRESS || ':4449'
				       FROM EMNE_EM em
                      WHERE prop.EM_ID = em.ID                           
                        AND em.EM_TYPE_ID = 'EM-MVM')
 WHERE prop.VALUE LIKE 'jnp://%'
   AND prop.EM_ID = (SELECT id FROM EMNE_EM em WHERE prop.EM_ID = em.ID AND em.EM_TYPE_ID = 'EM-MVM');
   
-- GM
UPDATE EMNE_EM_PROPERTIES prop
   SET prop.VALUE = (SELECT 'remote://' || em.DISPLAY_ADDRESS || ':4448'
				       FROM EMNE_EM em
                      WHERE prop.EM_ID = em.ID                           
                        AND em.EM_TYPE_ID = 'EM-GM')
 WHERE prop.VALUE LIKE 'jnp://%'
   AND prop.EM_ID = (SELECT id FROM EMNE_EM em WHERE prop.EM_ID = em.ID AND em.EM_TYPE_ID = 'EM-GM');