insert into emne_ne_type (ID, GUI_LABEL_SHORT, GUI_LABEL_LONG, GUI_HELP_ID, ICON_ID, SUPPORTED_LAYERS, CAPABILITIES, PASSW_POLICY, PROTOCOL, NE_CONTROLLER_ID, MO_VERSION)
values ('7090 M 2.x', '7090 M 2.x NE', '7090 M 2.x Network Element', '123402', 'icon_pair_7090_default', '101111011000000000001111000110001111000110000111100011110000011011001000000000000000000000001111101100010000000000000000', '100111000000010000000000111000100000', 'validatePassword', 'RMT', 'com.ossnms.mvm.hit7090', 1 );
update emne_ne_type_properties set ne_type_id = '7090 M 2.x' where ne_type_id = '7090 2.00';
update EMNE_EM_TYPE_SUP_NE_TYPES set NE_TYPE_ID = '7090 M 2.x' where ne_type_id = '7090 2.00';
update EMNE_NE_TYPE_PROPERTY_PAGE_MAP set NE_TYPE_ID = '7090 M 2.x' where ne_type_id = '7090 2.00';
update emne_ne set ne_type_id = '7090 M 2.x' where ne_type_id = '7090 2.00';
delete from emne_ne_type where ID = '7090 2.00';