/*
 * Migration script for:
 * EM/NE (TNMS 15.x) to DCN Manager (TNMS 16.0)
 */

/*
 * Identify the Mediator type from a Channel type.
 */
CREATE OR REPLACE FUNCTION get_mediator_by_channel(channel_type IN VARCHAR2)
  RETURN VARCHAR2 IS
BEGIN
  IF    (channel_type IN ('EM-MVM', 'EM-NMS')) THEN RETURN 'MVM';
  ELSIF (channel_type IN ('SNMP', 'QB3M'))     THEN RETURN 'BCB';
  ELSIF (channel_type LIKE 'EM-GM')            THEN RETURN 'GM';
  ELSIF (channel_type LIKE 'UNO')              THEN RETURN 'UNO';
  ELSE  RETURN NULL;
  END IF;
END get_mediator_by_channel;
/

/*
 * Identify the Channel type from a Mediator type.
 */
CREATE OR REPLACE FUNCTION get_channel_by_mediator(mediator_type IN VARCHAR2)
  RETURN VARCHAR2 IS
BEGIN
  IF    (mediator_type LIKE 'MVM') THEN RETURN ('EM-MVM,EM-NMS');
  ELSIF (mediator_type LIKE 'GM')  THEN RETURN 'EM-GM';
  ELSE  RETURN NULL;
  END IF;
END get_channel_by_mediator;
/

/*
 * Tranform the discovery policy description to a ENUM name.
 */
CREATE OR REPLACE FUNCTION translate_discovery_policy(discovery_policy IN VARCHAR2)
  RETURN VARCHAR2 IS
BEGIN
  IF    (discovery_policy LIKE 'Discovery By Domain')  THEN RETURN 'DISCOVERY_BY_DOMAIN';
  ELSIF (discovery_policy LIKE 'Discover All Network') THEN RETURN 'DISCOVER_ALL_NETWORK';
  ELSE  RETURN 'NO_DISCOVERY';
  END IF;
END translate_discovery_policy;
/

/*
 * If the channel address was null return the '127.0.0.1' IP.
 */
CREATE OR REPLACE FUNCTION verify_channel_address(address IN VARCHAR2)
  RETURN VARCHAR2 IS
BEGIN
  IF (address IS NULL) THEN
    RETURN '127.0.0.1';
  ELSE
    RETURN address;
  END IF;
END verify_channel_address;
/

/*
 * Transform the 0 to INACTIVE and  1 to ACTIVE
 */
CREATE OR REPLACE FUNCTION translate_activation_required(activation IN NUMBER)
  RETURN VARCHAR2 IS
BEGIN
  IF (activation = 0) THEN
    RETURN 'INACTIVE';
  ELSE
    RETURN 'ACTIVE';
  END IF;
END translate_activation_required;
/

/*
 * Return the HASH from a SCS Sync Category
 */
CREATE OR REPLACE FUNCTION get_counter_hash(ne_id_arg IN NUMBER, sync_category IN NUMBER)
  RETURN VARCHAR2 IS
    counter_var NUMBER;
BEGIN
  BEGIN
    SELECT counter.counter_hash
      INTO counter_var
      FROM emne_ne_sync_counter counter
     WHERE counter.ne_id = ne_id_arg
       AND counter.scs_sync_category = sync_category;
  EXCEPTION
    WHEN no_data_found THEN
      counter_var := -1;
  END;

  return counter_var;
END get_counter_hash;
/

/*
 * Migrate the EM/NE global settings
 */
CREATE OR REPLACE PROCEDURE migrate_settings IS
BEGIN
    EXECUTE IMMEDIATE '
    INSERT INTO dcn_settings (settings_id, version, mediator_retries, channel_retries, ne_retries, retry_interval, scaling_limit, enable_scaling, use_native_naming, discovery)
         SELECT 6 settings_id,
                0 version_number,
                0 mediator_retries,
                emne_settings.retry_em      channel_retries,
                emne_settings.retry_ne      ne_retries,
                time_interval_for_scheduler retry_interval,
                global_schedule_startup     scaling_limit,
                activation_schedule_startup enable_scaling,
                (SELECT show_native_naming FROM emne_network_settings WHERE id = (SELECT MIN(s.id) FROM emne_network_settings s)) use_native_naming,
                translate_discovery_policy(emne_settings.discovery_policy) discovery
                --freeze_ne_position deprecated
           FROM emne_man_settings emne_settings';
END migrate_settings;
/

/*
 * Creates the Mediators based on EM/NE EM types.
 */
CREATE OR REPLACE PROCEDURE create_mediators_from_channels IS

    v_logical_id    NUMBER        := NULL;
    v_name          VARCHAR2(255) := NULL;
    v_host_primary  VARCHAR2(255) := NULL;
    v_host_standby  VARCHAR2(255) := NULL;
    v_type          VARCHAR2(255) := NULL;
    v_channel_type  VARCHAR2(255) := NULL;

    -- SQL
    v_cursor_sql VARCHAR2(1024) :=
        'SELECT DISTINCT (get_mediator_by_channel(channel.em_type_id) || ''_'' || verify_channel_address(channel.display_address)) mediator_name,
                         verify_channel_address(channel.display_address) host,
                         get_mediator_by_channel(channel.em_type_id) type_name
                   FROM  emne_em channel';

    -- CURSOR DEF
    TYPE CURSOR_MEDIATORS IS REF CURSOR;
    r_mediators           CURSOR_MEDIATORS;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Migrating Mediators::BEGIN');
    DBMS_OUTPUT.PUT_LINE('--');

    OPEN r_mediators FOR v_cursor_sql;

    LOOP
        FETCH r_mediators INTO v_name, v_host_primary, v_type;
            EXIT WHEN r_mediators%NOTFOUND;

            SELECT dcn_seq_mediator_id.NEXTVAL
               INTO v_logical_id
            FROM dual;
            DBMS_OUTPUT.PUT_LINE('-- BEGIN ' || v_name || '--');
            DBMS_OUTPUT.PUT_LINE('Mediator Name: ' || v_name);
            DBMS_OUTPUT.PUT_LINE('Mediator Host: ' || v_host_primary);
            DBMS_OUTPUT.PUT_LINE('Mediator Type: ' || v_type);
            DBMS_OUTPUT.PUT_LINE('Mediator Logical ID: ' || TO_CHAR(v_logical_id));

            DBMS_OUTPUT.PUT_LINE('Creating Logical Mediator');

            INSERT INTO DCN_MEDIATOR_INFO (
                        MEDIATOR_ID, MEDIATOR_NAME, TYPE_NAME, VERSION_NUMBER, ACTIVATION_REQUIRED,
                        CONCURRENT_LIMITED, CONCURRENT_LIMIT, RECONNECT_INTERVAL)
                 VALUES(v_logical_id,
                        v_name,
                        v_type,
                        0,   -- version_number,
                        0,   -- activation_required,
                        1,   -- concurrent_limited,
                        20,  -- concurrent_limit,
                        0 ); -- reconnect_interval

            DBMS_OUTPUT.PUT_LINE('Creating PRIMARY Physical Mediator');

            INSERT INTO DCN_MEDIATOR_PHYSICAL_DATA (
                        PHYSICAL_MEDIATOR_ID, LOGICAL_MEDIATOR_ID, HOST, VERSION_NUMBER, PRIORITY)
                 VALUES(DCN_SEQ_PHYSICAL_MEDIATOR_ID.NEXTVAL,
                        v_logical_id,
                        v_host_primary,
                        0,  -- version_number,
                        0); -- primary_priority

            v_channel_type := get_channel_by_mediator(v_type);
            DBMS_OUTPUT.PUT_LINE('Channel Type: ' || v_channel_type);

            IF (v_channel_type IS NOT NULL) THEN
                DBMS_OUTPUT.PUT_LINE('Loading standby host');

                SELECT max(p.VALUE) as standby_host
                  INTO v_host_standby
                  FROM EMNE_EM_PROPERTIES p, EMNE_EM em
                 WHERE em.id = p.em_id
                   AND KEY_  = 'StandbyComputerName'
                   AND em.EM_TYPE_ID IN (select regexp_substr(v_channel_type,'[^,]+', 1, level) from dual
                                    connect by regexp_substr(v_channel_type, '[^,]+', 1, level) is not null)
                   AND em.DISPLAY_ADDRESS = v_host_primary;

                DBMS_OUTPUT.PUT_LINE('Standby Host: ' || v_host_standby);

                IF ((v_host_standby IS NOT NULL) AND (v_host_standby <> v_host_primary)) THEN
                    DBMS_OUTPUT.PUT_LINE('Creating STANDBY Physical Mediator');

                    INSERT INTO DCN_MEDIATOR_PHYSICAL_DATA (
                                PHYSICAL_MEDIATOR_ID, LOGICAL_MEDIATOR_ID, HOST, VERSION_NUMBER, PRIORITY)
                         VALUES(DCN_SEQ_PHYSICAL_MEDIATOR_ID.NEXTVAL,
                                v_logical_id,
                                v_host_standby,
                                0,  -- version_number,
                                1); -- secondary_priority
                 END IF;
             END IF;

             DBMS_OUTPUT.PUT_LINE('-- END ' || v_name || '--');
        END LOOP;

        CLOSE r_mediators;

        DBMS_OUTPUT.PUT_LINE('Migrating Mediators::END');
        DBMS_OUTPUT.PUT_LINE('--');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('ERROR ON MIGRATE MEDIATORS');
            DBMS_OUTPUT.PUT_LINE( SUBSTR(SQLERRM, 1, 999) );

        IF( r_mediators%ISOPEN ) THEN
            CLOSE r_mediators;
        END IF;
END create_mediators_from_channels;
/

/*
 * Migrates EM/NE EMs to Channel Info and Preferences
 */
CREATE OR REPLACE PROCEDURE migrate_channels IS
BEGIN
    -- Migrating channels info
    EXECUTE IMMEDIATE '
    INSERT INTO dcn_channel_info (channel_id, version_number, channel_type, core_id, activation_required, mediator_id)
         SELECT channel.id         channel_id,
                0                  version_number,
                channel.em_type_id channel_type,
                channel.core_id    core_id,
                channel.activation activation_required,
                (SELECT mediator.mediator_id
                   FROM dcn_mediator_info mediator, DCN_MEDIATOR_PHYSICAL_DATA mediator_data
                  WHERE mediator_data.LOGICAL_MEDIATOR_ID = mediator.MEDIATOR_ID
                    AND mediator.type_name = get_mediator_by_channel(channel.em_type_id)
                    AND mediator_data.PRIORITY = 0
                    AND mediator_data.host = verify_channel_address(channel.display_address)) mediator_id
           FROM emne_em channel';

    -- Migrating channels preferences
    EXECUTE IMMEDIATE '
    INSERT INTO dcn_channel_preferences (channel_id, version_number, channel_name, reconnect_interval, concurrent_limited, concurrent_limit)
         SELECT channel.id    channel_id,
                0             version_number,
                channel.name  channel_name,
                channel.reconnect_interval,
                (SELECT activation_schedule_startup
                   FROM emne_man_settings
                  WHERE id = (SELECT MIN(m.id) FROM emne_man_settings m)) concurrent_limited,
                (CASE WHEN (scheduled_startup > 999) THEN 999
                      ELSE scheduled_startup END) concurrent_limit
          FROM emne_em channel';
END migrate_channels;
/

/*
 * Migrates the EM/NE NEs info, preferences, operation and counters.
 */
CREATE OR REPLACE PROCEDURE migrate_nes IS
BEGIN
    -- Migrating NEs info
    EXECUTE IMMEDIATE '
    INSERT INTO dcn_ne_info (ne_id, version, channel_id, core_id, icon_id, proxy_type, used_by, comms_lost_alarm_raised, activation_required)
         SELECT ne.id ne_id,
                0 version_number,
                ne.em_id channel_id,
                ne.core_id,
                ne.icon_id,
                ne.ne_type_id proxy_type,
                ne.used_by,
                (CASE WHEN (ne.com_lost_raised_id IS NULL) THEN 0 ELSE 1 END) comms_lost_alarm_raised,
                translate_activation_required(ne.activation) activation_required
           FROM emne_ne ne';

    -- Migrating NE Counters
    -- CATEGORY_ALL = 0   CATEGORY_ALARMS = 1   CATEGORY_PACKET = 3
    EXECUTE IMMEDIATE '
    INSERT INTO dcn_ne_counters (ne_id, version, all_categories, alarm, packet)
         SELECT info.ne_id,
                0 version_number,
                get_counter_hash(info.ne_id, 0) all_categories,
                get_counter_hash(info.ne_id, 1) alarm,
                get_counter_hash(info.ne_id, 3) packet
           FROM dcn_ne_info info';

    -- Migrating NE Preferences
    -- To be processed in Java Code: route_sorting_mode, password.
    EXECUTE IMMEDIATE '
    INSERT INTO dcn_ne_preferences (ne_id, version, id_name, uses_gne, reconnect_interval, global_id, user_name, container_id, route_sorting_mode)
         SELECT ne.id,
                0 version_number,
                ne.name id_name,
                ne.uses_gne,
                ne.max_ne_init_time reconnect_interval,
                ne.globalid global_id,
                ne.login_user_name user_name,
                ne.system_id container_id,
                ''DEFAULT'' route_sorting_mode
           FROM emne_ne ne';

    -- Migrating NE operation
    -- To be processed in Java Code: write_access, operational_mode, commissioning_mode, family,ne_sub_type,ne_type,  ne_specific_type
    EXECUTE IMMEDIATE '
    INSERT INTO dcn_ne_operation (ne_id, version,  event_forwarding, main_release, maintenance_release, multiple_subgroup_member,
                                  subgroups_equal, multiple_group_member, always_compatible, tp_group_mask, ne_sub_type_descr, real_ne_name, icon_id, is_gne)
         SELECT ne.id                             ne_id,
                0                                 version_number,
                ne.event_forwarding               event_forwarding,
                ne.ne_main_release                main_release,
                ne.ne_maintenance_release         maintenance_release,
                ne.multiple_subgroup_membership   multiple_subgroup_member,
                ne.subgroups_must_be_equal        subgroups_equal,
                ne.multiple_group_membership      multiple_group_member,
                ne.always_compatible              always_compatible,
                ne.tp_group_mask                  tp_group_mask,
                ne.ne_subtype                     ne_sub_type_descr,
                ne.real_ne_name                   real_ne_name,
                ne.icon_id                        icon_id,
                ne.gne                            is_gne
           FROM emne_ne ne';
END migrate_nes;
/

/*
 * Migrates EM/NE Domains and the association with the NEs.
 */
CREATE OR REPLACE PROCEDURE migrate_dcn_domains IS
BEGIN
    -- Migrating domains
    EXECUTE IMMEDIATE '
    INSERT INTO dcn_domain (domain_id, version, automatic_ne_activation, domain_name)
         SELECT DCN_SEQ_DOMAIN_ID.nextval domain_id,
                0 version_number,
                0 automatic_ne_activation,
                domain_name
           FROM (SELECT domain.name domain_name
                   FROM emne_as domain
               GROUP BY domain.name)';

    -- Update Domain automatic activation
    EXECUTE IMMEDIATE '
    UPDATE dcn_domain
       SET dcn_domain.automatic_ne_activation = (SELECT MAX(discovery_permitted) FROM emne_as
                                                  WHERE dcn_domain.domain_name = emne_as.name)';
END migrate_dcn_domains;
/

/*
 * Migrates EM/NE System Containers.
 */
CREATE OR REPLACE PROCEDURE migrate_systems IS
BEGIN
    -- Migrating systems
	EXECUTE IMMEDIATE '
    INSERT INTO DCN_CONTAINER
               (CONTAINER_ID, CONTAINER_TYPE, VERSION, CONTAINER_NAME, CONTAINER_DESCRIPTION)
         SELECT emne_system.id,
                ''SYSTEM'',
                0,
				emne_system.NAME,
				emne_system.DESCRIPTION
           FROM EMNE_SYSTEM_CONTAINER emne_system';
		   
END migrate_systems;
/

DROP SEQUENCE DCN_SEQ_CHANNEL_ID;
DROP SEQUENCE DCN_SEQ_NE_ID;
DROP SEQUENCE DCN_SEQ_CONTAINER_ID;

RENAME SEQ_EMNE_EM_ID TO DCN_SEQ_CHANNEL_ID;
RENAME SEQ_EMNE_NE_ID TO DCN_SEQ_NE_ID;
RENAME SEQ_EMNE_SYSTEM_CONTAINER_ID TO DCN_SEQ_CONTAINER_ID;

CALL migrate_settings();
CALL create_mediators_from_channels();
CALL migrate_channels();
CALL migrate_systems();
CALL migrate_nes();
CALL migrate_dcn_domains();

DROP PROCEDURE migrate_settings;
DROP PROCEDURE create_mediators_from_channels;
DROP PROCEDURE migrate_channels;
DROP PROCEDURE migrate_systems;
DROP PROCEDURE migrate_nes;
DROP PROCEDURE migrate_dcn_domains;

DROP FUNCTION get_mediator_by_channel;
DROP FUNCTION get_channel_by_mediator;
DROP FUNCTION translate_discovery_policy;
DROP FUNCTION verify_channel_address;
DROP FUNCTION translate_activation_required;
DROP FUNCTION get_counter_hash;

COMMIT;