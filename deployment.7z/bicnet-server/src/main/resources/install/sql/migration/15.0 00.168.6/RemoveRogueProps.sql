update emne_ne set TID = '' where PROTOCOL != 'TL1';
delete from emne_ne_properties where key_ = 'TID';
delete from emne_ne_properties where key_ LIKE 'TL1_TID%' AND ne_id in (select id from EMNE_NE where PROTOCOL != 'TL1');
update EMNE_USED_GATEWAY_NES set TL1_TID = '' where NE_ID in (select id from EMNE_NE where PROTOCOL != 'TL1');