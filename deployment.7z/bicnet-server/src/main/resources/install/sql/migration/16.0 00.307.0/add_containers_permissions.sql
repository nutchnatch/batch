BEGIN
	DECLARE
		addPermissionItemVar NUMBER;
	BEGIN
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->New (NE Container)','New NE Container');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Container Properties','Container Properties');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Move System Container','Move System Container');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Move NE Container','Move NE Container');

  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Permissions for mediators objects already exists');

	END;
END;
/
BEGIN
	DECLARE
		vboolean BOOLEAN;
	BEGIN
    vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->New (NE Container)');
    vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Object Context Menu->Container Properties');
    vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Move System Container');
    vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Move NE Container');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('WARN - Permissions for mediators objects already exists');
	END;
END;
/