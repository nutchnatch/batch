#!/usr/bin/env bash

DB_USER=@DB_USER@
DB_NAME=@DB_NAME@
DB_PORT=@DB_PORT@
DB_HOST=@DB_HOST@

JAVA=@JAVA_BIN@

MIGRATION_DIR=@MIGRATION_DIR@
SETUP_DIR=@INSTALL_BIN_DIR@/..
DEPS_DIR=@AP_SERVER_DIR@/modules/system/layers/base
JBOSS_BICNET=@JBOSS_DEPLOY_DIR@
SERVER_DIR=@JBOSS_DIR@

DB_PWD=`$SERVER_DIR/bin/mainvars/mainvars.sh obtain TNMS 2>> DCN_Manager_migration.log`

if [ -z "$DB_PWD" ]; then
	exit 1
fi

$JAVA -cp \
 .:"$MIGRATION_DIR/16.0 00.003.0/dcn-manager-5.0.151.001.jar":$DEPS_DIR/org/jboss/log4j/logmanager/main/*:$DEPS_DIR/org/jboss/logmanager/main/*:$DEPS_DIR/org/jboss/jandex/main/*:$DEPS_DIR/org/hibernate/main/*:$DEPS_DIR/org/hibernate/commons-annotations/main/*:$DEPS_DIR/org/javassist/main/*:$DEPS_DIR/javax/transaction/api/main/*:$DEPS_DIR/org/dom4j/main/*:$DEPS_DIR/org/antlr/main/*:$DEPS_DIR/javax/persistence/api/main/*:$DEPS_DIR/org/slf4j/main/*:$DEPS_DIR/org/jboss/logging/main/*:$JBOSS_BICNET/conf/dcn-manager:$JBOSS_BICNET/lib/*:$SETUP_DIR/lib/ojdbc7.jar:"$MIGRATION_DIR/16.0 00.003.0/dcn-manager-initial-migration.jar" \
 com.ossnms.dcn_manager.bicnet.migration.Application $DB_USER "$DB_PWD" $DB_HOST $DB_PORT $DB_NAME \
 >> DCN_Manager_migration.log
