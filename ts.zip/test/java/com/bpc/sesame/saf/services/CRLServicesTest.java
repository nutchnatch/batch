package com.bpc.sesame.saf.services;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.concurrent.TimeoutException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bpc.sesame.saf.exception.TechnicalException;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

@SuppressWarnings({"restriction"})
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={CRLServicesTest.TestConfig.class, PropertySourcesPlaceholderConfigurer.class})
@TestPropertySource(properties = {
		"sesame.saf.crl-download.enable=true",
		"sesame.saf.crl-download.initialDelay=100000",
		"sesame.saf.crl-download.fixedRate=4000000",
		"sesame.saf.crl-download.job.timeout=500",
		"sesame.saf.crl-download.url1=ldap://changebytthetest", 
		"sesame.saf.crl-download.destination.file=target/CRLs.pem"})
@EnableAsync
public class CRLServicesTest {
	
	static {
		System.setProperty("logback.configurationFile","logback-test.xml");
	}

	@Autowired
	public CRLServices crlServices;
	
	@Test
	public void testTimeoutWithNonRoutableIp() throws IOException   {
		
		Files.deleteIfExists(Paths.get("target/CRLs.pem"));
		crlServices.setUrls(Arrays.asList("ldap://10.255.255.1/ou=Europe,o=Group?certificateRevocationList;binary?base"));
		try {
			crlServices.scheduleCRLsDownload();
			Assert.fail("The job must timeout");
		} catch (Exception e) {
			Assert.assertEquals(e.getClass(), TechnicalException.class);
			Assert.assertEquals(e.getCause().getClass(), TimeoutException.class);
		}
		
	}
	
	@Test
	public void testHttpAndFileDownload() throws IOException   {
		
		Path p = Paths.get("target/CRLs.pem");
		Path p1 = Paths.get("target/CRLs.pem.1");
		Path p2 = Paths.get("target/CRLs.pem.2");
		Files.deleteIfExists(p);
		Files.deleteIfExists(p1);
		Files.deleteIfExists(p2);
		try {
			createHttpServerWhichReturnCRL();
			crlServices.setUrls(Arrays.asList(
					"http://localhost:" + server.getAddress().getPort() + "/crl",
					"./src/test/config-clients/keystoresForTLS/crl.pem"
				)
			);
			crlServices.scheduleCRLsDownload();
			
			//check the files
			Assert.assertTrue(Files.exists(p));
			Assert.assertTrue(Files.exists(p1));
			Assert.assertTrue(Files.exists(p2));
			Assert.assertTrue(Files.size(p1)>500);
			Assert.assertTrue(Files.size(p2)>500);
			Assert.assertTrue(Files.size(p1)+Files.size(p2)==Files.size(p));
			
			//change the url order and use invalid path
			crlServices.setUrls(Arrays.asList(
					"./invalid.pem",
					"http://localhost:" + server.getAddress().getPort() + "/crl"
				)
			);
			
			crlServices.scheduleCRLsDownload();
			//the url 1 should failed on the log but not the entire job
			
			//check the files
			Assert.assertTrue(Files.exists(p));
			Assert.assertTrue(Files.exists(p1));
			Assert.assertTrue(Files.exists(p2));
			Assert.assertTrue(Files.size(p2)==Files.size(p1));
			Assert.assertTrue(Files.size(p1)+Files.size(p2)==Files.size(p));
			
		} finally {
			server.stop(1);
		}
	}
	
	
	@Test
	public void test_concat() throws IOException {
		Path source = Paths.get("./src/test/config-clients/keystoresForTLS/crl.pem");
		Path dest = Paths.get("./target/test_concat.pem");
		Files.deleteIfExists(dest);
		crlServices.concatFile(source, dest);
		Assert.assertTrue(Files.size(source)==Files.size(dest));
		crlServices.concatFile(source, dest);
		Assert.assertTrue(Files.size(source)*2==Files.size(dest));
	}
	
	
	private HttpServer server;
	private byte[] sampleCRL = null;
	
	public void createHttpServerWhichReturnCRL() throws IOException {
		
		server = HttpServer.create(new InetSocketAddress(0), 0);
		System.out.println("server started at " + server.getAddress().getPort());
		URL resource = Thread.currentThread().getContextClassLoader().getResource("certificates/BNPP_Root.crl");
		try (InputStream is = resource.openStream();
				ByteArrayOutputStream os = new ByteArrayOutputStream()) {
		    int nRead;
		    byte[] data = new byte[1024];
		    while ((nRead = is.read(data, 0, data.length)) != -1) {
		        os.write(data, 0, nRead);
		    }
		 
		    os.flush();
		    sampleCRL = os.toByteArray();
		}
		server.createContext("/crl", new HttpHandler(){
	         @Override
	         public void handle(HttpExchange he) throws IOException {
				he.sendResponseHeaders(200, sampleCRL.length);
				OutputStream os = he.getResponseBody();
				os.write(sampleCRL);
				os.flush();
				os.close();
	         }
		});
		server.setExecutor(null);
		server.start();
	}
	

	@Configuration
	@EnableScheduling
	@EnableAsync
	public static class  TestConfig {
		
		@Bean
		public CRLServices getCRLServices() {
			return new CRLServices();
		}
	}
}
