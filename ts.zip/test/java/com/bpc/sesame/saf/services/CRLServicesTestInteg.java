package com.bpc.sesame.saf.services;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.ExecutionException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={CRLServicesTestInteg.TestConfig.class, PropertySourcesPlaceholderConfigurer.class})
@TestPropertySource(properties = {
		"sesame.saf.crl-download.enable=true",
		"sesame.saf.crl-download.initialDelay=100000",
		"sesame.saf.crl-download.fixedRate=4000000",
		"sesame.saf.crl-download.job.timeout=60000",
		"sesame.saf.crl-download.url1=ldap://directory.echonet/ou=Europe,o=Group?certificateRevocationList;binary?base", 
		"sesame.saf.crl-download.url2=ldap://directory.echonet/ou=Europe,o=Group?certificateRevocationList;binary?base", 
		"sesame.saf.crl-download.destination.file=target/CRLs.pem"})
public class CRLServicesTestInteg {
	
	static {
		System.setProperty("logback.configurationFile","logback-test.xml");
	}

	@Autowired
	public CRLServices crlServices;
	
	@Test
	public void test() throws InterruptedException, ExecutionException, IOException {
		
		Files.deleteIfExists(Paths.get("target/CRLs.pem"));
		crlServices.scheduleCRLsDownload();
		Assert.assertTrue(crlServices.isInitialized());
		
	}
	
	@Test
	public void direct() throws InterruptedException, ExecutionException, IOException {
		
		Path p1 = Paths.get("target/CRLs.pem.1");
		Files.deleteIfExists(p1);
		crlServices.downloadCRLToTempFile("ldap://directory.echonet/ou=Europe,o=Group?certificateRevocationList;binary?base", 1);
		Assert.assertTrue(Files.exists(p1));
		Assert.assertTrue(Files.size(p1)>10000);
	}
	
	@Configuration
	@EnableScheduling
	@EnableAsync
	public static class  TestConfig {
		
		@Bean
		public CRLServices getCRLServices() {
			return new CRLServices();
		}
	}
}
