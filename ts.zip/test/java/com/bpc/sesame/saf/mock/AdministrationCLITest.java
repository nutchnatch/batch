package com.bpc.sesame.saf.mock;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import gencl.sesame.services.standard.proxy.AuthenticationServicesWSP;
import gentypes.saml.metadata.v20.EntityDescriptorType;
import gentypes.saml.metadata.v20.IDPSSODescriptorType;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import com.bnppa.sesame.services.internal.model.v2.IdentityProviderCertificate;
import com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel;
import com.bnppa.sesame.services.internal.model.v2.ServiceProvider;
import com.bnppa.sesame.services.internal.v2.IdentityProviderServices;
import com.bnppa.sesame.services.internal.v2.ServiceProvidersServices;
import com.bpc.sesame.saf.util.XmlTools;

@RunWith(MockitoJUnitRunner.class)
public class AdministrationCLITest {
	
	@Mock
	ServiceProvidersServices serviceProvidersServicesMock;
	
	@Mock
	IdentityProviderServices identityProviderServicesMock;
	
	@Mock
	AuthenticationServicesWSP authenticationServicesWSPMock;
	
	@Test
	public void testInitIdpCerts() throws Exception {
		
		//check the call loginInUserRef
		doAnswer(new Answer<String>() {
		    public String answer(InvocationOnMock invocation) {
		        Object[] args = invocation.getArguments();
		        String login = (String) args[0];
		        String password = (String) args[1];
		        Assert.assertEquals(login, "SAFADMIN");
		        Assert.assertEquals(password, "Password01*");
		        return "mySesameToken";
		    }})
		 .when(authenticationServicesWSPMock).loginInUserRef(anyString(), anyString(), anyString());
		
		//check the call storeIdentityProviderCertificate
		doAnswer(new Answer<Void>() {
			private BigInteger serial = BigInteger.ZERO;
		    public Void answer(InvocationOnMock invocation) {
		    	serial = serial.add(BigInteger.ONE);
		        Object[] args = invocation.getArguments();
		        String token = (String) args[0];
		        IdentityProviderCertificate cert = (IdentityProviderCertificate) args[1];
		        Assert.assertEquals(token, "mySesameToken");
		        Assert.assertEquals(cert.getSerialNumber(), serial);
		        Assert.assertTrue(cert.getCertificate().contains("--END CERTIFICATE--"));
		        Assert.assertTrue(cert.getCertificate().contains("--BEGIN RSA PRIVATE KEY--"));
		        return null;
		    }})
		 .when(identityProviderServicesMock).storeIdentityProviderCertificate(anyString(), any(IdentityProviderCertificate.class));
		
		//check the logout
		doAnswer(new Answer<Void>() {
		    public Void answer(InvocationOnMock invocation) {
		        Object[] args = invocation.getArguments();
		        String token = (String) args[0];
		        Assert.assertEquals(token, "mySesameToken");
		        return null;
		    }})
		 .when(authenticationServicesWSPMock).logout(anyString());
		
		//Excecute the script
		AdministrationCLI cli = new AdministrationCLI(authenticationServicesWSPMock, identityProviderServicesMock, serviceProvidersServicesMock);
		cli.launch(new String[] {"--login","SAFADMIN","--password","Password01*","--action","initIdpCerts","--passphrase","sdfsdfsd", "--key-size", "512"});
		
		
		verify(authenticationServicesWSPMock, times(1)).loginInUserRef(anyString(), anyString(), anyString());
		verify(identityProviderServicesMock, times(2)).storeIdentityProviderCertificate(anyString(), any(IdentityProviderCertificate.class));
		verify(authenticationServicesWSPMock, times(1)).logout(anyString());
	}
	
	@Test
	public void testAddSP() throws Exception {
		//check the call loginInUserRef
		doAnswer(new Answer<String>() {
		    public String answer(InvocationOnMock invocation) {
		        Object[] args = invocation.getArguments();
		        String login = (String) args[0];
		        String password = (String) args[1];
		        Assert.assertEquals(login, "SAFADMIN");
		        Assert.assertEquals(password, "Password01*");
		        return "mySesameToken";
		    }})
		 .when(authenticationServicesWSPMock).loginInUserRef(anyString(), anyString(), anyString());
		
		//check the call storeIdentityProviderCertificate
		doAnswer(new Answer<Void>() {
			private BigInteger serial = BigInteger.ZERO;
		    public Void answer(InvocationOnMock invocation) {
		    	serial = serial.add(BigInteger.ONE);
		        Object[] args = invocation.getArguments();
		        String token = (String) args[0];
		        ServiceProvider sp = (ServiceProvider) args[1];
		        Assert.assertEquals(token, "mySesameToken");
		        Assert.assertEquals(sp.getAuthLevel(), SAFAuthLevel.HIGH);
		        Assert.assertEquals(sp.getEntityId(), "urn:cardif:saf:sp:test:prog2");
		        Assert.assertEquals(sp.getApplicationDomain(), "SAF");
		        Assert.assertEquals(sp.getId(), "TO_CHANGE");
		        Assert.assertEquals(sp.getLabel(), "TO_CHANGE");
		        Assert.assertEquals(sp.getLabel(), "TO_CHANGE");
		        try {
					String metadataXml = new String(Files.readAllBytes(Paths.get("src/test/config-clients/urn_cardif_saf_sp_test_prog2.xml")),"UTF-8");
					Assert.assertEquals(sp.getMetaData(), metadataXml);
		        } catch (Exception e) {
					throw new RuntimeException(e);
				}
		        return null;
		    }})
		 .when(serviceProvidersServicesMock).createServiceProvider(anyString(), any(ServiceProvider.class));
		
		//check the logout
		doAnswer(new Answer<Void>() {
		    public Void answer(InvocationOnMock invocation) {
		        Object[] args = invocation.getArguments();
		        String token = (String) args[0];
		        Assert.assertEquals(token, "mySesameToken");
		        return null;
		    }})
		 .when(authenticationServicesWSPMock).logout(anyString());
		
		//Excecute the script
		AdministrationCLI cli = new AdministrationCLI(authenticationServicesWSPMock, identityProviderServicesMock, serviceProvidersServicesMock);
		cli.launch(new String[] {"--login","SAFADMIN","--password","Password01*","--action","addSP","--sp-metadata","src/test/config-clients/urn_cardif_saf_sp_test_prog2.xml"});
		
		verify(authenticationServicesWSPMock, times(1)).loginInUserRef(anyString(), anyString(), anyString());
		verify(serviceProvidersServicesMock, times(1)).createServiceProvider(anyString(), any(ServiceProvider.class));
		verify(authenticationServicesWSPMock, times(1)).logout(anyString());
	}
	
	@Test
	public void testGetIDPMetadata() throws Exception {
		
		String idpMetadata = "target/_cli_test_idp.xml";
		Files.deleteIfExists(Paths.get(idpMetadata));
		
		//check the call loginInUserRef
		doAnswer(new Answer<String>() {
		    public String answer(InvocationOnMock invocation) {
		        Object[] args = invocation.getArguments();
		        String login = (String) args[0];
		        String password = (String) args[1];
		        Assert.assertEquals(login, "SAFADMIN");
		        Assert.assertEquals(password, "Password01*");
		        return "mySesameToken";
		    }})
		 .when(authenticationServicesWSPMock).loginInUserRef(anyString(), anyString(), anyString());

		
		//check the call getCurrentIdentityProviderCertificate
		doAnswer(new Answer<IdentityProviderCertificate>() {
		    public IdentityProviderCertificate answer(InvocationOnMock invocation) throws Exception {
		        Object[] args = invocation.getArguments();
		        String token = (String) args[0];
		        Assert.assertEquals(token, "mySesameToken");
		        String pemContentCurrent = new String(Files.readAllBytes(Paths.get("src/test/config-mock/identityProvider/idp.001.certificate.pk.pem")),"UTF-8");
		        IdentityProviderCertificate current = new IdentityProviderCertificate();
		        current.setCertificate(pemContentCurrent);
		        current.setSerialNumber(BigInteger.ONE);
		        return current;
		    }})
		 .when(identityProviderServicesMock).getCurrentIdentityProviderCertificate(anyString());
		
		//check the call getCurrentIdentityProviderCertificate
		doAnswer(new Answer<IdentityProviderCertificate>() {
		    public IdentityProviderCertificate answer(InvocationOnMock invocation) throws Exception {
		        Object[] args = invocation.getArguments();
		        String token = (String) args[0];
		        Assert.assertEquals(token, "mySesameToken");
		        String pemContentNext = new String(Files.readAllBytes(Paths.get("src/test/config-mock/identityProvider/idp.002.certificate.pk.pem")),"UTF-8");
		        IdentityProviderCertificate next = new IdentityProviderCertificate();
		        next.setCertificate(pemContentNext);
		        next.setSerialNumber(BigInteger.valueOf(2));
		        return next;
		    }})
		 .when(identityProviderServicesMock).getNextIdentityProviderCertificate(anyString());
		
		//check the logout
		doAnswer(new Answer<Void>() {
		    public Void answer(InvocationOnMock invocation) {
		        Object[] args = invocation.getArguments();
		        String token = (String) args[0];
		        Assert.assertEquals(token, "mySesameToken");
		        return null;
		    }})
		 .when(authenticationServicesWSPMock).logout(anyString());
		
		//Excecute the script
		AdministrationCLI cli = new AdministrationCLI(authenticationServicesWSPMock, identityProviderServicesMock, serviceProvidersServicesMock);
		cli.launch(new String[] {	"--login",			"SAFADMIN",
									"--password",		"Password01*",
									"--action",			"getIDPMetadata",
									"--idp-metadata",	idpMetadata,
									"--idp-url",		"http://localhost:8080/sesame_saf"});
		
		verify(authenticationServicesWSPMock, times(1)).loginInUserRef(anyString(), anyString(), anyString());
		verify(identityProviderServicesMock, times(1)).getCurrentIdentityProviderCertificate(anyString());
		verify(identityProviderServicesMock, times(1)).getNextIdentityProviderCertificate(anyString());
		verify(authenticationServicesWSPMock, times(1)).logout(anyString());
		
		//verify output file
		String xml = new String(Files.readAllBytes(Paths.get(idpMetadata)),"UTF-8");
		EntityDescriptorType metadata = XmlTools.stringToEntityDescriptorType(xml);
		Assert.assertNotNull(metadata);
		IDPSSODescriptorType desc  = (IDPSSODescriptorType) metadata.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor().get(0);
		Assert.assertEquals(2, desc.getKeyDescriptor().size());
		Assert.assertEquals(3, desc.getSingleSignOnService().size());
		Assert.assertTrue(desc.getSingleSignOnService().get(0).getLocation().startsWith("http://localhost:8080/sesame_saf/"));
		Assert.assertTrue(desc.getSingleSignOnService().get(1).getLocation().startsWith("http://localhost:8080/sesame_saf/"));
		Assert.assertTrue(desc.getSingleSignOnService().get(2).getLocation().startsWith("http://localhost:8080/sesame_saf/"));
	}
}
