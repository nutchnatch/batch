package com.bpc.sesame.saf.mock;

import gentypes.saml.assertion.v20.AssertionType;
import gentypes.saml.protocol.v20.ResponseType;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.annotation.PostConstruct;

import org.assertj.core.api.Condition;
import org.assertj.core.condition.AnyOf;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;
import org.w3c.dom.Document;

import com.bpc.sesame.saf.functional.ParentTest;
import com.bpc.sesame.saf.model.ResponseStatus;
import com.bpc.sesame.saf.util.XmlTools;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.anyOf;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=ApplicationBoot.class, webEnvironment = WebEnvironment.RANDOM_PORT)
public class ServiceProviderCLITest extends ParentTest {

	@Value("https://localhost:${local.server.port}${server.context-path}/admin")
	private String adminServletURL;

	private String IDP_METADATA_PATH = "./target/_test_idp.xml";
	private String OUTPUT_FILE = "./target/_test_output.raw";
	private String SAML_OUTPUT_FILE = "./target/_test_output.xml";
	private String INPUT_FILE = "./target/_test_input.xml";

	private String[] construct(String... params) {
		
		String[] response = new String[params.length + 8];
		response[0] = "--idp-metadata"; 
		response[1] = IDP_METADATA_PATH;
		response[2] = "--config-dir";
		response[3] = "./src/test/config-clients/";
		response[4] = "--output-file";
		response[5] = OUTPUT_FILE;
		response[6] = "--saml-output-file";
		response[7] = SAML_OUTPUT_FILE;

		System.arraycopy(params, 0, response, 8, params.length);
		return response;
	}
	
	@PostConstruct
	public void init() throws Exception {
		URL metadataUrl = new URL(adminServletURL +"?getMetadata=true");
		String metadataContent = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1").init().downloadIdpMetadata(metadataUrl);
		Files.write(Paths.get(IDP_METADATA_PATH), metadataContent.getBytes("UTF-8"));
	}
	
	@Before
	public void prepareTest() throws IOException {
		Files.deleteIfExists(Paths.get(OUTPUT_FILE));
		Files.deleteIfExists(Paths.get(SAML_OUTPUT_FILE));
		Files.deleteIfExists(Paths.get(INPUT_FILE));
	}
	
	@Test
	public void cli_test() throws IOException {
		
		new ServiceProviderCLI().launch(construct("--sp-entity-id", "urn:cardif:saf:sp:test:prog1"));
		
		Assert.assertTrue(Files.exists(Paths.get(OUTPUT_FILE)));
		Assert.assertTrue(Files.exists(Paths.get(SAML_OUTPUT_FILE)));
		
		Document dom = XmlTools.stringToDom(new String(Files.readAllBytes(Paths.get(SAML_OUTPUT_FILE)),"UTF-8"));
		Assert.assertNotNull(dom);
		ResponseType response = XmlTools.domToResponseType(dom);
		Assert.assertNotNull(response);
		Assert.assertNotNull(response.getAssertionOrEncryptedAssertion().get(0));
		Assert.assertNotNull(response.getAssertionOrEncryptedAssertion().get(0) instanceof AssertionType);
		ResponseStatus status = ResponseStatus.from(response.getStatus().getStatusCode().getValue());
		Assert.assertEquals(ResponseStatus.SUCCESS, status);
		
	}
	
	@Test
	public void cli_test_soap() throws IOException {
		
		new ServiceProviderCLI().launch(construct(
				"--sp-entity-id", "urn:cardif:saf:sp:test:prog1",
				"--binding", "SOAP"));
		
		Assert.assertTrue(Files.exists(Paths.get(SAML_OUTPUT_FILE)));
		
		Document dom = XmlTools.stringToDom(new String(Files.readAllBytes(Paths.get(SAML_OUTPUT_FILE)),"UTF-8"));
		Assert.assertNotNull(dom);
		ResponseType response = XmlTools.domToResponseType(dom);
		Assert.assertNotNull(response);
		Assert.assertNotNull(response.getAssertionOrEncryptedAssertion().get(0));
		Assert.assertNotNull(response.getAssertionOrEncryptedAssertion().get(0) instanceof AssertionType);
		ResponseStatus status = ResponseStatus.from(response.getStatus().getStatusCode().getValue());
		Assert.assertEquals(ResponseStatus.SUCCESS, status);
		
	}
	
	@Test
	public void cli_test_inputFile_requestExpired() throws IOException {
		
		String rawRequest = 
				"<samlp:AuthnRequest xmlns:samlp=\"urn:oasis:names:tc:SAML:2.0:protocol\" ForceAuthn=\"false\" ProtocolBinding=\"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST\" AssertionConsumerServiceURL=\"http://localhost:8080/sci-sp/saml/SSO\" ID=\"hifncjbgbdcneoegjmadbabaepdjkenjblbjdoad\" Version=\"2.0\" IssueInstant=\"2016-09-07T12:28:32.522Z\" Destination=\"https://localhost:65393/sesame_saf/redirect/sso/1/2\" xmlns:xenc=\"http://www.w3.org/2001/04/xmlenc#\" xmlns:saml=\"urn:oasis:names:tc:SAML:2.0:assertion\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">\r\n" + 
				"  	<saml:Issuer>urn:cardif:saf:sp:test:prog1</saml:Issuer>\r\n" + 
				"</samlp:AuthnRequest>";
		Files.write(Paths.get(INPUT_FILE), rawRequest.getBytes("UTF-8"));
		
		new ServiceProviderCLI().launch(new String[] {
				"--idp-metadata", IDP_METADATA_PATH,
				"--config-dir", "./src/test/config-clients/",
				"--input-file",INPUT_FILE,
				"--output-file",OUTPUT_FILE});
		
		Assert.assertTrue(Files.exists(Paths.get(OUTPUT_FILE)));
		
		String html = new String(Files.readAllBytes(Paths.get(OUTPUT_FILE)),"UTF-8");
		Assert.assertNotNull(html);
		assertThat(html).contains("RequesterException: The request have expired.");
	}
	
	@Test
	public void cli_test_inputFile_without_issuer() throws IOException {
		
		String rawRequest = 
				"<samlp:AuthnRequest xmlns:samlp=\"urn:oasis:names:tc:SAML:2.0:protocol\" "
				+ "ForceAuthn=\"false\" "
				+ "ProtocolBinding=\"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST\" "
				+ "AssertionConsumerServiceURL=\"http://localhost:8080/sci-sp/saml/SSO\" "
				+ "ID=\"hifncjbgbdcneoegjmadbabaepdjkenjblbjdoad\" "
				+ "Version=\"2.0\" "
				+ "IssueInstant=\""+XmlTools.createXmlGregorianCalendar(0).toXMLFormat()+"\" "
				+ "Destination=\"https://localhost:65393/sesame_saf/redirect/sso/1/2\" "
				+ "xmlns:xenc=\"http://www.w3.org/2001/04/xmlenc#\" xmlns:saml=\"urn:oasis:names:tc:SAML:2.0:assertion\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">\r\n" + 
				"</samlp:AuthnRequest>";
		Files.write(Paths.get(INPUT_FILE), rawRequest.getBytes("UTF-8"));
		
		new ServiceProviderCLI().launch(construct(
				"--signature-state", "MISSING",
				"--binding", "POST",
				"--input-file",INPUT_FILE));
		
		Assert.assertTrue(Files.exists(Paths.get(OUTPUT_FILE)));
		
		String html = new String(Files.readAllBytes(Paths.get(OUTPUT_FILE)),"UTF-8");
		Assert.assertNotNull(html);
		assertThat(html).contains("RequesterException: The request must have an issuer.");
	}
	

	@Test
	public void cli_test_SOAP_inputFile() throws IOException {
		
		String rawRequest = 
				"<ns3:AuthnRequest xmlns:ns3=\"urn:oasis:names:tc:SAML:2.0:protocol\" \r\n\r\n "
				+ "ForceAuthn=\"false\" "
				+ "ProtocolBinding=\"urn:oasis:names:tc:SAML:2.0:bindings:SOAP\" "
				+ "AssertionConsumerServiceURL=\"http://localhost:8080/sci-sp/saml/SSO\" \r\n "
				+ "ID=\"hifncjbgbdcneoegjmadbabaepdjkenjblbjdoad\" "
				+ "Version=\"2.0\" "
				+ "IssueInstant=\""+XmlTools.createXmlGregorianCalendar(0).toXMLFormat()+"\" "
				+ "Destination=\"https://localhost:65393/sesame_saf/redirect/sso/1/2\" "
				+ "xmlns:xenc=\"http://www.w3.org/2001/04/xmlenc#\" xmlns:saml=\"urn:oasis:names:tc:SAML:2.0:assertion\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">\r\n" 
				+ "  	<saml:Issuer>urn:cardif:saf:sp:test:prog1</saml:Issuer>\r\n"
				+ "</ns3:AuthnRequest>";
		Files.write(Paths.get(INPUT_FILE), rawRequest.getBytes("UTF-8"));
		
		new ServiceProviderCLI().launch(construct(
				"--signature-state", "NORMAL",
				"--binding", "SOAP",
				"--input-file",INPUT_FILE));
		
		Assert.assertTrue(Files.exists(Paths.get(SAML_OUTPUT_FILE)));
		
		Document dom = XmlTools.stringToDom(new String(Files.readAllBytes(Paths.get(SAML_OUTPUT_FILE)),"UTF-8"));
		Assert.assertNotNull(dom);
		ResponseType response = XmlTools.domToResponseType(dom);
		Assert.assertNotNull(response);
		Assert.assertNotNull(response.getAssertionOrEncryptedAssertion().get(0));
		Assert.assertNotNull(response.getAssertionOrEncryptedAssertion().get(0) instanceof AssertionType);
		ResponseStatus status = ResponseStatus.from(response.getStatus().getStatusCode().getValue());
		Assert.assertEquals(ResponseStatus.SUCCESS, status);
	}
	
	@Test
	public void cli_test_signatureMissing() throws IOException {
		
		new ServiceProviderCLI().launch(construct(
				"--sp-entity-id", "urn:cardif:saf:sp:test:prog1",
				"--signature-state","MISSING"));
		
		Assert.assertTrue(Files.exists(Paths.get(OUTPUT_FILE)));
		
		String html = new String(Files.readAllBytes(Paths.get(OUTPUT_FILE)),"UTF-8");
		Assert.assertNotNull(html);
		assertThat(html).contains("RequesterException: No signature found in this message.");
	}
	
	@Test
	public void cli_test_signatureCorrupt() throws IOException {
		
		new ServiceProviderCLI().launch(construct(
				"--sp-entity-id", "urn:cardif:saf:sp:test:prog1",
				"--signature-state","CORRUPT"));
		
		Assert.assertTrue(Files.exists(Paths.get(OUTPUT_FILE)));
		
		String html = new String(Files.readAllBytes(Paths.get(OUTPUT_FILE)),"UTF-8");
		Assert.assertNotNull(html);
		assertThat(html).contains("RequesterException: Could not verify the signature of the request.");
	}
	
	@Test
	public void cli_test_WITHOUT_Certificate() throws IOException {
		
		new ServiceProviderCLI().launch(construct(
				"--sp-entity-id", "urn:cardif:saf:sp:test:prog1",
				"--client-certificate","WITHOUT"));
		
		Assert.assertTrue(Files.exists(Paths.get(OUTPUT_FILE)));
		
		String html = new String(Files.readAllBytes(Paths.get(OUTPUT_FILE)),"UTF-8");
		Assert.assertNotNull(html);
		assertThat(html).contains("RequesterException: Failed to log user : no certificate found.");
	}
	
	@Test
	public void cli_test_UNKNOWN_Certificate() throws IOException {
		
		new ServiceProviderCLI().launch(construct(
				"--sp-entity-id", "urn:cardif:saf:sp:test:prog1",
				"--client-certificate","UNKNOWN",
				"--binding", "SOAP"));
		
		Assert.assertTrue(Files.exists(Paths.get(OUTPUT_FILE)));
		
		final String html = new String(Files.readAllBytes(Paths.get(OUTPUT_FILE)),"UTF-8");
		Assert.assertNotNull(html);
		
		String pattern = "SSLHandshakeException: Received fatal alert: certificate_unknown"
				+ "|"
				+ "SocketException: Broken pipe";
		assertThat(html).containsPattern(pattern);

	}
	
}
