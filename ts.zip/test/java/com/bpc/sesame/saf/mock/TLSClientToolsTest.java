package com.bpc.sesame.saf.mock;

import static com.bpc.sesame.saf.mock.TLSClient.SMARTCARD;

import java.sql.Date;

import org.junit.Test;

import com.bpc.sesame.saf.model.CertificatePK;

public class TLSClientToolsTest {
	
	private static final String SIGNATURE_ALGORITHM = "SHA256withRSA";
	private static final Date NOT_AFTER = Date.valueOf("2037-01-01");
	private static final Date NOT_BEFORE = Date.valueOf("2016-01-01");
	private static final int KEY_SIZE = 2048;
	
	@Test
	public void testCreationOfCertificate() {
		CertificatePK ca = TLSClientTools.certificateForTestingCA("Test CA", 1, NOT_BEFORE, NOT_AFTER, SIGNATURE_ALGORITHM, KEY_SIZE);
		CertificatePK user = TLSClientTools.certificateForTestingClient(ca, SMARTCARD, "sdfdsffds", 2, NOT_BEFORE, NOT_AFTER, SIGNATURE_ALGORITHM, KEY_SIZE, true, true, true);
		System.out.println(ca.getCertificate().toString());
		System.out.println("####################################################");
		System.out.println(user.getCertificate().toString());
	}
}
