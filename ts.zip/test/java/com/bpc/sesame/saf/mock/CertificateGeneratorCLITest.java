package com.bpc.sesame.saf.mock;

import static com.bpc.sesame.saf.mock.CertificateGeneratorCLI.CACLIENT_KEYSTORE_NAME;
import static com.bpc.sesame.saf.mock.CertificateGeneratorCLI.CASERVER_KEYSTORE_NAME;
import static com.bpc.sesame.saf.mock.CertificateGeneratorCLI.CLIENT_KEYSTORE_NAME_SUF;
import static com.bpc.sesame.saf.mock.CertificateGeneratorCLI.CLIENT_TRUSTSTORE_NAME;
import static com.bpc.sesame.saf.mock.CertificateGeneratorCLI.CRL_NAME;
import static com.bpc.sesame.saf.mock.CertificateGeneratorCLI.GOOD_CLIENTCA_CERT_PEM;
import static com.bpc.sesame.saf.mock.CertificateGeneratorCLI.GOOD_SERVERCA_CERT_PEM;
import static com.bpc.sesame.saf.mock.CertificateGeneratorCLI.GOOD_SERVER_CERT_PEM;
import static com.bpc.sesame.saf.mock.CertificateGeneratorCLI.GOOD_SERVER_PK_PEM;
import static com.bpc.sesame.saf.mock.CertificateGeneratorCLI.SERVER_KEYSTORE_NAME;
import static com.bpc.sesame.saf.mock.CertificateGeneratorCLI.TEST_DIR;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import org.junit.Assert;
import org.junit.Test;

public class CertificateGeneratorCLITest {
	
	@Test
	public void generateAll() throws Exception {
		
		
		deleteRecursively(TEST_DIR);
		Files.createDirectories(TEST_DIR);
		
		CertificateGeneratorCLI cli = new CertificateGeneratorCLI();
		
		cli.launch(new String[] {"--action", "caServer"});
		Assert.assertTrue(Files.exists(TEST_DIR.resolve(CASERVER_KEYSTORE_NAME)));
		Assert.assertTrue(Files.exists(TEST_DIR.resolve(CLIENT_TRUSTSTORE_NAME)));
		Assert.assertTrue(Files.exists(TEST_DIR.resolve(GOOD_SERVERCA_CERT_PEM)));
		
		cli.launch(new String[] {"--action", "server"});
		Assert.assertTrue(Files.exists(TEST_DIR.resolve(SERVER_KEYSTORE_NAME)));
		Assert.assertTrue(Files.exists(TEST_DIR.resolve(GOOD_SERVER_CERT_PEM)));
		Assert.assertTrue(Files.exists(TEST_DIR.resolve(GOOD_SERVER_PK_PEM)));
		
		cli.launch(new String[] {"--action", "caClient"});
		Assert.assertTrue(Files.exists(TEST_DIR.resolve(CACLIENT_KEYSTORE_NAME)));
		Assert.assertTrue(Files.exists(TEST_DIR.resolve(GOOD_CLIENTCA_CERT_PEM)));
		
		cli.launch(new String[] {"--action", "client", "--client-uid", "483838"});
		String keystoreName = CertificateGeneratorCLI.CLIENT_KEYSTORE_NAME_PRE + "483838" + CLIENT_KEYSTORE_NAME_SUF;
		Assert.assertTrue(Files.exists(TEST_DIR.resolve(keystoreName)));
		
		cli.launch(new String[] {"--action", "crl"});
		Assert.assertTrue(Files.exists(TEST_DIR.resolve(CRL_NAME)));
		long filesize = Files.size(TEST_DIR.resolve(CRL_NAME));
		
		cli.launch(new String[] {"--action", "crlUpdate", "--client-uid", "483838"});
		Assert.assertTrue(filesize < Files.size(TEST_DIR.resolve(CRL_NAME)));
		filesize = Files.size(TEST_DIR.resolve(CRL_NAME));
		 
		cli.launch(new String[] {"--action", "client", "--client-uid", "newUser"});
		keystoreName = CertificateGeneratorCLI.CLIENT_KEYSTORE_NAME_PRE + "newUser" + CLIENT_KEYSTORE_NAME_SUF;
		Assert.assertTrue(Files.exists(TEST_DIR.resolve(keystoreName)));
		
		cli.launch(new String[] {"--action", "crlUpdate", "--client-uid", "newUser"});
		Assert.assertTrue(filesize < Files.size(TEST_DIR.resolve(CRL_NAME)));
		
	}
	
	private void deleteRecursively(Path directory) throws IOException {
		if (Files.notExists(directory)) {
			return;
		}
		Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
			@Override
			public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
				Files.delete(file);
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
				Files.delete(dir);
				return FileVisitResult.CONTINUE;
			}
		});
	}
}
