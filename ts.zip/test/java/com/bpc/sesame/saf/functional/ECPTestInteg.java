package com.bpc.sesame.saf.functional;

import com.bpc.sesame.saf.exception.RequesterException;
import com.bpc.sesame.saf.mock.TLSClient;
import com.bpc.sesame.saf.mock.TLSClientTools;
import com.bpc.sesame.saf.util.XmlTools;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.nio.file.Paths;
import java.util.List;

/**
 * This test act as a ECP module and it needs :
 * - BPC_SAFDEMO_SPRING to act as SP with this url http://localhost:8080/saf-demo-spring/
 * - BPC_SAF (mock) to act as IDP with this url https://localhost:8443/sesame_saf/
 */
public class ECPTestInteg {

    @Test
    public void test() {

        // 1st Request from ECP to SP
        RestTemplate rt = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/vnd.paos+xml");
        headers.add("PAOS", "ver='urn:liberty:paos:2003-08'; 'urn:oasis:names:tc:SAML:2.0:profiles:SSO:ecp'");
        HttpEntity entity = new HttpEntity(headers);
        ResponseEntity<String> response = rt.exchange("http://localhost:8080/saf-demo-spring/initializeECP", HttpMethod.GET, entity, String.class);
        List<String> cookies = response.getHeaders().get("Set-Cookie");

        //Adapt the AuthnRequest receive from the SP
        // - Remove the PAOS headers
        Document document = XmlTools.stringToDom(response.getBody());
        NodeList nl = document.getElementsByTagNameNS("http://schemas.xmlsoap.org/soap/envelope/", "Header");
        if (nl.getLength() > 1) {
            throw new RequesterException("Multiple headers founds in this message.");
        }
        if (nl.getLength()==1) {
            Node header = nl.item(0);
            header.getParentNode().removeChild(header);
        }

        nl = document.getElementsByTagNameNS("urn:oasis:names:tc:SAML:2.0:protocol", "AuthnRequest");
        if (nl.getLength() != 1) {
            throw new RequesterException("Need only one AuthnRequest Element, here : " + nl.getLength());
        }
        Element authnRequest = ((Element)nl.item(0));
        String id = authnRequest.getAttribute("ID");
        String authnRequestInSOAP = XmlTools.domToString(document);


        // 2nd request from the ECP to IPD (with TLS auth)
        TLSClientTools tlsClientTools = new TLSClientTools(Paths.get("./src/test/config-clients/"),null);
        RestTemplate restTemplateTLSAware = tlsClientTools.getRestClient(TLSClient.SMARTCARD);
        headers = new HttpHeaders();
        headers.set("Content-Type", "text/xml");
        entity = new HttpEntity(authnRequestInSOAP,headers);
        response = restTemplateTLSAware.exchange("https://localhost:8443/sesame_saf/soap/sso/1/2", HttpMethod.POST, entity, String.class);

        //Adapt the Receive "Request" from the IDP
        // - add the PAOS header
        document = XmlTools.stringToDom(response.getBody());
        nl = document.getElementsByTagNameNS("http://schemas.xmlsoap.org/soap/envelope/", "Envelope");
        if (nl.getLength() != 1) {
            throw new RequesterException("No envelope found");
        }
        Element envelope = (Element) nl.item(0);
        Element header = null;
        nl = document.getElementsByTagNameNS("http://schemas.xmlsoap.org/soap/envelope/", "Header");
        if (nl.getLength()==0) {
            header = document.createElementNS("http://schemas.xmlsoap.org/soap/envelope/","Header");
            envelope.insertBefore(header, envelope.getFirstChild());
        } else {
            header = (Element) nl.item(0);
        }
        Element responseECP = document.createElementNS("urn:oasis:names:tc:SAML:2.0:profiles:SSO:ecp","Response");
        responseECP.setAttribute("refToMessageID",id);
        responseECP.setAttributeNS("http://schemas.xmlsoap.org/soap/envelope/","soap:mustUnderstand", "1");
        responseECP.setAttributeNS("http://schemas.xmlsoap.org/soap/envelope/","soap:actor", "http://schemas.xmlsoap.org/soap/actor/next/");
        header.appendChild(responseECP);
        String responseInSOAP = XmlTools.domToString(document);


        // 3rd request from the ECP to SP for final login
        headers = new HttpHeaders();
        headers.set("Content-Type", "application/vnd.paos+xml");
        headers.set("Cookie", cookies.get(0)); //we need to inject the cookie inside this request because BPC_SAFDEMO_SPRING use session to store request
        entity = new HttpEntity(responseInSOAP,headers);
        response = restTemplateTLSAware.exchange("http://localhost:8080/saf-demo-spring/saml/SSO", HttpMethod.POST, entity, String.class);
        Assert.assertEquals(302, response.getStatusCodeValue());

        headers = new HttpHeaders();
        headers.set("Cookie", cookies.get(0));
        entity = new HttpEntity(headers);
        response = restTemplateTLSAware.exchange("http://localhost:8080/saf-demo-spring", HttpMethod.GET, entity, String.class);
        Assert.assertTrue(response.getBody().contains("Overview of the authenticated user's data."));
    }
}
