package com.bpc.sesame.saf.functional;

import gentypes.saml.assertion.v20.AssertionType;
import gentypes.saml.assertion.v20.AttributeStatementType;
import gentypes.saml.assertion.v20.AttributeType;
import gentypes.saml.assertion.v20.StatementAbstractType;
import gentypes.sesame.services.common.model.Joining;
import gentypes.sesame.services.common.model.KeyValue;
import gentypes.sesame.services.common.model.UserIdentity;
import gentypes.sesame.services.common.model.UsingRight;

import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;

import javax.annotation.PostConstruct;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.bpc.sesame.saf.mock.ApplicationBoot;
import com.bpc.sesame.saf.mock.ResponseHolder;
import com.bpc.sesame.saf.mock.ServiceProviderImpl;
import com.bpc.sesame.saf.mock.ServiceProviderImpl.Binding;
import com.bpc.sesame.saf.mock.ServiceProviderImpl.SignatureAlgo;
import com.bpc.sesame.saf.mock.ServiceProviderImpl.SignatureState;
import com.bpc.sesame.saf.mock.TLSClient;
import com.bpc.sesame.saf.model.Attribute;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=ApplicationBoot.class, webEnvironment = WebEnvironment.RANDOM_PORT)
public class SSORedirectTest extends ParentTest {

    @Value("https://localhost:${local.server.port}${server.context-path}/admin?getMetadata=true")
    private URL metadataUrl;
    
    private String metadataContent;
    
    protected Binding getDefaultBinding() {
    	return Binding.REDIRECT;
    }
    
    @PostConstruct
    public void init() throws MalformedURLException {
    	if (System.getProperty("idp.url")!=null) {
    		metadataUrl = new URL(System.getProperty("idp.url"));
    	}
    	metadataContent = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1").init().downloadIdpMetadata(metadataUrl);
    }
    
	@Test
	public void test_PROG1() throws IOException {

		// GIVEN : Service Provider
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
		.idpMetadata(metadataContent)
		.binding(getDefaultBinding())
		.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlOk(serviceProvider, responseHolder);
	}
	
	@Test
	public void test_PROG1_483838() throws IOException {

		// GIVEN : Service Provider
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
		.idpMetadata(metadataContent)
		.binding(getDefaultBinding())
		.clientUid("483838")
		.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlOk(serviceProvider, responseHolder);
	}
    
	@Test
	public void test_PROG1_AllAttributes() throws IOException {

		// GIVEN : Service Provider
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
		.idpMetadata(metadataContent)
		.binding(getDefaultBinding())
		.attributesIndex(1)
		.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlOk(serviceProvider, responseHolder);
		AssertionType s = (AssertionType) responseHolder.getResponse().getAssertionOrEncryptedAssertion().get(0);
		for (StatementAbstractType statement : s.getStatementOrAuthnStatementOrAuthzDecisionStatement()) {
			if (statement instanceof AttributeStatementType) {
				AttributeStatementType attributes = (AttributeStatementType) statement;
				Assert.assertEquals(8, attributes.getAttributeOrEncryptedAttribute().size());
				for (Serializable object : attributes.getAttributeOrEncryptedAttribute()) {
					AttributeType attribut = (AttributeType)object;
					
					//Check the types of all attributes
					if (attribut.getName().equals(Attribute.EXTENDED_ATTRIBUTES.getName())) {
						Assert.assertEquals(KeyValue.class, attribut.getAttributeValue().get(0).getClass());
					} else if (attribut.getName().equals(Attribute.DISPLAY_NAME.getName())) {
						Assert.assertEquals(String.class, attribut.getAttributeValue().get(0).getClass());
					} else if (attribut.getName().equals(Attribute.TOKEN.getName())) {
						Assert.assertEquals(String.class, attribut.getAttributeValue().get(0).getClass());
					} else if (attribut.getName().equals(Attribute.JOININGS.getName())) {
						Assert.assertEquals(Joining.class, attribut.getAttributeValue().get(0).getClass());
					} else if (attribut.getName().equals(Attribute.PERMISSIONS_ID.getName())) {
						Assert.assertEquals(String.class, attribut.getAttributeValue().get(0).getClass());
					} else if (attribut.getName().equals(Attribute.ROLES_ID.getName())) {
						Assert.assertEquals(String.class, attribut.getAttributeValue().get(0).getClass());
					} else if (attribut.getName().equals(Attribute.USING_RIGHT.getName())) {
						Assert.assertEquals(UsingRight.class, attribut.getAttributeValue().get(0).getClass());
					} else if (attribut.getName().equals(Attribute.USER_IDENTITY.getName())) {
						Assert.assertEquals(UserIdentity.class, attribut.getAttributeValue().get(0).getClass());
					}
				}
			}
		}

	}
	
	@Test
	public void test_PROG1_RequestExpired_AllAttributes() throws IOException {

		// GIVEN : Service Provider
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
		.idpMetadata(metadataContent)
		.binding(getDefaultBinding())
		.timeshifting(-3000)
		.attributesIndex(1)
		.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();
		
        //THEN : Execute Test on response
        assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "RequesterException: The request have expired.");
	}
	
    @Test
    public void test_PROG1_Softpki() throws IOException {
    	
    	//GIVEN : Service Provider
    	ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
    	.idpMetadata(metadataContent)
    	.binding(getDefaultBinding())
    	.clientCertificate(TLSClient.SOFTPKI)
    	.init();
    	
    	//WHEN : Execute the request
    	ResponseHolder responseHolder = serviceProvider.execute();
        
        //THEN : Execute Test on response
    	assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "RequesterException: Failed to log user : certificate too weak.");
    }
    
    @Test
    public void test_PROG2_Softpki() throws IOException {
    	
    	//GIVEN : Service Provider
    	ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog2")
    	.idpMetadata(metadataContent)
    	.binding(getDefaultBinding())
    	.clientCertificate(TLSClient.SOFTPKI)
    	.init();
    	
    	//WHEN : Execute the request
    	ResponseHolder responseHolder = serviceProvider.execute();
        
        //THEN : Execute Test on response
    	assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "RequesterException: Failed to log user : certificate too weak.");
    }
    
    @Test
    public void test_PROG1_RequestExpired() throws IOException {
    	
    	//GIVEN : Service Provider
    	ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
    	.idpMetadata(metadataContent)
    	.binding(getDefaultBinding())
    	.timeshifting(-3000)
    	.init();
		
    	//WHEN : Execute the request
    	ResponseHolder responseHolder = serviceProvider.execute();
        
        //THEN : Execute Test on response
    	assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "RequesterException: The request have expired.");
    }
    
    @Test
    public void test_PROG1_RequestTooRecent() throws IOException {
    	
    	//GIVEN : Service Provider
    	ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
    	.idpMetadata(metadataContent)
    	.binding(getDefaultBinding())
    	.timeshifting(+3000)
    	.init();
		
    	//WHEN : Execute the request
    	ResponseHolder responseHolder = serviceProvider.execute();
        
        //THEN : Execute Test on response
    	assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "RequesterException: The request is too recent.");
    }
    
	@Test
	public void test_PROG1_SHA512() throws IOException {

		// GIVEN : Service Provider
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
		.idpMetadata(metadataContent)
		.binding(getDefaultBinding())
		.signatureAlgo(SignatureAlgo.SHA_512)
		.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlOk(serviceProvider, responseHolder);
	}
	
	@Test
	public void test_PROG1_SHA1() throws IOException {

		// GIVEN : Service Provider
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
		.idpMetadata(metadataContent)
		.binding(getDefaultBinding())
		.signatureAlgo(SignatureAlgo.SHA1)
		.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "RequesterException: Unknown Algorithm for request signature");
	}
	
	@Test
	public void test_PROG1_relayState() throws IOException {

		// GIVEN : Service Provider
		String relayState = "https://&#mdfd:/<script></script>";
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
		.idpMetadata(metadataContent)
		.binding(getDefaultBinding())
		.relayState(relayState)
		.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlOk(serviceProvider, responseHolder);
		Assert.assertEquals(responseHolder.getRelayState(), relayState);
	}
	

	
	@Test
	public void test_PROG1_rawRequest() throws IOException {
		String rawRequest = "<samlp:AuthnRequest "
				+ "					xmlns:samlp=\"urn:oasis:names:tc:SAML:2.0:protocol\" "
				+ "					ForceAuthn=\"false\" "
				+ "					ProtocolBinding=\"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST\" "
				+ "					AssertionConsumerServiceURL=\"http://localhost:8080/sci-sp/saml/SSO\" "
				+ "					ID=\"chiohmifaaeimjflkcogadpoignjpbpmnekalbff\" "
				+ "					Version=\"2.0\" "
				+ "					IssueInstant=\"2016-09-05T16:43:27.869Z\" "
				+ "					Destination=\"https://localhost:50094/sesame_saf/redirect/sso/1/2\" "
				+ "					xmlns:saml=\"urn:oasis:names:tc:SAML:2.0:assertion\" "
				+ "					xmlns:xenc=\"http://www.w3.org/2001/04/xmlenc#\" "
				+ "					xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">\r\n" 
				+ "  			<saml:Issuer>urn:cardif:saf:sp:test:prog1</saml:Issuer>\r\n" + 
				"			</samlp:AuthnRequest>";
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
		.idpMetadata(metadataContent)
		.binding(getDefaultBinding())
		.rawRequest(rawRequest)
		.init();
		
		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "RequesterException: The request have expired.");
	}
     
	@Test
	public void test_PROG1_corruptSignature() throws IOException {

		// GIVEN : Service Provider
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
		.idpMetadata(metadataContent)
		.binding(getDefaultBinding())
		.signatureState(SignatureState.CORRUPT)
		.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "RequesterException: Could not verify the signature of the request.");
	}
	
	@Test
	public void test_PROG1_missingSignature() throws IOException {

		// GIVEN : Service Provider
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
		.idpMetadata(metadataContent)
		.binding(getDefaultBinding())
		.signatureState(SignatureState.MISSING)
		.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "No signature found in this message.");
	}
	
	@Test
	public void test_PROG1_withoutDnsName() throws IOException {

		// GIVEN : Service Provider
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog1")
		.idpMetadata(metadataContent)
		.binding(getDefaultBinding())
		.clientCertificate(TLSClient.WITHOUT_DNSNAME)
		.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "RequesterException: Failed to log user : no certificate found.");
	}

	@Test
	public void test_PROG3() throws IOException {

		// GIVEN : Service Provider
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog3")
				.idpMetadata(metadataContent)
				.binding(getDefaultBinding())
				.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "RequesterException: The issuer of this request is unknown : 'urn:cardif:saf:sp:test:prog3'");
	}

	@Test
	public void test_PROG3_AllAttributes() throws IOException {

		// GIVEN : Service Provider
		ServiceProviderImpl serviceProvider = new ServiceProviderImpl("urn:cardif:saf:sp:test:prog3")
				.idpMetadata(metadataContent)
				.binding(getDefaultBinding())
				.attributesIndex(1)
				.init();

		// WHEN : Execute the request
		ResponseHolder responseHolder = serviceProvider.execute();

		// THEN : Test on response
		assertSamlError(serviceProvider, responseHolder, "Authentication Failed.", "RequesterException: The issuer of this request is unknown : 'urn:cardif:saf:sp:test:prog3'");
	}
}