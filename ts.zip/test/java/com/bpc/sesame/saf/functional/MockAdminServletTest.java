package com.bpc.sesame.saf.functional;

import gentypes.saml.metadata.v20.EntityDescriptorType;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.annotation.PostConstruct;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.bpc.sesame.saf.mock.ApplicationBoot;
import com.bpc.sesame.saf.mock.TLSClient;
import com.bpc.sesame.saf.mock.TLSClientTools;
import com.bpc.sesame.saf.util.XmlTools;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=ApplicationBoot.class, webEnvironment = WebEnvironment.RANDOM_PORT)
public class MockAdminServletTest extends ParentTest {
	
	@Value("https://localhost:${local.server.port}${server.context-path}/admin")
	private String adminServletURL;
	
	@PostConstruct
	public void init() throws Exception {
		
	}
	
	@Test
	public void admin_servlet_display_ok_test() throws IOException {
		
		RestTemplate restTemplate = new TLSClientTools(Paths.get("./src/test/config-clients/"),null).getRestClient(TLSClient.SMARTCARD);
    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(adminServletURL);
    	String html = restTemplate.getForObject(builder.build().encode().toUri(), String.class);
    	Assert.assertTrue(html.contains("<h3>Sesame SAF Mock : Administration</h3>"));
	}
	
	@Test
	public void admin_servlet_add_certificate_button_ok_test() throws IOException {

		Path newCertificate = Paths.get("./src/test/config-mock/identityProvider/idp.003.certificate.pk.pem");
		Files.deleteIfExists(newCertificate);
		try {
			RestTemplate restTemplate = new TLSClientTools(Paths.get("./src/test/config-clients/"), null)
					.getRestClient(TLSClient.SMARTCARD);
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(adminServletURL).queryParam("addCertificate", "true");
			String html = restTemplate.getForObject(builder.build().encode().toUri(), String.class);
			Assert.assertTrue(html.contains("<h3>Sesame SAF Mock : Administration</h3>"));
			Assert.assertTrue(Files.exists(newCertificate));
		} finally {
			Files.deleteIfExists(newCertificate);
		}

	}
	
	@Test
	public void admin_servlet_display_metadata_ok_test() throws IOException {

		RestTemplate restTemplate = new TLSClientTools(Paths.get("./src/test/config-clients/"),null).getRestClient(TLSClient.SMARTCARD);
    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(adminServletURL).queryParam("getMetadata", "true");
    	String xml = restTemplate.getForObject(builder.build().encode().toUri(), String.class);
		Assert.assertNotNull(xml);
		EntityDescriptorType metadata = XmlTools.stringToEntityDescriptorType(xml);
		Assert.assertNotNull(metadata);
		Assert.assertNotNull(metadata.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor().get(0));
	}
}
