package com.bpc.sesame.saf.functional;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.bpc.sesame.saf.mock.ApplicationBoot;
import com.bpc.sesame.saf.mock.ServiceProviderImpl.Binding;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=ApplicationBoot.class, webEnvironment = WebEnvironment.RANDOM_PORT)
public class SSOSoapTest extends SSORedirectTest{

    protected Binding getDefaultBinding() {
    	return Binding.SOAP;
    }
 
	@Test
	public void test_PROG1_relayState() throws IOException {

		//SOAP binding cannot test relayState
	}
}