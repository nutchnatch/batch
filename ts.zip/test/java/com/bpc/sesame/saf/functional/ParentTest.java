package com.bpc.sesame.saf.functional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import gentypes.saml.assertion.v20.AssertionType;
import gentypes.saml.assertion.v20.AttributeStatementType;
import gentypes.saml.assertion.v20.StatementAbstractType;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.junit.Assert;
import org.junit.Rule;
import org.springframework.boot.test.rule.OutputCapture;

import com.bpc.sesame.saf.mock.ResponseHolder;
import com.bpc.sesame.saf.mock.ServiceProviderImpl;
import com.bpc.sesame.saf.mock.ServiceProviderImpl.Binding;
import com.bpc.sesame.saf.model.ResponseStatus;

public class ParentTest {
	private static String configDirectory = "./src/test/config-mock/";
	
	private Set<ResponseStatus> FAILED_STATUS = new HashSet<>(
			Arrays.asList(ResponseStatus.REQUESTER, ResponseStatus.RESPONDER));

	static {
		System.setProperty("spring.config.location",configDirectory);
		System.setProperty("logging.config", "file:"+configDirectory+"logback.xml");
	}
	
	@Rule
	public OutputCapture capture = new OutputCapture();
	
	/**
	 * Valid that this response is an error response well-formed
	 * @param serviceProvider
	 * @param responseHolder
	 * @param errorMessage
	 * @param exceptionMessage
	 */
	public void assertSamlError(ServiceProviderImpl serviceProvider, ResponseHolder responseHolder, String errorMessage, String exceptionMessage) {
        
		//check the http response code
		if (serviceProvider.binding == Binding.SOAP) {
        	assertEquals(responseHolder.getResponseHttpCode(), 200);
        } else {
        	assertEquals(responseHolder.getResponseHttpCode(), 500);
        }
		
        assertNotNull(responseHolder.getResponse());
        ResponseStatus status = ResponseStatus.from(responseHolder.getResponse().getStatus().getStatusCode().getValue());
        assertTrue(FAILED_STATUS.contains(status));
        if (serviceProvider.binding != Binding.SOAP) {
	        assertTrue(responseHolder.getHtml().contains(errorMessage));
	        assertTrue(responseHolder.getHtml().contains(exceptionMessage));
        }
        assertTrue(capture.toString().contains(exceptionMessage));
	}
	
	/**
	 * Valid that this response is a success response well-formed
	 * @param serviceProvider
	 * @param responseHolder
	 */
	public void assertSamlOk(ServiceProviderImpl serviceProvider, ResponseHolder responseHolder) {
		assertEquals(responseHolder.getResponseHttpCode(), 200);
		assertTrue(responseHolder.getResponse().getAssertionOrEncryptedAssertion().size() == 1);
		AssertionType assertion = (AssertionType) responseHolder.getResponse().getAssertionOrEncryptedAssertion().get(0);
		assertNotNull(assertion);
		ResponseStatus status = ResponseStatus.from(responseHolder.getResponse().getStatus().getStatusCode().getValue());
		assertEquals(ResponseStatus.SUCCESS,status);
		String clientUid = serviceProvider.clientUid!=null?serviceProvider.clientUid:"483838";
		String idpCertSerialNumbersKnownBySP = "1/2";
		String audit = ",success," + serviceProvider.binding.toString() +","+ serviceProvider.spEntityId + "," + clientUid+","+idpCertSerialNumbersKnownBySP+"," +
				"ValidSesameTokenFor_" + clientUid;
		assertTrue(capture.toString().contains(audit));
		Assert.assertEquals(responseHolder.getRelayState(), serviceProvider.relayState);
		
		
		for (StatementAbstractType statement : assertion.getStatementOrAuthnStatementOrAuthzDecisionStatement()) {
			if (statement instanceof AttributeStatementType) {
				AttributeStatementType attributes = (AttributeStatementType) statement;
				if (attributes.getAttributeOrEncryptedAttribute().size()==0) {
					fail("An <AttributeStatement> must have one or more <Attribute>,<EncryptedAttribute> not zero");
				}
			}
		}

	}
	
}
