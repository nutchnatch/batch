package com.bpc.sesame.saf.functional;

import com.bpc.sesame.saf.WebConstants;
import com.bpc.sesame.saf.mock.TLSClient;
import com.bpc.sesame.saf.mock.TLSClientTools;
import com.bpc.sesame.saf.test.ApplicationBoot;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.nio.file.Paths;

import static org.junit.Assert.assertTrue;

/**
 *
 * Testing class for the change password servlet.
 *
 * @author a20257
 * @since 1.0.0
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes=ApplicationBoot.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ChangePasswordServletTest {
    /**
     * Configuration directory containing the application.properties.
     */
    private static String configDirectory = "./src/test/config-saf/";

    /**
     * The url for the change password servlet.
     */
    @Value("http://localhost:${local.server.port}${server.context-path}/changePassword")
    private String changePasswordPageURL;

    /**
     * Set the system property <code>spring.config.location</code>.
     */
    @BeforeClass
    public static void setConfigDirectory(){
        System.setProperty("spring.config.location",configDirectory);
        System.setProperty("logging.config", "file:"+configDirectory+"logback.xml");
    }

    /**
     *
     * Test for invalid login or password.
     *
     * 1 - Post to the servlet with the user badpwd (user for the sesame mock to return the invalid login/password)
     * 2 - Verify that the response page has the corresponding sesame error L001cLIW1
     *
     */
    @Test
    public void testLoginOrPasswordInvalid(){


        final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(changePasswordPageURL)
                .queryParam(WebConstants.PARAMETER_NEW_PASS, "a")
                .queryParam(WebConstants.PARAMETER_LOGIN, "badpwd")
                .queryParam(WebConstants.PARAMETER_OLD_PASS, "a");
        final RestTemplate template = new RestTemplate();
        final String xml = template.postForObject(builder.build().encode().toUri(), null, String.class);
        assertTrue(xml.contains("L001cLIW1"));
    }
    /**
     *
     * Test for success.
     *
     * 1 - Post to the servlet with an user other than badpwd (for the sesame mock to return success)
     * 2 - Verify that the response as the parameter success and the Http status code is 302 (Found)
     *
     */
    @Test
    public void testChangePasswordOk(){
        final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(changePasswordPageURL)
                .queryParam(WebConstants.PARAMETER_NEW_PASS, "a")
                .queryParam(WebConstants.PARAMETER_LOGIN, "user")
                .queryParam(WebConstants.PARAMETER_OLD_PASS, "a");

        final RestTemplate template = new RestTemplate();
        final ResponseEntity<String> response = template.postForEntity(builder.build().encode().toUri(), null, String.class);
        assertTrue(response.getStatusCode().equals(HttpStatus.FOUND));
        assertTrue(response.getHeaders().getLocation().getQuery().equals("success"));
    }
}
