package com.bpc.sesame.saf.functional;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.bpc.sesame.saf.mock.ApplicationBoot;
import com.bpc.sesame.saf.mock.ServiceProviderImpl.Binding;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=ApplicationBoot.class, webEnvironment = WebEnvironment.RANDOM_PORT)
public class SSOPostTest extends SSORedirectTest{

    protected Binding getDefaultBinding() {
    	return Binding.POST;
    }
 

}