package com.bpc.sesame.saf;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bnppa.sesame.services.internal.v2.IdentityProviderServices;
import com.bnppa.sesame.services.internal.v2.ServiceProvidersServices;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={ApplicationWeb.class})
public class ApplicationWebTest {
	
	@Autowired
	private ServiceProvidersServices serviceProvidersServices;

	@Autowired
	private IdentityProviderServices identityProviderServices;

	@Test
	public void checkThatApplicationContextForWebappIsOK() {
		Assert.assertNotNull(serviceProvidersServices);
		Assert.assertNotNull(identityProviderServices);
	}
}
