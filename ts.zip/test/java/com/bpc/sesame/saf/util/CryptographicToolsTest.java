package com.bpc.sesame.saf.util;

import static com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel.HIGH;
import static com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel.MEDIUM;
import static com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel.NO_AUTH;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import gentypes.saml.metadata.v20.EntityDescriptorType;
import gentypes.saml.metadata.v20.KeyTypes;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Random;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.util.StringUtils;

import com.bpc.sesame.saf.mock.ApplicationBoot;
import com.bpc.sesame.saf.model.CertificatePK;

public class CryptographicToolsTest {
	
	@Test
	public void testRealSmartCardCertificate() throws Exception {
		X509Certificate certificate = CryptographicTools.extractCertificateFromClasspath("certificates/user-cert-from-smartcard.cer");
		assertEquals("798732", CryptographicTools.extractDNSNameFromCertificate(certificate));
		assertEquals(HIGH, CryptographicTools.extractSAFAuthLevelFromCertificate(certificate,true));
	}

	@Test
	public void testRealSmartCardCertificate2() throws Exception {
		X509Certificate certificate = CryptographicTools.extractCertificateFromClasspath("certificates/user2-cert-from-smartcard.cer");
		assertEquals("479874", CryptographicTools.extractDNSNameFromCertificate(certificate));
		assertEquals(HIGH, CryptographicTools.extractSAFAuthLevelFromCertificate(certificate,true));
	}
	
	@Test
	public void testRealSoftwareCertificate() throws Exception {
		X509Certificate certificate = CryptographicTools.extractCertificateFromClasspath("certificates/user-cert-from-software-no-role.cer");
		assertEquals("483838", CryptographicTools.extractDNSNameFromCertificate(certificate));
		assertEquals(NO_AUTH, CryptographicTools.extractSAFAuthLevelFromCertificate(certificate,true));
		assertEquals(MEDIUM, CryptographicTools.extractSAFAuthLevelFromCertificate(certificate,false));
	}
	
	@Test
	public void testRealSoftwareWithClientAuthCertificate() throws Exception {
		X509Certificate certificate = CryptographicTools.extractCertificateFromClasspath("certificates/user-cert-from-software-role-client-auth.cer");
		assertEquals("483838", CryptographicTools.extractDNSNameFromCertificate(certificate));
		assertEquals(MEDIUM, CryptographicTools.extractSAFAuthLevelFromCertificate(certificate,true));
	}
	
	@Test
	public void testSPMetadata() {
		String xml = XmlTools.pathWithXmlToString(Paths.get(ApplicationBoot.getConfigDirectory() + "serviceProviders/urn_cardif_saf_sp_test_spring.xml"));
		EntityDescriptorType desc = XmlTools.stringToEntityDescriptorType(xml);
		List<X509Certificate> certs = CryptographicTools.extractCertificateFromEntityDescriptorType(desc.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor().get(0), KeyTypes.SIGNING);
		assertNotNull(certs);
		assertNotNull(certs.get(0));
	}
	
	@Test
	public void convertCRL() throws IOException {
		byte[] fakeCRL = new byte[800];
		new Random().nextBytes(fakeCRL);
		Path dest = Paths.get("target/test.crl");
		
		CryptographicTools.crlBytesToPemFile(fakeCRL, dest, false);
		Assert.assertEquals(2, StringUtils.countOccurrencesOf(new String(Files.readAllBytes(dest)), " X509 CRL"));
		long firstSize = Files.size(dest);
		CryptographicTools.crlBytesToPemFile(fakeCRL,dest, true);
		Assert.assertEquals(4, StringUtils.countOccurrencesOf(new String(Files.readAllBytes(dest)), " X509 CRL"));
		Assert.assertEquals(2*firstSize, Files.size(dest));
		CryptographicTools.crlBytesToPemFile(fakeCRL, dest, false);
		Assert.assertEquals(2, StringUtils.countOccurrencesOf(new String(Files.readAllBytes(dest)), " X509 CRL"));
		Assert.assertEquals(firstSize, Files.size(dest));
	}
	
	@Test
	public void pemStringToPK() {
		String pemString = "-----BEGIN CERTIFICATE-----\r\n" + 
				"MIICtzCCAZ+gAwIBAgIBAjANBgkqhkiG9w0BAQsFADAfMR0wGwYDVQQDDBRDZXJ0\r\n" + 
				"aWZpY2F0ZSBOdW1iZXIgMjAeFw0xNTEyMzEyMzAwMDBaFw0zNjEyMzEyMzAwMDBa\r\n" + 
				"MB8xHTAbBgNVBAMMFENlcnRpZmljYXRlIE51bWJlciAyMIIBIjANBgkqhkiG9w0B\r\n" + 
				"AQEFAAOCAQ8AMIIBCgKCAQEA0AsSvSgBMdJT4Ryf3bK62v1QW99NH3c4LaVEpFh6\r\n" + 
				"tVrEH7Sc6w84x60SAphqxkQTWhcCPr22dMu9B+59mjOsHNfubiTULXedqTB4Zo9r\r\n" + 
				"ZGHUnpkCeoINep0OXxkDw8R3fx9QODTEJATJShQvSMy6v2QmWXMZx2NeK/1M/nqv\r\n" + 
				"8eZd8dU0Rbi+AWtjxtqaiIrlqmPHou5p80zi8RdpMx3jqV9yr2mqPrx7qvbnWkgM\r\n" + 
				"IRkcAc7kesCLX56uVRMyIqE7LHCD/KT6CrD6wL+UqptaI0UKh/fjXbf851egGUmx\r\n" + 
				"FcIfyFst1MMx4zA+QGF2Ux9qWWZ6tzKRa8SgC2lne6YGowIDAQABMA0GCSqGSIb3\r\n" + 
				"DQEBCwUAA4IBAQCo1sy6uhyrLrario7MW86AGGrwbR8OCxVkAe2TzCOo0kexdm26\r\n" + 
				"DIvSo6K2tIQVRVDjJEEO0FbLaj08JHPl8Awq5uc7UIS+YYK9MPI9rbAklu7tjdLY\r\n" + 
				"Mosnf6/MBKkgePDkNk/TcavzAw4Q2smTgcqogp7iPvm/EutNewyvGpzK6c5G51Fr\r\n" + 
				"o8jaj+LIKCtSJ7HRZje9njTeT6ewCsKbzEwJzR/gqaDDuVNLuYl9KvZ2urEE4/Ml\r\n" + 
				"l63VJNsrR+W+q5p3gsa/jdw8aMfNkZRky73fL3Wr5xSBeRfvr5k/nIlzz0SegelD\r\n" + 
				"kILEmUQU9NkbLmiQc2R8QlDiBf4pV1nR1FJX\r\n" + 
				"-----END CERTIFICATE-----\r\n" + 
				"-----BEGIN RSA PRIVATE KEY-----\r\n" + 
				"Proc-Type: 4,ENCRYPTED\r\n" + 
				"DEK-Info: AES-256-CFB,357B04B0B000208A181ACF34C39D0FEA\r\n" + 
				"\r\n" + 
				"2eur9WqiSU6jSYM8qEupTgmMSm1h4xWjzGdGYvDsbyFAs5Slv2PW1MMMzCEMNLTJ\r\n" + 
				"Bz1T2YBHCT1JSlqIVUFj4GLc2luyW0KGYUIfzVwQeuiniRp/mw8gBCl3utNeIEkw\r\n" + 
				"tWpw1Ynyu65Pm2+tvF4+ZA2iaKTMshQYkr1J2hcW0zJevE4QndCm2Y0cAwBDq/D8\r\n" + 
				"dYx6UtUHHOfC/2XzsQrz4ZRgf02O+Z1dMNiOQHgYht0gOJVND4cs4UxfxZdmI8gf\r\n" + 
				"m//W2F8aneQplDfGB8UELA7Akr+/qlJZ8E+I9nIeOAOWxU1BMTWKeascgVSFkuYT\r\n" + 
				"0elTMvlJaXjeIPxlnvPxHNa03Or3TrIajvfBHZb+BBjEZveTfa0SeVomMcwDBX6A\r\n" + 
				"4psC7Au3SxWLNEjEg2ySpiyOq6cWt9IGnxMQzLlYNFNmlhEAqqwWHz+8dhf72yNd\r\n" + 
				"krLYUr1MEW7nkuKepQzIUrLI5c8gnw0q13mDHyLtaRJh6nN7CgRwWaiz9aE9K7Hz\r\n" + 
				"AfwSg+lhiSB7GUC7oYFbTwl4iXR9asZDRYQ5/aBfUv3dUsf4B8oHgUa+OL/aQEXI\r\n" + 
				"CW6lcAbhLW79nbvVsi0UiN7ZCCHulFwJtjdMS2QT2ZoykpOdGBEZWhJPNnpm4fdK\r\n" + 
				"BtNxyG3a2/cm+AIw5T4OfuS4NQNcsuvJyRAuL4DyHrhp65FSGeTsIlaJuXSibBNE\r\n" + 
				"xYYXyj84Kzr6Z4ZaCenjqbVoHneE9Zg9HuFUXg/4N88ZkiigfLoB858wZitUAB+/\r\n" + 
				"tErNcsGXZEMSYLyVsZIydNxLtaG+Yosl6yU5D5tnUtsZKK3hGrrqBl/laLQu8CNt\r\n" + 
				"nlSC/2r+TL6y0W4buo58tXk5AUNqtaJ6h8txb6EHImMxnHalXkJgxfdopICm8h++\r\n" + 
				"4qTPIheol+lTa6c+7LKqmDD2/XskNTTnVrs/jUBRYAqbCoeSA1SjvRSC2o7NlxrH\r\n" + 
				"qvIJGEQjCjpw53cwxq0gJy00ms6mD2tSUzIxeViXyyXiL9XJpJ4lh691K0JcTkuZ\r\n" + 
				"JvvG1zG+i1kXfjMJOC6ZzvjE4pghJKOhfmvQ42JDVgJK01CYOyxHNcbuxrKeta1V\r\n" + 
				"bIYHH2klzg4tEX3Q067Jv64Q06nlLCv7jWWoa1gnpN4G/pjaIpfv+j6EG/SqlOdL\r\n" + 
				"ZenZvdeLkQSTaGyegc1F3OZtpibBLXyCa02B9wFKgz6C87dqfj3shQvYPBSLmuvC\r\n" + 
				"YOM+IXmiomGRcuYQPBhgtLzHa4oxmI3EWEtt0kPJ2hS8F2Jj+v2R9N/qN6I4zIMw\r\n" + 
				"9ltXWuOCojvUqlnVqGvMZXDvTbm/bGpreW3VlmTzrP3qBLioxtZ9Zyo0cV1y7/ok\r\n" + 
				"h5vNfat3/TblsvTYZ2OKHLmgWYFfV1zHCt8Glr+H8JfeWKqrfBULAcpRMQqgQACf\r\n" + 
				"mkIgyhCRdujIut/fZIHjF3y5NMkiQbYiiKq1hajWe30ojKqH6h/MREqnm/h4RkHe\r\n" + 
				"Sl51IGf2Tzg727pFSLxzG81PjhPFfVSFWIEW9GcMtlqG4EtQM6bvzE/WGxB4RLc5\r\n" + 
				"X69p5nPCthWuj5/rH1T8QPMuZZgI9krNw1YpDc1SsVY5rktnRD05\r\n" + 
				"-----END RSA PRIVATE KEY-----";
		CertificatePK cert = CryptographicTools.pemStringToCertificatePK(pemString, "hello\r".toCharArray());
		String content = CryptographicTools.certificatePKToPemString(cert, "hello".toCharArray());
		System.out.println(content);
	}
}
