package com.bpc.sesame.saf.util;

import gentypes.saml.metadata.v20.EntityDescriptorType;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.xml.security.c14n.Canonicalizer;
import org.junit.Assert;
import org.junit.Test;
import org.xml.sax.SAXParseException;

public class XmlToolsTest {
	
	@Test
	public void playWithCanonicalization() throws Exception {
		//not a real test but good way to see how Canonicalization works
		String xml = "<n1:elem2 \r\n " + 
				"             xml:space=\"retain\"\r\n " + 
				"             xmlns:n1=\"http://example.net\"\r\n" + 
				"             xml:lang=\"en\"\r\n" + 
				"             xmlns:n2=\"http://foo.example\">\r\n" + 
				"       <n3:stuff xmlns:n3=\"ftp://example.org\"></n3:stuff>\r\n" + 
				"   </n1:elem2>";
		org.apache.xml.security.Init.init();
		Canonicalizer canon = Canonicalizer.getInstance(Canonicalizer.ALGO_ID_C14N_EXCL_OMIT_COMMENTS);
		byte canonXmlBytes[] = canon.canonicalize(xml.getBytes("UTF-8"));
		String canonXmlString = new String(canonXmlBytes, "UTF-8");
		System.out.println(xml + "\n\n");
		System.out.println(canonXmlString);
		Assert.assertNotEquals(xml, canonXmlString);
	}

	@Test
	public void stringToEntityDescriptorType() throws UnsupportedEncodingException, IOException {
		String xmlContent = new String(Files.readAllBytes(Paths.get("src/test/config-clients/urn_cardif_saf_sp_test_prog1.xml")), "UTF-8");
		EntityDescriptorType element = XmlTools.stringToEntityDescriptorType(xmlContent);
		Assert.assertNotNull(element);
		Assert.assertNotNull(element.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor());
	}
	
	@Test
	public void stringToEntityDescriptorType_2() throws UnsupportedEncodingException, IOException {
		EntityDescriptorType element = XmlTools.stringToEntityDescriptorType(metadata);
		Assert.assertNotNull(element);
		Assert.assertNotNull(element.getRoleDescriptorOrIDPSSODescriptorOrSPSSODescriptor());
	}
	
	@Test 
	public void validRequest() {
		String validRequest = "<samlp:AuthnRequest xmlns:samlp=\"urn:oasis:names:tc:SAML:2.0:protocol\" ForceAuthn=\"false\" ProtocolBinding=\"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST\" AssertionConsumerServiceURL=\"http://localhost:8080/sci-sp/saml/SSO\" ID=\"ifhjpchfnikhpfebebmdofpnbillondcollgmejk\" Version=\"2.0\" IssueInstant=\"2016-09-14T11:32:06.199Z\" Destination=\"https://localhost:51437/sesame_saf/redirect/sso/1/2\" xmlns:xenc=\"http://www.w3.org/2001/04/xmlenc#\" xmlns:saml=\"urn:oasis:names:tc:SAML:2.0:assertion\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">\r\n" + 
				"  <saml:Issuer>sdfsdfsdfdsfdsf</saml:Issuer>\r\n" + 
				"</samlp:AuthnRequest>";
		XmlTools.validateRequest(validRequest);
		Assert.assertTrue("This request is correct",true);
	}
	
	@Test 
	public void dangerousRequest() {
		String dangerousRequest = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\r\n" + 
				" <!DOCTYPE foo [  \r\n" + 
				"   <!ELEMENT foo ANY >\r\n" + 
				"   <!ENTITY xxe SYSTEM \"file:///c:/boot.ini\" >]>\r\n" + 
				"<samlp:AuthnRequest xmlns:samlp=\"urn:oasis:names:tc:SAML:2.0:protocol\" ForceAuthn=\"false\" ProtocolBinding=\"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST\" AssertionConsumerServiceURL=\"http://localhost:8080/sci-sp/saml/SSO\" ID=\"ifhjpchfnikhpfebebmdofpnbillondcollgmejk\" Version=\"2.0\" IssueInstant=\"2016-09-14T11:32:06.199Z\" Destination=\"https://localhost:51437/sesame_saf/redirect/sso/1/2\" xmlns:xenc=\"http://www.w3.org/2001/04/xmlenc#\" xmlns:saml=\"urn:oasis:names:tc:SAML:2.0:assertion\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">\\r\\n\" + \r\n" + 
				"	<saml:Issuer>&xxe;</saml:Issuer>\r\n" + 
				"</samlp:AuthnRequest>";
		try {
			XmlTools.validateRequest(dangerousRequest);
			Assert.fail("Dangerous request not valid : XXE attack");
		} catch (Exception e) {
			Assert.assertEquals(e.getCause().getClass(), SAXParseException.class);
			Assert.assertTrue(e.getCause().getMessage().contains("accessExternalDTD"));
		}
	}

	String metadata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
			"<md:EntityDescriptor ID=\"dsfsdfeazrdaezrteazrazef\"\r\n" + 
			"	entityID=\"urn:cardif:saf:sp:test:prog1\" xmlns:md=\"urn:oasis:names:tc:SAML:2.0:metadata\">\r\n" + 
			"	<md:SPSSODescriptor AuthnRequestsSigned=\"false\"\r\n" + 
			"		WantAssertionsSigned=\"true\" protocolSupportEnumeration=\"urn:oasis:names:tc:SAML:2.0:protocol\">\r\n" + 
			"		<md:KeyDescriptor use=\"signing\">\r\n" + 
			"			<ds:KeyInfo xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">\r\n" + 
			"				<ds:X509Data>\r\n" + 
			"					<ds:X509Certificate>MIIDUjCCAjqgAwIBAgIEUOLIQTANBgkqhkiG9w0BAQUFADBrMQswCQYDVQQGEwJGSTEQMA4GA1UE\r\n" + 
			"						CBMHVXVzaW1hYTERMA8GA1UEBxMISGVsc2lua2kxGDAWBgNVBAoTD1JNNSBTb2Z0d2FyZSBPeTEM\r\n" + 
			"						MAoGA1UECwwDUiZEMQ8wDQYDVQQDEwZhcG9sbG8wHhcNMTMwMTAxMTEyODAxWhcNMjIxMjMwMTEy\r\n" + 
			"						ODAxWjBrMQswCQYDVQQGEwJGSTEQMA4GA1UECBMHVXVzaW1hYTERMA8GA1UEBxMISGVsc2lua2kx\r\n" + 
			"						GDAWBgNVBAoTD1JNNSBTb2Z0d2FyZSBPeTEMMAoGA1UECwwDUiZEMQ8wDQYDVQQDEwZhcG9sbG8w\r\n" + 
			"						ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCXqP0wqL2Ai1haeTj0alwsLafhrDtUt00E\r\n" + 
			"						5xc7kdD7PISRA270ZmpYMB4W24Uk2QkuwaBp6dI/yRdUvPfOT45YZrqIxMe2451PAQWtEKWF5Z13\r\n" + 
			"						F0J4/lB71TtrzyH94RnqSHXFfvRN8EY/rzuEzrpZrHdtNs9LRyLqcRTXMMO4z7QghBuxh3K5gu7K\r\n" + 
			"						qxpHx6No83WNZj4B3gvWLRWv05nbXh/F9YMeQClTX1iBNAhLQxWhwXMKB4u1iPQ/KSaal3R26pON\r\n" + 
			"						UUmu1qVtU1quQozSTPD8HvsDqGG19v2+/N3uf5dRYtvEPfwXN3wIY+/R93vBA6lnl5nTctZIRsyg\r\n" + 
			"						0Gv5AgMBAAEwDQYJKoZIhvcNAQEFBQADggEBAFQwAAYUjso1VwjDc2kypK/RRcB8bMAUUIG0hLGL\r\n" + 
			"						82IvnKouGixGqAcULwQKIvTs6uGmlgbSG6Gn5ROb2mlBztXqQ49zRvi5qWNRttir6eyqwRFGOM6A\r\n" + 
			"						8rxj3Jhxi2Vb/MJn7XzeVHHLzA1sV5hwl/2PLnaL2h9WyG9QwBbwtmkMEqUt/dgixKb1Rvby/tBu\r\n" + 
			"						RogWgPONNSACiW+Z5o8UdAOqNMZQozD/i1gOjBXoF0F5OksjQN7xoQZLj9xXefxCFQ69FPcFDeEW\r\n" + 
			"						bHwSoBy5hLPNALaEUoa5zPDwlixwRjFQTc5XXaRpgIjy/2gsL8+Y5QRhyXnLqgO67BlLYW/GuHE=\r\n" + 
			"					</ds:X509Certificate>\r\n" + 
			"				</ds:X509Data>\r\n" + 
			"			</ds:KeyInfo>\r\n" + 
			"		</md:KeyDescriptor>\r\n" + 
			"		<md:KeyDescriptor use=\"encryption\">\r\n" + 
			"			<ds:KeyInfo xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">\r\n" + 
			"				<ds:X509Data>\r\n" + 
			"					<ds:X509Certificate>MIIDUjCCAjqgAwIBAgIEUOLIQTANBgkqhkiG9w0BAQUFADBrMQswCQYDVQQGEwJGSTEQMA4GA1UE\r\n" + 
			"						CBMHVXVzaW1hYTERMA8GA1UEBxMISGVsc2lua2kxGDAWBgNVBAoTD1JNNSBTb2Z0d2FyZSBPeTEM\r\n" + 
			"						MAoGA1UECwwDUiZEMQ8wDQYDVQQDEwZhcG9sbG8wHhcNMTMwMTAxMTEyODAxWhcNMjIxMjMwMTEy\r\n" + 
			"						ODAxWjBrMQswCQYDVQQGEwJGSTEQMA4GA1UECBMHVXVzaW1hYTERMA8GA1UEBxMISGVsc2lua2kx\r\n" + 
			"						GDAWBgNVBAoTD1JNNSBTb2Z0d2FyZSBPeTEMMAoGA1UECwwDUiZEMQ8wDQYDVQQDEwZhcG9sbG8w\r\n" + 
			"						ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCXqP0wqL2Ai1haeTj0alwsLafhrDtUt00E\r\n" + 
			"						5xc7kdD7PISRA270ZmpYMB4W24Uk2QkuwaBp6dI/yRdUvPfOT45YZrqIxMe2451PAQWtEKWF5Z13\r\n" + 
			"						F0J4/lB71TtrzyH94RnqSHXFfvRN8EY/rzuEzrpZrHdtNs9LRyLqcRTXMMO4z7QghBuxh3K5gu7K\r\n" + 
			"						qxpHx6No83WNZj4B3gvWLRWv05nbXh/F9YMeQClTX1iBNAhLQxWhwXMKB4u1iPQ/KSaal3R26pON\r\n" + 
			"						UUmu1qVtU1quQozSTPD8HvsDqGG19v2+/N3uf5dRYtvEPfwXN3wIY+/R93vBA6lnl5nTctZIRsyg\r\n" + 
			"						0Gv5AgMBAAEwDQYJKoZIhvcNAQEFBQADggEBAFQwAAYUjso1VwjDc2kypK/RRcB8bMAUUIG0hLGL\r\n" + 
			"						82IvnKouGixGqAcULwQKIvTs6uGmlgbSG6Gn5ROb2mlBztXqQ49zRvi5qWNRttir6eyqwRFGOM6A\r\n" + 
			"						8rxj3Jhxi2Vb/MJn7XzeVHHLzA1sV5hwl/2PLnaL2h9WyG9QwBbwtmkMEqUt/dgixKb1Rvby/tBu\r\n" + 
			"						RogWgPONNSACiW+Z5o8UdAOqNMZQozD/i1gOjBXoF0F5OksjQN7xoQZLj9xXefxCFQ69FPcFDeEW\r\n" + 
			"						bHwSoBy5hLPNALaEUoa5zPDwlixwRjFQTc5XXaRpgIjy/2gsL8+Y5QRhyXnLqgO67BlLYW/GuHE=\r\n" + 
			"					</ds:X509Certificate>\r\n" + 
			"				</ds:X509Data>\r\n" + 
			"			</ds:KeyInfo>\r\n" + 
			"		</md:KeyDescriptor>\r\n" + 
			"		<md:NameIDFormat>urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified\r\n" + 
			"		</md:NameIDFormat>\r\n" + 
			"		\r\n" + 
			"		<md:AttributeConsumingService index=\"1\"\r\n" + 
			"			xmlns:md=\"urn:oasis:names:tc:SAML:2.0:metadata\" xmlns:saml=\"urn:oasis:names:tc:SAML:2.0:assertion\">\r\n" + 
			"			<md:ServiceName xml:lang=\"en\">POC SP SAML</md:ServiceName>\r\n" + 
			"\r\n" + 
			"			<md:RequestedAttribute\r\n" + 
			"				NameFormat=\"urn:oasis:names:tc:SAML:2.0:attrname-format:uri\" \r\n" + 
			"				Name=\"urn:oid:2.16.840.1.113730.3.1.241\"\r\n" + 
			"				FriendlyName=\"displayName\" />\r\n" + 
			"				\r\n" + 
			"			<md:RequestedAttribute Name=\"urn:bnpparibas:cardif:saml:sesame:attribute:token\" />\r\n" + 
			"			<md:RequestedAttribute Name=\"urn:bnpparibas:cardif:saml:sesame:attribute:user-identity\" />\r\n" + 
			"			<md:RequestedAttribute Name=\"urn:bnpparibas:cardif:saml:sesame:attribute:permissions-id\" />\r\n" + 
			"			<md:RequestedAttribute Name=\"urn:bnpparibas:cardif:saml:sesame:attribute:roles-id\" />\r\n" + 
			"			<md:RequestedAttribute Name=\"urn:bnpparibas:cardif:saml:sesame:attribute:using-right\" />\r\n" + 
			"			<md:RequestedAttribute Name=\"urn:bnpparibas:cardif:saml:sesame:attribute:joinings\" />\r\n" + 
			"			<md:RequestedAttribute Name=\"urn:bnpparibas:cardif:saml:sesame:attribute:extended-attributes\" />\r\n" + 
			"				\r\n" + 
			"		</md:AttributeConsumingService>\r\n" + 
			"		<md:AttributeConsumingService index=\"2\"\r\n" + 
			"			xmlns:md=\"urn:oasis:names:tc:SAML:2.0:metadata\" xmlns:saml=\"urn:oasis:names:tc:SAML:2.0:assertion\">\r\n" + 
			"			<md:ServiceName xml:lang=\"en\">POC SP SAML</md:ServiceName>\r\n" + 
			"\r\n" + 
			"			<md:RequestedAttribute\r\n" + 
			"				NameFormat=\"urn:oasis:names:tc:SAML:2.0:attrname-format:uri\" \r\n" + 
			"				Name=\"urn:oid:2.16.840.1.113730.3.1.241\"\r\n" + 
			"				FriendlyName=\"displayName\" />\r\n" + 
			"				\r\n" + 
			"		</md:AttributeConsumingService>\r\n" + 
			"	</md:SPSSODescriptor>\r\n" + 
			"</md:EntityDescriptor>";
}
