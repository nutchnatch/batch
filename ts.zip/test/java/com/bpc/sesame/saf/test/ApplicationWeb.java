package com.bpc.sesame.saf.test;

import com.bpc.sesame.saf.Application;
import com.bpc.sesame.saf.services.EnvironmentServices;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * This class declare the spring configuration in the web scenario for testing purposes.
 * Necessary since the normal ApplicationWeb exposes an {@link EnvironmentServices} bean for non mock, but we want to specifically have one for
 * the sesame mock usage (declared in {@link ApplicationBoot}.
 *
 * @see Application
 * @author a20257
 * @since 1.0.0
 */
@Configuration
@PropertySource(value={"classpath:properties/sesame-saf.properties"}, ignoreResourceNotFound=true)
public class ApplicationWeb {
    /**
     * Sesame base URL.
     */
    @Value("${sesame.saf.identity-provider.sesame-base-url}")
	private String sesameBaseURL;
}
