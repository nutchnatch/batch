package com.bpc.sesame.saf.test.clients;

import gencl.sesame.services.standard.proxy.AuthenticationServicesWSP;
import gencl.sesame.services.standard.proxy.AuthenticationServicesWSPService;

import java.io.IOException;
import java.net.HttpURLConnection;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.xml.bind.DatatypeConverter;
import javax.xml.ws.BindingProvider;

import org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean;
import org.springframework.remoting.httpinvoker.SimpleHttpInvokerRequestExecutor;


import com.bnppa.sesame.services.internal.model.v2.IdentityProviderCertificate;
import com.bnppa.sesame.services.internal.v2.IdentityProviderServices;
import com.bnppa.sesame.services.internal.v2.ServiceProvidersServices;

public class BatchCreate {
	
//	private static final String SIGNATURE_ALGORITHM = "SHA256withRSA";
//	private static final Date NOT_AFTER = Date.valueOf("2037-01-01");
//	private static final Date NOT_BEFORE = Date.valueOf("2016-01-01");
//	private static final int KEY_SIZE = 2048;
	
	
	
    public static ServiceProvidersServices getServiceProvidersServices(String sesameBaseURL) throws Exception {
        HttpInvokerProxyFactoryBean factory = new HttpInvokerProxyFactoryBean();
        factory.setHttpInvokerRequestExecutor(new SimpleHttpInvokerRequestExecutor(){
            @Override
            protected void prepareConnection(HttpURLConnection con, int contentLength) throws IOException {
                String key = "test" + ":" + "test";
                key =  DatatypeConverter.printBase64Binary(key.getBytes("UTF-8"));
                con.addRequestProperty("Authorization", "Basic " + key);
                super.prepareConnection(con, contentLength);
            }
        });
        factory.setServiceUrl(sesameBaseURL + "/sesame_services/Remote/RemoteHttpBean/ServiceProvidersServices");
        factory.setServiceInterface(ServiceProvidersServices.class);
        factory.afterPropertiesSet();
        return (ServiceProvidersServices) factory.getObject();
    }
    
    public static IdentityProviderServices getIdentityProviderServices(String sesameBaseURL) throws Exception {
        HttpInvokerProxyFactoryBean factory = new HttpInvokerProxyFactoryBean();
        factory.setHttpInvokerRequestExecutor(new SimpleHttpInvokerRequestExecutor(){
            @Override
            protected void prepareConnection(HttpURLConnection con, int contentLength) throws IOException {
                String key = "test" + ":" + "test";
                key =  DatatypeConverter.printBase64Binary(key.getBytes("UTF-8"));
                con.addRequestProperty("Authorization", "Basic " + key);
                super.prepareConnection(con, contentLength);
            }
        });
        factory.setServiceUrl(sesameBaseURL + "/sesame_services/Remote/RemoteHttpBean/IdentityProviderServices");
        factory.setServiceInterface(IdentityProviderServices.class);
        factory.afterPropertiesSet();
        return (IdentityProviderServices) factory.getObject();
    }

	
	public static void main(String[] args) throws Exception {
		System.setProperty("https.proxyHost", "localhost");
		System.setProperty("https.proxyPort", "8888");
        HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String s, SSLSession sslSession) {
                return true;
            }
        });

        //String sesameBaseURL = "https://france-sesame-services-uatprj-assurance.staging.echonet";
        String sesameBaseURL = "http://localhost:8080";
       // String uid = "a10817";
        String uid = "SAFADMIN";
		String password = "Password01*";
		
		AuthenticationServicesWSP authent = new AuthenticationServicesWSPService().getAuthenticationServicesWSP();
		((BindingProvider)authent).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, sesameBaseURL + "/sesame_services/services/AuthenticationServicesWSP");
		
		String token = authent.loginInUserRef(uid, password, "GROUP");

		
//		ServiceProvidersServices serviceProvidersServices = getServiceProvidersServices();
//		List<ServiceProvider> sp = serviceProvidersServices.getServiceProvidersWithoutMetadata(token);
//		System.out.println("Number of Service Providers : " + sp.size());
//		
//		ServiceProvider sp1 = serviceProvidersServices.getServiceProvider(token, "urn:cardif:saf:sp:test:prog1");
//		if (sp1!=null) {
//			serviceProvidersServices.deleteServiceProvider(token, "urn:cardif:saf:sp:test:prog1");
//			System.out.println("delete sp1");
//		}
//		sp = serviceProvidersServices.getServiceProvidersWithoutMetadata(token);
//		System.out.println("Number of Service Providers : " + sp.size());
//		
////			ServiceProvider serviceProvider = new ServiceProvider();
////			serviceProvider.setApplicationDomain("SESAME");
////			serviceProvider.setAuthLevel(SAFAuthLevel.HIGH);
////			serviceProvider.setEntityId("urn:cardif:saf:sp:test:prog1");
////			serviceProvider.setLabel("Test application 1");
////			serviceProvider.setId("MEGA1");
////			serviceProvider.setMetaData(new String(Files.readAllBytes(Paths.get("src/test/config-clients/urn_cardif_saf_sp_test_prog1.xml")),"UTF-8"));
////			serviceProvidersServices.createServiceProvider(token, serviceProvider);
////			System.out.println("create sp1");
//		
//		
//		ServiceProvider sp2 = serviceProvidersServices.getServiceProvider(token, "urn:cardif:saf:sp:test:prog2");
//		if (sp2!=null) {
//			serviceProvidersServices.deleteServiceProvider(token, "urn:cardif:saf:sp:test:prog2");
//			System.out.println("delete sp2");
//		}
//		ServiceProvider serviceProvider = new ServiceProvider();
//			serviceProvider.setApplicationDomain("SESAME");
//			serviceProvider.setAuthLevel(SAFAuthLevel.HIGH);
//			serviceProvider.setEntityId("urn:cardif:saf:sp:test:prog2");
//			serviceProvider.setLabel("Test application 2");
//			serviceProvider.setId("MEGA2");
//			serviceProvider.setMetaData(new String(Files.readAllBytes(Paths.get("src/test/config-clients/urn_cardif_saf_sp_test_prog2.xml")),"UTF-8"));
//			serviceProvidersServices.createServiceProvider(token, serviceProvider);
//			
//			System.out.println("create sp2");
//			

		
		IdentityProviderServices identityProviderServices = getIdentityProviderServices(sesameBaseURL);
		//IdentityProviderCertificate current = identityProviderServices.getCurrentIdentityProviderCertificate(token);
		//IdentityProviderCertificate current = identityProviderServices.getCurrentIdentityProviderCertificateWithoutToken();
		//System.out.println(current.getCertificate());
		IdentityProviderCertificate next = identityProviderServices.getNextIdentityProviderCertificate(token);
		System.out.println(next.getCertificate());

		//		if (current == null) {
//			IdentityProviderCertificate certificate = new IdentityProviderCertificate();
//			CertificatePK certificatePK = CryptographicTools.certificateForIDP(BigInteger.ONE, NOT_BEFORE, NOT_AFTER, SIGNATURE_ALGORITHM, KEY_SIZE);
//			String pem = CryptographicTools.certificatePKToPemString(certificatePK, "tZe$o.$k104".toCharArray());
//			certificate.setCertificate(pem);
//			certificate.setCreationDate(new java.util.Date());
//			certificate.setSerialNumber(BigInteger.ONE);
//			identityProviderServices.storeIdentityProviderCertificate(token, certificate);
//			
//			identityProviderServices.setCurrentIdentityProviderCertificate(token, BigInteger.ONE);
//			
//			current = identityProviderServices.getCurrentIdentityProviderCertificate(token);
//			System.out.println("Current certificate : " + current);
//		}
//		
//
//		
		authent.logout(token);
		
	}
}
