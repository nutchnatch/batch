package com.bpc.sesame.saf.test;

import com.bpc.sesame.saf.Application;
import com.bpc.sesame.saf.mock.SesameMockBootstrap;
import com.bpc.sesame.saf.services.EnvironmentServices;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.*;

/**
 *
 * Application boot for testing purposes.
 * Necessary for having the Sesame Mock launched to be used for testing.
 *
 * @author a20257
 * @since 1.0.0
 */
@Configuration
@Import({ApplicationWeb.class})
@ServletComponentScan({"com.bpc.sesame.saf.servlets"})
@ComponentScan(
        basePackages={"com.bpc.sesame.saf"},
        useDefaultFilters = false,
        includeFilters = {
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = Application.class)
})
@PropertySource(value={"classpath:properties/sesame-saf-default.properties"})
@EnableAutoConfiguration
public class ApplicationBoot {

    /**
     * Sesame base URL.
     */
    @Value("${sesame.saf.identity-provider.sesame-base-url}")
    private String sesameBaseURL;

    /**
     * Implement the EnvironmentServices for mock scenario.
     * In mock the scenario the sesameBaseURL is dynamic that's why it's called a sesameDynamicBaseURL
     * @return  the {@link EnvironmentServices}
     */
    @Bean
    public EnvironmentServices getEnvironmentServicesForMock() {
        return new EnvironmentServices() {

            private String sesameDynamicBaseURL;
            @Override
            public String getSesameBaseURL() {
                if ("<EMBEDDED>".equals(sesameBaseURL)) {
                    return sesameDynamicBaseURL;
                } else {
                    return sesameBaseURL;
                }
            }

            @Override
            public void setSesameBaseURL(String sesameBaseURL) {
                this.sesameDynamicBaseURL = sesameBaseURL;
            }
        };
    }

    /**
     * The sesame mock bootstrap bean.
     */
    @Bean
    public SesameMockBootstrap executorListener() {
        return new SesameMockBootstrap();
    }

    /**
     * Entry point for the spring-boot
     * @param args  The arguments
     */
    public static void main(final String[] args) {
        SpringApplication.run(ApplicationBoot.class, args);
    }
}
