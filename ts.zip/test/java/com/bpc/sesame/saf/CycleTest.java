package com.bpc.sesame.saf;
import java.io.IOException;

import jdepend.framework.JDepend;
import junit.framework.TestCase;

public class CycleTest extends TestCase {

    private JDepend jdepend;

    public CycleTest(String name) {
        super(name);
    }

    protected void setUp() throws IOException {
      
        jdepend = new JDepend();
    
        jdepend.addDirectory("target/classes");
    }
  
    /**
     * Tests that a package dependency cycle does not 
     * exist for any of the analyzed packages.
     * @throws IOException 
     */
    public void testAllPackages() throws IOException {
    
        jdepend.analyze();
        
        if (jdepend.containsCycles()) {
        	System.out.println("Cycles exist, search 'Package Dependency Cycles' in console.");
        	jdepend.textui.JDepend d = new jdepend.textui.JDepend();
        	d.addDirectory("target/classes");
        	d.analyze();
        }
        assertFalse("Cycles exist, search 'Package Dependency Cycles' in console.", jdepend.containsCycles());
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(CycleTest.class);
    }
}