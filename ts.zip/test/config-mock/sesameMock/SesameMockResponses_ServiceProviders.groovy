
import java.util.Properties;

import java.nio.file.DirectoryStream;
import java.nio.file.FileSystemNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.bnppa.sesame.services.internal.exception.v2.InvalidParameterException;
import com.bnppa.sesame.services.internal.exception.v2.UnauthorizedActionException;
import com.bnppa.sesame.services.internal.model.v2.SAFAuthLevel;
import com.bnppa.sesame.services.internal.model.v2.ServiceProvider;
import com.bnppa.sesame.services.internal.v2.ServiceProvidersServices;

/**
 * Services to manager the different service providers
 * @author 483838
 */
/**
 * Mock implementation of the services to manage the services providers.
 * This implementation is based on a local directory where it can find the sp metadatas and 
 * a file service-providers.properties.
 * Please, launch the mock and go the adminServlet http://localhost:8080/sesame_saf/admin.
 * To view the usage of this directory.
 * @author 483838
 */
public class SesameMockResponses_ServiceProviders {
	
	private static final Logger log = LoggerFactory.getLogger(SesameMockResponses_ServiceProviders.class);
	
	private static final String SERVICE_PROVIDERS_PROP = "serviceProviders/service-providers.properties";
	
	private Path metadatasDirectory;
	
	private Properties properties;

	public SesameMockResponses_ServiceProviders() throws FileNotFoundException, IOException {
		String configDirectory;
		if (Files.exists(Paths.get("./src/test/config-mock/"))) {
			configDirectory = "./src/test/config-mock/";
		} else if (Files.exists(Paths.get("./config-mock/"))) {
			configDirectory = "./config-mock/";
		} else {
			throw new FileNotFoundException("Cannot found the configuration Directory.");
		}
		
		properties = new Properties();
		File f = Paths.get(configDirectory + SERVICE_PROVIDERS_PROP).toFile();
		if (!f.exists()) {
			log.error("Impossible to found : " + f.getAbsolutePath());
			throw new FileNotFoundException("Impossible to found the " + SERVICE_PROVIDERS_PROP);
		}
		metadatasDirectory = f.getParentFile().toPath();
		
		def props = new Properties()
		f.withInputStream {
			stream -> props.load(stream)
		}
		properties = props
	}
	
	
	
	private ServiceProvider constructMetadata(String entityId) {
		ServiceProvider meta = new ServiceProvider();
		meta.setEntityId(entityId);
		String appDomain = properties.getProperty(entityIdToKey(entityId) + ".app-domain");
		if (appDomain == null || appDomain.length()==0) {
			appDomain = "DEFAULT";
		}
		meta.setApplicationDomain(appDomain);
		String al = properties.getProperty(entityIdToKey(entityId) + ".auth-level");
		meta.setAuthLevel(al==null||al.equals("")?SAFAuthLevel.HIGH:SAFAuthLevel.valueOf(al));
		return meta;
	}
	

	def mock_ServiceProvidersServices_getServiceProvider(String token, String entityId) throws UnauthorizedActionException,com.bnppa.sesame.services.internal.exception.v2.TechnicalException {
		return mock_ServiceProvidersServices_getServiceProviderWithoutToken(entityId);
	}
	
	def mock_ServiceProvidersServices_getServiceProvidersWithoutMetadata(String token) throws UnauthorizedActionException, com.bnppa.sesame.services.internal.exception.v2.TechnicalException {
		
		List<ServiceProvider> result = new ArrayList<>();
		Set<String> checker = new HashSet<>();
		Files.newDirectoryStream(metadatasDirectory, "*.xml").withCloseable { ds ->
			for (Path p : ds) {
				def rootNode = new XmlSlurper().parse(p.toFile())
				def entityId = rootNode.@entityID as String
				
				if (!entityId) {
					throw new Exception("The metadata " + p.getFileName() + " doesn't have entity id.");
				}
				
				if (checker.contains(entityId)) {
					log.warn("At least 2 metadatas file have the same EntityID : " + entityId);
				}
				
				checker.add(entityId);
				result.add(constructMetadata(entityId));
			}
		}
		
		return result;
	}

	
	def mock_ServiceProvidersServices_getServiceProviderWithoutToken(String entityId) throws UnauthorizedActionException, com.bnppa.sesame.services.internal.exception.v2.TechnicalException {

		String metadataFilename = entityIdToKey(entityId) + ".xml";
		
		Path metadataPath = metadatasDirectory.resolve(metadataFilename);
		
		if (Files.notExists(metadataPath)) {
			throw new FileSystemNotFoundException("Doesn't found metadata file : " + metadataFilename);
		}

		ServiceProvider metadata = constructMetadata(entityId);
		metadata.setMetaData(metadataPath.toFile().getText('UTF-8'));
		return metadata;

	}
	
	private String entityIdToKey(String entityId) {
		return entityId.replaceAll("[^a-zA-Z0-9.-]", "_");
	}
}