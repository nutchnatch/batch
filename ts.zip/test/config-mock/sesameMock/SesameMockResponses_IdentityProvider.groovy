
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

import com.bnppa.sesame.services.internal.exception.v2.InvalidParameterException;
import com.bnppa.sesame.services.internal.exception.v2.UnauthorizedActionException;
import com.bnppa.sesame.services.internal.model.v2.IdentityProviderCertificate;
import com.bnppa.sesame.services.internal.v2.IdentityProviderServices;

/**
 * Mock implementation of the services to manage the identity provider.
 * This implementation is based on a local directory where it can find the idp certifcates.
 * Please, launch the mock and go the adminServlet http://localhost:8080/sesame_saf/admin.
 * To view the usage of this directory.
 * @author 483838
 */
public class SesameMockResponses_IdentityProvider {
	
	private Path idpCertDirectory;
	
	private static final String IDP_MOCK_CERT = "identityProvider";
	
	public SesameMockResponses_IdentityProvider() throws FileNotFoundException, IOException {
		String configDirectory;
		if (Files.exists(Paths.get("./src/test/config-mock/"))) {
			configDirectory = "./src/test/config-mock/";
		} else if (Files.exists(Paths.get("./config-mock/"))) {
			configDirectory = "./config-mock/";
		} else {
			throw new FileNotFoundException("Cannot found the configuration Directory.");
		}
		
		idpCertDirectory = Paths.get(configDirectory + IDP_MOCK_CERT);
		if (Files.notExists(idpCertDirectory)) {
			throw new FileNotFoundException("Impossible to found the " + IDP_MOCK_CERT + " directory for IDP Mock certificates.");
		}
	}
	
	def mock_IdentityProviderServices_getIdentityProviderCertificatesInfo(String token) throws UnauthorizedActionException, com.bnppa.sesame.services.internal.exception.v2.TechnicalException {
		List<IdentityProviderCertificate> certificates = new ArrayList<>();
		
		Files.newDirectoryStream(idpCertDirectory, "*.certificate.pk.pem").withCloseable { stream ->
			try {
				for (Path entry : stream) {
					IdentityProviderCertificate c = new IdentityProviderCertificate();
					c.setSerialNumber(new BigInteger(entry.getFileName().toString().substring(4,7)));
					long time = Files.readAttributes(entry, BasicFileAttributes.class).creationTime().toMillis();
					c.setCreationDate(new Date(time));
					certificates.add(c);
				}
			} catch (Exception e) {
				throw new Exception("Impossible to get certificates from " + idpCertDirectory , e);
			}
		}
		
		Collections.sort(certificates);
		return certificates;
	}
	
	void mock_IdentityProviderServices_storeIdentityProviderCertificate(String token, IdentityProviderCertificate certificate) throws UnauthorizedActionException,
	InvalidParameterException, com.bnppa.sesame.services.internal.exception.v2.TechnicalException {

		try {
			Files.write(getCertificatePath(certificate.getSerialNumber().longValue()), certificate.getCertificate().getBytes("UTF-8"));
		} catch (Exception e) {
			throw new RuntimeException("Error when writing certificate of private key.",e);
		}

	}
	
	private Path getCertificatePath(long serialNumber) {
		String name = ((serialNumber + 1000)+"").substring(1);
		return idpCertDirectory.resolve("idp."+name+".certificate.pk.pem");
	}

	def mock_IdentityProviderServices_getCurrentIdentityProviderCertificate(String token) throws UnauthorizedActionException, com.bnppa.sesame.services.internal.exception.v2.TechnicalException {
		return mock_IdentityProviderServices_getCurrentIdentityProviderCertificateWithoutToken();
	}

	def mock_IdentityProviderServices_getNextIdentityProviderCertificate(String token) throws UnauthorizedActionException, com.bnppa.sesame.services.internal.exception.v2.TechnicalException {
		List<IdentityProviderCertificate> serialNumbers = mock_IdentityProviderServices_getIdentityProviderCertificatesInfo(token);
		if (serialNumbers.size()>1) {
			try {
				IdentityProviderCertificate nextCert = serialNumbers.get(serialNumbers.size()-1); 
				String certificate = new String(Files.readAllBytes(getCertificatePath(nextCert.getSerialNumber().longValue())),"UTF-8");
				nextCert.setCertificate(certificate);
				return nextCert;
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		return null;
	}

	def mock_IdentityProviderServices_getCurrentIdentityProviderCertificateWithoutToken() throws UnauthorizedActionException, com.bnppa.sesame.services.internal.exception.v2.TechnicalException {
		List<IdentityProviderCertificate> certificates = mock_IdentityProviderServices_getIdentityProviderCertificatesInfo(null);
		if (certificates.size()==0) {
			return null;
		}

		IdentityProviderCertificate current = certificates.get(certificates.size()-1); 
		if (certificates.size()>1) {
			current = certificates.get(certificates.size()-2);
		}
		try {
			String certificate = new String(Files.readAllBytes(getCertificatePath(current.getSerialNumber().longValue())),"UTF-8");
			current.setCertificate(certificate);
			return current;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

}
