package com.ossnms.dcn_manager.test.util;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

public final class ReturnFirstArgumentAsString implements Answer<String> {
    @Override
    public String answer(InvocationOnMock invocation) {
        return (String) invocation.getArguments()[0];
    }
}