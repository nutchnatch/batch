package com.ossnms.dcn_manager.test.util;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

import java.util.Objects;
import java.util.Optional;

/**
 * Matcher used to verify if a given {@link Optional} instance is in the
 * present state and has a specific value.
 *
 * @see TypeSafeMatcher<T>
 */
public class HasValue<T> extends TypeSafeMatcher<Optional<T>> {

    private final Optional<T> value;

    public HasValue(T value) {
        this.value = Optional.of(value);
    }

    @Override
    public void describeTo(Description description) {
        description.appendText("present and with value ").appendValue(value);
    }

    @Override
    protected boolean matchesSafely(Optional<T> item) {
        return Objects.equals(item, value);
    }
}
