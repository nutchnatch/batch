package com.ossnms.dcn_manager.test.util;

import org.hamcrest.Factory;

/**
 * Convenience class that aggregates factory methods for the custom Matchers
 * used throughout the component's unit tests
 */
public final class OtherMatchers {

	/** Prevents instantiation */
    private OtherMatchers() {
    }

	@Factory
	public static IsAbsent absent() {
		return new IsAbsent();
	}

	@Factory
	public static IsPresent present() {
        return new IsPresent();
    }

    @Factory
    public static <T> HasValue<T> hasValue(T value) {
        return new HasValue<>(value);
    }
}
