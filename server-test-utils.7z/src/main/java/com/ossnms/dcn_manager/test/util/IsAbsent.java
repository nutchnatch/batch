package com.ossnms.dcn_manager.test.util;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

import java.util.Optional;

/**
 * Matcher used to verify if a given {@link Optional} instance is in the
 * absent state, that is, it does not have a value.
 *
 * @see TypeSafeMatcher
 */
public class IsAbsent extends TypeSafeMatcher<Optional<?>> {

    @Override
    public void describeTo(Description description) {
        description.appendText("absent");
    }

    @Override
    protected boolean matchesSafely(Optional<?> item) {
        return !item.isPresent();
    }
}
