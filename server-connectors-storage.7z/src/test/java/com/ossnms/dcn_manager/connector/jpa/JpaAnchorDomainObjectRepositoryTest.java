package com.ossnms.dcn_manager.connector.jpa;

import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.storage.channel.entities.ChannelInfoDb;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

@SuppressWarnings("unchecked")
public class JpaAnchorDomainObjectRepositoryTest {

    private static final int CHANNEL_ID = 2;
    private static final int MEDIATOR_ID = 1;
    private static final String SELECT_ALL_IDS_NAMED_QUERY = "selectAllIdsNamedQuery";
    private static final String SELECT_ALL_NAMED_QUERY = "selectAllNamedQuery";

    private final class JpaAnchorDomainObjectRepositoryMock
        extends JpaAnchorDomainObjectRepository<ChannelInfoData, ChannelInfoMutationDescriptor, ChannelInfoDb, ChannelInfoInitialData> {

        public JpaAnchorDomainObjectRepositoryMock() {
            super(
                ChannelInfoDb.class,
                new Supplier<CloseableEntityTransaction>() {
                    @Override
                    public CloseableEntityTransaction get() {
                        return new CloseableEntityTransaction(em, et);
                    }
                },
                SELECT_ALL_NAMED_QUERY,
                SELECT_ALL_IDS_NAMED_QUERY
            );
        }

        @Override
        protected ChannelInfoDb buildDatabaseObjectForInsert(int parentId, ChannelInfoInitialData objectPrototype) {
            return new ChannelInfoDb(parentId, objectPrototype);
        }

        @Override
        protected ChannelInfoDb buildDatabaseObjectForInsert(ChannelInfoInitialData objectPrototype) {
            return new ChannelInfoDb(MEDIATOR_ID, objectPrototype); // for testing only, don't even THINK of doing this on real code...
        }

        @Override
        protected ChannelInfoDb buildDatabaseObjectForUpdate(ChannelInfoData targetObject, ChannelInfoData mutationResult) {
            return new ChannelInfoDb(targetObject.getId(), targetObject.getMediatorId(), targetObject.getVersion(), mutationResult);
        }

    }

    private EntityTransaction et;
    private EntityManager em;

    private final JpaAnchorDomainObjectRepositoryMock ador = new JpaAnchorDomainObjectRepositoryMock();

    @Before
    public void setUp() {
        et = mock(EntityTransaction.class);
        em = mock(EntityManager.class);
    }

    @Test(expected=RepositoryException.class)
    public void testInsert_exception_propagates() throws RepositoryException {
        doThrow(new PersistenceException()).when(em).persist(isA(ChannelInfoDb.class));

        ador.insert(new ChannelInfoInitialData().setType("channelType"));
    }

    @Test
    public void testInsert() throws RepositoryException {
        when(em.merge(isA(ChannelInfoDb.class))).then(new PassthroughAnswer<ChannelInfoDb>());

        final ChannelInfoData data = ador.insert(new ChannelInfoInitialData().setType("channelType"));

        assertThat(data, is(notNullValue()));
        assertThat(data.getMediatorId(), is(MEDIATOR_ID));
        assertThat(data.getType(), is("channelType"));
    }

    @Test(expected=RepositoryException.class)
    public void testQueryAllEntityIdentifiers_exception_propagates() throws RepositoryException {
        when(em.createNamedQuery(anyString(), any(Class.class))).thenThrow(new PersistenceException());

        ador.queryAllEntityIdentifiers();
    }

    @Test
    public void testQueryAllEntityIdentifiers_noResults() throws RepositoryException {
        final TypedQuery<Integer> query = mock(TypedQuery.class);

        when(query.getResultList()).thenReturn(Collections.<Integer>emptyList());
        when(em.createNamedQuery(SELECT_ALL_IDS_NAMED_QUERY, Integer.class)).thenReturn(query);

        final Iterable<Integer> identifiers = ador.queryAllEntityIdentifiers();

        assertThat(identifiers, is(emptyIterable()));
    }

    @Test
    public void testQueryAllEntityIdentifiers() throws RepositoryException {
        final TypedQuery<Integer> query = mock(TypedQuery.class);

        when(query.getResultList()).thenReturn(Collections.singletonList(CHANNEL_ID));
        when(em.createNamedQuery(SELECT_ALL_IDS_NAMED_QUERY, Integer.class)).thenReturn(query);

        final Iterable<Integer> identifiers = ador.queryAllEntityIdentifiers();

        assertThat(identifiers, is(Matchers.<Integer>iterableWithSize(1)));
        assertThat(identifiers, hasItem(CHANNEL_ID));
    }

}
