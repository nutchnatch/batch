package com.ossnms.dcn_manager.connector.jpa;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.storage.channel.entities.ChannelInfoDb;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SuppressWarnings("unchecked")
public class JpaDomainObjectRepositoryTest {

    private static final String CHANNEL_TYPE = "channelType";
    private static final String SELECT_ALL_NAMED_QUERY = "selectAllNamedQuery";
    private static final int MEDIATOR_ID = 4;
    private static final int CHANNEL_ID = 6;

    private final class JpaDomainObjectRepositoryStub
        extends JpaDomainObjectRepository<ChannelInfoData, ChannelInfoMutationDescriptor, ChannelInfoDb, ChannelInfoInitialData> {

        public JpaDomainObjectRepositoryStub() {
            super(
                    ChannelInfoDb.class,
                    new Supplier<CloseableEntityTransaction>() {
                        @Override
                        public CloseableEntityTransaction get() {
                            return new CloseableEntityTransaction(em, et);
                        }
                    },
                    SELECT_ALL_NAMED_QUERY
            );
        }

        @Override
        protected ChannelInfoDb buildDatabaseObjectForInsert(int parentId, ChannelInfoInitialData initialData) {
            return new ChannelInfoDb(parentId, initialData);
        }

        @Override
        protected ChannelInfoDb buildDatabaseObjectForUpdate(ChannelInfoData targetObject, ChannelInfoData mutationResult) {
            return new ChannelInfoDb(targetObject.getId(), targetObject.getMediatorId(), targetObject.getVersion(), mutationResult);
        }
    }

    private EntityTransaction et;
    private EntityManager em;

    private final JpaDomainObjectRepositoryStub dor = new JpaDomainObjectRepositoryStub();

    @Before
    public void setUp() {
        et = mock(EntityTransaction.class);
        em = mock(EntityManager.class);
    }

    @Test(expected=RepositoryException.class)
    public void testInsertOnTransaction_exception_propagates() throws RepositoryException {
        doThrow(new PersistenceException()).when(em).persist(any(ChannelInfoDb.class));

        dor.insert(new CloseableEntityTransaction(em, et), MEDIATOR_ID, new ChannelInfoInitialData().setType(CHANNEL_TYPE));
    }

    @Test
    public void testInsertOnTransaction() throws RepositoryException {
        when(em.merge(any(ChannelInfoDb.class))).then(new PassthroughAnswer<ChannelInfoDb>());

        final ChannelInfoData data = dor.insert(new CloseableEntityTransaction(em, et), MEDIATOR_ID,
                new ChannelInfoInitialData().setType(CHANNEL_TYPE));

        assertThat(data, is(notNullValue()));
        assertThat(data.getMediatorId(), is(MEDIATOR_ID));
        assertThat(data.getType(), is(CHANNEL_TYPE));
    }

    @Test(expected=RepositoryException.class)
    public void testRemove_findException_propagates() throws RepositoryException {
        when(em.find(any(Class.class), any())).thenThrow(new PersistenceException());

        dor.remove(CHANNEL_ID);
    }

    @Test(expected=RepositoryException.class)
    public void testRemove_removeException_propagates() throws RepositoryException {
        final ChannelInfoDb found = new ChannelInfoDb();
        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(found);
        doThrow(new PersistenceException()).when(em).remove(found);

        dor.remove(CHANNEL_ID);
    }

    @Test
    public void testRemove_notFound_ignores() throws RepositoryException {
        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(null);

        dor.remove(CHANNEL_ID);

        verify(em, never()).remove(any());
    }

    @Test
    public void testRemove() throws RepositoryException {
        final ChannelInfoDb found = new ChannelInfoDb();
        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(found);

        dor.remove(CHANNEL_ID);

        verify(em).remove(found);
    }

    @Test(expected=RepositoryException.class)
    public void testQuery_exception_propagates() throws RepositoryException {
        when(em.find(any(Class.class), any())).thenThrow(new PersistenceException());

        dor.query(CHANNEL_ID);
    }

    @Test
    public void testQuery_nothingFound() throws RepositoryException {
        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(null);

        final Optional<ChannelInfoData> query = dor.query(CHANNEL_ID);

        assertThat(query, is(absent()));
    }

    @Test
    public void testQuery() throws RepositoryException {
        final ChannelInfoDb found = new ChannelInfoDb(CHANNEL_ID, MEDIATOR_ID, 0, new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(CHANNEL_ID, 0, MEDIATOR_ID));
        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(found);

        final Optional<ChannelInfoData> query = dor.query(CHANNEL_ID);
        assertThat(query, is(present()));
    }

    @Test(expected=RepositoryException.class)
    public void testQueryAll_exception_propagates() throws RepositoryException {
        when(em.createNamedQuery(anyString(), any(Class.class))).thenThrow(new PersistenceException());

        dor.queryAll();
    }

    @Test
    public void testQueryAll_noResults() throws RepositoryException {
        final TypedQuery<ChannelInfoDb> query = mock(TypedQuery.class);

        when(query.getResultList()).thenReturn(Collections.emptyList());
        when(em.createNamedQuery(SELECT_ALL_NAMED_QUERY, ChannelInfoDb.class)).thenReturn(query);

        final Iterable<ChannelInfoData> all = dor.queryAll();

        assertThat(all, is(emptyIterable()));
    }

    @Test
    public void testQueryAll() throws RepositoryException {
        final ChannelInfoDb found = new ChannelInfoDb(CHANNEL_ID, MEDIATOR_ID, 0, new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(CHANNEL_ID, 0, MEDIATOR_ID));
        final TypedQuery<ChannelInfoDb> query = mock(TypedQuery.class);

        when(query.getResultList()).thenReturn(Collections.singletonList(found));
        when(em.createNamedQuery(SELECT_ALL_NAMED_QUERY, ChannelInfoDb.class)).thenReturn(query);

        final Iterable<ChannelInfoData> all = dor.queryAll();

        assertThat(all, is(Matchers.iterableWithSize(1)));
    }

    @Test(expected=RepositoryException.class)
    public void testTryUpdate_exception_propagates() throws RepositoryException {
        final ChannelInfoData original = new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(CHANNEL_ID, 0, MEDIATOR_ID);
        final ChannelInfoMutationDescriptor descriptor =
                new ChannelInfoMutationDescriptor(original)
                   .setActive(true);

        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(new ChannelInfoDb(CHANNEL_ID, MEDIATOR_ID, 0, original));
        doThrow(new PersistenceException()).when(em).merge(any());

        dor.tryUpdate(descriptor);
    }

    @Test
    public void testTryUpdate_incorrectVersion() throws RepositoryException {
        final ChannelInfoMutationDescriptor descriptor =
                new ChannelInfoMutationDescriptor(
                        new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(CHANNEL_ID, 0, MEDIATOR_ID))
                .setActive(true);

        when(em.merge(any())).thenThrow(new OptimisticLockException());

        final Optional<ChannelInfoData> updated = dor.tryUpdate(descriptor);

        assertThat(updated, is(absent()));
    }

    @Test
    public void testTryUpdate() throws RepositoryException {
        final ChannelInfoData original = new ChannelInfoBuilder().setActivationRequired(false).setType(CHANNEL_TYPE).build(CHANNEL_ID, 0, MEDIATOR_ID);
        final ChannelInfoMutationDescriptor descriptor =
                new ChannelInfoMutationDescriptor(original)
                    .setActive(true);

        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(new ChannelInfoDb(CHANNEL_ID, MEDIATOR_ID, 0, original));
        when(em.merge(any())).then(new PassthroughAnswer<>());

        final Optional<ChannelInfoData> updated = dor.tryUpdate(descriptor);

        assertThat(updated, is(present()));
    }

    @Test
    public void testTryUpdate_noChanges() throws RepositoryException {
        final ChannelInfoData original = new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(CHANNEL_ID, 0, MEDIATOR_ID);
        final ChannelInfoMutationDescriptor descriptor =
                new ChannelInfoMutationDescriptor(original);

        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(new ChannelInfoDb(CHANNEL_ID, MEDIATOR_ID, 0, original));
        when(em.merge(any())).thenThrow(new OptimisticLockException());

        final Optional<ChannelInfoData> updated = dor.tryUpdate(descriptor);

        assertTrue(updated.get() == descriptor.getTarget());
    }

    @Test
    public void testTryUpdate_originalNotFound_returnsAbsent() throws RepositoryException {
        final ChannelInfoData original = new ChannelInfoBuilder().setActivationRequired(false).setType(CHANNEL_TYPE).build(CHANNEL_ID, 0, MEDIATOR_ID);
        final ChannelInfoMutationDescriptor descriptor =
                new ChannelInfoMutationDescriptor(original)
                    .setActive(true);

        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(null);

        final Optional<ChannelInfoData> updated = dor.tryUpdate(descriptor);

        assertThat(updated, is(absent()));

        verify(em, never()).merge(any());
    }

    @Test
    public void testTryUpdate_withinUnitOfWork() throws RepositoryException {
        final ChannelInfoData original = new ChannelInfoBuilder().setActivationRequired(false).setType(CHANNEL_TYPE).build(CHANNEL_ID, 0, MEDIATOR_ID);
        final ChannelInfoMutationDescriptor descriptor =
                new ChannelInfoMutationDescriptor(original)
                        .setActive(true);

        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(new ChannelInfoDb(CHANNEL_ID, MEDIATOR_ID, 0, original));
        when(em.merge(any())).then(new PassthroughAnswer<>());

        final Optional<ChannelInfoData> updated = dor.tryUpdate(new JpaUnitOfWorkContext(new CloseableEntityTransaction(em, et)), descriptor);

        assertThat(updated, is(present()));
    }

    @Test
    public void testTryUpdate_withinUnitOfWork_originalNotFound_returnsAbsent() throws RepositoryException {
        final ChannelInfoData original = new ChannelInfoBuilder().setActivationRequired(false).setType(CHANNEL_TYPE).build(CHANNEL_ID, 0, MEDIATOR_ID);
        final ChannelInfoMutationDescriptor descriptor =
                new ChannelInfoMutationDescriptor(original)
                        .setActive(true);

        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(null);

        final Optional<ChannelInfoData> updated = dor.tryUpdate(new JpaUnitOfWorkContext(new CloseableEntityTransaction(em, et)), descriptor);

        assertThat(updated, is(absent()));

        verify(em, never()).merge(any());
    }

    @Test
    public void testTryUpdate_withinUnitOfWork_noChanges() throws RepositoryException {
        final ChannelInfoData original = new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(CHANNEL_ID, 0, MEDIATOR_ID);
        final ChannelInfoMutationDescriptor descriptor =
                new ChannelInfoMutationDescriptor(original);

        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(new ChannelInfoDb(CHANNEL_ID, MEDIATOR_ID, 0, original));
        when(em.merge(any())).thenThrow(new OptimisticLockException());

        final Optional<ChannelInfoData> updated = dor.tryUpdate(new JpaUnitOfWorkContext(new CloseableEntityTransaction(em, et)), descriptor);

        assertTrue(updated.get() == descriptor.getTarget());
    }

    @Test(expected = PersistenceException.class)
    public void testTryUpdate_withinUnitOfWork_exception_propagates() throws RepositoryException {
        final ChannelInfoData original = new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(CHANNEL_ID, 0, MEDIATOR_ID);
        final ChannelInfoMutationDescriptor descriptor =
                new ChannelInfoMutationDescriptor(original)
                        .setActive(true);

        when(em.find(ChannelInfoDb.class, CHANNEL_ID)).thenReturn(new ChannelInfoDb(CHANNEL_ID, MEDIATOR_ID, 0, original));
        doThrow(new PersistenceException()).when(em).merge(any());

        final CloseableEntityTransaction transaction = new CloseableEntityTransaction(em, et);
        dor.tryUpdate(new JpaUnitOfWorkContext(transaction), descriptor);
    }

}
