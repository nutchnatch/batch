package com.ossnms.dcn_manager.connector.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.SingleColumnType;
import org.junit.Before;
import org.junit.Test;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isA;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@SuppressWarnings({ "rawtypes", "unchecked" })
public class OptionalTypesTest {

    private SingleColumnType<Object> type;
    private OptionalTypes<?> optionalTypes;

    @Before
    public void setUp() {
        type = mock(SingleColumnType.class);
        optionalTypes = new OptionalTypes<>(type);
    }

    @Test
    public void testSqlTypes() {
        final int[] sqlTypes = optionalTypes.sqlTypes();
        assertThat(sqlTypes, is(notNullValue()));
        assertThat(sqlTypes.length, is(1));
    }

    @Test
    public void testReturnedClass() {
        assertThat(optionalTypes.returnedClass(), is(equalTo((Class) Optional.class)));
    }

    @Test
    public void testNullSafeGet() throws HibernateException, SQLException {
        final ResultSet rs = mock(ResultSet.class);
        final SessionImplementor si = mock(SessionImplementor.class);
        final Object result = new Object();

        when(type.get(any(ResultSet.class), any(String.class), any(SessionImplementor.class)))
            .thenReturn(null, result);

        Object get = optionalTypes.nullSafeGet(rs, new String[] { "column" }, si, null);
        assertThat(get, isA((Class) Optional.class));
        assertThat((Optional<?>) get, is(absent()));

        get = optionalTypes.nullSafeGet(rs, new String[] { "column" }, si, null);
        assertThat(get, isA((Class) Optional.class));
        assertThat((Optional<?>) get, is(present()));
        assertThat(((Optional<?>) get).get(), is(result));
    }

    @Test
    public void testNullSafeSet() throws HibernateException, SQLException {
        final SessionImplementor si = mock(SessionImplementor.class);
        final PreparedStatement ps = mock(PreparedStatement.class);
        final Object value = new Object();

        optionalTypes.nullSafeSet(ps, null, 1, si);
        optionalTypes.nullSafeSet(ps, Optional.empty(), 1, si);
        optionalTypes.nullSafeSet(ps, Optional.of(value), 1, si);

        verify(type, times(2)).set(ps, null, 1, si);
        verify(type).set(ps, value, 1, si);
    }

    @Test
    public void testDeepCopy() {
        final Object value = new Object();
        assertThat(optionalTypes.deepCopy(value), is(value));
    }

    @Test
    public void testIsMutable() {
        assertThat(optionalTypes.isMutable(), is(false));
    }

    @Test
    public void testDisassemble() {
        final Serializable value = mock(Serializable.class);
        Object get;

        get = optionalTypes.disassemble(null);
        assertThat(get, is(nullValue()));

        get = optionalTypes.disassemble(Optional.empty());
        assertThat(get, is(nullValue()));

        get = optionalTypes.disassemble(Optional.of(value));
        assertThat(get, is(value));
    }

    @Test
    public void testAssemble() {
        final Serializable value = mock(Serializable.class);
        Object get;

        get = optionalTypes.assemble(null, null);
        assertThat(get, isA((Class) Optional.class));
        assertThat((Optional<?>) get, is(absent()));

        get = optionalTypes.assemble(value, null);
        assertThat(get, isA((Class) Optional.class));
        assertThat((Optional<?>) get, is(present()));
        assertThat(((Optional<Serializable>) get).get(), is(value));
    }

    @Test
    public void testReplace() {
        final Object value = new Object();
        assertThat(optionalTypes.replace(value, null, null), is(value));
    }

}
