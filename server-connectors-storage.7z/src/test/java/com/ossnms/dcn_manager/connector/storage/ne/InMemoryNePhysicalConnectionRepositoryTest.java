package com.ossnms.dcn_manager.connector.storage.ne;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;

public class InMemoryNePhysicalConnectionRepositoryTest {

    private static final int CHANNEL_INSTANCE_ID = 30;
    private static final int NE_ID = 20;

    @Test
    public void insert() throws Exception {

        final InMemoryNePhysicalConnectionRepository repo = new InMemoryNePhysicalConnectionRepository();

        assertThat(repo.queryAll(), is(emptyIterable()));

        final NePhysicalConnectionData newConnectionData1 = repo.insert(
            new NePhysicalConnectionInitialData()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .setAdditionalInfo("info"),
            NE_ID,
            CHANNEL_INSTANCE_ID);

        final NePhysicalConnectionData newConnectionData2 = repo.insert(
            new NePhysicalConnectionInitialData(),
            NE_ID,
            CHANNEL_INSTANCE_ID);

        assertThat(newConnectionData1.getId(), is(1));
        assertThat(newConnectionData1.getActualActivationState(), is(ActualActivationState.INITIALIZED));
        assertThat(newConnectionData1.isActive(), is(true));
        assertThat(newConnectionData1.getAdditionalInfo(), is("info"));

        assertThat(newConnectionData2.getId(), is(2));

        assertThat(repo.queryAll(), hasItems(newConnectionData1, newConnectionData2));

    }

    @Test
    public void remove() throws Exception {

        final InMemoryNePhysicalConnectionRepository repo = new InMemoryNePhysicalConnectionRepository();

        final NePhysicalConnectionData newConnectionData = repo.insert(
                new NePhysicalConnectionInitialData(),
                NE_ID,
                CHANNEL_INSTANCE_ID);

        assertThat(repo.queryAll(), hasItem(newConnectionData));

        repo.remove(newConnectionData.getId());

        assertThat(repo.queryAll(), not(hasItem(newConnectionData)));
    }

    @Test
    public void remove_unknownId_ignores() throws Exception {

        final InMemoryNePhysicalConnectionRepository repo = new InMemoryNePhysicalConnectionRepository();

        repo.remove(9876);
    }

}
