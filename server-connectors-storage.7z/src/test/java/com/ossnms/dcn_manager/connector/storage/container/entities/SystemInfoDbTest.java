package com.ossnms.dcn_manager.connector.storage.container.entities;

import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class SystemInfoDbTest {
    private static final int VERSION = 100;
    private static final int ID_1 = 1;
    private static final String NAME_1 = "name1";
    private static final String NAME_2 = "name2";

    private SystemInfoDb systemInfoDb;

    @Before public void setUp() throws Exception {
        systemInfoDb = new SystemInfoDb(ID_1, VERSION, NAME_1);
        systemInfoDb.setContainerUserText(Optional.of("text"));
        systemInfoDb.setContainerDescription(Optional.of("desc"));
    }

    @Test public void build() throws Exception {
        final SystemInfo info = systemInfoDb.build();

        assertThat(info.getId(), is(systemInfoDb.getContainerId()));
        assertThat(info.getDescription(), is(systemInfoDb.getContainerDescription()));
        assertThat(info.getName(), is(systemInfoDb.getContainerName()));
        assertThat(info.getParentId(), is(systemInfoDb.getParentId()));
        assertThat(info.getUserText(), is(systemInfoDb.getContainerUserText()));
        assertThat(info.getVersion(), is(systemInfoDb.getVersion()));
    }

    @Test public void testEquals() throws Exception {
        SystemInfoDb infoDb = new SystemInfoDb(ID_1, VERSION, NAME_1);

        assertEquals(infoDb, systemInfoDb);
    }

    @Test public void testEquals_false() throws Exception {
        SystemInfoDb infoDb = new SystemInfoDb(2, VERSION, NAME_2);

        assertNotEquals(infoDb, systemInfoDb);
    }

    @Test public void testEquals_false_by_name() throws Exception {
        SystemInfoDb infoDb = new SystemInfoDb(ID_1, VERSION, NAME_2);

        assertNotEquals(infoDb, systemInfoDb);
    }

    @Test public void testEquals_false_by_id() throws Exception {
        SystemInfoDb infoDb = new SystemInfoDb(2, VERSION, NAME_1);

        assertNotEquals(infoDb, systemInfoDb);
    }

    @Test public void testEquals_false_by_version() throws Exception {
        SystemInfoDb infoDb = new SystemInfoDb(ID_1, 3, NAME_1);

        assertNotEquals(infoDb, systemInfoDb);
    }

    @Test public void testHasCode() throws Exception {
        SystemInfoDb infoDb = new SystemInfoDb(ID_1, VERSION, NAME_1);

        assertEquals(infoDb.hashCode(), systemInfoDb.hashCode());

        infoDb.setContainerId(2);
        assertNotEquals(infoDb.hashCode(), systemInfoDb.hashCode());

        infoDb.setContainerName(NAME_2);
        assertNotEquals(infoDb.hashCode(), systemInfoDb.hashCode());

        infoDb.setVersion(3);
        assertNotEquals(infoDb.hashCode(), systemInfoDb.hashCode());
    }
}