package com.ossnms.dcn_manager.connector.jpa;

import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SuppressWarnings("unchecked")
public class JpaAggregateEntityRepositoryTest {

    private static final String FETCH_ALL_QUERY = "fetch_all_query";

    private final class JpaAggregateEntityRepositoryStub
            extends JpaAggregateEntityRepository<Object, Object> {

        @Override
        protected CloseableEntityTransaction getTransaction() {
            return new CloseableEntityTransaction(em, et);
        }

        @Override
        protected Optional<Object> fetchEntity(Object dbEntity) {
            return Optional.ofNullable(dbEntity);
        }

        @Override
        protected Class<Object> getDbClass() {
            return Object.class;
        }

        @Override
        protected String getFetchAllQueryName() {
            return FETCH_ALL_QUERY;
        }

    }

    private EntityTransaction et;
    private EntityManager em;
    private JpaAggregateEntityRepositoryStub aer;

    @Before
    public void setUp() {
        et = mock(EntityTransaction.class);
        em = mock(EntityManager.class);

        aer = new JpaAggregateEntityRepositoryStub();
    }

    @Test(expected = RepositoryException.class)
    public void testQuery_exception_propagatesIt() throws RepositoryException {

        when(em.find(any(Class.class), any())).thenThrow(new PersistenceException());

        aer.query(56);
    }

    @Test
    public void testQuery_nothingFound() throws RepositoryException {

        when(em.find(Object.class, 56)).thenReturn(null);

        final Optional<Object> result = aer.query(56);

        assertThat(result, is(absent()));
    }

    @Test
    public void testQuery() throws RepositoryException {
        final Object dbRow = new Object();

        when(em.find(Object.class, 56)).thenReturn(dbRow);

        final Optional<Object> result = aer.query(56);

        assertThat(result, hasValue(dbRow));
    }

    @Test(expected = RepositoryException.class)
    public void testQueryAll_exception_propagatesIt() throws RepositoryException {

        when(em.createNamedQuery(anyString(), any(Class.class))).thenThrow(new PersistenceException());

        aer.queryAll();
    }

    @Test
    public void testQueryAll_nothingFound() throws RepositoryException {
        final TypedQuery<Object> query = mock(TypedQuery.class);

        when(query.getResultList()).thenReturn(Collections.emptyList());
        when(em.createNamedQuery(FETCH_ALL_QUERY, Object.class)).thenReturn(query);
        when(query.setHint(anyString(), anyInt())).thenReturn(query);

        final Iterable<Object> all = aer.queryAll();

        assertThat(all, is(emptyIterable()));
    }

    @Test
    public void testQueryAll_absentEntities_ignored() throws RepositoryException {
        final TypedQuery<Object> query = mock(TypedQuery.class);
        final Object singleResult = new Object();

        // we'll use a null result, which should never happen, to cause our mock to return an absent Optional.
        when(query.getResultList()).thenReturn(Arrays.asList(null, singleResult));
        when(em.createNamedQuery(FETCH_ALL_QUERY, Object.class)).thenReturn(query);
        when(query.setHint(anyString(), anyInt())).thenReturn(query);

        final Iterable<Object> all = aer.queryAll();

        assertThat(all, is(iterableWithSize(1)));
        assertThat(all, hasItem(singleResult));
    }

    @Test
    public void testQueryAll() throws RepositoryException {
        final TypedQuery<Object> query = mock(TypedQuery.class);
        final Object singleResult = new Object();

        when(query.getResultList()).thenReturn(Collections.singletonList(singleResult));
        when(em.createNamedQuery(FETCH_ALL_QUERY, Object.class)).thenReturn(query);
        when(query.setHint(anyString(), anyInt())).thenReturn(query);

        final Iterable<Object> all = aer.queryAll();

        assertThat(all, hasItem(singleResult));
    }
}
