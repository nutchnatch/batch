package com.ossnms.dcn_manager.connector.storage.domain;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.PassthroughAnswer;
import com.ossnms.dcn_manager.connector.storage.JpaRepositoryTestBase;
import com.ossnms.dcn_manager.connector.storage.domain.entities.DomainInfoDb;
import com.ossnms.dcn_manager.connector.storage.domain.entities.DomainNeMembershipDb;
import com.ossnms.dcn_manager.core.entities.domain.DomainCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.utils.Consumer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.test.util.OtherMatchers;
import org.hibernate.exception.ConstraintViolationException;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityExistsException;
import javax.persistence.NoResultException;
import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class NetworkDomainRepositoryTest extends JpaRepositoryTestBase {

    private static final int DOMAIN_ID = 14;

    private NetworkDomainRepository repo;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        repo = new NetworkDomainRepository() {

            @Override
            protected CloseableEntityTransaction getTransaction() {
                return tx;
            }

        };
    }

    @Test(expected=UnsupportedOperationException.class)
    public void create() throws Exception {
        repo.create(new DomainCreationDescriptor("name", true));
    }

    @Test
    public void tryCreate() throws Exception {
        final Optional<DomainInfoData> domain = repo.tryCreate(new DomainCreationDescriptor("name"));
        assertThat(domain, hasValue(new DomainInfoData(0, 0, "name")));
    }

    @Test
    public void tryCreate_constraintViolated_returnsAbsent() throws Exception {

        doThrow(new PersistenceException(new ConstraintViolationException(null, null, null))).when(tx).close();

        final Optional<DomainInfoData> domain = repo.tryCreate(new DomainCreationDescriptor("name"));
        assertThat(domain, is(absent()));
    }

    @Test(expected=RepositoryException.class)
    public void tryCreate_error_throws() throws Exception {

        doThrow(new PersistenceException()).when(tx).close();

        repo.tryCreate(new DomainCreationDescriptor("name"));
    }

    @Test(expected=RepositoryException.class)
    public void delete_domainNotEmpty_throws() throws Exception {

        final DomainInfoDb db = new DomainInfoDb();
        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(db);
        mockQuery("DomainInfoDb.SELECT_DOMAIN_NES", Integer.class, ImmutableList.of(15));

        repo.delete(new DomainDeletionDescriptor(DOMAIN_ID));
    }

    @Test(expected=RepositoryException.class)
    public void delete_error_throws() throws Exception {

        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenThrow(new PersistenceException());

        repo.delete(new DomainDeletionDescriptor(DOMAIN_ID));
    }

    @Test
    public void delete_domainNotFound_ignores() throws Exception {

        repo.delete(new DomainDeletionDescriptor(DOMAIN_ID));

        verify(entityManager, never()).remove(isA(DomainInfoDb.class));
    }

    @Test
    public void delete() throws Exception {

        final DomainInfoDb db = new DomainInfoDb();
        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(db);
        mockQuery("DomainInfoDb.SELECT_DOMAIN_NES", Integer.class, ImmutableList.of());

        repo.delete(new DomainDeletionDescriptor(DOMAIN_ID));

        verify(entityManager).remove(db);
    }

    @Test
    public void tryAddNe_domainHasDisappeared_returnsFalse() throws Exception {
        boolean result;

        result = repo.tryAddNaturalNE(DOMAIN_ID, 15);
        assertThat(result, is(false));

        result = repo.tryAddTransitiveNE(DOMAIN_ID, 15);
        assertThat(result, is(false));
    }

    @Test
    public void tryAddNe_membershipAlreadyExists_returnFalse() throws Exception {

        final DomainInfoDb db = new DomainInfoDb();
        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(db);

        doThrow(new PersistenceException(new EntityExistsException())).when(tx).close();

        boolean result;

        result = repo.tryAddNaturalNE(DOMAIN_ID, 15);
        assertThat(result, is(false));

        result = repo.tryAddTransitiveNE(DOMAIN_ID, 15);
        assertThat(result, is(false));
    }

    @Test(expected=RepositoryException.class)
    public void tryAddNaturalNe_otherPersistenceException_throws() throws Exception {

        final DomainInfoDb db = new DomainInfoDb();
        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(db);

        doThrow(new PersistenceException()).when(tx).close();

        repo.tryAddNaturalNE(DOMAIN_ID, 15);
    }

    @Test(expected=RepositoryException.class)
    public void tryAddTransitiveNe_otherPersistenceException_throws() throws Exception {

        final DomainInfoDb db = new DomainInfoDb();
        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(db);

        doThrow(new PersistenceException()).when(tx).close();

        repo.tryAddTransitiveNE(DOMAIN_ID, 15);
    }

    @Test
    public void tryAddNe_returnsTrue() throws Exception {

        final DomainInfoDb db = new DomainInfoDb();
        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(db);
        mockQuery("DomainInfoDb.SELECT_DOMAIN_NES", Integer.class, ImmutableList.of());

        boolean result;

        result = repo.tryAddNaturalNE(DOMAIN_ID, 15);
        assertThat(result, is(true));

        result = repo.tryAddTransitiveNE(DOMAIN_ID, 15);
        assertThat(result, is(true));

        verify(entityManager, times(2)).persist(isA(DomainNeMembershipDb.class));
    }

    @Test
    public void tryRemoveNe_membershipDoesNotExist_returnsFalse() throws Exception {

        final DomainInfoDb db = new DomainInfoDb();
        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(db);

        final TypedQuery<DomainNeMembershipDb> query =
            mockQuery("DomainInfoDb.SELECT_NE_MEMBERSHIP", DomainNeMembershipDb.class, null);
        when(query.getSingleResult()).thenThrow(new NoResultException());

        boolean result;

        result = repo.tryRemoveNaturalNE(DOMAIN_ID, 15);
        assertThat(result, is(false));

        result = repo.tryRemoveTransitiveNE(DOMAIN_ID, 15);
        assertThat(result, is(false));
    }

    @Test(expected=RepositoryException.class)
    public void tryRemoveNaturalNe_otherPersistenceException_throws() throws Exception {

        final DomainInfoDb db = new DomainInfoDb();
        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(db);

        final DomainNeMembershipDb neMembershipDb = new DomainNeMembershipDb(db, 15, null /* irrelevant for this use case */);
        mockSingleResultQuery("DomainInfoDb.SELECT_NE_MEMBERSHIP", DomainNeMembershipDb.class, neMembershipDb);

        doThrow(new PersistenceException()).when(tx).close();

        repo.tryRemoveNaturalNE(DOMAIN_ID, 15);
    }

    @Test(expected=RepositoryException.class)
    public void tryRemoveTransitiveNe_otherPersistenceException_throws() throws Exception {

        final DomainInfoDb db = new DomainInfoDb();
        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(db);

        final DomainNeMembershipDb neMembershipDb = new DomainNeMembershipDb(db, 15, null /* irrelevant for this use case */);
        mockSingleResultQuery("DomainInfoDb.SELECT_NE_MEMBERSHIP", DomainNeMembershipDb.class, neMembershipDb);

        doThrow(new PersistenceException()).when(tx).close();

        repo.tryRemoveTransitiveNE(DOMAIN_ID, 15);
    }

    @Test
    public void tryRemoveNe_returnsTrue() throws Exception {

        final DomainInfoDb db = new DomainInfoDb();
        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(db);

        final DomainNeMembershipDb neMembershipDb = new DomainNeMembershipDb(db, 15, null /* irrelevant for this use case */);
        mockSingleResultQuery("DomainInfoDb.SELECT_NE_MEMBERSHIP", DomainNeMembershipDb.class, neMembershipDb);

        boolean result;

        result = repo.tryRemoveNaturalNE(DOMAIN_ID, 15);
        assertThat(result, is(true));

        result = repo.tryRemoveTransitiveNE(DOMAIN_ID, 15);
        assertThat(result, is(true));

        verify(entityManager, times(2)).remove(neMembershipDb);
    }

    private static class MutationConsumer<T> implements Consumer<T> {

        private boolean called;

        @Override
        public void accept(T in) {
            called = true;
        }

    }

    @Test
    public void tryUpdate() throws Exception {
        final MutationConsumer<DomainInfoMutationDescriptor> consumer = new MutationConsumer<>();
        final DomainInfoData originalData = new DomainInfoData(DOMAIN_ID, 1, "name", false);
        final DomainInfoMutationDescriptor mutation = new DomainInfoMutationDescriptor(originalData)
            .setAutomaticNeActivationPermitted(true)
            .whenApplied(consumer);

        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(new DomainInfoDb(DOMAIN_ID, 1, "name", false));
        when(entityManager.merge(any())).then(new PassthroughAnswer<>());

        final Optional<DomainInfoData> updated = repo.tryUpdate(mutation);
        assertThat(updated, is(OtherMatchers.present()));

        assertThat(consumer.called, is(true));

        final DomainInfoData newData = updated.get();
        assertThat(newData, not(is(originalData)));
        assertThat(newData.isAutomaticNeActivationPermitted(), is(true));
    }

    @Test
    public void tryUpdate_originalNotFound_returnsAbsent() throws Exception {
        final DomainInfoData originalData = new DomainInfoData(DOMAIN_ID, 1, "name", false);
        final DomainInfoMutationDescriptor mutation = new DomainInfoMutationDescriptor(originalData)
            .setAutomaticNeActivationPermitted(true);

        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(null); // just for expressiveness

        final Optional<DomainInfoData> updated = repo.tryUpdate(mutation);
        assertThat(updated, is(absent()));

        verify(entityManager, never()).merge(any());
    }

    @Test
    public void tryUpdate_repoError_throws() throws Exception {
        final MutationConsumer<DomainInfoMutationDescriptor> consumer = new MutationConsumer<>();
        final DomainInfoData originalData = new DomainInfoData(DOMAIN_ID, 1, "name", false);
        final DomainInfoMutationDescriptor mutation = new DomainInfoMutationDescriptor(originalData)
            .setAutomaticNeActivationPermitted(true)
            .whenApplied(consumer);

        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(new DomainInfoDb(DOMAIN_ID, 1, "name", false));

        doThrow(new PersistenceException()).when(tx).close();

        try {
            repo.tryUpdate(mutation);
            fail("Exception not propagated.");
        } catch (final RepositoryException e) {
            // ok
        }

        assertThat(consumer.called, is(false));
    }

    @Test
    public void tryUpdate_concurrentModification_returnsAbsent() throws Exception {
        final MutationConsumer<DomainInfoMutationDescriptor> consumer = new MutationConsumer<>();
        final DomainInfoData originalData = new DomainInfoData(DOMAIN_ID, 1, "name", false);
        final DomainInfoMutationDescriptor mutation = new DomainInfoMutationDescriptor(originalData)
            .setAutomaticNeActivationPermitted(true)
            .whenApplied(consumer);

        when(entityManager.find(DomainInfoDb.class, DOMAIN_ID)).thenReturn(new DomainInfoDb(DOMAIN_ID, 1, "name", false));

        doThrow(new OptimisticLockException()).when(tx).close();

        final Optional<DomainInfoData> updated = repo.tryUpdate(mutation);
        assertThat(updated, is(absent()));

        assertThat(consumer.called, is(false));
    }
}
