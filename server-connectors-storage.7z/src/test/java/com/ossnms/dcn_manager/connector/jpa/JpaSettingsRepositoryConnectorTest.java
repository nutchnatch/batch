package com.ossnms.dcn_manager.connector.jpa;

import com.ossnms.dcn_manager.connector.storage.settings.JpaSettingsRepositoryConnector;
import com.ossnms.dcn_manager.connector.storage.settings.entities.GlobalSettingsDb;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettingsMutationDescriptor;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class JpaSettingsRepositoryConnectorTest {

    private EntityManager entityManager;
    private CloseableEntityTransaction tx;

    private JpaSettingsRepositoryConnectorStub repo;

    private final class JpaSettingsRepositoryConnectorStub
        extends JpaSettingsRepositoryConnector {

        @Override
        protected CloseableEntityTransaction getTransaction() {
            return tx;
        }

        @Override
        public boolean areStandbyConnectionsAllowed() { return false; }

        @Override
        protected GlobalSettingsDb injectStartupLimit(GlobalSettingsDb globalSettingsDb) {
            return globalSettingsDb;
        }
    }

    @Before
    public void setUp() {
        entityManager = mock(EntityManager.class);
        tx = mock(CloseableEntityTransaction.class);

        when(tx.getEntityManager()).thenReturn(entityManager);

        repo = new JpaSettingsRepositoryConnectorStub();
    }

    @Test(expected=IllegalStateException.class)
    public void notStarted_throws() throws Exception {
        repo.getSettings();
    }

    @Test
    public void start_withDefaults() throws Exception {
        final GlobalSettings defaultInstance = GlobalSettings.build().toGlobalSettings(6, 0);

        repo.start();

        assertThat(repo.getSettings(), is(defaultInstance));
    }

    @Test
    public void start_withExisting() throws Exception {
        final GlobalSettings existingInstance = GlobalSettings.build()
                .setChannelRetries(0)
                .setMediatorRetries(9876)
                .toGlobalSettings(6, 0);

        when(entityManager.find(eq(GlobalSettingsDb.class), anyInt()))
            .thenReturn(new GlobalSettingsDb(existingInstance));

        repo.start();

        assertThat(repo.getSettings(), is(existingInstance));
    }

    @Test(expected=RepositoryException.class)
    public void start_withError_throws() throws Exception {
        when(entityManager.find(eq(GlobalSettingsDb.class), anyInt()))
            .thenThrow(new PersistenceException());

        repo.start();
    }

    @Test
    public void updateSettings() throws Exception {

        repo.start();

        final GlobalSettingsMutationDescriptor mutation = new GlobalSettingsMutationDescriptor(repo.getSettings())
            .setChannelRetries(8765);

        when(entityManager.merge(any())).then(invocation -> invocation.getArguments()[0]);

        final Optional<GlobalSettings> updatedSettings = repo.tryUpdateSettings(mutation);

        assertThat(updatedSettings, is(present()));
        assertThat(updatedSettings.get().getChannelRetries(), is(8765));
        assertThat(updatedSettings.get(), is(repo.getSettings()));
    }

    @Test
    public void updateSettings_concurrentModification_doesNotChange() throws Exception {

        repo.start();

        final GlobalSettings originalSettings = repo.getSettings();

        final GlobalSettingsMutationDescriptor mutation = new GlobalSettingsMutationDescriptor(originalSettings)
            .setChannelRetries(8765);

        when(entityManager.merge(any(GlobalSettingsDb.class))).thenThrow(new OptimisticLockException());

        final Optional<GlobalSettings> updatedSettings = repo.tryUpdateSettings(mutation);

        assertThat(updatedSettings, is(absent()));
        assertThat(repo.getSettings(), is(originalSettings));
    }

    @Test(expected=RepositoryException.class)
    public void updateSettings_repoError_throws() throws Exception {

        repo.start();

        final GlobalSettingsMutationDescriptor mutation = new GlobalSettingsMutationDescriptor(repo.getSettings())
                .setChannelRetries(8765);

        when(entityManager.merge(any(GlobalSettingsDb.class))).thenThrow(new PersistenceException());

        repo.tryUpdateSettings(mutation);
    }
}
