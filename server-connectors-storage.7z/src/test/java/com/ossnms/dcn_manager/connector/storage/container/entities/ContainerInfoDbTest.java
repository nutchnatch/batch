package com.ossnms.dcn_manager.connector.storage.container.entities;

import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class ContainerInfoDbTest {
    private static final int VERSION = 100;
    private static final int ID_1 = 1;
    private static final int PARENT_ID = 2;
    private static final String NAME_1 = "name1";
    private static final String NAME_2 = "name2";

    private ContainerInfoDb containerInfoDb;

    @Before public void setUp() throws Exception {
        containerInfoDb = new ContainerInfoDb(ID_1, VERSION, Optional.of(PARENT_ID), NAME_1);
        containerInfoDb.setContainerUserText(Optional.of("text"));
        containerInfoDb.setContainerDescription(Optional.of("desc"));
    }

    @Test public void build() throws Exception {
        final ContainerInfo containerInfo = containerInfoDb.build();

        assertThat(containerInfo.getId(), is(containerInfoDb.getContainerId()));
        assertThat(containerInfo.getDescription(), is(containerInfoDb.getContainerDescription()));
        assertThat(containerInfo.getName(), is(containerInfoDb.getContainerName()));
        assertThat(containerInfo.getParentId(), is(containerInfoDb.getParentId()));
        assertThat(containerInfo.getUserText(), is(containerInfoDb.getContainerUserText()));
        assertThat(containerInfo.getVersion(), is(containerInfoDb.getVersion()));
    }

    @Test public void testEquals() throws Exception {
        ContainerInfoDb infoDb = new ContainerInfoDb(ID_1, VERSION, Optional.of(PARENT_ID), NAME_1);

        assertEquals(infoDb, containerInfoDb);
    }

    @Test public void testEquals_diff_parent() throws Exception {
        ContainerInfoDb infoDb = new ContainerInfoDb(ID_1, VERSION, Optional.of(3), NAME_1);

        assertEquals(infoDb, containerInfoDb);
    }

    @Test public void testEquals_false() throws Exception {
        ContainerInfoDb infoDb = new ContainerInfoDb(2, VERSION, Optional.of(PARENT_ID), NAME_2);

        assertNotEquals(infoDb, containerInfoDb);
    }

    @Test public void testEquals_false_by_name() throws Exception {
        ContainerInfoDb infoDb = new ContainerInfoDb(ID_1, VERSION, Optional.of(PARENT_ID), NAME_2);

        assertNotEquals(infoDb, containerInfoDb);
    }

    @Test public void testEquals_false_by_id() throws Exception {
        ContainerInfoDb infoDb = new ContainerInfoDb(2, VERSION, Optional.of(PARENT_ID), NAME_1);

        assertNotEquals(infoDb, containerInfoDb);
    }

    @Test public void testEquals_false_by_version() throws Exception {
        ContainerInfoDb infoDb = new ContainerInfoDb(ID_1, 3, Optional.of(PARENT_ID), NAME_1);

        assertNotEquals(infoDb, containerInfoDb);
    }

    @Test public void testHasCode() throws Exception {
        ContainerInfoDb infoDb = new ContainerInfoDb(ID_1, VERSION, Optional.of(PARENT_ID), NAME_1);

        assertEquals(infoDb.hashCode(), containerInfoDb.hashCode());

        infoDb.setContainerId(2);
        assertNotEquals(infoDb.hashCode(), containerInfoDb.hashCode());

        infoDb.setContainerName(NAME_2);
        assertNotEquals(infoDb.hashCode(), containerInfoDb.hashCode());

        infoDb.setVersion(3);
        assertNotEquals(infoDb.hashCode(), containerInfoDb.hashCode());
    }
}