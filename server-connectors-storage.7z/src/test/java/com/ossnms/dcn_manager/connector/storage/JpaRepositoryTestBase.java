package com.ossnms.dcn_manager.connector.storage;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import org.junit.Before;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;

public abstract class JpaRepositoryTestBase {

    protected EntityManager entityManager;
    protected CloseableEntityTransaction tx;

    @Before
    public void setUp() throws Exception {

        entityManager = mock(EntityManager.class);
        tx = mock(CloseableEntityTransaction.class);

        when(tx.getEntityManager()).thenReturn(entityManager);

        when(entityManager.merge(any())).then(new Answer<Object>() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                return invocation.getArguments()[0];
            }
        });

    }

    protected <T> TypedQuery<T> mockQuery(String queryName, Class<T> resultType, List<T> resultList) {
        @SuppressWarnings("unchecked") final TypedQuery<T> query = mock(TypedQuery.class);
        when(query.setParameter(anyString(), any())).thenReturn(query);
        when(query.getResultList()).thenReturn(resultList);
        when(entityManager.createNamedQuery(queryName, resultType)).thenReturn(query);
        return query;
    }

    protected <T> TypedQuery<T> mockSingleResultQuery(String queryName, Class<T> resultType, T singleResult) {
        @SuppressWarnings("unchecked") final TypedQuery<T> query = mock(TypedQuery.class);
        when(query.setParameter(anyString(), any())).thenReturn(query);
        when(query.getSingleResult()).thenReturn(singleResult);
        when(entityManager.createNamedQuery(queryName, resultType)).thenReturn(query);
        return query;
    }

    protected <T> TypedQuery<T> mockSingleResultQuery(String queryName, Class<T> resultType) {
        @SuppressWarnings("unchecked") final TypedQuery<T> query = mock(TypedQuery.class);
        when(query.setParameter(anyString(), any())).thenReturn(query);
        when(query.getSingleResult()).thenThrow(new NoResultException());
        when(entityManager.createNamedQuery(queryName, resultType)).thenReturn(query);
        return query;
    }

}