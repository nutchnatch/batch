package com.ossnms.dcn_manager.connector.storage.domain.entities;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.dcn_manager.connector.storage.domain.entities.DomainInfoDb;
import com.ossnms.dcn_manager.connector.storage.domain.entities.DomainNeKey;
import com.ossnms.dcn_manager.connector.storage.domain.entities.Membership;

public class DomainNeKeyTest {

    @Test
    public void testEquals() {
        final DomainInfoDb info1 = new DomainInfoDb(1, 2, "name", true);
        final DomainInfoDb info2 = new DomainInfoDb(2, 3, "name2", false);

        final DomainNeKey key = new DomainNeKey(info1, 1, Membership.NATURAL);

        assertThat(key.equals(key), is(true));
        assertThat(key.equals(null), is(false));
        assertThat(key.equals("blah"), is(false));

        assertThat(key, is(new DomainNeKey(info1, 1, Membership.NATURAL)));
        assertThat(key, not(is(new DomainNeKey(info2, 1, Membership.NATURAL))));
        assertThat(key, not(is(new DomainNeKey(info1, 10, Membership.NATURAL))));
        assertThat(key, not(is(new DomainNeKey(info1, 1, Membership.TRANSITIVE))));
    }

    @Test
    public void testHashCode() {
        final DomainInfoDb info1 = new DomainInfoDb(1, 2, "name", true);
        final DomainInfoDb info2 = new DomainInfoDb(2, 3, "name2", false);

        final DomainNeKey key = new DomainNeKey(info1, 1, Membership.NATURAL);

        assertThat(key.hashCode(), is(new DomainNeKey(info1, 1, Membership.NATURAL).hashCode()));
        assertThat(key.hashCode(), not(is(new DomainNeKey(info2, 1, Membership.NATURAL).hashCode())));
        assertThat(key.hashCode(), not(is(new DomainNeKey(info1, 10, Membership.NATURAL).hashCode())));
        assertThat(key.hashCode(), not(is(new DomainNeKey(info1, 1, Membership.TRANSITIVE).hashCode())));
    }

}
