package com.ossnms.dcn_manager.connector.storage.container.entities;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class ContainerSystemKeyTest {
    private static final int ID_1 = 1;
    private static final int ID_2 = 2;

    private ContainerSystemKey systemKey;
    private ContainerInfoDb containerInfoDb;

    @Before public void setUp() throws Exception {
        containerInfoDb = new ContainerInfoDb();
        containerInfoDb.setContainerId(ID_1);
        systemKey = new ContainerSystemKey(containerInfoDb, ID_2);
    }

    @Test public void testEquals() throws Exception {
        ContainerSystemKey key = new ContainerSystemKey(containerInfoDb, ID_2);

        assertEquals(key, systemKey);
    }

    @Test public void testNotEquals_container() throws Exception {
        ContainerInfoDb containerInfoDiff = new ContainerInfoDb();
        containerInfoDiff.setContainerId(ID_2);
        ContainerSystemKey key = new ContainerSystemKey(containerInfoDiff, ID_2);

        assertNotEquals(key, systemKey);
    }

    @Test public void testNotEquals_neId() throws Exception {
        ContainerSystemKey key = new ContainerSystemKey(containerInfoDb, ID_1);

        assertNotEquals(key, systemKey);
    }

    @Test public void testHashcode() throws Exception {
        ContainerSystemKey key = new ContainerSystemKey(containerInfoDb, ID_2);

        assertEquals(key.hashCode(), systemKey.hashCode());

        ContainerInfoDb containerInfoDiff = new ContainerInfoDb();
        containerInfoDiff.setContainerId(ID_2);
        key = new ContainerSystemKey(containerInfoDiff, ID_2);
        assertNotEquals(key, systemKey);

        key = new ContainerSystemKey(containerInfoDiff, 4);
        assertNotEquals(key, systemKey);
    }
}