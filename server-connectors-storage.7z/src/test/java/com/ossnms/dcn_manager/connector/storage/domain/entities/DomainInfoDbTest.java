package com.ossnms.dcn_manager.connector.storage.domain.entities;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.dcn_manager.connector.storage.domain.entities.DomainInfoDb;

public class DomainInfoDbTest {

    @Test
    public void testEquals() {
        final DomainInfoDb info1 = new DomainInfoDb(1, 2, "name", true);
        final DomainInfoDb info2 = new DomainInfoDb(2, 3, "name2", false);

        assertThat(info1.equals(info1), is(true));
        assertThat(info1.equals(null), is(false));
        assertThat(info1.equals("blah"), is(false));

        assertThat(info1, is(new DomainInfoDb(1, 2, "name", true)));
        assertThat(info1, not(is(new DomainInfoDb(10, 2, "name", true))));
        assertThat(info1, not(is(new DomainInfoDb(1, 20, "name", true))));
        assertThat(info1, not(is(new DomainInfoDb(1, 2, "XnameX", true))));
        assertThat(info1, not(is(new DomainInfoDb(1, 2, "name", false))));
        assertThat(info1, not(is(info2)));
    }

    @Test
    public void testHashCode() {
        final DomainInfoDb info1 = new DomainInfoDb(1, 2, "name", true);
        final DomainInfoDb info2 = new DomainInfoDb(2, 3, "name2", false);

        assertThat(info1.hashCode(), is(new DomainInfoDb(1, 2, "name", true).hashCode()));
        assertThat(info1.hashCode(), not(is(new DomainInfoDb(10, 2, "name", true).hashCode())));
        assertThat(info1.hashCode(), not(is(new DomainInfoDb(1, 20, "name", true).hashCode())));
        assertThat(info1.hashCode(), not(is(new DomainInfoDb(1, 2, "XnameX", true).hashCode())));
        assertThat(info1.hashCode(), not(is(new DomainInfoDb(1, 2, "name", false).hashCode())));
        assertThat(info1.hashCode(), not(is(info2.hashCode())));
    }

}
