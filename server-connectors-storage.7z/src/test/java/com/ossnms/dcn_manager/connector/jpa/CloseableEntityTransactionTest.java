package com.ossnms.dcn_manager.connector.jpa;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isA;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;

public class CloseableEntityTransactionTest {

    private EntityTransaction et;
    private EntityManager em;
    private CloseableEntityTransaction cet;

    @Before
    public void setUp() {
        et = mock(EntityTransaction.class);
        em = mock(EntityManager.class);

        cet = new CloseableEntityTransaction(em, et);
    }

    @Test
    public void isCloseable() {
        assertThat(cet, isA(AutoCloseable.class));
    }

    @Test
    public void close_commit() {
        when(et.getRollbackOnly()).thenReturn(false);

        cet.close();

        verify(et).commit();
        verify(et, never()).rollback();
        verify(em, never()).close();
    }

    @Test
    public void close_rollback() {
        when(et.getRollbackOnly()).thenReturn(true);

        cet.close();

        verify(et).rollback();
        verify(et, never()).commit();
        verify(em, never()).close();
    }

    @Test
    public void testGetEntityManager() {
        assertThat(cet.getEntityManager(), is(em));
    }

}
