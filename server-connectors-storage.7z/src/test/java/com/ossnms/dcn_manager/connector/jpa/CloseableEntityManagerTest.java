package com.ossnms.dcn_manager.connector.jpa;

import static org.hamcrest.Matchers.isA;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import javax.persistence.EntityManager;

import org.junit.Test;

import com.ossnms.dcn_manager.connector.jpa.CloseableEntityManager;

public class CloseableEntityManagerTest {

    @Test
    public void isCloseable() {
        final EntityManager em = mock(EntityManager.class);
        final CloseableEntityManager cem = new CloseableEntityManager(em);

        assertThat(cem, isA(AutoCloseable.class));

        cem.close();
        verify(em).close();
    }

}
