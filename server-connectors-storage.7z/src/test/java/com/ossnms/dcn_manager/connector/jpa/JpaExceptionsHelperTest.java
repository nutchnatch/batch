package com.ossnms.dcn_manager.connector.jpa;

import static com.ossnms.dcn_manager.connector.jpa.JpaExceptionsHelper.tryFindInChain;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;
import javax.persistence.RollbackException;

import org.junit.Test;

public class JpaExceptionsHelperTest {

    @Test
    public void testTryFindInChain() throws Exception {

        final Throwable cause = new OptimisticLockException();

        assertThat(tryFindInChain(new PersistenceException(), OptimisticLockException.class), is(absent()));
        assertThat(tryFindInChain(new PersistenceException(new RollbackException()), OptimisticLockException.class), is(absent()));

        assertThat(tryFindInChain(cause, OptimisticLockException.class), hasValue(cause));
        assertThat(tryFindInChain(new PersistenceException(cause), OptimisticLockException.class), hasValue(cause));
        assertThat(tryFindInChain(new PersistenceException(new RollbackException(cause)), OptimisticLockException.class), hasValue(cause));
    }
}
