package com.ossnms.dcn_manager.connector.storage.channel;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelConnectionInitialData;

public class InMemoryChannelPhysicalConnectionRepositoryTest {

    private static final int MEDIATOR_INSTANCE_ID = 30;
    private static final int CHANNEL_ID = 20;

    @Test
    public void insert() throws Exception {

        final InMemoryChannelPhysicalConnectionRepository repo = new InMemoryChannelPhysicalConnectionRepository();

        assertThat(repo.queryAll(), is(emptyIterable()));

        final ChannelPhysicalConnectionData newConnectionData1 = repo.insert(
            new ChannelConnectionInitialData()
                .setActivation(ActualActivationState.ACTIVE)
                .setActive(true)
                .setAdditionalInfo("info"),
            CHANNEL_ID,
            MEDIATOR_INSTANCE_ID);

        final ChannelPhysicalConnectionData newConnectionData2 = repo.insert(
            new ChannelConnectionInitialData(),
            CHANNEL_ID,
            MEDIATOR_INSTANCE_ID);

        assertThat(newConnectionData1.getId(), is(1));
        assertThat(newConnectionData1.getActualActivationState(), is(ActualActivationState.ACTIVE));
        assertThat(newConnectionData1.isActive(), is(true));
        assertThat(newConnectionData1.getAdditionalInfo(), is("info"));

        assertThat(newConnectionData2.getId(), is(2));

        assertThat(repo.queryAll(), hasItems(newConnectionData1, newConnectionData2));

    }

    @Test
    public void remove() throws Exception {

        final InMemoryChannelPhysicalConnectionRepository repo = new InMemoryChannelPhysicalConnectionRepository();

        final ChannelPhysicalConnectionData newConnectionData = repo.insert(
            new ChannelConnectionInitialData(),
            CHANNEL_ID,
            MEDIATOR_INSTANCE_ID);

        assertThat(repo.queryAll(), hasItem(newConnectionData));

        repo.remove(newConnectionData.getId());

        assertThat(repo.queryAll(), not(hasItem(newConnectionData)));
    }

    @Test
    public void remove_unknownId_ignores() throws Exception {

        final InMemoryChannelPhysicalConnectionRepository repo = new InMemoryChannelPhysicalConnectionRepository();

        repo.remove(9876);
    }

}
