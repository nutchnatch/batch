package com.ossnms.dcn_manager.connector.hibernate;

import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import org.hibernate.PropertyAccessException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.BooleanType;
import org.junit.Test;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.Matchers.arrayContaining;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isA;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class OptionalTpGroupSettingsTypeTest {

    private final OptionalTpGroupSettingsType optionalType = new OptionalTpGroupSettingsType();

    @Test
    public void testGetPropertyNames() {
        assertThat(optionalType.getPropertyNames(),
            is(arrayContaining("multipleSubgroupMembership", "subgroupsMustBeEqual", "multipleGroupMembership", "alwaysCompatible")));
    }

    @Test
    public void testGetPropertyTypes() {
        assertThat(optionalType.getPropertyTypes(),
            is(arrayContaining(BooleanType.INSTANCE, BooleanType.INSTANCE, BooleanType.INSTANCE, BooleanType.INSTANCE)));
    }

    @Test
    public void testGetPropertyValue() {

        assertThat(optionalType.getPropertyValue(null, 0), is(nullValue()));

        assertThat(optionalType.getPropertyValue(Optional.empty(), 0), is(nullValue()));

        assertThat(optionalType.getPropertyValue(Optional.of(new TpGroupSettings(false, false, false, true)), 0),
                is(Boolean.TRUE));
        assertThat(optionalType.getPropertyValue(Optional.of(new TpGroupSettings(false, false, true, false)), 1),
                is(Boolean.TRUE));
        assertThat(optionalType.getPropertyValue(Optional.of(new TpGroupSettings(false, true, false, false)), 2),
                is(Boolean.TRUE));
        assertThat(optionalType.getPropertyValue(Optional.of(new TpGroupSettings(true, false, false, false)), 3),
                is(Boolean.TRUE));
        assertThat(optionalType.getPropertyValue(Optional.of(new TpGroupSettings(false, false, false, false)), 99),
                is(nullValue()));
    }

    @Test(expected=PropertyAccessException.class)
    public void testSetPropertyValue() {
        optionalType.setPropertyValue(new TpGroupSettings(false, false, false, true), 0, true);
    }

    @Test
    public void testReturnedClass() {
        assertThat(optionalType.returnedClass(), is(equalTo((Class) Optional.class)));
    }

    @Test
    public void testNullSafeGet() throws Exception {
        final ResultSet rs = mock(ResultSet.class);
        final SessionImplementor si = mock(SessionImplementor.class);

        final Object object = optionalType.nullSafeGet(rs, new String[] { "a", "b", "c", "d" }, si, null);
        assertThat(object, isA((Class) Optional.class));
        assertThat((Optional<?>) object, is(present()));
        assertThat(((Optional<TpGroupSettings>) object).get(), isA(TpGroupSettings.class));

        verify(rs).getBoolean("a");
        verify(rs).getBoolean("b");
        verify(rs).getBoolean("c");
        verify(rs).getBoolean("d");
    }

    @Test
    public void testNullSafeSet() throws Exception {
        final SessionImplementor si = mock(SessionImplementor.class);
        final PreparedStatement ps = mock(PreparedStatement.class);

        optionalType.nullSafeSet(ps, null, 0, si);
        optionalType.nullSafeSet(ps, Optional.empty(), 0, si);
        optionalType.nullSafeSet(ps, Optional.of(new TpGroupSettings(true, true, true, true)), 100, si);

        verify(ps, times(2)).setObject(0, null);
        verify(ps, times(2)).setObject(1, null);
        verify(ps, times(2)).setObject(2, null);
        verify(ps, times(2)).setObject(3, null);

        verify(ps).setBoolean(100, true);
        verify(ps).setBoolean(101, true);
        verify(ps).setBoolean(102, true);
        verify(ps).setBoolean(103, true);
    }

    @Test
    public void testDeepCopy() {
        final TpGroupSettings settings = new TpGroupSettings(true, true, true, true);

        assertThat(optionalType.deepCopy(settings), is(settings));
    }

    @Test
    public void testIsMutable() {
        assertThat(optionalType.isMutable(), is(false));
    }

    @Test
    public void testDisassemble() {
        final SessionImplementor si = mock(SessionImplementor.class);
        final Serializable value = new TpGroupSettings(true, true, true, true);
        Object get;

        get = optionalType.disassemble(null, si);
        assertThat(get, is(nullValue()));

        get = optionalType.disassemble(Optional.empty(), si);
        assertThat(get, is(nullValue()));

        get = optionalType.disassemble(Optional.of(value), si);
        assertThat(get, is(value));
    }

    @Test
    public void testAssemble() {
        final SessionImplementor si = mock(SessionImplementor.class);
        final Serializable value = new TpGroupSettings(true, true, true, true);
        Object get;

        get = optionalType.assemble(null, si, null);
        assertThat(get, isA((Class) Optional.class));
        assertThat((Optional<?>) get, is(absent()));

        get = optionalType.assemble(value, si, null);
        assertThat(get, isA((Class) Optional.class));
        assertThat((Optional<?>) get, is(present()));
        assertThat(((Optional<Serializable>) get).get(), is(value));
    }

    @Test
    public void testReplace() {
        final SessionImplementor si = mock(SessionImplementor.class);
        final Object value = new TpGroupSettings(true, true, true, true);
        assertThat(optionalType.replace(value, null, si, null), is(value));
    }

}
