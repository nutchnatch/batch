package com.ossnms.dcn_manager.connector.storage.ne;

import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import static org.mockito.Mockito.*;

public class JpaNeSynchronizationRepositoryTest {

    private CloseableEntityTransaction tx;
    private EntityManager em;

    private JpaNeSynchronizationRepository repo;

    @Before
    public void setUp() throws Exception {

        tx = mock(CloseableEntityTransaction.class);
        em = mock(EntityManager.class);

        when(tx.getEntityManager()).thenReturn(em);

        repo = new JpaNeSynchronizationRepository(() -> tx);
    }

    @Test
    public void clearSynchronizationData() throws Exception {

        final Query query = mock(Query.class);

        when(em.createNamedQuery(anyString())).thenReturn(query);

        repo.clearAllSynchronizationData();

        verify(em).createNamedQuery("NeSynchronizationDb.CLEAR_ALL_SYNC_DATA");
        verify(query).executeUpdate();
    }

    @Test(expected = RepositoryException.class)
    public void clearSynchronizationData_error_propagates() throws Exception {

        final Query query = mock(Query.class);

        when(query.executeUpdate()).thenThrow(new PersistenceException());
        when(em.createNamedQuery(anyString())).thenReturn(query);

        repo.clearAllSynchronizationData();
    }
}