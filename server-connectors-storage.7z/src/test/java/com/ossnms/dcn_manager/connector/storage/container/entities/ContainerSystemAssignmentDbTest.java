package com.ossnms.dcn_manager.connector.storage.container.entities;

import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class ContainerSystemAssignmentDbTest {
    private static final int ID_1 = 1;
    private static final int ID_2 = 2;

    private ContainerSystemAssignmentDb containerSystemAssignmentDb;
    private ContainerInfoDb containerInfoDb;

    @Before public void setUp() throws Exception {
        containerInfoDb = new ContainerInfoDb();
        containerInfoDb.setContainerId(ID_1);

        ContainerSystemKey containerNeKey = new ContainerSystemKey(containerInfoDb, ID_2);
        containerSystemAssignmentDb = new ContainerSystemAssignmentDb(containerNeKey, AssignmentType.PRIMARY);
    }

    @Test public void testEquals() throws Exception {
        ContainerSystemKey key = new ContainerSystemKey(containerInfoDb, ID_2);
        ContainerSystemAssignmentDb assignmentDb = new ContainerSystemAssignmentDb(key, AssignmentType.PRIMARY);

        assertEquals(assignmentDb, containerSystemAssignmentDb);
    }

    @Test public void testEquals_diff_assignment() throws Exception {
        ContainerSystemKey key = new ContainerSystemKey(containerInfoDb, ID_2);
        ContainerSystemAssignmentDb assignmentDb = new ContainerSystemAssignmentDb(key, AssignmentType.LOGICAL);

        assertEquals(assignmentDb, containerSystemAssignmentDb);
    }

    @Test public void testNotEquals_container() throws Exception {
        ContainerInfoDb containerInfoDiff = new ContainerInfoDb();
        containerInfoDiff.setContainerId(ID_2);
        ContainerSystemKey key = new ContainerSystemKey(containerInfoDiff, ID_2);
        ContainerSystemAssignmentDb assignmentDb = new ContainerSystemAssignmentDb(key, AssignmentType.PRIMARY);

        assertNotEquals(assignmentDb, containerSystemAssignmentDb);
    }

    @Test public void testNotEquals_neId() throws Exception {
        ContainerSystemKey key = new ContainerSystemKey(containerInfoDb, ID_1);
        ContainerSystemAssignmentDb assignmentDb = new ContainerSystemAssignmentDb(key, AssignmentType.PRIMARY);

        assertNotEquals(assignmentDb, containerSystemAssignmentDb);
    }

    @Test public void testHashcode() throws Exception {
        ContainerSystemKey key = new ContainerSystemKey(containerInfoDb, ID_2);
        ContainerSystemAssignmentDb assignmentDb = new ContainerSystemAssignmentDb(key, AssignmentType.PRIMARY);

        assertEquals(assignmentDb.hashCode(), containerSystemAssignmentDb.hashCode());

        ContainerInfoDb containerInfoDiff = new ContainerInfoDb();
        containerInfoDiff.setContainerId(ID_2);
        key = new ContainerSystemKey(containerInfoDiff, ID_2);
        assignmentDb = new ContainerSystemAssignmentDb(key, AssignmentType.PRIMARY);
        assertNotEquals(assignmentDb.hashCode(), containerSystemAssignmentDb.hashCode());

        key = new ContainerSystemKey(containerInfoDiff, 4);
        assignmentDb = new ContainerSystemAssignmentDb(key, AssignmentType.PRIMARY);
        assertNotEquals(assignmentDb.hashCode(), containerSystemAssignmentDb.hashCode());

        key = new ContainerSystemKey(containerInfoDiff, ID_2);
        assignmentDb = new ContainerSystemAssignmentDb(key, AssignmentType.LOGICAL);
        assertNotEquals(assignmentDb.hashCode(), containerSystemAssignmentDb.hashCode());
    }
}