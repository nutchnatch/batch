package com.ossnms.dcn_manager.connector.storage.container.entities;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class ContainerNeKeyTest {
    private static final int ID_1 = 1;
    private static final int ID_2 = 2;

    private ContainerNeKey containerNeKey;
    private ContainerInfoDb containerInfoDb;

    @Before public void setUp() throws Exception {
        containerInfoDb = new ContainerInfoDb();
        containerInfoDb.setContainerId(ID_1);
        containerNeKey = new ContainerNeKey(containerInfoDb, ID_2);
    }

    @Test public void testEquals() throws Exception {
        ContainerNeKey key = new ContainerNeKey(containerInfoDb, ID_2);

        assertEquals(key, containerNeKey);
    }

    @Test public void testNotEquals_container() throws Exception {
        ContainerInfoDb containerInfoDiff = new ContainerInfoDb();
        containerInfoDiff.setContainerId(ID_2);
        ContainerNeKey key = new ContainerNeKey(containerInfoDiff, ID_2);

        assertNotEquals(key, containerNeKey);
    }

    @Test public void testNotEquals_neId() throws Exception {
        ContainerNeKey key = new ContainerNeKey(containerInfoDb, ID_1);

        assertNotEquals(key, containerNeKey);
    }

    @Test public void testHashcode() throws Exception {
        ContainerNeKey key = new ContainerNeKey(containerInfoDb, ID_2);

        assertEquals(key.hashCode(), containerNeKey.hashCode());

        ContainerInfoDb containerInfoDiff = new ContainerInfoDb();
        containerInfoDiff.setContainerId(ID_2);
        key = new ContainerNeKey(containerInfoDiff, ID_2);
        assertNotEquals(key, containerNeKey);

        key = new ContainerNeKey(containerInfoDiff, 4);
        assertNotEquals(key, containerNeKey);
    }
}