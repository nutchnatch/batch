package com.ossnms.dcn_manager.connector.storage.container.entities;

import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class ContainerNeAssignmentDbTest {
    private static final int ID_1 = 1;
    private static final int ID_2 = 2;

    private ContainerNeAssignmentDb containerNeAssignmentDb;
    private ContainerInfoDb containerInfoDb;

    @Before public void setUp() throws Exception {
        containerInfoDb = new ContainerInfoDb();
        containerInfoDb.setContainerId(ID_1);

        ContainerNeKey containerNeKey = new ContainerNeKey(containerInfoDb, ID_2);
        containerNeAssignmentDb = new ContainerNeAssignmentDb(containerNeKey, AssignmentType.PRIMARY);
    }

    @Test public void testEquals() throws Exception {
        ContainerNeKey key = new ContainerNeKey(containerInfoDb, ID_2);
        ContainerNeAssignmentDb assignmentDb = new ContainerNeAssignmentDb(key, AssignmentType.PRIMARY);

        assertEquals(assignmentDb, containerNeAssignmentDb);
    }

    @Test public void testEquals_diff_assignment() throws Exception {
        ContainerNeKey key = new ContainerNeKey(containerInfoDb, ID_2);
        ContainerNeAssignmentDb assignmentDb = new ContainerNeAssignmentDb(key, AssignmentType.LOGICAL);

        assertEquals(assignmentDb, containerNeAssignmentDb);
    }

    @Test public void testNotEquals_container() throws Exception {
        ContainerInfoDb containerInfoDiff = new ContainerInfoDb();
        containerInfoDiff.setContainerId(ID_2);

        ContainerNeKey key = new ContainerNeKey(containerInfoDiff, ID_2);
        ContainerNeAssignmentDb assignmentDb = new ContainerNeAssignmentDb(key, AssignmentType.PRIMARY);

        assertNotEquals(assignmentDb, containerNeAssignmentDb);
    }

    @Test public void testNotEquals_neId() throws Exception {
        ContainerNeKey key = new ContainerNeKey(containerInfoDb, ID_1);
        ContainerNeAssignmentDb assignmentDb = new ContainerNeAssignmentDb(key, AssignmentType.PRIMARY);

        assertNotEquals(assignmentDb, containerNeAssignmentDb);
    }

    @Test public void testHashcode() throws Exception {
        ContainerNeKey key = new ContainerNeKey(containerInfoDb, ID_2);
        ContainerNeAssignmentDb assignmentDb = new ContainerNeAssignmentDb(key, AssignmentType.PRIMARY);

        assertEquals(assignmentDb.hashCode(), containerNeAssignmentDb.hashCode());

        ContainerInfoDb containerInfoDiff = new ContainerInfoDb();
        containerInfoDiff.setContainerId(ID_2);
        key = new ContainerNeKey(containerInfoDiff, ID_2);
        assignmentDb = new ContainerNeAssignmentDb(key, AssignmentType.PRIMARY);
        assertNotEquals(assignmentDb.hashCode(), containerNeAssignmentDb.hashCode());

        key = new ContainerNeKey(containerInfoDiff, 4);
        assignmentDb = new ContainerNeAssignmentDb(key, AssignmentType.PRIMARY);
        assertNotEquals(assignmentDb.hashCode(), containerNeAssignmentDb.hashCode());

        key = new ContainerNeKey(containerInfoDiff, ID_2);
        assignmentDb = new ContainerNeAssignmentDb(key, AssignmentType.LOGICAL);
        assertNotEquals(assignmentDb.hashCode(), containerNeAssignmentDb.hashCode());
    }
}