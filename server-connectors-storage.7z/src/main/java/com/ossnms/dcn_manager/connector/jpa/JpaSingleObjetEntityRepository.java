package com.ossnms.dcn_manager.connector.jpa;

import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.persistence.EntityManager;
import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;

import static com.ossnms.dcn_manager.connector.jpa.JpaExceptionsHelper.tryFindInChain;

import java.util.Optional;

/**
 * <p>Base implementation of a JPA repository of Single Object Entities. These are entities
 * that are composed of a single business object, as opposed to aggregates of business entities
 * that form a logical entity.</p>
 *
 * <p>This implementation uses template methods instead of parameters supplied at
 * construction time because we want to support usage patters that do not allow
 * usage of constructors with parameters.</p>
 *
 * @param <E> Business entity concrete type.
 * @param <D> Concrete type of the aggregate entity database representation.
 * @param <M> Business entity mutation concrete type.
 */
public abstract class JpaSingleObjetEntityRepository<E extends BusinessObjectData, D extends BusinessObjectDb<E>, M extends MutationDescriptor<E, ?>>
        extends JpaAggregateEntityRepository<E, D> {

    protected Optional<E> tryUpdate(@Nonnull M domainObjectMutation, @Nonnull D updatedDbObject) throws RepositoryException {
        D infoDb;
        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();
            final D existing = entityManager.find(getDbClass(), domainObjectMutation.getTarget().getId());
            if (null != existing) {
                infoDb = entityManager.merge(updatedDbObject);
            } else {
                LoggerFactory.getLogger(getClass()).warn("Tried to update inexisting object with {}", domainObjectMutation);
                return Optional.empty();
            }
        } catch (final OptimisticLockException e) {
            LoggerFactory.getLogger(getClass()).warn("Tried to update out-of-date object with {}", domainObjectMutation);
            return Optional.empty();
        } catch (final PersistenceException exception) {
            if (tryFindInChain(exception, OptimisticLockException.class).isPresent()) {
                LoggerFactory.getLogger(getClass()).warn("Tried to update out-of-date object with {}", domainObjectMutation);
                return Optional.empty();
            }
            throw new RepositoryException(exception);
        }
        domainObjectMutation.applied();
        return Optional.of(infoDb.build());
    }

    protected Optional<E> tryUpdate(@Nonnull UowContext ctx, @Nonnull M domainObjectMutation, @Nonnull D updatedDbObject) {
        final CloseableEntityTransaction tx = ((JpaUnitOfWorkContext) ctx).getTransaction();
        final EntityManager entityManager = tx.getEntityManager();
        final D existing = entityManager.find(getDbClass(), domainObjectMutation.getTarget().getId());
        if (null != existing) {
            return Optional.of(entityManager.merge(updatedDbObject).build());
        } else {
            LoggerFactory.getLogger(getClass()).warn("Tried to update inexisting object with {}", domainObjectMutation);
            return Optional.empty();
        }
    }

}
