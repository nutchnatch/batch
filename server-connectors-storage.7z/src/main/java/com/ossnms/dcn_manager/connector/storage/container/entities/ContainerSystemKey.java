package com.ossnms.dcn_manager.connector.storage.container.entities;

import org.apache.commons.lang3.builder.EqualsBuilder;

import java.io.Serializable;
import java.util.Objects;

/**
 * Maps the Association between Containers and Systems.
 */
public class ContainerSystemKey implements Serializable {
    private static final long serialVersionUID = -1893544698199542019L;

    private ContainerInfoDb containerInfo;
    private int systemContainerId;

    public ContainerSystemKey() {
    }

    public ContainerSystemKey(final ContainerInfoDb containerInfo, final int systemContainerId) {
        this.containerInfo = containerInfo;
        this.systemContainerId = systemContainerId;
    }

    @Override public int hashCode() {
        return Objects.hash(containerInfo.getContainerId(), systemContainerId);
    }

    @Override public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final ContainerSystemKey rhs = (ContainerSystemKey) obj;
        return new EqualsBuilder().append(containerInfo.getContainerId(), rhs.containerInfo.getContainerId())
                .append(systemContainerId, rhs.systemContainerId).isEquals();
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public ContainerInfoDb getContainerInfo() {
        return containerInfo;
    }

    public void setContainerInfo(ContainerInfoDb containerInfo) {
        this.containerInfo = containerInfo;
    }

    public int getSystemContainerId() {
        return systemContainerId;
    }

    public void setSystemContainerId(int systemContainerId) {
        this.systemContainerId = systemContainerId;
    }
}
