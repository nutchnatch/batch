package com.ossnms.dcn_manager.connector.storage.ne;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaDomainObjectRepository;
import com.ossnms.dcn_manager.connector.jpa.JpaUnitOfWorkContext;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeDirectRouteDb;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeUserPreferencesDb;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;

import static com.ossnms.dcn_manager.connector.jpa.JpaExceptionsHelper.tryFindInChain;

import java.util.Objects;
import java.util.Optional;

public class JpaNeUserPreferencesRepository
    extends JpaDomainObjectRepository<NeUserPreferencesData, NeUserPreferencesMutationDescriptor, NeUserPreferencesDb, NeUserPreferencesInitialData>
    implements NeUserPreferencesRepository {

    public JpaNeUserPreferencesRepository(@Nonnull Supplier<CloseableEntityTransaction> transactionSupplier) {
        super(NeUserPreferencesDb.class, transactionSupplier, "NeUserPreferencesDb.SELECT_ALL");
    }

    @Override
    protected NeUserPreferencesDb buildDatabaseObjectForUpdate(NeUserPreferencesData targetObject, NeUserPreferencesData mutationResult) {
        return new NeUserPreferencesDb(targetObject.getId(), targetObject.getVersion(), mutationResult);
    }

    @Override
    protected NeUserPreferencesDb buildDatabaseObjectForInsert(int parentId, NeUserPreferencesInitialData initialData) {
        return new NeUserPreferencesDb(parentId, initialData);
    }

    /**
     * {@inheritDoc}
     *
     * <p>Implementation note: NE User Preferences entities contain a reference to the NE Direct Route, which is
     * a separate database object. This reference is mapped as a one-to-one JPA unidirectional association.
     * This means that whenever the Route Key changes, we need to apply the delete-then-insert pattern
     * ourselves because the JPA provider has no way of knowing that we want to replace the other object instead
     * of simply changing the association. If we don't follow this approach, a new Direct Route will be created
     * whenever the Route Key changes.</p>
     */
    @Override
    public Optional<NeUserPreferencesData> tryUpdate(@Nonnull NeUserPreferencesMutationDescriptor mutation)
            throws RepositoryException {
    	final Optional<NeUserPreferencesData> result;
    	try (final CloseableEntityTransaction tx = getTransaction()) {
        	result = doUpdate(tx, mutation);
        } catch (final OptimisticLockException e) {
            LoggerFactory.getLogger(getClass()).warn("Tried to update NE Preferences with {}", mutation);
            return Optional.empty();
        } catch (final PersistenceException e) {
            if (tryFindInChain(e, OptimisticLockException.class).isPresent()) {
                LoggerFactory.getLogger(getClass()).warn("Tried to update out-of-date NE Preferences with {}", mutation);
                return Optional.empty();
            }

            throw new RepositoryException(e);
        }
        mutation.applied();
        return result;
        
    }

    /**
     * {@inheritDoc}
     * @see #tryUpdate(NeUserPreferencesMutationDescriptor)
     */
    @Override
    public Optional<NeUserPreferencesData> tryUpdate(@Nonnull UowContext context, @Nonnull NeUserPreferencesMutationDescriptor mutation) {
        return doUpdate(((JpaUnitOfWorkContext) context).getTransaction(), mutation);
    }

    private Optional<NeUserPreferencesData> doUpdate(@Nonnull CloseableEntityTransaction tx, @Nonnull NeUserPreferencesMutationDescriptor mutation) {
        final NeUserPreferencesData target = mutation.getTarget();
        final NeUserPreferencesData mutationResult = mutation.apply();
        final NeUserPreferencesDb preferencesForUpdate = buildDatabaseObjectForUpdate(target, mutationResult);
        final EntityManager entityManager = tx.getEntityManager();
        final NeUserPreferencesDb existing = entityManager.find(NeUserPreferencesDb.class, target.getId());
        if (null == existing) {
            LoggerFactory.getLogger(getClass()).warn("Tried to update inexisting NE Preferences with {}", preferencesForUpdate);
            return Optional.empty();
        }
        if (!Objects.equals(target.getDirectRoute().getKey(), mutationResult.getDirectRoute().getKey())) {
            final NeDirectRouteDb existingRoute = existing.getDirectRoute();
            if (null != existingRoute) {
                entityManager.remove(existingRoute);
            }
        }
        final NeUserPreferencesDb newData = entityManager.merge(preferencesForUpdate);
        return Optional.of(newData).map(getDataBuilder()::apply);
    }

    @Override
    public Optional<NeUserPreferencesData> query(String neName) throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            try {
                return Optional.of(tx.getEntityManager()
                        .createNamedQuery("NeUserPreferencesDb.SELECT_BY_NAME", NeUserPreferencesDb.class)
                        .setParameter("name", neName)
                        .getSingleResult())
                    .map(getDataBuilder()::apply);
            } catch (final NoResultException ex) {
                return Optional.empty();
            }
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Optional<NeUserPreferencesData> queryByGlobalId(String globalId)
            throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            return Optional.of(tx.getEntityManager()
                    .createNamedQuery("NeUserPreferencesDb.SELECT_BY_GLOBAL_ID", NeUserPreferencesDb.class)
                    .setParameter("globalId", Optional.of(globalId))
                    .getSingleResult())
                .map(getDataBuilder()::apply);
        } catch (final NoResultException ex) {
            return Optional.empty();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

}
