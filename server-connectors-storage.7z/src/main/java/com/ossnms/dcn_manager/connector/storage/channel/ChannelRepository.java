package com.ossnms.dcn_manager.connector.storage.channel;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaAggregateEntityRepository;
import com.ossnms.dcn_manager.connector.storage.StartableRepository;
import com.ossnms.dcn_manager.connector.storage.channel.entities.ChannelEntityDb;
import com.ossnms.dcn_manager.connector.storage.channel.entities.ChannelInfoDb;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import java.util.List;
import java.util.Optional;

import static com.google.common.collect.Iterables.transform;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p> A thread-safe in-memory and JPA implementation of a Channel domain entity repository. </p>
 */
public abstract class ChannelRepository
        extends JpaAggregateEntityRepository<ChannelEntity, ChannelEntityDb>
        implements ChannelEntityRepository, StartableRepository {

    private static final Logger LOGGER = getLogger(ChannelRepository.class);

    private JpaChannelInfoRepository infoRepo;
    private InMemoryChannelConnectionRepository connectionRepo;
    private JpaChannelUserPreferencesRepository prefsRepo;

    @Override
    protected Class<ChannelEntityDb> getDbClass() {
        return ChannelEntityDb.class;
    }

    @Override
    protected String getFetchAllQueryName() {
        return "ChannelEntityDb.FETCH_ALL";
    }

    /**
     * Helper method that gathers the remaining domain object instances associated to the domain entity
     *
     * @param channelDb The object representing the part of the entity to be retrieved that is stored in
     *                  the database
     * @return An {@link Optional} bearing the retrieved entity, if one exists
     * @throws RepositoryException When an error occurs while working with the
     *                             underlying data storage.
     */
    @Override
    protected Optional<ChannelEntity> fetchEntity(ChannelEntityDb channelDb) throws RepositoryException {
        final int entityId = channelDb.getChannelId();
        final Optional<ChannelConnectionData> channelConnection = getPhysicalChannelConnectionRepository().query(entityId);

        return channelConnection.isPresent() ?
                Optional.of(new ChannelEntity(
                        getPhysicalChannelInfoRepository().getDataBuilder().apply(channelDb.getInfo()),
                        channelConnection.get(),
                        getPhysicalChannelUserPreferencesRepository().getDataBuilder().apply(channelDb.getPreferences()))) :
                Optional.<ChannelEntity>empty();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ChannelEntity create(ChannelCreateDescriptor descriptor) throws RepositoryException {
        ChannelInfoData infoData;
        ChannelUserPreferencesData preferencesData;
        ChannelConnectionData connectionData;

        try (CloseableEntityTransaction tx = getTransaction()) {
            infoData =
                    getPhysicalChannelInfoRepository().insert(tx, descriptor.getMediatorId(), descriptor.getInfoInitialData());
            preferencesData =
                    getPhysicalChannelUserPreferencesRepository().insert(tx, infoData.getId(), descriptor.getPreferencesInitialData());
            connectionData =
                    new ChannelConnectionData(infoData.getId(), infoData.getVersion(), descriptor.getConnectionInitialData());
        } catch (final PersistenceException ex) {
            throw new RepositoryException(ex);
        }

        // if we get here, all data is in the database already.
        getPhysicalChannelConnectionRepository().insert(connectionData);

        return new ChannelEntity(infoData, connectionData, preferencesData);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void delete(ChannelDeleteDescriptor descriptor) throws RepositoryException {
        final int entityId = descriptor.getId();
        // Signal the removal of the domain entity instance by first removing from
        // the Channel Info repository (see comments on the implementation of the create method)
        getPhysicalChannelInfoRepository().remove(entityId);
        getPhysicalChannelConnectionRepository().remove(entityId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Optional<ChannelEntity> queryChannel(int channelId) throws RepositoryException {
        return query(channelId);
    }

    @Override
    public Optional<String> queryChannelName(int channelId) throws RepositoryException {

        try (CloseableEntityTransaction tx = getTransaction()) {

            return Optional.of(tx.getEntityManager()
                    .createNamedQuery("ChannelUserPreferencesDb.CHANNEL_NAME", String.class)
                    .setParameter("channelId", channelId)
                    .getSingleResult());

        } catch (final NoResultException exception) {
            return Optional.empty();
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }

    }

    @Override
    public Iterable<ChannelInfoData> queryActivationRequiredIs(int parentMediatorId, boolean activationRequired)
            throws RepositoryException {

        try (CloseableEntityTransaction tx = getTransaction()) {

            final List<ChannelInfoDb> dbResults = tx.getEntityManager()
                    .createNamedQuery("ChannelInfoDb.INFO_BY_STATE_UNDER_MEDIATOR", ChannelInfoDb.class)
                    .setParameter("mediatorId", parentMediatorId)
                    .setParameter("reqState", activationRequired)
                    .getResultList();

            return transform(dbResults, getPhysicalChannelInfoRepository().getDataBuilder());

        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ChannelInfoRepository getChannelInfoRepository() {
        return getPhysicalChannelInfoRepository();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ChannelConnectionRepository getChannelConnectionRepository() {
        return getPhysicalChannelConnectionRepository();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ChannelUserPreferencesRepository getChannelUserPreferencesRepository() {
        return getPhysicalChannelUserPreferencesRepository();
    }

    protected void initialize(Supplier<CloseableEntityTransaction> transactionSupplier) {
        infoRepo = new JpaChannelInfoRepository(transactionSupplier);
        connectionRepo = new InMemoryChannelConnectionRepository();
        prefsRepo = new JpaChannelUserPreferencesRepository(transactionSupplier);
    }

    /**
     * Holds the channel info domain object's repository.
     */
    protected JpaChannelInfoRepository getPhysicalChannelInfoRepository() {
        return infoRepo;
    }

    /**
     * Holds the channel connection domain object's repository.
     */
    protected InMemoryChannelConnectionRepository getPhysicalChannelConnectionRepository() {
        return connectionRepo;
    }

    /**
     * Holds the channel user preferences domain object's repository.
     */
    protected JpaChannelUserPreferencesRepository getPhysicalChannelUserPreferencesRepository() {
        return prefsRepo;
    }

    @Override
    public void start() throws RepositoryException {
        LOGGER.info("Starting Channel Repository (JPA).");

        final Iterable<Integer> existingIds = infoRepo.queryAllEntityIdentifiers();
        for (final Integer id : existingIds) {
            final ChannelConnectionData connection = new ChannelConnectionBuilder().build(id, 0);
            connectionRepo.insert(connection);
        }

    }
}
