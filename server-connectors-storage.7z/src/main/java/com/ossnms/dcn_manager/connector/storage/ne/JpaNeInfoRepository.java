package com.ossnms.dcn_manager.connector.storage.ne;

import java.util.List;

import javax.annotation.Nonnull;
import javax.persistence.PersistenceException;

import com.google.common.base.Supplier;
import com.google.common.collect.FluentIterable;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaAnchorDomainObjectRepository;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeInfoDb;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoInitialData;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public class JpaNeInfoRepository
    extends JpaAnchorDomainObjectRepository<NeInfoData, NeInfoMutationDescriptor, NeInfoDb, NeInfoInitialData>
    implements NeEntityRepository.NeInfoRepository {

    public JpaNeInfoRepository(@Nonnull Supplier<CloseableEntityTransaction> transactionSupplier) {
        super(NeInfoDb.class, transactionSupplier, "NeInfoDb.SELECT_ALL", "NeInfoDb.SELECT_ALL_IDENTIFIERS");
    }

    @Override
    public Iterable<NeInfoData> queryAll(int parentChannelId) throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final List<NeInfoDb> foundDb = tx.getEntityManager()
                    .createNamedQuery("NeInfoDb.SELECT_ALL_UNDER_CHANNEL", NeInfoDb.class)
                    .setParameter("channelId", parentChannelId)
                    .getResultList();
            return FluentIterable.from(foundDb).transform(getDataBuilder());
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    protected NeInfoDb buildDatabaseObjectForInsert(int parentId, NeInfoInitialData objectPrototype) {
        return new NeInfoDb(parentId, objectPrototype);
    }

    @Override
    protected NeInfoDb buildDatabaseObjectForInsert(NeInfoInitialData objectPrototype) {
        throw new UnsupportedOperationException();
    }

    @Override
    protected NeInfoDb buildDatabaseObjectForUpdate(NeInfoData targetObject, NeInfoData mutationResult) {
        return new NeInfoDb(targetObject.getNeId(), mutationResult.getChannelId(), targetObject.getVersion(), mutationResult);
    }

}
