package com.ossnms.dcn_manager.connector.storage.ne.entities;

import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationPrototype;

public class NeOperationDb extends NeOperationPrototype<NeOperationDb>
    implements BusinessObjectDb<NeOperationData> {

    private int neId;
    private int version;

    public NeOperationDb() {

    }

    public NeOperationDb(int id, int version, NeOperationData copy) {
        neId = id;
        this.version = version;

        setCommissioning(copy.getCommissioning());
        setEventForwardingMode(copy.isEventForwardingActive());
        setFamily(copy.getFamily());
        setIconId(copy.getIconId());
        setGatewayMode(copy.getGatewayMode());
        setMainRelease(copy.getMainRelease());
        setMaintenanceRelease(copy.getMaintenanceRelease());
        setNeSpecificType(copy.getNeSpecificType());
        setNeSubType(copy.getNeSubType());
        setNeSubTypeDescription(copy.getNeSubTypeDescription());
        setNeType(copy.getNeType());
        setOperational(copy.getOperational());
        setRealNeName(copy.getRealNeName());
        setTpGroupMask(copy.getTpGroupMask());
        setTpGroupMode(copy.getTpGroupMode());
        setWriteAccess(copy.getWriteAccess());
        setNeighbourhoodId(copy.getNeighbourhoodId());
        setLocation(copy.getLocation());
        setAdditionalTypeInfo(copy.getAdditionalTypeInfo());
    }

    public NeOperationDb(int id, NeOperationPrototype<?> other) {
        super(other);
        neId = id;
    }

    @Override
    public NeOperationData build() {
        return new NeOperationData(neId, version, this);
    }

    @Override
    protected NeOperationDb self() {
        return this;
    }

}
