package com.ossnms.dcn_manager.connector.storage.mediator;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaAnchorDomainObjectRepository;
import com.ossnms.dcn_manager.connector.storage.mediator.entities.MediatorInfoDb;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoInitialData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorInfoRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import java.util.Optional;

public class JpaMediatorInfoRepository
        extends JpaAnchorDomainObjectRepository<MediatorInfoData, MediatorInfoMutationDescriptor, MediatorInfoDb, MediatorInfoInitialData>
        implements MediatorInfoRepository {

    private final Supplier<CloseableEntityTransaction> transactionSupplier;

    public JpaMediatorInfoRepository(@Nonnull Supplier<CloseableEntityTransaction> transactionSupplier) {
        super(MediatorInfoDb.class, transactionSupplier, "MediatorInfoDb.SELECT_ALL", "MediatorInfoDb.SELECT_ALL_IDS");
        this.transactionSupplier = transactionSupplier;
    }

    @Override
    public Optional<MediatorInfoData> query(String mediatorName) throws RepositoryException {
        try (final CloseableEntityTransaction tx = transactionSupplier.get()) {

            final MediatorInfoDb mediatorInfoDb =
                    tx.getEntityManager()
                            .createNamedQuery("MediatorInfoDb.SELECT_BY_NAME", MediatorInfoDb.class)
                            .setParameter("n", mediatorName)
                            .getSingleResult();

            return Optional.ofNullable(mediatorInfoDb).map(getDataBuilder()::apply);
        } catch (final NoResultException e) {
            return Optional.empty();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Optional<MediatorInfoData> queryByHost(String mediatorType, String hostName) throws RepositoryException {
        try (final CloseableEntityTransaction tx = transactionSupplier.get()) {

            final MediatorInfoDb mediatorInfoDb =
                    tx.getEntityManager()
                            .createNamedQuery("MediatorInfoDb.SELECT_BY_HOST_AND_TYPE", MediatorInfoDb.class)
                            .setParameter("n", hostName)
                            .setParameter("t", mediatorType)
                            .getSingleResult();

            return Optional.ofNullable(mediatorInfoDb).map(getDataBuilder()::apply);
        } catch (final NoResultException e) {
            return Optional.empty();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    protected MediatorInfoDb buildDatabaseObjectForInsert(int parentId, MediatorInfoInitialData objectPrototype) {
        return buildDatabaseObjectForInsert(objectPrototype);
    }

    @Override
    protected MediatorInfoDb buildDatabaseObjectForInsert(MediatorInfoInitialData objectPrototype) {
        return new MediatorInfoDb(objectPrototype);
    }

    @Override
    protected MediatorInfoDb buildDatabaseObjectForUpdate(MediatorInfoData targetObject,
                                                          MediatorInfoData mutationResult) {
        return new MediatorInfoDb(targetObject.getId(), targetObject.getVersion(), mutationResult);
    }

}