package com.ossnms.dcn_manager.connector.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.EnumType;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

@SuppressWarnings("rawtypes")
public final class OptionalEnumType extends EnumType {

    private static final long serialVersionUID = 5926579230002860854L;

    @Override
    public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner) throws SQLException {
        final Object enumValue = super.nullSafeGet(rs, names, session, owner);
        return Optional.ofNullable(enumValue);
    }

    @Override
    public void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session) throws HibernateException, SQLException {
        super.nullSafeSet(st, dereferenceAsOptional(value), index, session);
    }

    @Override
    public String objectToSQLString(Object value) {
        return super.objectToSQLString(dereferenceAsOptional(value));
    }

    @Override
    public String toXMLString(Object value) {
        return super.toXMLString(dereferenceAsOptional(value));
    }

    @Override
    public Object fromXMLString(String xmlValue) {
        final Object value = super.fromXMLString(xmlValue);
        return Optional.ofNullable(value);
    }

    @Override
    public String toLoggableString(Object value, SessionFactoryImplementor factory) {
        return value.toString();
    }

    private Object dereferenceAsOptional(Object value) {
        return value != null ? ((Optional) value).orElse(null): null;
    }
}