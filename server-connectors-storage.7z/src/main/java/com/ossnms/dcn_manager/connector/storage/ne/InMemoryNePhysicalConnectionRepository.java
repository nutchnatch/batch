package com.ossnms.dcn_manager.connector.storage.ne;

import java.util.concurrent.atomic.AtomicInteger;

import com.mysema.query.collections.CollQuery;
import com.mysema.query.collections.CollQueryFactory;
import com.ossnms.dcn_manager.composables.storage.InMemoryDomainObjectRepository;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.QNePhysicalConnectionData;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;

public class InMemoryNePhysicalConnectionRepository
        extends InMemoryDomainObjectRepository<NePhysicalConnectionData, NePhysicalConnectionMutationDescriptor>
        implements NePhysicalConnectionRepository {

    private final AtomicInteger nextNeInstanceId = new AtomicInteger(1);

    @Override
    public CollQuery query(QNePhysicalConnectionData neConnection) {
        return CollQueryFactory.from(neConnection, queryAll());
    }

    @Override
    public Iterable<NePhysicalConnectionData> queryAll(int logicalNeId) {
        final QNePhysicalConnectionData data = QNePhysicalConnectionData.nePhysicalConnectionData;
        return query(data).where(data.logicalNeId.eq(logicalNeId)).list(data);
    }

    @Override
    public NePhysicalConnectionData insert(NePhysicalConnectionInitialData initialConnectionData, int neId, int channelInstanceId) {
        final NePhysicalConnectionData newData =
            new NePhysicalConnectionData(nextNeInstanceId.getAndIncrement(), neId, channelInstanceId, 0, initialConnectionData);
        insert(newData);
        return newData;
    }

}
