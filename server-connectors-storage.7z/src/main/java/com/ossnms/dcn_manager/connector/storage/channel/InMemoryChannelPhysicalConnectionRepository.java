package com.ossnms.dcn_manager.connector.storage.channel;

import java.util.concurrent.atomic.AtomicInteger;

import com.mysema.query.collections.CollQuery;
import com.mysema.query.collections.CollQueryFactory;
import com.ossnms.dcn_manager.composables.storage.InMemoryDomainObjectRepository;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.QChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;

/**
 * Concrete type that supports an in-memory implementation of the {@link ChannelPhysicalConnectionRepository}.
 */
public class InMemoryChannelPhysicalConnectionRepository
        extends InMemoryDomainObjectRepository<ChannelPhysicalConnectionData, ChannelPhysicalConnectionMutationDescriptor>
	    implements ChannelPhysicalConnectionRepository {

    private final AtomicInteger nextChannelInstanceId = new AtomicInteger(1);

    @Override
    public CollQuery query(QChannelPhysicalConnectionData info) {
        return CollQueryFactory.from(info, queryAll());
    }

    @Override
    public Iterable<ChannelPhysicalConnectionData> queryAll(int logicalChannelId) {
        final QChannelPhysicalConnectionData connectionData = QChannelPhysicalConnectionData.channelPhysicalConnectionData;
        return query(connectionData).where(connectionData.logicalChannelId.eq(logicalChannelId)).list(connectionData);
    }

    @Override
    public ChannelPhysicalConnectionData insert(ChannelConnectionInitialData initialConnectionData, int channelId, int mediatorInstanceId) {
        final ChannelPhysicalConnectionData newData =
            new ChannelPhysicalConnectionData(nextChannelInstanceId.getAndIncrement(), mediatorInstanceId, channelId, 0, initialConnectionData);
        insert(newData);
        return newData;
    }

}