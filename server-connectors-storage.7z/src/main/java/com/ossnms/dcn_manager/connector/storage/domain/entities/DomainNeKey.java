package com.ossnms.dcn_manager.connector.storage.domain.entities;

import java.io.Serializable;
import java.util.Objects;

import org.apache.commons.lang3.builder.EqualsBuilder;

public class DomainNeKey implements Serializable {

    private static final long serialVersionUID = 2677305246036592326L;

    private DomainInfoDb domain;
    private int neId;
    private Membership membership;

    public DomainNeKey() {

    }

    public DomainNeKey(DomainInfoDb domain, int neId, Membership membership) {
        this.domain = domain;
        this.neId = neId;
        this.membership = membership;
    }

    @Override
    public int hashCode() {
        return Objects.hash(domain, neId, membership);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final DomainNeKey rhs = (DomainNeKey) obj;
        return new EqualsBuilder()
            .append(domain, rhs.domain)
            .append(neId, rhs.neId)
            .append(membership, rhs.membership)
            .isEquals();
    }

    /**
     * @return The parent domain.
     */
    public DomainInfoDb getDomain() {
        return domain;
    }
    /**
     * @param domain New parent domain.
     */
    public void setDomain(DomainInfoDb domain) {
        this.domain = domain;
    }
    /**
     * @return Participant NE identifier.
     */
    public int getNeId() {
        return neId;
    }
    /**
     * @param neId New participant NE identifier.
     */
    public void setNeId(int neId) {
        this.neId = neId;
    }
    /**
     * @return Membership type.
     */
    public Membership getMembership() {
        return membership;
    }
    /**
     * @param membership New membership type.
     */
    public void setMembership(Membership membership) {
        this.membership = membership;
    }
}