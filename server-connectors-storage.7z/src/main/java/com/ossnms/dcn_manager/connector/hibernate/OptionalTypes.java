package com.ossnms.dcn_manager.connector.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.SingleColumnType;
import org.hibernate.usertype.UserType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.Optional;

class OptionalTypes<T> implements UserType {

    private final SingleColumnType<T> storedType;

    protected OptionalTypes(SingleColumnType<T> storedType) {
        this.storedType = storedType;
    }

    @Override
    public int[] sqlTypes() {
        return new int[] { storedType.sqlType() };
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Class returnedClass() {
        return Optional.class;
    }

    @Override
    public boolean equals(Object x, Object y) throws HibernateException { // NOMPD: overriding UserType#equals, not Object#equals
        return Objects.equals(x, y);
    }

    @Override
    public int hashCode(Object x) throws HibernateException {
        return x.hashCode();
    }

    @Override
    public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner)
            throws HibernateException, SQLException {
        return Optional.ofNullable(storedType.get(rs, names[0], session));
    }

    @SuppressWarnings("unchecked")
    @Override
    public void nullSafeSet(PreparedStatement st, Object value, int index,
            SessionImplementor session) throws HibernateException, SQLException {
        storedType.set(st, value != null ? ((Optional<T>) value).orElse(null) : null, index, session);
    }

    @Override
    public Object deepCopy(Object value) throws HibernateException {
        // Optionals are immutable, so a deep copy results in the same object reference every time.
        return value;
    }

    @Override
    public boolean isMutable() {
        return false;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Serializable disassemble(Object value) throws HibernateException {
        return (Serializable) (value != null ? ((Optional) value).orElse(null) : null);
    }

    @Override
    public Object assemble(Serializable cached, Object owner) throws HibernateException {
        return Optional.ofNullable(cached);
    }

    @Override
    public Object replace(Object original, Object target, Object owner) throws HibernateException {
        return original;
    }

}
