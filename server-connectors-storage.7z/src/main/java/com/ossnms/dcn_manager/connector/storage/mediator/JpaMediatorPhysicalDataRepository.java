package com.ossnms.dcn_manager.connector.storage.mediator;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaAnchorDomainObjectRepository;
import com.ossnms.dcn_manager.connector.storage.mediator.entities.MediatorPhysicalDataDb;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataInitialData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalDataMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalDataRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import java.util.Optional;

class JpaMediatorPhysicalDataRepository
        extends JpaAnchorDomainObjectRepository<MediatorPhysicalData, MediatorPhysicalDataMutationDescriptor, MediatorPhysicalDataDb, MediatorPhysicalDataInitialData>
        implements MediatorPhysicalDataRepository {

    private final Supplier<CloseableEntityTransaction> transactionSupplier;

    public JpaMediatorPhysicalDataRepository(@Nonnull Supplier<CloseableEntityTransaction> transactionSupplier) {
        super(MediatorPhysicalDataDb.class, transactionSupplier, "MediatorPhysicalDataDb.SELECT_ALL", "MediatorPhysicalDataDb.SELECT_ALL_IDS");
        this.transactionSupplier = transactionSupplier;
    }

    @Override
    public Optional<MediatorPhysicalData> queryByHost(String hostName) throws RepositoryException {
        try (final CloseableEntityTransaction tx = transactionSupplier.get()) {

            final MediatorPhysicalDataDb mediatorPhysicalDataDb =
                tx.getEntityManager()
                    .createNamedQuery("MediatorPhysicalDataDb.SELECT_BY_HOST", MediatorPhysicalDataDb.class)
                    .setParameter("n", hostName)
                    .getSingleResult();

            return Optional.ofNullable(mediatorPhysicalDataDb).map(getDataBuilder()::apply);
        } catch (final NoResultException e) {
            return Optional.empty();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    protected MediatorPhysicalDataDb buildDatabaseObjectForInsert(int parentId, MediatorPhysicalDataInitialData objectPrototype) {
        return new MediatorPhysicalDataDb(parentId, objectPrototype);
    }

    @Override
    protected MediatorPhysicalDataDb buildDatabaseObjectForInsert(MediatorPhysicalDataInitialData objectPrototype) {
        return new MediatorPhysicalDataDb(objectPrototype);
    }

    @Override
    protected MediatorPhysicalDataDb buildDatabaseObjectForUpdate(MediatorPhysicalData targetObject,
            MediatorPhysicalData mutationResult) {
        return new MediatorPhysicalDataDb(targetObject.getId(), targetObject.getVersion(), mutationResult);
    }

}