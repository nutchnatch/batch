package com.ossnms.dcn_manager.connector.storage.ne.entities;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDirectRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesPrototype;
import com.ossnms.dcn_manager.core.entities.ne.data.RouteSortingMode;

import javax.annotation.CheckForNull;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class NeUserPreferencesDb extends NeUserPreferencesPrototype<NeUserPreferencesDb>
    implements BusinessObjectDb<NeUserPreferencesData> {

    private int neId;
    private int version;

    @Nullable
    private NeDirectRouteDb directRoute;
    
    @Nullable
    private NeDataTransferSettingsDb dataTransferSettingsDb;
    
    public NeUserPreferencesDb() {
    }

    public NeUserPreferencesDb(int id, int version, @Nonnull NeUserPreferencesData copy) {
        this.neId = id;
        this.version = version;

        setGlobalId(copy.getGlobalId());
        setName(copy.getName());
        setPassword(copy.getPassword());
        setProperties(copy.getAllOpaqueProperties());
        setReconnectInterval(copy.getReconnectInterval());
        setUserName(copy.getUserName());
        setUsesGne(copy.usesGne());
        setUsesFlatIp(copy.usesFlatIp());
        setContainerId(copy.getContainerId());
        setUserText(copy.getUserText());
        enableRouteSorting(copy.getRouteSortingMode() != RouteSortingMode.NONE);
        enableRouteSortingByUsage(copy.getRouteSortingMode() == RouteSortingMode.AUTO_PRIORITY);

        dataTransferSettingsDb = new NeDataTransferSettingsDb().from(copy);

        // copy from the business entity into this prototype and into the DB object.
        final NeDirectRouteData copyDirectRoute = copy.getDirectRoute();
        final ImmutableMap<String, String> copyDirectRouteProperties = copyDirectRoute.getAllOpaqueProperties();
        final NeRoutePropertyAdapter<?> prototypeDirectRouteAdapter = getDirectRouteAdapter();
        prototypeDirectRouteAdapter.setKey(copyDirectRoute.getKey());
        prototypeDirectRouteAdapter.setProperties(copyDirectRouteProperties);
        if (!Strings.isNullOrEmpty(copyDirectRoute.getKey())) {
            directRoute = new NeDirectRouteDb();
            directRoute.setNeId(id);
            directRoute.setVersion(version);
            directRoute.setKey(copyDirectRoute.getKey());
            directRoute.setProperties(copyDirectRouteProperties);
        }
    }

    public NeUserPreferencesDb(int id, @Nonnull NeUserPreferencesPrototype<?> other) {
        super(other);
        this.neId = id;

        dataTransferSettingsDb = new NeDataTransferSettingsDb().from(other.getDataTransferSettingsAdapter());

        // copy from the other prototype into the DB object.
        final NeRoutePropertyAdapter<?> otherDirectRouteAdapter = other.getDirectRouteAdapter();
        if (otherDirectRouteAdapter.getKey().isPresent()) {
            directRoute = new NeDirectRouteDb();
            directRoute.setNeId(neId);
            directRoute.setKey(otherDirectRouteAdapter.getKey().orElse(null));
            directRoute.setProperties(otherDirectRouteAdapter.getProperties());
        }
    }

    @Override
    public NeUserPreferencesData build() {
        if (null != directRoute) {
            // copy direct route data from the external DB object into the User Preferences prototype
            final NeRoutePropertyAdapter<?> prototypeDirectRouteAdapter = getDirectRouteAdapter();
            prototypeDirectRouteAdapter.setKey(directRoute.getKey());
            prototypeDirectRouteAdapter.setProperties(directRoute.getPropertyBag());
        }

        this.setDataTransferSettings(dataTransferSettingsDb);

        return new NeUserPreferencesData(neId, version, this);
    }
    
    @CheckForNull
    public NeDataTransferSettingsDb getDataTransferSettingsDb() {
        return dataTransferSettingsDb;
    }

    public void setDataTransferSettingsDb(@Nullable NeDataTransferSettingsDb dataTransferSettingsDb) {
        this.dataTransferSettingsDb = dataTransferSettingsDb;
    }
    
    @CheckForNull
    public NeDirectRouteDb getDirectRoute() {
        return directRoute;
    }

    @Override
    protected NeUserPreferencesDb self() {
        return this;
    }

}
