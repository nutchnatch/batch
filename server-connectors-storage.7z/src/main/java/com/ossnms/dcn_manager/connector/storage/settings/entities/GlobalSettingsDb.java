package com.ossnms.dcn_manager.connector.storage.settings.entities;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;

/**
 * JPA representation of the DCN Manager global configuration.
 *
 * @see GlobalSettings
 */
public class GlobalSettingsDb extends GlobalSettings.Builder {

    private int id;
    private int versionNumber;

    /**
     * Creates a new object with default values.
     */
    public GlobalSettingsDb() {

    }

    /**
     * Creates a new object with a predefined ID and version.
     */
    public GlobalSettingsDb(int defaultId, int defaultVersion) {
        id = defaultId;
        versionNumber = defaultVersion;
    }

    /**
     * Creates a new database object based on values set on
     * an existing internal domain object.
     *
     * @param internalData Internal domain object instance.
     */
    public GlobalSettingsDb(@Nonnull GlobalSettings internalData) {
        super(internalData);
        id = internalData.getId();
        versionNumber = internalData.getVersion();
    }

    /**
     * Builds a new instance of {@link GlobalSettings} with the current
     * identifier and version number.
     */
    public GlobalSettings toGlobalSettings() {
        return toGlobalSettings(id, versionNumber);
    }

}
