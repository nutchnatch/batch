package com.ossnms.dcn_manager.connector.jpa;

import com.google.common.base.Equivalence;
import com.google.common.base.Function;
import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.storage.BusinessObjectRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.persistence.EntityManager;
import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;
import java.util.List;
import java.util.Optional;

import static com.google.common.collect.Iterables.transform;
import static com.ossnms.dcn_manager.connector.jpa.JpaExceptionsHelper.tryFindInChain;

/**
 * <p>A generic implementation of a persistent domain object repository using JPA.</p>
 *
 * <p>Insert and deletion operations are not part of the general Domain Object Repository contract
 * (@see {@link BusinessObjectRepository}) because these operations are only to be used by Domain Entity
 * Repository implementations, that is, the repository of Domain Object aggregates. This is due to the
 * fact that Domain Object instances must always be created and removed within the context of an
 * insertion or removal of the Domain Entity instance (i.e. creation or removal of the aggregate). </p>
 *
 * <p>Mutable representations of the domain object are required for database operations
 * because the JPA API is unable to manage immutable entities properly.</p>
 *
 * @param <T> The domain object concrete type (i.e. its data dimension)
 * @param <M> The domain object's mutation descriptor concrete type
 * @param <D> The domain object's concrete type of its mutable database representation
 * @param <P> The domain object's prototype, i.e., a mutable type used as a parameter object for
 *            creating the domain object with a set of data
 */
public abstract class JpaDomainObjectRepository
        <T extends BusinessObjectData, M extends MutationDescriptor<T, M>, D extends BusinessObjectDb<T>, P>
            implements BusinessObjectRepository<T, M> {

    /**
     * Given a database entity, produces the corresponding DCN Manager domain entity.
     */
    public final class BuildInfoDataFromDb implements Function<D, T> {

        @Override
        public T apply(D input) {
            return null != input ? input.build() : null;
        }

    }

    private final BuildInfoDataFromDb dataBuilder = new BuildInfoDataFromDb();
    private final Supplier<CloseableEntityTransaction> transactionSupplier;
    private final Class<D> dbClass;
    private final String selectAllNamedQuery;

    /**
     * Creates a new repository instance.
     *
     * @param dbClass Database entity type.
     * @param transactionSupplier Database transaction supplier, used to delimit interactions with the database.
     * @param selectAllNamedQuery The name of a JPA query without parameters, used to select all objects.
     */
    public JpaDomainObjectRepository(
            @Nonnull Class<D> dbClass, @Nonnull Supplier<CloseableEntityTransaction> transactionSupplier,
            @Nonnull String selectAllNamedQuery) {
        this.dbClass = dbClass;
        this.transactionSupplier = transactionSupplier;
        this.selectAllNamedQuery = selectAllNamedQuery;
    }

    /**
     * @return An instance of the appropriate {@link BuildInfoDataFromDb} domain entity builder.
     */
    public BuildInfoDataFromDb getDataBuilder() {
        return dataBuilder;
    }

    protected CloseableEntityTransaction getTransaction() {
        return transactionSupplier.get();
    }

    public T insert(@Nonnull CloseableEntityTransaction tx, int parentId, @Nonnull P initialData)
            throws RepositoryException {
        try {
            final D newData = buildDatabaseObjectForInsert(parentId, initialData);
            tx.getEntityManager().persist(newData);
            return getDataBuilder().apply(newData);
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }
    }

    public void remove(int entityId) throws RepositoryException {
        try (final CloseableEntityTransaction tx = transactionSupplier.get()) {
            remove(tx, entityId);
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    public void remove(CloseableEntityTransaction tx, int entityId) {
        final EntityManager manager = tx.getEntityManager();
        final D existing = manager.find(dbClass, entityId);
        if (null != existing) {
            manager.remove(existing);
        }
    }

    @Override
    public Optional<T> query(int id) throws RepositoryException {
        try (final CloseableEntityTransaction tx = transactionSupplier.get()) {
            final D infoDb = tx.getEntityManager().find(dbClass, id);
            return Optional.ofNullable(infoDb).map(dataBuilder::apply);
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Iterable<T> queryAll() throws RepositoryException {
        try (final CloseableEntityTransaction tx = transactionSupplier.get()) {
            final List<D> results = tx.getEntityManager()
                    .createNamedQuery(selectAllNamedQuery, dbClass)
                    .getResultList();
            return transform(results, dataBuilder);
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Optional<T> tryUpdate(@Nonnull M mutation) throws RepositoryException {
        final T target = mutation.getTarget();
        final T mutationResult = mutation.apply();
        if (Equivalence.identity().equivalent(target, mutationResult)) {
            // Because mutations should be no-ops against their target if no actual changes are
            // required, try to avoid accessing the DB in such case.
            return Optional.of(mutationResult);
        }
        final Optional<D> updatedObject = update(target, mutationResult);
        if (updatedObject.isPresent()) {
            mutation.applied();
            return Optional.of(mutationResult);
        }
        return Optional.empty();
    }

    @Override
    public Optional<T> tryUpdate(@Nonnull UowContext context, @Nonnull M mutation) {
        final T target = mutation.getTarget();
        final T mutationResult = mutation.apply();
        if (Equivalence.identity().equivalent(target, mutationResult)) {
            // Because mutations should be no-ops against their target if no actual changes are
            // required, try to avoid accessing the DB in such case.
            return Optional.of(mutationResult);
        }
        final D info = buildDatabaseObjectForUpdate(target, mutationResult);
        final CloseableEntityTransaction tx = ((JpaUnitOfWorkContext) context).getTransaction();
        return findAndMerge(tx, target, info)
            .map(obj -> mutationResult);
    }

    protected Optional<D> update(@Nonnull T target, @Nonnull T mutationResult) throws RepositoryException {
        final D info = buildDatabaseObjectForUpdate(target, mutationResult);
        try (final CloseableEntityTransaction tx = transactionSupplier.get()) {
            return findAndMerge(tx, target, info);
        } catch (final OptimisticLockException e) {
            LoggerFactory.getLogger(getClass()).warn("Tried to update out-of-date object with {}", info);
            return Optional.empty();
        } catch (final PersistenceException e) {
            if (tryFindInChain(e, OptimisticLockException.class).isPresent()) {
                LoggerFactory.getLogger(getClass()).warn("Tried to update out-of-date object with {}", info);
                return Optional.empty();
            }
            throw new RepositoryException(e);
        }
    }

    private Optional<D> findAndMerge(CloseableEntityTransaction tx, @Nonnull T target, D info) {
        final EntityManager entityManager = tx.getEntityManager();
        // first attempt to find the object we're trying to update so we don't create a new row instead.
        final D infoDb = entityManager.find(dbClass, target.getId());
        if (null != infoDb) {
            return Optional.of(entityManager.merge(info));
        }
        LoggerFactory.getLogger(getClass()).warn("Tried to update inexisting object with {}", info);
        return Optional.empty();
    }

    protected Optional<D> persist(@Nonnull D info) throws RepositoryException {
        try (final CloseableEntityTransaction tx = transactionSupplier.get()) {
            tx.getEntityManager().persist(info);
            return Optional.of(info);
        } catch (final OptimisticLockException e) {
            LoggerFactory.getLogger(getClass()).warn("Tried to update out-of-date object with {}", info);
            return Optional.empty();
        } catch (final PersistenceException e) {
            if (tryFindInChain(e, OptimisticLockException.class).isPresent()) {
                LoggerFactory.getLogger(getClass()).warn("Tried to update out-of-date object with {}", info);
                return Optional.empty();
            }
            throw new RepositoryException(e);
        }
    }

    protected abstract D buildDatabaseObjectForInsert(int parentId, @Nonnull P initialData);

    protected abstract D buildDatabaseObjectForUpdate(@Nonnull T targetObject, @Nonnull T mutationResult);
}
