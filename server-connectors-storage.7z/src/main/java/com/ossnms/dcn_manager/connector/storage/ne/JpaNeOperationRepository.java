package com.ossnms.dcn_manager.connector.storage.ne;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaDomainObjectRepository;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeOperationDb;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeOperationRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import java.util.Optional;

public class JpaNeOperationRepository
        extends JpaDomainObjectRepository<NeOperationData, NeOperationMutationDescriptor, NeOperationDb, NeOperationInitialData>
        implements NeOperationRepository {

    public JpaNeOperationRepository(@Nonnull Supplier<CloseableEntityTransaction> transactionSupplier) {
        super(NeOperationDb.class, transactionSupplier, "NeOperationDb.SELECT_ALL");
    }

    @Override
    protected NeOperationDb buildDatabaseObjectForUpdate(NeOperationData targetObject, NeOperationData mutationResult) {
        return new NeOperationDb(targetObject.getId(), targetObject.getVersion(), mutationResult);
    }

    @Override
    protected NeOperationDb buildDatabaseObjectForInsert(int parentId, NeOperationInitialData initialData) {
        return new NeOperationDb(parentId, initialData);
    }

    @Override
    public Optional<NeOperationData> queryByRealName(String realName) throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            return Optional.of(tx.getEntityManager()
                    .createNamedQuery("NeOperationDb.SELECT_BY_REAL_NAME", NeOperationDb.class)
                    .setParameter("realName", Optional.of(realName))
                    .getSingleResult())
                    .map(getDataBuilder()::apply);
        } catch (final NoResultException exception) {
            return Optional.empty();
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }
    }

    @Override
    public Optional<NeOperationData> queryByNeighbourhoodId(String neighbourhoodId) throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            return Optional.of(tx.getEntityManager()
                    .createNamedQuery("NeOperationDb.SELECT_BY_NEIGHBOURHOOD_ID", NeOperationDb.class)
                    .setParameter("neighbourhoodId", Optional.of(neighbourhoodId))
                    .getSingleResult())
                    .map(getDataBuilder()::apply);
        } catch (final NoResultException exception) {
            return Optional.empty();
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }
    }
}
