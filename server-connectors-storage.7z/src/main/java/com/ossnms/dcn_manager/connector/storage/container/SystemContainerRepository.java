package com.ossnms.dcn_manager.connector.storage.container;

import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaSingleObjetEntityRepository;
import com.ossnms.dcn_manager.connector.storage.container.entities.SystemInfoDb;
import com.ossnms.dcn_manager.core.entities.container.system.SystemCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import java.util.Optional;

public abstract class SystemContainerRepository
        extends JpaSingleObjetEntityRepository<SystemInfo, SystemInfoDb, SystemInfoMutationDescriptor>
        implements SystemRepository {

    @Override
    protected Class<SystemInfoDb> getDbClass() {
        return SystemInfoDb.class;
    }

    @Override
    protected String getFetchAllQueryName() {
        return "SystemInfoDb.SELECT_ALL";
    }

    @Override
    protected Optional<SystemInfo> fetchEntity(SystemInfoDb dbEntity) throws RepositoryException {
        return Optional.of(dbEntity.build());
    }

    @Override
    public SystemInfo create(SystemCreationDescriptor descriptor) throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            final SystemInfoDb infoDb = new SystemInfoDb(descriptor);
            tx.getEntityManager().persist(infoDb);
            return infoDb.build();
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }
    }

    @Override
    public void delete(SystemDeletionDescriptor descriptor) throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();
            final SystemInfoDb infoDb = entityManager.find(SystemInfoDb.class, descriptor.getId());
            if (null != infoDb) {
                entityManager.remove(infoDb);
            }
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }
    }

    @Override
    public Optional<SystemInfo> tryUpdate(SystemInfoMutationDescriptor mutation) throws RepositoryException {
        final SystemInfo mutationTarget = mutation.getTarget();
        final SystemInfo mutationResult = mutation.apply();
        final SystemInfoDb info = new SystemInfoDb(mutationTarget.getId(), mutationTarget.getVersion(), mutationResult.getName());
        info.setContainerDescription(mutationResult.getDescription());
        info.setContainerUserText(mutationResult.getUserText());
        return tryUpdate(mutation, info);
    }

    @Override
    public Optional<SystemInfo> tryUpdate(@Nonnull UowContext context, @Nonnull SystemInfoMutationDescriptor mutation) {
        final SystemInfo mutationTarget = mutation.getTarget();
        final SystemInfo mutationResult = mutation.apply();
        final SystemInfoDb info = new SystemInfoDb(mutationTarget.getId(), mutationTarget.getVersion(), mutationResult.getName());
        info.setContainerDescription(mutationResult.getDescription());
        info.setContainerUserText(mutationResult.getUserText());
        return tryUpdate(context, mutation, info);
    }

    @Override
    public Optional<SystemInfo> queryByName(String systemName) throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final SystemInfoDb result = tx.getEntityManager()
                    .createNamedQuery("SystemInfoDb.SELECT_BY_NAME", SystemInfoDb.class)
                    .setParameter("name", systemName)
                    .getSingleResult();
            return Optional.of(result.build());
        } catch (final NoResultException e) {
            return Optional.empty();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }
}
