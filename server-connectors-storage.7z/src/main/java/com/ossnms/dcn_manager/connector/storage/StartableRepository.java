package com.ossnms.dcn_manager.connector.storage;

import com.ossnms.dcn_manager.exceptions.RepositoryException;

/**
 * Marks a repository as requiring an explicit start-up operation.
 */
public interface StartableRepository {

    /**
     * Starts the repository. Must be called only once during the entire life
     * span of the repository instance, and before any operations are attempted
     * against the instance.
     *
     * @throws RepositoryException If an error occurs while dealing with the
     *  underlying data source.
     */
    void start() throws RepositoryException;

}