package com.ossnms.dcn_manager.connector.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

public class CloseableEntityTransaction implements EntityTransaction, AutoCloseable {

    private final EntityTransaction transaction;
    private final EntityManager manager;

    public CloseableEntityTransaction(EntityManager manager, EntityTransaction transaction) {
        this.manager = manager;
        this.transaction = transaction;
    }

    @Override
    public void begin() {
        transaction.begin();
    }

    @Override
    public void commit() {
        transaction.commit();
    }

    @Override
    public void rollback() {
        transaction.rollback();
    }

    @Override
    public void setRollbackOnly() {
        transaction.setRollbackOnly();
    }

    @Override
    public boolean getRollbackOnly() {
        return transaction.getRollbackOnly();
    }

    @Override
    public boolean isActive() {
        return transaction.isActive();
    }

    /**
     * Closes this transaction. The transaction is committed unless it is marked for rollback, in
     * which case it is rolled back.
     *
     * @throws javax.persistence.PersistenceException If an unexpected error condition is encountered.
     * @throws javax.persistence.RollbackException If the commit fails.
     * @throws java.lang.IllegalStateException If the transaction is not active.
     */
    @Override
    public void close() {
        if (transaction.getRollbackOnly()) {
            transaction.rollback();
        } else {
            transaction.commit();
        }
    }

    public EntityManager getEntityManager() {
        return manager;
    }

}
