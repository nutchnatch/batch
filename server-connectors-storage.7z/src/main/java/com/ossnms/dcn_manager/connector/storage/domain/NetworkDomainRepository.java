package com.ossnms.dcn_manager.connector.storage.domain;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaSingleObjetEntityRepository;
import com.ossnms.dcn_manager.connector.storage.domain.entities.DomainInfoDb;
import com.ossnms.dcn_manager.connector.storage.domain.entities.DomainNeMembershipDb;
import com.ossnms.dcn_manager.connector.storage.domain.entities.Membership;
import com.ossnms.dcn_manager.core.entities.domain.DomainCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.google.common.collect.Iterables.isEmpty;
import static com.google.common.collect.Lists.transform;
import static com.ossnms.dcn_manager.connector.jpa.JpaExceptionsHelper.tryFindInChain;


public abstract class NetworkDomainRepository
        extends JpaSingleObjetEntityRepository<DomainInfoData, DomainInfoDb, DomainInfoMutationDescriptor>
        implements DomainRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(NetworkDomainRepository.class);

    @Override
    public Optional<DomainInfoData> tryCreate(DomainCreationDescriptor descriptor) throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            final DomainInfoDb infoDb = new DomainInfoDb(descriptor.getName(), descriptor.isAutomaticNeActivationPermitted());
            tx.getEntityManager().persist(infoDb);
            return Optional.of(infoDb.build());
        } catch (final EntityExistsException exception) {
            LOGGER.warn("Found existing entity with same identity as {}", descriptor.getName());
            return Optional.empty();
        } catch (final PersistenceException exception) {
            if (tryFindInChain(exception, ConstraintViolationException.class).isPresent()) {
                LOGGER.warn("Found existing entity with same identity as {}", descriptor.getName());
                return Optional.empty();
            }
            throw new RepositoryException(exception);
        }
    }

    @Override
    public void delete(DomainDeletionDescriptor descriptor) throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();
            final DomainInfoDb infoDb = entityManager.find(DomainInfoDb.class, descriptor.getId());
            if (null != infoDb) {
                if (!isEmpty(queryChildrenNEs(infoDb.getDomainId()))) {
                    throw new RepositoryException("Domain must be empty to be deleted: {}", descriptor);
                }
                entityManager.remove(infoDb);
            }
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }
    }

    @Override
    public Optional<DomainInfoData> tryUpdate(DomainInfoMutationDescriptor mutation)
            throws RepositoryException {
        final DomainInfoData mutationTarget = mutation.getTarget();
        final DomainInfoData mutationResult = mutation.apply();
        final DomainInfoDb info = new DomainInfoDb(mutationTarget.getId(), mutationTarget.getVersion(),
                mutationResult.getName(), mutationResult.isAutomaticNeActivationPermitted());
        return tryUpdate(mutation, info);
    }

    @Override
    public Optional<DomainInfoData> tryUpdate(@Nonnull UowContext context, @Nonnull DomainInfoMutationDescriptor mutation) {
        final DomainInfoData mutationTarget = mutation.getTarget();
        final DomainInfoData mutationResult = mutation.apply();
        final DomainInfoDb info = new DomainInfoDb(mutationTarget.getId(), mutationTarget.getVersion(),
                mutationResult.getName(), mutationResult.isAutomaticNeActivationPermitted());
        return tryUpdate(context, mutation, info);
    }

    @Override
    public Iterable<DomainInfoData> queryAllForNE(int neId) {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final List<DomainInfoDb> result = tx.getEntityManager()
                    .createNamedQuery("DomainInfoDb.SELECT_ALL_FOR_NE", DomainInfoDb.class)
                    .setParameter("neId", neId)
                    .getResultList();
            return transform(result, DomainInfoDb.BUILDER);
        } catch (final PersistenceException e) {
            LOGGER.error("Failed to obtain domains for NE {}: {} {}", neId, e.getMessage(),
                    Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

    @Override
    public Iterable<DomainInfoData> queryNaturalDomainsForNE(int neId) {
        return queryForNE(neId, Membership.NATURAL);
    }

    @Override
    public Iterable<DomainInfoData> queryTransitiveDomainsForNE(int neId) {
        return queryForNE(neId, Membership.TRANSITIVE);
    }

    private Iterable<DomainInfoData> queryForNE(int neId, Membership membership) {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final List<DomainInfoDb> result = tx.getEntityManager()
                    .createNamedQuery("DomainInfoDb.SELECT_FOR_NE", DomainInfoDb.class)
                    .setParameter("neId", neId)
                    .setParameter("membership", membership)
                    .getResultList();
            return transform(result, DomainInfoDb.BUILDER);
        } catch (final PersistenceException e) {
            LOGGER.error("Failed to obtain domains for NE {}: {} {}", neId, e.getMessage(),
                    Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

    @Override
    public Iterable<Integer> queryChildrenNEs(int domainId) {
        try (CloseableEntityTransaction tx = getTransaction()) {
            return tx.getEntityManager()
                .createNamedQuery("DomainInfoDb.SELECT_DOMAIN_NES", Integer.class)
                .setParameter("domainId", domainId)
                .getResultList();
        } catch (final PersistenceException exception) {
            LOGGER.error("Failed to obtain children NEs for domain {}, using empty domain list: {} {}",
                    domainId, exception.getMessage(), Throwables.getStackTraceAsString(exception));
        }
        return Collections.emptyList();
    }

    @Override
    public boolean tryAddTransitiveNE(int domainId, int neId) throws RepositoryException {
        return tryAddNE(domainId, neId, Membership.TRANSITIVE);
    }

    @Override
    public boolean tryAddNaturalNE(int domainId, int neId) throws RepositoryException {
        return tryAddNE(domainId, neId, Membership.NATURAL);
    }

    private boolean tryAddNE(int domainId, int neId, Membership membership) throws RepositoryException {
        boolean result = false;
        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();
            final DomainInfoDb infoDb = entityManager.find(DomainInfoDb.class, domainId);
            if (null != infoDb) {
                entityManager.persist(new DomainNeMembershipDb(infoDb, neId, membership));
                result = true;
            }
        } catch (final PersistenceException exception) {
            if (tryFindInChain(exception, EntityExistsException.class).isPresent()) {
                return false;
            }
            throw new RepositoryException(exception);
        }
        return result;
    }

    @Override
    public boolean tryRemoveTransitiveNE(int domainId, int neId) throws RepositoryException {
        return tryRemoveNE(domainId, neId, Membership.TRANSITIVE);
    }

    @Override
    public boolean tryRemoveNaturalNE(int domainId, int neId) throws RepositoryException {
        return tryRemoveNE(domainId, neId, Membership.NATURAL);
    }

    private boolean tryRemoveNE(int domainId, int neId, Membership membership) throws RepositoryException {
        boolean result = false;
        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();
            final DomainNeMembershipDb domainMembership =
                entityManager.createNamedQuery("DomainInfoDb.SELECT_NE_MEMBERSHIP", DomainNeMembershipDb.class)
                    .setParameter("domainId", domainId)
                    .setParameter("neId", neId)
                    .setParameter("membership", membership)
                    .getSingleResult();
            entityManager.remove(domainMembership);
            result = true;
        } catch (final PersistenceException exception) {
            result = false;
            if (!tryFindInChain(exception, NoResultException.class).isPresent()) {
                throw new RepositoryException(exception);
            }
        }
        return result;
    }

    @Override
    public Optional<DomainInfoData> queryByName(String domainName)
            throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final DomainInfoDb result = tx.getEntityManager()
                    .createNamedQuery("DomainInfoDb.SELECT_BY_NAME", DomainInfoDb.class)
                    .setParameter("name", domainName)
                    .getSingleResult();
            return Optional.of(result.build());
        } catch (final NoResultException e) {
            return Optional.empty();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    protected Optional<DomainInfoData> fetchEntity(DomainInfoDb dbEntity)
            throws RepositoryException {
        return Optional.of(dbEntity.build());
    }

    @Override
    protected Class<DomainInfoDb> getDbClass() {
        return DomainInfoDb.class;
    }

    @Override
    protected String getFetchAllQueryName() {
        return "DomainInfoDb.SELECT_ALL";
    }

}
