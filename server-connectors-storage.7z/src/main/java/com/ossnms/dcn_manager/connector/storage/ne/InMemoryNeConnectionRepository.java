package com.ossnms.dcn_manager.connector.storage.ne;

import com.mysema.query.collections.CollQuery;
import com.mysema.query.collections.CollQueryFactory;
import com.ossnms.dcn_manager.composables.storage.InMemoryDomainObjectRepository;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.QNeConnectionData;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;

public class InMemoryNeConnectionRepository
        extends InMemoryDomainObjectRepository<NeConnectionData, NeConnectionMutationDescriptor>
        implements NeEntityRepository.NeConnectionRepository {

    @Override
    public CollQuery query(QNeConnectionData neConnection) {
        return CollQueryFactory.from(neConnection, queryAll());
    }

}
