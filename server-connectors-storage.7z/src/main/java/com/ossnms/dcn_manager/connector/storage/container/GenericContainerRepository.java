package com.ossnms.dcn_manager.connector.storage.container;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaSingleObjetEntityRepository;
import com.ossnms.dcn_manager.connector.storage.container.entities.ContainerInfoDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.ContainerNeAssignmentDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.ContainerSystemAssignmentDb;
import com.ossnms.dcn_manager.core.entities.container.RootContainerId;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.google.common.collect.Lists.transform;
import static com.ossnms.dcn_manager.connector.jpa.JpaExceptionsHelper.tryFindInChain;


public abstract class GenericContainerRepository
        extends JpaSingleObjetEntityRepository<ContainerInfo, ContainerInfoDb, ContainerInfoMutationDescriptor>
        implements ContainerRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(GenericContainerRepository.class);

    private static final String CONTAINER_ID_PARAM = "containerId";
    private static final String SYSTEM_CONTAINER_ID_PARAM = "systemContainerId";
    private static final String NE_ID_PARAM = "neId";

    @Override protected Class<ContainerInfoDb> getDbClass() {
        return ContainerInfoDb.class;
    }

    @Override protected String getFetchAllQueryName() {
        return "ContainerInfoDb.SELECT_ALL";
    }

    @Override protected Optional<ContainerInfo> fetchEntity(ContainerInfoDb dbEntity) throws RepositoryException {
        return Optional.of(dbEntity.build());
    }

    protected Optional<NeAssignmentData> fetchEntity(ContainerNeAssignmentDb dbEntity) throws RepositoryException {
        return Optional.of(dbEntity.build());
    }

    protected Optional<SystemAssignmentData> fetchEntity(ContainerSystemAssignmentDb dbEntity) throws RepositoryException {
        return Optional.of(dbEntity.build());
    }

    /**
     * {@inheritDoc}
     */
    @Override public ContainerInfo create(ContainerCreationDescriptor descriptor) throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            final ContainerInfoDb infoDb = new ContainerInfoDb(descriptor);
            tx.getEntityManager().persist(infoDb);
            return infoDb.build();
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public void delete(ContainerDeletionDescriptor descriptor) throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();
            final ContainerInfoDb infoDb = entityManager.find(ContainerInfoDb.class, descriptor.getId());
            if (null != infoDb) {
                entityManager.remove(infoDb);
            }
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public Optional<ContainerInfo> tryUpdate(ContainerInfoMutationDescriptor mutation)
            throws RepositoryException {
        final ContainerInfo mutationTarget = mutation.getTarget();
        final ContainerInfo mutationResult = mutation.apply();
        final ContainerInfoDb info = new ContainerInfoDb(mutationTarget.getId(), mutationTarget.getVersion(),
                mutationResult.getParentId(), mutationResult.getName());
        info.setContainerDescription(mutationResult.getDescription());
        info.setContainerUserText(mutationResult.getUserText());
        return tryUpdate(mutation, info);
    }

    /**
     * {@inheritDoc}
     */
    @Override public Optional<ContainerInfo> tryUpdate(@Nonnull UowContext context,
                                                     @Nonnull ContainerInfoMutationDescriptor mutation) {
        final ContainerInfo mutationTarget = mutation.getTarget();
        final ContainerInfo mutationResult = mutation.apply();
        final ContainerInfoDb info = new ContainerInfoDb(mutationTarget.getId(), mutationTarget.getVersion(),
                mutationResult.getParentId(), mutationResult.getName());
        info.setContainerDescription(mutationResult.getDescription());
        info.setContainerUserText(mutationResult.getUserText());
        return tryUpdate(context, mutation, info);
    }

    /**
     * {@inheritDoc}
     */
    @Override public Optional<ContainerInfo> queryByName(@Nonnull String systemName) throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final ContainerInfoDb result = tx.getEntityManager()
                    .createNamedQuery("ContainerInfoDb.SELECT_BY_NAME", ContainerInfoDb.class)
                    .setParameter("name", systemName).getSingleResult();
            return Optional.of(result.build());
        } catch (final NoResultException e) {
            return Optional.empty();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public ContainerInfo getRootContainer() throws RepositoryException {
        final Optional<ContainerInfo> rootContainer = query(RootContainerId.ID.get());

        if (rootContainer.isPresent()) {
            return rootContainer.get();
        } else {
            throw new RepositoryException("Root Container Must be defined on Repository");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public void addNeAssignment(@Nonnull final NeAssignmentData neAssignmentData)
            throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();
            entityManager.persist(new ContainerNeAssignmentDb(neAssignmentData));
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public void addSystemAssignment(@Nonnull final SystemAssignmentData systemAssignmentData)
            throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();
            entityManager.persist(new ContainerSystemAssignmentDb(systemAssignmentData));
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public boolean tryUpdateNeAssignment(@Nonnull final NeAssignmentData neAssignmentData) throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();

            final ContainerNeAssignmentDb neAssignmentDb = new ContainerNeAssignmentDb(neAssignmentData);

            final ContainerNeAssignmentDb found = entityManager
                    .find(ContainerNeAssignmentDb.class, neAssignmentDb.getContainerNeKey());

            if (null != found) {
                return entityManager.merge(neAssignmentDb).build() != null;
            } else {
                LOGGER.warn("Tried to update insisting object with {}", neAssignmentDb);
                return false;
            }
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public boolean tryUpdateSystemAssignment(@Nonnull final SystemAssignmentData systemAssignmentData) throws RepositoryException {
        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();

            final ContainerSystemAssignmentDb assignmentDb = new ContainerSystemAssignmentDb(systemAssignmentData);

            final ContainerSystemAssignmentDb found = entityManager
                    .find(ContainerSystemAssignmentDb.class, assignmentDb.getContainerSystemKey());

            if (null != found) {
                return entityManager.merge(assignmentDb).build() != null;
            } else {
                LOGGER.warn("Tried to update insisting object with {}", assignmentDb);
                return false;
            }
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public boolean tryRemoveNeAssignment(@Nonnull final NeAssignmentData neAssignmentData) throws RepositoryException {
        boolean removed;

        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();
            final ContainerNeAssignmentDb containerNeAssignment = entityManager
                    .createNamedQuery("ContainerNeAssignmentDb.SELECT_BY_NE_AND_CONTAINER",
                            ContainerNeAssignmentDb.class)
                    .setParameter(NE_ID_PARAM, neAssignmentData.getNeId())
                    .setParameter(CONTAINER_ID_PARAM, neAssignmentData.getContainerInfo().getId())
                    .getSingleResult();
            entityManager.remove(containerNeAssignment);
            removed = true;
        } catch (final PersistenceException exception) {
            removed = false;
            if (!tryFindInChain(exception, NoResultException.class).isPresent()) {
                throw new RepositoryException(exception);
            }
        }

        return removed;
    }

    /**
     * {@inheritDoc}
     */
    @Override public boolean tryRemoveSystemAssignment(@Nonnull final SystemAssignmentData systemAssignmentData)
            throws RepositoryException {
        boolean removed;

        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();
            final ContainerSystemAssignmentDb containerSystemAssignment = entityManager
                    .createNamedQuery("ContainerSystemAssignmentDb.SELECT_BY_SYSTEM_AND_CONTAINER",
                            ContainerSystemAssignmentDb.class)
                    .setParameter(SYSTEM_CONTAINER_ID_PARAM, systemAssignmentData.getSystemContainerId())
                    .setParameter(CONTAINER_ID_PARAM, systemAssignmentData.getContainerInfo().getId())
                    .getSingleResult();
            entityManager.remove(containerSystemAssignment);
            removed = true;
        } catch (final PersistenceException exception) {
            removed = false;
            if (!tryFindInChain(exception, NoResultException.class).isPresent()) {
                throw new RepositoryException(exception);
            }
        }

        return removed;
    }

    /**
     * {@inheritDoc}
     */
    @Override public Iterable<NeAssignmentData> queryAllByNE(final int neId) {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final List<ContainerNeAssignmentDb> result = tx.getEntityManager()
                    .createNamedQuery("ContainerNeAssignmentDb.SELECT_ALL_BY_NE", ContainerNeAssignmentDb.class)
                    .setParameter(NE_ID_PARAM, neId)
                    .getResultList();
            return transform(result, ContainerNeAssignmentDb.BUILDER);
        } catch (final PersistenceException e) {
            LOGGER.error("Failed to obtain Containers for NE {}: {} {}", neId, e.getMessage(),
                    Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public Iterable<SystemAssignmentData> queryAllBySystem(final int systemContainerId) {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final List<ContainerSystemAssignmentDb> result = tx.getEntityManager()
                    .createNamedQuery("ContainerSystemAssignmentDb.SELECT_ALL_BY_SYSTEM", ContainerSystemAssignmentDb.class)
                    .setParameter(SYSTEM_CONTAINER_ID_PARAM, systemContainerId)
                    .getResultList();
            return transform(result, ContainerSystemAssignmentDb.BUILDER);
        } catch (final PersistenceException e) {
            LOGGER.error("Failed to obtain Containers for System {}: {} {}", systemContainerId, e.getMessage(),
                    Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public Optional<SystemAssignmentData> querySystemAssignment(int systemContainerId, int containerId)
            throws RepositoryException{
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final ContainerSystemAssignmentDb result = tx.getEntityManager()
                    .createNamedQuery("ContainerSystemAssignmentDb.SELECT_BY_SYSTEM_AND_CONTAINER",
                            ContainerSystemAssignmentDb.class)
                    .setParameter(SYSTEM_CONTAINER_ID_PARAM, systemContainerId)
                    .setParameter(CONTAINER_ID_PARAM, containerId)
                    .getSingleResult();

            return Optional.of(result.build());
        } catch (final NoResultException e) {
            return Optional.empty();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public Optional<NeAssignmentData> queryNeAssignment(int neId, int containerId) throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final ContainerNeAssignmentDb result = tx.getEntityManager()
                    .createNamedQuery("ContainerNeAssignmentDb.SELECT_BY_NE_AND_CONTAINER",
                            ContainerNeAssignmentDb.class)
                    .setParameter(NE_ID_PARAM, neId)
                    .setParameter(CONTAINER_ID_PARAM, containerId)
                    .getSingleResult();

            return Optional.of(result.build());
        } catch (final NoResultException e) {
            return Optional.empty();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public Iterable<Integer> queryAllNeIdByContainer(int containerId) {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            return tx.getEntityManager()
                    .createNamedQuery("ContainerNeAssignmentDb.SELECT_ALL_NES_IN_CONTAINER", Integer.class)
                    .setParameter(CONTAINER_ID_PARAM, containerId)
                    .getResultList();
        } catch (final PersistenceException e) {
            LOGGER.error("Failed to obtain NEs for Container {}: {} {}", containerId, e.getMessage(),
                    Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override public Iterable<Integer> queryAllSystemIdByContainer(int containerId) {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            return tx.getEntityManager()
                    .createNamedQuery("ContainerSystemAssignmentDb.SELECT_ALL_SYSTEM_BY_CONTAINER", Integer.class)
                    .setParameter(CONTAINER_ID_PARAM, containerId)
                    .getResultList();
        } catch (final PersistenceException e) {
            LOGGER.error("Failed to obtain Systems for Container {}: {} {}", containerId, e.getMessage(),
                    Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }
}
