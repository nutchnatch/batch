package com.ossnms.dcn_manager.connector.storage.ne.entities;

import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoPrototype;

import javax.annotation.Nonnull;

public class NeInfoDb extends NeInfoPrototype<NeInfoDb>
        implements BusinessObjectDb<NeInfoData> {

    private int neId;
    private int channelId;
    private int version;

    public NeInfoDb() {

    }

    public NeInfoDb(int neId, int channelId, int version, @Nonnull NeInfoData copy) {
        this.neId = neId;
        this.channelId = channelId;
        this.version = version;

        setCoreId(copy.getCoreId());
        setIconId(copy.getIconId());
        setProxyType(copy.getProxyType());
        setUsedBy(copy.getUsedBy());
        setCommsLostAlarmRaised(copy.isCommsLostAlarmRaised());
        setRequiredActivationState(copy.getRequiredActivationState());
    }

    public NeInfoDb(int channelId, @Nonnull NeInfoPrototype<?> other) {
        super(other);

        this.channelId = channelId;
    }

    @Override
    public NeInfoData build() {
        return new NeInfoData(neId, channelId, version, this);
    }

    @Override
    protected NeInfoDb self() {
        return this;
    }

}
