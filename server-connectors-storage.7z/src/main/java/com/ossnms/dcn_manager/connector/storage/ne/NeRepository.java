package com.ossnms.dcn_manager.connector.storage.ne;

import com.google.common.base.Predicate;
import com.google.common.base.Supplier;
import com.google.common.collect.FluentIterable;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaAggregateEntityRepository;
import com.ossnms.dcn_manager.connector.jpa.JpaUnitOfWork;
import com.ossnms.dcn_manager.connector.storage.StartableRepository;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeEntityDb;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeInfoDb;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.QNeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.uow.UnitOfWork;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import java.util.List;
import java.util.Optional;

import static com.google.common.collect.Iterables.filter;
import static com.google.common.collect.Iterables.transform;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * JPA NE repository implementation.
 */
public abstract class NeRepository
        extends JpaAggregateEntityRepository<NeEntity, NeEntityDb>
        implements NeEntityRepository, StartableRepository {

    private static final Logger LOGGER = getLogger(NeRepository.class);

    private JpaNeInfoRepository infoRepo;
    private InMemoryNeConnectionRepository connectionRepo;
    private JpaNeOperationRepository operationRepo;
    private JpaNeUserPreferencesRepository preferencesRepo;
    private JpaNeGatewayRouteRepository routeRepo;
    private JpaNeSynchronizationRepository synchronizationRepo;

    protected void initialize(@Nonnull Supplier<CloseableEntityTransaction> transactionSupplier) {
        infoRepo = new JpaNeInfoRepository(transactionSupplier);
        connectionRepo = new InMemoryNeConnectionRepository();
        operationRepo = new JpaNeOperationRepository(transactionSupplier);
        preferencesRepo = new JpaNeUserPreferencesRepository(transactionSupplier);
        routeRepo = new JpaNeGatewayRouteRepository(transactionSupplier);
        synchronizationRepo = new JpaNeSynchronizationRepository(transactionSupplier);
    }

    /**
     * {@inheritDoc}
     * <p>Ensures that volatile repositories that need to be consistent with their persisted counterparts
     * are populated.</p>
     */
    @Override
    public void start() throws RepositoryException {
        LOGGER.info("Starting NE Repository (JPA).");

        final Iterable<Integer> existingIds = infoRepo.queryAllEntityIdentifiers();
        for (final Integer id : existingIds) {
            final NeConnectionData connection = new NeConnectionBuilder().build(id, 0);
            connectionRepo.insert(connection);
        }

    }

    @Override
    public <A> UnitOfWork<A> unitOfWork(A accumulator) {
        return new JpaUnitOfWork<>(accumulator, this::getTransaction);
    }

    @Override
    protected Class<NeEntityDb> getDbClass() {
        return NeEntityDb.class;
    }

    @Override
    protected String getFetchAllQueryName() {
        return "NeEntityDb.FETCH_ALL";
    }

    @Override
    public NeInfoRepository getNeInfoRepository() {
        return getPhysicalNeInfoRepository();
    }

    @Override
    public NeConnectionRepository getNeConnectionRepository() {
        return getPhysicalNeConnectionRepository();
    }

    @Override
    public NeOperationRepository getNeOperationRepository() {
        return getPhysicalNeOperationRepository();
    }

    @Override
    public NeUserPreferencesRepository getNeUserPreferencesRepository() {
        return getPhysicalNeUserPreferencesRepository();
    }

    @Override
    public NeSynchronizationRepository getNeSynchronizationRepository() {
        return getPhysicalNeSynchronizationRepository();
    }

    @Override
    public NeGatewayRoutesRepository getNeGatewayRoutesRepository() {
        return getPhysicalNeGatewayRouteRepository();
    }

    @Override
    public Optional<String> queryNeName(int neId) throws RepositoryException {

        try (CloseableEntityTransaction tx = getTransaction()) {

            return Optional.of(tx.getEntityManager()
                .createNamedQuery("NeUserPreferencesDb.NE_NAME", String.class)
                .setParameter("neId", neId)
                .getSingleResult());

        } catch (final NoResultException exception) {
            return Optional.empty();
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }

    }

    @Override
    public Iterable<NeInfoData> queryActivationRequiredIs(int parentChannelId, @Nonnull RequiredActivationState active)
            throws RepositoryException {

        try (CloseableEntityTransaction tx = getTransaction()) {

            final List<NeInfoDb> dbResults = tx.getEntityManager()
                .createNamedQuery("NeInfoDb.INFO_BY_STATE_UNDER_CHANNEL", NeInfoDb.class)
                .setParameter("channelId", parentChannelId)
                .setParameter("reqState", active)
                .getResultList();

            return transform(dbResults, getPhysicalNeInfoRepository().getDataBuilder());

        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }

    }

    @Override
    public Iterable<NeInfoData> queryActualActivationIsDifferentThan(int parentChannelId, @Nonnull ActualActivationState active)
            throws RepositoryException {
        final Iterable<NeInfoData> channelChildren = getPhysicalNeInfoRepository().queryAll(parentChannelId);

        final Integer[] channelChildrenIds = FluentIterable.from(channelChildren)
            .transform(input -> null != input ? input.getNeId() : null)
            .toArray(Integer.class);
        final QNeConnectionData conn = QNeConnectionData.neConnectionData;
        final List<Integer> neIdsInDesiredState =
            getPhysicalNeConnectionRepository().query(conn)
                .where(conn.activationState.ne(active).and(conn.id.in(channelChildrenIds)))
                .list(conn.id);

        return filter(channelChildren, new Predicate<NeInfoData>() {
            @Override
            public boolean apply(NeInfoData input) {
                return null != input && neIdsInDesiredState.contains(input.getNeId());
            }
        });
    }

    @Override
    public NeEntity create(NeCreateDescriptor createEvent) throws RepositoryException {

        final NeInfoData info;
        final NeConnectionData connection;
        final NeOperationData operation;
        final NeSynchronizationData sync;
        final NeUserPreferencesData preferences;

        try (CloseableEntityTransaction tx = getTransaction()) {

            info = getPhysicalNeInfoRepository().insert(tx, createEvent.getChannelId(), createEvent.getInfo());
            operation = getPhysicalNeOperationRepository().insert(tx, info.getNeId(), createEvent.getOperation());
            sync = getPhysicalNeSynchronizationRepository().insert(tx, info.getNeId(), createEvent.getSynchronization());
            preferences = getPhysicalNeUserPreferencesRepository().insert(tx, info.getNeId(), createEvent.getPreferences());

            getPhysicalNeGatewayRouteRepository().insert(tx, info.getNeId(), createEvent.getGatewayRoutes());

        } catch (final PersistenceException ex) {
            throw new RepositoryException(ex);
        }

        connection = new NeConnectionData(info.getNeId(), info.getVersion(), createEvent.getConnection());
        getPhysicalNeConnectionRepository().insert(connection);

        return new NeEntity(connection, operation, info, sync, preferences);
    }

    @Override
    public void delete(NeDeleteDescriptor descriptor) throws RepositoryException {
        final int neId = descriptor.getId();
        try (CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager entityManager = tx.getEntityManager();
            final NeEntityDb entityDb = entityManager.find(NeEntityDb.class, neId);
            if (null != entityDb) {
                entityManager.remove(entityDb);
            }
        } catch (final PersistenceException ex) {
            throw new RepositoryException(ex);
        }

        getPhysicalNeConnectionRepository().remove(neId);
    }

    @Override
    public Optional<NeEntity> queryNe(int neId) throws RepositoryException {
        return query(neId);
    }

    /**
     * Helper method that gathers the remaining domain object instances associated to the domain entity
     * @param neDb The object representing the part of the entity to be retrieved that is stored in
     *  the database
     * @return An {@link Optional} bearing the retrieved entity, if one exists
     * @throws RepositoryException When an error occurs while working with the
     *  underlying data storage.
     */
    @Override
    protected Optional<NeEntity> fetchEntity(NeEntityDb neDb) throws RepositoryException
    {
        final int entityId = neDb.getNeId();
        final Optional<NeConnectionData> neConnection = getPhysicalNeConnectionRepository().query(entityId);

        return neConnection.isPresent() ?
                Optional.of(new NeEntity(
                        neConnection.get(),
                        getPhysicalNeOperationRepository().getDataBuilder().apply(neDb.getOperation()),
                        getPhysicalNeInfoRepository().getDataBuilder().apply(neDb.getInfo()),
                        getPhysicalNeSynchronizationRepository().getDataBuilder().apply(neDb.getSynchronization()),
                        getPhysicalNeUserPreferencesRepository().getDataBuilder().apply(neDb.getPreferences()))) :
                Optional.empty();
    }

    protected JpaNeInfoRepository getPhysicalNeInfoRepository() {
        return infoRepo;
    }

    protected InMemoryNeConnectionRepository getPhysicalNeConnectionRepository() {
        return connectionRepo;
    }

    protected JpaNeOperationRepository getPhysicalNeOperationRepository() {
        return operationRepo;
    }

    protected JpaNeUserPreferencesRepository getPhysicalNeUserPreferencesRepository() {
        return preferencesRepo;
    }

    protected JpaNeSynchronizationRepository getPhysicalNeSynchronizationRepository() {
        return synchronizationRepo;
    }

    protected JpaNeGatewayRouteRepository getPhysicalNeGatewayRouteRepository() {
        return routeRepo;
    }

}
