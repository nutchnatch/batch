package com.ossnms.dcn_manager.connector.storage.ne;

import com.google.common.base.Function;
import com.google.common.base.Supplier;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSet.Builder;
import com.google.common.collect.Iterables;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaUnitOfWorkContext;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeConnectionRouteDb;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeConnectionRouteDbKey;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeConnectionRouteDbKey.Type;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeGatewayRouteDb;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.core.utils.GuavaCollectors;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nonnull;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static com.google.common.collect.Iterables.isEmpty;
import static java.util.stream.StreamSupport.stream;

/**
 * Implementation of the NE gateway routes repository, based on a JPA-compatible storage provider.
 */
public class JpaNeGatewayRouteRepository
        implements NeGatewayRoutesRepository {

    private static final int QUERY_DEFAULT_BLOCK_SIZE = 1000;

    public static final class BuildInfoDataFromDb implements Function<NeGatewayRouteDb, NeGatewayRouteData> {

        @Override
        public NeGatewayRouteData apply(NeGatewayRouteDb input) {
            return null != input ? input.build() : null;
        }

    }

    private final BuildInfoDataFromDb dataBuilder = new BuildInfoDataFromDb();
    private final Supplier<CloseableEntityTransaction> transactionSupplier;

    public JpaNeGatewayRouteRepository(@Nonnull Supplier<CloseableEntityTransaction> transactionSupplier) {
        this.transactionSupplier = transactionSupplier;
    }

    public BuildInfoDataFromDb getDataBuilder() {
        return dataBuilder;
    }

    public ImmutableSet<NeGatewayRouteData> insert(@Nonnull CloseableEntityTransaction tx, int neId,
            @Nonnull Collection<NeGatewayRouteBuilder> gatewayRoutes) {
        final Builder<NeGatewayRouteData> setBuilder = ImmutableSet.builder();
        final EntityManager entityManager = tx.getEntityManager();

        for (final NeGatewayRouteBuilder routeBuilder : gatewayRoutes) {
            final NeGatewayRouteDb routeDb = new NeGatewayRouteDb(neId, routeBuilder);
            entityManager.persist(routeDb);
            setBuilder.add(dataBuilder.apply(routeDb));
        }

        return setBuilder.build();
    }

    @Override
    public Iterable<NeGatewayRouteData> queryRoutes(int neId) throws RepositoryException {
        return Optional.ofNullable(queryRoutes(ImmutableSet.of(neId)).get(neId)).orElse(ImmutableList.of()) ;
    }

    @Override
    public ImmutableMap<Integer, Iterable<NeGatewayRouteData>> queryRoutes(@Nonnull ImmutableSet<Integer> neIds) throws RepositoryException {
        Objects.requireNonNull("neIds must not be null");

        if (neIds.isEmpty()){
            return ImmutableMap.of();
        }

        //partitioning neIds set in chunks with maximum size of QUERY_DEFAULT_BLOCK_SIZE.
        final Iterable<List<Integer>> partitions = Iterables.partition(neIds, QUERY_DEFAULT_BLOCK_SIZE);

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            return ImmutableMap.copyOf(stream(partitions.spliterator(), false).map(ids -> query(tx, ids))
                    .flatMap(Collection::stream)
                    .collect(Collectors.groupingBy(NeGatewayRouteData::getId, GuavaCollectors.toImmutableList())));

        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }
    }


    //
    public List<NeGatewayRouteData> query(CloseableEntityTransaction tx, int neid) {
        return query(tx, ImmutableSet.of(neid));
    }


    /**
     * Attempts to find all gateway routes associated for a specific NE ids.
     *
     * @param tx An open JPA transaction.
     * @param neIds The Set containing the ne ids.
     * @return The target NE collection of routes.
     */
    private List<NeGatewayRouteData> query(CloseableEntityTransaction tx, Iterable<Integer> neIds) {

        final List<NeGatewayRouteDb> gtwRoutesFromDb = tx.getEntityManager()
                .createNamedQuery("NeGatewayRouteDb.SELECT_BY_NE_IDS", NeGatewayRouteDb.class)
                .setParameter("neIds", neIds)
                .getResultList();

        return gtwRoutesFromDb.stream().map(NeGatewayRouteDb::build).collect(Collectors.toList());
    }


    @Override
    public Iterable<NeGatewayRouteData> updateRoutes(int neId, Iterable<NeGatewayRouteMutationDescriptor> routesToUpdate)
            throws RepositoryException {
        // fast path
        if (isEmpty(routesToUpdate)) {
            return Collections.emptyList();
        }

        final Builder<NeGatewayRouteData> builder = ImmutableSet.builder();

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final EntityManager entityManager = tx.getEntityManager();

            for (final NeGatewayRouteMutationDescriptor descriptor : routesToUpdate) {
                final NeGatewayRouteData routeData = descriptor.apply();
                if (descriptor.getKey().isPresent() &&
                    !Objects.equals(descriptor.getKey().get(), descriptor.getTarget().getKey())) {
                    deleteRoute(entityManager, descriptor.getTarget().getKey());
                }
                entityManager.merge(new NeGatewayRouteDb(routeData));
                builder.add(routeData);
            }

        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }

        for (final NeGatewayRouteMutationDescriptor descriptor : routesToUpdate) {
            descriptor.applied();
        }

        return builder.build();
    }

    @Override public NeGatewayRouteData updateRoute(UowContext ctx, int neId, NeGatewayRouteMutationDescriptor routeToUpdate) {
        final CloseableEntityTransaction tx = ((JpaUnitOfWorkContext) ctx).getTransaction();
        final EntityManager entityManager = tx.getEntityManager();
        final NeGatewayRouteData routeData = routeToUpdate.apply();
        if (routeToUpdate.getKey().isPresent() &&
                !Objects.equals(routeToUpdate.getKey().get(), routeToUpdate.getTarget().getKey())) {
            deleteRoute(entityManager, routeToUpdate.getTarget().getKey());
        }
        entityManager.merge(new NeGatewayRouteDb(routeData));
        return routeData;
    }

    @Override
    public NeGatewayRouteData createRoute(UowContext ctx, int neId, NeGatewayRouteMutationDescriptor routeToAdd) {
        final CloseableEntityTransaction tx = ((JpaUnitOfWorkContext) ctx).getTransaction();
        final EntityManager entityManager = tx.getEntityManager();
        final NeGatewayRouteData routeData = routeToAdd.apply();
        entityManager.persist(new NeGatewayRouteDb(routeData));
        return routeData;
    }

    @Override
    public void deleteRoute(UowContext ctx, String routeKey) {
        final CloseableEntityTransaction tx = ((JpaUnitOfWorkContext) ctx).getTransaction();
        final EntityManager entityManager = tx.getEntityManager();
        deleteRoute(entityManager, routeKey);
    }

    @Override
    public Iterable<NeGatewayRouteData> createRoutes(int neId, Iterable<NeGatewayRouteMutationDescriptor> routesToAdd)
            throws RepositoryException {
        // fast path
        if (isEmpty(routesToAdd)) {
            return Collections.emptyList();
        }

        final Builder<NeGatewayRouteData> builder = ImmutableSet.builder();

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final EntityManager entityManager = tx.getEntityManager();

            for (final NeGatewayRouteMutationDescriptor descriptor : routesToAdd) {
                final NeGatewayRouteData routeData = descriptor.apply();
                entityManager.persist(new NeGatewayRouteDb(routeData));
                builder.add(routeData);
            }

        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }

        for (final NeGatewayRouteMutationDescriptor descriptor : routesToAdd) {
            descriptor.applied();
        }

        return builder.build();
    }

    @Override
    public void deleteRoutes(Iterable<String> routeKeys)
            throws RepositoryException {
        // fast path
        if (isEmpty(routeKeys)) {
            return;
        }

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final EntityManager entityManager = tx.getEntityManager();

            for (final String key : routeKeys) {
                deleteRoute(entityManager, key);
            }

        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }

    }

    private void deleteRoute(EntityManager entityManager, String key) {
        final NeGatewayRouteDb existingRouteDb =
            entityManager.find(NeGatewayRouteDb.class,
                new NeConnectionRouteDbKey(Type.GATEWAY, key));
        if (null != existingRouteDb) {
            entityManager.remove(existingRouteDb);
        }
    }

    @Override
    @SuppressWarnings("rawtypes")
    public Set<Pair<String, Integer>> tryFindRouteKeys(@Nonnull Set<String> routeKeys)
            throws RepositoryException {
        // fast path
        if (routeKeys.isEmpty()) {
            return Collections.emptySet();
        }

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final List<NeConnectionRouteDb> routes = tx.getEntityManager()
                .createNamedQuery("NeConnectionRoute.FIND_KEYS", NeConnectionRouteDb.class)
                .setParameter("keys", routeKeys)
                .getResultList();

            return FluentIterable.from(routes)
                .transform(route -> Pair.of(route.getKey(), route.getNeId()))
                .toSet();

        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }

    }

    @Override
    public void renameRouteDomains(@Nonnull String previousName, @Nonnull String newName)
            throws RepositoryException {

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            tx.getEntityManager()
                    .createNamedQuery("NeConnectionRoute.RENAME_DOMAINS")
                    .setParameter("oldName", previousName)
                    .setParameter("newName", newName)
                    .executeUpdate();

        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }

    }
}
