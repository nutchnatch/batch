package com.ossnms.dcn_manager.connector.storage.ne.entities;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.connector.storage.ne.entities.NeConnectionRouteDbKey.Type;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionRouteData.NeConnectionRoutePrototype;

public abstract class NeConnectionRouteDb<E, T extends NeConnectionRouteDb<E, T>> extends
        NeConnectionRoutePrototype<E, T> {

    private final NeConnectionRouteDbKey routeKey = new NeConnectionRouteDbKey();

    private int neId;
    private int version;

    protected NeConnectionRouteDb(@Nonnull Type type) {
        this.routeKey.setType(type);
    }

    protected NeConnectionRouteDb(@Nonnull Type type, int neId, NeConnectionRoutePrototype<?, ?> other) {
        super(other);
        this.neId = neId;
        this.routeKey.setKey(super.getKey());
        this.routeKey.setType(type);
    }

    public int getNeId() {
        return neId;
    }

    public void setNeId(int neId) {
        this.neId = neId;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    protected NeConnectionRouteDbKey getRouteKey() {
        return routeKey;
    }

    @Override
    public T setKey(String key) {
        routeKey.setKey(key);
        return super.setKey(key);
    }

    @Override
    public final String getKey() { // NOPMD: increasing protected method visibility to public
        return routeKey.getKey();
    }
}
