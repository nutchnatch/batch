package com.ossnms.dcn_manager.connector.storage.domain.entities;

import com.google.common.base.Function;

/**
 * Association class between Domains and NEs. Allows to specify whether
 * this is a "natural" or "transitive" domain membership.
 */
public class DomainNeMembershipDb {

    private DomainNeKey associationKey;

    public DomainNeMembershipDb() {

    }

    public DomainNeMembershipDb(DomainInfoDb domain, int neId, Membership membership) {
        associationKey = new DomainNeKey(domain, neId, membership);
    }

    public DomainNeKey getAssociationKey() {
        return associationKey;
    }

    public void setAssociationKey(DomainNeKey associationKey) {
        this.associationKey = associationKey;
    }

    public static final Function<DomainNeMembershipDb, Integer> GET_NE_ID =
        new Function<DomainNeMembershipDb, Integer>() {
            @Override
            public Integer apply(DomainNeMembershipDb input) {
                return null != input ? input.getAssociationKey().getNeId() : null;
            }
        };
}
