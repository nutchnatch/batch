package com.ossnms.dcn_manager.connector.jpa;

import com.ossnms.dcn_manager.core.storage.uow.UnitOfWorkImplBase;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;

import static com.ossnms.dcn_manager.connector.jpa.JpaExceptionsHelper.tryFindInChain;

import java.util.Collection;
import java.util.function.Supplier;

public class JpaUnitOfWork<A> extends UnitOfWorkImplBase<A> {

    private final Supplier<CloseableEntityTransaction> transactionSupplier;

    public JpaUnitOfWork(A accumulator, Supplier<CloseableEntityTransaction> transactionSupplier) {
        super(accumulator);
        this.transactionSupplier = transactionSupplier;
    }

    @Override
    protected void executeSteps(Collection<UnitOfWorkImplBase<A>.UowStep<?>> uowSteps) throws DcnManagerException {
        try (JpaUnitOfWorkContext ctx = new JpaUnitOfWorkContext(transactionSupplier.get())) {
            for (UowStep<?> step : uowSteps) {
                try {
                    step.execute(ctx);
                } catch (final RuntimeException | DcnManagerException e) {
                    ctx.getTransaction().setRollbackOnly();
                    throw e;
                }
            }
        } catch (OptimisticLockException l) {
            throw new DataUpdateException(l);
        } catch (PersistenceException e) {
            if (tryFindInChain(e, OptimisticLockException.class).isPresent()) {
                throw new DataUpdateException(e);
            }            
			throw new RepositoryException(e); 
		}
    }

}
