package com.ossnms.dcn_manager.connector.storage.mediator;

import com.google.common.base.Supplier;
import com.google.common.collect.AbstractIterator;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.storage.StartableRepository;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import java.util.Iterator;
import java.util.Optional;

import static com.google.common.collect.Iterables.filter;
import static org.slf4j.LoggerFactory.getLogger;

public abstract class MediatorRepository implements MediatorEntityRepository, StartableRepository {

    private static final Logger LOGGER = getLogger(MediatorRepository.class);

    private MediatorInstanceRepository instanceRepository;

    private InMemoryMediatorConnectionRepository connectionRepo;
    private JpaMediatorInfoRepository infoRepo;

    private Supplier<CloseableEntityTransaction> transactionSupplier;


    @Override
    public MediatorEntity create(MediatorCreateDescriptor descriptor) throws RepositoryException {

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            // We use the Mediator Info repository as the authority for the existence of the Domain Entity.
            final MediatorInfoData info = infoRepo.insert(tx, descriptor.getInfoInitialData());

            for (final MediatorInstanceCreateDescriptor instanceCreateDescriptor : descriptor.getInstanceCreateDescriptors()) {
                instanceRepository.create(tx, info.getId(), instanceCreateDescriptor);
            }

            final MediatorConnectionData connection =
                    new MediatorConnectionData(info.getId(), info.getVersion(), descriptor.getConnectionInitialData());
            connectionRepo.insert(connection);

            return new MediatorEntity(info, connection);
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void delete(MediatorDeleteDescriptor descriptor) throws RepositoryException {
        final int entityId = descriptor.getId();

        final Iterable<MediatorPhysicalData> instancesData = filter(
                instanceRepository.getMediatorPhysicalDataRepository().queryAll(),
                input -> input != null && input.getLogicalMediatorId() == entityId);

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            // Signal the removal of the domain entity instance by first removing from
            // the Mediator Info repository (see comments on the implementation of the create method)
            infoRepo.remove(tx, entityId);

            connectionRepo.remove(entityId);

            for (final MediatorPhysicalData data : instancesData) {
                instanceRepository.delete(tx, new MediatorInstanceDeleteDescriptor(data.getId()));
            }

        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public MediatorInfoRepository getMediatorInfoRepository() {
        return infoRepo;
    }

    @Override
    public MediatorConnectionRepository getMediatorConnectionRepository() {
        return connectionRepo;
    }

    @Override
    public Optional<MediatorEntity> query(int mediatorId) throws RepositoryException {
        // Again, the order is important to ensure that only benign race conditions may occur
        final Optional<MediatorInfoData> info = infoRepo.query(mediatorId);
        if (!info.isPresent()) {
            return Optional.empty();
        }

        return fetchMediatorEntityFromMediatorInfo(info.get());
    }

    @Override
    public Iterable<MediatorEntity> queryAll() throws RepositoryException {
        final Iterable<MediatorInfoData> allInfos = infoRepo.queryAll();
        return new Iterable<MediatorEntity>() {
            @Override
            public Iterator<MediatorEntity> iterator() {
                // Retain weak-consistent view of the current repo contents
                final Iterator<MediatorInfoData> sourceIterator = allInfos.iterator();
                return new AbstractIterator<MediatorEntity>() {
                    @Override
                    protected MediatorEntity computeNext() {
                        // Fetch next valid entity, if one exists
                        while (sourceIterator.hasNext()) {
                            final Optional<MediatorEntity> nextEntity = fetchMediatorEntityFromMediatorInfo(sourceIterator.next());
                            if (nextEntity.isPresent()) {
                                return nextEntity.get();
                            }
                        }
                        return endOfData();
                    }
                };
            }
        };
    }

    @Override
    public Optional<String> queryMediatorName(int id) throws RepositoryException {

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            return Optional.of(tx.getEntityManager()
                    .createNamedQuery("MediatorInfoDb.MEDIATOR_NAME", String.class)
                    .setParameter("mediatorId", id)
                    .getSingleResult());

        } catch (final NoResultException exception) {
            return Optional.empty();
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }

    }

    /**
     * Helper method that gathers the remaining domain object instances associated to the domain entity
     * that has the given mediator info
     *
     * @param mediatorInfo The object representing the mediator info part of the entity to be retrieved
     * @return An {@link Optional} bearing the retrieved entity, if one exists
     */
    private Optional<MediatorEntity> fetchMediatorEntityFromMediatorInfo(MediatorInfoData mediatorInfo) {
        final int entityId = mediatorInfo.getId();
        final Optional<MediatorConnectionData> connection = connectionRepo.query(entityId);

        return connection.isPresent() ?
                Optional.of(new MediatorEntity(mediatorInfo, connection.get())) :
                Optional.empty();
    }

    protected void initialize(@Nonnull Supplier<CloseableEntityTransaction> transactionSupplier, @Nonnull MediatorInstanceRepository instanceRepository) {
        this.transactionSupplier = transactionSupplier;
        this.instanceRepository = instanceRepository;
        connectionRepo = new InMemoryMediatorConnectionRepository();
        infoRepo = new JpaMediatorInfoRepository(transactionSupplier);
    }

    @Override
    public void start() throws RepositoryException {
        LOGGER.info("Starting Mediator Repository (JPA).");

        final Iterable<Integer> existingMediatorIds = infoRepo.queryAllEntityIdentifiers();
        for (final Integer mediatorId : existingMediatorIds) {
            final MediatorConnectionData connection = new MediatorConnectionBuilder().build(mediatorId, 0);
            connectionRepo.insert(connection);
        }
    }

}
