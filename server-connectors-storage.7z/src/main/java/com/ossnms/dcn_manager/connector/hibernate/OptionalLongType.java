package com.ossnms.dcn_manager.connector.hibernate;

import org.hibernate.type.LongType;

public final class OptionalLongType extends OptionalTypes<Long> {

    public OptionalLongType() {
        super(LongType.INSTANCE);
    }

}