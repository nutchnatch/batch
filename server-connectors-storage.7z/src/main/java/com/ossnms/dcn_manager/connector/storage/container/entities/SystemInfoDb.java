package com.ossnms.dcn_manager.connector.storage.container.entities;

import com.ossnms.dcn_manager.core.entities.container.system.SystemCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import org.apache.commons.lang3.builder.EqualsBuilder;

import javax.annotation.Nonnull;
import java.util.Objects;
import java.util.Optional;

public class SystemInfoDb extends BaseContainerInfoDb<SystemInfo> {
    private static final long serialVersionUID = 6555417815268472860L;

    public SystemInfoDb() {

    }

    public SystemInfoDb(int systemId, int version, @Nonnull String systemName) {
        super(systemId, version, Optional.empty(), systemName);
    }

    public SystemInfoDb(@Nonnull SystemCreationDescriptor descriptor) {
        super(descriptor.getName());
        setContainerDescription(descriptor.getDescription());
        setContainerUserText(descriptor.getUserText());
    }

    @Override public SystemInfo build() {
        return new SystemInfo(getContainerId(), getVersion(), getContainerName(), getContainerDescription(),
                getContainerUserText());
    }

    @Override public int hashCode() {
        return Objects.hash(getContainerId(), getVersion(), getContainerName());
    }

    @Override public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final SystemInfoDb rhs = (SystemInfoDb) obj;
        return new EqualsBuilder()
                .append(getContainerId(), rhs.getContainerId())
                .append(getVersion(), rhs.getVersion())
                .append(getContainerName(), rhs.getContainerName())
                .isEquals();
    }
}
