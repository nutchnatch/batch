package com.ossnms.dcn_manager.connector.storage.settings;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.storage.StartableRepository;
import com.ossnms.dcn_manager.connector.storage.settings.entities.GlobalSettingsDb;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettingsMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;

import java.util.Optional;

import static com.google.common.base.Preconditions.checkState;
import static com.ossnms.dcn_manager.connector.jpa.JpaExceptionsHelper.tryFindInChain;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * DCN Manager configuration repository implementation that stores its information in a
 * database managed with JPA.
 */
public abstract class JpaSettingsRepositoryConnector implements SettingsRepository, StartableRepository {

    private static final Logger LOGGER = getLogger(JpaSettingsRepositoryConnector.class);
    private static final int FIXED_SETTINGS_IDENTIFIER = 6; // the first perfect number (http://mathworld.wolfram.com/PerfectNumber.html)

    private volatile GlobalSettings settings;

    protected abstract CloseableEntityTransaction getTransaction();

    @Override
    public void start() throws RepositoryException {
        LOGGER.info("Starting Settings Repository (JPA).");

        try (final CloseableEntityTransaction tx = getTransaction()) {
            final GlobalSettingsDb settingsDb =
                    tx.getEntityManager().find(GlobalSettingsDb.class, FIXED_SETTINGS_IDENTIFIER);
            settings = Optional.ofNullable(settingsDb)
                    .orElse(injectStartupLimit(new GlobalSettingsDb(FIXED_SETTINGS_IDENTIFIER, 0)))
                    .toGlobalSettings();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }
    
    protected abstract GlobalSettingsDb injectStartupLimit(GlobalSettingsDb globalSettingsDb);
    
    /**
     * @throws IllegalStateException If the repository has not been started.
     */
    @Override
    public GlobalSettings getSettings() {
        checkState(null != settings, "Settings repository not started!");
        return settings;
    }

    @Override
    public Optional<GlobalSettings> tryUpdateSettings(GlobalSettingsMutationDescriptor mutation) throws RepositoryException {
        GlobalSettingsDb newSettings;
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final GlobalSettingsDb dbEntity = new GlobalSettingsDb(mutation.apply());
            newSettings = tx.getEntityManager().merge(dbEntity);
        } catch (final OptimisticLockException e) {
            LOGGER.warn("Tried to update out-of-date settings with {}", mutation);
            return Optional.empty();
        } catch (final PersistenceException e) {
            if (tryFindInChain(e, OptimisticLockException.class).isPresent()) {
                LOGGER.warn("Tried to update out-of-date settings with {}", mutation);
                return Optional.empty();
            }

            LOGGER.warn("Failed to update settings with {}: {}", mutation, Throwables.getStackTraceAsString(e));
            throw new RepositoryException(e);
        }
        settings = newSettings.toGlobalSettings();
        mutation.applied();
        return Optional.of(settings);
    }

}
