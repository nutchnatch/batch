package com.ossnms.dcn_manager.connector.storage.ne.entities;

import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationPrototype;

import javax.annotation.Nonnull;

/**
 * Database object mapping for {@link NeSynchronizationData} entities.
 */
public class NeSynchronizationDb extends NeSynchronizationPrototype<NeSynchronizationDb>
        implements BusinessObjectDb<NeSynchronizationData> {

    private int neId;
    private int version;

    /**
     * Creates a new instance.
     * Used by the ORM layer to create objects before populating them.
     */
    public NeSynchronizationDb() {

    }

    /**
     * Creates a new instance with data from an existing entity.
     * Used to update objects in the ORM layer.
     *
     * @param id NE identifier.
     * @param version Object version, used for optimistic locking.
     * @param copy Entity used as the data source.
     */
    public NeSynchronizationDb(int id, int version, @Nonnull NeSynchronizationData copy) {
        neId = id;
        this.version = version;

        setAlarms(copy.getAlarms());
        setAll(copy.getAll());
        setPacket(copy.getPacket());
    }

    /**
     * Creates a new instance with data from an existing creation descriptor.
     * Used to create objects in the ORM layer.
     *
     * @param id NE identifier.
     * @param copy Entity prototype, used as the data source.
     */
    public NeSynchronizationDb(int id, @Nonnull NeSynchronizationPrototype<?> copy) {
        super(copy);
        neId = id;
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.connector.storage.BusinessObjectDb#build()
     */
    @Override
    public NeSynchronizationData build() {
        return new NeSynchronizationData(neId, version, this);
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationPrototype#self()
     */
    @Override
    protected NeSynchronizationDb self() {
        return this;
    }

}
