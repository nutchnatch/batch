package com.ossnms.dcn_manager.connector.storage.ne.entities;

import java.io.Serializable;

import javax.annotation.Nonnull;

import com.google.common.base.Objects;

public class NeConnectionRouteDbKey implements Serializable {

    public enum Type {
        GATEWAY, DIRECT
    }

    private static final long serialVersionUID = 164285515111303728L;

    private String key;
    private String type;

    public NeConnectionRouteDbKey() {

    }

    public NeConnectionRouteDbKey(@Nonnull Type type, @Nonnull String key) {
        this.type = type.name();
        this.key = key;
    }

    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public void setType(Type type) {
        this.type = type.name();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(key, type);
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !obj.getClass().equals(getClass())) {
            return false;
        }
        final NeConnectionRouteDbKey other = (NeConnectionRouteDbKey) obj;
        return Objects.equal(key, other.key) && Objects.equal(type, other.type);
    }

}