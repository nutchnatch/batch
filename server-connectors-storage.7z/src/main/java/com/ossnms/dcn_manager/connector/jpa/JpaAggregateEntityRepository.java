package com.ossnms.dcn_manager.connector.jpa;

import com.google.common.collect.AbstractIterator;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.LoggerFactory;

import javax.persistence.PersistenceException;
import java.util.Iterator;
import java.util.Optional;

/**
 * <p>Base implementation of a JPA repository of Aggregate Entities. These are entities
 * that aggregate all business entities that form a logical entity.</p>
 *
 * <p>This implementation uses template methods instead of parameters supplied at
 * construction time because we want to support usage patters that do not allow
 * usage of constructors with parameters.</p>
 *
 * @param <E> Aggregate entity concrete type.
 * @param <D> Concrete type of the aggregate entity database representation.
 */
public abstract class JpaAggregateEntityRepository<E, D> {

    private static final String HIBERNATE_JDBC_FETCH_SIZE_HINT = "org.hibernate.fetchSize";
    private static final int FETCH_SIZE = 500;

    private final class AllEntitiesIterable implements Iterable<E> {
        private final Iterable<D> allDbEntities;

        private AllEntitiesIterable(Iterable<D> allDbEntities) {
            this.allDbEntities = allDbEntities;
        }

        @Override
        public Iterator<E> iterator() {
            // Retain weak-consistent view of the current repo contents
            final Iterator<D> sourceIterator = allDbEntities.iterator();
            return new AbstractIterator<E>() {
                @Override
                protected E computeNext() {
                    // Fetch next valid entity, if one exists
                    while(sourceIterator.hasNext()) {
                        try {
                            final Optional<E> nextEntity = fetchEntity(sourceIterator.next());
                            if(nextEntity.isPresent()) {
                                return nextEntity.get();
                            }
                        } catch (final RepositoryException ex) {
                            break;
                        }
                    }
                    return endOfData();
                }
            };
        }
    }

    /**
     * Gets the Business Entity instance with the given identifier, if one exists
     * @param id The Business Entity identifier.
     * @return An {@link Optional} instance bearing the Business Entity instance, or an
     * absent {@link Optional} if no Business Entity exists with the given identifier.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    public Optional<E> query(int id) throws RepositoryException {

        try (CloseableEntityTransaction tx = getTransaction()) {
            final D dbEntity = tx.getEntityManager().find(getDbClass(), id);
            if (null == dbEntity) {
                LoggerFactory.getLogger(getClass())
                    .warn("No {} entity found with ID {}", getDbClass().getSimpleName(), id);
            } else {
                return fetchEntity(dbEntity);
            }
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }

        return Optional.empty();
    }

    /**
     * Retrieves all Entity instances present in the repository.
     * @return An instance of an iterable over all known Entity instances.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    public Iterable<E> queryAll() throws RepositoryException {

        final Iterable<D> allDbEntities;
        try (CloseableEntityTransaction tx = getTransaction()) {
            allDbEntities = tx.getEntityManager()
                .createNamedQuery(getFetchAllQueryName(), getDbClass())
                    .setHint(HIBERNATE_JDBC_FETCH_SIZE_HINT, FETCH_SIZE)
                .getResultList();
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }

        return new AllEntitiesIterable(allDbEntities);
    }

    /**
     * @return A new transaction that can be used to interact with the database.
     */
    protected abstract CloseableEntityTransaction getTransaction();

    /**
     * Helper method that gathers the remaining domain object instances associated to the domain entity
     * @param dbEntity The object representing the part of the entity to be retrieved that is stored in
     *  the database
     * @return An {@link Optional} bearing the retrieved entity, if one exists
     * @throws RepositoryException When an error occurs while working with the
     *  underlying data storage.
     */
    protected abstract Optional<E> fetchEntity(D dbEntity) throws RepositoryException;

    /**
     * @return The persisted object class information.
     */
    protected abstract Class<D> getDbClass();

    /**
     * @return The name of the query that allows to fetch all known aggregate entities.
     */
    protected abstract String getFetchAllQueryName();

}
