package com.ossnms.dcn_manager.connector.storage.ne;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaDomainObjectRepository;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeSynchronizationDb;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

/**
 * Concrete implementation of a JPA repository to store instances of {@link NeSynchronizationData}.
 */
public class JpaNeSynchronizationRepository
    extends JpaDomainObjectRepository<NeSynchronizationData, NeSynchronizationMutationDescriptor, NeSynchronizationDb, NeSynchronizationInitialData>
    implements NeEntityRepository.NeSynchronizationRepository {

    /**
     * Creates a new repository instance.
     */
    public JpaNeSynchronizationRepository(@Nonnull Supplier<CloseableEntityTransaction> transactionSupplier) {
        super(NeSynchronizationDb.class, transactionSupplier, "NeSynchronizationDb.SELECT_ALL");
    }

    @Override
    protected NeSynchronizationDb buildDatabaseObjectForUpdate(NeSynchronizationData targetObject, NeSynchronizationData mutationResult) {
        return new NeSynchronizationDb(targetObject.getId(), targetObject.getVersion(), mutationResult);
    }

    @Override
    protected NeSynchronizationDb buildDatabaseObjectForInsert(int parentId, NeSynchronizationInitialData initialData) {
        return new NeSynchronizationDb(parentId, initialData);
    }

    @Override
    public void clearAllSynchronizationData() throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            final EntityManager manager = tx.getEntityManager();
            manager.createNamedQuery("NeSynchronizationDb.CLEAR_ALL_SYNC_DATA")
                    .executeUpdate();
        } catch (PersistenceException e) {
            throw new RepositoryException(e);
        }
    }
}
