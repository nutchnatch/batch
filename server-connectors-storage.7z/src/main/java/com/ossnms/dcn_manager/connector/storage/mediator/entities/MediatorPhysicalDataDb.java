package com.ossnms.dcn_manager.connector.storage.mediator.entities;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataPrototype;

public class MediatorPhysicalDataDb extends MediatorPhysicalDataPrototype<MediatorPhysicalDataDb> implements BusinessObjectDb<MediatorPhysicalData> {

    private int id;
    private int logicalMediatorId;
    private int versionNumber;

    public MediatorPhysicalDataDb() {

    }

    /** Data copy, allowing to change the ID and version number. */
    public MediatorPhysicalDataDb(int id, int versionNumber, @Nonnull MediatorPhysicalData copy) {
        this.id = id;
        this.logicalMediatorId = copy.getLogicalMediatorId();
        this.versionNumber = versionNumber;

        setPriority(copy.getPriority());
        setHost(copy.getHost());
    }

    public MediatorPhysicalDataDb(@Nonnull MediatorPhysicalDataPrototype<?> objectPrototype) {
        super(objectPrototype);
    }

    public MediatorPhysicalDataDb(int logicalId, @Nonnull MediatorPhysicalDataPrototype<?> objectPrototype) {
        super(objectPrototype);
        this.logicalMediatorId = logicalId;
    }

    @Override
    public MediatorPhysicalData build() {
        return new MediatorPhysicalData(id, logicalMediatorId, versionNumber, this);
    }

    @Override
    protected MediatorPhysicalDataDb self() {
        return this;
    }

    /**
     * @return Physical Mediator instance ID.
     */
    public int getId() {
        return id;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("id", id)
                .append("logicalId", logicalMediatorId)
                .append("versionNumber", versionNumber)
                .appendSuper(super.toString())
                .toString();
    }

}