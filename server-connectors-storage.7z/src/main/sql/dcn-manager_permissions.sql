-- Add permission Items
BEGIN
	DECLARE
		addPermissionItemVar NUMBER;
		PRODUCT_NAME varchar2(25):= '@PRODUCT_NAME@';
        PRODUCT_NCT varchar2(25) := 'TNMS NCT';
	BEGIN
	-- emNeManager
	addPermissionItemVar := USMPERMISSIONITEMADD('activate EM','Activate DCN Channel');
    addPermissionItemVar := USMPERMISSIONITEMADD('activate NE','Activate NE');
    addPermissionItemVar := USMPERMISSIONITEMADD('add usage','Show the Used By information');
	addPermissionItemVar := USMPERMISSIONITEMADD('Administration->System Preferences->Network Settings','Network Settings');
    addPermissionItemVar := USMPERMISSIONITEMADD('create EM','Create EM');
    addPermissionItemVar := USMPERMISSIONITEMADD('create NE','Create NE');
    addPermissionItemVar := USMPERMISSIONITEMADD('deactivate EM','Deactivate EM');
    addPermissionItemVar := USMPERMISSIONITEMADD('deactivate NE','Deactivate NE');
    addPermissionItemVar := USMPERMISSIONITEMADD('delete EM','Delete EM');
    addPermissionItemVar := USMPERMISSIONITEMADD('delete NE','Delete NE');
    addPermissionItemVar := USMPERMISSIONITEMADD('File->Export Configuration->EM/NE Objects','Export EMNE Objects');
    addPermissionItemVar := USMPERMISSIONITEMADD('File->Import Configuration->EM/NE Objects','Import EMNE Objects');
    addPermissionItemVar := USMPERMISSIONITEMADD('modify element manager settings','Manage the DCN Channel settings');
    addPermissionItemVar := USMPERMISSIONITEMADD('modify network element settings','Manage the NE settings');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Activate All NEs in EM','Activate All Nes in EM');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Activate Mediators','Activate Mediators');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Activate EMs','Activate EMs ');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Activate NEs','Activate NEs ');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Copy NE Name into ID Name','Copy the NE Network Name into the NE Name');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Cut (and Paste)','Allow Cut and Paste');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Deactivate All NEs in EM','Deactivate All Nes in EM');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Deactivate Mediators','Deactivate Mediators');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Deactivate EMs','Deactivate EMs');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Deactivate NEs','Deactivate NEs');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Delete','Delete Object');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Drag NE','Drag and Drop NE Object');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Duplicate','Duplicate EM/NE Object');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Find','Find Object in DCN the Management Tree');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Management','Open DCN Management Window');
	addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Table View','Open DCN Table View');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Move NE','Move NE');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Move Channel','Move Channel');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Move System Container','Move System Container');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Move NE Container','Move NE Container');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->New (AS)','New AS');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->New (Mediator)','New Mediator');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->New (EM)','New EM');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->New (NE)','New NE');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->New (SC)','New System Container');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->New (NE Container)','New NE Container');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Print','DCN Management Print ');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Properties','DCN Object Properties');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Mediator Properties','Open Mediator Properties');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->EM Properties','Open EM Properties');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Container Properties','Container Properties');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Resynchronize Data','Resynchronize NE Data');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Save As','DCN "Save As" Option');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Server Properties','TNMS Server Object Properties');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->State Summary','State Summary');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Mediator Properties - Read Only','Open Mediator properties in read-only mode');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->EM Properties - Read Only','Open Channel properties in read-only mode');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Properties - Read Only','Open NE properties in read-only mode');
    addPermissionItemVar := USMPERMISSIONITEMADD('Network->DCN->Container Properties - Read Only','Open Container properties in read-only mode');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Access Control->Connect','Connect NE');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Access Control->Disconnect','Disconnect NE');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Access Control->Enforce Write Access','NE Enforce Write Access');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Access Control->Release Write Access','NE Release Write Access');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Access Control->Request Write Access','NE Request Write Access');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Discovery Permitted','Enable Auto-Discover');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Maintenance Mode->Maintenance','Set NE to Maintenance Mode');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Maintenance Mode->Operation','Set NE to Operation Mode');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Resyncronize Data','Resynchronize NE Data');
    addPermissionItemVar := USMPERMISSIONITEMADD('Object Context Menu->Set to Active Mode','Set NE to Active Mode');
    addPermissionItemVar := USMPERMISSIONITEMADD('release usage','Release Usage');
    addPermissionItemVar := USMPERMISSIONITEMADD('set NE data transfer settings','Set the SFTP settings for the NE');
    addPermissionItemVar := USMPERMISSIONITEMADD('shutdown EM/NE','Shutdown the EM/NE component');
    addPermissionItemVar := USMPERMISSIONITEMADD('start synchronization','Start NE Synchronization');
	addPermissionItemVar := USMPERMISSIONITEMADD('DCN-Manager->System Preferences','DCN System Preferences');
	

    IF PRODUCT_NAME != PRODUCT_NCT THEN
		addPermissionItemVar := USMPERMISSIONITEMADD('Administration->Import From Core->Scheduled DCN','Schedule DCN Import from Core');
    END IF;

	END;
END;
/
BEGIN
	DECLARE
		vboolean BOOLEAN;
		PRODUCT_NAME varchar2(25):='@PRODUCT_NAME@';
        PRODUCT_NCT varchar2(25) := 'TNMS NCT';
	BEGIN
	-- emNeManager
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','activate EM');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','activate NE');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','add usage');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Administration->System Preferences->Network Settings');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','create EM');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','create NE');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','deactivate EM');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','deactivate NE');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','delete EM');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','delete NE');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','File->Export Configuration->EM/NE Objects');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','File->Import Configuration->EM/NE Objects');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','modify element manager settings');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','modify network element settings');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Activate All NEs in EM');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Activate Mediators');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Activate EMs');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Activate NEs');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Copy NE Name into ID Name');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Cut (and Paste)');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Deactivate All NEs in EM');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Deactivate Mediators');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Deactivate EMs');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Deactivate NEs');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Delete');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Drag NE');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Duplicate');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->New (NE Container)');
	vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Network->DCN->Mediator Properties - Read Only');
    vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Network->DCN->EM Properties - Read Only');
    vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Network->DCN->Properties - Read Only');
    vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Network->DCN->Container Properties - Read Only');
	vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Network->DCN->Find');
	vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Network->DCN->Management');
	vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Network->DCN->Table View');
	vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Network->DCN->Resynchronize Data');
	vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Network->DCN->State Summary');
	vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Object Context Menu->Access Control->Release Write Access');
	vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Object Context Menu->Access Control->Request Write Access');
	vboolean := USMPERMISSIONITEMASSIGN('Network Supervision','Object Context Menu->Resyncronize Data');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Move NE');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Move Channel');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Move System Container');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Move NE Container');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->New (AS)');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->New (Mediator)');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->New (EM)');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->New (NE)');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->New (SC)');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Print');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Properties');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Save As');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Server Properties');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Object Context Menu->Access Control->Connect');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Object Context Menu->Access Control->Disconnect');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Object Context Menu->Access Control->Enforce Write Access');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Object Context Menu->Discovery Permitted');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Object Context Menu->Maintenance Mode->Maintenance');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Object Context Menu->Maintenance Mode->Operation');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Object Context Menu->Set to Active Mode');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','release usage');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','set NE data transfer settings');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','shutdown EM/NE');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','start synchronization');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Mediator Properties');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->EM Properties');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Network->DCN->Container Properties');
	vboolean := USMPERMISSIONITEMASSIGN('Network Administration','DCN-Manager->System Preferences');

    IF PRODUCT_NAME != PRODUCT_NCT THEN
		vboolean := USMPERMISSIONITEMASSIGN('Network Administration','Administration->Import From Core->Scheduled DCN');
    END IF;
	
		IF ISTNMSDX() = 1 THEN
		vboolean := USMPERMISSIONITEMASSIGN('INC Readonly','Network->DCN->Management');
	END IF;

	END;
END;
/