package com.company;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import javax.crypto.*;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Key;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class TestEncryption {

    @Test
    public void testEncryptDecrypt() {
        try{
            // First, we need a key; we'll just generate one
            // though we could look one up in the keystore or
            // obtain one via a key agreement algorithm.
            KeyGenerator kg = KeyGenerator.getInstance("DES");
            Cipher c = Cipher.getInstance("DES/CBC/PKCS5Padding");
            Key key = kg.generateKey( );
            // Now we'll do the encryption. We'll also retrieve
            // the initialization vector, which the engine will
            // calculate for us.
            c.init(Cipher.ENCRYPT_MODE, key);
            byte input[] = "Stand and unfold yourself".getBytes( );
            byte encrypted[] = c.doFinal(input);
            byte iv[] = c.getIV( );
            // Now we'll do the decryption. The initialization
            // vector can be transmitted to the recipient with
            // the ciphertext, but the key must be transmitted
            // securely.
            IvParameterSpec dps = new IvParameterSpec(iv);
            c.init(Cipher.DECRYPT_MODE, key, dps);
            byte output[] = c.doFinal(encrypted);
            System.out.println("The string was ");
            System.out.println(new String(output));
        } catch (Exception e) {
            e.printStackTrace( );
        }
    }

    @Test
    public void encryptCipher() {
        try {
            KeyGenerator kg = KeyGenerator.getInstance("DES");
            kg.init(new SecureRandom( ));
            SecretKey key = kg.generateKey( );
            SecretKeyFactory skf = SecretKeyFactory.getInstance("DES");
            Class spec = Class.forName("javax.crypto.spec.DESKeySpec");
            DESKeySpec ks = (DESKeySpec) skf.getKeySpec(key, spec);
            ObjectOutputStream oos = new ObjectOutputStream(
                    new FileOutputStream("keyfile"));
            oos.writeObject(ks.getKey( ));
            Cipher c = Cipher.getInstance("DES/CBC/PKCS5Padding");
            c.init(Cipher.ENCRYPT_MODE, key);
            CipherOutputStream cos = new CipherOutputStream(
                    new FileOutputStream("ciphertext"), c);

            Path path = Paths.get("Java_Security_2nd_Edition.pdf");
            byte[] data = Files.readAllBytes(path);

//            byte[] data = "Folks and destin".getBytes();
            cos.write(data);
            cos.flush();
            cos.close();
//            PrintWriter pw = new PrintWriter(
//                    new OutputStreamWriter(cos));
//            pw.println("Stand and unfold yourself");
//            pw.close( );
            oos.writeObject(c.getIV( ));
            oos.close( );
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Test
    public void decryptCipher() {
        try {
            ObjectInputStream ois = new ObjectInputStream(
                    new FileInputStream("keyfile"));
            DESKeySpec ks = new DESKeySpec((byte[]) ois.readObject( ));
            SecretKeyFactory skf = SecretKeyFactory.getInstance("DES");
            SecretKey key = skf.generateSecret(ks);
            Cipher c = Cipher.getInstance("DES/CBC/PKCS5Padding");
            c.init(Cipher.DECRYPT_MODE, key,
                    new IvParameterSpec((byte[]) ois.readObject( )));
            CipherInputStream cis = new CipherInputStream(
                    new FileInputStream("ciphertext"), c);
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(cis));
            System.out.println("Got message");
//            System.out.println(br.readLine( ));

            List<Byte> values = new ArrayList<>();
            int nextByte;
            while ((nextByte = cis.read()) != -1) {
                values.add((byte) nextByte);
            }

            byte[] bytes = new byte[values.size()];
            for (int i = 0; i < bytes.length; i++) {
                bytes[i] = values.get(i);
            }

            Path path = Paths.get("outputfile.pdf");
            Files.write(path, bytes);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}