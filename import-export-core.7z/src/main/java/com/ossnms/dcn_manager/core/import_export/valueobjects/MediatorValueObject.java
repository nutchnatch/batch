package com.ossnms.dcn_manager.core.import_export.valueobjects;

import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

@Immutable public interface MediatorValueObject extends Serializable {

    @Parameter String getName();

    @Parameter String getType();

    @Parameter String getHost();

    @Parameter Collection<MediatorInstanceValueObject> getMediatorInstances();

    Optional<Integer> getMediatorId();
    Optional<Integer> getReconnectInterval();

    Optional<Integer> getConcurrentActivationsLimit();

    Optional<Boolean> getConcurrentActivationsLimited();

    Optional<String> getDescription();

    //todo user text

    Map<String, String> getPropertyBag();
}
