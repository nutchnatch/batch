package com.ossnms.dcn_manager.core.import_export.valueobjects;

import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;

import java.io.Serializable;

@Immutable public interface MediatorInstanceValueObject extends Serializable {

    @Parameter String getHost();

    @Parameter Integer getPriority();
}
