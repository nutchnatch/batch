package com.ossnms.dcn_manager.core.import_export.valueobjects;

import java.util.Optional;

import org.immutables.value.Value.Immutable;

@Immutable public interface NeAdditionalInfo {
	
	Optional<String> getEonType();
	
	Optional<String> getLocalInterface();
	
	Optional<String> getLocalInterfaceMask();
	
	Optional<String> getManagementInterface();
	
	Optional<String> getManagementInterfaceMask();
	
	Optional<String> getRouterInterface();
	
	Optional<String> getRouterInterfaceMask();
	
	Optional<String> getDcnInterface();
	
	Optional<String> getDcnInterfaceMask();
	
	Optional<String> getGateway();
	
	Optional<String> getNeSwVersion();
	
	Optional<String> getMountMode();
}
