package com.ossnms.dcn_manager.core.import_export.valueobjects;

import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;

import java.io.Serializable;
import java.util.Map;
import java.util.Optional;

@Immutable public interface ChannelValueObject extends Serializable {

    @Parameter String getName();

    @Parameter String getType();

    @Parameter MediatorValueObject getMediator();

    Map<String, String> getPropertyBag();

    Optional<Integer> getChannelId();

    Optional<Integer> getConcurrentActivationsLimit();

    Optional<Boolean> getConcurrentActivationsLimited();
}
