/**
 * <b>Import/Export Value Objects</b> to be possible transform the Entities from any import flow(TNMS CORE, EM/NE legacy,...) 
 * to a canonical value object.
 */
package com.ossnms.dcn_manager.core.import_export.valueobjects;
