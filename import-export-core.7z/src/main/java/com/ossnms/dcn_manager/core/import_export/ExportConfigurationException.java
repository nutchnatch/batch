package com.ossnms.dcn_manager.core.import_export;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * ExportConfigurationException thrown by #Exporter when an error occurs.
 */
public class ExportConfigurationException extends DcnManagerException {

    private static final long serialVersionUID = -6927775173048496950L;

    /** @see DcnManagerException#DcnManagerException() */
    public ExportConfigurationException() {

    }

    /** @see DcnManagerException#DcnManagerException(String) */
    public ExportConfigurationException(final String message) {
        super(message);
    }

    /** @see DcnManagerException#DcnManagerException(Throwable) */
    public ExportConfigurationException(final Throwable cause) {
        super(cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable) */
    public ExportConfigurationException(final String message, final Throwable cause) {
        super(message, cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,boolean,boolean) */
    public ExportConfigurationException(final String message, final Throwable cause, final boolean enableSuppression,
            final boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /** @see DcnManagerException#DcnManagerException(String, Object...) */
    public ExportConfigurationException(final String format, final Object... formatParameters) {
        super(format, formatParameters);
    }
}
