package com.ossnms.dcn_manager.core.import_export.valueobjects;

import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;

@Immutable public interface AssignedContainer {
    @Parameter String idName();

    @Parameter Boolean isPrimary();
}
