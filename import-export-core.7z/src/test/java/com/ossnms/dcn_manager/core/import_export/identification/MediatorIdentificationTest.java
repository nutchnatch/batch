package com.ossnms.dcn_manager.core.import_export.identification;

import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorInfoRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Test;

import java.util.List;
import java.util.Optional;

import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorValueObject.of;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MediatorIdentificationTest {

    @Test public void singletonOnHostIsPresent_shouldExist() throws Exception {
        List<MediatorType> installedTypes = asList(type("MVM", false));
        List<Mediator> persistedMediators = asList(mediator("name", "MVM", "127.0.0.1"));
        MediatorValueObject mediator = of("name", "MVM", "127.0.0.1", emptyList());

        boolean exists = idUsing(installedTypes, persistedMediators).exists(mediator);

        assertThat(exists, is(true));
    }

    @Test public void singletonOnHostIsNotPresent_shouldNotExist() throws Exception {
        List<MediatorType> installedTypes = asList(type("GM", false));
        List<Mediator> persistedMediators = asList(mediator("some name", "GM", "host"));
        MediatorValueObject mediator = of("any name", "GM", "wrong host", emptyList());

        boolean exists = idUsing(installedTypes, persistedMediators).exists(mediator);

        assertThat(exists, is(false));
    }

    @Test public void multipleOnHostIsPresent_shouldExist() throws Exception {
        List<MediatorType> installedTypes = asList(type("UNO", true));
        List<Mediator> persistedMediators = asList(mediator("name", "UNO", "host"));
        MediatorValueObject mediator = of("name", "UNO", "host", emptyList());

        boolean exists = idUsing(installedTypes, persistedMediators).exists(mediator);

        assertThat(exists, is(true));
    }

    @Test public void multipleOnHostIsAbsent_shouldNotExist() throws Exception {
        List<MediatorType> installedTypes = asList(type("UNO", true));
        List<Mediator> persistedMediators = asList(mediator("name", "UNO", "host"));
        MediatorValueObject mediator = of("another name", "UNO", "host", emptyList());

        boolean exists = idUsing(installedTypes, persistedMediators).exists(mediator);

        assertThat(exists, is(false));
    }

    @Test public void unknownType_shouldNotExist() throws Exception {
        List<MediatorType> installedTypes = emptyList();
        List<Mediator> persistedMediators = emptyList();
        MediatorValueObject mediator = of("name", "unknownType", "host", emptyList());

        boolean exists = idUsing(installedTypes, persistedMediators).exists(mediator);

        assertThat(exists, is(false));
    }

    private MediatorIdentification idUsing(List<MediatorType> installedTypes, List<Mediator> persistedMediators) throws Exception {
        return new MediatorIdentification(Types.from(installedTypes), repositoryWith(persistedMediators));
    }

    private MediatorInfoRepository repositoryWith(List<Mediator> persistedMediators) throws Exception {
        return new InfoRepo(persistedMediators);
    }

    private MediatorType type(String name, Boolean allowManyOnSameHost) {
        MediatorType type = mock(MediatorType.class);
        when(type.allowManyOnSameHost()).thenReturn(allowManyOnSameHost);
        when(type.getName()).thenReturn(name);
        return type;
    }

    private Mediator mediator(String name, String typeName, String host) {
        return new Mediator(host, new MediatorInfoBuilder()
                .setName(name)
                .setTypeName(typeName)
                .build(0, 0));
    }

    private static class Mediator {
        private final MediatorInfoData info;
        private final String host;

        Mediator(String host, MediatorInfoData info) {
            this.info = info;
            this.host = host;
        }
    }

    private static class InfoRepo implements MediatorInfoRepository {
        
        private final List<Mediator> mediators;

        InfoRepo(List<Mediator> mediators) {
            this.mediators = mediators;
        }

        @Override public Optional<MediatorInfoData> query(String mediatorName) throws RepositoryException {
            return mediators.stream()
                    .map(mediator -> mediator.info)
                    .filter(info -> info.getName().equals(mediatorName))
                    .findFirst();
        }

        @Override public Optional<MediatorInfoData> queryByHost(
                String mediatorType, String hostName) throws RepositoryException {
            return mediators.stream()
                    .filter(mediator -> mediator.host.equals(hostName))
                    .map(mediator -> mediator.info)
                    .filter(info -> info.getTypeName().equals(mediatorType))
                    .findFirst();
        }

        @Override public Optional<MediatorInfoData> query(int id) throws RepositoryException {
            return Optional.empty();
        }

        @Override public Iterable<MediatorInfoData> queryAll() throws RepositoryException {
            return emptyList();
        }

        @Override
        public Optional<MediatorInfoData> tryUpdate(MediatorInfoMutationDescriptor mutation) throws RepositoryException {
            return Optional.empty();
        }

        @Override public Optional<MediatorInfoData> tryUpdate(
                UowContext context, MediatorInfoMutationDescriptor mutation) {
            return Optional.empty();
        }
    }
}