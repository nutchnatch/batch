package com.ossnms.dcn_manager.core.utils;

import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;



public class IsPresentTest {

	private IsPresent<Optional<Integer>> predicate;
	
	@Before
	public void setUp() throws Exception {
		predicate = new IsPresent<>();
	}

	@Test
	public void apply_withANullInput_returnsFalse() {
		assertThat(predicate.apply(null), is(false));
	}

	@Test
	public void apply_withAnAbsentOptionalInput_returnsFalse() {
		assertThat(predicate.apply(Optional.empty()), is(false));
	}
	@Test
	public void apply_withAPresentOptional_returnsTrue() {
		final int someValue = 1;
		assertThat(predicate.apply(Optional.of(someValue)), is(true));
	}
}
