package com.ossnms.dcn_manager.core.properties.channel;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class ChannelPropertiesTest {

    private final ChannelProperties channelProperties = new ChannelProperties();

    private ChannelType type;

    private static final int CHANNEL_ID = 1;
    private static final int RECONNECT_INTERVAL = 600;
    private static final String CHANNEL_NAME = "Channel name";
    private static final boolean CONCURRENT_ACTIVATIONS_LIMITED = true;
    private static final int CONCURRENT_ACTIVATIONS_LIMIT = 24;

    private ChannelUserPreferencesData createAChannelUserPreferences(ImmutableMap<String, String> properties)
    {
    	final int VERSION = 1;
        return new ChannelUserPreferencesBuilder()
                        .setReconnectInterval(RECONNECT_INTERVAL)
                        .setName(CHANNEL_NAME)
                        .setConcurrentActivationsLimit(CONCURRENT_ACTIVATIONS_LIMIT)
                        .setConcurrentActivationsLimited(CONCURRENT_ACTIVATIONS_LIMITED)
                        .setProperties(properties)
                        .build(CHANNEL_ID, VERSION);
    }

    @Before
    public void setUp() {
        type = MockFactory.mockEmType();
    }

    @Test
    public void testGetProperties() {
        final Map<String, String> typeProperties = ImmutableMap.of("A", "A_VALUE");

        final ChannelUserPreferencesData channel = createAChannelUserPreferences(
        		ImmutableMap.of(
        				"START", "A:${property.A} B:${Property.B}",
        				"B", "${PROPERTY.C}-B",
        				"C", "C_VALUE"
        		)
        );

        when(type.getTypeProperties()).thenReturn(typeProperties);

        final Map<String, String> properties = channelProperties.getProperties(type, channel);
        assertThat(properties.size(), is(greaterThanOrEqualTo(8))); // this count will contain well-known properties as well.
        assertThat(properties, hasEntry("A", "A_VALUE"));
        assertThat(properties, hasEntry("B", "C_VALUE-B"));
        assertThat(properties, hasEntry("C", "C_VALUE"));
        assertThat(properties, hasEntry("START", "A:A_VALUE B:C_VALUE-B"));
        assertThat(properties, allOf(
                hasEntry(ChannelProperty.ID_NAME.getName(), CHANNEL_NAME),
                hasEntry(ChannelProperty.RECONNECT_INTERVAL.getName(), "600"),
                hasEntry(ChannelProperty.CONCURRENT_ACTIVATIONS_LIMIT.getName(), "24"),
                hasEntry(ChannelProperty.CONCURRENT_ACTIVATIONS_LIMITED.getName(), "true")));
        assertThat(properties, not(hasKey("UNKNOWN")));
    }

    @Test
    public void testGetProperty() {
        final Map<String, String> typeProperties = ImmutableMap.of("A", "A_VALUE");
        final ChannelUserPreferencesData channel = createAChannelUserPreferences(ImmutableMap.of("B", "B_VALUE"));

        when(type.getTypeProperties()).thenReturn(typeProperties);

        // TODO: verify (I removed the setReconnetInterval on the create descriptor)
        assertThat(channelProperties.getProperty(type, channel, "A").get(), is("A_VALUE"));
        assertThat(channelProperties.getProperty(type, channel, "B").get(), is("B_VALUE"));
        assertThat(channelProperties.getProperty(type, channel, "C").isPresent(), is(false));
        assertThat(channelProperties.getProperty(type, channel, ChannelProperty.ID_NAME.getName()).get(), is(CHANNEL_NAME));
        assertThat(channelProperties.getProperty(type, channel, ChannelProperty.ID_NAME).get(), is(CHANNEL_NAME));
        assertThat(channelProperties.getProperty(type, channel, ChannelProperty.RECONNECT_INTERVAL).get(), is(Integer.toString(RECONNECT_INTERVAL)));
        assertThat(channelProperties.getProperty(type, channel, ChannelProperty.CONCURRENT_ACTIVATIONS_LIMIT).get(), is(Integer.toString(CONCURRENT_ACTIVATIONS_LIMIT)));
        assertThat(channelProperties.getProperty(type, channel, ChannelProperty.CONCURRENT_ACTIVATIONS_LIMITED).get(), is(Boolean.toString(CONCURRENT_ACTIVATIONS_LIMITED)));
    }

    @Test
    public void testReplacePropertyVariablesWithoutPlaceholder() {

    	final Map<String, String> typeProperties = Collections.emptyMap();
        final ChannelUserPreferencesData channel = createAChannelUserPreferences(ImmutableMap.of("START", "no place holder"));

        when(type.getTypeProperties()).thenReturn(typeProperties);

        final String result = channelProperties.getProperty(type, channel, "START").get();
        assertThat(result, is("no place holder"));
    }

    @Test
    public void testReplacePropertyVariables() {
        final Map<String, String> typeProperties = ImmutableMap.of("A", "A_VALUE");
        final ChannelUserPreferencesData channel = createAChannelUserPreferences(
        			ImmutableMap.of(
        					"START", "A:${property.A} B:${Property.B} UNKNOWN:${Property.xpto}",
        					"B", "B_VALUE"
        			)
        		);

        when(type.getTypeProperties()).thenReturn(typeProperties);

        final String result = channelProperties.getProperty(type, channel, "START").get();
        assertThat(result, is("A:A_VALUE B:B_VALUE UNKNOWN:"));
    }

    @Test
    public void testReplacePropertyVariablesRecursively() {
        final Map<String, String> typeProperties = ImmutableMap.of("A", "A_VALUE");
        final ChannelUserPreferencesData channel = createAChannelUserPreferences(
    			ImmutableMap.of(
    					"START", "A:${property.A} B:${Property.B}",
    					"B", "${PROPERTY.C}",
    					"C", "C_VALUE"
    			)
    		);

        when(type.getTypeProperties()).thenReturn(typeProperties);

        final String result = channelProperties.getProperty(type, channel, "START").get();
        assertThat(result, is("A:A_VALUE B:C_VALUE"));
    }

    @Test
    public void testSetProperty() throws InvalidMutationException {

        final ChannelUserPreferencesBuilder builder = new ChannelUserPreferencesBuilder();

        channelProperties.setProperty(type, builder, "xpto", "val");
        channelProperties.setProperty(type, builder, ChannelProperty.ID_NAME, "new_name");
        channelProperties.setProperty(type, builder, ChannelProperty.RECONNECT_INTERVAL, "300");
        channelProperties.setProperty(type, builder, ChannelProperty.CONCURRENT_ACTIVATIONS_LIMIT, "66");
        channelProperties.setProperty(type, builder, ChannelProperty.CONCURRENT_ACTIVATIONS_LIMITED, "false");

        final ChannelUserPreferencesData data = builder.build(CHANNEL_ID, 1);
        assertThat(data.getName(), is("new_name"));
        assertThat(data.getAllOpaqueProperties().get("xpto"), is("val"));
        assertThat(data.getReconnectInterval(), is(300));
        assertThat(data.getConcurrentActivationsLimit(), is(66));
        assertThat(data.isConcurrentActivationsLimited(), is(false));
    }

    @Test
    public void testSetProperties() throws InvalidMutationException {

        final ChannelUserPreferencesBuilder builder = new ChannelUserPreferencesBuilder();

        channelProperties.setProperties(type, builder, ImmutableMap.of(
                "xpto", "val",
                ChannelProperty.ID_NAME.getName(), "new_name",
                ChannelProperty.CONCURRENT_ACTIVATIONS_LIMIT.getName(), "66",
                ChannelProperty.CONCURRENT_ACTIVATIONS_LIMITED.getName(), "false"));

        final ChannelUserPreferencesData data = builder.build(CHANNEL_ID, 1);
        assertThat(data.getName(), is("new_name"));
        assertThat(data.getConcurrentActivationsLimit(), is(66));
        assertThat(data.isConcurrentActivationsLimited(), is(false));
        assertThat(data.getAllOpaqueProperties().get("xpto"), is("val"));
    }

    @Test(expected=InvalidMutationException.class)
    public void testSetInvalidIdNameProperty() throws InvalidMutationException {
        final ChannelUserPreferencesBuilder builder = new ChannelUserPreferencesBuilder();
        channelProperties.setProperty(type, builder, ChannelProperty.ID_NAME, "");
    }

    @Test(expected=InvalidMutationException.class)
    public void testSetNullIdNameProperty() throws InvalidMutationException {
        final ChannelUserPreferencesBuilder builder = new ChannelUserPreferencesBuilder();
        channelProperties.setProperty(type, builder, ChannelProperty.ID_NAME, null);
    }

    @Test
    public void testSetTypeProperty_causesNoChanges() throws InvalidMutationException {
        final Map<String, String> typeProperties = ImmutableMap.of("A", "A_VALUE", "B", "B_VALUE");
        final ChannelUserPreferencesBuilder builder = new ChannelUserPreferencesBuilder();

        when(type.getTypeProperties()).thenReturn(typeProperties);

        channelProperties.setProperty(type, builder, "A", "NEW_A");

        final ChannelUserPreferencesData data = builder.build(CHANNEL_ID, 1);
        assertThat(data.getAllOpaqueProperties().isEmpty(), is(true));
    }

    @Test
    public void testToString() {
        assertThat(ChannelProperty.ID_NAME.toString(), not(nullValue()));
    }
}
