package com.ossnms.dcn_manager.core.policies.common;

import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

public class PrunableQueueTest {

    private PrunableQueue<Integer> queue;

    private int addToQueue(int startValue, int endValue) {
        int start = startValue;
        while(start != endValue) {
            queue.enqueue(start++);
        }
        return endValue - startValue;
    }

    @Before
    public void setUp() {
        queue = new PrunableQueue<>();
    }

    @Test
    public void getSize_onAnEmptyQueue_returnsZero() {
        assertThat(queue.getSize(), is(equalTo(0)));
    }

    @Test
    public void getSize_onANonEmptyQueue_returnsCorrectValue() {
        final int COUNT = 4;
        addToQueue(0, COUNT);
        assertThat(queue.getSize(), is(equalTo(COUNT)));
    }

    @Test
    public void dequeue_onAnEmptyQueue_returnsAbsentOptional() {
        final Optional<Integer> elem = queue.tryDequeue();
        assertFalse(elem.isPresent());
    }

    @Test
    public void dequeue_onANonEmptyQueue_returnsCorrectValue() {
        final Integer inItem = 1;
        queue.enqueue(inItem);
        final Optional<Integer> outItem = queue.tryDequeue();
        assertTrue(outItem.isPresent());
        assertThat(outItem.get(), is(equalTo(inItem)));
    }

    @Test
    public void dequeue_onANonEmptyQueue_withSelector_returnsCorrectValue() {
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        assertThat(queue.getSize(), is(3));
        final Optional<Integer> outItem = queue.tryDequeue(input -> input.equals(2));
        assertTrue(outItem.isPresent());
        assertThat(outItem.get(), is(equalTo(2)));
        assertThat(queue.getSize(), is(2));
    }

    @Test
    public void dequeue_onANonEmptyQueue_withNonMatchingSelector_returnsEmptyOptional() {
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        assertThat(queue.getSize(), is(3));
        final Optional<Integer> outItem = queue.tryDequeue(input -> input.equals(2222));
        assertFalse(outItem.isPresent());
        assertThat(queue.getSize(), is(3));
    }

    @Test
    public void prune_withANonMatchingSelector_returnsAbsentOptional() {
        final int COUNT = 4;
        addToQueue(0, COUNT);
        final Optional<Integer> item = queue.prune(input -> input.equals(COUNT + 1));

        assertFalse(item.isPresent());
        assertThat(queue.getSize(), is(equalTo(COUNT)));
    }

    @Test
    public void prune_withAMatchingSelector_removesElement() {
        final int COUNT = 4;
        addToQueue(0, COUNT);

        final int SELECTOR_VALUE = COUNT - 1;
        final Optional<Integer> item = queue.prune(input -> input.equals(SELECTOR_VALUE));

        assertTrue(item.isPresent());
        assertThat(item.get(), is(equalTo(SELECTOR_VALUE)));
        assertThat(queue.getSize(), is(equalTo(COUNT - 1)));
    }

    @Test
    public void pruneAll_withANonMatchingSelector_removesNothing() {
        final int COUNT = 4;
        addToQueue(0, COUNT);

        queue.pruneAll(input -> false);

        assertThat(queue.getSize(), is(equalTo(COUNT)));
    }

    @Test
    public void pruneAll_withAMatchingSelector_removesElements() {
        final int COUNT = 4;
        addToQueue(0, COUNT);

        queue.pruneAll(input -> true);

        assertThat(queue.getSize(), is(0));
    }

    @Test
    public void unorderedItems_areDequeuedInOrder() throws Exception {
        /*
         * The queue uses natural ordering.
         */
        queue.enqueue(1);
        queue.enqueue(3);
        queue.enqueue(2);

        assertThat(queue.tryDequeue().get(), is(1));
        assertThat(queue.tryDequeue().get(), is(2));
        assertThat(queue.tryDequeue().get(), is(3));
    }
}
