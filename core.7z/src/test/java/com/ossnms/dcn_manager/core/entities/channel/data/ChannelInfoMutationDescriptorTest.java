package com.ossnms.dcn_manager.core.entities.channel.data;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.core.entities.MutationDescriptorTestBase;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;

public class ChannelInfoMutationDescriptorTest extends MutationDescriptorTestBase<ChannelInfoData, ChannelInfoMutationDescriptor> {

	// The following string literal must match the one used in ChannelInfoMutationDescriptor.toString()
	// A public constant field was not used to prevent polluting the type's public interface
	private static final String ACTIVE_TO_STRING_KEY = "active";

	// Domain object's original values and mutation values, to verify mutation correctness
	private static final int MEDIATOR_ID = 10;
	private static final String CHANNEL_TYPE = "A channel type", CORE_ID = "A core id";
	private static final boolean ORIGINAL_ACTIVATION_STATUS = false;
	private static final boolean MUTATION_ACTIVATION_STATUS = true;

	@Before
	@Override
	public void setUp() throws Exception {
		final int ID = 1, VERSION = 1;
		domainObject = new ChannelInfoBuilder()
		    .setType(CHANNEL_TYPE)
		    .setCoreId(CORE_ID)
		    .setActivationRequired(ORIGINAL_ACTIVATION_STATUS)
		    .build(ID, VERSION, MEDIATOR_ID);
		emptyMutation = new ChannelInfoMutationDescriptor(domainObject);
		mutation = new ChannelInfoMutationDescriptor(domainObject).setActive(MUTATION_ACTIVATION_STATUS);
	}


	@Test
	public void apply_inAValidMutationDescriptor_producesTheCorrectMutation() {
		final ChannelInfoData result = mutation.apply();
		// ID and VERSION are already verified in inherited test methods
		assertThat(result.getMediatorId(), is(equalTo(MEDIATOR_ID)));
		assertThat(result.getType(), is(equalTo(CHANNEL_TYPE)));
		assertThat(result.getCoreId(), is(equalTo(CORE_ID)));
		assertThat(result.isActivationRequired(), is(MUTATION_ACTIVATION_STATUS));
	}

	@Test
	public void toString_onANonEmptyMutation_returnsStringWithMutationInfo() {
		assertThat(mutation.toString(), containsString(ACTIVE_TO_STRING_KEY));
	}

	@Test
	public void toString_onAnEmptyMutation_returnsStringWithoutThatMutationInfo() {
		assertThat(emptyMutation.toString(), not(containsString(ACTIVE_TO_STRING_KEY)));
	}
}
