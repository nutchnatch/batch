package com.ossnms.dcn_manager.core.configuration.model;

import com.ossnms.dcn_manager.core.configuration.loaders.XmlConfiguration;
import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.core.jaxb.netype.Config;
import com.ossnms.dcn_manager.core.jaxb.netype.Mappings;
import com.ossnms.dcn_manager.core.jaxb.netype.Properties;
import com.ossnms.dcn_manager.core.jaxb.netype.Route;
import com.ossnms.dcn_manager.core.jaxb.type.DefaultIcon;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import com.ossnms.dcn_manager.core.jaxb.type.TypeProperties;
import org.junit.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.emptyCollectionOf;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class NeTypeLoaderTest {

    private static final URL NE_TYPE_URL = XmlConfigurationTest.class.getClassLoader().getResource("netype/NeTypeLoadTest.xml");

    @Test
    public void testLoading() {
        final Config config = XmlConfiguration.unmarshal(Config.class, NE_TYPE_URL, null);
        assertNotNull(config);
        assertThat(config.getName(), is("UNO 1.0"));

        final DefaultIcon defaultIcon = config.getDefaultIcon();
        assertNotNull(defaultIcon);
        assertNotNull(defaultIcon.getName());

        final PropertyPageFiles propertyPageFiles = config.getPropertyPageFiles();
        assertNotNull(propertyPageFiles);
        assertNotNull(propertyPageFiles.getPropertyPageFile());

        final TypeProperties typeProperties = config.getTypeProperties();
        assertNotNull(typeProperties);
        assertNotNull(typeProperties.getElement());

        final Properties properties = config.getProperties();
        assertNotNull(properties);

        final Mappings mappings = properties.getMappings();
        assertNotNull(mappings);
        assertThat(mappings.getUsesGne(), is("TEST_USES_GNE"));
        assertThat(mappings.getReconnectInterval(), is("TEST_RECONNECT_INTERVAL"));

        final Route gatewayRoute = properties.getGatewayRoute();
        assertNotNull(gatewayRoute);
        assertThat(gatewayRoute.getAddressKey(), is("${Route.ADDRESS}${Route.PORT}${Route.TEST_TID}"));
        final List<Attribute> gatewayAttributes = gatewayRoute.getAttribute();
        assertNotNull(gatewayAttributes);
        assertThat(gatewayAttributes, not(emptyCollectionOf(Attribute.class)));

        final Route directRoute = properties.getDirectRoute();
        assertNotNull(directRoute);
        assertThat(directRoute.getAddressKey(), is("${Route.BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP}${Route.TL1_DEFAULT_PORT}${Route.TL1_NE_TARGET_ID}"));
        final List<Attribute> directAttributes = directRoute.getAttribute();
        assertNotNull(directAttributes);
        assertThat(directAttributes, not(emptyCollectionOf(Attribute.class)));
    }

    @Test
    public void testBadURL() throws MalformedURLException {
        final Config configuration = XmlConfiguration.unmarshal(Config.class, new URL("file:///blah"), null);
        assertNull(configuration);
    }
}
