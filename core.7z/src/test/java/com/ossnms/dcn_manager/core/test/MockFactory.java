package com.ossnms.dcn_manager.core.test;

import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.Type;
import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.test.util.ReturnFirstArgumentAsString;

import java.util.Collections;
import java.util.Optional;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public final class MockFactory {

    private MockFactory() {

    }

    public static MediatorType mockMediatorType() {
        return configure(mock(MediatorType.class));
    }

    public static ChannelType mockEmType() {
        return configure(mock(ChannelType.class));
    }

    public static NeType mockNeType() {
        final NeType type = configure(mock(NeType.class));
        configureDirectRouteAttributes(type);
        when(type.getPropertyNamesToIgnoreOnDiscoveryUpdates()).thenReturn(Collections.emptyList());
        when(type.getIdentificationControlMap()).thenReturn(ImmutableBiMap.of());
        when(type.getAdditionalTypeInfoControlMap()).thenReturn(ImmutableBiMap.of());
        return type;
    }

    private static void configureDirectRouteAttributes(final NeType type) {
        final Attribute ip = new Attribute();
        ip.setName("ip_address");
        final Attribute port = new Attribute();
        port.setName("port");
        when(type.getDirectRouteAttributes()).thenReturn(ImmutableMap.of(ip.getName(), ip, port.getName(), port));
        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.empty());
    }

    private static <T extends Type> T configure(T type) {
        final ReturnFirstArgumentAsString returnFirstArgumentAsString = new ReturnFirstArgumentAsString();
        when(type.getName()).thenReturn("type_name");
        when(type.mapIncomingPropertyName(anyString())).then(returnFirstArgumentAsString);
        when(type.mapOutgoingPropertyName(anyString())).then(returnFirstArgumentAsString);
        when(type.getTypeProperties()).thenReturn(Collections.emptyMap());
        return type;
    }
}
