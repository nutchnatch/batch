package com.ossnms.dcn_manager.core.test;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import org.mockito.invocation.InvocationOnMock;

import java.util.Optional;

public final class UowMutationAnswer<T extends BusinessObjectData> extends MutationAnswer<T> {
    @Override
    public Optional<T> answer(InvocationOnMock invocation) {
        @SuppressWarnings("unchecked")
        final MutationDescriptor<T, ?> mutation = (MutationDescriptor<T, ?>) invocation.getArguments()[1];
        return null != mutation ? Optional.of(mutation.apply()) : null;
    }
}