package com.ossnms.dcn_manager.core.utils;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

public class OptionalsTest {

    @Test
    public void testIsPresent() {
        final Predicate<Optional<?>> predicate = Optionals.isPresent();

        assertThat(predicate.apply(Optional.empty()), is(false));
        assertThat(predicate.apply(null), is(false));
        assertThat(predicate.apply(Optional.of(1)), is(true));
    }

    @Test
    public void testDereference() {
        final Function<Optional<? extends Integer>, Integer> function = Optionals.dereference();

        assertThat(function.apply(Optional.empty()), is(nullValue()));
        assertThat(function.apply(null), is(nullValue()));
        assertThat(function.apply(Optional.of(1)), is(1));
    }

}
