package com.ossnms.dcn_manager.core.properties.ne;

import com.google.common.base.Throwables;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.RouteSortingMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;
import com.ossnms.dcn_manager.core.jaxb.netype.RouteMapping;
import com.ossnms.dcn_manager.core.properties.EntityPropertyOperations.Scope;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.i18n.Message;
import org.junit.Before;
import org.junit.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

public class NePropertiesTest extends PropertiesTestBase {

    private final NeProperties neProperties = new NeProperties();

    private NeType type;
    private NeCreateDescriptor createDescriptor;
    private NeEntity baseEntity;

    @Before
    public void setUp() {
        type = MockFactory.mockNeType();
        createDescriptor = new NeCreateDescriptor(1, type);
        createDescriptor.getPreferences().setName("type_name_99");
        createDescriptor.getPreferences().setUsesGne(true);
        baseEntity = NeEntity.build(99, VERSION, createDescriptor);
    }

    @Test
    public void testBuildRouteDescription_routes_working() {
        final NeProperties neProperties = new NeProperties();
        final NeConnectionData connectedData =
                new NeConnectionBuilder().setActivationState(ActualActivationState.CONNECTED).build(NEID, VERSION);

        final NeUserPreferencesData preferencesData = new NeUserPreferencesBuilder()
                .setName("name")
                .setUsesGne(true)
                .setUsesFlatIp(true)
                .build(NEID, VERSION);

        NeEntity entity = new NeEntity(connectedData,
                baseEntity.getOperation(), baseEntity.getInfo(),
                baseEntity.getSync(), preferencesData);
        
        assertThat(neProperties.buildCurrentRouteDescription(entity,
                ImmutableList.of(
                        new NeGatewayRouteBuilder().setUsed(true).setKey("1").setPriority(1).build(NEID, VERSION),
                        new NeGatewayRouteBuilder().setUsed(false).setKey("2").setPriority(2).build(NEID, VERSION)
                    )), hasValue(1 + " (" + Message.WORKING.toString() + ")"));
    }

    @Test
    public void testBuildRouteDescription_routes_protection() {
        final NeProperties neProperties = new NeProperties();
        final NeConnectionData connectedData =
                new NeConnectionBuilder().setActivationState(ActualActivationState.CONNECTED).build(NEID, VERSION);

        final NeUserPreferencesData preferencesData = new NeUserPreferencesBuilder()
                .setName("name")
                .setUsesGne(true)
                .setUsesFlatIp(true)
                .build(NEID, VERSION);

        NeEntity entity = new NeEntity(connectedData,
                baseEntity.getOperation(), baseEntity.getInfo(),
                baseEntity.getSync(), preferencesData);
        assertThat(neProperties.buildCurrentRouteDescription(entity,
                ImmutableList.of(
                        new NeGatewayRouteBuilder().setUsed(false).setKey("1").setPriority(1).build(NEID, VERSION),
                        new NeGatewayRouteBuilder().setUsed(true).setKey("2").setPriority(2).build(NEID, VERSION)
                )), hasValue(2 + " (" + Message.PROTECTING.toString() + ")"));
    }

    @Test public void testBuildRouteDescription_route_not_found() throws Exception {
        final NeProperties neProperties = new NeProperties();
        final NeConnectionData connectedData =
                new NeConnectionBuilder().setActivationState(ActualActivationState.CONNECTED).build(NEID, VERSION);

        NeEntity entity = new NeEntity(connectedData,
                baseEntity.getOperation(), baseEntity.getInfo(),
                baseEntity.getSync(), baseEntity.getPreferences());

        assertThat(neProperties.buildCurrentRouteDescription(entity,
                ImmutableList.of(
                        new NeGatewayRouteBuilder().setUsed(false).setKey("1").setPriority(1).build(NEID, VERSION),
                        new NeGatewayRouteBuilder().setUsed(false).setKey("2").setPriority(2).build(NEID, VERSION)
                )), hasValue(Message.DIRECT_CONNECTION.toString()));
    }

    @Test public void testBuildRouteDescription_direct() throws Exception {
        final NeProperties neProperties = new NeProperties();
        final NeConnectionData connectedData =
                new NeConnectionBuilder().setActivationState(ActualActivationState.CONNECTED).build(NEID, VERSION);

        NeEntity entity = new NeEntity(connectedData,
                baseEntity.getOperation(), baseEntity.getInfo(),
                baseEntity.getSync(), baseEntity.getPreferences());
        assertThat(neProperties.buildCurrentRouteDescription(entity,
                ImmutableList.of()), hasValue(Message.DIRECT_CONNECTION.toString()));
    }

    @Test public void testBuildRouteDescription_direct_flat_ip() throws Exception {
        final NeProperties neProperties = new NeProperties();
        final NeConnectionData connectedData =
                new NeConnectionBuilder().setActivationState(ActualActivationState.CONNECTED).build(NEID, VERSION);
        final NeUserPreferencesData preferencesData = new NeUserPreferencesBuilder()
                .setName("name")
                .setUsesGne(false)
                .setUsesFlatIp(true)
                .build(NEID, VERSION);

        NeEntity entity = new NeEntity(connectedData,
                baseEntity.getOperation(), baseEntity.getInfo(),
                baseEntity.getSync(), preferencesData);
        assertThat(neProperties.buildCurrentRouteDescription(entity,
                ImmutableList.of()), hasValue(Message.DIRECT_CONNECTION_BY_FLAT_IP.toString()));
    }

    @Test public void testBuildRouteDescription_disconnected_direct_flat_ip() throws Exception {
        final NeProperties neProperties = new NeProperties();
        final NeConnectionData connectedData =
                new NeConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(NEID, VERSION);
        final NeUserPreferencesData preferencesData = new NeUserPreferencesBuilder()
                .setName("name")
                .setUsesGne(false)
                .setUsesFlatIp(true)
                .build(NEID, VERSION);

        NeEntity entity = new NeEntity(connectedData,
                baseEntity.getOperation(), baseEntity.getInfo(),
                baseEntity.getSync(), preferencesData);
        assertThat(neProperties.buildCurrentRouteDescription(entity,
                ImmutableList.of()), is(absent()));
    }

    @Test
    public void testBuildRouteDescription_disconnectedNe() {
        NeEntity entity;
        final NeProperties neProperties = new NeProperties();
        final NeConnectionData disconnectedData =
                new NeConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(NEID, VERSION);

        entity = new NeEntity(disconnectedData,
                baseEntity.getOperation(), baseEntity.getInfo(),
                baseEntity.getSync(), baseEntity.getPreferences());
        assertThat(neProperties.buildCurrentRouteDescription(entity,
                ImmutableList.of(
                        new NeGatewayRouteBuilder().setUsed(true).setKey("1").setPriority(1).build(NEID, VERSION),
                        new NeGatewayRouteBuilder().setUsed(false).setKey("2").setPriority(2).build(NEID, VERSION)
                    )), is(absent()));

        entity = new NeEntity(disconnectedData,
                baseEntity.getOperation(), baseEntity.getInfo(),
                baseEntity.getSync(), baseEntity.getPreferences());
        assertThat(neProperties.buildCurrentRouteDescription(entity,
                ImmutableList.of(
                        new NeGatewayRouteBuilder().setUsed(false).setKey("1").setPriority(1).build(NEID, VERSION),
                        new NeGatewayRouteBuilder().setUsed(true).setKey("2").setPriority(2).build(NEID, VERSION)
                    )), is(absent()));

        entity = new NeEntity(disconnectedData,
                baseEntity.getOperation(), baseEntity.getInfo(),
                baseEntity.getSync(), baseEntity.getPreferences());
        assertThat(neProperties.buildCurrentRouteDescription(entity,
                ImmutableList.of(
                        new NeGatewayRouteBuilder().setUsed(false).setKey("1").setPriority(1).build(NEID, VERSION),
                        new NeGatewayRouteBuilder().setUsed(false).setKey("2").setPriority(2).build(NEID, VERSION)
                    )), is(absent()));

        entity = new NeEntity(disconnectedData,
                baseEntity.getOperation(), baseEntity.getInfo(),
                baseEntity.getSync(), baseEntity.getPreferences());
        assertThat(neProperties.buildCurrentRouteDescription(entity,
                ImmutableList.<NeGatewayRouteData>of()), is(absent()));
    }

    @Test
    public void testGetAllProperties() {
        final Map<String, String> typeProperties = ImmutableMap.of("A", "A_VALUE", "D", "${Property.C}");

        final NeEntity entity = new NeEntity(
                baseEntity.getConnection(),
                baseEntity.getOperation(),
                baseEntity.getInfo(),
                baseEntity.getSync(),
                new NeUserPreferencesBuilder()
                    .setName("type_name_99")
                    .setProperty("START", "A:${property.A} B:${Property.B}")
                    .setProperty("B", "${PROPERTY.C}")
                    .setProperty("C", "C_VALUE")
                    .build(NEID, VERSION));

        when(type.getTypeProperties()).thenReturn(typeProperties);

        final Map<String, String> properties = neProperties.getProperties(type, entity);
        assertThat(properties.size(), is(greaterThanOrEqualTo(4))); // this count will include well known properties as well.
        assertThat(properties, hasEntry("A", "A_VALUE"));
        assertThat(properties, hasEntry("B", "C_VALUE"));
        assertThat(properties, hasEntry("C", "C_VALUE"));
        assertThat(properties, hasEntry("D", "C_VALUE"));
        assertThat(properties, hasEntry("START", "A:A_VALUE B:C_VALUE"));
        assertThat(properties, not(hasKey("UNKNOWN")));
    }

    @Test
    public void testGetPrivateProperties() {
        final Map<String, String> properties = neProperties.getProperties(type, baseEntity, Scope.PRIVATE);
        assertThat(properties, hasEntry(WellKnownNePropertyNames.ID_NAME, baseEntity.getPreferences().getName()));
    }

    @Test
    public void testGetPublicProperties() {
        final Map<String, String> properties = neProperties.getProperties(type, baseEntity, Scope.PUBLIC);
        assertThat(properties, not(hasEntry(WellKnownNePropertyNames.ID_NAME, baseEntity.getPreferences().getName())));
    }

    @Test
    public void testGetProperty() {
        final Map<String, String> typeProperties = ImmutableMap.of("A", "A_VALUE", "D", "${Property.B}");

        final NeEntity entity = new NeEntity(
                baseEntity.getConnection(),
                baseEntity.getOperation(),
                baseEntity.getInfo(),
                baseEntity.getSync(),
                new NeUserPreferencesBuilder()
                    .setName("type_name_99")
                    .setProperty("B", "B_VALUE")
                    .build(NEID, VERSION));

        when(type.getTypeProperties()).thenReturn(typeProperties);

        assertThat(neProperties.getProperty(type, entity, "A").get(), is("A_VALUE"));
        assertThat(neProperties.getProperty(type, entity, "B").get(), is("B_VALUE"));
        assertThat(neProperties.getProperty(type, entity, "C").isPresent(), is(false));
        assertThat(neProperties.getProperty(type, entity, "D").get(), is("B_VALUE"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.ID_NAME.getName()).get(), is("type_name_99"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.ID_NAME).get(), is("type_name_99"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.NE_TYPE).get(), is("type_name"));
    }

    @Test
    public void testSetProperty() throws InvalidMutationException {

        final NeUserPreferencesMutationDescriptor mutator = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());

        neProperties.setProperty(type, mutator, "xpto", "val");
        neProperties.setProperty(type, mutator, NeProperty.ID_NAME, "new_name");

        assertThat(mutator.getName().get(), is("new_name"));
        assertThat(mutator.getProperties().get("xpto"), is("val"));
    }

    @Test
    public void testSetNeType_setNotSupportedThroughProperties_ignores() throws InvalidMutationException {
        final NeUserPreferencesMutationDescriptor mutator = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());
        neProperties.setProperty(type, mutator, NeProperty.NE_TYPE, "new_type");
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetWellKnownProperties() {

        final NeEntity entity = new NeEntity(
                baseEntity.getConnection(),
                new NeOperationBuilder().setGatewayMode(Optional.of(GatewayMode.PRIMARY)).build(NEID, VERSION),
                baseEntity.getInfo(),
                baseEntity.getSync(),
                new NeUserPreferencesBuilder()
                    .setName("type_name_99")
                    .setGlobalId(Optional.of("gid"))
                    .setReconnectInterval(12)
                    .setUsesGne(true)
                    .setUserName(Optional.of("uname"))
                    .setPassword(Optional.of("passwd"))
                    .build(NEID, VERSION));

        configureWellKnownPropertyMappings();

        assertThat(neProperties.getProperty(type, entity, NeProperty.ID_NAME).get(), is("type_name_99"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.USES_GNE).get(), is("true"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.RECONNECT_INTERVAL).get(), is("12"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.GLOBAL_NE_ID).get(), is("gid"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.USER_NAME).get(), is("uname"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.USER_PASSWORD).get(), is("passwd"));

        assertThat(neProperties.getProperty(type, entity, WellKnownNePropertyNames.DEPRECATED_NUM_OF_DHCP), is(absent()));
        assertThat(neProperties.getProperty(type, entity, WellKnownNePropertyNames.DEPRECATED_NUM_OF_ADD_NSAPS), is(absent()));

        assertThat(entity.getAllOpaqueProperties().isEmpty(), is(true));

        final Map<String, String> properties = neProperties.getProperties(type, entity);
        assertThat(properties, is(notNullValue()));
        assertThat(properties, allOf(
                hasEntry("ugne", "true"),
                hasEntry("BCB-Attribute/NE/neProxyType", "type_name"),
                hasEntry("name", "type_name_99"),
                hasEntry("rciv", "12"),
                hasEntry(WellKnownNePropertyNames.GLOBAL_NE_ID, "gid"),
                hasEntry("unm", "uname"),
                hasEntry("upw", "passwd")
            ));

        assertThat(neProperties.getProperty(type, entity, "name").get(), is("type_name_99"));
        assertThat(neProperties.getProperty(type, entity, "ugne").get(), is("true"));
        assertThat(neProperties.getProperty(type, entity, "rciv").get(), is("12"));
        assertThat(neProperties.getProperty(type, entity, WellKnownNePropertyNames.GLOBAL_NE_ID).get(), is("gid"));
        assertThat(neProperties.getProperty(type, entity, "unm").get(), is("uname"));
        assertThat(neProperties.getProperty(type, entity, "upw").get(), is("passwd"));
    }

    @Test
    public void testGatewayRouteAttributes_areIgnored() throws InvalidMutationException {

        when(type.getGatewayRouteAttributes())
            .thenReturn(ImmutableMap.of(
                    "routeCost", attribute("routeCost", RouteMapping.COST),
                    "routeStuff", attribute("routeStuff"))
            );

        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());
        neProperties.setProperty(type, mutation, "routeCost_000", "X");
        neProperties.setProperty(type, mutation, "routeStuff_098", "X");

        final Map<String, String> properties = mutation.getProperties();
        assertThat(properties.entrySet(), hasSize(0));
    }

    @Test
    public void testDomainAttributes_areIgnored() throws InvalidMutationException {

        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());
        neProperties.setProperty(type, mutation, WellKnownNePropertyNames.DEPRECATED_DOMAIN_NAME_FOR_NE, "Z");

        final Map<String, String> properties = mutation.getProperties();
        assertThat(properties.entrySet(), hasSize(0));
    }

    @Test
    public void testDirectRouteAttributes_areIgnored() throws InvalidMutationException {
        final String port = "port";
        final String ip_address = "ip_address";

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(1, type);
        descriptor.getPreferences().setName("name");
        final NeEntity entity = NeEntity.build(1, VERSION, descriptor);
        assertThat(entity.getPreferences().getAllOpaqueProperties().isEmpty(), is(true));
        assertThat(neProperties.getProperty(type, entity, ip_address).isPresent(), is(false));
        assertThat(neProperties.getProperty(type, entity, port).isPresent(), is(false));

        final Map<String, String> properties = neProperties.getProperties(type, entity);
        assertThat(properties.containsKey(ip_address), is(false));
        assertThat(properties.containsKey(port), is(false));

        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());
        neProperties.setProperty(type, mutation, ip_address, "1.1.1.1");
        neProperties.setProperty(type, mutation, port, "111");

        final NeEntity newEntity = new NeEntity(
                baseEntity.getConnection(),
                baseEntity.getOperation(),
                baseEntity.getInfo(),
                baseEntity.getSync(),
                mutation.apply());

        assertThat(newEntity.getPreferences().getAllOpaqueProperties().isEmpty(), is(true));
        assertThat(newEntity.getPreferences().getDirectRoute().getAllOpaqueProperties().isEmpty(), is(true));

        final Map<String, String> newProperties = neProperties.getProperties(type, newEntity);
        assertThat(newProperties, not(hasKey(ip_address)));
        assertThat(newProperties, not(hasKey(port)));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testSetWellKnownProperties() throws InvalidMutationException {

        final NeEntity originalEntity = new NeEntity(
                baseEntity.getConnection(),
                new NeOperationBuilder().setGatewayMode(Optional.of(GatewayMode.NONE)).build(NEID, VERSION),
                baseEntity.getInfo(),
                baseEntity.getSync(),
                new NeUserPreferencesBuilder().setName("name").setReconnectInterval(0).setUsesGne(false).build(NEID, VERSION));

        configureWellKnownPropertyMappings();

        final NeUserPreferencesMutationDescriptor set = new NeUserPreferencesMutationDescriptor(originalEntity.getPreferences());
        neProperties.setProperty(type, set, "name", "new_name");
        neProperties.setProperty(type, set, "ugne", "true");
        neProperties.setProperty(type, set, "rciv", "42");
        neProperties.setProperty(type, set, "unm", "newnm");
        neProperties.setProperty(type, set, "upw", "newpw");
        neProperties.setProperty(type, set, WellKnownNePropertyNames.GLOBAL_NE_ID, "ngid");

        neProperties.setProperty(type, set, WellKnownNePropertyNames.DEPRECATED_NUM_OF_DHCP, "depre1");
        neProperties.setProperty(type, set, WellKnownNePropertyNames.DEPRECATED_NUM_OF_ADD_NSAPS, "depre2");

        neProperties.setProperty(type, set, WellKnownNePropertyNames.RESTART_NE, "ignore1");

        final NeEntity entity = new NeEntity(
                originalEntity.getConnection(),
                originalEntity.getOperation(),
                originalEntity.getInfo(),
                originalEntity.getSync(),
                set.apply());

        assertThat(neProperties.getProperty(type, entity, NeProperty.ID_NAME).get(), is("new_name"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.USES_GNE).get(), is("true"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.RECONNECT_INTERVAL).get(), is("42"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.GLOBAL_NE_ID).get(), is("ngid"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.USER_NAME).get(), is("newnm"));
        assertThat(neProperties.getProperty(type, entity, NeProperty.USER_PASSWORD).get(), is("newpw"));

        assertThat(neProperties.getProperty(type, entity, WellKnownNePropertyNames.DEPRECATED_NUM_OF_DHCP), is(absent()));
        assertThat(neProperties.getProperty(type, entity, WellKnownNePropertyNames.DEPRECATED_NUM_OF_ADD_NSAPS), is(absent()));
        assertThat(neProperties.getProperty(type, entity, WellKnownNePropertyNames.RESTART_NE), is(absent()));

        assertThat(entity.getAllOpaqueProperties().isEmpty(), is(true));

        final Map<String, String> properties = neProperties.getProperties(type, entity);
        assertThat(properties, is(notNullValue()));
        assertThat(properties, allOf(
                hasEntry("ugne", "true"),
                hasEntry("BCB-Attribute/NE/neProxyType", "type_name"),
                hasEntry("name", "new_name"),
                hasEntry("rciv", "42"),
                hasEntry("unm", "newnm"),
                hasEntry("upw", "newpw"),
                hasEntry(WellKnownNePropertyNames.GLOBAL_NE_ID, "ngid")
            ));
    }

    @Test
    public void testSetGatewayModeProperty_setNotSupportedThroughProperties_ignored() throws InvalidMutationException {
        configureWellKnownPropertyMappings();

        final NeUserPreferencesMutationDescriptor set = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());
        neProperties.setProperty(type, set, "gatewayMode", "PRIMARY");
    }

    private void configureWellKnownPropertyMappings() {
        final ImmutableBiMap<String, String> mapping = ImmutableBiMap.<String, String>builder()
            .put("name", NeProperty.ID_NAME.getName())
            .put("gatewayMode", NeProperty.GATEWAY_MODE.getName())
            .put("ugne", NeProperty.USES_GNE.getName())
            .put("rciv", NeProperty.RECONNECT_INTERVAL.getName())
            .put("unm", NeProperty.USER_NAME.getName())
            .put("upw", NeProperty.USER_PASSWORD.getName())
            .build();
        when(type.mapIncomingPropertyName(anyString())).then(new Answer<String>() {
            @Override
            public String answer(InvocationOnMock invocation) throws Throwable {
                final String key = (String) invocation.getArguments()[0];
                final String result = mapping.get(invocation.getArguments()[0]);
                return result != null ? result : key;
            }
        });
        when(type.mapOutgoingPropertyName(anyString())).then(new Answer<String>() {
            @Override
            public String answer(InvocationOnMock invocation) throws Throwable {
                final String key = (String) invocation.getArguments()[0];
                final String result = mapping.inverse().get(key);
                return result != null ? result : key;
            }
        });
    }

    @Test
    public void testSetProperties() throws InvalidMutationException {

        final NeUserPreferencesMutationDescriptor mutator = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());

        neProperties.setProperties(type, mutator, ImmutableMap.of("xpto", "val", NeProperty.ID_NAME.getName(), "new_name"));

        assertThat(mutator.getName().get(), is("new_name"));
        assertThat(mutator.getProperties().get("xpto"), is("val"));
    }

    @Test
    public void testSetRouteSortingProperties() throws InvalidMutationException {

        final NeUserPreferencesMutationDescriptor mutator = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());

        assertThat(mutator.getTarget().getRouteSortingMode(), is(RouteSortingMode.AUTO_PRIORITY));
        neProperties.setProperty(type, mutator, NeProperty.USE_DEFAULT_ROUTE_SORTING, "true");
        assertThat(mutator.getRouteSortingMode().get(), is(RouteSortingMode.AUTO_PRIORITY));
        neProperties.setProperty(type, mutator, WellKnownNePropertyNames.INTERNAL_ENABLE_PRIORITY_SWAP, WellKnownNePropertyNames.INTERNAL_ENABLE_PRIORITY_SWAP);
        assertThat(mutator.getRouteSortingMode().get(), is(RouteSortingMode.AUTO_PRIORITY));
        neProperties.setProperty(type, mutator, WellKnownNePropertyNames.INTERNAL_ENABLE_PRIORITY_SWAP, "");
        assertThat(mutator.getRouteSortingMode().get(), is(RouteSortingMode.AUTO_PRIORITY));

        neProperties.setProperty(type, mutator, NeProperty.USE_DEFAULT_ROUTE_SORTING, "false");
        assertThat(mutator.getRouteSortingMode().get(), is(RouteSortingMode.NONE));
        neProperties.setProperty(type, mutator, WellKnownNePropertyNames.INTERNAL_ENABLE_PRIORITY_SWAP, "true");
        assertThat(mutator.getRouteSortingMode().get(), is(RouteSortingMode.NONE));

        neProperties.setProperty(type, mutator, NeProperty.USE_DEFAULT_ROUTE_SORTING, "true");
        assertThat(mutator.getRouteSortingMode().get(), is(RouteSortingMode.AUTO_PRIORITY));
    }

    @Test(expected=InvalidMutationException.class)
    public void testSetInvalidIdNameProperty_throws() throws InvalidMutationException {
        final NeUserPreferencesMutationDescriptor mutator = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());
        neProperties.setProperty(type, mutator, NeProperty.ID_NAME, "");
    }

    @Test(expected=InvalidMutationException.class)
    public void testSetNullIdNameProperty_throws() throws InvalidMutationException {
        final NeUserPreferencesMutationDescriptor mutator = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());
        neProperties.setProperty(type, mutator, NeProperty.ID_NAME, null);
    }

    @Test
    public void testSetTypeProperty_causesNoChanges() throws InvalidMutationException {
        final Map<String, String> typeProperties = ImmutableMap.of("A", "A_VALUE", "B", "B_VALUE");
        final NeUserPreferencesMutationDescriptor mutator = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());

        when(type.getTypeProperties()).thenReturn(typeProperties);

        neProperties.setProperty(type, mutator, "A", "NEW_A");

        assertThat(mutator.getProperties().isEmpty(), is(true));
    }

    @Test
    public void testSetOperationalProperty_causesNoChanges() throws InvalidMutationException {

        final NeUserPreferencesMutationDescriptor mutator = new NeUserPreferencesMutationDescriptor(baseEntity.getPreferences());

        Stream.of(NeOperationalProperty.values()).forEach(property -> {
            try {
                neProperties.setProperty(type, mutator, property.getName(), "0");
            } catch (InvalidMutationException e) {
                Throwables.propagate(e);
            }
        });

        assertThat(mutator.getProperties().isEmpty(), is(true));
    }

    @Test
    public void testToString() {
        assertThat(NeProperty.ID_NAME.toString(), not(nullValue()));
    }
}
