package com.ossnms.dcn_manager.core.policies.impl.jobs;

import com.ossnms.dcn_manager.core.events.ne.IdentifiedNeEvent;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.policies.impl.JobWrapper;
import org.hamcrest.Matcher;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.lessThan;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

public class NeJobTest {

    private NeConnectionManager connectionManager = mock(NeConnectionManager.class);

    private static class TestJob extends NeJob<IdentifiedNeEvent> {

        TestJob() {
            super(mock(IdentifiedNeEvent.class), Priority.MEDIUM);
        }

        @Override
        protected void runJob() {

        }

    }

    @Test
    public void runWithoutCancellation() throws Exception {
        final TestJob job = spy(new TestJob());

        job.run();

        verify(job).runJob();
        verify(job, never()).cancel();
    }

    @Test
    public void runBeforeCancellation() throws Exception {
        final TestJob job = spy(new TestJob());

        job.run();

        job.cancel();

        verify(job).runJob();
    }

    @Test
    public void runAfterCancellation() throws Exception {
        final TestJob job = spy(new TestJob());

        job.cancel();

        job.run();

        verify(job, never()).runJob();
    }

    @Test
    public void idempotentCancellation() throws Exception {
        final TestJob job = spy(new TestJob());

        job.cancel();

        job.cancel();

        job.run();

        verify(job, never()).runJob();
    }

    @Test
    public void testJobPriorityOrdering() throws Exception {

        
        final NeJob<?> activation = new ActivationJob(new RequiredNeStateEvent.Activate(1, 1, 1, 1, true), connectionManager);
        final NeJob<?> initialization = new LazySynchronizationJob(new NeSynchronizationEvent(1, 1, 1, 1, true), connectionManager);
        final NeJob<?> synchronization = new SynchronizationJob(new NeSynchronizationEvent(1, 1, 1, 1, true), connectionManager);
        final NeJob<?> deactivation = new DeactivationJob(new RequiredNeStateEvent.Deactivate(1, 1, 1, 1, true), connectionManager);

        compare(deactivation, activation, is(lessThan(0)));
        compare(deactivation, initialization, is(lessThan(0)));
        compare(deactivation, synchronization, is(lessThan(0)));
        compare(deactivation, deactivation, is(0));

        compare(activation, initialization, is(greaterThan(0)));
        compare(activation, synchronization, is(greaterThan(0)));
        compare(activation, deactivation, is(greaterThan(0)));
        compare(activation, activation, is(0));

    }

    @Test
    public void testJobActiveAndPriorityOrdering() throws Exception {

        final NeJob<?> activationActive = new ActivationJob(new RequiredNeStateEvent.Activate(1, 1, 1, 1, true), connectionManager);
        final NeJob<?> activationInactive = new ActivationJob(new RequiredNeStateEvent.Activate(1, 1, 1, 1, false), connectionManager);
        final NeJob<?> initializationActive = new LazySynchronizationJob(new NeSynchronizationEvent(1, 1, 1, 1, true), connectionManager);
        final NeJob<?> initializationInactive = new LazySynchronizationJob(new NeSynchronizationEvent(1, 1, 1, 1, false), connectionManager);
        final NeJob<?> synchronizationActive = new SynchronizationJob(new NeSynchronizationEvent(1, 1, 1, 1, true), connectionManager);
        final NeJob<?> synchronizationInactive = new SynchronizationJob(new NeSynchronizationEvent(1, 1, 1, 1, false), connectionManager);
        final NeJob<?> deactivationActive = new DeactivationJob(new RequiredNeStateEvent.Deactivate(1, 1, 1, 1, true), connectionManager);
        final NeJob<?> deactivationInactive = new DeactivationJob(new RequiredNeStateEvent.Deactivate(1, 1, 1, 1, false), connectionManager);

        compare(deactivationActive, activationActive, is(lessThan(0)));
        compare(deactivationInactive, activationInactive, is(lessThan(0)));
        compare(deactivationActive, initializationActive, is(lessThan(0)));
        compare(deactivationInactive, initializationInactive, is(lessThan(0)));
        compare(deactivationActive, synchronizationActive, is(lessThan(0)));
        compare(deactivationInactive, synchronizationInactive, is(lessThan(0)));

        compare(deactivationActive, deactivationActive, is(0));
        compare(deactivationInactive, deactivationInactive, is(0));
        compare(deactivationActive, deactivationInactive, is(greaterThan(0)));
        compare(deactivationInactive, deactivationActive, is(lessThan(0)));

        compare(activationActive, initializationActive, is(greaterThan(0)));
        compare(activationActive, initializationInactive, is(greaterThan(0)));
        compare(activationInactive, initializationActive, is(greaterThan(0)));
        compare(activationInactive, initializationInactive, is(greaterThan(0)));

        compare(activationActive, synchronizationActive, is(greaterThan(0)));
        compare(activationActive, synchronizationInactive, is(greaterThan(0)));
        compare(activationInactive, synchronizationActive, is(greaterThan(0)));
        compare(activationInactive, synchronizationInactive, is(greaterThan(0)));

        compare(activationActive, deactivationActive, is(greaterThan(0)));
        compare(activationActive, deactivationInactive, is(greaterThan(0)));
        compare(activationInactive, deactivationActive, is(greaterThan(0)));
        compare(activationInactive, deactivationInactive, is(greaterThan(0)));

        compare(activationActive, activationActive, is(0));
        compare(activationInactive, activationInactive, is(0));
        compare(activationActive, activationInactive, is(greaterThan(0)));
        compare(activationInactive, activationActive, is(lessThan(0)));

    }

    private static void compare(NeJob<?> left, NeJob<?> right, Matcher<Integer> matcher) {
        assertThat(left.compareTo(right), matcher);
        assertThat(wrapped(left).compareTo(right), matcher);
        assertThat(left.compareTo(wrapped(right)), matcher);
        assertThat(wrapped(left).compareTo(wrapped(right)), matcher);
    }

    private static JobWrapper wrapped(NeJob job) {
        return new JobWrapper(job, Optional::empty);
    }
}
