package com.ossnms.dcn_manager.core.properties.ne;

import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.core.jaxb.netype.RouteMapping;

class PropertiesTestBase {

    protected static final int NEID = 12;
    protected static final int VERSION = 1;

    public PropertiesTestBase() {
        super();
    }

    protected Attribute attribute(String name, RouteMapping mapping) {
        final Attribute attr = attribute(name);
        attr.setMapsTo(mapping);
        return attr;
    }

    protected Attribute attribute(String name) {
        final Attribute attr = new Attribute();
        attr.setName(name);
        return attr;
    }

    protected Attribute attribute(String name, String source) {
        final Attribute attr = attribute(name);
        attr.setSource(source);
        return attr;
    }

}