package com.ossnms.dcn_manager.core.entities.channel.data;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.entities.DynamicDomainObjectMutationDescriptorTestBase;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import org.junit.Before;
import org.junit.Test;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.both;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

public class ChannelUserPreferencesMutationDescriptorTest extends
	DynamicDomainObjectMutationDescriptorTestBase<ChannelUserPreferencesData, ChannelUserPreferencesMutationDescriptor> {

	// The following string literals must match the ones used in ChannelUserPreferencesMutationDescriptor.toString()
	// Public constant fields were not used to prevent polluting the type's public interface
	private static final String NAME_TO_STRING_KEY = "new name";
	private static final String RECONNECT_INTERVAL_TO_STRING_KEY = "new reconnectInterval";

	// Domain object's original values and mutation values, to verify mutation correctness
	private static final String ORIGINAL_CHANNEL_NAME = "A channel name";
	private static final String MUTATION_CHANNEL_NAME = "The channel new name";
	private static final int ORIGINAL_RECONNECT_INTERVAL = 600;
	private static final int MUTATION_RECONNECT_INTERVAL = 500;
	private static final String PROPERTY_A_KEY = "A", PROPERTY_B_KEY = "B";
	private static final String PROPERTY_A_ORIGINAL_VALUE = "vA", PROPERTY_A_MUTATION_VALUE = "v2A";
	private static final String PROPERTY_B_ORIGINAL_VALUE = "vB";
	private static final ImmutableMap<String, String> ORIGINAL_PROPERTIES = ImmutableMap.of(
			PROPERTY_A_KEY, PROPERTY_A_ORIGINAL_VALUE,
			PROPERTY_B_KEY, PROPERTY_B_ORIGINAL_VALUE
	);

	@Before
	@Override
	public void setUp() throws Exception {
		final int ID = 1, VERSION = 1;
		domainObject = new ChannelUserPreferencesBuilder()
		    .setReconnectInterval(ORIGINAL_RECONNECT_INTERVAL)
		    .setName(ORIGINAL_CHANNEL_NAME)
		    .setProperties(ORIGINAL_PROPERTIES)
		    .build(ID, VERSION);
		emptyMutation = new ChannelUserPreferencesMutationDescriptor(domainObject);
		mutation = new ChannelUserPreferencesMutationDescriptor(domainObject)
			.setProperty(PROPERTY_A_KEY, PROPERTY_A_MUTATION_VALUE)
			.setName(MUTATION_CHANNEL_NAME)
			.setReconnectInterval(MUTATION_RECONNECT_INTERVAL);
	}

	@Test
	public void apply_inAValidMutationDescriptor_producesTheCorrectMutation() {
		final ChannelUserPreferencesData result = mutation.apply();
		// ID and VERSION are already verified in inherited test methods
		assertThat(result.getName(), is(equalTo(MUTATION_CHANNEL_NAME)));
		assertThat(result.getReconnectInterval(), is(equalTo(MUTATION_RECONNECT_INTERVAL)));
		assertThat(result.getOpaqueProperty(PROPERTY_A_KEY), is(present()));
		assertThat(result.getOpaqueProperty(PROPERTY_A_KEY).get(), is(equalTo(PROPERTY_A_MUTATION_VALUE)));
		assertThat(result.getOpaqueProperty(PROPERTY_B_KEY), is(present()));
		assertThat(result.getOpaqueProperty(PROPERTY_B_KEY).get(), is(equalTo(PROPERTY_B_ORIGINAL_VALUE)));
	}

	@Override
    @Test
	public void toString_onANonEmptyMutation_returnsStringWithMutationInfo() {
		assertThat(
			mutation.toString(),
			both(containsString(NAME_TO_STRING_KEY)).and(containsString(RECONNECT_INTERVAL_TO_STRING_KEY))
		);
	}

	@Test
	public void toString_onAnEmptyMutation_returnsStringWithoutThatMutationInfo() {
		assertThat(
			emptyMutation.toString(),
			both(not(containsString(NAME_TO_STRING_KEY))).and(not(containsString(RECONNECT_INTERVAL_TO_STRING_KEY)))
		);
	}
}
