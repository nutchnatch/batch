package com.ossnms.dcn_manager.core.configuration.model;

import static com.google.common.base.Preconditions.checkArgument;

import java.util.List;

import com.ossnms.dcn_manager.core.jaxb.type.Element;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFile;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import com.ossnms.dcn_manager.core.jaxb.type.TypeProperties;

public class TypeTestBase {

    protected PropertyPageFiles buildPropertyPageFiles(String... fileNames) {
        final PropertyPageFiles files = new PropertyPageFiles();
        final List<PropertyPageFile> fileList = files.getPropertyPageFile();
        for (final String name : fileNames) {
            final PropertyPageFile pageFile = new PropertyPageFile();
            pageFile.setName(name);
            fileList.add(pageFile);
        }
        return files;
    }

    protected TypeProperties buildTypeProperties(String... keyValues) {
        checkArgument(keyValues.length % 2 == 0, "Argument count must be even: (key, value) pairs.");
        final TypeProperties props = new TypeProperties();
        final List<Element> elements = props.getElement();
        for (int i = 0; i < keyValues.length; i += 2) {
            final Element element = new Element();
            element.setKey(keyValues[i]);
            element.setContent(keyValues[i + 1]);
            elements.add(element);
        }
        return props;
    }

}
