package com.ossnms.dcn_manager.core.configuration.model;

import com.ossnms.dcn_manager.core.configuration.loaders.DefaultPropertyLoader;
import com.ossnms.dcn_manager.core.configuration.loaders.XmlConfiguration;
import com.ossnms.dcn_manager.core.jaxb.emtype.Config;
import com.ossnms.dcn_manager.core.properties.channel.ChannelProperty;
import org.junit.Test;

import java.net.URL;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.google.common.collect.Iterables.getOnlyElement;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.emptyIterableOf;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ChannelTypeTest {

    @Test
    public void testLoading() {
        final ClassLoader classLoader = getClass().getClassLoader();
        final Types<NeType> types = Types.from(neTypes("UNO 1.0", "SOME OTHER"));
        Config config = load(classLoader.getResource("emtype/EmTypeLoadTest.xml"));
        final DefaultPropertyValues defaultPropertyValues = new DefaultPropertyLoader().load(Collections.singletonList(classLoader.getResource("defaultproperties/PropertyPageLoadTest.xml")));

        final ChannelType type = new ChannelType(config, types, defaultPropertyValues);

        assertThat(type.getName(), is("UNO"));
        assertThat(type.supportsDiscovery(), is(true));

        final Iterable<NeType> neTypes = type.getSupportedNeTypes();
        assertThat(neTypes, not(is(emptyIterableOf(NeType.class))));
        assertThat(getOnlyElement(neTypes).getName(), is("UNO 1.0"));

        final Map<String, String> defaultValues = type.getSupportedPropertyDefaultValues();
        assertThat(defaultValues, allOf(
                hasEntry("Enable_Scaled_Startup", "true"),
                hasEntry("SwitchBackTime", "600")
        ));
        assertThat(defaultValues.keySet(), not(hasItem("No_Default")));
    }

    private Config load(URL resource) {
        return XmlConfiguration.unmarshal(Config.class, resource, null);
    }

    @Test
    public void testLoading_noDefaultPropertyMatch() {
        final ClassLoader classLoader = getClass().getClassLoader();
        final Types<NeType> types = Types.from(neTypes("UNO 1.0", "SOME OTHER"));
        Config config = load(classLoader.getResource("emtype/EmTypeLoadTest.xml"));
        final DefaultPropertyValues defaultPropertyValues = new DefaultPropertyLoader().load(Collections.singletonList(classLoader.getResource("defaultproperties/DefaultsLoadTest.xml")));

        final ChannelType type = new ChannelType(config, types, defaultPropertyValues);

        final Map<String, String> defaultValues = type.getSupportedPropertyDefaultValues();
        assertThat(defaultValues.isEmpty(), is(true));
    }

    @Test
    public void testLoading_withoutDiscovery() {
        final ClassLoader classLoader = getClass().getClassLoader();
        final Types<NeType> types = Types.from(neTypes("UNO 1.0", "SOME OTHER"));
        Config config = load(classLoader.getResource("emtype/EmTypeWithoutDiscovery.xml"));
        final ChannelType type = new ChannelType(config, types, null);

        assertThat(type.supportsDiscovery(), is(false));
    }

    @Test
    public void testPropertyNameMapping() {
        final ClassLoader classLoader = getClass().getClassLoader();
        Config config = load(classLoader.getResource("emtype/EmTypeLoadTest.xml"));
        final Types<NeType> types = Types.from(neTypes("UNO 1.0", "SOME OTHER"));

        final ChannelType type = new ChannelType(config, types, null);

        assertThat(type.mapIncomingPropertyName("user_text"), is(ChannelProperty.USER_TEXT.getName()));
        assertThat(type.mapOutgoingPropertyName(ChannelProperty.USER_TEXT.getName()), is("user_text"));
    }

    private Collection<NeType> neTypes(String... names) {
        return Stream.of(names).map(name -> {
            final NeType type = mock(NeType.class);
            when(type.getName()).thenReturn(name);
            return type;
        }).collect(Collectors.toList()); 
    }
}
