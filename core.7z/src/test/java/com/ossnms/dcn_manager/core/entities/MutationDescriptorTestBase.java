package com.ossnms.dcn_manager.core.entities;

import static com.ossnms.dcn_manager.core.utils.matchers.Matchers.mutationOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.utils.Consumer;

/**
 * <p>Abstract class that defines {@link MutationDescriptor}'s hierarchy base test suit. 
 * The class serves as the base class for all concrete mutation descriptors test suites, 
 * therefore ensuring that inherited behavior is not accidentally broken. </p>
 * 
 * <p> Derived classes must override the setup method to ensure that the test suite fields
 * are initiated with instances of the concrete types. Derived classes must also define the 
 * concrete mutations' effects.</p>
 * 
 * <p> Implementation note: The Ignore annotation is not required because, obviously, JUnit 
 * runner doesn't try to instantiate abstract classes and therefore . We are using it, though, 
 * for increased readability.</p>
 */
@Ignore
public abstract class MutationDescriptorTestBase<T extends BusinessObjectData, M extends MutationDescriptor<T, M>> {

	/** The domain object instance to be used in the test suite, that is, the target of the mutation. */  
	protected T domainObject;
	/** The concrete mutation type instance to be tested by applying it to {@link #domainObject}. */
	protected M mutation;
	/** 
	 * The concrete mutation type instance to be tested by applying it to {@link #domainObject}. 
	 * This mutation is expected to be empty, and the instance is used to verify if the same domain object 
	 * instance is produced when it is applied.
	 */
	protected M emptyMutation;
	
	/**
	 * Abstract method to be defined in derived classes in order to ensure correct initiation of the test
	 * suite's fields.
	 * @throws Exception If any error occurred 
	 */
	@Before
	public abstract void setUp() throws Exception;
	
	@Test
	public void apply_inAValidMutationDescriptor_producesAValidMutation() {
		T result = mutation.apply();
		assertThat(result, is(mutationOf(domainObject)));
	}

	@Test
	public void apply_inAValidMutationDescriptor_producesSameInstanceAsGetResult() {
		T result = mutation.apply();
		assertThat(result, is(sameInstance(mutation.getResult())));
	}
	
	@Test
	public void apply_inAnEmptyMutationDescriptor_producesOriginalDomainObjectInstance() {
		T result = emptyMutation.apply();
		assertThat(result, is(sameInstance(domainObject)));
	}
	
	@Test
	public void applied_inAMutationDescriptorWithNoContinuation_returnsSafely() {
		mutation.apply();
		mutation.applied();
	}
	
	@Test(expected=IllegalStateException.class)
	public void applied_inAMutationDescriptorWithNoCallToApply_throwsException() {
		mutation.applied();
	}
	
	@Test
	public void applied_inAMutationDescriptorWithContinuation_triggersContinuationWithSameInstance() {
		
		// Arrange
		class TestConsumer implements Consumer<M> {
			private boolean executed = false;
			@Override
			public void accept(M in) {
				executed = true;
				assertThat(in, is(sameInstance(mutation)));
			}
		}
		TestConsumer continuation = new TestConsumer();
		mutation.whenApplied(continuation);
		
		// Act
		mutation.apply();
		mutation.applied();

		// Assert
		assertThat(continuation.executed, is(true));
	}
	
	@Test
	public void toString_inAMutationDescriptor_producesStringWithTargetObjectInformation() {
		// The following string literal must match the one used in MutationDescriptor.toString()
		// A public constant field was not used to prevent polluting the type's public interface 
		assertThat(mutation.toString(), containsString("targetDomainObject"));
	}

}
