package com.ossnms.dcn_manager.core.policies.common;

import com.ossnms.dcn_manager.core.policies.common.BoundedExecutor.Signaller;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

public class PartitionedInteractionManagerTest {

    /** Class whose instances represent jobs that trigger the activation of a given channel. */
    private static class MockJob extends Job<Integer> {

        public MockJob(Integer requestEvent) { super(requestEvent); }

        @Override
        public void runJob() { }
    }

    /**
     * Mock implementation of a partitioned interaction manager. This class is used
     * to test the functionalities implemented in the abstract class.
     */
    private static class MockPartitionedInteractionManager extends PartitionedInteractionManager<Job<Integer>> {

        public MockPartitionedInteractionManager(
                int maxSimultaneousInteractions, Executor executionPolicy,
                BiFunction<Integer, Predicate<Job<Integer>>, Optional<Job<Integer>>> upstreamSupplier) {
            super(maxSimultaneousInteractions, "MOCK", executionPolicy, upstreamSupplier);
        }

        public MockJob scheduleMockJob(@Nonnull final Integer event) {

            // Create job and add it to the queue, passing in the predicate to be used to check if the created job
            // cancels any pending job
            final MockJob job = spy(new MockJob(event));
            schedulePartitionInteraction(
                    event,
                    job,
                    retainedJob -> retainedJob.getOriginatingEvent().equals(event)
            );
            return job;
        }

        public void onMockJobCompletion(int partitionId) {
            onInteractionEnded(i -> true);
        }

        public void onMockJobCompletion() {
            onInteractionEnded(i -> true);
        }

        public void onMockJobCancellation(int partitionId) {
            // Select any job
            super.unschedulePartitionInteraction(partitionId, i -> true);
        }

        public void onMockJobCancellation() {
            super.unscheduleInteraction(i -> true);
        }

        public void onMockEvent(int partitionId) {
            onEvent(partitionId, new Signaller<Job<Integer>>() {
                // Select any job
                @Override public boolean select(@Nonnull Job<Integer> input) { return true; }
                // Require execution of additional code
                @Override public Optional<Runnable> signal(@Nonnull Job<Integer> job) {
                    return Optional.<Runnable>of(() -> { }); }
            });
        }

        public void onMockEvent() {
            onEvent(new Signaller<Job<Integer>>() {
                // Select any job
                @Override public boolean select(@Nonnull Job<Integer> input) { return true; }
                // Require execution of additional code
                @Override public Optional<Runnable> signal(@Nonnull Job<Integer> job) {
                    return Optional.<Runnable>of(() -> { }); }
            });
        }
    }

    private Executor executionPolicy;
    private MockPartitionedInteractionManager interactionManager;
    private BiFunction<Integer, Predicate<Job<Integer>>, Optional<Job<Integer>>> upstreamSupplier;

    private static final int DEFAULT_UPPER_BOUND = 4;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() {
        upstreamSupplier = mock(BiFunction.class);
        executionPolicy = mock(Executor.class);

        doAnswer(invocation -> {
            ((Runnable) invocation.getArguments()[0]).run();
            return null;
        }).when(executionPolicy).execute(Mockito.any(Runnable.class));

        interactionManager = new MockPartitionedInteractionManager(DEFAULT_UPPER_BOUND, executionPolicy, upstreamSupplier);
    }

    @Test(expected=IllegalArgumentException.class)
    public void testInitialization_withZeroMaxInteractions_throwsException() {
        new MockPartitionedInteractionManager(0, executionPolicy, upstreamSupplier);
    }

    @Test(expected=IllegalArgumentException.class)
    public void testInitialization_withNegativeMaxInteractions_throwsException() {
        new MockPartitionedInteractionManager(-2, executionPolicy, upstreamSupplier);
    }

    @Test
    public void getOngoingJobCount_onUnexistingPartition_returnsZero() {
        final int partitionId = 1;
        assertThat(interactionManager.getOngoingJobCount(partitionId), is(equalTo(0)));
    }

    @Test
    public void getPendingJobCount_onUnexistingPartition_returnsZero() {
        final int partitionId = 1;
        assertThat(interactionManager.getPendingJobCount(partitionId), is(equalTo(0)));
    }

    @Test
    public void getMaxOngoingJobCount_onUnexistingPartition_returnsDefaultValue() {
        final int partitionId = 1;
        assertThat(interactionManager.getMaxOngoingJobCount(partitionId), is(equalTo(DEFAULT_UPPER_BOUND)));
    }

    @Test
    public void setMaxOngoingJobCount_onUnexistingPartition_CreatesQueueAndSetsThreshold() {
        final int partitionId = 1;
        final int newMaxInteractions = 3;
        interactionManager.setMaxOngoingJobCount(partitionId, newMaxInteractions);
        assertThat(interactionManager.getOngoingJobCount(), is(equalTo(0)));
        assertThat(interactionManager.getOngoingJobCount(partitionId), is(equalTo(0)));
        assertThat(interactionManager.getMaxOngoingJobCount(partitionId), is(equalTo(newMaxInteractions)));

        assertJobsStream(interactionManager.getOngoingJobs(),0);
    }

    @Test
    public void schedulePartitionInteraction_onUnexistingPartition_CreatesQueueWithCorrectStateAndSchedulesWork() {
        final int partitionId = 1;
        final MockJob mockJob = interactionManager.scheduleMockJob(partitionId);
        assertThat(interactionManager.getOngoingJobCount(), is(equalTo(1)));
        assertThat(interactionManager.getOngoingJobCount(partitionId), is(equalTo(1)));
        assertThat(interactionManager.getPendingJobCount(), is(equalTo(0)));
        assertThat(interactionManager.getPendingJobCount(partitionId), is(equalTo(0)));
        assertThat(interactionManager.getMaxOngoingJobCount(partitionId), is(equalTo(DEFAULT_UPPER_BOUND)));

        assertJobsStream(interactionManager.getOngoingJobs(), 1, mockJob);
        assertJobsStream(interactionManager.getOngoingJobs(partitionId), 1, mockJob);
        assertJobsStream(interactionManager.getPendingJobs(), 0);
        assertJobsStream(interactionManager.getPendingJobs(partitionId), 0);
    }

    private void assertJobsStream(final Stream<PolicyJob<?>> jobs, final int size, final PolicyJob<?> ...jobsToTest) {
        assertThat(jobs, notNullValue());
        final Set<PolicyJob<?>> jobsAsSet = jobs.collect(Collectors.toSet());
        assertThat(jobsAsSet.size(), is(size));
        if(jobsToTest.length > 0){
            assertThat(jobsAsSet, Matchers.containsInAnyOrder(jobsToTest));
        }
    }

    @Test
    public void onCancellation_NoOngoingWork_hasNoEffect() {
        interactionManager.onMockJobCancellation();
        assertThat(interactionManager.getOngoingJobCount(), is(equalTo(0)));
        assertThat(interactionManager.getPendingJobCount(), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(), 0);
        assertJobsStream(interactionManager.getPendingJobs(), 0);
    }

    @Test
    public void onInteractionEnded_withNoOngoingWork_hasNoEffect() {
        interactionManager.onMockJobCompletion();
        assertThat(interactionManager.getOngoingJobCount(), is(equalTo(0)));
        assertThat(interactionManager.getPendingJobCount(), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(), 0);
        assertJobsStream(interactionManager.getPendingJobs(), 0);
    }

    @Test
    public void onEvent_withNoOngoingWork_hasNoEffect() {
        interactionManager.onMockEvent();
        verifyZeroInteractions(executionPolicy);
    }

    @Test
    public void onCancellation_withOngoingWork_correctlyUpdatesOngoingWorkEstimate() {
        final int partitionId = 1;
        final MockJob mockJob = interactionManager.scheduleMockJob(partitionId);
        assertThat(interactionManager.getOngoingJobCount(), is(equalTo(1)));
        assertThat(interactionManager.getPendingJobCount(), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(), 1, mockJob);
        assertJobsStream(interactionManager.getPendingJobs(), 0);

        interactionManager.onMockJobCancellation();
        assertThat(interactionManager.getOngoingJobCount(), is(equalTo(0)));
        assertThat(interactionManager.getPendingJobCount(), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(), 0);
        assertJobsStream(interactionManager.getPendingJobs(), 0);
    }

    @Test
    public void onInteractionEnded_withOngoingWork_correctlyUpdatesOngoingWorkEstimate() {
        final int partitionId = 1;
        final MockJob mockJob = interactionManager.scheduleMockJob(partitionId);
        assertThat(interactionManager.getOngoingJobCount(), is(equalTo(1)));
        assertThat(interactionManager.getPendingJobCount(), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(), 1, mockJob);
        assertJobsStream(interactionManager.getPendingJobs(), 0);

        interactionManager.onMockJobCompletion();
        assertThat(interactionManager.getOngoingJobCount(), is(equalTo(0)));
        assertThat(interactionManager.getPendingJobCount(), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(), 0);
        assertJobsStream(interactionManager.getPendingJobs(), 0);
    }

    @Test
    public void onEvent_withOngoingWork_correctlySubmitsCode() {
        final int partitionId = 1;
        interactionManager.scheduleMockJob(partitionId);
        interactionManager.onMockJobCompletion();
        verify(executionPolicy).execute(isA(Runnable.class));
    }

    @Test
    public void onPartitionInteractionEnded_withNoOngoingWork_hasNoEffect() {
        final int partitionId = 1;
        interactionManager.onMockJobCompletion(partitionId);
        assertThat(interactionManager.getOngoingJobCount(partitionId), is(equalTo(0)));
        assertThat(interactionManager.getPendingJobCount(partitionId), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(partitionId), 0);
        assertJobsStream(interactionManager.getPendingJobs(partitionId), 0);
    }

    @Test
    public void onPartitionCancellation_withNoOngoingWork_hasNoEffect() {
        final int partitionId = 1;
        interactionManager.onMockJobCancellation(partitionId);
        assertThat(interactionManager.getOngoingJobCount(partitionId), is(equalTo(0)));
        assertThat(interactionManager.getPendingJobCount(partitionId), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(partitionId), 0);
        assertJobsStream(interactionManager.getPendingJobs(partitionId), 0);
    }

    @Test
    public void onPartitionEvent_withNoOngoingWork_hasNoEffect() {
        final int partitionId = 1;
        interactionManager.onMockEvent(partitionId);
        verifyZeroInteractions(executionPolicy);
    }

    @Test
    public void onPartitionInteractionEnded_withOngoingWork_correctlyUpdatesOngoingWorkEstimate() {
        final int partitionId = 1;
        interactionManager.scheduleMockJob(partitionId);
        assertThat(interactionManager.getOngoingJobCount(partitionId), is(equalTo(1)));
        assertThat(interactionManager.getPendingJobCount(partitionId), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(partitionId), 1);
        assertJobsStream(interactionManager.getPendingJobs(partitionId), 0);

        interactionManager.onMockJobCompletion(partitionId);
        assertThat(interactionManager.getOngoingJobCount(partitionId), is(equalTo(0)));
        assertThat(interactionManager.getPendingJobCount(partitionId), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(partitionId), 0);
        assertJobsStream(interactionManager.getPendingJobs(partitionId), 0);
    }

    @Test
    public void onPartitionEvent_withOngoingWork_correctlySubmitsCode() {
        final int partitionId = 1;
        interactionManager.scheduleMockJob(partitionId);
        interactionManager.onMockEvent(partitionId);
        verify(executionPolicy, times(2)).execute(isA(Runnable.class)); // once for the mock job and once for the event code
    }

    @Test
    public void onPartitionCancellation_withOngoingWork_correctlyCancelsAndUpdatesOngoingWorkEstimate() {
        final int partitionId = 1;
        final MockJob job = interactionManager.scheduleMockJob(partitionId);
        interactionManager.onMockJobCancellation(partitionId);
        assertThat(interactionManager.getOngoingJobCount(partitionId), is(equalTo(0)));
        assertThat(interactionManager.getPendingJobCount(partitionId), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(partitionId), 0);
        assertJobsStream(interactionManager.getPendingJobs(partitionId), 0);
        verify(job).cancel();
    }

    @Test
    public void onPartitionRemoval_withoutAnyInteraction() throws Exception {
        interactionManager.removePartition(1);
        assertThat(interactionManager.getOngoingJobCount(), is(equalTo(0)));
        assertThat(interactionManager.getPendingJobCount(), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(), 0);
        assertJobsStream(interactionManager.getPendingJobs(), 0);
    }

    @Test
    public void onPartitionRemoval_withOngoingJob_throwsExceptionAfterRemoval() throws Exception {
        interactionManager.scheduleMockJob(1);
        assertThat(interactionManager.getOngoingJobCount(), is(equalTo(1)));
        try {
            interactionManager.removePartition(1);
            fail("No exception with ongoing work");
        } catch (final IllegalStateException e) {
            // good.
        }
        assertThat(interactionManager.getOngoingJobCount(), is(equalTo(0)));
        assertThat(interactionManager.getPendingJobCount(), is(equalTo(0)));
        assertJobsStream(interactionManager.getOngoingJobs(), 0);
        assertJobsStream(interactionManager.getPendingJobs(), 0);
    }

    @Test
    public void pullsWorkFromPendingPartition() throws Exception {

        interactionManager.setMaxOngoingJobCount(1, 1);
        interactionManager.setMaxOngoingJobCount(2, 1);

        // allow queue #1 job to be ongoing but #2 job will be pending
        doAnswer(invocation -> {
            final MockJob job = (MockJob) invocation.getArguments()[0];
            if (2 == job.getOriginatingEvent()) {
                throw new RejectedExecutionException();
            }
            job.run();
            return null;
        }).when(executionPolicy).execute(any(Runnable.class));

        final MockJob mockJob1 = interactionManager.scheduleMockJob(1);
        final MockJob mockJob2 = interactionManager.scheduleMockJob(2);

        assertThat(interactionManager.getOngoingJobCount(1), is(1));
        assertThat(interactionManager.getOngoingJobCount(2), is(0));
        assertJobsStream(interactionManager.getOngoingJobs(1),1, mockJob1);
        assertJobsStream(interactionManager.getOngoingJobs(2),0);

        assertThat(interactionManager.getPendingJobCount(1), is(0));
        assertThat(interactionManager.getPendingJobCount(2), is(1));
        assertJobsStream(interactionManager.getPendingJobs(1), 0);
        assertJobsStream(interactionManager.getPendingJobs(2), 1, mockJob2);

        final Optional<Job<Integer>> workForExecution = interactionManager.getRetainedWorkForExecution(i -> true);

        assertThat(workForExecution.isPresent(), is(true));

        assertThat(interactionManager.getOngoingJobCount(1), is(1));
        assertThat(interactionManager.getOngoingJobCount(2), is(1));
        assertJobsStream(interactionManager.getOngoingJobs(1), 1, mockJob1);
        assertJobsStream(interactionManager.getOngoingJobs(2), 1, mockJob2);

        assertThat(interactionManager.getPendingJobCount(1), is(0));
        assertThat(interactionManager.getPendingJobCount(2), is(0));
        assertJobsStream(interactionManager.getPendingJobs(1), 0);
        assertJobsStream(interactionManager.getPendingJobs(2), 0);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void pullsWorkFromUpstreamWhenEmpty() throws Exception {

        final MockJob job = new MockJob(2);

        interactionManager.setMaxOngoingJobCount(1, 1);
        interactionManager.setMaxOngoingJobCount(2, 1);

        assertThat(interactionManager.getOngoingJobCount(1), is(0));
        assertThat(interactionManager.getOngoingJobCount(2), is(0));
        assertJobsStream(interactionManager.getOngoingJobs(1), 0);
        assertJobsStream(interactionManager.getOngoingJobs(2), 0);

        assertThat(interactionManager.getPendingJobCount(1), is(0));
        assertThat(interactionManager.getPendingJobCount(2), is(0));
        assertJobsStream(interactionManager.getPendingJobs(1), 0);
        assertJobsStream(interactionManager.getPendingJobs(2), 0);

        when(upstreamSupplier.apply(eq(1), isA(Predicate.class))).thenReturn(Optional.empty());
        when(upstreamSupplier.apply(eq(2), isA(Predicate.class))).thenReturn(Optional.of(job));

        final Optional<Job<Integer>> workForExecution = interactionManager.getRetainedWorkForExecution(i -> true);

        assertThat(workForExecution, is(Optional.of(job)));

        assertThat(interactionManager.getOngoingJobCount(1), is(0));
        assertThat(interactionManager.getOngoingJobCount(2), is(1));
        assertJobsStream(interactionManager.getOngoingJobs(1), 0);
        assertJobsStream(interactionManager.getOngoingJobs(2), 1, job);

        assertThat(interactionManager.getPendingJobCount(1), is(0));
        assertThat(interactionManager.getPendingJobCount(2), is(0));
        assertJobsStream(interactionManager.getPendingJobs(1), 0);
        assertJobsStream(interactionManager.getPendingJobs(2), 0);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void pullsWorkFromUpstreamWhenEmpty_doesNothingIfUnavailable() throws Exception {

        interactionManager.setMaxOngoingJobCount(1, 1);
        interactionManager.setMaxOngoingJobCount(2, 1);

        assertThat(interactionManager.getOngoingJobCount(1), is(0));
        assertThat(interactionManager.getOngoingJobCount(2), is(0));
        assertJobsStream(interactionManager.getOngoingJobs(1), 0);
        assertJobsStream(interactionManager.getOngoingJobs(2),0);

        assertThat(interactionManager.getPendingJobCount(1), is(0));
        assertThat(interactionManager.getPendingJobCount(2), is(0));
        assertJobsStream(interactionManager.getPendingJobs(1), 0);
        assertJobsStream(interactionManager.getPendingJobs(2), 0);

        when(upstreamSupplier.apply(isA(Integer.class), isA(Predicate.class))).thenReturn(Optional.empty());

        final Optional<Job<Integer>> workForExecution = interactionManager.getRetainedWorkForExecution(i -> true);

        assertThat(workForExecution, is(Optional.empty()));

        assertThat(interactionManager.getOngoingJobCount(1), is(0));
        assertThat(interactionManager.getOngoingJobCount(2), is(0));
        assertJobsStream(interactionManager.getOngoingJobs(1), 0);
        assertJobsStream(interactionManager.getOngoingJobs(2), 0);

        assertThat(interactionManager.getPendingJobCount(1), is(0));
        assertThat(interactionManager.getPendingJobCount(2), is(0));
        assertJobsStream(interactionManager.getPendingJobs(1), 0);
        assertJobsStream(interactionManager.getPendingJobs(2), 0);
    }
}
