package com.ossnms.dcn_manager.core.test;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

public final class RunRunnableAnswer implements Answer<Void> {
    @Override
    public Void answer(InvocationOnMock invocation) throws Throwable {
        final Runnable task = (Runnable) invocation.getArguments()[0];
        if (task != null) {
            task.run();
        }
        return null;
    }
}