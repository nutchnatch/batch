package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.ChannelConnectionManager;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.test.RunRunnableAnswer;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.concurrent.RejectedExecutionException;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

public class ChannelInteractionManagerImplTest {

    private ChannelConnectionManager connectionManager;
    private ObservableExecutor executionPolicy;
    private ChannelInteractionManagerImpl manager;

    @Before
    public void setUp() {
        connectionManager = mock(ChannelConnectionManager.class);

        executionPolicy = mock(ObservableExecutor.class);
        doAnswer(new RunRunnableAnswer()).when(executionPolicy).execute(isA(Runnable.class));

        manager = new ChannelInteractionManagerImpl(connectionManager, executionPolicy);
    }

    @Test
    public void testScheduleActivation() {

        manager.scheduleActivation(new Activate(10, 1, Collections.singleton(100)));

        verify(connectionManager).connect(100);
    }

    @Test
    public void testScheduleDeactivation() {

        manager.scheduleDeactivation(new Deactivate(10, 1, Collections.singleton(100)));

        verify(connectionManager).disconnect(100);
    }

    @Test
    public void testCancelDeactivation_withAPendingDeactivation_cancelsJob() {

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        manager.scheduleDeactivation(new Deactivate(10, 99, Collections.singleton(1)));
        manager.scheduleDeactivation(new Deactivate(20, 99, Collections.singleton(2)));

        // Cancel deactivation, which should cancel one of the retained deactivations.
        manager.cancelDeactivations(new Deactivate(10, 99, Collections.singleton(1)));

        verify(executionPolicy, times(5)).execute(any(Runnable.class)); // due to the rejection, scheduling attempts submit twice.

        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));
    }

    @Test
    public void testCancelActivation_withAPendingActivation_cancelsJob() {

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        manager.scheduleActivation(new Activate(10, 99, Collections.singleton(1)));
        manager.scheduleActivation(new Activate(20, 99, Collections.singleton(2)));

        // Cancel activation, which should cancel one of the retained deactivations.
        manager.cancelActivations(new Activate(10, 99, Collections.singleton(1)));

        verify(executionPolicy, times(5)).execute(any(Runnable.class)); // due to the rejection, scheduling attempts submit twice.

        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));
    }

    @Test
    public void testScheduleDeactivation_withAPendingActivation_cancelsJob() {

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        manager.scheduleActivation(new Activate(10, 99, Collections.singleton(1)));
        manager.scheduleActivation(new Activate(20, 99, Collections.singleton(2)));

        // Schedule deactivation, which should cancel one of the retained activations.
        manager.scheduleDeactivation(new Deactivate(10, 99, Collections.singleton(1)));

        verify(executionPolicy, times(4)).execute(any(Runnable.class)); // due to the rejection, scheduling attempts submit twice.

        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));
    }

    @Test
    public void testScheduleActivation_withAPendingDeactivation_cancelsJob() {

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        manager.scheduleDeactivation(new Deactivate(10, 99, Collections.singleton(1)));
        manager.scheduleDeactivation(new Deactivate(20, 99, Collections.singleton(2)));

        // Schedule activation, which should cancel one of the retained deactivations.
        manager.scheduleActivation(new Activate(10, 99, Collections.singleton(1)));

        verify(executionPolicy, times(4)).execute(any(Runnable.class)); // due to the rejection, scheduling attempts submit twice.

        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));
    }

    @Test
    public void testOnMediatorInteractionEnded_withANonOngoingInteraction_producesNoEffect() {

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        manager.scheduleActivation(new Activate(10, 99, Collections.singleton(1)));

        manager.onChannelInteractionEnded(new ActualChannelStateEvent.ChannelActivatedEvent(10, new PhysicalChannelStateEvent.PhysicalChannelActivatedEvent(20, 2, true)));

        verify(executionPolicy, times(3)).execute(any(Runnable.class)); // due to the rejection, scheduling attempts submit twice.
        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));
    }

    @Test
    public void testOnMediatorInteractionEnded_withAnOngoingInteraction_correctlyUpdatesOngoingJobsEstimate() {

        manager.scheduleActivation(new Activate(10, 99, Collections.singleton(1)));

        manager.onChannelInteractionEnded(new ActualChannelStateEvent.ChannelActivatedEvent(10, new PhysicalChannelStateEvent.PhysicalChannelActivatedEvent(10, 1, true)));

        verify(executionPolicy, times(1)).execute(any(Runnable.class));
        assertThat(manager.getOngoingJobCount(), is(1));
        assertThat(manager.getPendingJobCount(), is(0));
    }

    @Test
    public void testOnMediatorInteractionEnded_withPendingJobs_dispatchesRetainedJob() {

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        manager.scheduleActivation(new Activate(10, 99, Collections.singleton(1)));

        manager.onChannelInteractionEnded(new ActualChannelStateEvent.ChannelActivatedEvent(10, new PhysicalChannelStateEvent.PhysicalChannelActivatedEvent(20, 2, true)));

        verify(executionPolicy, times(3)).execute(any(Runnable.class)); // due to the rejection, scheduling attempts submit twice.
        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));
    }


    @Test
    public void testRunsPendingJobsOnLimitedCapacity() throws Exception {

        // should retain this job because the underlying executor is full.
        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));
        manager.scheduleActivation(new Activate(10, 1, Collections.singleton(100)));
        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));

        // we now "release" the executor and submit a new job.
        doAnswer(new RunRunnableAnswer()).when(executionPolicy).execute(isA(Runnable.class));
        manager.scheduleActivation(new Activate(10, 1, Collections.singleton(200)));

        // it should have submitted and executed both jobs.
        assertThat(manager.getOngoingJobCount(), is(2));
        assertThat(manager.getPendingJobCount(), is(0));
        verify(connectionManager).connect(100);
        verify(connectionManager).connect(200);
    }

}
