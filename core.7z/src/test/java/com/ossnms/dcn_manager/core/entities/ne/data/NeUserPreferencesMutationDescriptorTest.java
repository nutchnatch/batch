package com.ossnms.dcn_manager.core.entities.ne.data;

import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

public class NeUserPreferencesMutationDescriptorTest {

    private static final int VERSION = 0;
    private static final int NE_ID = 4;

    private final NeUserPreferencesData dataWithContainerId =
            new NeUserPreferencesBuilder().setName("a").setContainerId(Optional.of(3)).build(NE_ID, VERSION);

    @Test
    public void clearContainerId() {
        final NeUserPreferencesMutationDescriptor descriptor = new NeUserPreferencesMutationDescriptor(dataWithContainerId);

        descriptor.clearContainerId();
        assertThat(descriptor.getContainerId(), is(absent()));

        final NeUserPreferencesData newData = descriptor.apply();
        assertThat(newData.getContainerId(), is(absent()));
        assertThat(newData, not(dataWithContainerId));
    }

    @Test
    public void setAbsentContainerId_clearsIt() {
        final NeUserPreferencesMutationDescriptor descriptor = new NeUserPreferencesMutationDescriptor(dataWithContainerId);

        descriptor.setContainerId(Optional.<Integer>empty());
        assertThat(descriptor.getContainerId(), is(absent()));

        final NeUserPreferencesData newData = descriptor.apply();
        assertThat(newData.getContainerId(), is(absent()));
        assertThat(newData, not(dataWithContainerId));
    }

    @Test
    public void setPresentContainer_changesIt() {
        final NeUserPreferencesMutationDescriptor descriptor = new NeUserPreferencesMutationDescriptor(dataWithContainerId);

        descriptor.setContainerId(Optional.of(400));
        assertThat(descriptor.getContainerId(), hasValue(400));

        final NeUserPreferencesData newData = descriptor.apply();
        assertThat(newData.getContainerId(), hasValue(400));
        assertThat(newData, not(dataWithContainerId));
    }

    @Test
    public void setDirectRouteKey_createsIt() throws Exception {
        final NeUserPreferencesMutationDescriptor descriptor = new NeUserPreferencesMutationDescriptor(dataWithContainerId);

        descriptor.getDirectRouteAdapter().setKey("createdKey");
        assertThat(descriptor.getDirectRouteAdapter().getKey(), hasValue("createdKey"));

        final NeUserPreferencesData newData = descriptor.apply();
        assertThat(newData.getDirectRoute().getKey(), is("createdKey"));
    }

    @Test
    public void setDirectRouteKey_changesIt() throws Exception {
        final NeUserPreferencesBuilder prefsBuilder = new NeUserPreferencesBuilder().setName("a");
        prefsBuilder.getDirectRouteAdapter().setKey("existing");
        prefsBuilder.build(NE_ID, VERSION);

        final NeUserPreferencesMutationDescriptor descriptor = new NeUserPreferencesMutationDescriptor(dataWithContainerId);
        descriptor.getDirectRouteAdapter().setKey("newKey");
        assertThat(descriptor.getDirectRouteAdapter().getKey(), hasValue("newKey"));

        final NeUserPreferencesData newData = descriptor.apply();
        assertThat(newData.getDirectRoute().getKey(), is("newKey"));
    }

    @Test
    public void setNullDirectRouteKey_clearsIt() throws Exception {
        final NeUserPreferencesBuilder prefsBuilder = new NeUserPreferencesBuilder().setName("a");
        prefsBuilder.getDirectRouteAdapter().setKey("existing");
        prefsBuilder.build(NE_ID, VERSION);

        final NeUserPreferencesMutationDescriptor descriptor = new NeUserPreferencesMutationDescriptor(dataWithContainerId);
        descriptor.getDirectRouteAdapter().setKey(null);
        assertThat(descriptor.getDirectRouteAdapter().getKey(), is(absent()));

        final NeUserPreferencesData newData = descriptor.apply();
        assertThat(newData.getDirectRoute().getKey(), is(nullValue()));
    }

    @Test
    public void setEmptyDirectRouteKey_clearsIt() throws Exception {
        final NeUserPreferencesBuilder prefsBuilder = new NeUserPreferencesBuilder().setName("a");
        prefsBuilder.getDirectRouteAdapter().setKey("existing");
        prefsBuilder.build(NE_ID, VERSION);

        final NeUserPreferencesMutationDescriptor descriptor = new NeUserPreferencesMutationDescriptor(dataWithContainerId);
        descriptor.getDirectRouteAdapter().setKey("");
        assertThat(descriptor.getDirectRouteAdapter().getKey(), is(absent()));

        final NeUserPreferencesData newData = descriptor.apply();
        assertThat(newData.getDirectRoute().getKey(), is(nullValue()));
    }

    @Test
    public void setNullDirectRouteKeyOnNullExisting_noOp() throws Exception {
        assertThat(dataWithContainerId.getDirectRoute().getKey(), is(nullValue())); // pre-test sanity check

        final NeUserPreferencesMutationDescriptor descriptor = new NeUserPreferencesMutationDescriptor(dataWithContainerId);

        descriptor.getDirectRouteAdapter().setKey(null);
        assertThat(descriptor.getDirectRouteAdapter().getKey(), is(absent()));

        final NeUserPreferencesData newData = descriptor.apply();
        assertThat(newData.getDirectRoute().getKey(), is(nullValue()));
    }
    
    @Test
    public void setDataTransferSettingsAdapter_createsIt() throws Exception {
        final String USERNAME = "username";
        final String PASSWORD = "password";
        final NeUserPreferencesMutationDescriptor descriptor = new NeUserPreferencesMutationDescriptor(dataWithContainerId);

        descriptor.getDataTransferSettingsAdapter().setUsername(Optional.of(USERNAME));
        descriptor.getDataTransferSettingsAdapter().setPassword(Optional.of(PASSWORD));
        assertThat(descriptor.getDataTransferSettingsAdapter().getUsername().get(), is(USERNAME));
        assertThat(descriptor.getDataTransferSettingsAdapter().getPassword().get(), is(PASSWORD));

        final NeUserPreferencesData newData = descriptor.apply();
        assertThat(newData.getDataTransferSettings().getUsername().get(), is(USERNAME));
        assertThat(newData.getDataTransferSettings().getPassword().get(), is(PASSWORD));
    }
    
}
