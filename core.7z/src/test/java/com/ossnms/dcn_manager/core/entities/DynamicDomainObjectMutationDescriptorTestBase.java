package com.ossnms.dcn_manager.core.entities;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

import org.junit.Ignore;
import org.junit.Test;

import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectData;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectMutationDescriptor;

/**
 * <p>Abstract class that defines {@link DynamicBusinessObjectMutationDescriptor}'s hierarchy base
 * test suit. The class serves as the base class for all concrete mutation descriptors test suites,
 * therefore ensuring that inherited behavior is not accidentally broken. </p>
 *
 * <p> Derived classes must override the setup method to ensure that the test suite fields
 * are initiated with instances of the concrete types. </p>
 *
 * <p> Implementation note: The Ignore annotation is not required because, obviously, JUnit
 * runner doesn't try to instantiate abstract classes and therefore . We are using it, though,
 * for increased readability.</p>
 */
@Ignore
public abstract class DynamicDomainObjectMutationDescriptorTestBase<T extends DynamicBusinessObjectData, M extends DynamicBusinessObjectMutationDescriptor<T, M>>
	extends MutationDescriptorTestBase<T, M> {

	// The following string literal must match the one used in DynamicBusinessObjectMutationDescriptor.toString()
	// Public constant fields were not used to prevent polluting the type's public interface
	private static final String DYNAMIC_PROPERTIES_TOSTRING_KEY = "new properties";

	@Test
	public void toString_onANonEmptyMutation_returnsStringWithMutationInfo() {
		assertThat(mutation.toString(), containsString(DYNAMIC_PROPERTIES_TOSTRING_KEY));
	}

	@Test
	public void toString_onAMutationWithoutDynamicProperties_returnsStringWithoutThatInfo() {
		assertThat(emptyMutation.toString(), not(containsString(DYNAMIC_PROPERTIES_TOSTRING_KEY)));
	}
}
