package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorConnectionManager;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.test.RunRunnableAnswer;
import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.RejectedExecutionException;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

public class MediatorInteractionManagerImplTest {

    private MediatorConnectionManager connectionManager;
    private ObservableExecutor executionPolicy;
    private MediatorInteractionManagerImpl manager;

    @Before
    public void setUp() {
        connectionManager = mock(MediatorConnectionManager.class);
        executionPolicy = mock(ObservableExecutor.class);

        doAnswer(new RunRunnableAnswer()).when(executionPolicy).execute(isA(Runnable.class));

        manager = new MediatorInteractionManagerImpl(connectionManager, executionPolicy);
    }

    @Test
    public void testScheduleActivation() {

        manager.scheduleActivation(new ActivateMediatorEvent(10, 1));

        verify(connectionManager).connect(1);
    }

    @Test
    public void testScheduleDeactivation() {

        manager.scheduleDeactivation(new DeactivateMediatorEvent(10, 2));

        verify(connectionManager).disconnect(2);
    }

    @Test
    public void testScheduleDeactivation_withAPendingActivation_cancelsJob() {

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        manager.scheduleActivation(new ActivateMediatorEvent(10, 1));
        manager.scheduleActivation(new ActivateMediatorEvent(20, 2));

        // Schedule deactivation, which should cancel one of the retained activations.
        manager.scheduleDeactivation(new DeactivateMediatorEvent(10, 1));

        verify(executionPolicy, times(4)).execute(any(Runnable.class)); // due to the rejection, scheduling attempts submit twice.

        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));
    }

    @Test
    public void testScheduleActivation_withAPendingDeactivation_cancelsJob() {

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        manager.scheduleDeactivation(new DeactivateMediatorEvent(10, 1));
        manager.scheduleDeactivation(new DeactivateMediatorEvent(20, 2));

        // Schedule activation, which should cancel one of the retained deactivations.
        manager.scheduleActivation(new ActivateMediatorEvent(10, 1));

        verify(executionPolicy, times(4)).execute(any(Runnable.class)); // due to the rejection, scheduling attempts submit twice.

        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));
    }

    @Test
    public void testOnMediatorInteractionEnded_withANonOngoingInteraction_producesNoEffect() {

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        manager.scheduleActivation(new ActivateMediatorEvent(10, 1));

        manager.onMediatorInteractionEnded(new ActualMediatorStateEvent.MediatorActivatedEvent(10, new PhysicalMediatorStateEvent.PhysicalMediatorActivatedEvent(20, 2, true)));

        verify(executionPolicy, times(3)).execute(any(Runnable.class)); // due to the rejection, scheduling attempts submit twice.
        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));
    }

    @Test
    public void testOnMediatorInteractionEnded_withAnOngoingInteraction_correctlyUpdatesOngoingJobsEstimate() {

        manager.scheduleActivation(new ActivateMediatorEvent(10, 1));

        manager.onMediatorInteractionEnded(new ActualMediatorStateEvent.MediatorActivatedEvent(10, new PhysicalMediatorStateEvent.PhysicalMediatorActivatedEvent(10, 1, true)));

        verify(executionPolicy, times(1)).execute(any(Runnable.class));
        assertThat(manager.getOngoingJobCount(), is(1));
        assertThat(manager.getPendingJobCount(), is(0));
    }

    @Test
    public void testOnMediatorInteractionEnded_withPendingJobs_dispatchesRetainedJob() {

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        manager.scheduleActivation(new ActivateMediatorEvent(10, 1));

        manager.onMediatorInteractionEnded(new ActualMediatorStateEvent.MediatorActivatedEvent(10, new PhysicalMediatorStateEvent.PhysicalMediatorActivatedEvent(20, 2, true)));

        verify(executionPolicy, times(3)).execute(any(Runnable.class)); // due to the rejection, scheduling attempts submit twice.
        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));
    }

    @Test
    public void testRunsPendingJobsOnLimitedCapacity() throws Exception {

        // should retain this job because the underlying executor is full.
        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));
        manager.scheduleActivation(new ActivateMediatorEvent(10, 1));
        assertThat(manager.getOngoingJobCount(), is(0));
        assertThat(manager.getPendingJobCount(), is(1));

        // we now "release" the executor and submit a new job.
        doAnswer(new RunRunnableAnswer()).when(executionPolicy).execute(isA(Runnable.class));
        manager.scheduleActivation(new ActivateMediatorEvent(10, 2));

        // it should have submitted and executed both jobs.
        assertThat(manager.getOngoingJobCount(), is(2));
        assertThat(manager.getPendingJobCount(), is(0));
        verify(connectionManager).connect(1);
        verify(connectionManager).connect(2);
    }


/*
    @Test
    public void testScheduleActivation_allowedByPolicy_dispatchesJobExecution() {

        final int maxInteractions = 4;
        final MediatorInteractionManager manager = createMediatorInteractionManager(maxInteractions, executionPolicy, connectionManager);

        scheduleActivations(manager, maxInteractions);

        verify(executionPolicy, times(maxInteractions)).execute(any(Runnable.class));
        assertThat(manager.getOngoingJobCount(), is(both(equalTo(maxInteractions)).and(equalTo(manager.getMaxOngoingJobCount()))));
        assertThat(manager.getPendingJobCount(), is(equalTo(0)));
    }


    @Test
    public void testScheduleActivation_allowedByPolicy_dispatchesCorrectJob() throws ConnectException {
        final int maxInteractions = 1;
        final int mediatorId = 1;
        final MediatorInteractionManager manager = createMediatorInteractionManager(maxInteractions, executionPolicy, connectionManager);

        doAnswer(new Answer<Void>() {
            @Override
            public Void answer(InvocationOnMock invocation) {
                ((Runnable) invocation.getArguments()[0]).run();
                return null;
            }}).when(executionPolicy).execute(any(Runnable.class));

        manager.scheduleActivation(new RequiredMediatorStateEvent.ActivateMediatorEvent(mediatorId));

        verify(executionPolicy, times(1)).execute(any(Runnable.class));
        verify(connectionManager, times(1)).connect(mediatorId);
    }

    @Test
    public void testScheduleDeactivation_allowedByPolicy_dispatchesCorrectJob() throws ConnectException {
        final int maxInteractions = 1;
        final int mediatorId = 1;
        final MediatorInteractionManager manager = createMediatorInteractionManager(maxInteractions, executionPolicy, connectionManager);

        doAnswer(new Answer<Void>() {
            @Override
            public Void answer(InvocationOnMock invocation) {
                ((Runnable) invocation.getArguments()[0]).run();
                return null;
            }}).when(executionPolicy).execute(any(Runnable.class));

        manager.scheduleDeactivation(new RequiredMediatorStateEvent.DeactivateMediatorEvent(mediatorId));

        verify(executionPolicy, times(1)).execute(any(Runnable.class));
        verify(connectionManager, times(1)).disconnect(mediatorId);
    }

    @Test
    public void testScheduleActivation_withMaximumOngoingInteractions_retainsJob() {

        final int maxInteractions = 4;
        final MediatorInteractionManager manager = createMediatorInteractionManager(maxInteractions, executionPolicy, connectionManager);
        final int retainedInteractions = 2;

        // Schedule activations. maxInteractions jobs should be immediately dispatched for execution, while
        // the remaining (i.e. retainedCount) should be retained
        scheduleActivations(manager, maxInteractions + retainedInteractions);

        verify(executionPolicy, times(maxInteractions)).execute(any(Runnable.class));

        assertThat(manager.getOngoingJobCount(), is(both(equalTo(maxInteractions)).and(equalTo(manager.getMaxOngoingJobCount()))));
        assertThat(manager.getPendingJobCount(), is(equalTo(retainedInteractions)));
    }

    @Test
    public void testOnMediatorInteractionEnded_withRedundantEvent_doesNotDispatchRetainedJob() {

        final int maxInteractions = 1;
        final MediatorInteractionManager manager = createMediatorInteractionManager(maxInteractions, executionPolicy, connectionManager);

        // Schedule activations. maxInteractions jobs should be immediately dispatched for execution, while
        // the remaining (i.e. retainedCount) should be retained
        final int retainedCount = 2;
        scheduleActivations(manager, maxInteractions + retainedCount);

        final int mediatorId = 1;
        manager.onMediatorInteractionEnded(new ActualMediatorStateEvent.MediatorActivatedEvent(mediatorId));

        // Produce redundant event
        manager.onMediatorInteractionEnded(new ActualMediatorStateEvent.MediatorActivatedEvent(mediatorId));

        verify(executionPolicy, times(maxInteractions+1)).execute(any(Runnable.class));
        assertThat(manager.getOngoingJobCount(), is(both(equalTo(maxInteractions)).and(equalTo(manager.getMaxOngoingJobCount()))));
        assertThat(manager.getPendingJobCount(), is(equalTo(retainedCount-1)));
    }

    @Test(expected=IllegalArgumentException.class)
    public void testSetMaxOngoingJobCount_withNonPositiveValue_throwsException() {

        final int initialMaxInteractionsInteractions = 1;
        final int invalidValue = -2;
        createMediatorInteractionManager(initialMaxInteractionsInteractions, executionPolicy, connectionManager).setMaxOngoingJobCount(invalidValue);
    }

    @Test
    public void testSetMaxOngoingJobCount_increasingCapacity_dispatchesCorrespondingWork() {

        final int initialMaxInteractionsInteractions = 2;
        final MediatorInteractionManager manager = createMediatorInteractionManager(initialMaxInteractionsInteractions, executionPolicy, connectionManager);

        // Schedule activations. initialMaxInteractionsInteractions jobs should be immediately dispatched for execution, while
        // the remaining (i.e. retainedCount) should be retained
        final int retainedCount = 4;
        scheduleActivations(manager, initialMaxInteractionsInteractions + retainedCount);

        // Verify set-up
        verify(executionPolicy, times(initialMaxInteractionsInteractions)).execute(any(Runnable.class));
        assertThat(manager.getOngoingJobCount(), is(both(equalTo(initialMaxInteractionsInteractions)).and(equalTo(manager.getMaxOngoingJobCount()))));
        assertThat(manager.getPendingJobCount(), is(equalTo(retainedCount)));

        // Act
        final int newRetainedCount = 1;
        final int newMaxInteractions = initialMaxInteractionsInteractions + retainedCount - newRetainedCount;
        manager.setMaxOngoingJobCount(newMaxInteractions);

        // Verify capacity increase correctness
        verify(executionPolicy, times(newMaxInteractions)).execute(any(Runnable.class));
        assertThat(manager.getOngoingJobCount(), is(both(equalTo(newMaxInteractions)).and(equalTo(manager.getMaxOngoingJobCount()))));
        assertThat(manager.getPendingJobCount(), is(equalTo(newRetainedCount)));
    }

    @Test
    public void testSetMaxOngoingJobCount_decreasingCapacity_correctlyRetainsWork() {

        final int initialMaxInteractionsInteractions = 4;
        final MediatorInteractionManager manager = createMediatorInteractionManager(initialMaxInteractionsInteractions, executionPolicy, connectionManager);

        // Schedule activations. initialMaxInteractionsInteractions jobs should be immediately dispatched for execution, while
        // the remaining (i.e. retainedCount) should be retained
        final int retainedCount = 4;
        scheduleActivations(manager, initialMaxInteractionsInteractions + retainedCount);

        // Verify set-up
        verify(executionPolicy, times(initialMaxInteractionsInteractions)).execute(any(Runnable.class));
        assertThat(manager.getOngoingJobCount(), is(both(equalTo(initialMaxInteractionsInteractions)).and(equalTo(manager.getMaxOngoingJobCount()))));
        assertThat(manager.getPendingJobCount(), is(equalTo(retainedCount)));

        // Act
        final int newMaxInteractions = initialMaxInteractionsInteractions - 2;
        manager.setMaxOngoingJobCount(newMaxInteractions);
        // Signal job completion
        final int mediatorId = 1;
        manager.onMediatorInteractionEnded(new ActualMediatorStateEvent.MediatorActivatedEvent(mediatorId));

        // Verify capacity decrease correctness, meaning, no job was dispatched for execution as a consequence of
        // the previous job completion
        verify(executionPolicy, times(initialMaxInteractionsInteractions)).execute(any(Runnable.class));
        assertThat(manager.getOngoingJobCount(), is(equalTo(initialMaxInteractionsInteractions-1)));
        assertThat(manager.getPendingJobCount(), is(equalTo(retainedCount)));
    }
*/
}
