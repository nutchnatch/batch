package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.policies.common.Job;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;
import com.ossnms.dcn_manager.core.test.RunRunnableAnswer;
import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.*;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

public class PriorityExecutionPolicyTest {

    private Executor executor;
    private SingleThreadFactory threadFactory;
    private CapacityNotificationObserver capacityNotificationObserver;
    private PriorityExecutionPolicy policy;

    private static final class SingleThreadFactory implements ThreadFactory {

        private Thread createdThread;

        @Override
        public Thread newThread(Runnable r) {
            if (null != createdThread) {
                fail("No more than one thread should ever be created!");
            }
            createdThread = new Thread(r);
            return createdThread;
        }

        protected Thread getCreatedThread() {
            return createdThread;
        }

    }

    @Before
    public void setUp() throws Exception {
        executor = mock(Executor.class);
        threadFactory = new SingleThreadFactory();
        capacityNotificationObserver = mock(CapacityNotificationObserver.class);

        policy = new PriorityExecutionPolicy(executor, threadFactory, capacityNotificationObserver);

        doAnswer(new RunRunnableAnswer()).when(executor).execute(any(Runnable.class));
    }

    @Test
    public void execute_submits() {
        final PolicyJob<?> job = mock(PolicyJob.class);
        when(job.getPriority()).thenReturn(PolicyJob.Priority.MEDIUM);

        policy.execute(job);

        verify(job).run();
        assertThat(threadFactory.getCreatedThread(), is(nullValue()));
        verify(capacityNotificationObserver).capacityIsAvailable();
    }

    @Test
    public void execute_submits_JobThrowException() {

        final Event event = mock(Event.class);
        final Job<Event> job = new Job<Event>(event, PolicyJob.Priority.MEDIUM){
            @Override
            protected void runJob() {
                throw new IllegalStateException("testing");
            }
        };

        //we are handling the exceptions thrown by job execution
        policy.execute(job);

        verify(executor).execute(any(Runnable.class));
        assertThat(threadFactory.getCreatedThread(), is(nullValue()));
        //the observer shall always be notified even when the job throws exceptions
        verify(capacityNotificationObserver).capacityIsAvailable();
    }

    @Test
    public void execute_highPriority_submits() {
        final PolicyJob<?> job = mock(PolicyJob.class);
        when(job.getPriority()).thenReturn(PolicyJob.Priority.HIGH);

        policy.execute(job);

        verify(job).run();
        assertThat(threadFactory.getCreatedThread(), is(nullValue()));
        verify(capacityNotificationObserver).capacityIsAvailable();
    }

    @Test
    public void execute_highPriority_executorRejects_runsInFallbackThread() throws InterruptedException {
        final Semaphore semaphore = new Semaphore(0);

        final PolicyJob<?> job = mock(PolicyJob.class);
        when(job.getPriority()).thenReturn(PolicyJob.Priority.HIGH);

        doThrow(new RejectedExecutionException()).when(executor).execute(any(Runnable.class));
        doAnswer(invocation -> {
            semaphore.release();
            return null;
        }).when(capacityNotificationObserver).capacityIsAvailable();

        policy.execute(job);

        boolean capacityNotified = semaphore.tryAcquire(30, TimeUnit.SECONDS);
        assertThat(capacityNotified, is(true));

        verify(job).run();
        verify(capacityNotificationObserver).capacityIsAvailable();
    }

}