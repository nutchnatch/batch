package com.ossnms.dcn_manager.core.entities.channel.data;

import static org.hamcrest.CoreMatchers.both;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.either;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.core.entities.MutationDescriptorTestBase;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;

public class ChannelConnectionMutationDescriptorTest extends MutationDescriptorTestBase<ChannelConnectionData, ChannelConnectionMutationDescriptor> {

	// The following string literals must match the ones used in ChannelConnectionMutationDescriptor.toString()
	// Public constant fields were not used to prevent polluting the type's public interface
	private static final String CONNECTED_TO_STRING_KEY = "connected";
	private static final String ADDITIONAL_INFO_TO_STRING_KEY = "connected";

	private static final ActualActivationState MUTATION_ACTIVATION_STATUS = ActualActivationState.ACTIVE;

	@Before
	@Override
	public void setUp() throws Exception {
		final int ID = 1, VERSION = 1;
		domainObject = new ChannelConnectionBuilder().build(ID, VERSION);
		emptyMutation = new ChannelConnectionMutationDescriptor(domainObject);
		mutation = new ChannelConnectionMutationDescriptor(domainObject)
			.setConnection(MUTATION_ACTIVATION_STATUS);
	}

	@Test
	public void apply_inAValidMutationDescriptor_producesTheCorrectMutation() {
		final ChannelConnectionData result = mutation.apply();
		assertThat(result.getActualActivationState(), is(sameInstance(MUTATION_ACTIVATION_STATUS)));
		assertThat(result.isActive(), is(true));
	}

	@Test
	public void toString_onANonEmptyMutation_returnsStringWithMutationInfo() {
		assertThat(
			mutation.toString(),
			either(containsString(CONNECTED_TO_STRING_KEY)).or(containsString(ADDITIONAL_INFO_TO_STRING_KEY))
		);
	}

	@Test
	public void toString_onAnEmptyMutation_returnsStringWithoutThatMutationInfo() {
		assertThat(
			emptyMutation.toString(),
			both(not(containsString(CONNECTED_TO_STRING_KEY))).and(not(containsString(ADDITIONAL_INFO_TO_STRING_KEY)))
		);
	}
}
