package com.ossnms.dcn_manager.core.properties.ne;

import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class NeDirectRoutePropertiesTest extends PropertiesTestBase {

    private NeType type;

    @Before
    public void setUp() {
        type = MockFactory.mockNeType();
    }

    @Test
    public void testKeyRefreshing_fromNeProperties() throws InvalidMutationException {

        final String ip_address = "ip_address";

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Property."+WellKnownNePropertyNames.ID_NAME+"}"));

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(1, type);
        descriptor.getPreferences().setName("name");

        final NeDirectRouteProperties routeProperties = new NeDirectRouteProperties();

        routeProperties.set(type, descriptor, descriptor.getPreferences(), ip_address, "1.2.3.4");
        assertThat(descriptor.getPreferences().getDirectRouteAdapter().getKey(), hasValue("1.2.3.4:name"));

        descriptor.getPreferences().setName("newName");
        routeProperties.refreshRouteKey(type, descriptor, descriptor.getPreferences());
        assertThat(descriptor.getPreferences().getDirectRouteAdapter().getKey(), hasValue("1.2.3.4:newName"));
    }

    @Test
    public void testKeyBuilding_fromNeProperties() throws InvalidMutationException {

        final String ip_address = "ip_address";
        final String name = "name";

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Property."+WellKnownNePropertyNames.ID_NAME+"}"));

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(1, type);
        descriptor.getPreferences().setName(name);

        final NeDirectRouteProperties routeProperties = new NeDirectRouteProperties();

        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(
                new NeUserPreferencesBuilder().setName(name).build(1, 1));
        routeProperties.set(type, descriptor, mutation, ip_address, "1.2.3.4");

        final NeUserPreferencesData finalPreferences = mutation.apply();
        assertThat(finalPreferences.getDirectRoute().getKey(), is("1.2.3.4:name"));
    }

    @Test
    public void testKeyBuilding_withPartialUpdates() throws InvalidMutationException {

        final String port = "port";
        final String ip_address = "ip_address";

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(1, type);
        descriptor.getPreferences().setName("name");

        final NeDirectRouteProperties routeProperties = new NeDirectRouteProperties();

        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(
                new NeUserPreferencesBuilder().setName("name").build(1, 1));
        routeProperties.set(type, descriptor, mutation, port, "123");

        final NeEntity newEntity = new NeEntity(
                new NeConnectionBuilder().build(NEID, VERSION),
                new NeOperationBuilder().build(NEID, VERSION),
                new NeInfoBuilder().setProxyType("type").build(NEID, 1, VERSION),
                new NeSynchronizationData.NeSynchronizationBuilder().build(NEID, VERSION),
                mutation.apply());
        assertThat(newEntity.getPreferences().getDirectRoute().getKey(), is(nullValue()));

        final NeUserPreferencesMutationDescriptor mutation2 = new NeUserPreferencesMutationDescriptor(
                newEntity.getPreferences());
        routeProperties.set(type, newEntity, mutation2, ip_address, "1.2.3.4");

        final NeUserPreferencesData finalPreferences = mutation2.apply();
        assertThat(finalPreferences.getDirectRoute().getKey(), is("1.2.3.4:123"));
    }

    @Test
    public void testKeyBuilding_presentButEmptyValues_areIgnored() throws InvalidMutationException {

        final String ip_address = "ip_address";

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}"));

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(1, type);
        descriptor.getPreferences().setName("name");

        final NeDirectRouteProperties routeProperties = new NeDirectRouteProperties();

        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(
                new NeUserPreferencesBuilder().setName("name").build(1, 1));
        routeProperties.set(type, descriptor, mutation, ip_address, "");

        final NeUserPreferencesData finalPreferences = mutation.apply();
        assertThat(finalPreferences.getDirectRoute().getKey(), is(nullValue()));
    }

    @Test
    public void testKeyBuilding_presentValues_areUsed() throws InvalidMutationException {

        final String ip_address = "ip_address";

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}"));

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(1, type);
        descriptor.getPreferences().setName("name");

        final NeDirectRouteProperties routeProperties = new NeDirectRouteProperties();

        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(
                new NeUserPreferencesBuilder().setName("name").build(1, 1));
        routeProperties.set(type, descriptor, mutation, ip_address, "1.2.3.4");

        final NeUserPreferencesData finalPreferences = mutation.apply();
        assertThat(finalPreferences.getDirectRoute().getKey(), is("1.2.3.4"));
    }

    @Test
    public void testDirectRouteAttributes_areIgnored() throws InvalidMutationException {

        final String port = "port";
        final String ip_address = "ip_address";

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(1, type);
        descriptor.getPreferences().setName("name");
        final NeEntity entity = NeEntity.build(1, VERSION, descriptor);

        final NeDirectRouteProperties routeProperties = new NeDirectRouteProperties();

        assertThat(entity.getPreferences().getAllOpaqueProperties().isEmpty(), is(true));
        assertThat(routeProperties.get(type, entity, ip_address), is(absent()));
        assertThat(routeProperties.get(type, entity, port), is(absent()));

        final Map<String, String> properties = routeProperties.toProperties(entity);
        assertThat(properties.containsKey(ip_address), is(false));
        assertThat(properties.containsKey(port), is(false));

        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(
                new NeUserPreferencesBuilder().setName("name").build(1, 1));
        routeProperties.set(type, entity, mutation, ip_address, "1.1.1.1");
        routeProperties.set(type, entity, mutation, port, "111");

        final NeEntity newEntity = new NeEntity(
                new NeConnectionBuilder().build(NEID, VERSION),
                new NeOperationBuilder().build(NEID, VERSION),
                new NeInfoBuilder().setProxyType("type").build(NEID, 1, VERSION),
                new NeSynchronizationData.NeSynchronizationBuilder().build(NEID, VERSION),
                mutation.apply());

        assertThat(newEntity.getPreferences().getAllOpaqueProperties().isEmpty(), is(true));
        assertThat(newEntity.getPreferences().getDirectRoute().getOpaqueProperty(ip_address).get(), is("1.1.1.1"));
        assertThat(newEntity.getPreferences().getDirectRoute().getOpaqueProperty(port).get(), is("111"));
        assertThat(newEntity.getPreferences().getDirectRoute().getKey(), is("1.1.1.1:111"));

        assertThat(routeProperties.get(type, newEntity, ip_address).get(), is("1.1.1.1"));
        assertThat(routeProperties.get(type, newEntity, port).get(), is("111"));

        final Map<String, String> newProperties = routeProperties.toProperties(newEntity);
        assertThat(newProperties.get(ip_address), is("1.1.1.1"));
        assertThat(newProperties.get(port), is("111"));
    }

}
