package com.ossnms.dcn_manager.core.configuration.model;

import com.ossnms.dcn_manager.core.configuration.loaders.XmlConfiguration;
import com.ossnms.dcn_manager.core.jaxb.emtype.Config;
import com.ossnms.dcn_manager.core.jaxb.emtype.SupportedNeType;
import com.ossnms.dcn_manager.core.jaxb.emtype.SupportedNeTypes;
import com.ossnms.dcn_manager.core.jaxb.type.DefaultIcon;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import com.ossnms.dcn_manager.core.jaxb.type.TypeProperties;
import org.junit.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.emptyCollectionOf;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class TypeLoaderChannelTest {

    private static final URL EM_TYPE_URL = TypeLoaderChannelTest.class.getClassLoader().getResource("emtype/EmTypeLoadTest.xml");

    @Test
    public void testLoading() {
        final Config config = XmlConfiguration.unmarshal(Config.class, EM_TYPE_URL, null);
        assertNotNull(config);

        assertThat(config.getName(), is("UNO"));

        final SupportedNeTypes supportedNeTypes = config.getSupportedNeTypes();
        assertNotNull(supportedNeTypes);

        final List<SupportedNeType> supportedNeTypeList = supportedNeTypes.getSupportedNeType();
        assertThat(supportedNeTypeList, not(is(emptyCollectionOf(SupportedNeType.class))));
        final SupportedNeType supportedNeType = supportedNeTypeList.get(0);
        assertNotNull(supportedNeType);
        assertThat(supportedNeType.getFamily(), is("UNO"));
        assertThat(supportedNeType.getName(), is("UNO 1.0"));
        assertThat(supportedNeType.getProfile(), is("Win.WM;Sol.WM"));

        final DefaultIcon defaultIcon = config.getDefaultIcon();
        assertNotNull(defaultIcon);
        assertNotNull(defaultIcon.getName());

        final PropertyPageFiles propertyPageFiles = config.getPropertyPageFiles();
        assertNotNull(propertyPageFiles);
        assertNotNull(propertyPageFiles.getPropertyPageFile());

        final TypeProperties typeProperties = config.getTypeProperties();
        assertNotNull(typeProperties);
        assertNotNull(typeProperties.getElement());
    }

    @Test
    public void testBadURL() throws MalformedURLException {
        final Config config = XmlConfiguration.unmarshal(Config.class, new URL("file:///xpto"), null);
        assertThat(config, is(nullValue()));
    }
}
