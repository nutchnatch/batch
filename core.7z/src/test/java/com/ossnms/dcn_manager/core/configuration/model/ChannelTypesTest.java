package com.ossnms.dcn_manager.core.configuration.model;

import com.ossnms.dcn_manager.core.configuration.loaders.TypeLoaderChannel;
import org.junit.Before;
import org.junit.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

public class ChannelTypesTest {

    private Types<NeType> neTypes;
    private DefaultPropertyValues defaultValues;

    @Before
    public void setUp() {
        neTypes = mock(Types.class);
        defaultValues = mock(DefaultPropertyValues.class);
    }

    @Test
    public void testLoading() {
        final ClassLoader classLoader = getClass().getClassLoader();
        final Types<ChannelType> types = new TypeLoaderChannel(neTypes, defaultValues).load(
                Collections.singleton(classLoader.getResource("emtype/EmTypeLoadTest.xml")));

        assertFalse(types.isEmpty());
        assertTrue(types.containsKey("UNO"));
        assertThat(types.get("UNO").getName(), is("UNO"));
    }

    @Test
    public void testLoadingBadURL() throws MalformedURLException {
        final Types<ChannelType> types = new TypeLoaderChannel(neTypes, defaultValues).load(
                Collections.singleton(new URL("file:///xpto")));
        assertTrue(types.isEmpty());
    }

}
