package com.ossnms.dcn_manager.core.configuration.model;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.core.configuration.loaders.ModelLoader;
import com.ossnms.dcn_manager.core.jaxb.defaultproperties.Defaults;
import org.junit.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import static org.hamcrest.CoreMatchers.isA;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class ImmutableModelMapTest {

    private static final Iterable<URL> FILES =
            ImmutableList.of(
                    ImmutableModelMapTest.class.getClassLoader().getResource("defaultproperties/DefaultsLoadTest.xml"));

    @Test
    public void testBadValueClass() {
        final Map<String, Object> map = new ModelLoader<>().loadValues(Object.class, FILES);
        assertTrue(map.isEmpty());
    }

    @Test
    public void testBadUrl() throws MalformedURLException {
        final Map<String, Defaults> map =
                new ModelLoader<Defaults>().loadValues(Defaults.class, ImmutableList.of(new URL("file://abc")));
        assertTrue(map.isEmpty());
    }

    @Test
    public void testBadSchemaUrl() throws MalformedURLException {
        final Map<String, Defaults> map =
                new ModelLoader<Defaults>().loadValues(Defaults.class, FILES, new URL("file://abc"));
        assertTrue(map.isEmpty());
    }

    @Test
    public void testBadValueClassWithoutSchema() {
        final Map<String, Object> map = new ModelLoader<>().loadValues(Object.class, FILES);
        assertTrue(map.isEmpty());
    }

    @Test
    public void testBadUrlWithoutSchema() throws MalformedURLException {
        final Map<String, Defaults> map =
                new ModelLoader<Defaults>().loadValues(Defaults.class, ImmutableList.of(new URL("file://abc")));
        assertTrue(map.isEmpty());
    }

    @Test
    public void testLoading() throws MalformedURLException {
        final Map<String, Defaults> map = new ModelLoader<Defaults>().loadValues(Defaults.class, FILES);
        assertFalse(map.isEmpty());
        assertTrue(map.containsKey("DefaultsLoadTest"));
        assertThat(map.get("DefaultsLoadTest"), isA(Defaults.class));
    }

    @Test
    public void testLoadingWithoutSchema() throws MalformedURLException {
        final Map<String, Defaults> map = new ModelLoader<Defaults>().loadValues(Defaults.class, FILES);
        assertFalse(map.isEmpty());
        assertTrue(map.containsKey("DefaultsLoadTest"));
        assertThat(map.get("DefaultsLoadTest"), isA(Defaults.class));
    }

}
