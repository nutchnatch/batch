package com.ossnms.dcn_manager.core.entities.ne.behavior;

import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class NeInfoBehaviorTest {

    private NetworkElementNotifications notifications;

    @Before
    public void setUp() {
        notifications = mock(NetworkElementNotifications.class);
    }

    @Test
    public void activate_onDeactivated_withActiveChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.INACTIVE), notifications)
                .activationRequired();

        assertThat(mutation, is(present()));
        assertThat(mutation.get().getRequiredActivationState(), is(present()));
        assertThat(mutation.get().getRequiredActivationState().get(), is(RequiredActivationState.ACTIVE));

        mutation.get().apply();
        mutation.get().applied();
        verify(notifications).notifyChanges(isA(RequiredNeStateEvent.Activate.class));
    }

    @Test
    public void activate_onActivated_withActiveChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.ACTIVE), notifications)
                .activationRequired();

        assertThat(mutation, not(is(present())));
    }

    @Test
    public void activate_onDeactivated_withInactiveChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.INACTIVE), notifications)
                .activationRequired();

        assertThat(mutation, is(present()));
        assertThat(mutation.get().getRequiredActivationState(), is(present()));
        assertThat(mutation.get().getRequiredActivationState().get(), is(RequiredActivationState.ACTIVE));

        mutation.get().apply();
        mutation.get().applied();
        verify(notifications).notifyChanges(isA(RequiredNeStateEvent.Activate.class));
    }

    @Test
    public void activate_onActivated_withInactiveChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.ACTIVE), notifications)
                .activationRequired();
        assertThat(mutation, not(is(present())));
    }

    @Test
    public void activate_onDeactivated_withFailedChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.INACTIVE), notifications)
                .activationRequired();

        assertThat(mutation, is(present()));
        assertThat(mutation.get().getRequiredActivationState(), is(present()));
        assertThat(mutation.get().getRequiredActivationState().get(), is(RequiredActivationState.ACTIVE));

        mutation.get().apply();
        mutation.get().applied();
        verify(notifications).notifyChanges(isA(RequiredNeStateEvent.Activate.class));
    }

    @Test
    public void activate_onActivated_withFailedChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.ACTIVE), notifications)
                .activationRequired();
        assertThat(mutation, not(is(present())));
    }

    @Test
    public void deactivate_onActivated_withActiveChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.ACTIVE), notifications)
                .deactivationRequired();

        assertThat(mutation, is(present()));
        assertThat(mutation.get().getRequiredActivationState(), is(present()));
        assertThat(mutation.get().getRequiredActivationState().get(), is(RequiredActivationState.INACTIVE));

        mutation.get().apply();
        mutation.get().applied();
        verify(notifications).notifyChanges(isA(RequiredNeStateEvent.Deactivate.class));
    }

    @Test
    public void deactivate_onActivated_withInactiveChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.ACTIVE), notifications)
                .deactivationRequired();

        assertThat(mutation, is(present()));
        assertThat(mutation.get().getRequiredActivationState(), is(present()));
        assertThat(mutation.get().getRequiredActivationState().get(), is(RequiredActivationState.INACTIVE));

        mutation.get().apply();
        mutation.get().applied();
        verify(notifications).notifyChanges(isA(RequiredNeStateEvent.Deactivate.class));
    }

    @Test
    public void deactivate_onActivated_withFailedChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.ACTIVE), notifications)
                .deactivationRequired();

        assertThat(mutation, is(present()));
        assertThat(mutation.get().getRequiredActivationState(), is(present()));
        assertThat(mutation.get().getRequiredActivationState().get(), is(RequiredActivationState.INACTIVE));

        mutation.get().apply();
        mutation.get().applied();
        verify(notifications).notifyChanges(isA(RequiredNeStateEvent.Deactivate.class));
    }

    @Test
    public void deactivate_onDeactivated_withActiveChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.INACTIVE), notifications)
                .deactivationRequired();

        assertThat(mutation, not(is(present())));
    }

    @Test
    public void deactivate_onDeactivated_withInactiveChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.INACTIVE), notifications)
                .deactivationRequired();

        assertThat(mutation, not(is(present())));
    }

    @Test
    public void deactivate_onDeactivated_withFailedChannel() {
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(createData(RequiredActivationState.INACTIVE), notifications)
                .deactivationRequired();

        assertThat(mutation, not(is(present())));
    }

    private NeInfoData createData(RequiredActivationState requiredState) {
        return new NeInfoData.NeInfoBuilder()
            .setProxyType("type-name")
            .setRequiredActivationState(requiredState)
            .build(1, 1, 1);
    }

}
