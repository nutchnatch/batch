package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.ne.IdentifiedNeEvent;
import com.ossnms.dcn_manager.core.policies.common.Job;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;
import com.ossnms.dcn_manager.core.test.RunRunnableAnswer;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ThreadFactory;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

public class NetworkElementInteractionManagerSystemStageTest {

    private ObservableExecutor executionPolicy;
    private ThreadFactory threadFactory;

    private class TestJob extends Job<IdentifiedNeEvent> {

        private TestJob(boolean active) {
            super(new IdentifiedNeEvent(1, 1, 1, 1, active) { });
        }

        @Override
        public void runJob() {

        }

    }

    @Before
    public void setUp() {
        executionPolicy = mock(ObservableExecutor.class);
        threadFactory = mock(ThreadFactory.class);

        doAnswer(new RunRunnableAnswer())
            .when(executionPolicy).execute(any(Runnable.class));
    }

    @Test
    public void scheduleJob_belowLimit_executes() throws Exception {

        final NetworkElementInteractionManagerSystemStage stage =
                new NetworkElementInteractionManagerSystemStage(1, executionPolicy, threadFactory, p -> Optional.empty());

        stage.execute(new TestJob(true));   // one job to the 'active' partition
        stage.execute(new TestJob(false));  // one job to the 'standby' partition

        assertThat(stage.getOngoingJobCount(), is(2)); // because it is below the limit and the limit is the same for both partitions, they must have executed already.
        assertJobsStream(stage.getOngoingJobs(), 2);
        assertThat(stage.getOngoingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(1));
        assertJobsStream(stage.getOngoingJobs(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), 1);
        assertThat(stage.getOngoingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(1));
        assertJobsStream(stage.getOngoingJobs(NetworkElementInteractionManagerSystemStage.STANDBY_ID), 1);
        assertThat(stage.getPendingJobCount(), is(0));
        assertJobsStream(stage.getPendingJobs(), 0);
    }

    @Test
    public void scheduleJob_onLimit_queues() throws Exception {

        final NetworkElementInteractionManagerSystemStage stage =
                new NetworkElementInteractionManagerSystemStage(1, executionPolicy, threadFactory, p -> Optional.empty());

        stage.execute(new TestJob(true));
        stage.execute(new TestJob(true));
        stage.execute(new TestJob(true));

        stage.execute(new TestJob(false));
        stage.execute(new TestJob(false));
        stage.execute(new TestJob(false));

        assertThat(stage.getOngoingJobCount(), is(2)); // the first is running because it was below the limit.
        assertJobsStream(stage.getOngoingJobs(), 2);
        assertThat(stage.getOngoingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(1));
        assertJobsStream(stage.getOngoingJobs(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), 1);
        assertThat(stage.getOngoingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(1));
        assertJobsStream(stage.getOngoingJobs(NetworkElementInteractionManagerSystemStage.STANDBY_ID), 1);

        assertThat(stage.getPendingJobCount(), is(4)); // others were queued.
        assertJobsStream(stage.getPendingJobs(), 4);
        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(2));
        assertJobsStream(stage.getPendingJobs(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), 2);
        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(2));
        assertJobsStream(stage.getPendingJobs(NetworkElementInteractionManagerSystemStage.STANDBY_ID), 2);
    }

    @Test
    public void finishJob_terminatesAndRunsQueued() throws Exception {

        final NetworkElementInteractionManagerSystemStage stage =
                new NetworkElementInteractionManagerSystemStage(1, executionPolicy, threadFactory, p -> Optional.empty());

        stage.execute(new TestJob(true));
        stage.execute(new TestJob(true));
        stage.execute(new TestJob(true));

        stage.execute(new TestJob(false));
        stage.execute(new TestJob(false));
        stage.execute(new TestJob(false));

        assertThat(stage.getOngoingJobCount(), is(2)); // the first is running because it was below the limit.
        assertJobsStream(stage.getOngoingJobs(), 2);
        assertThat(stage.getPendingJobCount(), is(4)); // others were queued.
        assertJobsStream(stage.getPendingJobs(), 4);

        stage.onNeInteractionEnded(job -> job.getOriginatingEvent().isActiveInstance()); // complete an 'active' job

        assertThat(stage.getOngoingJobCount(), is(2)); // the first ended and one was executed.
        assertJobsStream(stage.getOngoingJobs(), 2);
        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(1));
        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(1));
        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(2));
        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(2));

        stage.onNeInteractionEnded(job -> ! job.getOriginatingEvent().isActiveInstance()); // complete a 'standby' job

        assertThat(stage.getOngoingJobCount(), is(2)); // the first ended and one was executed.
        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(1));
        assertJobsStream(stage.getPendingJobs(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), 1);
        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(1));
        assertJobsStream(stage.getPendingJobs(NetworkElementInteractionManagerSystemStage.STANDBY_ID), 1);
    }

    @Test
    public void cancelJob_cancelsQueued() throws Exception {

        final NetworkElementInteractionManagerSystemStage stage =
                new NetworkElementInteractionManagerSystemStage(1, executionPolicy, threadFactory, p -> Optional.empty());

        stage.execute(new TestJob(true));
        stage.execute(new TestJob(true));
        stage.execute(new TestJob(true));
        stage.execute(new TestJob(false));
        stage.execute(new TestJob(false));
        stage.execute(new TestJob(false));

        assertThat(stage.getOngoingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(1)); // the first is running because it was below the limit.
        assertJobsStream(stage.getOngoingJobs(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), 1);
        assertThat(stage.getOngoingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(1));
        assertJobsStream(stage.getOngoingJobs(NetworkElementInteractionManagerSystemStage.STANDBY_ID), 1);


        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(2)); // others were queued.
        assertJobsStream(stage.getPendingJobs(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), 2);

        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(2));
        assertJobsStream(stage.getPendingJobs(NetworkElementInteractionManagerSystemStage.STANDBY_ID), 2);

        stage.unscheduleNeInteraction(job -> job.getOriginatingEvent().isActiveInstance()); // cancel all 'active' jobs

        assertThat(stage.getOngoingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(0)); // the first was completed because the predicate matched.
        assertJobsStream(stage.getOngoingJobs(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), 0);

        assertThat(stage.getOngoingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(1));
        assertJobsStream(stage.getOngoingJobs(NetworkElementInteractionManagerSystemStage.STANDBY_ID), 1);

        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(0)); // the others were cancelled because the predicate matched.
        assertJobsStream(stage.getPendingJobs(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), 0);
        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(2));
        assertJobsStream(stage.getPendingJobs(NetworkElementInteractionManagerSystemStage.STANDBY_ID), 2);

        stage.unscheduleNeInteraction(job -> ! job.getOriginatingEvent().isActiveInstance()); // cancel all 'standby' jobs

        assertThat(stage.getOngoingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(0));
        assertJobsStream(stage.getOngoingJobs(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), 0);
        assertThat(stage.getOngoingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(0)); // the first was completed because the predicate matched.
        assertJobsStream(stage.getOngoingJobs(NetworkElementInteractionManagerSystemStage.STANDBY_ID), 0);
        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), is(0));
        assertJobsStream(stage.getPendingJobs(NetworkElementInteractionManagerSystemStage.ACTIVE_ID), 0);
        assertThat(stage.getPendingJobCount(NetworkElementInteractionManagerSystemStage.STANDBY_ID), is(0)); // the others were cancelled because the predicate matched.
        assertJobsStream(stage.getPendingJobs(NetworkElementInteractionManagerSystemStage.STANDBY_ID), 0);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void pullWork_capacityAvailable_noPendingAvailable_providesWorkFromSupplier() throws Exception {

        final TestJob stageWork = spy(new TestJob(true));
        final TestJob upstreamJob = spy(new TestJob(true));

        final Function<Predicate<PolicyJob<? extends IdentifiedNeEvent>>, Optional<PolicyJob<? extends IdentifiedNeEvent>>> supplier =
                mock(Function.class);

        final NetworkElementInteractionManagerSystemStage stage =
                new NetworkElementInteractionManagerSystemStage(2, executionPolicy, threadFactory, supplier);

        when(supplier.apply(any())).thenReturn(Optional.of(upstreamJob), Optional.empty());

        stage.execute(stageWork);

        verify(supplier).apply(any());
        verify(stageWork).runJob();
        verify(upstreamJob).runJob();
    }

    @Test
    @SuppressWarnings("unchecked")
    public void pullWork_capacityAvailable_noPendingAvailable_providesWorkFromSupplier_doesNotRunForDifferentPartition() throws Exception {

        final TestJob stageWork = spy(new TestJob(true));
        final TestJob upstreamJob = spy(new TestJob(false));

        final Function<Predicate<PolicyJob<? extends IdentifiedNeEvent>>, Optional<PolicyJob<? extends IdentifiedNeEvent>>> supplier =
                predicate -> predicate.test(upstreamJob) ? Optional.of(upstreamJob) : Optional.empty();

        final NetworkElementInteractionManagerSystemStage stage =
                new NetworkElementInteractionManagerSystemStage(2, executionPolicy, threadFactory, supplier);

        stage.execute(stageWork);

        // we don't need to check if the predicate is called, this was verified on the previous test.
        verify(stageWork).runJob();
        verify(upstreamJob, never()).runJob(); // the upstream job did not match the same partition (completed 'active' but only had work for 'standby')
    }

    private void assertJobsStream(final Stream<PolicyJob<?>> jobs, final int size) {
        assertThat(jobs, notNullValue());
        final Set<PolicyJob<?>> jobsAsSet = jobs.collect(Collectors.toSet());
        assertThat(jobsAsSet.size(), Matchers.is(size));
    }

}
