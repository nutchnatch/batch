package com.ossnms.dcn_manager.core.entities.ne.data;

import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class NeSynchronizationDataTest {

    @Test
    public void testCreation() throws Exception {
        final NeSynchronizationData data = new NeSynchronizationData.NeSynchronizationBuilder()
            .setAll(Optional.of(1L))
            .setAlarms(Optional.of(2L))
            .setPacket(Optional.of(3L))
            .build(3, 5);

        assertThat(data.getId(), is(3));
        assertThat(data.getVersion(), is(5));
        assertThat(data.getAll(), hasValue(1L));
        assertThat(data.getAlarms(), hasValue(2L));
        assertThat(data.getPacket(), hasValue(3L));
    }

    @Test
    public void testModification() throws Exception {
        final NeSynchronizationData data = new NeSynchronizationData.NeSynchronizationBuilder()
                .setAll(Optional.of(16L))
                .setAlarms(Optional.of(28L))
                .setPacket(Optional.of(39L))
                .build(3, 5);

        final NeSynchronizationData newData = new NeSynchronizationMutationDescriptor(data)
                .setAll(1L)
                .setAlarms(2L)
                .setPacket(3L)
                .apply();

        assertThat(newData.getId(), is(3));
        assertThat(newData.getVersion(), is(5));
        assertThat(newData.getAll(), hasValue(1L));
        assertThat(newData.getAlarms(), hasValue(2L));
        assertThat(newData.getPacket(), hasValue(3L));
    }
}
