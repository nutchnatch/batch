package com.ossnms.dcn_manager.core.properties.mediator;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMITED;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames.DESCRIPTION;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames.ID_NAME;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames.RECONNECT_INTERVAL;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class MediatorPropertiesTest {

    private static final int RECONNECT_ATTEMPT_INTERVAL_VAL = 5;
    private static final int CONCURRENT_ACTIVATIONS_LIMIT_VAL = 4;
    private static final boolean CONCURRENT_ACTIVATIONS_LIMITED_VAL = true;
    private static final boolean ACTIVATION_REQUIRED_VAL = true;
    private static final String DESCRIPTION_VAL = "descr";
    private static final String TYPE_VAL = "type";
    private static final String NAME_VAL = "name";

    private final MediatorProperties properties = new MediatorProperties();

    private MediatorType type;

    @Before
    public void setUp() {
        type = MockFactory.mockMediatorType();
        when(type.getTypeProperties())
            .thenReturn(ImmutableMap.of("something", "else"));
    }

    @Test
    public void testGetProperties() {
        final MediatorEntity entity = createMediatorEntity();

        final Map<String, String> props = properties.getProperties(type, entity);

        assertThat(props, allOf(
                hasEntry("something", "else"),
                hasEntry(CONCURRENT_ACTIVATIONS_LIMIT, Integer.toString(CONCURRENT_ACTIVATIONS_LIMIT_VAL)),
                hasEntry(CONCURRENT_ACTIVATIONS_LIMITED, Boolean.toString(CONCURRENT_ACTIVATIONS_LIMITED_VAL)),
                hasEntry(DESCRIPTION, DESCRIPTION_VAL),
                hasEntry(ID_NAME, NAME_VAL),
                hasEntry(RECONNECT_INTERVAL, Integer.toString(RECONNECT_ATTEMPT_INTERVAL_VAL))
            ));
    }

    private MediatorEntity createMediatorEntity() {
        return new MediatorEntity(
                new MediatorInfoBuilder()
                    .setName(NAME_VAL)
                    .setTypeName(TYPE_VAL)
                    .setDescription(Optional.of(DESCRIPTION_VAL))
                    .setActivationRequired(ACTIVATION_REQUIRED_VAL)
                    .setConcurrentActivationsLimited(CONCURRENT_ACTIVATIONS_LIMITED_VAL)
                    .setConcurrentActivationsLimit(CONCURRENT_ACTIVATIONS_LIMIT_VAL)
                    .setReconnectAttemptInterval(RECONNECT_ATTEMPT_INTERVAL_VAL)
                    .build(1, 2),
                new MediatorConnectionBuilder().build(1, 2));
    }

    @Test
    public void testSetProperties() throws InvalidMutationException {
        final MediatorInfoData infoData = new MediatorInfoBuilder()
            .setName("?")
            .setTypeName("?")
            .setDescription(Optional.of(""))
            .setActivationRequired(false)
            .setConcurrentActivationsLimited(false)
            .setConcurrentActivationsLimit(0)
            .setReconnectAttemptInterval(0)
            .build(1, 2);

        final MediatorInfoMutationDescriptor mutation = new MediatorInfoMutationDescriptor(infoData);

        properties.setProperties(type, mutation, ImmutableMap.<String, String>builder()
                .put(CONCURRENT_ACTIVATIONS_LIMIT, Integer.toString(CONCURRENT_ACTIVATIONS_LIMIT_VAL))
                .put(CONCURRENT_ACTIVATIONS_LIMITED, Boolean.toString(CONCURRENT_ACTIVATIONS_LIMITED_VAL))
                .put(DESCRIPTION, DESCRIPTION_VAL)
                .put(ID_NAME, NAME_VAL)
                .put(RECONNECT_INTERVAL, Integer.toString(RECONNECT_ATTEMPT_INTERVAL_VAL))
                .put("custom", "value")
                .put(PRIMARY_HOST_NAME, "primary") // these two should be ignored because they relate to physical instances.
                .put(SECONDARY_HOST_NAME, "secondary")
                .build()
            );

        final MediatorInfoData newInfoData = mutation.apply();

        assertThat(newInfoData.getName(), is(NAME_VAL));
        assertThat(newInfoData.getDescription().get(), is(DESCRIPTION_VAL));
        assertThat(newInfoData.getConcurrentActivationsLimit(), is(CONCURRENT_ACTIVATIONS_LIMIT_VAL));
        assertThat(newInfoData.isConcurrentActivationsLimited(), is(CONCURRENT_ACTIVATIONS_LIMITED_VAL));
        assertThat(newInfoData.getReconnectAttemptInterval(), is(RECONNECT_ATTEMPT_INTERVAL_VAL));

        assertThat(newInfoData.getOpaqueProperty("custom"), hasValue("value"));
        assertThat(newInfoData.getOpaqueProperty(PRIMARY_HOST_NAME), is(absent()));
        assertThat(newInfoData.getOpaqueProperty(SECONDARY_HOST_NAME), is(absent()));

        assertThat(newInfoData.getAllOpaqueProperties(), hasEntry("custom", "value"));
    }

    @Test(expected=InvalidMutationException.class)
    public void testSetEmptyName() throws InvalidMutationException {

        properties.setProperty(type, new MediatorInfoMutationDescriptor(createMediatorEntity().getInfo()),
                MediatorProperty.ID_NAME, "");

    }

    @Test(expected=InvalidMutationException.class)
    public void testSetNullName() throws InvalidMutationException {

        properties.setProperty(type, new MediatorInfoMutationDescriptor(createMediatorEntity().getInfo()),
                MediatorProperty.ID_NAME, null);

    }

}
