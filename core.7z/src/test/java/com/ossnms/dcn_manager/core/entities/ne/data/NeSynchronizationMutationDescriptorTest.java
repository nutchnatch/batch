package com.ossnms.dcn_manager.core.entities.ne.data;

import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class NeSynchronizationMutationDescriptorTest {

    @Test
    public void testChanges_onlyDifferentAttributesAreRecorded() {
        final NeSynchronizationData original = new NeSynchronizationBuilder()
            .setAll(Optional.of(10L))
            .setAlarms(Optional.of(20L))
            .setPacket(Optional.of(30L))
            .build(1, 2);

        final NeSynchronizationMutationDescriptor descriptor =
            new NeSynchronizationMutationDescriptor(original);

        descriptor.setAll(10);
        assertThat(descriptor.getAll(), is(absent()));
        descriptor.setAll(15);
        assertThat(descriptor.getAll(), hasValue(15L));

        descriptor.setAlarms(20);
        assertThat(descriptor.getAlarms(), is(absent()));
        descriptor.setAlarms(25);
        assertThat(descriptor.getAlarms(), hasValue(25L));

        descriptor.setPacket(30);
        assertThat(descriptor.getPacket(), is(absent()));
        descriptor.setPacket(35);
        assertThat(descriptor.getPacket(), hasValue(35L));
    }

}
