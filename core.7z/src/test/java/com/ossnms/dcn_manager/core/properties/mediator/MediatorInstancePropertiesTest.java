package com.ossnms.dcn_manager.core.properties.mediator;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalDataMutationDescriptor;
import com.ossnms.dcn_manager.test.util.OtherMatchers;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.google.common.collect.Iterables.getOnlyElement;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class MediatorInstancePropertiesTest {

    private static final int LOGICAL_MEDIATOR_ID = 1;
    private static final int MEDIATOR_INSTANCE_ID = 10;
    private static final String HOSTNAME = "hostname";

    private MediatorInstanceProperties properties;

    @Before
    public void setUp() {
        properties = new MediatorInstanceProperties(
            Collections.singleton(
                new MediatorInstance(
                    new MediatorPhysicalDataBuilder().setPriority(0).setHost(HOSTNAME).build(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0),
                    new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0)
                )),
            MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1);
    }

    @Test
    public void propertyHandled() throws Exception {
        assertThat(MediatorInstanceProperties.isMediatorInstanceProperty(WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME), is(true));
        assertThat(MediatorInstanceProperties.isMediatorInstanceProperty(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME), is(true));
        assertThat(MediatorInstanceProperties.isMediatorInstanceProperty(WellKnownMediatorPropertyNames.ID_NAME), is(false));
        assertThat(MediatorInstanceProperties.isMediatorInstanceProperty(null), is(false));
    }

    @Test
    public void toProperties() throws Exception {
        final Map<String, String> properties = MediatorInstanceProperties.getProperties(
                ImmutableList.of(
                        new MediatorInstance(
                            new MediatorPhysicalDataBuilder().setPriority(0).setHost(HOSTNAME).build(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0),
                            new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0)
                        ),
                        new MediatorInstance(
                            new MediatorPhysicalDataBuilder().setPriority(1).setHost("backup").build(MEDIATOR_INSTANCE_ID + 1, LOGICAL_MEDIATOR_ID, 0),
                            new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID + 1, LOGICAL_MEDIATOR_ID, 0)
                        )));

        assertThat(properties.size(), is(2));
        assertThat(properties, allOf(
                hasEntry(WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME, HOSTNAME),
                hasEntry(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "backup")
            ));
    }

    @Test
    public void toProperties_primaryOnly() throws Exception {
        final Map<String, String> properties = MediatorInstanceProperties.getProperties(
                ImmutableList.of(
                        new MediatorInstance(
                            new MediatorPhysicalDataBuilder().setPriority(0).setHost(HOSTNAME).build(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0),
                            new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0)
                        )));

        assertThat(properties.size(), is(1));
        assertThat(properties, hasEntry(WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME, HOSTNAME));
    }

    @Test
    public void toProperties_secondaryOnly() throws Exception {
        final Map<String, String> properties = MediatorInstanceProperties.getProperties(
                ImmutableList.of(
                        new MediatorInstance(
                            new MediatorPhysicalDataBuilder().setPriority(1).setHost(HOSTNAME).build(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0),
                            new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0)
                        )));

        assertThat(properties.size(), is(1));
        assertThat(properties, hasEntry(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, HOSTNAME));
    }

    @Test(expected=IllegalStateException.class)
    public void toProperties_duplicatePriorities_throws() throws Exception {
        MediatorInstanceProperties.getProperties(
                ImmutableList.of(
                        new MediatorInstance(
                            new MediatorPhysicalDataBuilder().setPriority(0).setHost(HOSTNAME).build(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0),
                            new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0)
                        ),
                        new MediatorInstance(
                            new MediatorPhysicalDataBuilder().setPriority(0).setHost("backup").build(MEDIATOR_INSTANCE_ID + 1, LOGICAL_MEDIATOR_ID, 0),
                            new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID + 1, LOGICAL_MEDIATOR_ID, 0)
                        )));
    }

    @Test
    public void changeExistingInstance() throws Exception {

        properties.setProperty(WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME, "new host");

        assertThat(properties.getDataCreations(), is(emptyIterable()));
        assertThat(properties.getDataRemovals(), is(emptyIterable()));

        final List<MediatorPhysicalDataMutationDescriptor> mutations = properties.getDataMutations();
        assertThat(mutations, is(Matchers.<MediatorPhysicalDataMutationDescriptor>iterableWithSize(1)));
        final MediatorPhysicalDataMutationDescriptor descriptor = getOnlyElement(mutations);

        assertThat(descriptor.getHost(), OtherMatchers.hasValue("new host"));
    }

    @Test
    public void changeExistingInstance_multipleTimes_lastOneWins() throws Exception {

        properties.setProperty(WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME, "new host 1");
        properties.setProperty(WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME, "new host 2");
        properties.setProperty(WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME, "new host 3");

        assertThat(properties.getDataCreations(), is(emptyIterable()));
        assertThat(properties.getDataRemovals(), is(emptyIterable()));

        final List<MediatorPhysicalDataMutationDescriptor> mutations = properties.getDataMutations();
        assertThat(mutations, is(Matchers.<MediatorPhysicalDataMutationDescriptor>iterableWithSize(1)));
        final MediatorPhysicalDataMutationDescriptor descriptor = getOnlyElement(mutations);

        assertThat(descriptor.getHost(), OtherMatchers.hasValue("new host 3"));
    }

    @Test
    public void createNewInstance() throws Exception {

        properties.setProperty(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "new host");

        assertThat(properties.getDataMutations(), is(emptyIterable()));
        assertThat(properties.getDataRemovals(), is(emptyIterable()));

        final List<MediatorInstanceCreateDescriptor> creations = properties.getDataCreations();
        assertThat(creations, is(Matchers.<MediatorInstanceCreateDescriptor>iterableWithSize(1)));
        final MediatorInstanceCreateDescriptor creation = getOnlyElement(creations);

        final MediatorPhysicalData newPhysicalData =
                new MediatorPhysicalData(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0, creation.getInitialData());
        final MediatorPhysicalConnectionData newConnectionData =
                new MediatorPhysicalConnectionData(MEDIATOR_INSTANCE_ID, LOGICAL_MEDIATOR_ID, 0, creation.getConnectionInitialData());

        assertThat(newPhysicalData.getHost(), is("new host"));
        assertThat(newPhysicalData.getPriority(), is(MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1));
        assertThat(newConnectionData.isActive(), is(true));

    }

    @Test
    public void createNewInstance_multipleTimes_lastOneWins() throws Exception {

        properties.setProperty(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "new host 1");
        properties.setProperty(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "new host 2");
        properties.setProperty(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, "new host 3");

        assertThat(properties.getDataMutations(), is(emptyIterable()));
        assertThat(properties.getDataRemovals(), is(emptyIterable()));

        final List<MediatorInstanceCreateDescriptor> creations = properties.getDataCreations();
        assertThat(creations, is(Matchers.<MediatorInstanceCreateDescriptor>iterableWithSize(1)));
        final MediatorInstanceCreateDescriptor creation = getOnlyElement(creations);

        assertThat(creation.getInitialData().getHost(), is("new host 3"));
        assertThat(creation.getInitialData().getPriority(), is(MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1));
    }

    @Test
    public void deleteExistingInstance() throws Exception {

        properties.setProperty(WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME, null);

        assertThat(properties.getDataCreations(), is(emptyIterable()));
        assertThat(properties.getDataMutations(), is(emptyIterable()));

        assertThat(properties.getDataRemovals(), contains(MEDIATOR_INSTANCE_ID));
    }

    @Test
    public void deleteMissingInstance() throws Exception {

        properties.setProperty(WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME, null);

        assertThat(properties.getDataCreations(), is(emptyIterable()));
        assertThat(properties.getDataMutations(), is(emptyIterable()));
        assertThat(properties.getDataRemovals(), is(emptyIterable()));
    }

    @Test
    public void setUnknownProperty_isIgnored() throws Exception {

        properties.setProperty("blah", "bleh");

        assertThat(properties.getDataCreations(), is(emptyIterable()));
        assertThat(properties.getDataMutations(), is(emptyIterable()));
        assertThat(properties.getDataRemovals(), is(emptyIterable()));
    }

    @Test(expected=IllegalArgumentException.class)
    public void setEmptyPropertyName_throws() throws Exception {

        properties.setProperty("", "");

    }
}
