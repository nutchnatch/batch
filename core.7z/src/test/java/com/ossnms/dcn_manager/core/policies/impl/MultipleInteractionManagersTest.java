/*
* Copyright (C) Coriant
* The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
* Offenders will be liable for damages.
* All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
* Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
*
*/

package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelConnectionManager;
import com.ossnms.dcn_manager.core.outbound.MediatorConnectionManager;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutorImpl;
import com.ossnms.dcn_manager.core.test.RunRunnableAnswer;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class MultipleInteractionManagersTest {

    private ChannelConnectionManager channelConnectionManager;
    private ChannelInteractionManagerImpl channelManager;

    private MediatorConnectionManager mediatorConnectionManager;
    private MediatorInteractionManagerImpl mediatorManager;

    private Executor executor;

    private ObservableExecutor observableExecutor;

    @Before
    public void setUp() {
        channelConnectionManager = mock(ChannelConnectionManager.class);

        executor = mock(Executor.class);

        doAnswer(new RunRunnableAnswer()).when(executor).execute(isA(Runnable.class));

        observableExecutor = new ObservableExecutorImpl(executor);

        channelManager = new ChannelInteractionManagerImpl(channelConnectionManager, observableExecutor);

        mediatorConnectionManager = mock(MediatorConnectionManager.class);

        mediatorManager = new MediatorInteractionManagerImpl(mediatorConnectionManager, observableExecutor);

    }

    @Test
    public void test_resubmittedMediatorManagerTaskAfterRejection(){

        //rejecting the task submit (simulating a saturated executor)
        doThrow(new RejectedExecutionException()).when(executor).execute(isA(Runnable.class));
        mediatorManager.scheduleActivation(new RequiredMediatorStateEvent.ActivateMediatorEvent(10, 1));

        assertThat(mediatorManager.getOngoingJobCount(), is(0));
        assertThat(mediatorManager.getPendingJobCount(), is(1));

        //set the usual behaviour - not saturated
        doAnswer(new RunRunnableAnswer()).when(executor).execute(isA(Runnable.class));

        //schedule in channelManager - this should force the resubmission of the previous rejected task
        channelManager.scheduleDeactivation(new RequiredChannelStateEvent.Deactivate(10, 99, Collections.singleton(1)));

        // the first task will be submitted three times -
        verify(executor, times(4)).execute(any(Runnable.class));
        assertThat(mediatorManager.getOngoingJobCount(), is(1));
        assertThat(mediatorManager.getPendingJobCount(), is(0));

        assertThat(channelManager.getOngoingJobCount(), is(1));
        assertThat(channelManager.getPendingJobCount(), is(0));
    }

    @Test
    public void test_resubmittedChannelManagerTaskAfterRejection(){

        //rejecting the task submit (simulating a saturated executor)
        doThrow(new RejectedExecutionException()).when(executor).execute(isA(Runnable.class));
        channelManager.scheduleDeactivation(new RequiredChannelStateEvent.Deactivate(10, 99, Collections.singleton(1)));

        //the submission was rejected
        assertThat(channelManager.getOngoingJobCount(), is(0));
        assertThat(channelManager.getPendingJobCount(), is(1));

        //restore the usual behaviour - not saturated
        doAnswer(new RunRunnableAnswer()).when(executor).execute(isA(Runnable.class));

        //schedule in channelManager - this should force the resubmission of the previous rejected task
        mediatorManager.scheduleActivation(new RequiredMediatorStateEvent.ActivateMediatorEvent(10, 1));

        // the first task(Deactivate event) will be submitted three times  + 1 one for the submission of ActivateMediatorEvent
        verify(executor, times(4)).execute(any(Runnable.class));
        assertThat(mediatorManager.getOngoingJobCount(), is(1));
        assertThat(mediatorManager.getPendingJobCount(), is(0));

        assertThat(channelManager.getOngoingJobCount(), is(1));
        assertThat(channelManager.getPendingJobCount(), is(0));
    }
}
