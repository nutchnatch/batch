package com.ossnms.dcn_manager.exceptions;

import org.slf4j.helpers.MessageFormatter;

/**
 * Abstract base class for all exceptions thrown within EM/NE when errors occur.
 * @see Exception
 */
public abstract class DcnManagerException extends Exception {

    private static final long serialVersionUID = -1249478941120743112L;

    /** @see Exception#Exception() */
    public DcnManagerException() {

    }

    /** @see Exception#Exception(String) */
    public DcnManagerException(String message) {
        super(message);
    }

    /** @see Exception#Exception(Throwable) */
    public DcnManagerException(Throwable cause) {
        super(cause);
    }

    /** @see Exception#Exception(String,Throwable) */
    public DcnManagerException(String message, Throwable cause) {
        super(message, cause);
    }

    /** @see Exception#Exception(String,Throwable,boolean,boolean) */
    public DcnManagerException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * Constructs a new exception with a detail message built from the given format
     * string and parameters.
     * @param format A format string.
     * @param formatParameters Parameters referenced by format specifiers in the format string.
     *
     * @see DcnManagerException#DcnManagerException(String)
     * @see MessageFormatter#arrayFormat(String, Object[])
     */
    public DcnManagerException(String format, Object... formatParameters) {
        this(buildMessage(format, formatParameters));
    }

    /**
     * Constructs a new exception with a cause and a detail message built from the given format
     * string and parameters.
     * @param format A format string.
     * @param cause The cause.
     * @param formatParameters Parameters referenced by format specifiers in the format string.
     *
     * @see DcnManagerException#DcnManagerException(String,Throwable)
     * @see MessageFormatter#arrayFormat(String, Object[])
     */
    public DcnManagerException(String format, Throwable cause, Object... formatParameters) {
        this(buildMessage(format, formatParameters), cause);
    }

    private static String buildMessage(String format, Object... formatParameters) {
        return MessageFormatter.arrayFormat(format, formatParameters).getMessage();
    }
}
