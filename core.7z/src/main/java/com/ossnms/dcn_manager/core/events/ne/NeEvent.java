package com.ossnms.dcn_manager.core.events.ne;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import com.ossnms.dcn_manager.core.events.EntityEvent;

/**
 * Base class for all events related to the NE domain entity.
 *
 * Additional design constraints pertaining to all derived event types. Note that these are 
 * cumulative to the design constraints specified by the base class {@link EntityEvent}.
 */
@Immutable
public abstract class NeEvent extends EntityEvent {

    /**
     * Creates a new object.
     * @param neId The affected NE ID.
     */
    public NeEvent(int neId) {
        super(neId);
    }

    /**
     * Creates a new object.
     * @param neId The affected NE ID.
     * @param detailedDescription Detailed event description for human consumption.
     */
    public NeEvent(int neId, @Nonnull String detailedDescription) {
        super(neId, detailedDescription);
    }

    /**
     * @return The affected NE ID.
     */
    public int getNeId() {
        return getEntityId();
    }
}
