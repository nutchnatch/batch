package com.ossnms.dcn_manager.core.events.mediator;

import java.util.Objects;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>Used to signal physical mediator server instance activation state changes. Derived class instances
 * represent specific mediator activation events. This class follows closely the implementation of
 * {@link ActualMediatorStateEvent} because the logical state mirrors the physical state (or a combination
 * thereof, depending on the strategy).</p>
 *
 * @see ActualMediatorStateEvent
 */
@Immutable
public abstract class PhysicalMediatorStateEvent extends MediatorEvent {

    private final int logicalMediatorId;
    private final boolean instanceActive;

    /**
     * Initiates an instance with the given arguments.
     * @param mediatorInstanceId The affected physical mediator server instance identifier.
     * @param logicalMediatorId The affected logical mediator identifier.
     * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
     * standby instance).
     */
    protected PhysicalMediatorStateEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive) {
        super(mediatorInstanceId);
        this.logicalMediatorId = logicalMediatorId;
        this.instanceActive = instanceActive;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param mediatorInstanceId The affected physical mediator server instance identifier.
     * @param logicalMediatorId The affected logical mediator identifier.
     * @param instancePriority Priority value for the physical mediator server instance (determines whether it is the primary instance).
     * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
     * standby instance).
     * @param detailedDescription Human-readable event description.
     */
    protected PhysicalMediatorStateEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive, @Nonnull String detailedDescription) {
        super(mediatorInstanceId, detailedDescription);
        this.logicalMediatorId = logicalMediatorId;
        this.instanceActive = instanceActive;
    }

    /**
     * @return The affected logical mediator identifier.
     */
    public int getLogicalMediatorId() {
        return logicalMediatorId;
    }

    /**
     * @return Whether this refers to the physical mediator server instance that is currently active (as opposed to the
     * standby instance).
     */
    public boolean isInstanceActive() {
        return instanceActive;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getMediatorId(), getDetailedDescription(), logicalMediatorId, instanceActive);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final PhysicalMediatorStateEvent rhs = (PhysicalMediatorStateEvent) obj;
        return new EqualsBuilder()
                .append(getMediatorId(), rhs.getMediatorId())
                .append(getDetailedDescription(), rhs.getDetailedDescription())
                .append(logicalMediatorId, rhs.logicalMediatorId)
                .append(instanceActive, rhs.instanceActive)
                .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("logicalMediatorId", logicalMediatorId)
                .append("instanceActive", instanceActive)
                .toString();
    }

    
    /**
     * Class whose instances represent events used to signal that a mediation activation is going to be scheduled.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
   @Immutable
   public static final class PhysicalMediatorStartingUpEvent extends PhysicalMediatorStateEvent {

        public PhysicalMediatorStartingUpEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive);
        }

        public PhysicalMediatorStartingUpEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive,
                @Nonnull String detailedDescription) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive, detailedDescription);
        }
    }


    /**
     * Class whose instances represent events used to signal that a mediation activation has been initiated.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
   @Immutable
   public static final class PhysicalMediatorActivatingEvent extends PhysicalMediatorStateEvent {

        public PhysicalMediatorActivatingEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive);
        }

        public PhysicalMediatorActivatingEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive,
                @Nonnull String detailedDescription) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a mediation activation has succeeded.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalMediatorActivatedEvent extends PhysicalMediatorStateEvent {

        public PhysicalMediatorActivatedEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive);
        }

        public PhysicalMediatorActivatedEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive,
                @Nonnull String detailedDescription) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a mediation activation has failed.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
   public static final class PhysicalMediatorActivationFailedEvent extends PhysicalMediatorStateEvent {

        public PhysicalMediatorActivationFailedEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive);
        }

        public PhysicalMediatorActivationFailedEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive,
                @Nonnull String detailedDescription) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a mediation deactivation has been initiated.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
   public static final class PhysicalMediatorDeactivatingEvent extends PhysicalMediatorStateEvent {

        public PhysicalMediatorDeactivatingEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive);
        }

        public PhysicalMediatorDeactivatingEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive,
                @Nonnull String detailedDescription) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a mediation deactivation has completed.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalMediatorDeactivatedEvent extends PhysicalMediatorStateEvent {

        public PhysicalMediatorDeactivatedEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive);
        }

        public PhysicalMediatorDeactivatedEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive,
                @Nonnull String detailedDescription) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive, detailedDescription);
        }
    }
    
    /**
     * Class whose instances represent events used to signal that a mediation activation is going to be scheduled.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
   @Immutable
   public static final class PhysicalMediatorShuttingDownEvent extends PhysicalMediatorStateEvent {

        public PhysicalMediatorShuttingDownEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive);
        }

        public PhysicalMediatorShuttingDownEvent(int mediatorInstanceId, int logicalMediatorId, boolean instanceActive,
                @Nonnull String detailedDescription) {
            super(mediatorInstanceId, logicalMediatorId, instanceActive, detailedDescription);
        }
    }



}
