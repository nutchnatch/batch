package com.ossnms.dcn_manager.core.entities.container.system;

import com.ossnms.dcn_manager.core.entities.container.ContainerInfoBase;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Contains information about a System Container. System Containers represent a logical grouping
 * of NEs in the management system. They will be handled as a single Network Element.
 */
public final class SystemInfo extends ContainerInfoBase {

    /**
     * Creates a new object.
     *
     * @param systemId   Numeric system identifier.
     * @param version    Object version.
     * @param systemName System name. Must not be empty.
     * @throws IllegalArgumentException If the name is null or empty.
     */
    public SystemInfo(int systemId, int version, @Nonnull String systemName) {
        super(systemId, version, systemName);
    }

    /**
     * Creates a new object.
     *
     * @param systemId    Numeric system identifier.
     * @param version     Object version.
     * @param systemName  System name. Must not be empty.
     * @param description Human readable description.
     * @throws IllegalArgumentException If the name is null or empty.
     */
    public SystemInfo(int systemId, int version, @Nonnull String systemName, @Nonnull Optional<String> description,
            @Nonnull Optional<String> userText) {
        super(systemId, version, Optional.empty(), systemName, description, userText);
    }

}
