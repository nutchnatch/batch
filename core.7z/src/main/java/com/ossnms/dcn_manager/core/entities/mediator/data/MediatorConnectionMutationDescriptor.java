package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.google.common.base.Objects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * <p>Describes all changes requested to an instance of {@link MediatorConnectionData}.</p>
 * <p>Like all mutation descriptors, this class is not thread safe.</p>
 */
public class MediatorConnectionMutationDescriptor
        extends MutationDescriptor<MediatorConnectionData, MediatorConnectionMutationDescriptor> {

    private Optional<ActualActivationState> activeState = Optional.empty();
    private Optional<String> additionalInfo = Optional.empty();

    /**
     * Creates a new mutation descriptor object.
     * @param target Target instance for the mutation.
     */
   public MediatorConnectionMutationDescriptor(@Nonnull MediatorConnectionData target) {
        super(target);
    }

    @Override
    protected MediatorConnectionMutationDescriptor self() {
        return this;
    }

    @Override
    protected MediatorConnectionData doApply() {
        return activeState.isPresent() || getAdditionalInfo().isPresent()
                ? new MediatorConnectionBuilder()
                    .setActualActivationState(activeState.orElse(getTarget().getActualActivationState()))
                    .setAdditionalInfo(getAdditionalInfo().orElse(getTarget().getAdditionalInfo()))
                    .build(getTarget().getId(), getTarget().getVersion() + 1)
                : getTarget();
    }

    /**
     * @return The new current activation state of the Mediator.
     */
    public Optional<ActualActivationState> getActiveState() {
        return activeState;
    }

    /**
     * @param activeState The new current activation state of the Mediator.
     */
    public MediatorConnectionMutationDescriptor setActive(@Nonnull ActualActivationState activeState) {
        final Optional<ActualActivationState> newValue = Optional.of(activeState);
        if (!Objects.equal(this.activeState, newValue)) {
            this.activeState = newValue;
        }
        return this;
    }

    /**
     * @return New additional state description.
     */
    public Optional<String> getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * @param additionalInfo New additional state description.
     */
    public MediatorConnectionMutationDescriptor setAdditionalInfo(@Nonnull String additionalInfo) {
        final Optional<String> newValue = Optional.of(additionalInfo);
        if (!Objects.equal(this.additionalInfo, newValue)) {
            this.additionalInfo = newValue;
        }
        return this;
    }

}
