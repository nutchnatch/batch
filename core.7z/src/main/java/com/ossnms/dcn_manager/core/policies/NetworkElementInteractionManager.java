package com.ossnms.dcn_manager.core.policies;

import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;

import javax.annotation.Nonnull;

/**
 * <p>Contract to be supported by classes that implement NE interaction management policies,
 * whose instances are responsible for managing interactions between the component and mediation
 * (i.e. through Connection Manager). The goal of such policies is to regulate DCN load imposed
 * by those interactions, in particular, between the component and multiple NEs in a given
 * channel. Notice also that these interactions are pertaining to NE activation and deactivation.</p>
 * <p>
 * <p>Although it is not expected that multiple policy implementations coexist, the definition of this
 * interface enables the complete characterization of the provided service without compromising concrete
 * implementations with lifetime management issues imposed by connectors.</p>
 * <p>
 * <p>NE interaction policies, in contrast to other interaction policies, are composed of multiple interaction
 * regulation stages. This approach enables the creation of interaction policies through composition, thereby
 * providing flexibility. Regardless of this flexibility, these abstractions are tailored to be used specifically
 * in NE interaction regulation policies, and are not intended to be adopted elsewhere.</p>
 */
public interface NetworkElementInteractionManager extends Iterable<NetworkElementInteractionManagerStage> {

    /**
     * Schedules the actual activation of the NE whose activation as just been marked as required.
     *
     * @param event the event bearing the relevant information
     */
    void scheduleActivation(@Nonnull Activate event);

    /**
     * Schedules the actual deactivation of the NE whose deactivation as just been marked as required.
     *
     * @param event the event bearing the relevant information
     */
    void scheduleDeactivation(@Nonnull Deactivate event);

    /**
     * Schedules resynchronization of an NE.
     *
     * @param event the event bearing the relevant information
     */
    void scheduleSynchronization(@Nonnull NeSynchronizationEvent event);

    /**
     * Cancels all pending and ongoing resynchronizations for a NE with the given identifier.
     *
     * @param event event bearing NE and Channel identification information.
     */
    void cancelSynchronizations(@Nonnull NeSynchronizationEvent event);

    /**
     * Cancels all pending and ongoing deactivations for a NE with the given identifier.
     *
     * @param event event bearing NE and Channel identification information.
     */
    void cancelDeactivations(@Nonnull RequiredNeStateEvent event);

    /**
     * Cancels all pending and ongoing activations for a NE with the given identifier.
     *
     * @param event event bearing NE and Channel identification information.
     */
    void cancelActivations(@Nonnull RequiredNeStateEvent event);

    /**
     * Informs that the NE interaction has ended.
     *
     * @param event Instance of the event description class.
     */
    void onNeInteractionEnded(@Nonnull ActualNeStateEvent event);

    /**
     * Informs that a management connection has just been established against the NE
     * and requests a new synchronization.
     *
     * @param event Instance of the event class with all relevant information.
     */
    void onNeConnected(@Nonnull NeSynchronizationEvent event);

    /**
     * Informs that properties have been changed on an NE.
     *
     * @param ne             The target NE.
     * @param neInstance     The target physical NE connection.
     * @param newPreferences New NE preferences, as set by the original property map.
     */
    void onNePropertiesUpdated(
            @Nonnull NeEntity ne, @Nonnull NePhysicalConnectionData neInstance,
            @Nonnull NeUserPreferencesMutationDescriptor newPreferences);

}
