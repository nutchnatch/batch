package com.ossnms.dcn_manager.core.entities.channel.data;


/**
 * <p>Class that implements the channel activation state.</p>
 *
 * <p>The state is implemented as an ordinary Java enum.</p>
 */
public enum ActualActivationState {
    ACTIVE,
    INACTIVE,
    FAILED,
    CREATING,
    ACTIVATING,
    DEACTIVATING,
    STARTINGUP,
    SHUTTINGDOWN;
}
