package com.ossnms.dcn_manager.core.entities.ne.behavior;

import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * <p>Class that implements the behavior dimension of the domain object that contains the persisted
 * NE state or, in other words, the NEs' information and required activation state. This means
 * that the application must ensure that the actual NE state converges to the required one. </p>
 *
 * <p>The implementation is based on the State Machine design pattern to deal with required activation
 * state transitions. The state machine is depicted in the following figure. Notice that the
 * representation of start and end states is merely illustrative of the expected flow: NEs
 * are originally created in the deactivated state, that is, activation not required. State transitions
 * are triggered by the depicted domain object operations. </p>
 *
 * <p><figure>
 * <img src="doc-files/neConnection_required_activation_state-state.png">
 * <figcaption>State diagram of the required activation state state machine</figcaption>
 * </figure></p>
 *
 * <p> The state machine is materialized in the following class hierarchy, only relevant to the domain
 * object implementation. For this reason the hierarchy is implemented as a set of static nested
 * classes not accessible from the outside. This solution has the merit of reducing overall
 * complexity (i.e. reducing the number of top-level classes) at the expense of increasing
 * file level complexity (i.e. its size). Nevertheless, and considering the actual file size, the
 * tradeoff is positive. In the case that the current file size increases, this approach must be
 * reevaluated. </p>
 *
 * <p> <figure>
 * <img src="doc-files/neConnection_required_activation_state-class.png">
 * <figcaption>Class diagram of the required activation state hierarchy</figcaption>
 * </figure> </p>
 *
 * <ul> Design decisions:
 * <li> Each state transition is materialized in an independent method,
 * to be overridden in concrete state classes; </li>
 * <li> Invalid transitions are signaled by producing an absent {@link Optional} instance,
 * instead of throwing an exception. Note that the exact reaction to an invalid
 * transition depends on the specific use case, and therefore throwing an exception
 * would be inappropriate; </li>
 * <li> Transitions are not applied on the on the domain object instance, due to its
 * immutable nature. Instead, state transitions produce a description of the resulting
 * mutation, which will be later applied on the repository. </li>
 * </ul>
 *
 * <p> As all types that implement domain objects' behavior dimension, this class instances are
 * not thread-safe, and therefore cannot be shared by multiple threads without explicit synchronization.
 * </p>
 */
/*
 * @startuml doc-files/neConnection_required_activation_state-state.png
 * [*] --> Deactivated
 * Activated --> Deactivated : deactivationRequired
 * Deactivated --> Activated : activationRequired
 * @enduml
 */
/*
 * @startuml doc-files/neConnection_required_activation_state-class.png
 * class RequiredActivation <<abstract>> {
 *      # activationRequired() : Optional<NeInfoMutationDescriptor>
 *      # deactivationRequired() : Optional<NeInfoMutationDescriptor>
 * }
 * RequiredActivation<|-- Activate
 * RequiredActivation<|-- Deactivate
 * hide fields
 * @enduml
 */
public final class NeInfoBehavior {

    /** The data dimension of the current domain object. */
    private final NeInfoData neInfo;
    /** The out-bound notification manager. */
    private final NetworkElementNotifications notifications;

    /**
     * Creates a new object.
     * @param neInfoData Current NE required state information.
     * @param notifications An instance of the outbound notifications manager
     *  so other components may be notified of any changes.
     */
    public NeInfoBehavior(@Nonnull NeInfoData neInfoData,
            @Nonnull NetworkElementNotifications notifications) {
        neInfo = neInfoData;
        this.notifications = notifications;
    }

    /**
     * Switches the required activation state of the NE to Active, if possible.
     * @return A {@link NeInfoMutationDescriptor} if the call produced
     *  a change.
     */
    public Optional<NeInfoMutationDescriptor> activationRequired() {
        return behaviorForData().activate();
    }

    /**
     * Switches the required activation state of the NE to Inactive, if possible.
     * @return A {@link NeInfoMutationDescriptor} if the call produced
     *  a change.
     */
    public Optional<NeInfoMutationDescriptor> deactivationRequired() {
        return behaviorForData().deactivate();
    }

    private RequiredActivation behaviorForData() {
        switch (neInfo.getRequiredActivationState()) {
        case ACTIVE:
            return new Activated();
        case INACTIVE:
            return new Dectivated();
        default:
            throw new IllegalStateException("State does not have a behavior associated: " + neInfo);
        }
    }

    protected NetworkElementNotifications getNotifications() {
        return notifications;
    }

    private abstract static class RequiredActivation {

        protected Optional<NeInfoMutationDescriptor> activate() {
            return Optional.empty();
        }

        protected Optional<NeInfoMutationDescriptor> deactivate() {
            return Optional.empty();
        }
    }

    private final class Activated extends RequiredActivation {
        @Override
        protected Optional<NeInfoMutationDescriptor> deactivate() {
            return Optional.of(new NeInfoMutationDescriptor(neInfo)
                .setRequiredActivationState(RequiredActivationState.INACTIVE)
                .whenApplied(in ->
                    getNotifications().notifyChanges(
                        new Deactivate(
                            in.getResult().getId(), 0, 0, 0, false))
                ));
        }

    }

    private final class Dectivated extends RequiredActivation {
        @Override
        protected Optional<NeInfoMutationDescriptor> activate() {
            return Optional.of(new NeInfoMutationDescriptor(neInfo)
                .setRequiredActivationState(RequiredActivationState.ACTIVE)
                .whenApplied(in ->
                    getNotifications().notifyChanges(
                        new Activate(
                            in.getResult().getId(), 0, 0, 0, false))
                ));
        }
    }
}
