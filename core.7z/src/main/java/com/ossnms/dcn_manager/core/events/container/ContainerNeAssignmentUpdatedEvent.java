package com.ossnms.dcn_manager.core.events.container;

import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;

/**
 * Base class for events that affect a container.
 */
public class ContainerNeAssignmentUpdatedEvent extends ContainerEvent {

    private final int neId;
    private final AssignmentType assignmentType;

    /**
     * Creates a new object.
     *
     * @param containerId The affected container ID.
     */
    public ContainerNeAssignmentUpdatedEvent(int containerId, int neId, AssignmentType assignmentType) {
        super(containerId);
        this.neId = neId;
        this.assignmentType = assignmentType;
    }

    public int getNeId() {
        return neId;
    }

    public int getContainerId() { return getEntityId(); }

    public AssignmentType getAssignmentType() {
        return assignmentType;
    }
}
