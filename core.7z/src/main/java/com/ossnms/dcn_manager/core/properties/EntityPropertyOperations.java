package com.ossnms.dcn_manager.core.properties;

/**
 * Defines operations that can be executed over an entity property,
 * such as obtaining its name.
 */
public interface EntityPropertyOperations {

    /** @return The property name as it is used in XML files. */
    String getName();

    /** @return The desired property visibility scope. */
    Scope getScope();

    @Override
    String toString();

    /** Property visibility intent. */
    public enum Scope {
        /** This property is intended for public (mediation) knowledge. */          PUBLIC,
        /** This property is only meant for usage between the server and client. */ PRIVATE
    }

}