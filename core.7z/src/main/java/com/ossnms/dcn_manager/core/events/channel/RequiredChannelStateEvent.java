package com.ossnms.dcn_manager.core.events.channel;

import java.util.Objects;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>Used to signal required channel activation state changes. Derived class instances represent specific
 * channel activation events, namely, activation required and deactivation required events. The following
 * figure depicts the class hierarchy.</p>
 *
 * <p> <figure>
 * <img src="doc-files/channel_required_activation_state_event-class.png">
 * <figcaption>Class diagram of the events related to operations performed on required channel state domain
 * objects</figcaption>
 * </figure> </p>
 *
 * <p>The abstract base class ({@link RequiredChannelStateEvent}) defines the information associated to all
 * concrete events, namely {@link RequiredChannelStateEvent.Activate} and {@link RequiredChannelStateEvent.Deactivate}
 * events. Instead of materializing these concrete event types as derived top-level classes, thus
 * increasing the overall solution's complexity (i.e. the total number of top-level classes), concrete event
 * types are materialized as static nested classes, leading to a curious coding pattern in which derived
 * classes are public nested classes of its super class.</p>
 *
 * <p>Despite being a curious coding pattern, the resulting solution reduces overall complexity and increases
 * readability: all related types are contained within the same compilation unit which, given its small size,
 * is not affected by significant complexity increase.</p>
 */
/*
 * @startuml doc-files/channel_required_activation_state_event-class.png

 * abstract class RequiredChannelStateEvent <<Immutable>> {
 *      - mediatorId: int
 *      # RequiredChannelStateEvent(channelId: int, mediatorId: int)
 *      # RequiredChannelStateEvent(channelId: int, mediatorId: int, description: String)
 *      + getMediatorId(): int
 * }
 * class Activate <<Immutable>> {
 * 		+ Activate(channelId: int, mediatorId: int)
 *      + Activate(channelId: int, mediatorId: int, , description: String)
 * }
 * class Deactivate <<Immutable>> {
 * 		+ Deactivate(channelId: int, mediatorId: int)
 *      + Deactivate(channelId: int, mediatorId: int, description: String)
 * }
 * abstract class ChannelEvent <<Immutable>> <|-- RequiredChannelStateEvent
 * hide ChannelEvent members
 * RequiredChannelStateEvent <|-- Activate
 * RequiredChannelStateEvent <|-- Deactivate

 * @enduml
 */
@Immutable
public abstract class RequiredChannelStateEvent extends ChannelEvent {

    /** The identifier of the mediator to which the channel is associated. */
    private final int mediatorId;
    /** Identifiers of all physical channel instances we intend to activate. */
    private final Iterable<Integer> channelInstanceIdentifiers;

    /**
     * Initiates an instance with the given arguments.
     * @param id The affected channel identifier.
     * @param mediatorId The identifier of the mediator to which the affected channel is associated.
     * @param channelInstances Channel instances upon which the required state must be enforced.
     */
    protected RequiredChannelStateEvent(int id, int mediatorId, @Nonnull Iterable<Integer> channelInstances) {
        super(id);
        this.mediatorId = mediatorId;
        this.channelInstanceIdentifiers = channelInstances;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param channelId The affected channel ID.
     * @param mediatorId The identifier of the mediator to which the affected channel is associated.
     * @param channelInstances Channel instances upon which the required state must be enforced.
     * @param detailedDescription Human-readable event description.
     */
    protected RequiredChannelStateEvent(int channelId, int mediatorId, @Nonnull Iterable<Integer> channelInstances, @Nonnull String detailedDescription) {
        super(channelId, detailedDescription);
        this.mediatorId = mediatorId;
        this.channelInstanceIdentifiers = channelInstances;
    }

    /**
     * @return The ID of the mediator to which the affected Channel is associated.
     */
    public int getMediatorId() {
        return mediatorId;
    }

    /**
     * @return Channel instances upon which the required state must be enforced.
     */
    public Iterable<Integer> getChannelInstanceIdentifiers() {
        return channelInstanceIdentifiers;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getChannelId(), getDetailedDescription(), mediatorId, channelInstanceIdentifiers);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final RequiredChannelStateEvent rhs = (RequiredChannelStateEvent) obj;
        return new EqualsBuilder()
                .append(getChannelId(), getChannelId())
                .append(getDetailedDescription(), rhs.getDetailedDescription())
                .append(mediatorId, rhs.mediatorId)
                .append(channelInstanceIdentifiers, rhs.channelInstanceIdentifiers)
                .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("mediatorId", mediatorId)
                .append("channelInstanceIdentifiers", channelInstanceIdentifiers)
                .toString();
    }

    /**
     * Class whose instances represent events used to signal that a channel activation has been required.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class Activate extends RequiredChannelStateEvent {
    	public Activate(int id, int mediatorId, @Nonnull Iterable<Integer> channelInstances) {
    		super(id, mediatorId, channelInstances);
    	}
        public Activate(int id, int mediatorId, @Nonnull Iterable<Integer> channelInstances, @Nonnull String description) {
            super(id, mediatorId, channelInstances, description);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel deactivation has been required
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class Deactivate extends RequiredChannelStateEvent {
    	public Deactivate(int id, int mediatorId, @Nonnull Iterable<Integer> channelInstances) {
            super(id, mediatorId, channelInstances);
    	}
        public Deactivate(int id, int mediatorId, @Nonnull Iterable<Integer> channelInstances, @Nonnull String description) {
            super(id, mediatorId, channelInstances, description);
        }
    }
}
