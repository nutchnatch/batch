/**
 * Contains the definition of events related to the Mediator domain entity.
 * 
 * <p>Mediator related events are classified in the following main groups, as depicted in the 
 * class diagram:
 * <ul>
 *  <li>Events pertaining to the mediator's required state 
 *  ({@link com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent});</li>
 *  <li>Events pertaining to the mediator's actual state 
 *  ({@link com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent}).</li>
 * </ul>
 * 
 * <p> <figure>
 * <img src="doc-files/mediator_event-class.png">
 * <figcaption>Class diagram of mediator related events</figcaption>
 * </figure> </p>
 * 
 * <p>The abstract classes that materialize each of group are, in turn, base classes for the concrete 
 * event types of that group. Instead of materializing these concrete event types as derived top-level classes, 
 * thereby increasing complexity of the overall solution (i.e. the total number of top-level classes), concrete 
 * event types are materialized as static nested classes, leading to a curious coding pattern in which derived 
 * classes are public nested classes of its super class. </p>
 * 
 * <p>Despite being a curious coding pattern, the resulting solution reduces overall complexity and increases
 * readability: all related types are contained within the same compilation unit, which, given its small size,
 * is not affected by significant complexity increase.</p>
 * 
 * <p>The description of these specific hierarchies is therefore presented in the documentation of each base 
 * class.</p>
 * 
 * @see com.ossnms.dcn_manager.core.events.mediator.MediatorEvent
 * @see com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent
 * @see com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent
 */
/*
 * @startuml doc-files/mediator_event-class.png
 * package emne.events {
 *   abstract class EntityEvent <<Immutable>> {
 *      -int entityId
 *      -String detailedDescription
 *      +EntityEvent(int entityId)
 *      +EntityEvent(int entityId, String detailedDescription)
 *      #int getEntityId()
 *      +String getDetailedDescription()
 *      +String toString()
 *      +boolean equals(Object obj)
 *      +int hashCode()
 *  }
 *  interface Event 
 *  hide Event members
 *  Event <|.. EntityEvent 
 * }
 
 * package emne.events.mediator {
 *  abstract class MediatorEvent <<Immutable>> {
 *      +MediatorEvent(int mediatorId)
 *      +MediatorEvent(int mediatorId, String detailedDescription)
 *      +int getMediatorId()
 *  }
 *  MediatorEvent --|> EntityEvent
 *  abstract class RequiredMediatorStateEvent <<Immutable>> --|> MediatorEvent
 *  abstract class ActualMediatorStateEvent <<Immutable>> --|> MediatorEvent
 *  hide ActualMediatorStateEvent members 
 *  hide RequiredMediatorStateEvent members 
 * @enduml
 */
package com.ossnms.dcn_manager.core.events.mediator;