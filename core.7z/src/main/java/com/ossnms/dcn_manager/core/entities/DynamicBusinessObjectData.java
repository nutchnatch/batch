package com.ossnms.dcn_manager.core.entities;

import com.google.common.collect.ImmutableMap;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import java.util.Optional;

/**
 * Base class for the data dimension of all domain objects that contain a dynamic facet,
 * i.e., that are able to store additional information as an unstructured set of (name, value)
 * pairs. Also known as "properties".
 */
@Immutable
public class DynamicBusinessObjectData extends BusinessObjectData implements PropertyBag {

    /** The set of channel dynamic properties which are not interpreted by the component. */
    private final ImmutableMap<String, String> propertyBag;

    /**
     * Constructs a new instance.
     * @param id Identifier.
     * @param version Version number.
     * @param propertyBag Final, immutable, set of (name, value) pairs to associate with this instance.
     */
    protected DynamicBusinessObjectData(int id, int version, @Nonnull ImmutableMap<String, String> propertyBag) {
        super(id, version);
        this.propertyBag = propertyBag;
    }

    /** @return A dynamic property value, if present. */
    @Override
    @Nullable
    public Optional<String> getOpaqueProperty(@Nonnull String name) {
        return Optional.ofNullable(getPropertyBag().get(name));
    }

    /** @return An immutable map with all dynamic properties that have been set. */
    @Override
    public ImmutableMap<String, String> getAllOpaqueProperties() {
        return getPropertyBag();
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("properties", getPropertyBag())
                .toString();
    }

    protected ImmutableMap<String, String> getPropertyBag() {
        return propertyBag;
    }
}
