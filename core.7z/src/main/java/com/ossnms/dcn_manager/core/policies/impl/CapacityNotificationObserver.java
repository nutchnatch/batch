package com.ossnms.dcn_manager.core.policies.impl;

/**
 * Observer that will be notified when an executor
 * has capacity available to receive new jobs.
 */
@FunctionalInterface
public interface CapacityNotificationObserver {

    /**
     * Called when an executor has capacity available to receive new jobs.
     */
    void capacityIsAvailable();

}
