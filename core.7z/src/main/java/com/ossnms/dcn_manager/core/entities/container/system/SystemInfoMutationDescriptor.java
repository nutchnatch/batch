package com.ossnms.dcn_manager.core.entities.container.system;

import com.ossnms.dcn_manager.core.entities.container.ContainerInfoMutationDescriptorBase;

import java.util.Optional;

/**
 * System container mutation descriptor.
 *
 * @see SystemInfo
 */
public class SystemInfoMutationDescriptor
        extends ContainerInfoMutationDescriptorBase<SystemInfo, SystemInfoMutationDescriptor> {

    /**
     * Creates a new object.
     * @param target Business object instance that represents the object to be modified.
     */
    public SystemInfoMutationDescriptor(SystemInfo target) {
        super(target);
    }

    @Override
    protected SystemInfoMutationDescriptor self() {
        return this;
    }

    @Override
    protected SystemInfo doApply() {
        return getName().isPresent() || getDescription().isPresent() || getUserText().isPresent()
                ? new SystemInfo(getTarget().getId(), getTarget().getVersion() + 1,
                        getName().orElse(getTarget().getName()),
                        getDescription().map(Optional::of).orElse(getTarget().getDescription()),
                        getUserText().map(Optional::of).orElse(getTarget().getUserText()))
                : getTarget();
    }

}
