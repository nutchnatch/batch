package com.ossnms.dcn_manager.core.events.domain;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import com.ossnms.dcn_manager.core.events.EntityEvent;

/**
 * Base class for events that affect a Domain domain entity.
 */
@Immutable
public abstract class DomainEvent extends EntityEvent {

    /**
     * Creates a new object.
     * @param domainId The affected domain ID.
     */
    public DomainEvent(int domainId) {
        super(domainId);
    }

    /**
     * Creates a new object.
     * @param domainId The affected Domain ID.
     * @param detailedDescription Detailed event description for human consumption.
     */
    public DomainEvent(int domainId, @Nonnull String detailedDescription) {
        super(domainId, detailedDescription);
    }

    /**
     * @return The affected Domain ID.
     */
    public int getDomainId() {
        return getEntityId();
    }
}
