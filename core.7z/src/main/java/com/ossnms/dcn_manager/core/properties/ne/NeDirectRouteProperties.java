package com.ossnms.dcn_manager.core.properties.ne;

import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySetters;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySetters.NeRoutePropertyAdapter;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySource;
import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.core.jaxb.netype.RouteMapping;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

public class NeDirectRouteProperties extends NeRouteProperties {

    public static boolean isDirectRouteProperty(@Nonnull NeType type, @Nonnull String name) {
        return type.getDirectRouteAttributes().containsKey(name);
    }

    boolean handles(@Nonnull NeType type, @Nonnull String name) {
        return isDirectRouteProperty(type, name);
    }

    private RouteMapping getRouteMapping(NeType type, String name) {
        final Attribute attribute = type.getDirectRouteAttributes().get(name);
        return attribute.getMapsTo();
    }

    public Optional<String> get(@Nonnull NeType type, @Nonnull NePropertySource propertySource, @Nonnull String name) {
        return handles(type, name)
             ? propertySource.getPreferences().getDirectRoute().getOpaqueProperty(name)
             : Optional.empty();
    }

    /**
     * <p>Produces a map of name/value pairs (properties) from the direct route
     * defined in an NE Entity.</p>
     *
     * @param propertySource An NE entity instance.
     * @return A map of name/value pairs with direct route information.
     */
    public Map<String, String> toProperties(@Nonnull NePropertySource propertySource) {
        return propertySource.getPreferences().getDirectRoute().getAllOpaqueProperties();
    }

    /**
     * Sets a single property value.
     *
     * @param type NE type metadata.
     * @param propertySource Reference NE property source, used for properties that need values from the NE entity.
     * @param descriptor Mutable property value target.
     * @param name Property name.
     * @param value New property value.
     * @throws InvalidMutationException If a property value is invalid.
     */
    public void set(@Nonnull NeType type, @Nonnull NePropertySource propertySource, @Nonnull NePropertySetters<?> descriptor, @Nonnull String name, @Nonnull String value)
            throws InvalidMutationException {
        final NeRoutePropertyAdapter<?> route = new NeRoutePropertyAdapterWithFallback(descriptor.getDirectRouteAdapter(), propertySource);
        final RouteMapping mapping = getRouteMapping(type, name);
        if (null == mapping) {
            route.setProperty(name, value);
            final Optional<String> generatedKey = getFromSource(type, type.getDirectRouteAddressKeySource(),
                    type.getDirectRouteAttributes(), route,
                    propertySource);
            route.setKey(generatedKey.orElse(null));
        } else {
            /*
             * Direct routes do not support setting cost, priority or usage attributes from properties.
             * The reason is that these attributes only make sense in the context of GNE routes, except
             * maybe for the usage ("used") information, which would be used internally anyway.
             */
            throw new InvalidMutationException("Unsupported direct route attribute: " + name);
        }
    }

    /**
     * Refreshes the direct route key. Should be used when changing NE properties because it is possible
     * for route keys to depend on NE-level properties. Should an NE-level property included in the key
     * be changed, the existing route key becomes inconsistent and therefore it is necessary to refresh it.
     *
     * @param type NE type metadata.
     * @param propertySource Reference NE property source, used for properties that need values from the NE entity.
     * @param descriptor Mutable property value target.
     */
    public void refreshRouteKey(@Nonnull NeType type, @Nonnull NePropertySource propertySource, @Nonnull NePropertySetters<?> descriptor) {
        final NeRoutePropertyAdapter<?> route = new NeRoutePropertyAdapterWithFallback(descriptor.getDirectRouteAdapter(), propertySource);
        final Optional<String> generatedKey = getFromSource(type, type.getDirectRouteAddressKeySource(),
                type.getDirectRouteAttributes(), route,
                propertySource);
        route.setKey(generatedKey.orElse(null));
    }

    /**
     * Set several property values at once.
     *
     * @param type NE type metadata.
     * @param propertySource Reference NE property source, used for properties that need values from the NE entity.
     * @param descriptor Mutable property value target.
     * @param properties New properties with values.
     * @throws InvalidMutationException If a property value is invalid.
     */
    public void set(@Nonnull NeType type, @Nonnull NePropertySource propertySource, @Nonnull NePropertySetters<?> descriptor, @Nonnull Map<String, String> properties)
            throws InvalidMutationException {
        for (final Entry<String, String> entry : properties.entrySet()) {
            if (handles(type, entry.getKey())) {
                set(type, propertySource, descriptor, entry.getKey(), entry.getValue());
            }
        }
    }

    /**
     * There are direct route properties that are built by obtaining values from other route direct properties.
     * If the business object is being updated in separate steps (if the mediation sends several update requests,
     * for example), ensure that any direct route property values set previously can be retrieved during the
     * current update.
     *
     * This is done by falling back property value requests to a previously set property source.
     *
     * @see #getProperty(String)
     */
    private static final class NeRoutePropertyAdapterWithFallback implements NeRoutePropertyAdapter<NeRoutePropertyAdapterWithFallback> {

        private final NeRoutePropertyAdapter<?> primary;
        private final NePropertySource fallback;

        private NeRoutePropertyAdapterWithFallback(NeRoutePropertyAdapter<?> primary, NePropertySource fallback) {
            this.primary = primary;
            this.fallback = fallback;
        }

        @Override
        public Optional<String> getCost() {
            return primary.getCost();
        }

        @Override
        public Optional<String> getPriority() {
            return primary.getPriority();
        }

        @Override
        public Optional<String> isUsed() {
            return primary.isUsed();
        }

        @Override
        public Optional<String> getDomain() {
            return primary.getDomain();
        }

        @Override
        public Optional<String> getGneName() { return primary.getGneName(); }

        @Override
        public Optional<String> getKey() {
            return primary.getKey();
        }

        /**
         * Obtain a property value from the property adapter. If not present, try to retrieve it
         * from the base NE property source because it may have been set in a previous update.
         *
         * @param name Property name.
         */
        @Override
        public Optional<String> getProperty(String name) {
            return primary.getProperty(name).map(Optional::of).orElse(fallback.getPreferences().getDirectRoute().getOpaqueProperty(name));
        }

        @Override
        public NeRoutePropertyAdapterWithFallback setProperty(String name, String value) {
            primary.setProperty(name, value);
            return this;
        }

        @Override
        public NeRoutePropertyAdapterWithFallback setProperties(Map<String, String> properties) {
            primary.setProperties(properties);
            return this;
        }

        @Override
        public NeRoutePropertyAdapterWithFallback setKey(String newKey) {
            primary.setKey(newKey);
            return this;
        }

        @Override
        public Map<String, String> getProperties() {
            throw new UnsupportedOperationException();
        }

    }
}
