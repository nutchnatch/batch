package com.ossnms.dcn_manager.core.properties;

import com.ossnms.dcn_manager.core.configuration.model.Type;
import com.ossnms.dcn_manager.core.entities.PropertyHandlerBase;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Optional;

/**
* Base interface for domain entity property handlers.
*
* @param <TYPE> Base domain entity type.
* @param <ENTITY> Property handler base domain entity.
* @param <MUTATION_DESCRIPTOR> Mutation descriptor class for the domain entity.
*/
public abstract class EntityPropertyHandler<TYPE extends Type, ENTITY, MUTATION_DESCRIPTOR> extends PropertyHandlerBase {

    /**
     * @param type Instance of the domain entity type.
     * @param name Property name.
     * @return True if this handler instance desires to execute the property update
     * or retrieval request.
     */
    public abstract boolean handles(@Nonnull TYPE type, @Nonnull String name);

    /**
     * Registers an update request for a property in a domain entity.
     * The actual location of the data storage depends on the specific entity.
     *
     * @param descriptor Mutation descriptor for the target domain entity.
     * @param name Property name.
     * @param value New property value.
     * @throws InvalidMutationException If the new property value is invalid
     *  or if the property is not supported by the domain entity.
     */
    public abstract void set(@Nonnull TYPE type, @Nonnull MUTATION_DESCRIPTOR descriptor, @Nonnull String name, @Nullable String value)
        throws InvalidMutationException;

    /**
     * Retrieves the value of a domain entity property.
     *
     * @param entity Domain entity instance.
     * @param name Property name.
     * @return The property value as a string, or null if the property does
     *  not exist or is not set.
     */
    public abstract Optional<String> get(@Nonnull TYPE type, @Nonnull ENTITY entity, @Nonnull String name);

}