package com.ossnms.dcn_manager.core.entities.container;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * Contains all information required to delete an existing DCN Container.
 */
public class ContainerDeletionDescriptorBase {

    private final int id;

    /**
     * Creates a new object.
     * @param containerId DCN Container identifier.
     * @throws IllegalArgumentException If the identifier is invalid.
     */
    public ContainerDeletionDescriptorBase(int containerId) {
        checkArgument(containerId > 0, "A DCN Container ID must be positive!");
        this.id = containerId;
    }

    /**
     * @return The DCN Container identifier.
     */
    public int getId() {
        return id;
    }

}
