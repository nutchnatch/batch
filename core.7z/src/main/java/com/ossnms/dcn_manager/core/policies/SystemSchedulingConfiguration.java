package com.ossnms.dcn_manager.core.policies;

/**
 * Configures job scheduling on the system, i.e., the number of jobs that
 * may be executing simultaneously in the entire system.
 *
 * Also provides access to runtime information about the system job load.
 */
public interface SystemSchedulingConfiguration {

    /**
     * @return The number of pending jobs.
     */
    int getPendingSystemJobCount();

    /**
     * @return The number of ongoing jobs.
     */
    int getOngoingSystemJobCount();

    /**
     * Sets the maximum allowed number of simultaneous work items in the system
     * execution queue. This configuration change may not have immediate
     * effect, meaning, ongoing work items will not be cancelled.
     * @param maximumOngoingJobCount The new maximum number of allowed simultaneous work items.
     * @throws IllegalArgumentException If {@literal maximumOngoingJobCount} is not greater
     * than {@value 0}.
     */
    void setMaxOngoingSystemJobCount(int maximumOngoingJobCount);

}
