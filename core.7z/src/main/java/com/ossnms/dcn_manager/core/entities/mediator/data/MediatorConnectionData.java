package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;

/**
 * Contains information about the actual (current) connection
 * to the Mediator server. It is known as its actual activation
 * state.
 */
public final class MediatorConnectionData extends BusinessObjectData {

    private final ActualActivationState actualActivationState;
    private final String additionalInfo;

    /**
     * Creates a new object with default values (inactive).
     * @param id The Mediator ID.
     * @param version This instances' version number.
     * @param prototype Initial instance data.
     */
    public MediatorConnectionData(int id, int version, MediatorConnectionPrototype<?> prototype) {
        super(id, version);
        this.actualActivationState = prototype.actualActivationState;
        this.additionalInfo = prototype.additionalInfo;
    }

    /**
     * @return Whether the Mediator is currently active.
     */
    public ActualActivationState getActualActivationState() {
        return actualActivationState;
    }

    /**
     * @return Whether the Mediator is currently failed.
     */
    public boolean isFailed() {
        return actualActivationState == ActualActivationState.FAILED;
    }

    /**
     * @return Whether the Mediator is currently active.
     */
    public boolean isActive() {
        return actualActivationState == ActualActivationState.ACTIVE;
    }

    /**
     * @return Additional state description. May be empty.
     */
    public String getAdditionalInfo() {
        return additionalInfo;
    }

    private abstract static class MediatorConnectionPrototype<T extends MediatorConnectionPrototype<T>> {

        private ActualActivationState actualActivationState = ActualActivationState.INACTIVE;
        private String additionalInfo = "";

        protected MediatorConnectionPrototype() {

        }

        protected abstract T self();

        /**
         * @param actualActivationState Whether the Mediator is currently active.
         */
        public T setActualActivationState(ActualActivationState actualActivationState) {
            this.actualActivationState = actualActivationState;
            return self();
        }

        /**
         * @param additionalInfo Additional state description. May be empty.
         */
        public T setAdditionalInfo(String additionalInfo) {
            this.additionalInfo = additionalInfo;
            return self();
        }

    }

    /**
     * Contains initial data values for the data object (it's a parameter object).
     */
    public static final class MediatorConnectionInitialData extends MediatorConnectionPrototype<MediatorConnectionInitialData> {

        @Override
        protected MediatorConnectionInitialData self() {
            return this;
        }

    }

    /**
     * Helps building a new instance of {@link MediatorConnectionData} with
     * predefined attribute values.
     */
    public static final class MediatorConnectionBuilder extends MediatorConnectionPrototype<MediatorConnectionBuilder> {

        public MediatorConnectionData build(int id, int version) {
            return new MediatorConnectionData(id, version, this);
        }

        @Override
        protected MediatorConnectionBuilder self() {
            return this;
        }

    }
}
