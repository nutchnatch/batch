package com.ossnms.dcn_manager.core.storage.ne;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.mysema.query.collections.CollQuery;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.QNeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.storage.BusinessEntityRepository;
import com.ossnms.dcn_manager.core.storage.BusinessObjectRepository;
import com.ossnms.dcn_manager.core.storage.uow.UnitOfWork;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.Set;

/**
 * Contract to be supported by all NE Entity repositories.
 *
 *  {@see DomainEntityRepository}
 */
public interface NeEntityRepository extends BusinessEntityRepository<NeEntity, NeCreateDescriptor, NeDeleteDescriptor> {

    /**
     * Contract to be supported by all repositories of NE Info domain object instances.
     * The goal here is to increase readability by getting generics out of the way, while preserving
     * compile time type checks.
     */
    interface NeInfoRepository extends BusinessObjectRepository<NeInfoData, NeInfoMutationDescriptor> {

        /**
         * Retrieves all NE Info instances present in the repository for NEs under a specific Channel.
         * @param parentChannelId Parent Channel identifier.
         * @return An instance of an iterable over all NE Info instances found.
         * @throws RepositoryException When an error occurs while working with the underlying data storage.
         */
        Iterable<NeInfoData> queryAll(int parentChannelId) throws RepositoryException;

    }

    /**
     * Contract to be supported by all repositories of NE Info domain object instances.
     * The goal here is to increase readability by getting generics out of the way, while preserving
     * compile time type checks.
     */
    interface NeConnectionRepository extends BusinessObjectRepository<NeConnectionData, NeConnectionMutationDescriptor> {

        CollQuery query(QNeConnectionData neConnection);

    }

    /**
     * Contract to be supported by all repositories of NE Operation domain object instances.
     * The goal here is to increase readability by getting generics out of the way, while preserving
     * compile time type checks.
     */
    interface NeOperationRepository extends BusinessObjectRepository<NeOperationData, NeOperationMutationDescriptor> {

        /**
         * Gets the NE Operation data related to the NE with the given "real name", if one exists.
         * @param realName The "real NE name" desired.
         * @throws RepositoryException When an error occurs while working with the underlying data storage.
         * @return An {@link Optional} instance bearing the domain object, or an
         * absent {@link Optional} if no domain object exists with the given name.
         */
        Optional<NeOperationData> queryByRealName(@Nonnull String realName)
            throws RepositoryException;

        /**
         * Gets the NE Operation data related to the NE with the given "neighbourhood ID", if one exists.
         * @param tid The "Neighbourhood ID" desired.
         * @throws RepositoryException When an error occurs while working with the underlying data storage.
         * @return An {@link Optional} instance bearing the domain object, or an
         * absent {@link Optional} if no domain object exists with the given name.
         */
        Optional<NeOperationData> queryByNeighbourhoodId(@Nonnull String tid)
            throws RepositoryException;

    }

    /**
     * Contract to be supported by all repositories of NE User Preferences domain object instances.
     * The goal here is to increase readability by getting generics out of the way, while preserving
     * compile time type checks.
     */
    interface NeUserPreferencesRepository extends BusinessObjectRepository<NeUserPreferencesData, NeUserPreferencesMutationDescriptor> {

        /**
         * Gets the NE Preferences related to the NE with the given name, if one exists.
         * @param neName The NE name.
         * @throws RepositoryException When an error occurs while working with the underlying data storage.
         * @return An {@link Optional} instance bearing the domain object, or an
         * absent {@link Optional} if no domain object exists with the given name.
         */
        Optional<NeUserPreferencesData> query(@Nonnull String neName) throws RepositoryException;

        /**
         * Gets the NE Preferences related to the NE with the given Global Identifier, if one exists.
         * @param globalId The desired identifier.
         * @throws RepositoryException When an error occurs while working with the underlying data storage.
         * @return An {@link Optional} instance bearing the domain object, or an
         * absent {@link Optional} if no domain object exists with the given name.
         */
        Optional<NeUserPreferencesData> queryByGlobalId(@Nonnull String globalId) throws RepositoryException;

    }

    /**
     * Contract to be supported by all repositories of NE synchronization domain object instances.
     * The goal here is to increase readability by getting generics out of the way, while preserving
     * compile time type checks.
     */
    interface NeSynchronizationRepository extends BusinessObjectRepository<NeSynchronizationData, NeSynchronizationMutationDescriptor> {

        /**
         * Clear current synchronization data for all Network Elements.
         * @throws RepositoryException When an error occurs while working with the underlying data storage.
         */
        void clearAllSynchronizationData() throws RepositoryException;

    }

    /**
     * Contract to be supported by all repositories of NE Gateway Route domain object instances.
     */
    interface NeGatewayRoutesRepository {

        /**
         * Attempts to find all gateway routes associated with a specific NE.
         *
         * @param neId The identifier of the desired NE.
         * @return The target NE collection of routes.
         * @throws RepositoryException When an error occurs while working with the underlying data storage.
         */
        Iterable<NeGatewayRouteData> queryRoutes(int neId)
                throws RepositoryException;


        /**
         * Attempts to find all gateway routes associated with a specific set of NEs.
         *
         * @param neIds The identifier of the desired NEs.
         * @return The map with the gateway routes grouped by ne.
         * @throws RepositoryException When an error occurs while working with the underlying data storage.
         */
        ImmutableMap<Integer, Iterable<NeGatewayRouteData>> queryRoutes(ImmutableSet<Integer> neIds)
                throws RepositoryException;


        /**
         * Creates new NE gateway routes according to the mutation descriptors provided.
         * Equal routes are never duplicated.
         *
         * @param neId The identifier of the desired NE.
         * @param routesToAdd A collection of gateway route modification descriptors for the new routes.
         * @return A collection of routes after modification.
         * @throws RepositoryException When an error occurs while working with the underlying data storage, or if the NE does
         *  not exist.
         */
        Iterable<NeGatewayRouteData> createRoutes(int neId, Iterable<NeGatewayRouteMutationDescriptor> routesToAdd)
                throws RepositoryException;

        /**
         * Update existing NE gateway routes according to the mutation descriptors provided.
         * Only existing routes are affected, no routes are created.
         *
         * @param neId The identifier of the desired NE.
         * @param routesToUpdate A collection of gateway route modification descriptors.
         * @return A collection of routes after modification.
         * @throws RepositoryException When an error occurs while working with the underlying data storage, or if the NE does
         *  not exist.
         */
        Iterable<NeGatewayRouteData> updateRoutes(int neId, Iterable<NeGatewayRouteMutationDescriptor> routesToUpdate)
                throws RepositoryException;

        /**
         * Deletes existing NE gateway routes.
         *
         * @param routeKeys A collection of keys that uniquely identify each route to delete.
         * @throws RepositoryException When an error occurs while working with the underlying data storage.
         * @see NeGatewayRouteData#getKey()
         */
        void deleteRoutes(Iterable<String> routeKeys)
                throws RepositoryException;

        /**
         * Deletes an existing NE gateway route within a Unit of Work.
         *
         * @param ctx Unit of Work context information.
         * @param routeKey A key that uniquely identifies the route to delete.
         * @see NeGatewayRouteData#getKey()
         */
        void deleteRoute(UowContext ctx, String routeKey);

        /**
         * Creates a new NE gateway route according to the mutation descriptor provided.
         *
         * @param neId The identifier of the desired NE.
         * @param routeToAdd A gateway route modification descriptor for the new route.
         * @return The newly created route.
         */
        NeGatewayRouteData createRoute(UowContext ctx, int neId, NeGatewayRouteMutationDescriptor routeToAdd);

        /**
         * Update an existing NE gateway route according to the mutation descriptor provided.
         * Only existing routes are affected, no routes are created.
         *
         * @param neId The identifier of the desired NE.
         * @param routeToUpdate A gateway route modification descriptor.
         * @return The route, after modification.
         */
        NeGatewayRouteData updateRoute(UowContext ctx, int neId, NeGatewayRouteMutationDescriptor routeToUpdate);

        /**
         * Searches for a set of NE route keys in gateway routes and direct routes.
         *
         * @param routeKeys The set of route keys to search for.
         * @return A set of pairs (key, NE ID) for all route keys that are associated with NEs.
         * @throws RepositoryException When an error occurs while working with the underlying data storage.
         * @see NeGatewayRouteData#getKey()
         */
        Set<Pair<String, Integer>> tryFindRouteKeys(@Nonnull Set<String> routeKeys)
                throws RepositoryException;

        /**
         * Bulk renaming of all domain names associated with gateway routes.
         * Should be used when an existing domain is renamed so gateway route information is coherent.
         *
         * @param previousName Previous domain name, which should still be present on routes.
         * @param newName New domain name.
         */
        void renameRouteDomains(@Nonnull String previousName, @Nonnull String newName)
                throws RepositoryException;
    }

    /**
     * Gets the repository for the entity's NE Info domain object.
     * @return The repository for the entity's NE Info domain object.
     */
    NeInfoRepository getNeInfoRepository();

    /**
     * Gets the repository for the entity's NE Connection domain object
     * @return The repository for the entity's NE Connection domain object.
     */
    NeConnectionRepository getNeConnectionRepository();

    /**
     * Gets the repository for the entity's NE Operation domain object
     * @return The repository for the entity's NE Operation domain object.
     */
    NeOperationRepository getNeOperationRepository();

    /**
     * Gets the repository for the entity's NE User Preferences domain object
     * @return The repository for the entity's NE User Preferences domain object.
     */
    NeUserPreferencesRepository getNeUserPreferencesRepository();

    /**
     * Gets the repository for the entity's NE Synchronization domain object
     * @return The repository for the entity's NE Synchronization domain object.
     */
    NeSynchronizationRepository getNeSynchronizationRepository();

    /**
     * Gets the repository for the entity's NE Gateway Route domain object
     * @return The repository for the entity's NE Gateway Route domain object.
     */
    NeGatewayRoutesRepository getNeGatewayRoutesRepository();

    /**
     * Obtains a collection of NE Information objects for NEs with a given
     * Activation Required state under a specific Channel.
     *
     * @param parentChannelId Parent Channel identifier.
     * @param active The desired activation required state.
     * @return A collection of {@link NeInfoData}.
     * @throws RepositoryException When an error occurs while working with the
     * underlying data storage.
     */
    Iterable<NeInfoData> queryActivationRequiredIs(int parentChannelId, @Nonnull RequiredActivationState active)
            throws RepositoryException;

    /**
     * Obtains a collection of NE Information objects for NEs where the actual activation
     * state does <b>not</b> match the given Actual Activation value, under a specific Channel.
     *
     * @param parentChannelId Parent Channel identifier.
     * @param active The desired actual activation state.
     * @return A collection of {@link NeInfoData}.
     * @throws RepositoryException When an error occurs while working with the
     * underlying data storage.
     */
    Iterable<NeInfoData> queryActualActivationIsDifferentThan(int parentChannelId, @Nonnull ActualActivationState active)
            throws RepositoryException;

    /**
     * Creates a new NE in the repository.
     * @param createEvent The creation event describing the new NE.
     * @return An instance of the NE just created.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    @Override
    NeEntity create(NeCreateDescriptor createEvent) throws RepositoryException;

    /**
     * Attempts to delete an existing NE from the repository.
     * @param deleteEvent The deletion event describing the request.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    @Override
    void delete(NeDeleteDescriptor deleteEvent) throws RepositoryException;

    /**
     * Gets the NE Entity instance with the given identifier, if one exists
     * @param neId The NE Entity identifier.
     * @return An {@link Optional} instance bearing the NE Entity instance, or an
     * absent {@link Optional} if no NE Entity exists with the given identifier.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    Optional<NeEntity> queryNe(int neId) throws RepositoryException;

    /**
     * Gets the name of the NE Entity with the given identifier, if one exists
     * @param neId The NE Entity identifier.
     * @return An {@link Optional} instance bearing the NE Entity name, or an
     * absent {@link Optional} if no NE Entity exists with the given identifier.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    Optional<String> queryNeName(int neId) throws RepositoryException;

    /**
     * Retrieves all NE Entity instances present in the repository.
     * @return An instance of an iterable over all known NE Entity instances.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    Iterable<NeEntity> queryAll() throws RepositoryException;

    <A> UnitOfWork<A> unitOfWork(A accumulator);
}
