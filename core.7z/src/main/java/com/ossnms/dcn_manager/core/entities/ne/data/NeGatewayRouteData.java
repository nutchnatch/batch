package com.ossnms.dcn_manager.core.entities.ne.data;

import static com.google.common.base.Preconditions.checkState;

public final class NeGatewayRouteData extends NeConnectionRouteData {

    public NeGatewayRouteData(int neId, int version, NeConnectionRoutePrototype<NeGatewayRouteData, ?> builder) {
        super(neId, version, builder);
    }

    /**
     * Facilitates the creation of a {@link NeGatewayRouteData} object by allowing
     * individual attributes to be set easily.
     */
    public static final class NeGatewayRouteBuilder
            extends NeGatewayRoutePrototype<NeGatewayRouteBuilder> {

        /**
         * Builds a new instance of {@link NeGatewayRouteData} with the information
         * provided.
         *
         * @throws IllegalStateException If no route key was provided.
         */
        public NeGatewayRouteData build(int neId, int version) {
            checkState(isKeyPresent(), "Route unique key is required for gateway routes.");
            return new NeGatewayRouteData(neId, version, this);
        }

        @Override
        protected NeGatewayRouteBuilder self() {
            return this;
        }

    }

    public abstract static class NeGatewayRoutePrototype<T extends NeGatewayRoutePrototype<T>>
        extends NeConnectionRoutePrototype<NeGatewayRouteData, T> {

    }

}
