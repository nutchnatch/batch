package com.ossnms.dcn_manager.core.configuration.loaders;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import javax.annotation.Nonnull;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.sax.SAXSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Map;


/**
 * Loads an immutable map that has file names for keys and deserialized
 * JAXB objects as their values. May use a XSD schema for validating and
 * providing default values as necessary when parsing XML files.
 *
 * @param <V> The root JAXB Java type.
 */
public class ModelLoader<V> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ModelLoader.class);

    @Nonnull
    public Map<String, V> loadValues(Class<V> valueClass, @Nonnull Iterable<URL> filesToLoad) {
        final Builder<String, V> mapBuilder = ImmutableMap.builder();
        try {
            final Unmarshaller unmarshaller = JAXBContext.newInstance(valueClass).createUnmarshaller();
            for (final URL url : filesToLoad) {
                try {
                    mapBuilder.put(
                            FilenameUtils.getBaseName(url.getFile()),
                            valueClass.cast(unmarshaller.unmarshal(url)));
                } catch (final JAXBException | IllegalArgumentException e) {
                    LOGGER.error("Failed to unmarshal XML from file '{}'. {}", url, e);
                }
            }
        } catch (final JAXBException e) {
            LOGGER.error("Could not create JAXB unmarshaller for {}. {}", valueClass.getName(), e);
        }
        return mapBuilder.build();
    }

    @Nonnull
    public Map<String, V> loadValues(
            @Nonnull Class<V> valueClass, @Nonnull Iterable<URL> filesToLoad, @Nonnull URL schemaUrl) {
        final Builder<String, V> mapBuilder = ImmutableMap.builder();
        try {
            /*
             * It is necessary to use XML Reader and SAX Parser explicitly because the XSD may contain default values,
             * which will not be used if we just apply the schema to the Unmarshaller instance.
             */
            final SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            final Schema schema = schemaFactory.newSchema(schemaUrl);
            final SAXParserFactory parserFactory = SAXParserFactory.newInstance();
            parserFactory.setNamespaceAware(true);
            parserFactory.setSchema(schema);
            final XMLReader xmlReader = parserFactory.newSAXParser().getXMLReader();
            final Unmarshaller unmarshaller = JAXBContext.newInstance(valueClass).createUnmarshaller();
            for (final URL url : filesToLoad) {
                try (InputStream urlStream = url.openStream()) {
                    final SAXSource source = new SAXSource(xmlReader, new InputSource(urlStream));
                    mapBuilder.put(
                            FilenameUtils.getBaseName(url.getFile()),
                            valueClass.cast(unmarshaller.unmarshal(source)));
                } catch (final JAXBException | IllegalArgumentException | IOException e) {
                    LOGGER.error("Failed to unmarshal XML from file '{}'. {}", url.toString(), e);
                }
            }
        } catch (final JAXBException | IllegalArgumentException | SAXException | ParserConfigurationException e) {
            LOGGER.error("Could not create JAXB unmarshaller for {}. {}", valueClass.getName(), e);
        }
        return mapBuilder.build();
    }
}
