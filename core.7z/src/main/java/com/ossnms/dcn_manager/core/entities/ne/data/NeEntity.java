package com.ossnms.dcn_manager.core.entities.ne.data;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.entities.PropertyBag;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;

/**
 * Aggregation class for network element objects.
 * Note that it should not be updated directly;
 * its members should be updated independently.
 *
 * Instances are immutable, and are therefore thread-safe.
 */
public final class NeEntity implements PropertyBag, NePropertySource {

    /**
     * Creates a new object.
     * @param id The new channel ID.
     * @param descriptor Default information.
     */
    public static NeEntity build(final int id, final int version, @Nonnull NeCreateDescriptor descriptor) {
        return new NeEntity(
                new NeConnectionData(id, version, descriptor.getConnection()),
                new NeOperationData(id, version, descriptor.getOperation()),
                new NeInfoData(id, descriptor.getChannelId(), version,
                        descriptor.getInfo().setProxyType(descriptor.getTypeName())),
                new NeSynchronizationData(id, version, descriptor.getSynchronization()),
                new NeUserPreferencesData(id, version, descriptor.getPreferences())
            );
    }

    public static String defaultName(int id, NeCreateDescriptor descriptor) {
        return String.format("%s_%d", descriptor.getTypeName(), id);
    }

    private final NeConnectionData connection;
    private final NeOperationData operation;
    private final NeInfoData info;
    private final NeSynchronizationData sync;
    private final NeUserPreferencesData preferences;

    public NeEntity(@Nonnull NeConnectionData connection,  @Nonnull NeOperationData operation,
            @Nonnull NeInfoData state, @Nonnull NeSynchronizationData sync,
            @Nonnull NeUserPreferencesData preferences) {
        this.connection = connection;
        this.operation = operation;
        this.info = state;
        this.sync = sync;
        this.preferences = preferences;
    }

    /** @return Volatile NE connection state. */
    public NeConnectionData getConnection() {
        return connection;
    }

    /** @return Volatile information about the NE operation. */
    @Override
    public NeOperationData getOperation() {
        return operation;
    }

    /** @return Persisted information about the NE state. */
    @Override
    public NeInfoData getInfo() {
        return info;
    }

    /** @return NE synchronization indicators. */
    public NeSynchronizationData getSync() {
        return sync;
    }

    /** @return Persisted information about the user preferences. */
    @Override
    public NeUserPreferencesData getPreferences() {
        return preferences;
    }

    @Override
    public Optional<String> getOpaqueProperty(String name) {
        return getPreferences().getOpaqueProperty(name).map(Optional::of).orElse(getPreferences().getDirectRoute().getOpaqueProperty(name));
    }

    @Override
    public Map<String, String> getAllOpaqueProperties() {
        return ImmutableMap.<String, String>builder()
            .putAll(getPreferences().getAllOpaqueProperties())
            .putAll(getPreferences().getDirectRoute().getAllOpaqueProperties())
            .build();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append(info)
                .append(preferences)
                .append(connection)
                .append(operation)
                .append(sync)
                .toString();
    }
}
