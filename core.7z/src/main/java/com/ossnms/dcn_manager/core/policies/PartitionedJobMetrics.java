package com.ossnms.dcn_manager.core.policies;


/**
 * Interface with job related metrics for partitioned systems
 */
public interface PartitionedJobMetrics extends JobMetrics {

    /**
     * @return the number of ongoing jobs for the given partition identifier
     */
    int getOngoingJobCount(int partitionId);

    /**
     * @return the number of pending jobs for the given partition identifier
     */
    int getPendingJobCount(int partitionId);

    /**
     * @return the max number of ongoing jobs configured for the given partition
     */
    int getMaxOngoingJobCount(int partitionId);

}
