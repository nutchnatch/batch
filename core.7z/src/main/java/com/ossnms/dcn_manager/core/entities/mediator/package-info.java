/**
 * <p>Contains data and behavior concerning the management of all Mediator domain entities.</p>
 */
package com.ossnms.dcn_manager.core.entities.mediator;