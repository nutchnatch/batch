package com.ossnms.dcn_manager.core.entities.ne.data;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;
import java.util.Optional;

/**
 * Representation of the many supported data transfer settings format.(SFTP, FTP, SCP)
 */
@Immutable
public class NeDataTransferSettings {
    
    private final Optional<String> uploadPath;
    private final Optional<String> username;
    private final Optional<String> password;
    private final Optional<String> ipAddress;
    private final boolean isScp;
    
    public NeDataTransferSettings(Optional<String> uploadPath, Optional<String> username, Optional<String> password, 
                                    Optional<String> ipAddress, boolean isScp) {
        this.uploadPath = uploadPath;
        this.username = username;
        this.password = password;
        this.ipAddress = ipAddress;
        this.isScp = isScp;
    }

    public NeDataTransferSettings(@Nonnull NeUserPreferencesData.DataTransferSettingsAdapter dataTransferSettingsAdapter) {
        this(dataTransferSettingsAdapter.getUploadpath(), dataTransferSettingsAdapter.getUsername(), dataTransferSettingsAdapter.getPassword(),
             dataTransferSettingsAdapter.getIpAddress(), dataTransferSettingsAdapter.getIsScp().orElse(false));
    }

    /**
     * @return Ne path value
     */
    public Optional<String> getUploadPath() {
        return uploadPath;
    }

    /**
     * @return Ne Username value
     */
    public Optional<String> getUsername() {
        return username;
    }

    /**
     * @return Ne Password value
     */
    public Optional<String> getPassword() {
        return password;
    }

    /**
     * @return Ne IP value
     */
    public Optional<String> getIpAddress() {
        return ipAddress;
    }

    /**
     * @return If is of type SCP
     */
    public boolean getIsScp() {
        return isScp;
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == null || o.getClass() != getClass()) {
            return false;
        }
        if (o == this) {
            return true;
        }
        final NeDataTransferSettings rhs = (NeDataTransferSettings) o;
        return new EqualsBuilder()
            .append(uploadPath, rhs.uploadPath)
            .append(username, rhs.username)
            .append(password, rhs.password)
            .append(ipAddress, rhs.ipAddress)
            .append(isScp, rhs.isScp)
            .isEquals();
    }
    
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(uploadPath)
            .append(username)
            .append(password)
            .append(ipAddress)
            .append(isScp)
            .toHashCode();
    }
    
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("uploadPath", uploadPath)
                .append("username", username)
                .append("password", password)
                .append("ipAddress", ipAddress)
                .append("isSCP", isScp)
                .toString();
    }
}
