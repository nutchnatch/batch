package com.ossnms.dcn_manager.core.entities.channel.data;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesInitialData;

/**
 * Describes an EM creation event. Contains all information necessary to create an EM.
 */
public final class ChannelCreateDescriptor {

    private final int mediatorId;
    private final String typeName;

    private final ChannelInfoInitialData infoInitialData;
    private final ChannelConnectionInitialData connectionInitialData;
    private final ChannelUserPreferencesInitialData preferencesInitialData;

    /**
     * Creates a new object.
     * @param type The EM type. Must be a known type.
     * @param mediatorId The parent mediator ID.
     */
    public ChannelCreateDescriptor(@Nonnull ChannelType type, int mediatorId) {
        this.mediatorId = mediatorId;
        this.typeName = type.getName();

        this.infoInitialData = new ChannelInfoInitialData()
            .setType(getTypeName());
        this.connectionInitialData = new ChannelConnectionInitialData();
        this.preferencesInitialData = new ChannelUserPreferencesInitialData();
    }

    /**
     * @return The identifier of the parent mediator for the new channel.
     */
    public int getMediatorId() {
        return mediatorId;
    }

    /**
     * @return The name of the Channel type.
     */
    public String getTypeName() {
        return typeName;
    }

    /**
     * @return Initial data for channel preferences. This instance is mutable.
     */
    public ChannelUserPreferencesInitialData getPreferencesInitialData() {
        return preferencesInitialData;
    }

    /**
     * @return Initial data for channel information. This instance is mutable.
     */
    public ChannelInfoInitialData getInfoInitialData() {
        return infoInitialData;
    }

    /**
     * @return Initial data for channel connection. This instance is mutable.
     */
    public ChannelConnectionInitialData getConnectionInitialData() {
        return connectionInitialData;
    }
}
