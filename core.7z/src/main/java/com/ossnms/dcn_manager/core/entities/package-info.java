/**
 * <p>Contains the definition of the component's domain entities.</p>
 *
 * <p>This package contains the definition of the component's domain entities. Instead of using a
 * modeling approach that captures the essence of the domain entities while disregarding the
 * context in which they are used, the chosen design promotes the segregation of domain entities
 * in their multiple facets, which are named <a href="#DomainObjects">domain objects</a>.</p>
 *
 * <a name="DomainObjects"></a>
 * <h4>Partitioned Domain Entities, a.k.a. Domain Objects</h4>
 *
 * <p>Each domain object is the aggregate root for information pertaining to a given facet of the
 * domain entity. For example, an obvious segregation is to decompose NE state into two facets:
 * required state and actual state. This solution has the merit of promoting locality of reference
 * because most use cases only use one of those facets. Additionally, and because not all NE state
 * is durable, by segregating NE state, durability becomes a property of the domain objects, and not
 * of the entity itself. This simplifies the code required to map entities to persistent storage.</p>
 *
 * <p>Domain objects are also designed to be <a href="#Immutability">immutable</a>, thereby attaining
 * thread-safety without the need to use defensive copying or synchronization. This solution has the
 * merit of reducing dynamic complexity, but at the expense of some increase in structural complexity
 * (i.e. more classes). The latter is usually more tractable.</p>
 *
 * <a name="Immutability"></a>
 * <h4>Immutability</h4>
 *
 * <p>As previously stated, domain objects are immutable. Although the consequences and technical
 * aspects of immutabillity are profusely documented
 * (e.g. <a href="https://docs.oracle.com/javase/tutorial/essential/concurrency/imstrat.html">here</a> and
 * <a href="http://www.javapractices.com/topic/TopicAction.do?Id=29">here</a>), our design assumes that immutability
 * means that, for all domain object state classes:
 * <ol>
 * <li>All fields are final;</li>
 * <li>All referred objects are themselves immutable (e.g. immutable collections);</li>
 * <li>All classes in the domain object state class hierarchy are immutable; (yes, we do allow inheritance,
 * but only if derived classes are themselves immutable);</li>
 * <li>And, finally, all domain object state classes must be annotated with {@link javax.annotation.concurrent.Immutable}.</li>
 * </ol>
 *
 * <p>Summing up, all domain object state instances must be
 * <a href="https://docs.oracle.com/javase/tutorial/essential/concurrency/immutable.html">immutable objects</a>,
 * that is, their state cannot change after their construction.</p>
 *
 * <a name="Mutations"></a>
 * <h4>Domain object mutations</h4>
 *
 * <p>Because domain objects are designed to be immutable, mutations must therefore be treated differently:
 * possible mutations are materialized in classes whose instances describe the mutation to be applied
 * to a given domain object instance (i.e. classes that derive from
 * {@link com.ossnms.dcn_manager.core.entities.MutationDescriptor}). These mutation descriptors, which
 * are mutable and not thread-safe because instances are not to be shared by multiple threads, are then
 * used by the repository associated to the domain object to safely produce the described mutation.
 * The following sequence diagram illustrates this idea in general terms.</p>
 *
 * <p><figure>
 * <img src="doc-files/mutation_use_case.png">
 * <figcaption>Participants in an use case that mutates a given domain object.</figcaption>
 * </figure></p>
 *
 * <p>As depicted, the use case is initiated by fetching the domain object instance from the corresponding
 * repository. The returned instance is the one which stored internally by the repository. Notice that this
 * is a safe approach because stored instances are immutable (no defensive copying and no synchronization
 * required on the domain object instance). Once the domain object instance is obtained, the use case
 * delegates the behavior that produces the mutation to the domain object itself (call labeled instance.doSomething()).
 * The returned mutation descriptor is then tentatively applied on the repository
 * (call labeled repo.tryUpdate(mutation)), which fails if a concurrent modification on the same domain
 * object instance has been detected.<p>
 *
 * <p>The detection of concurrent modifications of the same domain object instance is performed through
 * versioning, that is, domain object instances have an associated version number which increases every
 * time the object is modified. Note that a modification of a domain object instance actually corresponds
 * to the creation of a new instance with the resulting values. When the update is tentatively performed
 * on the repository, if the version number of the instance contained in the repository does not match
 * the version number of the instance to which the mutation is associated, the update fails. This optimistic
 * approach to concurrency is adequate especially because concurrent mutations are not frequent. Additionally,
 * the absence of locks implies that there is no locking overhead and, most importantly, there are no deadlocks.</p>
 *
 * <p>Another important property of domain objects is that they actually include the corresponding domain logic:
 * they are not part of an Anemic Domain model. Instead, these domain objects are responsible for reacting
 * to stimuli according to their current state, and their implementation is supported by the State Machine
 * design pattern. For example, the activation of a given NE only takes place if it is currently inactive
 * and the consequent actions are triggered by the associated domain object instance. Because successful
 * completion of updates presumes the subsequent execution of the use case's next steps, and because these
 * steps depend on the domain object concrete type (e.g. producing the corresponding domain event), in order
 * to decouple the repository from the actual code that performs those actions, a continuation based solution
 * was designed. Putting it simply, when the use case delegates the behavior to the domain object instance,
 * the appropriate mutation descriptor is created and parameterized with the function bearing the code to be
 * executed once the mutation is successfully applied on the repository (i.e., the continuation), thus
 * separating the moment of the behavior definition from its execution. The existing interactions are depicted
 * in more detail in the following sequence diagram.</p>
 *
 * <p><figure>
 * <img src="doc-files/mutation_use_case_detail.png">
 * <figcaption>Participants in an use case that mutates a given domain object.</figcaption>
 * </figure></p>
 *
 * <p>As depicted, when the use case delegates the behavior to the domain object instance (call labeled
 * instance.doSomething()), the returned mutation descriptor (labeled mutation) is created and parameterized
 * with the appropriate continuation (interactions 4 trough 7). Applying the mutation on the repository starts
 * by creating the modified version of the domain object, which is a responsibility of the mutation descriptor
 * (interactions 10 through 13), then, the new instance is tentatively stored on the repository and finally,
 * if successful, the mutation is signaled that it has been applied (interaction 14), thereby executing the
 * continuation (interaction 15).</p>
 *
 * <p>A closer observation of Figure \ref{fig:mutation_sequence_detail} reveals a cyclic dependency between mutation
 * descriptors and domain objects. Mutation descriptors are originally instantiated and parameterized by the domain
 * object's behavior (interactions 4 through 7) and domain objects are, in turn, instantiated by the mutation descriptor
 * when the described mutation is successfully applied on the repository (interactions 10 through 13). To break this
 * source code cyclic dependency, domain objects are further decomposed into their two dimensions, behavior and data,
 * described next.</p>
 *
 * <a name="Dimensions"></a>
 * <h4>Domain object's dimensions</h4>
 *
 * <p>Each concrete domain object is comprised of the corresponding concrete behavior implementation and of its delegate
 * concrete data implementation, as depicted in the following class diagram.</p>
 *
 * <p><figure>
 * <img src="doc-files/domain_objects_dimensions.png">
 * <figcaption>Domain objects dimensions.</figcaption>
 * </figure></p>
 *
 * <p>As depicted, mutation descriptors are instantiated as a result of the domain object's operations, which are materialized
 * in its behavioral dimension (in the figure, ConcreteBusinessObjectBehavior) and make use of the state in its data dimension
 * (in the figure, ConcreteBusinessObjectData). Mutation descriptors, in turn, when applied on the repository, instantiate
 * the domain object's data dimension. This decomposition of the domain object therefore eliminates the previously described
 * cyclic dependency.<p>
 *
 * <p>The previously described concepts are materialized in abstract base classes that are to be used to enforce the shared
 * semantics. Concrete mutation descriptors must therefore derive (directly or indirectly) from
 * {@link com.ossnms.dcn_manager.core.entities.MutationDescriptor}. Concrete domain objects (i.e. their data dimensions) must
 * derive (directly or indirectly) from {@link com.ossnms.dcn_manager.core.entities.BusinessObjectData}. Regarding the domain
 * objects' behavioral dimension, no base class was designed because no commonalities were identified. Regardless, all
 * behavioral dimensions implementations must be immutable and the associated delegate data dimension instance must be specified
 * upon construction.</p>
 *
 * <p>Specifically, the following domain objects are defined within this package:</p>
 * <p><figure>
 * <img src="doc-files/entity_relations.png">
 * <figcaption>High level domain object relations.</figcaption>
 * </figure></p>
 *
 * @see com.ossnms.dcn_manager.core.entities.BusinessObjectData
 * @see com.ossnms.dcn_manager.core.entities.MutationDescriptor
 **/
/*
 * @startuml doc-files/mutation_use_case.png

 * !definelong CALL_START(from,to,inMsg,nothing)
 * from -> to : inMsg
 * activate to
 * !enddefinelong

 * !definelong CALL_END(from,to,outMsg,nothing)
 * from <-- to : outMsg
 * deactivate to
 * !enddefinelong

 * !definelong CALL(from,to,inMsg,outMsg,nothing)
 * CALL_START(from,to,inMsg,nothing)
 * CALL_END(from,to,outMsg,nothing)
 * !enddefinelong

 * !define CALL_ASYNC(from,to,msg,nothing) from ->> to : msg

 * !definelong TRIGGER_CALL(from,to,inMsg,nothing)
 * from --\\ to : inMsg
 * activate to
 * !enddefinelong

 * hide footbox
 * autonumber

 * participant MutatingUseCase << command >>
 * participant "repo: SomeDORepository" as SomeDORepository << abstraction >>
 * participant "instance: SomeDO" as SomeDO << domain object >>

 * activate MutatingUseCase

 * CALL(MutatingUseCase,SomeDORepository,repo.findDO(id),instance,)
 * CALL(MutatingUseCase,SomeDO,instance.doSomething(),mutation,)
 * CALL_START(MutatingUseCase,SomeDORepository,repo.tryUpdate(mutation),)

 * TRIGGER_CALL(SomeDORepository,SomeDO,on sucess: mutation.applied(),)

 * CALL_END(SomeDORepository,SomeDO, ,)
 * CALL_END(MutatingUseCase,SomeDORepository, , )

 * deactivate MutatingUseCase
 * @enduml
 */
/*
 * @startuml doc-files/mutation_use_case_detail.png

 * !definelong CALL_START(from,to,inMsg,nothing)
 * from -> to : inMsg
 * activate to
 * !enddefinelong

 * !definelong CALL_END(from,to,outMsg,nothing)
 * from <-- to : outMsg
 * deactivate to
 * !enddefinelong

 * !definelong CALL(from,to,inMsg,outMsg,nothing)
 * CALL_START(from,to,inMsg,nothing)
 * CALL_END(from,to,outMsg,nothing)
 * !enddefinelong

 * !define CALL_ASYNC(from,to,msg,nothing) from ->> to : msg

 * !definelong TRIGGER_CALL(from,to,inMsg,nothing)
 * from --\\ to : inMsg
 * activate to
 * !enddefinelong

 * hide footbox
 * autonumber

 * participant MutatingUseCase << command >>
 * participant "repo: SomeDORepository" as SomeDORepository << abstraction >>
 * participant "instance: SomeDO" as SomeDO << domain object >>
 * participant "mutation: SomeDOMutation" as SomeDOMutation << mutation descriptor>>

 * activate MutatingUseCase

 * CALL(MutatingUseCase,SomeDORepository,repo.findDO(id),instance,)
 * CALL_START(MutatingUseCase,SomeDO,instance.doSomething(),)
 * CALL(SomeDO,SomeDOMutation,<<create>>,mutation,)
 * CALL(SomeDO,SomeDOMutation,<<specify continuation>>,,)
 * CALL_END(MutatingUseCase,SomeDO,mutation,)
 * CALL_START(MutatingUseCase,SomeDORepository,repo.tryUpdate(mutation),)

 * CALL_START(SomeDORepository,SomeDOMutation,mutation.apply(),)
 * CALL(SomeDOMutation,SomeDO,<<create>>,newInstance,)
 * CALL_END(SomeDORepository,SomeDOMutation,newInstance,)
 * CALL_START(SomeDORepository,SomeDOMutation,on sucess: mutation.applied(),)
 * CALL_START(SomeDOMutation,SomeDOMutation,<<execute continuation>>,)

 * CALL_END(SomeDORepository,SomeDOMutation,,)
 * deactivate SomeDOMutation
 * CALL_END(MutatingUseCase,SomeDORepository, , )

 * deactivate MutatingUseCase
 * @enduml
 */
/*
 * @startuml doc-files/domain_objects_dimensions.png
 * class ConcreteBusinessObjectBehavior <<Immutable>>
 * class ConcreteBusinessObjectData <<Immutable>>
 * class SomeMutationDescriptor

 * ConcreteBusinessObjectBehavior *- ConcreteBusinessObjectData : delegate
 * SomeMutationDescriptor --> ConcreteBusinessObjectData : <<instantiates>>
 * ConcreteBusinessObjectBehavior --> SomeMutationDescriptor : <<instantiates>>
 * hide members
 * @enduml
 */
/*
 * @startuml doc-files/entity_relations.png
 * class MediatorEntity <<immutable>>
 * class ChannelEntity <<immutable>>
 * class NeEntity <<immutable>>
 * class MediatorInstance <<immutable>>
 * class ChannelInstance <<immutable>>
 * class NeInstance <<immutable>>
 * MediatorEntity *-- "0..n" ChannelEntity
 * MediatorEntity *.. "1" MediatorInstance
 * ChannelEntity *-- "0..n" NeEntity
 * ChannelEntity *.. "1" ChannelInstance
 * NeEntity *.. "1" NeInstance
 * MediatorInstance *-- "0..n" ChannelInstance
 * ChannelInstance *-- "0..n" NeInstance
 * @enduml
 */
package com.ossnms.dcn_manager.core.entities;
