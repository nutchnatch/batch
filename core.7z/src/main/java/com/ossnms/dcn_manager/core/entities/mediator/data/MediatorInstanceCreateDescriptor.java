package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataInitialData;

import javax.annotation.Nonnull;

/**
 * Contains the minimum amount of information necessary to create a new
 * Mediator instance.
 */
public final class MediatorInstanceCreateDescriptor {

    private final MediatorPhysicalDataInitialData infoInitialData;
    private final MediatorPhysicalConnectionInitialData connectionInitialData;

    /**
     * Creates a new object.
     * @param host Mediator host name.
     */
    public MediatorInstanceCreateDescriptor(@Nonnull String host) {
        this.infoInitialData = new MediatorPhysicalDataInitialData()
            .setHost(host);
        this.connectionInitialData = new MediatorPhysicalConnectionInitialData();
    }

    /**
     * @return Initial mediator information data.
     */
    public MediatorPhysicalDataInitialData getInitialData() {
        return infoInitialData;
    }

    /**
     * @return Initial mediator connection data.
     */
    public MediatorPhysicalConnectionInitialData getConnectionInitialData() {
        return connectionInitialData;
    }

}
