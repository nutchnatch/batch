package com.ossnms.dcn_manager.core.entities.ne.data.types;

public enum OperationalMode {
    DISABLED,
    ENABLED;

}
