package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.google.common.base.Strings;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoInitialData;

import javax.annotation.Nonnull;
import java.util.LinkedList;
import java.util.List;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * Contains the minimum amount of information necessary to create a new
 * Mediator instance.
 */
public final class MediatorCreateDescriptor {

    private final MediatorInfoInitialData infoInitialData;
    private final MediatorConnectionInitialData connectionInitialData;
    private final String type;
    private final List<MediatorInstanceCreateDescriptor> instanceCreateDescriptors;

    /**
     * Creates a new object.
     * @param name Mediator name.
     * @param type Mediator type.
     * @throws IllegalArgumentException If either the name or type are missing.
     */
    public MediatorCreateDescriptor(@Nonnull String name, @Nonnull String type) {
        checkArgument(!Strings.isNullOrEmpty(name), "Mediator must have a name.");
        checkArgument(!Strings.isNullOrEmpty(type), "Mediator must have a type.");
        this.infoInitialData = new MediatorInfoInitialData()
            .setName(name)
            .setTypeName(type);
        this.connectionInitialData = new MediatorConnectionInitialData();
        this.instanceCreateDescriptors = new LinkedList<>();
        this.type = type;
    }

    /**
     * @return The list of physical mediator instances to be created together with this logical
     *  Mediator. This is a live list, meaning that any changes will be reflected in the creator
     *  instance and thus in the created object.
     */
    public List<MediatorInstanceCreateDescriptor> getInstanceCreateDescriptors() {
        return instanceCreateDescriptors;
    }

    /**
     * @return Initial mediator information data.
     */
    public MediatorInfoInitialData getInfoInitialData() {
        return infoInitialData;
    }

    /**
     * @return Initial mediator connection data.
     */
    public MediatorConnectionInitialData getConnectionInitialData() {
        return connectionInitialData;
    }

    /**
     * @return Initial mediator type name.
     */
    public String getType() {
        return type;
    }

}
