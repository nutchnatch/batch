package com.ossnms.dcn_manager.core.configuration.loaders;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.net.URL;

/**
 * Loader for XML configuration files that uses types bound with JAXB.
 */
public final class XmlConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(XmlConfiguration.class);

    private XmlConfiguration() {
    }

    @Nonnull
    public static <T> T unmarshal(Class<T> valueClass, @Nonnull URL source, @Nonnull T defaultValue) {
        try {
            final Unmarshaller unmarshaller = JAXBContext.newInstance(valueClass).createUnmarshaller();
            return valueClass.cast(unmarshaller.unmarshal(source));
        } catch (final JAXBException | IllegalArgumentException e) {
            LOGGER.warn("Failed to unmarshal {}. {}", source, e);
        }
        return defaultValue;
    }

}
