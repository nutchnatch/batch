package com.ossnms.dcn_manager.core.entities.container.system;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.entities.container.ContainerCreationDescriptorBase;

/**
 * Contains all information required to create a new System Container.
 */
public final class SystemCreationDescriptor extends ContainerCreationDescriptorBase<SystemCreationDescriptor> {

    /**
     * Creates a new object.
     * @param systemName System Container name. Must not be empty.
     * @throws IllegalArgumentException If the name is null or empty.
     */
    public SystemCreationDescriptor(@Nonnull String systemName) {
        super(systemName);
    }

    /**
     * Creates a new object.
     * @param parentContainer Parent DCN Container identifier. Must be positive.
     * @param systemName System Container name. Must not be empty.
     * @throws IllegalArgumentException If the name is null or empty or if the parent identifier is zero or negative.
     */
    public SystemCreationDescriptor(int parentContainer, @Nonnull String systemName) {
        super(parentContainer, systemName);
    }

    @Override
    protected SystemCreationDescriptor self() {
        return this;
    }
}
