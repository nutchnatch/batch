/**
 * <p>Package that contains the implementations of the existing DCN interaction management 
 * policies. It also includes the utility classes (with package accessibility) that were 
 * used in the implementations of the DCN interaction management policies. </p>
 * 
 * <p>Note that these classes were not designed bearing generality in mind. Instead, their 
 * purpose is to eliminate code repetition between interaction management policies 
 * implementations and ensure thread-safety by using lock-free techniques. They were 
 * thereby crafted bearing this goal in mind. </p>
 * 
 * <p>The following class diagram depicts the existing utility classes and their relations.
 * </p>
 * <p> <figure>
 * <img src="doc-files/utilities-class.png">
 * <figcaption>Class diagram of the package's utility classes</figcaption>
 * </figure> </p>
 * 
 * <p>All utility classes are thread-safe, either because instances are immutable (e.g. 
 * {@link com.ossnms.dcn_manager.core.policies.impl.Job}), or by using synchronization 
 * (in this case lock-free techniques).</p>
 * 
 * <p> The remaining package's classes correspond to the actual implementations of 
 * interaction management policies, and therefore are publicly accessible. The following 
 * class diagram depicts the existing implementations of interaction management policies 
 * and their dependencies with the formerly mentioned utility classes.</p>
 * 
 * <img src="doc-files/interaction_policies_impl-class.png">
 * <figcaption>Class diagram of interaction management policies.</figcaption>
 * </figure> </p>
 */
/*
 * @startuml doc-files/utilities-class.png
 * abstract class Job<RB> {
 *      -RB event
 *      +Job(RB requestEvent)
 *      +RB getOriginatingEvent()
 * }
 * note left of Job
 * <RB> Base type of the events 
 * associated with the job (<u>R</u>equired 
 * event <u>B</u>ase class).
 * endnote
 * interface Runnable {
 * }
 * hide Runnable members
 * Runnable <|.. Job

 * class BoundedExecutor<T extends Runnable> {
 *      -Executor executor
 *      -ConcurrentLinkedQueue<T> ongoingWorkItems
 *      -AtomicInteger size
 *      -int maxWorkItems
 *      +BoundedExecutor(Executor executor, int maxWorkItems)
 *      +boolean trySubmitWorkItem(T workItem)
 *      +Optional<T> signalWorkItemCompletion(Predicate<T> selector)
 *      +int getWorkItemCount()
 *      +int getMaxWorkItemCount()
 *      +void setMaxWorkItemCount(int value)
 * }

 * class ExecutionQueue<T extends Runnable> {
 *      -Executor executor
 *      -ConcurrentLinkedQueue<T> ongoingWorkItems
 *      -AtomicInteger size
 *      -int maxWorkItems
 *      +ExecutionQueue(Executor executor, int maxWorkItems)
 *      +boolean trySubmitWorkItem(T workItem)
 *      +Optional<T> signalWorkItemCompletion(Predicate<T> selector)
 *      +int getWorkItemCount()
 *      +int getWorkItemCount()
 *      +void setMaxWorkItemCount(int value)
 * }

 * class PrunableQueue<T> {
 *      -ConcurrentLinkedQueue<T> queue
 *      -AtomicInteger size
 *      +PrunableQueue()
 *      +int getSize()
 *      +Optional<T> tryDequeue()
 *      +void enqueue(T elem)
 *      +Optional<T> prune(Predicate<T> predicate)
 * }

 * ExecutionQueue *-- "1" BoundedExecutor : jobExecutor
 * ExecutionQueue *-- "1" PrunableQueue : jobRetainer
 * @enduml
 */
/*
 * @startuml doc-files/interaction_policies_impl-class.png
 * 
 * package .policies {
 *      interface MediatorInteractionManager
 *      interface ChannelInteractionManager
 * }
 * package .policies.impl {
 *      abstract class Job<RC extends RB, RB> <<abstract>>
 *      class ExecutionQueue<T extends Runnable>
 *      MediatorInteractionmanagerImpl o--> "1" ExecutionQueue : contains
 *      MediatorInteractionmanagerImpl ..> Job
 *      MediatorInteractionmanagerImpl ..|> MediatorInteractionManager
 *      ChannelInteractionmanagerImpl o--> "n" ExecutionQueue : contains
 *      ChannelInteractionmanagerImpl ..> Job
 *      ChannelInteractionmanagerImpl ..|> ChannelInteractionManager
 * }
 
 * hide members
 * @enduml
 */
package com.ossnms.dcn_manager.core.policies.common;