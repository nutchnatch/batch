package com.ossnms.dcn_manager.core.configuration.model;

import com.google.common.base.Predicate;
import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableBiMap.Builder;
import com.google.common.collect.Maps;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownChannelPropertyNames;
import com.ossnms.dcn_manager.core.jaxb.emtype.Config;
import com.ossnms.dcn_manager.core.jaxb.emtype.Mappings;
import com.ossnms.dcn_manager.core.jaxb.emtype.Properties;
import com.ossnms.dcn_manager.core.jaxb.emtype.SupportedNeType;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import com.ossnms.dcn_manager.core.jaxb.type.TypeProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;
import java.util.stream.StreamSupport;

public class ChannelType extends Type {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelType.class);

    private final Config configuration;
    private final Types<NeType> supportedNeTypes;
    private final BiMap<String, String> propertyMapping;

    /**
     * Creates a new object.
     * @param configuration
     * @param neTypes All NE Types known by EM/NE. They will be
 *  filtered according to the EM Type configuration.
     * @param defaultPropertyValues All default property values known by
*  EM/NE. They will be filtered according to the EM Type configuration.
     */
    public ChannelType(Config configuration, @Nonnull Types<NeType> neTypes,
                       @Nonnull DefaultPropertyValues defaultPropertyValues) {
        super(defaultPropertyValues);
        this.configuration = configuration;
        propertyMapping = readPropertyMapping(this.configuration);
        supportedNeTypes = neTypes;

        LOGGER.debug("{} property mapping: {}", this.configuration.getName(), propertyMapping);
    }

    public boolean supportsDiscovery() {
        // the attribute read from XML can be null, so we must avoid unboxing.
        return Boolean.TRUE.equals(configuration.isSupportsDiscovery());
    }

    public boolean supportsGlobalSFTP() {
        // the attribute read from XML can be null, so we must avoid unboxing.
        return Boolean.TRUE.equals(configuration.isSupportsGlobalSFTP());
    }

    private BiMap<String, String> readPropertyMapping(Config config) {
        final Builder<String,String> builder = ImmutableBiMap.builder();
        final Properties properties = config.getProperties();
        final Mappings mappings = properties != null ? properties.getMappings() : null;
        if (null != mappings) {
            putIfValid(builder, WellKnownChannelPropertyNames.USER_TEXT, mappings.getUserText());
        } else {
            LOGGER.warn("No property mapping found for Channel Type {}.", config.getName());
        }
        return builder.build();
    }

    /**
     * Given a property name as it is defined for a specific Channel Type,
     * produce the normalized internal name. If no normalization
     * exists, return the original name.
     *
     * @param name Channel property name.
     * @return Normalized name or the original name if no normalization exists.
     */
    @Override
    public String mapIncomingPropertyName(String name) {
        return propertyMapping.inverse().getOrDefault(name, name);
    }

    /**
     * Given a normalized property name, produce the name as it is
     * defined for a specific Channel Type. If no specialization exists,
     * return the original name.
     *
     * @param name Normalized property name.
     * @return Channel name or the original name if no specialization exists.
     */
    @Override
    public String mapOutgoingPropertyName(String name) {
        return propertyMapping.getOrDefault(name, name);
    }

    @Override
    public String getName() {
        return configuration.getName();
    }

    /** @return The list of NE Types supported by this EM. */
    @Nonnull
    public Collection<NeType> getSupportedNeTypes() {
        return Maps
            .filterKeys(supportedNeTypes, new NeTypeNameIsSupported())
            .values();
    }

    /**
     * @return The default network icon name.
     */
    @Nonnull
    public String getDefaultIcon() {
        return configuration.getDefaultIcon().getName();
    }

    @Override
    protected TypeProperties getSupportedTypeProperties() {
        return configuration.getTypeProperties();
    }

    @Override
    protected PropertyPageFiles getSupportedPropertyFiles() {
        return configuration.getPropertyPageFiles();
    }

    private final class NeTypeNameIsSupported implements Predicate<String> {
        @Override
        public boolean apply(@Nonnull final String name) {
            final Optional<SupportedNeType> found = StreamSupport.stream(configuration.getSupportedNeTypes().getSupportedNeType().spliterator(), false)
                            .filter(neType -> neType.getName().equals(name))
                            .findFirst();
            return found.isPresent();
        }
    }

}
