package com.ossnms.dcn_manager.core.outbound;

import com.ossnms.dcn_manager.core.events.settings.NativeNeNamingSettingChangeEvent;

/**
 * Describes an API for sending notifications to other components about configuration changes.
 */
public interface GlobalSettingsNotifications {

    /**
     * Notifies other components about changes to the Native NE Naming option.
     *
     * @param event Changes made.
     */
    void notifyChanges(NativeNeNamingSettingChangeEvent event);

}
