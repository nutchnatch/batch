package com.ossnms.dcn_manager.core.entities.channel.data;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectData;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectPrototype;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.function.Function;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * <p> Class that implements the data dimension of the domain object that contains all channel settings
 * that can be modified by the user. Includes settings that are not managed by EM/NE, that is, they are
 * not interpreted by the component and therefore their meaning is only relevant for other components.
 * Because EM/NE does not make use of these properties, the domain object does not have a behavior
 * dimension. </p>
 *
 * <p> Some settings have well known names for interfacing with the user interface and are
 * not stored in the property bag (see {@link com.ossnms.dcn_manager.core.properties.channel.ChannelProperties}). </p>
 *
 * <p>As all types that implement domain objects' data dimension, instances of this class are immutable,
 * and are therefore thread-safe.</p>
 */
public final class ChannelUserPreferencesData extends DynamicBusinessObjectData {

    private static final int DEFAULT_ACTIVATIONS_LIMIT = 20;

	/** The channel's user friendly name */
    private final String name;
    /** The channel's reconnect interval, expressed in minutes */
    private final int reconnectInterval;
    /** Do we limit the number of concurrent interactions against this channel? */
    private final boolean concurrentActivationsLimited;
    /** How many concurrent interactions are allowed against this channel? */
    private final int concurrentActivationsLimit;

    private Optional<String> userText = Optional.empty();

    /**
     * Creates an instance with the given arguments.
     *
     * @param id The channel identifier
     * @param version The domain object's version number
     * @param prototype Initial instance data
     */
    public ChannelUserPreferencesData(int id, int version, ChannelUserPreferencesPrototype<?> prototype) {
        super(id, version, ImmutableMap.copyOf(prototype.getPropertyBag()));
        reconnectInterval = prototype.reconnectInterval;
        name = prototype.name;
        concurrentActivationsLimited = prototype.concurrentActivationsLimited;
        concurrentActivationsLimit = prototype.concurrentActivationsLimit;
        userText = prototype.userText;
    }

    /** @return The channel name. */
    public String getName() {
        return name;
    }

    /** @return The channel's reconnect interval */
    public int getReconnectInterval() {
        return reconnectInterval;
    }

    public Optional<String> getUserText() {
        return userText;
    }

    /**
     * @return Whether the number of concurrent activations should be limited.
     */
    public boolean isConcurrentActivationsLimited() {
        return concurrentActivationsLimited;
    }

    /**
     * @return The maximum number of concurrent activations that can be in progress
     *  at any time. Enforced only if {@code concurrentActivationsLimited} is true.
     */
    public int getConcurrentActivationsLimit() {
        return concurrentActivationsLimit;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("name", name)
                .append("reconnectInterval", reconnectInterval)
                .append("concurrentActivationsLimited", concurrentActivationsLimited)
                .append("concurrentActivationsLimit", concurrentActivationsLimit)
                .toString();
    }

    public static final Function<ChannelUserPreferencesData, String> GET_NAME =
            input -> null != input ? input.getName() : null;

    /**
     * Facilitates the creation of a data object by allowing
     * individual attributes to be set easily.
     */
    public static final class ChannelUserPreferencesBuilder extends ChannelUserPreferencesPrototype<ChannelUserPreferencesBuilder> {

        public ChannelUserPreferencesData build(int id, int version) {
            return new ChannelUserPreferencesData(id, version, this);
        }

        @Override
        protected ChannelUserPreferencesBuilder self() {
            return this;
        }

    }

    /**
     * Contains initial data values for the data object (it's a parameter object).
     */
    public static final class ChannelUserPreferencesInitialData extends ChannelUserPreferencesPrototype<ChannelUserPreferencesInitialData> {
        @Override
        protected ChannelUserPreferencesInitialData self() {
            return this;
        }

        /**
         * @return The future channel name.
         */
        public String getName() {
            return super.name;
        }
    }

    public abstract static class ChannelUserPreferencesPrototype<T extends ChannelUserPreferencesPrototype<T>>
            extends DynamicBusinessObjectPrototype<T>
            implements ChannelPropertySetters<T> {

        private String name;
        private int reconnectInterval;
        private boolean concurrentActivationsLimited = true;
        private int concurrentActivationsLimit = DEFAULT_ACTIVATIONS_LIMIT;
        private Optional<String> userText = Optional.empty();

        protected ChannelUserPreferencesPrototype() {

        }

        protected ChannelUserPreferencesPrototype(@Nonnull ChannelUserPreferencesPrototype<?> prototype) {
            super(prototype);
            name = prototype.name;
            reconnectInterval = prototype.reconnectInterval;
            concurrentActivationsLimited = prototype.concurrentActivationsLimited;
            concurrentActivationsLimit = prototype.concurrentActivationsLimit;
            userText = prototype.userText;
        }

        @Override
        public T setName(String newName) {
            checkArgument(!Strings.isNullOrEmpty(newName), "Channel name must not be empty!");
            name = newName;
            return self();
        }

        @Override
        public T setReconnectInterval(int reconnectInterval) {
            this.reconnectInterval = reconnectInterval;
            return self();
        }

        /**
         * @param concurrentActivationsLimited Whether the number of concurrent activations should be limited.
         */
        @Override
        public T setConcurrentActivationsLimited(boolean concurrentActivationsLimited) {
            this.concurrentActivationsLimited = concurrentActivationsLimited;
            return self();
        }

        /**
         * @param concurrentActivationsLimit The maximum number of concurrent activations that can be in progress
         *      at any time. Enforced only if {@code concurrentActivationsLimited} is true.
         */
        @Override
        public T setConcurrentActivationsLimit(int concurrentActivationsLimit) {
            this.concurrentActivationsLimit = concurrentActivationsLimit;
            return self();
        }

        @Override
        public T setUserText(Optional<String> userText) {
            this.userText = userText;
            return self();
        }
    }
}
