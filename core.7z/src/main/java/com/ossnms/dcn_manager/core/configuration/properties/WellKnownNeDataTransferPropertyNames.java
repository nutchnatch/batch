package com.ossnms.dcn_manager.core.configuration.properties;

public final class WellKnownNeDataTransferPropertyNames {

    private WellKnownNeDataTransferPropertyNames() {
    }

    public static final String USERNAME     = "USERNAME";
    public static final String PASSWORD     = "PASSWORD";
    public static final String UPLOADPATH   = "UPLOADPATH";
    public static final String IP_ADDRESS   = "IP_ADDRESS";
    public static final String IS_SCP       = "IS_SCP";
    public static final String IS_FTP       = "IS_FTP";
    public static final String PROFILE_NAME = "PROFILE_NAME";

}
