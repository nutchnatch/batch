package com.ossnms.dcn_manager.core.entities.container;

import com.google.common.base.Objects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;

import javax.annotation.Nonnull;

import java.util.Optional;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.isNullOrEmpty;

/**
 * DCN container mutation descriptor.
 *
 * @see ContainerInfoBase
 */
public abstract class ContainerInfoMutationDescriptorBase<T extends ContainerInfoBase, M extends ContainerInfoMutationDescriptorBase<T, M>>
        extends MutationDescriptor<T, M> {

    private Optional<String> name = Optional.empty();
    private Optional<Integer> parentId = Optional.empty();
    private Optional<String> description = Optional.empty();
    private Optional<String> userText = Optional.empty();

    protected ContainerInfoMutationDescriptorBase(T target) {
        super(target);
    }

    /**
     * @return The new container name.
     */
    public Optional<String> getName() {
        return name;
    }

    /**
     * @param name The new container name.
     * @throws IllegalArgumentException If the new name is null or empty.
     */
    public M setName(@Nonnull String name) {
        checkArgument(!isNullOrEmpty(name), "DCN Container names must not be empty.");
        final Optional<String> newValue = Optional.of(name);
        if (!Objects.equal(this.name, newValue)) {
            this.name = newValue;
        }
        return self();
    }

    /**
     * @return The new parent container identifier.
     */
    public Optional<Integer> getParentId() {
        return parentId;
    }

    /**
     * @param parentId The new parent container identifier.
     * @throws IllegalArgumentException If the new identifier is not positive.
     */
    public M setParentId(int parentId) {
        checkArgument(parentId >= 0, "A DCN Container ID must be positive!");
        final Optional<Integer> newValue = Optional.of(parentId);
        if (!Objects.equal(this.parentId, newValue)) {
            this.parentId = newValue;
        }
        return self();
    }

    /**
     * @return Human readable description.
     */
    public Optional<String> getDescription() {
        return description;
    }

    /**
     * @param description Human readable description.
     */
    public M setDescription(Optional<String> description) {
        if (!Objects.equal(this.description, description)) {
            this.description = description;
        }
        return self();
    }

    /**
     * @return Container user text, provided by the operator.
     */
    public Optional<String> getUserText() {
        return userText;
    }

    /**
     * @param userText Container user text, provided by the operator.
     */
    public M setUserText(Optional<String> userText) {
        if (!Objects.equal(this.userText, userText)) {
            this.userText = userText;
        }
        return self();
    }
}
