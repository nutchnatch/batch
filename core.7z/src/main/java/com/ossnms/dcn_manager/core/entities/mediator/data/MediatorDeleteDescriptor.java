package com.ossnms.dcn_manager.core.entities.mediator.data;

/**
 * Contains the minimum amount of information necessary to delete
 * an existing Mediator instance.
 */
public final class MediatorDeleteDescriptor {

    private final int id;

    /**
     * Creates a new object.
     * @param id The identifier of the Mediator to delete.
     */
    public MediatorDeleteDescriptor(int id) {
        this.id = id;
    }

    /**
     * @return The identifier of the Mediator to delete.
     */
    public int getId() {
        return id;
    }

}
