package com.ossnms.dcn_manager.core.events;

import com.google.common.base.MoreObjects;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;

public class NeDiscoveredEvent implements Event {

    private final Map<String, String> properties;
    private final NeCreateDescriptor createDescriptor;
    private final Optional<String> receivedName;
    private final int receivedId;

    public NeDiscoveredEvent(
            @Nonnull NeCreateDescriptor createDescriptor, @Nonnull Map<String, String> properties,
            @Nonnull Optional<String> nameReceived, int idReceived) {
        this.createDescriptor = createDescriptor;
        this.properties = properties;
        this.receivedName = nameReceived;
        this.receivedId = idReceived;
    }

    /**
     * @return Discovered NE properties.
     */
    public Map<String, String> getProperties() {
        return properties;
    }

    /**
     * @return Create Descriptor for the discovered NE.
     */
    public NeCreateDescriptor getCreateDescriptor() {
        return createDescriptor;
    }

    /**
     * @return Received NE name.
     */
    public Optional<String> getNameReceived() {
        return receivedName;
    }

    /**
     * @return Received NE id.
     */
    public int getIdReceived() {
        return receivedId;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("receivedName", receivedName)
                .add("receivedId", receivedId)
                .add("createDescriptor", createDescriptor)
                .add("properties", properties)
                .toString();
    }
}
