package com.ossnms.dcn_manager.core.configuration.properties;


/**
 * Contains constants with the names of "well known" Mediator properties, i.e.,
 * properties that are required to be present in Mediator XML files.
 */
public final class WellKnownMediatorPropertyNames {

    public static final String ID_NAME = "BCB-Attribute/Mediator/idName";

    public static final String PRIMARY_HOST_NAME = "BCB-Attribute/Mediator/primaryHost";
    public static final String SECONDARY_HOST_NAME = "BCB-Attribute/Mediator/secondaryHost";

    public static final String DESCRIPTION = "Description";
    public static final String RECONNECT_INTERVAL = "ReconnectInterval";
    public static final String CONCURRENT_ACTIVATIONS_LIMITED = "ConcurrentActivationsLimited";
    public static final String CONCURRENT_ACTIVATIONS_LIMIT = "ConcurrentActivationsLimit";
    public static final String USER_TEXT = "UserText";

    private WellKnownMediatorPropertyNames() {

    }

}
