package com.ossnms.dcn_manager.core.entities.ne.data;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import java.util.Optional;


/**
 * <p>Holds NE synchronization stamps.</p>
 *
 * <p>These are intended to be used as a means of detection of a loss of
 * synchronization between TNMS and the mediation (not between the mediation
 * and the NE).</p>
 *
 * <p>They are hence used at NE initialization time so the amount of
 * data requested by TNMS can be reduced. In such case only the data
 * related to the stamps that are different will be requested.</p>
 */
public final class NeSynchronizationData extends BusinessObjectData {

    private final Optional<Long> all;
    private final Optional<Long> alarms;
    private final Optional<Long> packet;

    /**
     * Creates a new instance.
     *
     * @param neId Associated NE identifier.
     * @param version Data version number, for optimistic locking purposes.
     * @param prototype Initial data.
     */
    public NeSynchronizationData(int neId, int version, @Nonnull NeSynchronizationPrototype<?> prototype) {
        super(neId, version);
        all = prototype.all;
        alarms = prototype.alarms;
        packet = prototype.packet;
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .appendSuper(super.hashCode())
                .append(all)
                .append(alarms)
                .append(packet)
                .toHashCode();
    }

    /**
     * Two instances are considered equivalent if they have the same type and the same attribute values.
     */
    @Override
    public boolean equals(Object theOther) {
        if (theOther == null || !this.getClass().equals(theOther.getClass())) {
            return false;
        }

        final NeSynchronizationData other = (NeSynchronizationData) theOther;
        return new EqualsBuilder()
                .append(getId(), other.getId())
                .append(getVersion(), other.getVersion())
                .append(all, other.all)
                .append(alarms, other.alarms)
                .append(packet, other.packet)
                .isEquals();
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("all", all)
                .append("alarms", alarms)
                .append("packet", packet)
                .toString();
    }

    /**
     * @return "All" synchronization category stamp value.
     */
    public Optional<Long> getAll() {
        return all;
    }

    /**
     * @return "Alarm" synchronization category stamp value.
     */
    public Optional<Long> getAlarms() {
        return alarms;
    }

    /**
     * @return "Packet" synchronization category stamp value.
     */
    public Optional<Long> getPacket() {
        return packet;
    }

    /**
     * Parameter object to be used on Network Element entity creation.
     */
    public static final class NeSynchronizationInitialData
            extends NeSynchronizationPrototype<NeSynchronizationInitialData> {

        @Override
        protected NeSynchronizationInitialData self() {
            return this;
        }

    }

    /**
     * Builds an instance of {@link NeSynchronizationData} with initial data.
     */
    public static final class NeSynchronizationBuilder
            extends NeSynchronizationPrototype<NeSynchronizationBuilder> {

        @Override
        protected NeSynchronizationBuilder self() {
            return this;
        }

        /**
         * Creates a new instance of {@link NeSynchronizationData}.
         *
         * @param neId Associated NE identifier.
         * @param version Data version number, for optimistic locking purposes.
         * @return The new instance.
         */
        public NeSynchronizationData build(int neId, int version) {
            return new NeSynchronizationData(neId, version, this);
        }

    }

    /**
     * Facilitates creation of a {@link NeSynchronizationData} object by allowing individual attributes
     * to be set easily.
     */
    public abstract static class NeSynchronizationPrototype<T extends NeSynchronizationPrototype<T>> {

        private Optional<Long> all = Optional.empty();
        private Optional<Long> alarms = Optional.empty();
        private Optional<Long> packet = Optional.empty();

        protected NeSynchronizationPrototype() {

        }

        protected NeSynchronizationPrototype(@Nonnull NeSynchronizationPrototype<?> other) {
            all = other.all;
            alarms = other.alarms;
            packet = other.packet;
        }

        protected abstract T self();

        /**
         * @param all New "all" synchronization category stamp value.
         */
        public T setAll(Optional<Long> all) {
            this.all = all;
            return self();
        }

        /**
         * @param alarms New "alarms" synchronization category stamp value.
         */
        public T setAlarms(Optional<Long> alarms) {
            this.alarms = alarms;
            return self();
        }

        /**
         * @param packet New "packet" synchronization category stamp value.
         */
        public T setPacket(Optional<Long> packet) {
            this.packet = packet;
            return self();
        }


    }

}
