package com.ossnms.dcn_manager.core.entities.domain;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.isNullOrEmpty;

import java.util.Objects;

import javax.annotation.Nonnull;

/**
 * Contains all information required to create a new Domain.
 */
public final class DomainCreationDescriptor {

    private final String name;
    private boolean automaticNeActivationPermitted;

    /**
     * Creates a new object. Defaults automaticNeActivationPermitted to false
     * @param domainName Domain name. Must not be empty.
     * @throws IllegalArgumentException If the name is null or empty.
     */
    public DomainCreationDescriptor(@Nonnull String domainName) {
        this(domainName, false);
    }

    /**
     * Creates a new object.
     * @param domainName Domain name. Must not be empty.
     * @param automaticNeActivationPermitted Enable automatic activation of discovered NEs
     * @throws IllegalArgumentException If the name is null or empty.
     */
    public DomainCreationDescriptor(@Nonnull String domainName, boolean automaticNeActivationPermitted) {
        checkArgument(!isNullOrEmpty(domainName), "A domain name must not be empty!");
        this.name = domainName;
        this.automaticNeActivationPermitted = automaticNeActivationPermitted;
    }

    /**
     * @return The new domains' name.
     */
    public String getName() {
        return name;
    }

    /**
     * @return Whether automatic activation of freshly discovered NEs is permitted
     *  within this domain.
     */
    public boolean isAutomaticNeActivationPermitted() {
        return automaticNeActivationPermitted;
    }

    /**
     * @param automaticNeActivationPermitted Whether automatic activation of freshly
     *  discovered NEs is permitted within this domain.
     */
    public DomainCreationDescriptor setAutomaticNeActivationPermitted(boolean automaticNeActivationPermitted) {
        this.automaticNeActivationPermitted = automaticNeActivationPermitted;
        return this;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, automaticNeActivationPermitted);
    }

    @Override
    public boolean equals(Object obj) {
        if (null == obj || obj.getClass() != DomainCreationDescriptor.class) {
            return false;
        }
        final DomainCreationDescriptor rhs = (DomainCreationDescriptor) obj;
        return Objects.equals(name, rhs.name) && automaticNeActivationPermitted == rhs.automaticNeActivationPermitted;
    };
}
