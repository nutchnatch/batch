package com.ossnms.dcn_manager.core.utils;

import com.google.common.base.Predicate;

import java.util.Optional;

/**
 * Validates the presence of a value in instances of {@link Optional}.
 */
public class IsPresent<T extends Optional<?>> implements Predicate<T> {

    @Override
    public boolean apply(T input) {
        return null != input && input.isPresent();
    }

}
