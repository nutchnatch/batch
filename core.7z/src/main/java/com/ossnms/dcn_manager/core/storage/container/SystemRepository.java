package com.ossnms.dcn_manager.core.storage.container;

import com.ossnms.dcn_manager.core.entities.container.system.SystemCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.BusinessEntityRepository;
import com.ossnms.dcn_manager.core.storage.BusinessObjectRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Describes all operations that must be supported by a repository
 * of System Containers.
 */
public interface SystemRepository
        extends BusinessEntityRepository<SystemInfo, SystemCreationDescriptor, SystemDeletionDescriptor>,
                BusinessObjectRepository<SystemInfo, SystemInfoMutationDescriptor> {

    /**
     * Find a System Container by its name. All DCN containers, of which System Containers are
     * a specialization, have unique names.
     *
     * @param systemName Desired System Container name.
     * @return An instance of a System Container with the name provided, if found.
     * @throws RepositoryException When an error occurs when working with the database.
     */
    Optional<SystemInfo> queryByName(@Nonnull String systemName) throws RepositoryException;

}
