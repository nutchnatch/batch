package com.ossnms.dcn_manager.core.policies.common;

import java.util.Observer;
import java.util.concurrent.Executor;

/**
 * An {@link Executor} that allows listening to task completion notifications.
 * When a task completes any observers are notified. This invocation means that capacity may eventually
 * be available and occurs within the context of any thread, probably the thread that ran the command.
 *
 * @see Executor
 */
public interface ObservableExecutor extends Executor {

    /**
     * Adds an observer to the set of observers for this executor.
     *
     * @param   o   an observer to be added.
     * @throws NullPointerException   if the parameter o is null.
     * @see java.util.Observable#addObserver(Observer)
     */
    void addObserver(Observer o);

    /**
     * Removes an observer from the set of observers for this executor.
     *
     * @param   o   the observer to be deleted.
     * @see java.util.Observable#deleteObserver(Observer)
     */
    void deleteObserver(Observer o);

}

