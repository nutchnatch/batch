package com.ossnms.dcn_manager.core.configuration.model;

import com.ossnms.dcn_manager.core.collections.ImmutableForwardingMap;

import java.util.Collection;
import java.util.Map;

import static java.util.function.Function.identity;
import static java.util.stream.Collectors.toMap;

/**
 * Holds an immutable map of Types, built and loaded from a number of files.
 * Types without names are ignored.
 *
 * @param <T> The actual Type.
 */

public interface Types<T extends Type> extends Map<String, T> {

    static <T extends Type> Types<T> from(Collection<T> types) {
        return from(types.stream().collect(toMap(Type::getName, identity())));
    }

    static <T extends Type> Types<T> from(Map<String, T> types) {
        return new Container<>(types);
    }
}

class Container<T extends Type> extends ImmutableForwardingMap<String, T> implements Types<T> {

    private final Map<String, T> types;

    public Container(Map<String, T> types) {
        this.types = types;
    }

    @Override
    protected Map<String, T> delegate() {
        return types;
    }

}

