package com.ossnms.dcn_manager.core.configuration.model;

import com.google.common.base.Predicate;
import com.google.common.collect.Maps;
import com.ossnms.dcn_manager.core.jaxb.mediatortype.Config;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import com.ossnms.dcn_manager.core.jaxb.type.TypeProperties;

import javax.annotation.Nonnull;
import java.util.Collection;

/**
 * Static Mediator configuration, loaded from a XML file.
 */
public class MediatorType extends Type {

    private final Config configuration;
    private final Types<ChannelType> channelTypes;

    /**
     * Creates a new object.
     * @param configuration
     * @param defaultPropertyValues All default property values known by
 *  EM/NE for this specific Mediator Type configuration.
     * @param channelTypes All default Channel Types known by
*  EM/NE. They will be filtered according to the Mediator Type configuration.
     */
    public MediatorType(
            Config configuration, @Nonnull DefaultPropertyValues defaultPropertyValues,
            @Nonnull Types<ChannelType> channelTypes) {
        super(defaultPropertyValues);
        this.channelTypes = channelTypes;
        this.configuration = configuration;
    }

    @Override
    public String getName() {
        return configuration.getName();
    }

    /**
     * @return Whether the existence of more than one mediator associated with the same host (or IP)
     * should be allowed.
     */
    public boolean allowManyOnSameHost() {
        return configuration.isAllowManyOnSameHost();
    }

    /**
     * @return Connection Manager configuration: fully qualified
     * class name of the Java class that implements the Connection
     * Manager provider, who knows how to establish a connection to
     * the mediator server.
     */
    public String getConnectionManagerProviderClass() {
        return getPropertyValue("PROVIDER_CLASS");
    }

    /**
     * @return A collection of all Channel Types supported under a
     *  Mediator of this type.
     */
    public Collection<ChannelType> getSupportedChannelTypes() {
        return Maps.filterKeys(channelTypes, new Predicate<String>() {
            @Override
            public boolean apply(@Nonnull String typeName) {
                return configuration.getSupportedChannels().getChannel().contains(typeName);
            }
        })
        .values();
    }
    
    /**
     * @return The default network icon name.
     */
    @Nonnull
    public String getDefaultIcon() {
        return configuration.getDefaultIcon().getName();
    }

    @Override
    protected TypeProperties getSupportedTypeProperties() {
        return configuration.getTypeProperties();
    }

    @Override
    protected PropertyPageFiles getSupportedPropertyFiles() {
        return new PropertyPageFiles();
    }
    
    /**
     * 
     * @return true if mediator type supports establishment of sessions in hot standby role, false otherwise.
     */
    public boolean supportsHotStandby() {
        return configuration.isSupportsHotStandby();
    }

}
