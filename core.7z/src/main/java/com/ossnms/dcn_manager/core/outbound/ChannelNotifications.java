package com.ossnms.dcn_manager.core.outbound;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.*;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent;

import javax.annotation.Nonnull;

/**
 * Describes an API for sending notifications to other components about channel deletion, creation
 * and modification.
 *
 * Because the channel entity is segregated in three facets, update notification methods are overloaded
 * with all facet types and the entity aggregate type. Notice that these overloads are not required in the
 * methods for notification of creation and deletion: these operations are only applied to the aggregate.
 */
public interface ChannelNotifications {

    /**
     * Notifies other components that a channel has been deleted.
     * @param channel The deleted channel.
     */
    void notifyDelete(ChannelEntity channel);

    /**
     * Notifies other components that a channel has been created.
     * @param channel The new channel.
     */
    void notifyCreate(ChannelEntity channel);

    /**
     * Notifies other components that some modifications have been applied to a channel's user preferences.
     * @param mutation The description of all modifications applied to the channel's user preferences.
     * @param channelType The string representation of the channel's type
     */
    void notifyChanges(ChannelUserPreferencesMutationDescriptor mutation, String channelType);

    /**
     * Notifies other components that some modifications have been applied to a channel's info data.
     * @param mutation The description of all modifications applied to the channel's  info data.
     */
    void notifyChanges(ChannelInfoMutationDescriptor mutation);

    /**
     * Notifies other components that a given channel required state has been set to activated
     *
     * @param event The instance containing the event information
     */
    void notifyChanges(RequiredChannelStateEvent.Activate event);

    /**
     * Notifies other components that a given channel required state has been set to deactivated
     *
     * @param event The instance containing the event information
     */
    void notifyChanges(RequiredChannelStateEvent.Deactivate event);

    /**
     * Notifies other components that a given channel is changing its actual state to activated
     *
     * @param event The instance containing the event information
     */
    void notifyChanges(ChannelActivatingEvent event);

    /**
     * Notifies other components that a given channel actual state has been set to activated
     *
     * @param event The instance containing the event information
     */
    void notifyChanges(ChannelActivatedEvent event);

    /**
     * Notifies other components that a given channel is changing its actual state to activated
     *
     * @param event The instance containing the event information
     */
    void notifyChanges(ChannelDeactivatingEvent event);

    /**
     * Notifies other components that a given channel actual state has been set to deactivated
     *
     * @param event The instance containing the event information
     */
    void notifyChanges(ChannelDeactivatedEvent event);

    /**
     * Notifies other components that a given channel actual state has been set to failed
     *
     * @param event The instance containing the event information
     */
    void notifyChanges(ChannelActivationFailedEvent event);

    /**
     * Notifies other components that a given channel actual state has been set to "shutting down"
     *
     * @param event The instance containing the event information
     */
    void notifyChanges(ChannelShuttingDownEvent event);

    /**
     * Notifies other components that a given channel actual state has been set to "starting up"
     *
     * @param event The instance containing the event information
     */
    void notifyChanges(ChannelStartingUpEvent event);

    /**
     * Notifies other components that a given channel actual state has been set to "creating",
     * i.e., its activation is being requested but it is not active yet. Mostly used to provide
     * feedback to the user.
     *
     * @param channelCreatingEvent The instance containing the event information
     */
    void notifyChanges(ChannelCreatingEvent channelCreatingEvent);

    /**
     * Notifies other components that a physical channel connection has been deleted.
     * @param logicalChannelId Logical channel identifier.
     * @param physicalChannelId Physical channel identifier.
     */
    void notifyDeleteInstance(int logicalChannelId, int physicalChannelId);

    /**
     * Notifies other components that a new physical channel connection has been created.
     * @param physicalConnectionData Physical channel connection information.
     */
    void notifyCreateInstance(@Nonnull ChannelPhysicalConnectionData physicalConnectionData);
}
