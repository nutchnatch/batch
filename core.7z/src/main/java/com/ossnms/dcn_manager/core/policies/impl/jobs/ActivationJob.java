package com.ossnms.dcn_manager.core.policies.impl.jobs;

import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;

import javax.annotation.Nonnull;

/**
 * Class whose instances represent jobs that trigger the first activation stage
 * of a given NE.
 */
public class ActivationJob extends NeActivationChangeJob<RequiredNeStateEvent.Activate> {

    private final NeConnectionManager connectionManager;

    public ActivationJob(@Nonnull RequiredNeStateEvent.Activate requestEvent, @Nonnull NeConnectionManager connectionManager) {
        super(requestEvent, Priority.LOW);
        this.connectionManager = connectionManager;
    }

    /** {@inheritDoc} */
    @Override
    protected void runJob() {
        connectionManager.activate(getOriginatingEvent());
    }

}