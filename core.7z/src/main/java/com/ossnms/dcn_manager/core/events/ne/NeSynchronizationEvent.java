package com.ossnms.dcn_manager.core.events.ne;

import javax.annotation.concurrent.Immutable;

/**
 * Represents the occurrence of a synchronization event against an NE.
 * Usually this means that a connected and synchronized (initialized) NE
 * is being synchronized again.
 */
@Immutable
public class NeSynchronizationEvent extends IdentifiedNeEvent {

    /**
     * Creates a new instance.
     * @param neId NE identifier.
     * @param neInstanceId Physical NE connection instance identifier.
     * @param channelId Parent Channel identifier.
     * @param mediatorId Parent Mediator identifier.
     * @param activeInstance Whether this refers to the physical NE instance that is
     * currently active (as opposed to the standby instance).
     */
    public NeSynchronizationEvent(int neId, int neInstanceId, int channelId, int mediatorId, boolean activeInstance) {
        super(neId, channelId, mediatorId, neInstanceId, activeInstance);
    }
}
