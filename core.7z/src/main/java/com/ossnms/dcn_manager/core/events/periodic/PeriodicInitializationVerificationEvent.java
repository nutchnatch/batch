package com.ossnms.dcn_manager.core.events.periodic;

/**
 * This event represents a request for verifying the occurrence of
 * NE initialization timeouts.
 */
public class PeriodicInitializationVerificationEvent extends PeriodicEvent {

}
