package com.ossnms.dcn_manager.core.policies.impl.jobs;

import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent;

import javax.annotation.Nonnull;

/** Base class for all NE jobs that affect the NE activation state. */
public abstract class NeActivationChangeJob<T extends RequiredNeStateEvent> extends NeJob<T> {

    public NeActivationChangeJob(@Nonnull T requestEvent, @Nonnull Priority priority) {
        super(requestEvent, priority);
    }

}