package com.ossnms.dcn_manager.core.events.settings;


/**
 * Describes changes to the EM/NE Native NE Naming option that should be sent
 * to other components.
 */
public class NativeNeNamingSettingChangeEvent extends GlobalSettingsEvent {

    private final boolean showNativeNeNamingNaming;

    /**
     * Creates a new object.
     * @param changes Mutation descriptor that contains all changes applied to the
     *  settings.
     */
    public NativeNeNamingSettingChangeEvent(boolean showNativeNeNaming) {
        this.showNativeNeNamingNaming = showNativeNeNaming;
    }

    /**
     * @return To which value the native naming display option was changed.
     */
    public boolean getShowNativeNeNaming() {
        return showNativeNeNamingNaming;
    }

}
