package com.ossnms.dcn_manager.core.events.ne;

import javax.annotation.Nonnull;
import java.util.Optional;

public class NeConnectionDescriptionChangedEvent extends NeEvent {

    private Optional<String> targetDescription = Optional.empty();
    private Optional<String> routeDescription = Optional.empty();

    public NeConnectionDescriptionChangedEvent(int neId) {
        super(neId);
    }

    public NeConnectionDescriptionChangedEvent(int neId, String detailedDescription) {
        super(neId, detailedDescription);
    }

    /**
     * @return Connection target description.
     * @see com.ossnms.dcn_manager.core.properties.ne.NeProperty#DISPLAY_ADDRESS
     */
    public Optional<String> getTargetDescription() {
        return targetDescription;
    }

    /**
     * @param targetDescription New connection target description.
     */
    public NeConnectionDescriptionChangedEvent setTargetDescription(@Nonnull Optional<String> targetDescription) {
        this.targetDescription = targetDescription;
        return this;
    }

    /**
     * @return Connection route description.
     */
    public Optional<String> getRouteDescription() {
        return routeDescription;
    }

    /**
     * @param routeDescription New connection route description.
     */
    public NeConnectionDescriptionChangedEvent setRouteDescription(@Nonnull Optional<String> routeDescription) {
        this.routeDescription = routeDescription;
        return this;
    }

}
