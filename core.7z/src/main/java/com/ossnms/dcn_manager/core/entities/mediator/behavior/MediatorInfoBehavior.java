package com.ossnms.dcn_manager.core.entities.mediator.behavior;

import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * <p>Class that implements the behavior dimension of the domain object that describes the persisted
 * mediator state or, in other words, the mediators' information and required activation state. This means
 * that the application must ensure that the actual mediator state converges to the required one. </p>
 *
 * <p>The implementation is based on the State Machine design pattern to deal with required activation
 * state transitions. The state machine is depicted in the following figure. Notice that the
 * representation of start and end states is merely illustrative of the expected flow: mediators
 * are originally created in the deactivated state, that is, activation not required. State transitions
 * are triggered by the depicted domain object operations. </p>
 *
 * <p><figure>
 * <img src="doc-files/mediatorInfo_required_activation_state-state.png">
 * <figcaption>State diagram of the required activation state state machine</figcaption>
 * </figure></p>
 *
 * <p> The state machine is materialized in the following class hierarchy, only relevant to the domain
 * object implementation. For this reason the hierarchy is implemented as a set of static nested
 * classes not accessible from the outside. This solution has the merit of reducing overall
 * complexity (i.e. reducing the number of top-level classes) at the expense of increasing
 * file level complexity (i.e. its size). Nevertheless, and considering the actual file size, the
 * tradeoff is positive. In the case that the current file size increases, this approach must be
 * reevaluated. </p>
 *
 * <p> <figure>
 * <img src="doc-files/mediatorlInfo_required_activation_state-class.png">
 * <figcaption>Class diagram of the required activation state hierarchy</figcaption>
 * </figure> </p>
 *
 * <ul> Design decisions:
 * <li> Each state transition is materialized in an independent method,
 * to be overridden in concrete state classes; </li>
 * <li> Invalid transitions are signaled by producing an absent {@link Optional} instance,
 * instead of throwing an exception. Note that the exact reaction to an invalid
 * transition depends on the specific use case, and therefore throwing an exception
 * would be inappropriate; </li>
 * <li> Transitions are not applied on the on the domain object instance, due to its
 * immutable nature. Instead, state transitions produce a description of the resulting
 * mutation, which will be later applied on the repository. </li>
 * </ul>
 *
 * <p> As all types that implement domain objects' behavior dimension, this class instances are
 * not thread-safe, and therefore cannot be shared by multiple threads without explicit synchronization.
 * </p>
 */
/*
 * @startuml doc-files/mediatorInfo_required_activation_state-state.png
 * [*] --> Deactivated
 * Activated --> Deactivated : deactivationRequired
 * Deactivated --> Activated : activationRequired
 * @enduml
 */
/*
 * @startuml doc-files/mediatorInfo_required_activation_state-class.png
 * class RequiredActivation <<abstract>> {
 *      # activationRequired() : Optional<MediatorStateMutationDescriptor>
 *      # deactivationRequired() : Optional<MediatorStateMutationDescriptor>
 * }
 * RequiredActivation<|-- Activated
 * RequiredActivation<|-- Deactivated
 * hide fields
 * @enduml
 */
public class MediatorInfoBehavior {

    private final MediatorInfoData infoData;

    /**
     * Creates a new behavior object for manipulating a target instance of data.
     * @param infoData Target data instance.
     */
    public MediatorInfoBehavior(@Nonnull MediatorInfoData infoData) {
        this.infoData = infoData;
    }

    /**
     * Signals that activation is being requested on a mediator.
     * Once applied, the mutation returned will schedule the actual activation
     * for asynchronous execution.
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @param mediatorInstance Mediator instances upon which the required state must be enforced.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorInfoMutationDescriptor> activationRequired(
            @Nonnull MediatorNotifications notifications, int mediatorInstance) {
        return behaviorForActivation().activationRequired(notifications, mediatorInstance);
    }

    /**
     * Signals that deactivation is being requested on a mediator.
     * Once applied, the mutation returned will schedule the actual deactivation
     * for asynchronous execution.
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @param mediatorInstances Mediator instance upon which the required state must be enforced.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorInfoMutationDescriptor> deactivationRequired(
            @Nonnull MediatorNotifications notifications, @Nonnull Iterable<Integer> mediatorInstances) {
        return behaviorForActivation().deactivationRequired(notifications, mediatorInstances);
    }

    private RequiredActivation behaviorForActivation() {
        return infoData.isActivationRequired() ? new Activated() : new Deactivated();
    }

    private abstract class RequiredActivation {

        protected Optional<MediatorInfoMutationDescriptor> activationRequired(
                @Nonnull MediatorNotifications notifications, int mediatorInstance) {
            return Optional.empty();
        }

        protected Optional<MediatorInfoMutationDescriptor> deactivationRequired(
                @Nonnull MediatorNotifications notifications, @Nonnull Iterable<Integer> mediatorInstances) {
            return Optional.empty();
        }

    }

    private final class Activated extends RequiredActivation {

        @Override
        protected Optional<MediatorInfoMutationDescriptor> deactivationRequired(
                @Nonnull MediatorNotifications notifications, @Nonnull Iterable<Integer> mediatorInstances) {
            return Optional.of(new MediatorInfoMutationDescriptor(infoData)
                .setActivationRequired(false)
                .whenApplied(in -> {
                        final DeactivateMediatorEvent event = new DeactivateMediatorEvent(in.getResult().getId(), mediatorInstances);
                        notifications.notifyChanges(event);
                }));
        }

    }

    private final class Deactivated extends RequiredActivation {

        @Override
        protected Optional<MediatorInfoMutationDescriptor> activationRequired(
                @Nonnull MediatorNotifications notifications, int mediatorInstance) {
            return Optional.of(new MediatorInfoMutationDescriptor(infoData)
                .setActivationRequired(true)
                .whenApplied(in -> {
                        final ActivateMediatorEvent event = new ActivateMediatorEvent(in.getResult().getId(), mediatorInstance);
                        notifications.notifyChanges(event);
                }));
        }

    }
}
