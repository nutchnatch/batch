package com.ossnms.dcn_manager.core.entities.mediator.behavior;

import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.utils.Consumer;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * <p>Class that implements the behavior dimension of the domain object that describes the volatile true
 * mediator activation state or, in other words, the solution's connectivity to the given mediator. This means
 * that the application must ensure that the actual mediator activation state converges to the required one.</p>
 *
 * <p>The implementation is based on the State Machine design pattern to deal with actual activation
 * state transitions. The state machine is depicted in the following figure.
 * All transitions are delegated to {@link ActualActivation}. </p>
 *
 * <p><figure>
 * <img src="doc-files/mediatorConnection_actual_activation_state-state.png">
 * <figcaption>State diagram of the actual activation state state machine</figcaption>
 * </figure></p>
 *
 * <p>Note that transitions are not applied on the on the domain object instance, due to its
 * immutable nature. Instead, state transitions produce a description of the resulting
 * mutation, which will be later applied on the repository. </p>
 *
 * <p> The state machine is materialized in the following class hierarchy, only relevant to the domain
 * object implementation. For this reason the hierarchy is implemented as a set of static nested
 * classes not accessible from the outside. This solution has the merit of reducing overall
 * complexity (i.e. reducing the number of top-level classes) at the expense of increasing
 * file level complexity (i.e. its size). Nevertheless, and considering the actual file size, the
 * tradeoff is positive. In the case that the current file size increases, this approach must be
 * reevaluated. </p>
 *
 * <p> <figure>
 * <img src="doc-files/mediatorConnection_actual_activation_state-class.png">
 * <figcaption>Class diagram of the actual activation state hierarchy</figcaption>
 * </figure> </p>
 *
 * <p> As all types that implement domain objects' behavior dimension, this class instances are
 * not thread-safe, and therefore cannot be shared by multiple threads without explicit synchronization.
 * </p>
 *
 * @see ActualActivationState
 */
/*
 * @startuml doc-files/mediatorConnection_actual_activation_state-state.png
 * [*] --> Inactive
 * Inactive --> Activating : activating
 * Activating --> Active : activated
 * Active --> Deactivating : deactivating
 * Deactivating --> Inactive : deactivated
 * Activating --> Failed : failed
 * Active --> Failed : failed
 * Deactivating --> Failed : failed
 * Inactive --> Failed : failed
 * Failed --> Activating : activating
 * Failed --> Failed : failed
 * @enduml
 */
/*
 * @startuml doc-files/mediatorConnection_actual_activation_state-class.png
 * class ActualActivation <<abstract>> {
 *      # activated() : Optional<MediatorConnectionMutationDescriptor>
 *      # deactivated() : Optional<MediatorConnectionMutationDescriptor>
 *      # activating() : Optional<MediatorConnectionMutationDescriptor>
 *      # deactivating() : Optional<MediatorConnectionMutationDescriptor>
 *      # failed() : Optional<MediatorConnectionMutationDescriptor>
 * }
 * ActualActivation<|-- Active
 * ActualActivation<|-- Inactive
 * ActualActivation<|-- Activating
 * ActualActivation<|-- Deactivating
 * ActualActivation<|-- Failed
 * hide fields
 * @enduml
 */
public class MediatorConnectionBehavior {

    private final MediatorConnectionData connectionData;

    /**
     * Creates a new behavior object for manipulating a target instance of data.
     *
     * @param connectionData Target data instance.
     */
    public MediatorConnectionBehavior(@Nonnull MediatorConnectionData connectionData) {
        this.connectionData = connectionData;
    }

    /**
     * Signals a mediator as having started the activation process.
     *
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorConnectionMutationDescriptor> setActivating(@Nonnull MediatorNotifications notifications) {
        return behaviorForState().activating(notifications);
    }

    /**
     * Signals a mediator as having been successfully activated.
     *
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorConnectionMutationDescriptor> setActive(@Nonnull MediatorNotifications notifications) {
        return behaviorForState().activated(notifications);
    }

    /**
     * Signals a mediator as having started the deactivation process.
     *
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorConnectionMutationDescriptor> setDeactivating(@Nonnull MediatorNotifications notifications) {
        return behaviorForState().deactivating(notifications);
    }

    /**
     * Signals a mediator as having been successfully deactivated.
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorConnectionMutationDescriptor> setInactive(@Nonnull MediatorNotifications notifications) {
        return behaviorForState().deactivated(notifications);
    }

    /**
     * Signals that activation of a mediator has failed.
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @param description Human readable failure description. Will be eventually forwarded to the operator.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorConnectionMutationDescriptor> setFailed(
            @Nonnull MediatorNotifications notifications, @Nonnull String description) {
        return behaviorForState().failed(notifications, description);
    }

    private ActualActivation behaviorForState() {
        switch (connectionData.getActualActivationState()) {
        case ACTIVATING:
            return new Activating();
        case ACTIVE:
            return new Active();
        case DEACTIVATING:
            return new Deactivating();
        case INACTIVE:
            return new Inactive();
        case FAILED:
            return new Failed();
        default:
            throw new UnsupportedOperationException();
        }
    }

    private abstract class ActualActivation {

        protected Optional<MediatorConnectionMutationDescriptor> activating(@Nonnull MediatorNotifications notifications) {
            return Optional.empty();
        }

        protected Optional<MediatorConnectionMutationDescriptor> activated(@Nonnull MediatorNotifications notifications) {
            return Optional.empty();
        }

        protected Optional<MediatorConnectionMutationDescriptor> deactivating(@Nonnull MediatorNotifications notifications) {
            return Optional.empty();
        }

        protected Optional<MediatorConnectionMutationDescriptor> deactivated(@Nonnull MediatorNotifications notifications) {
            return Optional.empty();
        }

        protected Optional<MediatorConnectionMutationDescriptor> failed(
                @Nonnull MediatorNotifications notifications, @Nonnull String description) {
            return Optional.empty();
        }

    }

    private abstract class FailingActivationState extends ActualActivation {

        @Override
        protected Optional<MediatorConnectionMutationDescriptor> failed(
                @Nonnull final MediatorNotifications notifications, @Nonnull String description) {
            return Optional.of(new MediatorConnectionMutationDescriptor(connectionData)
                .setActive(ActualActivationState.FAILED)
                .setAdditionalInfo(description)
                .whenApplied(new Consumer<MediatorConnectionMutationDescriptor>() {
                    @Override
                    public void accept(MediatorConnectionMutationDescriptor in) {
                        final MediatorConnectionData result = in.getResult();
                        final MediatorActivationFailedEvent event =
                                new MediatorActivationFailedEvent(result.getId(), result.getAdditionalInfo());
                        notifications.notifyChanges(event);
                    }
                })
            );
        }

    }

    private abstract class CancellableState extends FailingActivationState {
        @Override
        protected Optional<MediatorConnectionMutationDescriptor> deactivating(@Nonnull final MediatorNotifications notifications) {
            return Optional.of(new MediatorConnectionMutationDescriptor(connectionData)
                .setActive(ActualActivationState.DEACTIVATING)
                .setAdditionalInfo("")
                .whenApplied(new Consumer<MediatorConnectionMutationDescriptor>() {
                    @Override
                    public void accept(MediatorConnectionMutationDescriptor in) {
                        notifications.notifyChanges(new MediatorDeactivatingEvent(in.getResult().getId()));
                    }
                })
            );
        }
        
    }
    
    private abstract class RestartableState extends CancellableState {

        @Override
        protected Optional<MediatorConnectionMutationDescriptor> activating(@Nonnull final MediatorNotifications notifications) {
            return Optional.of(new MediatorConnectionMutationDescriptor(connectionData)
                .setActive(ActualActivationState.ACTIVATING)
                .setAdditionalInfo("")
                .whenApplied(new Consumer<MediatorConnectionMutationDescriptor>() {
                    @Override
                    public void accept(MediatorConnectionMutationDescriptor in) {
                        notifications.notifyChanges(new MediatorActivatingEvent(in.getResult().getId()));
                    }
                })
            );
        }

    }

    private final class Activating extends CancellableState {

        @Override
        protected Optional<MediatorConnectionMutationDescriptor> activated(@Nonnull final MediatorNotifications notifications) {
            return Optional.of(new MediatorConnectionMutationDescriptor(connectionData)
                .setActive(ActualActivationState.ACTIVE)
                .setAdditionalInfo("")
                .whenApplied(new Consumer<MediatorConnectionMutationDescriptor>() {
                    @Override
                    public void accept(MediatorConnectionMutationDescriptor in) {
                        final MediatorActivatedEvent event = new MediatorActivatedEvent(in.getResult().getId());
                        notifications.notifyChanges(event);
                    }
                })
            );
        }        
    }

    private final class Active extends CancellableState {
        // all relevant interactions are supported by ancestors.
    }

    private final class Deactivating extends FailingActivationState {

        @Override
        protected Optional<MediatorConnectionMutationDescriptor> deactivated(@Nonnull final MediatorNotifications notifications) {
            return Optional.of(new MediatorConnectionMutationDescriptor(connectionData)
                .setActive(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .whenApplied(new Consumer<MediatorConnectionMutationDescriptor>() {
                    @Override
                    public void accept(MediatorConnectionMutationDescriptor in) {
                        final MediatorDeactivatedEvent event = new MediatorDeactivatedEvent(in.getResult().getId());
                        notifications.notifyChanges(event);
                    }
                })
            );
        }

    }

    private class Inactive extends FailingActivationState {
        @Override
        protected Optional<MediatorConnectionMutationDescriptor> activating(@Nonnull final MediatorNotifications notifications) {
            return Optional.of(new MediatorConnectionMutationDescriptor(connectionData)
                .setActive(ActualActivationState.ACTIVATING)
                .setAdditionalInfo("")
                .whenApplied(new Consumer<MediatorConnectionMutationDescriptor>() {
                    @Override
                    public void accept(MediatorConnectionMutationDescriptor in) {
                        notifications.notifyChanges(new MediatorActivatingEvent(in.getResult().getId()));
                    }
                })
            );
        }
    }

    private final class Failed extends RestartableState {

        @Override
        protected Optional<MediatorConnectionMutationDescriptor> deactivated(@Nonnull final MediatorNotifications notifications) {
            return Optional.of(new MediatorConnectionMutationDescriptor(connectionData)
                .setActive(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .whenApplied(new Consumer<MediatorConnectionMutationDescriptor>() {
                    @Override
                    public void accept(MediatorConnectionMutationDescriptor in) {
                        final MediatorDeactivatedEvent event = new MediatorDeactivatedEvent(in.getResult().getId());
                        notifications.notifyChanges(event);
                    }
                })
            );
        }

    }
}
