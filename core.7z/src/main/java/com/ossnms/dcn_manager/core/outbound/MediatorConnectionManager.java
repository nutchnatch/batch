package com.ossnms.dcn_manager.core.outbound;

import java.util.Map;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;

/**
 * Manages the Mediator connections..
 *
 * TODO: Review...
 */
public interface MediatorConnectionManager {

    /**
     * Connects the mediator.
     *
     * @param physicalMediatorInstanceId
     */
    void connect(int physicalMediatorInstanceId);

    /**
     * Disconnects the mediator.
     *
     * @param context
     * @param physicalMediatorInstanceId
     */
    void disconnect(int physicalMediatorInstanceId);

    /**
     * Sends a set of changed property values to the mediator.
     *
     * @param physicalMediatorInstanceId Mediator instance identifier.
     * @param properties A map of properties to send.
     * @throws ConnectException Should an error occur while communicating with the mediator.
     * or south-bound components.
     */
    void updateMediatorProperties(int physicalMediatorInstanceId, @Nonnull Map<String, String> properties)  throws ConnectException;

}
