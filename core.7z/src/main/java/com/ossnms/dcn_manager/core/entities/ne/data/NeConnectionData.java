package com.ossnms.dcn_manager.core.entities.ne.data;

import com.mysema.query.annotations.QueryEntity;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Optional;


/**
 * Volatile NE connection state.
 */
@QueryEntity
public final class NeConnectionData extends BusinessObjectData {

    private final ActualActivationState activationState;
    private final Optional<String> connectedVia;
    private final Optional<String> additionalInfo;

    public NeConnectionData(int neId, int version, NeConnectionPrototype<?> initialData) {
        super(neId, version);
        this.connectedVia = initialData.connectedVia;
        this.additionalInfo = initialData.additionalInfo;
        this.activationState = initialData.activationState;
    }

    /**
     * @return The text that describes the currently connected route.
     */
    public Optional<String> getConnectedVia() {
        return connectedVia;
    }

    /**
     * @return Human readable additional state information.
     */
    public Optional<String> getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * @return Actual NE activation state.
     */
    public ActualActivationState getActivationState() {
        return activationState;
    }

    /**
     * @return Whether there is a valid connection to this NE.
     */
    public boolean isConnected() {
        return ActualActivationState.CONNECTED == activationState ||
               ActualActivationState.INITIALIZING == activationState ||
               ActualActivationState.INITIALIZED == activationState;
    }

    /**
     * @return Whether the NE is in an active, i.e., fully initialized.
     */
    public boolean isActive() {
        return ActualActivationState.INITIALIZED == activationState;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("activationState", activationState)
                .append("connectedVia", connectedVia)
                .append("additionalInfo", additionalInfo)
                .toString();
    }

    public static final class NeConnectionBuilder extends NeConnectionPrototype<NeConnectionBuilder> {

        /**
         * Creates a new instance of {@link NeConnectionData} with information
         * extracted from the current attribute values.
         *
         * @return A new instance of {@link NeConnectionData}.
         */
        public NeConnectionData build(int neId, int version) {
            return new NeConnectionData(neId, version, this);
        }

        @Override
        protected NeConnectionBuilder self() {
            return this;
        }

    }

    public static final class NeConnectionInitialData extends NeConnectionPrototype<NeConnectionInitialData> {

        @Override
        protected NeConnectionInitialData self() {
            return this;
        }

    }

    /**
     * Builder/prototype class. Used to help building instances of {@link NeConnectionData}.
     */
    private abstract static class NeConnectionPrototype<T extends NeConnectionPrototype<T>> {

        private ActualActivationState activationState = ActualActivationState.DISCONNECTED;
        private Optional<String> connectedVia = Optional.empty();
        private Optional<String> additionalInfo = Optional.empty();

        protected NeConnectionPrototype() {

        }

        protected abstract T self();

        /**
         * @param activationState New NE activation state.
         */
        public T setActivationState(ActualActivationState activationState) {
            this.activationState = activationState;
            return self();
        }

        /**
         * @param connectedVia New text that describes the currently connected route.
         */
        public T setConnectedVia(Optional<String> connectedVia) {
            this.connectedVia = connectedVia;
            return self();
        }

        /**
         * @param additionalInfo New human readable state information string.
         */
        public T setAdditionalInfo(Optional<String> additionalInfo) {
            this.additionalInfo = additionalInfo;
            return self();
        }
    }

}
