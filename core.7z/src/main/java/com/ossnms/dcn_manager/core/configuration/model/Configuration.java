package com.ossnms.dcn_manager.core.configuration.model;

public class Configuration implements StaticConfiguration {

    private final Types<NeType> neTypes;
    private final Types<ChannelType> channelTypes;
    private final Types<MediatorType> mediatorTypes;
    private final DefaultPropertyValues defaultPropertyValues;
    private final PasswordPropertyMetadata passwordPropertyMetadata;

    public Configuration(Types<NeType> neTypes, 
                         Types<ChannelType> channelTypes,
                         Types<MediatorType> mediatorTypes, 
                         DefaultPropertyValues defaultPropertyValues, 
                         PasswordPropertyMetadata passwordPropertyMetadata) {
        this.neTypes = neTypes;
        this.channelTypes = channelTypes;
        this.mediatorTypes = mediatorTypes;
        this.defaultPropertyValues = defaultPropertyValues;
        this.passwordPropertyMetadata = passwordPropertyMetadata;
    }

    @Override public Types<NeType> getNeTypes() {
        return neTypes;
    }

    @Override public Types<ChannelType> getChannelTypes() {
        return channelTypes;
    }

    @Override public Types<MediatorType> getMediatorTypes() {
        return mediatorTypes;
    }

    @Override public DefaultPropertyValues getDefaultPropertyValues() {
        return defaultPropertyValues;
    }

    @Override public PasswordPropertyMetadata getPasswordPropertyMetadata() {
        return passwordPropertyMetadata;
    }
}
