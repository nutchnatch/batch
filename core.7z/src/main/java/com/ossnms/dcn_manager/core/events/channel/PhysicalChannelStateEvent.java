package com.ossnms.dcn_manager.core.events.channel;

import java.util.Objects;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>Used to signal physical channel activation state changes against a specific mediator server.
 * Derived classes represent specific channel activation events. This class follows closely the implementation
 * of {@link ActualChannelStateEvent} because the logical state mirrors the physical state (or a combination
 * thereof, depending on the strategy).</p>
 *
 * @see ActualChannelStateEvent
 */
@Immutable
public abstract class PhysicalChannelStateEvent extends ChannelEvent {

    private final int logicalChannelId;
    private final boolean instanceActive;

    /**
     * Initiates an instance with the given arguments.
     * @param channelId The affected channel identifier.
     * @param logicalChannelId The affected logical channel identifier.
     * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
     * standby instance).
     */
    protected PhysicalChannelStateEvent(int channelId, int logicalChannelId, boolean instanceActive) {
        super(channelId);
        this.logicalChannelId = logicalChannelId;
        this.instanceActive = instanceActive;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param channelId The affected channel ID.
     * @param logicalChannelId The affected logical channel identifier.
     * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
     * standby instance).
     * @param detailedDescription Human-readable event description.
     */
    protected PhysicalChannelStateEvent(int channelId, int logicalChannelId, boolean instanceActive, @Nonnull String detailedDescription) {
        super(channelId, detailedDescription);
        this.logicalChannelId = logicalChannelId;
        this.instanceActive = instanceActive;
    }

    /**
     * @return The affected logical channel identifier.
     */
    public int getLogicalChannelId() {
        return logicalChannelId;
    }

    /**
     * @return Whether this refers to the physical mediator server instance that is currently active (as opposed to the
     * standby instance).
     */
    public boolean isInstanceActive() {
        return instanceActive;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getChannelId(), getDetailedDescription(), logicalChannelId, instanceActive);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final PhysicalChannelStateEvent rhs = (PhysicalChannelStateEvent) obj;
        return new EqualsBuilder()
                .append(getChannelId(), rhs.getChannelId())
                .append(getDetailedDescription(), rhs.getDetailedDescription())
                .append(logicalChannelId, rhs.logicalChannelId)
                .append(instanceActive, rhs.instanceActive)
                .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("logicalChannelId", logicalChannelId)
                .append("instanceActive", instanceActive)
                .toString();
    }

    /**
     * Class whose instances represent events used to signal that an attempt at creating the channel
     * is underway.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalChannelCreatingEvent extends PhysicalChannelStateEvent {

        public PhysicalChannelCreatingEvent(int channelId, int logicalChannelId, boolean instanceActive) {
            super(channelId, logicalChannelId, instanceActive);
        }

        public PhysicalChannelCreatingEvent(int channelId, int logicalChannelId, boolean instanceActive, @Nonnull String detailedDescription) {
            super(channelId, logicalChannelId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel has been created.
     * A created channel is an active channel.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalChannelCreatedEvent extends PhysicalChannelStateEvent {

        public PhysicalChannelCreatedEvent(int channelId, int logicalChannelId, boolean instanceActive) {
            super(channelId, logicalChannelId, instanceActive);
        }

        public PhysicalChannelCreatedEvent(int channelId, int logicalChannelId, boolean instanceActive, @Nonnull String detailedDescription) {
            super(channelId, logicalChannelId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel activation has been initiated.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalChannelActivatingEvent extends PhysicalChannelStateEvent {

        public PhysicalChannelActivatingEvent(int channelId, int logicalChannelId, boolean instanceActive) {
            super(channelId, logicalChannelId, instanceActive);
        }

        public PhysicalChannelActivatingEvent(int channelId, int logicalChannelId, boolean instanceActive, @Nonnull String detailedDescription) {
            super(channelId, logicalChannelId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel activation has succeeded.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalChannelActivatedEvent extends PhysicalChannelStateEvent {

        public PhysicalChannelActivatedEvent(int channelId, int logicalChannelId, boolean instanceActive) {
            super(channelId, logicalChannelId, instanceActive);
        }

        public PhysicalChannelActivatedEvent(int channelId, int logicalChannelId, boolean instanceActive, @Nonnull String detailedDescription) {
            super(channelId, logicalChannelId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel activation has failed.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalChannelActivationFailedEvent extends PhysicalChannelStateEvent {

        public PhysicalChannelActivationFailedEvent(int channelId, int logicalChannelId, boolean instanceActive) {
            super(channelId, logicalChannelId, instanceActive);
        }

        public PhysicalChannelActivationFailedEvent(int channelId, int logicalChannelId, boolean instanceActive, @Nonnull String detailedDescription) {
            super(channelId, logicalChannelId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel deactivation was completed.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalChannelDeactivatedEvent extends PhysicalChannelStateEvent {

        public PhysicalChannelDeactivatedEvent(int channelId, int logicalChannelId, boolean instanceActive) {
            super(channelId, logicalChannelId, instanceActive);
        }

        public PhysicalChannelDeactivatedEvent(int channelId, int logicalChannelId, boolean instanceActive, @Nonnull String detailedDescription) {
            super(channelId, logicalChannelId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel deactivation has been initiated.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalChannelDeactivatingEvent extends PhysicalChannelStateEvent {

        public PhysicalChannelDeactivatingEvent(int channelId, int logicalChannelId, boolean instanceActive) {
            super(channelId, logicalChannelId, instanceActive);
        }

        public PhysicalChannelDeactivatingEvent(int channelId, int logicalChannelId, boolean instanceActive, @Nonnull String detailedDescription) {
            super(channelId, logicalChannelId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel activation has been scheduled.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalChannelStartingUpEvent extends PhysicalChannelStateEvent {

        public PhysicalChannelStartingUpEvent(int channelId, int logicalChannelId, boolean instanceActive) {
            super(channelId, logicalChannelId, instanceActive);
        }

        public PhysicalChannelStartingUpEvent(int channelId, int logicalChannelId, boolean instanceActive, @Nonnull String detailedDescription) {
            super(channelId, logicalChannelId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel deactivation has been scheduled.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalChannelShuttingDownEvent extends PhysicalChannelStateEvent {

        public PhysicalChannelShuttingDownEvent(int channelId, int logicalChannelId, boolean instanceActive) {
            super(channelId, logicalChannelId, instanceActive);
        }

        public PhysicalChannelShuttingDownEvent(int channelId, int logicalChannelId, boolean instanceActive, @Nonnull String detailedDescription) {
            super(channelId, logicalChannelId, instanceActive, detailedDescription);
        }
    }
}
