package com.ossnms.dcn_manager.core.events.container;

import com.ossnms.dcn_manager.core.events.EntityEvent;

/**
 * Base class for events that affect a container.
 */
public abstract class ContainerEvent extends EntityEvent {

    /**
     * Creates a new object.
     * @param containerId The affected container ID.
     */
    ContainerEvent(int containerId) {
        super(containerId);
    }
}
