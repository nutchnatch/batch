package com.ossnms.dcn_manager.core.events.ne;

import javax.annotation.Nonnull;

/**
 * Fired by mediators when the target network element type is misconfigured.
 */
public class NeTypeChangedEvent extends NeEvent {

    private final String newNeTypeName;

    /**
     * Creates a new object.
     * @param neId The affected NE identifier.
     * @param newNeTypeName The name of the new NE type for this NE.
     */
    public NeTypeChangedEvent(int neId, @Nonnull String newNeTypeName) {
        super(neId);
        this.newNeTypeName = newNeTypeName;
    }

    /**
     * @return The name of the new NE type.
     */
    public String getNewNeTypeName() {
        return newNeTypeName;
    }

}
