package com.ossnms.dcn_manager.core.events.ne;

import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;

import java.util.Optional;

/**
 * Event that contains all Gateway Routes of a NE.
 */
public class NeGatewayRoutesChangedEvent extends NeEvent {

    private Optional<Iterable<NeGatewayRouteData>> gatewayRoutes = Optional.empty();

    public NeGatewayRoutesChangedEvent(int neId) {
        super(neId);
    }

    public NeGatewayRoutesChangedEvent(int neId, String detailedDescription) {
        super(neId, detailedDescription);
    }

    /**
     * Empty Set represents: All routes for that NE was unconfigured.
     * Empty Optional represents: No changes on Routes for that NE.
     */
    public Optional<Iterable<NeGatewayRouteData>> getGatewayRoutes() {
        return gatewayRoutes;
    }

    public NeGatewayRoutesChangedEvent setGatewayRoutes(Optional<Iterable<NeGatewayRouteData>> gatewayRoutes) {
        this.gatewayRoutes = gatewayRoutes;
        return this;
    }
}
