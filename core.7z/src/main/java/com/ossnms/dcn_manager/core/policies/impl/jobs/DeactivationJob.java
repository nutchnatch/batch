package com.ossnms.dcn_manager.core.policies.impl.jobs;

import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;

import javax.annotation.Nonnull;

/** Class whose instances represent jobs that trigger the activation of a given NE. */
public class DeactivationJob extends NeActivationChangeJob<RequiredNeStateEvent.Deactivate> {

    private final NeConnectionManager connectionManager;

    public DeactivationJob(@Nonnull RequiredNeStateEvent.Deactivate requestEvent, @Nonnull NeConnectionManager connectionManager) {
        super(requestEvent, Priority.HIGH);
        this.connectionManager = connectionManager;
    }

    /** {@inheritDoc} */
    @Override
    protected void runJob() {
        connectionManager.deactivate(getOriginatingEvent());
    }

}