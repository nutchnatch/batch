/**
 * <p>Contains companion objects that know how to access unstructured
 * data within Mediator Entities. Also know how to transform these entities
 * into unstructured data blocks and back.</p>
 *
 * <p>These unstructured data blocks are known as properties, and only
 * supported properties will be interpreted. All others will be
 * treated as-is.</p>
 *
 * <p><img src="doc-files/package-dependencies.png"/></p>
 */
/*
 * @startuml doc-files/package-dependencies.png
 * title Birds'-eye view of dependencies
 * class MediatorProperties
 * class MediatorProperty
 * class MediatorType
 * class MediatorEntity
 * class MediatorEntityMutationDescriptor
 * MediatorType <.. MediatorProperties
 * MediatorEntity <.. MediatorProperties
 * MediatorEntityMutationDescriptor <.. MediatorProperties
 * MediatorProperty <.. MediatorProperties
 * @enduml
 */
package com.ossnms.dcn_manager.core.properties.mediator;
