package com.ossnms.dcn_manager.core.entities.channel.behavior;

import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelStartingUpEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelStartingUpEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectedEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * <p>Class that implements the behavior dimension of the domain object that describes the volatile true
 * channel activation state or, in other words, the solution's connectivity to the given channel. This means
 * that the application must ensure that the actual channel activation state converges to the required one.</p>
 *
 * <p>The implementation is based on the State Machine design pattern to deal with actual activation
 * state transitions.</p>
 *
 * <p> Note that transitions are not applied on the on the domain object instance, due to its
 * immutable nature. Instead, state transitions produce a description of the resulting
 * mutation, which will be later applied on the repository. </p>
 *
 * <p> As all types that implement domain objects' behavior dimension, this class instances are
 * not thread-safe, and therefore cannot be shared by multiple threads without explicit synchronization.
 * </p>
 *
 * <p>The behavior implementation is materialized in the {@code ActualActivationEvents} class
 * and is based on the State Machine design pattern to deal with actual activation state
 * transitions. One instance of {@code ActualActivationEvents} must be created for each
 * instance of {@link com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData} that will serve
 * as the base for changing the actual channel activation state. This instance is created through a factory method,
 * {@code ChannelConnectionBehavior#eventHandlerFor(ChannelConnectionState)}.
 * The state machine is depicted in the following figure. State transitions are triggered by
 * firing the depicted events. </p>
 *
 * <p><figure>
 * <img src="doc-files/actual_activation_state-state.png">
 * <figcaption>State diagram of the actual activation state state machine</figcaption>
 * </figure></p>
 *
 * <p> The state machine is materialized in the following class hierarchy, only relevant to the domain
 * object implementation. For this reason the hierarchy is implemented within the state behavior
 * object as a set of static nested classes not accessible from the outside. This solution has the merit
 * of reducing overall complexity (i.e. reducing the number of top-level classes) at the expense of increasing
 * file level complexity (i.e. its size). Nevertheless, and considering the actual file size, the
 * tradeoff is positive. In the case that the current file size increases, this approach must be
 * reevaluated. </p>
 *
 * <p> <figure>
 * <img src="doc-files/actual_activation_state-class.png">
 * <figcaption>Class diagram of the actual activation state hierarchy</figcaption>
 * </figure> </p>
 *
 * <ul> Design decisions:
 * <li> Each state transition is materialized in an independent method,
 * to be overridden in concrete state classes; </li>
 * <li> Invalid transitions are signaled by producing an absent {@link Optional} instance,
 * instead of throwing an exception. Note that the exact reaction to an invalid
 * transition depends on the specific use case, and therefore throwing an exception
 * would be inappropriate; </li>
 * <li> Transitions are not applied on the on the domain object instance, due to its
 * immutable nature. Instead, state transitions produce a description of the resulting
 * mutation, which will be later applied on the repository. </li>
 * </ul>
 * @see ActualActivationState
 */
/*
 * @startuml doc-files/actual_activation_state-state.png
 * [*] -r-> Inactive
 * Inactive --> StartingUp : startUp
 * Inactive --> Failed : failed
 * StartingUp --> Inactive : shutdown
 * StartingUp --> Failed : failed
 * Active --> Shutdown : shutdown
 * Active --> Failed : failed
 * state ExternalActivating {
 * Creating --> Active : created
 * Creating --> Failed : failed
 * Creating --> Shutdown : shutdown
 * Activating --> Active : activated
 * Activating --> Failed : failed
 * Activating --> Shutdown : shutdown
 * }
 * state "Advertised as Activating" as ExternalActivating
 * StartingUp --> Creating : creating
 * Shutdown -> Deactivating : deactivating
 * Shutdown --> Failed : failed
 * Deactivating --> Inactive : deactivated
 * Deactivating --> Failed : failed
 * Failed --> StartingUp : startUp
 * Failed --> Shutdown : shutdown
 * Failed --> Activating : activating
 * Failed --> Failed : failed
 * @enduml
 */
/*
 * @startuml doc-files/actual_activation_state-class.png
 * class ActualPhysicalActivationEvents <<abstract>> {
 *   activated() : Optional<ChannelConnectionMutationDescriptor>
 *   deactivated() : Optional<ChannelConnectionMutationDescriptor>
 *   activating() : Optional<ChannelConnectionMutationDescriptor>
 *   deactivating() : Optional<ChannelConnectionMutationDescriptor>
 *   startUp() : Optional<ChannelConnectionMutationDescriptor>
 *   shutdown() : Optional<ChannelConnectionMutationDescriptor>
 *   failed() : Optional<ChannelConnectionMutationDescriptor>
 * }
 * ActualPhysicalActivationEvents <|-- Active
 * ActualPhysicalActivationEvents <|-- Inactive
 * ActualPhysicalActivationEvents <|-- Activating
 * ActualPhysicalActivationEvents <|-- Deactivating
 * ActualPhysicalActivationEvents <|-- Failed
 * ActualPhysicalActivationEvents <|-- StartingUp
 * ActualPhysicalActivationEvents <|-- Shutdown
 * ActualPhysicalActivationEvents <|-- Creating
 * hide fields
 * @enduml
 */
public class ChannelPhysicalConnectionBehavior {

    private final ActualPhysicalActivationEvents activationEvents;

	/**
	 * Initiates an instance with the given domain object data.
	 *
	 * @param state The instance containing the domain object data
	 * @param notifications Instance of the class responsible for sending notifications about channels.
	 * @throws NullPointerException if the received domain object data argument is {@code null}
	 */
    public ChannelPhysicalConnectionBehavior(@Nonnull ChannelPhysicalConnectionData state, @Nonnull ChannelNotifications notifications) {
        activationEvents = eventHandlerFor(state, notifications);
    }

    /**
     * Starts the channel activation process.
     *
     * @param activationManager Instance of the class responsible for the activation policies.
     * @param activationEvent Instance of an event describing the required channel state upon startup.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelPhysicalConnectionMutationDescriptor> startUp(
            @Nonnull ChannelInteractionManager activationManager,
            @Nonnull Activate activationEvent) {
        return activationEvents.startUp(activationManager, activationEvent);
    }

    /**
     * Starts the channel deactivation process.
     *
     * @param activationManager Instance of the class responsible for the activation policies.
     * @param deactivationEvent Instance of an event describing the required channel state upon shutdown.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelPhysicalConnectionMutationDescriptor> shutdown(
            @Nonnull ChannelInteractionManager activationManager,
            @Nonnull Deactivate deactivationEvent) {
        return activationEvents.shutDown(activationManager, deactivationEvent);
    }

    /**
     * Signals a channel as being in the process of creation. Channel creation is its initial
     * activation. Spontaneous deactivation/activation sequences may happen during its
     * lifetime should the mediation need to recover from a channel connection or process failure.
     *
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelPhysicalConnectionMutationDescriptor> setCreating() {
        return activationEvents.creating();
    }

    /**
     * Signals a channel as having been created. The result of a created channel is an active channel.
     *
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelPhysicalConnectionMutationDescriptor> setCreated(@Nonnull ChannelInteractionManager activationManager) {
        return activationEvents.created(activationManager);
    }

    /**
     * Signals a channel as having started the activation process.
     *
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelPhysicalConnectionMutationDescriptor> setActivating() {
        return activationEvents.activating();
    }

    /**
     * Signals a channel as having been successfully activated.
     *
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelPhysicalConnectionMutationDescriptor> setActive(
            @Nonnull ChannelInteractionManager activationManager) {
        return activationEvents.activated(activationManager);
    }

    /**
     * Signals a channel as having started the deactivation process.
     *
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelPhysicalConnectionMutationDescriptor> setDeactivating() {
        return activationEvents.deactivating();
    }

    /**
     * Signals a channel as having been successfully deactivated.
     *
     * @param activationManager Instance of the class responsible for the activation policies.
     * @param neEventSource Instance of an NE event source for publishing NE state changes.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelPhysicalConnectionMutationDescriptor> setInactive(
            @Nonnull ChannelInteractionManager activationManager,
            @Nonnull MessageSource<NeEvent> neEventSource,
            @Nonnull Iterable<PhysicalNeDisconnectedEvent> childNeDeactivationEvents) {
        return activationEvents.deactivated(activationManager, neEventSource, childNeDeactivationEvents);
    }

    /**
     * Signals that activation of a channel has failed.
     *
     * @param activationManager Instance of the class responsible for the activation policies.
     * @param neEventSource Instance of an NE event source for publishing NE state changes.
     * @param childNeEvents A collection of failure events against children NEs that should be fired when
     *  the Channel failure itself is committed.
     * @param description Human readable failure description. Will be eventually forwarded to the operator.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelPhysicalConnectionMutationDescriptor> setFailed(
            @Nonnull ChannelInteractionManager activationManager,
            @Nonnull MessageSource<NeEvent> neEventSource,
            @Nonnull Iterable<PhysicalNeActivationFailedEvent> childNeEvents,
            @Nonnull String description) {
        return activationEvents.failed(activationManager, description, neEventSource, childNeEvents);
    }

    /**
     * <p>Creates a new instance of the behavior as a state machine for assistance
     * with changes of the actual activation state on a channel.</p>
     *
     * <p>This extra indirection is necessary because all mutation descriptors created
     * by state transitions must contain a reference to the original (target) entity.
     * However, enums are static instances, therefore they can not have any context
     * information. The solution found was to separate behavior from value and
     * instantiate a new behavior class with the appropriate target reference.</p>
     *
     * @param state Current physical channel instance connection state.
     * @param notifications Instance of the class responsible for sending notifications about channels.
     * @return An instance of the actual activation state machine.
     */
    private ActualPhysicalActivationEvents eventHandlerFor(ChannelPhysicalConnectionData state, ChannelNotifications notifications) {
        final ActualPhysicalActivationEvents handler;
        switch (state.getActualActivationState()) {
        case ACTIVE:
            handler = new Active(state, notifications);
            break;
        case INACTIVE:
            handler = new Inactive(state, notifications);
            break;
        case ACTIVATING:
            handler = new Activating(state, notifications);
            break;
        case DEACTIVATING:
            handler = new Deactivating(state, notifications);
            break;
        case FAILED:
            handler = new Failed(state, notifications);
            break;
        case CREATING:
            handler = new Creating(state, notifications);
            break;
        case STARTINGUP:
            handler = new StartingUp(state, notifications);
            break;
        case SHUTTINGDOWN:
            handler = new ShuttingDown(state, notifications);
            break;
        default:
            throw new IllegalStateException("No behavior for actual physical activation state " +
                state.getActualActivationState());
        }
        return handler;
    }

    /**
     * Behavior component of the actual activation state. Handles state transitions using the State Machine pattern.
     * To reduce code duplication, allows all state transactions by default. Specific implementations must disallow
     * transitions as appropriate.
     *
     * @see ActualActivationState
     */
    private abstract static class ActualPhysicalActivationEvents {

        private final ChannelPhysicalConnectionData data;
        private final ChannelNotifications notifications;

        protected ActualPhysicalActivationEvents(ChannelPhysicalConnectionData data, ChannelNotifications notifications)  {
            this.data = data;
            this.notifications = notifications;
        }

        /**
         * Promotes a change to the "startingUp" state.
         * @param activationManager Instance of the class responsible for the activation policies.
         * @param activationEvent Instance of an event describing the required channel state upon startup.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelPhysicalConnectionMutationDescriptor> startUp(@Nonnull ChannelInteractionManager activationManager,
                                                                                       @Nonnull Activate activationEvent) {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "creating" state.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelPhysicalConnectionMutationDescriptor> creating() {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "created" state.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelPhysicalConnectionMutationDescriptor> created(@Nonnull final ChannelInteractionManager activationManager) {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "activating" state.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelPhysicalConnectionMutationDescriptor> activating() {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "active" state.
         * @param activationManager Instance of the class responsible for the activation policies.
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelPhysicalConnectionMutationDescriptor> activated(@Nonnull ChannelInteractionManager activationManager) {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "shuttingDown" state.
         * @param activationManager Instance of the class responsible for the activation policies.
         * @param deactivationEvent Instance of an event describing the required channel state upon shutdown.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelPhysicalConnectionMutationDescriptor> shutDown(@Nonnull ChannelInteractionManager activationManager,
                                                                                        @Nonnull Deactivate deactivationEvent) {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "deactivating" state.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelPhysicalConnectionMutationDescriptor> deactivating() {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "inactive" state.
         * @param activationManager Instance of the class responsible for the activation policies.
         * @param neEventSource Instance of an NE event source for publishing NE state changes.
         * @param childNeDeactivationEvents NE state change events, issued for children of the channel being
         *                                  deactivated when the deactivation is actually applied.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelPhysicalConnectionMutationDescriptor> deactivated(@Nonnull ChannelInteractionManager activationManager,
                                                                                           @Nonnull MessageSource<NeEvent> neEventSource, @Nonnull Iterable<PhysicalNeDisconnectedEvent> childNeDeactivationEvents) {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "failed" state.
         * @param activationManager Instance of the class responsible for the activation policies.
         * @param description Additional, human readable, state description.
         * @param neEventSource Instance of an NE event source for publishing NE state changes.
         * @param childNeEvents A collection of failure events against children NEs that should be fired when
         *  the Channel failure itself is committed.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelPhysicalConnectionMutationDescriptor> failed(
                @Nonnull ChannelInteractionManager activationManager, @Nonnull String description,
                @Nonnull MessageSource<NeEvent> neEventSource, @Nonnull Iterable<PhysicalNeActivationFailedEvent> childNeEvents) {
            return Optional.empty();
        }

        protected ChannelPhysicalConnectionMutationDescriptor buildMutation() {
            return new ChannelPhysicalConnectionMutationDescriptor(data);
        }

        protected ChannelNotifications getNotifications() {
            return notifications;
        }

    }

    private abstract static class CancellableActivationEvent extends FailingActivationEvent {

        protected CancellableActivationEvent(ChannelPhysicalConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> shutDown(@Nonnull final ChannelInteractionManager activationManager,
                                                                                        @Nonnull final Deactivate deactivationEvent) {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.SHUTTINGDOWN)
                    .setAdditionalInfo("")
                    .whenApplied(in -> {
                            final ChannelShuttingDownEvent event = new ChannelShuttingDownEvent(in.getResult().getLogicalChannelId(),
                                    new PhysicalChannelShuttingDownEvent(in.getResult().getId(), in.getResult().getLogicalChannelId(), in.getResult().isActive()));
                            getNotifications().notifyChanges(event);
                            activationManager.cancelActivations(deactivationEvent);
                            activationManager.scheduleDeactivation(deactivationEvent);
                    }));
        }

    }

    private abstract static class FailingActivationEvent extends ActualPhysicalActivationEvents {

        protected FailingActivationEvent(ChannelPhysicalConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        /**
         * Promotes a change to the "failed" state.
         * @param activationManager Instance of the class responsible for the activation policies.
         * @param description Additional, human readable, state description.
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> failed(
                @Nonnull ChannelInteractionManager activationManager, @Nonnull String description,
                @Nonnull MessageSource<NeEvent> neEventSource, @Nonnull Iterable<PhysicalNeActivationFailedEvent> childNeEvents) {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.FAILED)
                    .setAdditionalInfo(description)
                    .whenApplied(in -> {
                        final ChannelPhysicalConnectionData mutationResult = in.getResult();
                        final ChannelActivationFailedEvent event =
                            new ChannelActivationFailedEvent(mutationResult.getLogicalChannelId(),
                                new PhysicalChannelActivationFailedEvent(mutationResult.getId(), mutationResult.getLogicalChannelId(), mutationResult.isActive(),
                                    mutationResult.getAdditionalInfo()),
                                mutationResult.getAdditionalInfo());
                        getNotifications().notifyChanges(event);
                        activationManager.onChannelInteractionEnded(event);
                        childNeEvents.forEach(neEventSource::push);
                    }));
        }

    }

    private static final class StartingUp extends FailingActivationEvent {

        protected StartingUp(ChannelPhysicalConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> creating() {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.CREATING)
                    .setAdditionalInfo("")
                    .whenApplied(in -> getNotifications().notifyChanges(new ChannelActivatingEvent(in.getResult().getLogicalChannelId(),
                            new PhysicalChannelActivatingEvent(in.getResult().getId(), in.getResult().getLogicalChannelId(), in.getResult().isActive()))))
                    );
        }

        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> shutDown(@Nonnull final ChannelInteractionManager activationManager,
                                                                                        @Nonnull final Deactivate deactivationEvent) {
            /*
             * We switch directly to INACTIVE because the STARTING UP state merely indicates that there's
             * a scheduled startup. It hasn't started yet. So we change states and cancel the start up.
             * Should the job start in the mean time, our state will remain INACTIVE even though a real
             * connection may be opened.
             */
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.INACTIVE)
                    .setAdditionalInfo("")
                    .whenApplied(in -> {
                            final ChannelPhysicalConnectionData mutationResult = in.getResult();
                            final ChannelDeactivatedEvent event = new ChannelDeactivatedEvent(mutationResult.getLogicalChannelId(),
                                    new PhysicalChannelDeactivatedEvent(mutationResult.getId(), mutationResult.getLogicalChannelId(), mutationResult.isActive()));
                            getNotifications().notifyChanges(event);
                            activationManager.cancelActivations(deactivationEvent);
                        }
                    ));
        }

    }

    private static final class Creating extends CancellableActivationEvent {

        protected Creating(ChannelPhysicalConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> created(@Nonnull final ChannelInteractionManager activationManager) {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.ACTIVE)
                    .setAdditionalInfo("")
                    .whenApplied(in ->  {
                            final ChannelPhysicalConnectionData mutationResult = in.getResult();
                            final ChannelActivatedEvent event = new ChannelActivatedEvent(mutationResult.getLogicalChannelId(),
                                    new PhysicalChannelActivatedEvent(mutationResult.getId(), mutationResult.getLogicalChannelId(), mutationResult.isActive()));
                            getNotifications().notifyChanges(event);
                            activationManager.onChannelInteractionEnded(event);
                        }
                    ));
        }
    }

    private static final class Activating extends CancellableActivationEvent {

        protected Activating(ChannelPhysicalConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> activated(@Nonnull final ChannelInteractionManager activationManager) {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.ACTIVE)
                    .setAdditionalInfo("")
                    .whenApplied(in -> {
                            final ChannelPhysicalConnectionData mutationResult = in.getResult();
                            final ChannelActivatedEvent event = new ChannelActivatedEvent(mutationResult.getLogicalChannelId(),
                                    new PhysicalChannelActivatedEvent(mutationResult.getId(), mutationResult.getLogicalChannelId(), mutationResult.isActive()));
                            getNotifications().notifyChanges(event);
                            activationManager.onChannelInteractionEnded(event);
                        }
                    ));
        }

    }

    private static final class Active extends CancellableActivationEvent {

        protected Active(ChannelPhysicalConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

    }

    private static final class ShuttingDown extends FailingActivationEvent {

        protected ShuttingDown(ChannelPhysicalConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> deactivating() {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.DEACTIVATING)
                    .setAdditionalInfo("")
                    .whenApplied(in -> getNotifications().notifyChanges(
                        new ChannelDeactivatingEvent(in.getResult().getLogicalChannelId(),
                            new PhysicalChannelDeactivatingEvent(in.getResult().getId(), in.getResult().getLogicalChannelId(), in.getResult().isActive()))))
                    );
        }

        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> startUp(@Nonnull final ChannelInteractionManager activationManager,
                                                                                       @Nonnull final Activate activationEvent) {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.STARTINGUP)
                    .setAdditionalInfo("")
                    .whenApplied(in -> {
                            final ChannelStartingUpEvent event = new ChannelStartingUpEvent(in.getResult().getLogicalChannelId(),
                                    new PhysicalChannelStartingUpEvent(in.getResult().getId(), in.getResult().getLogicalChannelId(), in.getResult().isActive()));
                            getNotifications().notifyChanges(event);
                            activationManager.cancelDeactivations(activationEvent);
                            activationManager.scheduleActivation(activationEvent);
                        }
                    ));
        }

    }

    private static final class Deactivating extends FailingActivationEvent {

        protected Deactivating(ChannelPhysicalConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> deactivated(@Nonnull ChannelInteractionManager activationManager,
                                                                                           @Nonnull MessageSource<NeEvent> neEventSource, @Nonnull Iterable<PhysicalNeDisconnectedEvent> childNeDeactivationEvents) {
            return Optional.of(buildMutation()
                .setConnection(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .whenApplied(in -> {
                        final ChannelPhysicalConnectionData mutationResult = in.getResult();
                        final ChannelDeactivatedEvent event = new ChannelDeactivatedEvent(mutationResult.getLogicalChannelId(),
                                new PhysicalChannelDeactivatedEvent(mutationResult.getId(), mutationResult.getLogicalChannelId(), mutationResult.isActive()));
                        getNotifications().notifyChanges(event);
                        activationManager.onChannelInteractionEnded(event);
                        childNeDeactivationEvents.forEach(neEventSource::push);
                    }
                ));
        }

    }

    private static class Inactive extends FailingActivationEvent {

        protected Inactive(ChannelPhysicalConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> startUp(@Nonnull final ChannelInteractionManager activationManager,
                                                                                       @Nonnull final Activate activationEvent) {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.STARTINGUP)
                    .setAdditionalInfo("")
                    .whenApplied(in -> {
                            final ChannelStartingUpEvent event = new ChannelStartingUpEvent(in.getResult().getLogicalChannelId(),
                                    new PhysicalChannelStartingUpEvent(in.getResult().getId(), in.getResult().getLogicalChannelId(), in.getResult().isActive()));
                            getNotifications().notifyChanges(event);
                            activationManager.cancelDeactivations(activationEvent);
                            activationManager.scheduleActivation(activationEvent);
                        }
                    ));
        }

    }

    private static final class Failed extends Inactive {

        protected Failed(ChannelPhysicalConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        /**
         * {@inheritDoc}
         *
         * <p>Mediations will recover failed channels automatically, so we need to allow a switch from Failed to Activating
         * without it going through the scheduler.</p>
         */
        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> activating() {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.ACTIVATING)
                    .setAdditionalInfo("")
                    .whenApplied(in -> getNotifications().notifyChanges(new ChannelActivatingEvent(in.getResult().getLogicalChannelId(),
                            new PhysicalChannelActivatingEvent(in.getResult().getId(), in.getResult().getLogicalChannelId(), in.getResult().isActive())))
                    ));
        }

        @Override
        public Optional<ChannelPhysicalConnectionMutationDescriptor> shutDown(@Nonnull final ChannelInteractionManager activationManager,
                                                                                        @Nonnull final Deactivate deactivationEvent) {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.SHUTTINGDOWN)
                    .setAdditionalInfo("")
                    .whenApplied(in -> {
                            final ChannelShuttingDownEvent event = new ChannelShuttingDownEvent(in.getResult().getLogicalChannelId(),
                                    new PhysicalChannelShuttingDownEvent(in.getResult().getId(), in.getResult().getLogicalChannelId(), in.getResult().isActive()));
                            getNotifications().notifyChanges(event);
                            activationManager.scheduleDeactivation(deactivationEvent);
                        }
                    ));
        }

    }

}
