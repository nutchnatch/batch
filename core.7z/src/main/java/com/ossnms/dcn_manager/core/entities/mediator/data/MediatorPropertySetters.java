package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.ossnms.dcn_manager.exceptions.InvalidMutationException;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Optional;

public interface MediatorPropertySetters<T extends MediatorPropertySetters<T>> {

    /**
     * @param name New mediator name.
     * @throws InvalidMutationException If the new mediator name is empty.
     */
    T setName(@Nonnull String name) throws InvalidMutationException;

    /**
     * @param description New description.
     */
    T setDescription(@Nonnull Optional<String> description);


    /**
     * @param userText
     * @return
     */
    T setUserText(@Nonnull Optional<String> userText);
    /**
     * @param activationRequired Whether activation will be required for this mediator.
     */
    T setActivationRequired(boolean activationRequired);

    /**
     * @param concurrentActivationsLimited Whether the number of concurrent activations should now be limited.
     */
    T setConcurrentActivationsLimited(boolean concurrentActivationsLimited);

    /**
     * @param concurrentActivationsLimit The new maximum number of concurrent activations that can be in progress
     *  at any time. Enforced only if {@code concurrentActivationsLimited} is true.
     */
    T setConcurrentActivationsLimit(int concurrentActivationsLimit);

    /**
     * @param reconnectAttemptInterval New amount of time to wait between automatic reconnection attempts,
     *  in minutes.
     */
    T setReconnectAttemptInterval(int reconnectAttemptInterval);

    /**
     * Stores a new property for the object. It will be stored in the property bag
     * without further handling.
     * @param name The name of the property to change.
     * @param value The new property value.
     */
    T setProperty(@Nonnull String name, @Nullable String value);

}