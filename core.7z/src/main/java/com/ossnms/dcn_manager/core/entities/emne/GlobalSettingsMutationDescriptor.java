package com.ossnms.dcn_manager.core.entities.emne;

import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Optional;

/**
 * Describes changes to be done on the global EM/NE configuration.
 * @see GlobalSettings
 */
public class GlobalSettingsMutationDescriptor extends MutationDescriptor<GlobalSettings, GlobalSettingsMutationDescriptor> {

    /**
     * @param target
     */
    public GlobalSettingsMutationDescriptor(GlobalSettings target) {
        super(target);
    }

    private Optional<Integer> mediatorRetries = Optional.empty();
    private Optional<Integer> channelRetries = Optional.empty();
    private Optional<Integer> neRetries = Optional.empty();
    private Optional<Integer> retryInterval = Optional.empty();
    private Optional<Integer> scaledStartupLimit = Optional.empty();
    private Optional<DiscoveryPolicy> discoveryPolicy = Optional.empty();
    private Optional<Boolean> enableScheduledStartup = Optional.empty();
    private Optional<Boolean> showNativeNeNaming = Optional.empty();
    private Optional<String> defaultContainerName = Optional.empty();


    @Override
    protected GlobalSettingsMutationDescriptor self() {
        return this;
    }

    @Override
    protected GlobalSettings doApply() {
        return new GlobalSettings.Builder()
                .setMediatorRetries(getMediatorRetries().orElse(getTarget().getMediatorRetries()))
                .setChannelRetries(getChannelRetries().orElse(getTarget().getChannelRetries()))
                .setNeRetries(getNeRetries().orElse(getTarget().getNeRetries()))
                .setRetryInterval(getRetryInterval().orElse(getTarget().getRetryInterval()))
                .setScaledStartupLimit(getScaledStartupLimit().orElse(getTarget().getScaledStartupLimit()))
                .setDiscoveryPolicy(getDiscoveryPolicy().orElse(getTarget().getDiscoveryPolicy()))
                .setEnableScheduledStartup(getEnableScheduledStartup().orElse(getTarget().isScheduledStartupEnabled()))
                .setShowNativeNeNaming(getShowNativeNeNaming().orElse(getTarget().isNativeNeNamingEnabled()))
                .setDefaultContainerName(getDefaultContainerName().orElse(getTarget().getDefaultContainerName()))
                .toGlobalSettings(getTarget().getId(), getTarget().getVersion());
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("mediatorRetries",mediatorRetries)
                .append("channelRetries",channelRetries)
                .append("neRetries",neRetries)
                .append("retryInterval",retryInterval)
                .append("scaledStartupLimit",scaledStartupLimit)
                .append("discoveryPolicy",discoveryPolicy)
                .append("enableScheduledStartup",enableScheduledStartup)
                .append("showNativeNeNaming",showNativeNeNaming)
                .append("defaultContainerName",defaultContainerName)
                .toString();
    }

    /** @return Mediator connection retry limit. Zero means infinite. */
    public Optional<Integer> getMediatorRetries() {
        return mediatorRetries;
    }

    /**
     * @param mediatorRetries The new Mediator connection retry limit.
     */
    public GlobalSettingsMutationDescriptor setMediatorRetries(int mediatorRetries) {
        this.mediatorRetries = Optional.of(mediatorRetries);
        return self();
    }

    /** @return Channel connection retry limit. Zero means infinite. */
    public Optional<Integer> getChannelRetries() {
        return channelRetries;
    }

    /**
     * @param channelRetries The new Channel connection retry limit.
     */
    public GlobalSettingsMutationDescriptor setChannelRetries(int channelRetries) {
        this.channelRetries = Optional.of(channelRetries);
        return self();
    }

    /** @return NE connection retry limit. Zero means infinite. */
    public Optional<Integer> getNeRetries() {
        return neRetries;
    }

    /**
     * @param neRetries The new NE connection retry limit.
     */
    public GlobalSettingsMutationDescriptor setNeRetries(int neRetries) {
        this.neRetries = Optional.of(neRetries);
        return self();
    }

    /** @return Retry interval. */
    public Optional<Integer> getRetryInterval() {
        return retryInterval;
    }

    /**
     * @param schedulerTimeInterval The new retry interval.
     */
    public GlobalSettingsMutationDescriptor setRetryInterval(int schedulerTimeInterval) {
        this.retryInterval = Optional.of(schedulerTimeInterval);
        return self();
    }

    /**
     * @param limit New scaled startup limit.
     */
    public GlobalSettingsMutationDescriptor setScaledStartupLimit(int limit) {
        this.scaledStartupLimit = Optional.of(limit);
        return self();
    }

    /** @return Scaled startup limit value. */
    public Optional<Integer> getScaledStartupLimit() {
        return scaledStartupLimit;
    }

    /**
     * @param policy New network discovery policy.
     */
    public GlobalSettingsMutationDescriptor setDiscoveryPolicy(DiscoveryPolicy policy) {
        this.discoveryPolicy = Optional.of(policy);
        return self();
    }

    /** @return The network discovery policy. */
    public Optional<DiscoveryPolicy> getDiscoveryPolicy() {
        return discoveryPolicy;
    }

    /**
     * @param enable Whether the scheduled startup algorithm is enabled.
     */
    public GlobalSettingsMutationDescriptor setEnableScheduledStartup(boolean enable) {
        this.enableScheduledStartup = Optional.of(enable);
        return self();
    }

    public GlobalSettingsMutationDescriptor setDefaultContainerName(String defaultContainerName) {
        this.defaultContainerName = Optional.of(defaultContainerName);
        return self();
    }

    /**
     * @return Whether a scheduled startup algorithm must be used during connection and
     * initialization of EM/NE objects.
     */
    public Optional<Boolean> getEnableScheduledStartup() {
        return enableScheduledStartup;
    }

    /**
     * @return Whether components should show the Native Name.
     */
    public Optional<Boolean> getShowNativeNeNaming() {
        return showNativeNeNaming;
    }

    /**
     * @return The default container name.
     */
    public Optional<String> getDefaultContainerName() {
        return defaultContainerName;
    }

    /**
     * @param showNativeNeNaming Whether components should show the Native Name.
     */
    public GlobalSettingsMutationDescriptor setShowNativeNeNaming(boolean showNativeNeNaming) {
        this.showNativeNeNaming = Optional.of(showNativeNeNaming);
        return self();
    }
}
