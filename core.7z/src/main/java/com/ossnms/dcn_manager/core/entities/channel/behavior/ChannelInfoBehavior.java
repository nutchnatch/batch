package com.ossnms.dcn_manager.core.entities.channel.behavior;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * <p>Class that implements the behavior dimension of the domain object that describes the persisted channel
 * state or, in other words, the channel's information and required activation state. This means
 * that the application must ensure that the actual channel state converges to the required one. </p>
 *
 * <p>The implementation is based on the State Machine design pattern to deal with required activation
 * state transitions. The state machine is depicted in the following figure. Notice that the
 * representation of start and end states is merely illustrative of the expected flow: channels
 * are originally created in the deactivated state, that is, activation not required. State transitions
 * are triggered by the depicted domain object operations (i.e.
 * {@link #activationRequired(com.ossnms.dcn_manager.core.policies.ChannelInteractionManager, ChannelNotifications)}
 * and {@link #deactivationRequired(com.ossnms.dcn_manager.core.policies.ChannelInteractionManager, ChannelNotifications)}). </p>
 *
 * <p><figure>
 * <img src="doc-files/channelInfo_required_activation_state-state.png">
 * <figcaption>State diagram of the required activation state state machine</figcaption>
 * </figure></p>
 *
 * <p> The state machine is materialized in the following class hierarchy, only relevant to the domain
 * object implementation. For this reason the hierarchy is implemented as a set of static nested
 * classes not accessible from the outside. This solution has the merit of reducing overall
 * complexity (i.e. reducing the number of top-level classes) at the expense of increasing
 * file level complexity (i.e. its size). Nevertheless, and considering the actual file size, the
 * tradeoff is positive. In the case that the current file size increases, this approach must be
 * reevaluated. </p>
 *
 * <p> <figure>
 * <img src="doc-files/channelInfo_required_activation_state-class.png">
 * <figcaption>Class diagram of the required activation state hierarchy</figcaption>
 * </figure> </p>
 *
 * <ul> Design decisions:
 * <li> Each state transition is materialized in an independent abstract method,
 * to be overridden in concrete state classes; </li>
 * <li> Invalid transitions are signaled by producing an absent {@link Optional} instance,
 * instead of throwing an exception. Note that the exact reaction to an invalid
 * transition depends on the specific use case, and therefore throwing an exception
 * would be inappropriate; </li>
 * <li> Transitions are not applied on the on the domain object instance, due to its
 * immutable nature. Instead, state transitions produce a description of the resulting
 * mutation, which will be later applied on the repository. </li>
 * </ul>
 *
 * <p> As all types that implement domain objects' behavior dimension, this class instances are
 * not thread-safe, and therefore cannot be shared by multiple threads without explicit synchronization.
 * </p>
 */
/*
 * @startuml doc-files/channelInfo_required_activation_state-state.png
 * [*] --> Deactivated
 * Deactivated --> [*]
 * Activated --> Deactivated : setDeactivated
 * Activated --> Activated : setActivated
 * Deactivated --> Activated : setActivated
 * Deactivated --> Deactivated : setDeactivated
 * @enduml
 */
/*
 * @startuml doc-files/channelInfo_required_activation_state-class.png
 * class RequiredActivationState <<abstract>> {
 * 		{abstract} + activate() : Optional<ChannelStateMutationDescriptor>
 *    	{abstract} + deactivate() : Optional<ChannelStateMutationDescriptor>
 *    	{abstract} + isActive() : boolean
 * }

 * RequiredActivationState <|-- Activated
 * RequiredActivationState <|-- Deactivated

 * hide fields
 * @enduml
 */
public class ChannelInfoBehavior {

	/**
	 * Base class for channel required activation states
	 */
	private abstract static class RequiredActivationState
	{
		/**
		 * Promotes the transition to the Activation required state. The channel activation is now required, and its actual
		 * activation must be triggered elsewehere.
		 *
		 * @param target the domain object instance to be activated
		 * @param eventDispatcher The event dispatcher instance, which is used to send the event that signals the
		 * state transition
		 * @param channelInstances Channel instances upon which the required state must be enforced.
		 * @return an {@link Optional} bearing the mutation descriptor to be used to update the activation state,
		 * or an absent {@link Optional} if the transition is not valid in the present state (i.e. the channel
		 * is already required to be activated)
		 */
		public abstract Optional<ChannelInfoMutationDescriptor> activate(
		        @Nonnull ChannelInfoData target, @Nonnull ChannelNotifications eventDispatcher, @Nonnull Iterable<Integer> channelInstances);

		/**
		 * Promotes the transition to the Deactivated required state. The channel is required to be deactivated, and its
		 * actual deactivation must be triggered elsewhere.
		 *
		 * @param target the domain object instance to be deactivated
		 * @param eventDispatcher The event dispatcher instance, which is used to send the event that signals the
		 * state transition
		 * @param channelInstances Channel instances upon which the required state must be enforced.
		 * @return an {@link Optional} bearing the mutation descriptor to be used to update the activation state,
		 * or an absent {@link Optional} if the transition is not valid in the present state (i.e. the channel
		 * is already required to be deactivated)
		 */
		public abstract Optional<ChannelInfoMutationDescriptor> deactivate(
		        @Nonnull ChannelInfoData target, @Nonnull ChannelNotifications eventDispatcher, @Nonnull Iterable<Integer> channelInstances);

		/**
		 * Singleton instances of the states of the activation state machine
		 */
		public static final RequiredActivationState ACTIVATED = new Activated();
		public static final RequiredActivationState DEACTIVATED = new Deactivated();

		/**
		 * Utility method that produces the {@link RequiredActivationState} instance that corresponds
		 * to the given boolean value
		 *
		 * @param isActivated boolean value used to describe the activation state (i.e. {@literal true} means
		 * activated, {@literal false} means deactivated
		 * @return the corresponding {@link RequiredActivationState} instance
		 */
		public static RequiredActivationState fromBoolean(boolean isActivated) { return isActivated ? ACTIVATED : DEACTIVATED; }
	}

	/**
	 * Class that implements the Activated state of the channel activation state machine
	 */
	private static final class Activated extends RequiredActivationState
	{
		/** {@inheritDoc} */
		@Override
		public Optional<ChannelInfoMutationDescriptor> activate(ChannelInfoData target, ChannelNotifications eventDispatcher, Iterable<Integer> channelInstances) {
			return Optional.empty();
		}

		/** {@inheritDoc} */
		@Override
		public Optional<ChannelInfoMutationDescriptor> deactivate(ChannelInfoData target, ChannelNotifications eventDispatcher, Iterable<Integer> channelInstances) {
			final ChannelInfoMutationDescriptor mutation = new ChannelInfoMutationDescriptor(target)
				.setActive(false)
				.whenApplied(appliedMutation -> {
					final ChannelInfoData mutatedChannel = appliedMutation.getResult();
					// Produce activation event
					final Deactivate event = new Deactivate(
							mutatedChannel.getId(), mutatedChannel.getMediatorId(), channelInstances);
					eventDispatcher.notifyChanges(event);
				});
			return Optional.of(mutation);
		}
	}

	/**
	 * Class that implements the Deactivated state of the channel activation state machine
	 */
	private static final class Deactivated extends RequiredActivationState
	{
		/** {@inheritDoc} */
		@Override
		public Optional<ChannelInfoMutationDescriptor> activate(ChannelInfoData target, ChannelNotifications eventDispatcher, Iterable<Integer> channelInstances) {

			final ChannelInfoMutationDescriptor mutation = new ChannelInfoMutationDescriptor(target)
				.setActive(true)
				.whenApplied(appliedMutation -> {
					final ChannelInfoData mutatedChannel = appliedMutation.getResult();
					// Produce activation event
					final Activate event = new Activate(
							mutatedChannel.getId(), mutatedChannel.getMediatorId(), channelInstances);
					eventDispatcher.notifyChanges(event);
				});
			return Optional.of(mutation);
		}

		/** {@inheritDoc} */
		@Override
		public Optional<ChannelInfoMutationDescriptor> deactivate(ChannelInfoData target, ChannelNotifications eventDispatcher, Iterable<Integer> channelInstances) {
			return Optional.empty();
		}
	}

	/**
	 * The data of the domain object
	 */
	private final ChannelInfoData entityData;

	/** The channel's required activation state */
	private final RequiredActivationState activationState;

	/**
	 * Initiates an instance with the given domain object data
	 * @param entityData the instance containing the domain object data
	 * @throws NullPointerException if the received argument is {@code null}
	 */
	public ChannelInfoBehavior(@Nonnull ChannelInfoData entityData) {
		this.entityData = entityData;
		activationState = RequiredActivationState.fromBoolean(entityData.isActivationRequired());
	}

    /**
     * Sets the channel's required activation state to Activated, if the instance is not currently required
     * to be activated.
     * Note that instances are immutable, and therefore the mutation is not applied to the current instance.
     * Instead, a description of the resulting mutation is returned. This mutation will be subsequently applied,
     * producing a newly created instance.
     *
	 * @param eventDispatcher The event dispatcher instance, which is used to send the event that signals the
	 * state transition
	 * @param channelInstances Channel instances upon which the required state must be enforced.
     * @return the resulting mutation descriptor, or an absent {@link Optional} if the
     * channel is already required to be activated
     */
	public Optional<ChannelInfoMutationDescriptor> activationRequired(@Nonnull ChannelNotifications eventDispatcher, @Nonnull Iterable<Integer> channelInstances) {
		return activationState.activate(entityData, eventDispatcher, channelInstances);
	}

    /**
     * Sets the channel's required activation state to Deactivated, if the instance is not currently required
     * to be deactivated.
     * Note that instances are immutable, and therefore the mutation is not applied to the current instance.
     * Instead, a description of the resulting mutation is returned. This mutation will be subsequently applied,
     * producing a newly created instance.
     *
	 * @param eventDispatcher The event dispatcher instance, which is used to send the event that signals the
	 * state transition
	 * @param channelInstances Channel instances upon which the required state must be enforced.
     * @return the resulting mutation descriptor, or an absent {@link Optional} if the
     * channel is already required to be deactivated
     */
	public Optional<ChannelInfoMutationDescriptor> deactivationRequired(@Nonnull ChannelNotifications eventDispatcher, @Nonnull Iterable<Integer> channelInstances) {
		return activationState.deactivate(entityData, eventDispatcher, channelInstances);
	}
}
