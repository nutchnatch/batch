/**
 * <p>Contains companion objects that know how to access unstructured
 * data within Channel Entities. Also know how to transform these entities
 * into unstructured data blocks and back.</p>
 *
 * <p>These unstructured data blocks are known as properties, and only
 * supported properties will be interpreted. All others will be
 * treated as-is.</p>
 *
 * <p><img src="doc-files/package-dependencies.png"/></p>
 */
/*
 * @startuml doc-files/package-dependencies.png
 *
 * title Bird's-eye view of dependencies
 *
 * class ChannelProperties
 * class ChannelProperty
 * class ChannelType
 * class ChannelEntity
 * class ChannelEntityMutationDescriptor
 *
 * ChannelType <.. ChannelProperties
 * ChannelEntity <.. ChannelProperties
 * ChannelEntityMutationDescriptor <.. ChannelProperties
 * ChannelProperty <.. ChannelProperties
 *
 * @enduml
 */
package com.ossnms.dcn_manager.core.properties.channel;
