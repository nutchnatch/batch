package com.ossnms.dcn_manager.core.entities.ne.data;

import java.util.Optional;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySource.NeOperationPropertySource;
import com.ossnms.dcn_manager.core.entities.ne.data.types.CommissioningMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.OperationalMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.types.WriteAccessMode;

/**
 * <p>Volatile information about the NE operation.
 * It only makes sense while the NE is connected and initialized, hence
 * it is not persisted.</p>
 *
 * <p>Also, not all attributes may contain valid information at all times.
 * Information validity may depend on the NE type, mediation behaviour or
 * NE connectivity status. Therefore they are all optional.</p>
 */
public final class NeOperationData extends BusinessObjectData implements NeOperationPropertySource {

    private final Optional<WriteAccessMode> writeAccess;
    private final Optional<OperationalMode> operational;
    private final Optional<Boolean> eventForwardingMode;
    private final Optional<CommissioningMode> commissioning;
    private final Optional<String> family;
    private final Optional<String> mainRelease;
    private final Optional<String> maintenanceRelease;
    private final Optional<TpGroupSettings> tpGroupMode;
    private final Optional<Long> tpGroupMask;
    private final Optional<String> neSubType;
    private final Optional<String> neSubTypeDescription;
    private final Optional<String> neType;
    private final Optional<String> neSpecificType;
    private final Optional<String> realNeName;
    private final Optional<String> iconId;
    private final Optional<String> neighbourhoodId;
    private final Optional<String> location;
    private final Optional<GatewayMode> gatewayMode;
    private final Optional<String> additionalTypeInfo;

    public NeOperationData(int neId, int version, @Nonnull NeOperationPrototype<?> prototype) {
        super(neId, version);
        writeAccess = prototype.writeAccess;
        operational = prototype.operational;
        eventForwardingMode = prototype.eventForwardingMode;
        commissioning = prototype.commissioning;
        family = prototype.family;
        mainRelease = prototype.mainRelease;
        maintenanceRelease = prototype.maintenanceRelease;
        tpGroupMode = prototype.tpGroupMode;
        tpGroupMask = prototype.tpGroupMask;
        neSubType = prototype.neSubType;
        neType = prototype.neType;
        neSpecificType = prototype.neSpecificType;
        neSubTypeDescription = prototype.neSubTypeDescription;
        realNeName = prototype.realNeName;
        iconId = prototype.iconId;
        neighbourhoodId = prototype.neighbourhoodId;
        location = prototype.location;
        gatewayMode = prototype.gatewayMode;
        additionalTypeInfo = prototype.additionalTypeInfo;
    }

    /**
     * @return The current write access status.
     */
    public Optional<WriteAccessMode> getWriteAccess() {
        return writeAccess;
    }

    /**
     * @return The current operational mode.
     */
    public Optional<OperationalMode> getOperational() {
        return operational;
    }

    /**
     * @return Whether event forwarding is active.
     */
    public Optional<Boolean> isEventForwardingActive() {
        return eventForwardingMode;
    }

    /**
     * @return The current commissioning status.
     */
    public Optional<CommissioningMode> getCommissioning() {
        return commissioning;
    }

    /**
     * @return NE family name.
     */
    public Optional<String> getFamily() {
        return family;
    }

    /**
     * @return Software main release identifier.
     */
    public Optional<String> getMainRelease() {
        return mainRelease;
    }

    /**
     * @return Software maintenance release identifier.
     */
    public Optional<String> getMaintenanceRelease() {
        return maintenanceRelease;
    }

    /**
     * @return TP grouping configuration.
     */
    public Optional<TpGroupSettings> getTpGroupMode() {
        return tpGroupMode;
    }

    /**
     * @return TP grouping.
     */
    public Optional<Long> getTpGroupMask() {
        return tpGroupMask;
    }

    /**
     * @return NE sub type name.
     */
    public Optional<String> getNeSubType() {
        return neSubType;
    }

    /**
     * @return NE sub type description.
     */
    public Optional<String> getNeSubTypeDescription() {
        return neSubTypeDescription;
    }

    /**
     * @return NE type name.
     */
    public Optional<String> getNeType() {
        return neType;
    }

    /**
     * @return NE specific type name.
     */
    public Optional<String> getNeSpecificType() {
        return neSpecificType;
    }

    /**
     * @return NE name, as set in the hardware.
     */
    @Override
    public Optional<String> getRealNeName() {
        return realNeName;
    }


    /**
     * @return The NE icon identifier.
     */
    public Optional<String> getIconId() {
        return iconId;
    }

    /**
     * @return The neighbourhood Id to identify the NE in its network vicinity.
     */
    @Override
    public Optional<String> getNeighbourhoodId() { return neighbourhoodId;  }

    public Optional<String> getLocation() {
        return location;
    }

    /**
     * @return The gateway role 
     */
    @Override
    public Optional<GatewayMode> getGatewayMode() {
        return gatewayMode;
    }

    /**
     * @return The additional type info - for instance the TL1 NE type
     */
    @Override
    public Optional<String> getAdditionalTypeInfo() {
        return additionalTypeInfo;
    }


    
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("writeAccess", writeAccess)
                .append("operational", operational)
                .append("eventForwardingMode", eventForwardingMode)
                .append("commissioning", commissioning)
                .append("family", family)
                .append("mainRelease", mainRelease)
                .append("maintenanceRelease", maintenanceRelease)
                .append("tpGroupMode", tpGroupMode)
                .append("tpGroupMask", tpGroupMask)
                .append("neSubType", neSubType)
                .append("neSubTypeDescription", neSubTypeDescription)
                .append("neType", neType)
                .append("neSpecificType", neSpecificType)
                .append("realNeName", realNeName)
                .append("neighbourhoodId", neighbourhoodId)
                .append("iconId", iconId)
                .append("location", location)
                .append("gatewayRole", gatewayMode)
                .append("additionalTypeInfo", additionalTypeInfo)
                .toString();
    }

    public static final class NeOperationBuilder extends NeOperationPrototype<NeOperationBuilder> {

        /**
         * @return A new instance of {@link NeOperationData} based on the current
         *  builder attribute values.
         */
        public NeOperationData build(int neId, int version) {
            return new NeOperationData(neId, version, this);
        }

        @Override
        protected NeOperationBuilder self() {
            return this;
        }

    }

    public static final class NeOperationInitialData
            extends NeOperationPrototype<NeOperationInitialData>
            implements NeOperationPropertySource , NeOperationPropertySetters<NeOperationInitialData> {

        @Override
        protected NeOperationInitialData self() {
            return this;
        }

        @Override
        public Optional<String> getRealNeName() {
            return super.realNeName;
        }

        @Override
        public NeOperationInitialData setRealNeName(String realNeName) {
            setRealNeName(Optional.ofNullable(realNeName));
            return self();
        }

        @Override
        public Optional<String> getNeighbourhoodId() {
            return super.neighbourhoodId;
        }

        @Override
        public NeOperationInitialData setNeighbourhoodId(String neighbourhoodId) {
            setNeighbourhoodId(Optional.ofNullable(neighbourhoodId));
            return self();
        }
        
        @Override
        public Optional<String> getAdditionalTypeInfo() {
            return super.additionalTypeInfo;
        }

        @Override
        public NeOperationInitialData setAdditionalTypeInfo(String additionalTypeInfo) {
            super.setAdditionalTypeInfo(Optional.ofNullable(additionalTypeInfo));
            return self();
        }
        
        @Override
        public Optional<GatewayMode> getGatewayMode() {
            return super.gatewayMode;
        }

        @Override
        public NeOperationInitialData setGatewayMode(GatewayMode gatewayRole) {
            super.setGatewayMode(Optional.ofNullable(gatewayRole));
            return self();
        }
    }

    /**
     * Helper class for building instances of {@link NeOperationData}.
     */
    public abstract static class NeOperationPrototype<T extends NeOperationPrototype<T>> {

        private Optional<String> iconId = Optional.empty();
        private Optional<WriteAccessMode> writeAccess = Optional.empty();
        private Optional<OperationalMode> operational = Optional.empty();
        private Optional<Boolean> eventForwardingMode = Optional.empty();
        private Optional<CommissioningMode> commissioning = Optional.empty();
        private Optional<String> family = Optional.empty();
        private Optional<String> mainRelease = Optional.empty();
        private Optional<String> maintenanceRelease = Optional.empty();
        private Optional<TpGroupSettings> tpGroupMode = Optional.empty();
        private Optional<Long> tpGroupMask = Optional.empty();
        private Optional<String> neSubType = Optional.empty();
        private Optional<String> neSubTypeDescription = Optional.empty();
        private Optional<String> neType = Optional.empty();
        private Optional<String> neSpecificType = Optional.empty();
        private Optional<String> realNeName = Optional.empty();
        private Optional<String> neighbourhoodId = Optional.empty();
        private Optional<String> location = Optional.empty();
        private Optional<String> additionalTypeInfo = Optional.empty();
        private Optional<GatewayMode> gatewayMode = Optional.empty();


        protected NeOperationPrototype() {

        }

        protected NeOperationPrototype(@Nonnull NeOperationPrototype<?> other) {
            iconId = other.iconId;
            writeAccess = other.writeAccess;
            operational = other.operational;
            eventForwardingMode = other.eventForwardingMode;
            commissioning = other.commissioning;
            family = other.family;
            mainRelease = other.mainRelease;
            maintenanceRelease = other.maintenanceRelease;
            tpGroupMode = other.tpGroupMode;
            tpGroupMask = other.tpGroupMask;
            neSubType = other.neSubType;
            neSubTypeDescription = other.neSubTypeDescription;
            neType = other.neType;
            neSpecificType = other.neSpecificType;
            realNeName = other.realNeName;
            neighbourhoodId = other.neighbourhoodId;
            location = other.location;
            additionalTypeInfo = other.additionalTypeInfo;
            gatewayMode = other.gatewayMode;
        }

        protected abstract T self();

        /**
         * @param writeAccess New write access status.
         */
        public T setWriteAccess(Optional<WriteAccessMode> writeAccess) {
            this.writeAccess = writeAccess;
            return self();
        }

        /**
         * @param operational New operational mode.
         */
        public T setOperational(Optional<OperationalMode> operational) {
            this.operational = operational;
            return self();
        }

        /**
         * @param eventForwardingMode Whether event forwarding is active.
         */
        public T setEventForwardingMode(Optional<Boolean> eventForwardingMode) {
            this.eventForwardingMode = eventForwardingMode;
            return self();
        }

        /**
         * @param commissioning New commissioning status.
         */
        public T setCommissioning(Optional<CommissioningMode> commissioning) {
            this.commissioning = commissioning;
            return self();
        }

        /**
         * @param family New NE family name.
         */
        public T setFamily(Optional<String> family) {
            this.family = family;
            return self();
        }

        /**
         * @param mainRelease New software main release identifier.
         */
        public T setMainRelease(Optional<String> mainRelease) {
            this.mainRelease = mainRelease;
            return self();
        }

        /**
         * @param maintenanceRelease New software maintenance release identifier.
         */
        public T setMaintenanceRelease(Optional<String> maintenanceRelease) {
            this.maintenanceRelease = maintenanceRelease;
            return self();
        }

        /**
         * @param tpGroupMode New TP grouping configuration.
         */
        public T setTpGroupMode(Optional<TpGroupSettings> tpGroupMode) {
            this.tpGroupMode = tpGroupMode;
            return self();
        }

        /**
         * @param tpGroupMask New TP grouping.
         */
        public T setTpGroupMask(Optional<Long> tpGroupMask) {
            this.tpGroupMask = tpGroupMask;
            return self();
        }

        /**
         * @param neSubType New NE sub type.
         */
        public T setNeSubType(Optional<String> neSubType) {
            this.neSubType = neSubType;
            return self();
        }

        /**
         * @param neSubTypeDescription New NE sub type description.
         */
        public T setNeSubTypeDescription(Optional<String> neSubTypeDescription) {
            this.neSubTypeDescription = neSubTypeDescription;
            return self();
        }

        /**
         * @param neType New NE type.
         */
        public T setNeType(Optional<String> neType) {
            this.neType = neType;
            return self();
        }

        /**
         * @param neSpecificType New NE specific type.
         */
        public T setNeSpecificType(Optional<String> neSpecificType) {
            this.neSpecificType = neSpecificType;
            return self();
        }

        /**
         * @param realNeName New NE name, as set in the hardware.
         */
        public T setRealNeName(Optional<String> realNeName) {
            this.realNeName = realNeName;
            return self();
        }

        /**
         * @param iconId New NE icon identifier.
         */
        public T setIconId(Optional<String> iconId) {
            this.iconId = iconId;
            return self();
        }

        /**
         * @param neighbourhoodId New NE neighbourhood identification.
         */
        public T setNeighbourhoodId(Optional<String> neighbourhoodId) {
            this.neighbourhoodId = neighbourhoodId;
            return self();
        }

        /**
         * @param location NE Location
         */
        public T setLocation(Optional<String> location) {
            this.location = location;
            return self();
        }
        
        /**
         * @param additionalTypeInfo New NE additional Type Info.
         */
        public T setAdditionalTypeInfo(Optional<String> additionalTypeInfo) {
            this.additionalTypeInfo = additionalTypeInfo;
            return self();
        }
        
        /**
         * @param gatewayRole New NE gateway role.
         */
        public T setGatewayMode(Optional<GatewayMode> gatewayMode) {
            this.gatewayMode = gatewayMode;
            return self();
        }
        

    }
}
