package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.google.common.base.Objects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * <p>Describes all changes requested to an instance of {@link MutationInfoData}.</p>
 * <p>Like all mutation descriptors, this class is not thread safe.</p>
 */
public class MediatorPhysicalDataMutationDescriptor
        extends MutationDescriptor<MediatorPhysicalData, MediatorPhysicalDataMutationDescriptor> {

    private Optional<Integer> priority = Optional.empty();
    private Optional<String> host = Optional.empty();

    /**
     * Creates a new mutation descriptor object.
     * @param target Target instance for the mutation.
     */
    public MediatorPhysicalDataMutationDescriptor(@Nonnull MediatorPhysicalData target) {
        super(target);
    }

    @Override
    protected MediatorPhysicalDataMutationDescriptor self() {
        return this;
    }

    @Override
    protected MediatorPhysicalData doApply() {
        return priority.isPresent() || host.isPresent()
                ? new MediatorPhysicalDataBuilder()
                    .setHost(host.orElse(getTarget().getHost()))
                    .setPriority(priority.orElse(getTarget().getPriority()))
                    .build(getTarget().getId(), getTarget().getLogicalMediatorId(), getTarget().getVersion() + 1)
                : getTarget();
    }

    /**
     * @return New mediator host name in the network.
     */
    public Optional<String> getHost() {
        return host;
    }

    /**
     * @param host New mediator host name in the network.
     */
    public MediatorPhysicalDataMutationDescriptor setHost(@Nonnull String host) {
        if (!Objects.equal(this.host.orElse(getTarget().getHost()), host)) {
            this.host = Optional.of(host);
        }
        return this;
    }

    /**
     * @return The new instance priority in the redundancy list.
     */
    public Optional<Integer> getPriority() {
        return priority;
    }

    /**
     * @param priority The new instance priority in the redundancy list.
     */
    public MediatorPhysicalDataMutationDescriptor setPriority(int priority) {
        if (this.priority.orElse(getTarget().getPriority()) != priority) {
            this.priority = Optional.of(priority);
        }
        return self();
    }

}
