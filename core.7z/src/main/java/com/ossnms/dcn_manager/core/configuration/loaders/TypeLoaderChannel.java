package com.ossnms.dcn_manager.core.configuration.loaders;

import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.DefaultPropertyValues;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.jaxb.emtype.Config;

import java.net.URL;

import static com.ossnms.dcn_manager.core.configuration.loaders.XmlConfiguration.unmarshal;

public class TypeLoaderChannel extends TypesLoader<ChannelType> {

    private final Types<NeType> neTypes;
    private final DefaultPropertyValues defaultPropertyValues;

    public TypeLoaderChannel(Types<NeType> neTypes, DefaultPropertyValues defaultPropertyValues) {
        this.neTypes = neTypes;
        this.defaultPropertyValues = defaultPropertyValues;
    }

    @Override ChannelType buildType(URL sourceUrl) {
        Config configuration = unmarshal(Config.class, sourceUrl, new Config());
        return new ChannelType(configuration, neTypes, defaultPropertyValues);
    }
}
