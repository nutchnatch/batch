/**
 * <p>Contains data and behavior concerning the management of all NE System Container domain entities.</p>
 *
 * <p>System Containers are specializations of DCN Containers and also follow simple rules:</p>
 * <ul>
 * <li>They have unique names.</li>
 * <li>They may contain zero or more NEs.</li>
 * <li>They may be children of generic DCN Containers only.</li>
 * <li>They are not associated to Channels or Mediators.</li>
 * <li>They may not contain other Containers.</li>
 * </ul>
 *
 */
package com.ossnms.dcn_manager.core.entities.container.system;

