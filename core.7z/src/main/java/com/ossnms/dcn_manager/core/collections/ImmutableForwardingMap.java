package com.ossnms.dcn_manager.core.collections;

import com.google.common.collect.ForwardingMap;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;

import static com.google.common.base.Predicates.in;
import static com.google.common.collect.Maps.filterKeys;

/**
 * An immutable map which forwards all its calls to another map. Attempts to modify the 
 * map will result in {@code UnsupportedOperationException} exceptions.
 *
 * @see ForwardingMap
 */
public abstract class ImmutableForwardingMap<K, V> extends ForwardingMap<K, V> {

    @Override
    public V put(K key, V value) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void putAll(Map<? extends K, ? extends V> map) {
        throw new UnsupportedOperationException();
    }

    @Override
    public V remove(Object object) {
        throw new UnsupportedOperationException();
    }

    /**
     * @return A view over the current map that contains only the
     * entries associated with the keys provided.
     */
    @Nonnull
    public Map<K, V> forKeys(@Nonnull Collection<K> keys) {
        return filterKeys(delegate(), in(keys));
    }


}
