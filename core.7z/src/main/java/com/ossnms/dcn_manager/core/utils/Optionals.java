package com.ossnms.dcn_manager.core.utils;

import com.google.common.base.Function;
import com.google.common.base.Predicate;

import java.util.Optional;
import java.util.function.BiConsumer;

/**
 * Utility class that provides predicates and functions useful when
 * working with streams of {@link Optional} instances.
 */
public enum Optionals {
    ;

    /**
     * @return A {@link Predicate} that succeeds when the {@link Optional}
     * instance is not {@code null} and its {@link Optional#isPresent()} method
     * returns {@code true}.
     */
    public static <T extends Optional<?>> Predicate<T> isPresent() {
        return new IsPresent<>();
    }

    /**
     * @return The object instance contained by the {@link Optional}
     * instance or {@code null}.
     * @see Optional#orElse
     */
    public static <T> Function<Optional<? extends T>, T> dereference() {
        return input -> null != input ? input.orElse(null) : null;
    }

    /**
     * Performs an action depending on presence of values
     *
     * @param forBoth    action to perform when both are present
     * @param forLeft    action to perform when only left is present
     * @param forRight   action to perform when only right is present
     * @param forNeither action to perform when none is present
     */
    public static <L, R> void forPresent(Optional<L> left, Optional<R> right,
                                         BiConsumer<L, R> forBoth,
                                         java.util.function.Consumer<L> forLeft,
                                         java.util.function.Consumer<R> forRight,
                                         Runnable forNeither) {
        if (left.isPresent() && right.isPresent()) {
            forBoth.accept(left.get(), right.get());
        } else if (left.isPresent()) {
            forLeft.accept(left.get());
        } else if (right.isPresent()) {
            forRight.accept(right.get());
        } else {
            forNeither.run();
        }
    }

}
