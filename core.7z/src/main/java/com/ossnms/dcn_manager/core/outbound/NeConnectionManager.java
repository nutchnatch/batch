package com.ossnms.dcn_manager.core.outbound;

import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;

import javax.annotation.Nonnull;
import java.util.Map;

/**
 * Manages NEs connections for outbound resources.
 */
public interface NeConnectionManager {

    /**
     * <p>Activates the selected NE.</p>
     *
     * @param event Activation event, carrying all necessary information for activation.
     */
    void activate(@Nonnull Activate event);

    /**
     * Deactivates the selected NE.
     *
     * @param event Deactivation event, carrying all necessary information for deactivation.
     */
    void deactivate(@Nonnull Deactivate event);

    /**
     * Initializes the selected NE lazily.
     * This means that an initialization will only be requested
     * if the mediation reports that it is not initialized.
     * Should the mediation report that it is already initialized
     * then this request is a no-op (with the exception of the
     * relevant outbound events).
     *
     * @param event Initialization event, carrying all necessary information.
     */
    void lazyInitialize(@Nonnull NeSynchronizationEvent event);

    /**
     * Always initializes the selected NE regardless of the
     * current mediation initialization status.
     *
     * @param event Initialization event, carrying all necessary information.
     */
    void alwaysInitialize(@Nonnull NeSynchronizationEvent event);

    /**
     * Sends a set of changed property values to the mediator.
     *
     * @param ne                     The target NE.
     * @param neInstance             The target physical NE connection.
     * @param newPreferences         New NE preferences, as set by the original property map.
     * @param updatedEmptyProperties
     * @throws ConnectException Should an error occur while communicating with the mediator
     *                          or south-bound components.
     */
    void updateNeProperties(
            @Nonnull NeEntity ne, @Nonnull NePhysicalConnectionData neInstance,
            @Nonnull NeUserPreferencesMutationDescriptor newPreferences, Map<String, String> updatedEmptyProperties)
            throws ConnectException;

}
