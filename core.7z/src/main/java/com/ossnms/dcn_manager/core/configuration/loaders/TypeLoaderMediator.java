package com.ossnms.dcn_manager.core.configuration.loaders;

import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.DefaultPropertyValues;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.jaxb.mediatortype.Config;

import java.net.URL;

import static com.ossnms.dcn_manager.core.configuration.loaders.XmlConfiguration.unmarshal;

public class TypeLoaderMediator extends TypesLoader<MediatorType> {

    private final Types<ChannelType> channelTypes;
    private final DefaultPropertyValues defaultPropertyValues;

    public TypeLoaderMediator(Types<ChannelType> channelTypes, DefaultPropertyValues defaultPropertyValues) {
        this.channelTypes = channelTypes;
        this.defaultPropertyValues = defaultPropertyValues;
    }

    @Override MediatorType buildType(URL sourceUrl) {
        Config configuration = unmarshal(Config.class, sourceUrl, new Config());
        return new MediatorType(configuration, defaultPropertyValues, channelTypes);
    }
}
