package com.ossnms.dcn_manager.core.entities.ne.data.types;

/**
 * Represents the current mode of the physical connection, used to
 * implement subtle differences in behavior when reacting to some
 * events.
 */
public enum ActualActivationMode {

    /** Standard operation: full initialization after Connected. */
    STANDARD,
    /** Recovering from connection lost after initialization: delta initialization after Connected. */
    CONNECT_RECOVER,
    /** NE initialization has failed for some reason. Automatic remedies may take place. */
    INIT_RECOVER,
    /** NE connection reset requested: initiate NE connection shutdown and initiate a startup after Disconnected (aka GX1813). */
    RESTART

}
