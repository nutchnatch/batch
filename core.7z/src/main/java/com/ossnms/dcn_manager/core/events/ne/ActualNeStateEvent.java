package com.ossnms.dcn_manager.core.events.ne;

import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import java.util.Objects;
import java.util.Optional;


/**
 * <p>
 * Used to signal actual NE activation state changes. Derived class instances represent specific NE
 * activation events as reported by the mediation. Most mediation events are mapped in order to
 * enable tracking of NE activation progress.
 * <br />
 * The following figure depicts the class hierarchy.
 * </p>
 *
 * <p> <figure>
 * <img src="doc-files/ne_actual_activation_state_event-class.png">
 * <figcaption>Class diagram of the events related to operations performed on actual NE state domain
 * objects</figcaption>
 * </figure> </p>
 *
 * <p>
 * The abstract base class ({@link ActualNeStateEvent}) defines the information associated to all
 * concrete events. Instead of materializing these concrete event types as derived top-level classes, which would
 * increase the overall solution's complexity (i.e. the total number of top-level classes), concrete event
 * types are materialized as static nested classes, leading to a curious coding pattern in which derived
 * classes are public nested classes of its super class. <br />
 * Despite being a curious coding pattern, the resulting solution reduces overall complexity and increases
 * readability: all related types are contained within the same compilation unit which, given its small size,
 * is not affected by significant complexity increase.
 * </p>
 */
/*
 * @startuml doc-files/channel_actual_activation_state_event-class.png
 * abstract class ActualNeStateEvent <<Immutable>> {
 *      # ActualNeStateEvent(neId: int)
 *      # ActualNeStateEvent(neId: int, description: String)
 * }
 * class NeConnectingEvent <<Immutable>> {
 *      + NeConnectingEvent(neId: int)
 *      + NeConnectingEvent(neId: int, description: String)
 * }
 * class NeConnectedEvent <<Immutable>> {
 *      + NeConnectedEvent(neId: int)
 *      + NeConnectedEvent(neId: int, description: String)
 * }
 * class NeDisconnectingEvent <<Immutable>> {
 *      + NeDisconnectingEvent(neId: int)
 *      + NeDisconnectingEvent(neId: int, description: String)
 * }
 * class NeDisconnectedEvent <<Immutable>> {
 *      + NeDisconnectedEvent(neId: int)
 *      + NeDisconnectedEvent(neId: int, description: String)
 * }
 * class NeInitializingEvent <<Immutable>> {
 *      + NeInitializingEvent(neId: int)
 *      + NeInitializingEvent(neId: int, description: String)
 * }
 * class NeInitializedEvent <<Immutable>> {
 *      + NeInitializedEvent(neId: int)
 *      + NeInitializedEvent(neId: int, description: String)
 * }
 * class NeActivationFailedEvent <<Immutable>> {
 *      + NeActivationFailedEvent(neId: int)
 *      + NeActivationFailedEvent(neId: int, description: String)
 * }
 * class NeStartingUpEvent <<Immutable>> {
 *      + NeStartingUpEvent(neId: int)
 *      + NeStartingUpEvent(neId: int, description: String)
 * }
 * class NeShuttingDownEvent <<Immutable>> {
 *      + NeShuttingDownEvent(neId: int)
 *      + NeShuttingDownEvent(neId: int, description: String)
 * }
 * ChannelEvent <<Immutable>> <|-- ActualNeStateEvent
 * hide ChannelEvent members
 * ActualNeStateEvent <|-- NeConnectingEvent
 * ActualNeStateEvent <|-- NeConnectedEvent
 * ActualNeStateEvent <|-- NeDisconnectingEvent
 * ActualNeStateEvent <|-- NeDisconnectedEvent
 * ActualNeStateEvent <|-- NeInitializingEvent
 * ActualNeStateEvent <|-- NeInitializedEvent
 * ActualNeStateEvent <|-- NeActivationFailedEvent
 * ActualNeStateEvent <|-- NeStartingUpEvent
 * ActualNeStateEvent <|-- NeShuttingDownEvent
 * @enduml
 */
@Immutable
public abstract class ActualNeStateEvent extends NeEvent {

    private final PhysicalNeStateEvent originatingPhysicalEvent;

    /**
     * Initiates an instance with the given arguments.
     * @param neId The affected NE identifier.
     */
    protected ActualNeStateEvent(int neId) {
        super(neId);
        originatingPhysicalEvent = null;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param neId The affected NE identifier.
     * @param detailedDescription Human-readable event description.
     */
    protected ActualNeStateEvent(int neId, @Nonnull String detailedDescription) {
        super(neId, detailedDescription);
        originatingPhysicalEvent = null;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param neId The affected NE identifier.
     * @param originatingEvent The physical event that originated this logical event.
     */
    protected ActualNeStateEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent) {
        super(neId);
        originatingPhysicalEvent = originatingEvent;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param neId The affected NE identifier.
     * @param originatingEvent The physical event that originated this logical event.
     * @param detailedDescription Human-readable event description.
     */
    protected ActualNeStateEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent, @Nonnull String detailedDescription) {
        super(neId, detailedDescription);
        originatingPhysicalEvent = originatingEvent;
    }

    /**
     * @return The originating physical event, if present.
     */
    public Optional<PhysicalNeStateEvent> getOriginatingPhysicalEvent() {
        return Optional.ofNullable(originatingPhysicalEvent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNeId(), getDetailedDescription(), originatingPhysicalEvent);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final ActualNeStateEvent rhs = (ActualNeStateEvent) obj;
        return new EqualsBuilder()
                .append(getNeId(), rhs.getNeId())
                .append(getDetailedDescription(), rhs.getDetailedDescription())
                .append(originatingPhysicalEvent, rhs.originatingPhysicalEvent)
                .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("originatingPhysicalEvent", originatingPhysicalEvent)
                .toString();
    }

    /**
     * Class whose instances represent events used to signal that a NE is disconnecting.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class NeDisconnectingEvent extends ActualNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         */
        public NeDisconnectingEvent(int neId) {
            super(neId);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param detailedDescription Human-readable event description.
         */
        public NeDisconnectingEvent(int neId, String detailedDescription) {
            super(neId, detailedDescription);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         */
        public NeDisconnectingEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent) {
            super(neId, originatingEvent);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         * @param detailedDescription Human-readable event description.
         */
        public NeDisconnectingEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent, @Nonnull String detailedDescription) {
            super(neId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE has disconnected.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class NeDisconnectedEvent extends ActualNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         */
        public NeDisconnectedEvent(int neId) {
            super(neId);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param detailedDescription Human-readable event description.
         */
        public NeDisconnectedEvent(int neId, String detailedDescription) {
            super(neId, detailedDescription);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         */
        public NeDisconnectedEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent) {
            super(neId, originatingEvent);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         * @param detailedDescription Human-readable event description.
         */
        public NeDisconnectedEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent, @Nonnull String detailedDescription) {
            super(neId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE has connected.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class NeConnectedEvent extends ActualNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         */
        public NeConnectedEvent(int neId) {
            super(neId);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param detailedDescription Human-readable event description.
         */
        public NeConnectedEvent(int neId, String detailedDescription) {
            super(neId, detailedDescription);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         */
        public NeConnectedEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent) {
            super(neId, originatingEvent);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         * @param detailedDescription Human-readable event description.
         */
        public NeConnectedEvent(int neId, String detailedDescription, @Nonnull PhysicalNeStateEvent originatingEvent) {
            super(neId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE is connecting.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class NeConnectingEvent extends ActualNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         */
        public NeConnectingEvent(int neId) {
            super(neId);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param detailedDescription Human-readable event description.
         */
        public NeConnectingEvent(int neId, String detailedDescription) {
            super(neId, detailedDescription);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         */
        public NeConnectingEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent) {
            super(neId, originatingEvent);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         * @param detailedDescription Human-readable event description.
         */
        public NeConnectingEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent, String detailedDescription) {
            super(neId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE is initializing.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class NeInitializingEvent extends ActualNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         */
        public NeInitializingEvent(int neId) {
            super(neId);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param detailedDescription Human-readable event description.
         */
        public NeInitializingEvent(int neId, String detailedDescription) {
            super(neId, detailedDescription);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         */
        public NeInitializingEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent) {
            super(neId, originatingEvent);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         * @param detailedDescription Human-readable event description.
         */
        public NeInitializingEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent, String detailedDescription) {
            super(neId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE is initialized.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class NeInitializedEvent extends ActualNeStateEvent {

        private final NeSynchronizationData synchronizationDataDifferences;

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         */
        public NeInitializedEvent(int neId) {
            super(neId);
            this.synchronizationDataDifferences = null;
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param detailedDescription Human-readable event description.
         */
        public NeInitializedEvent(int neId, String detailedDescription) {
            super(neId, detailedDescription);
            this.synchronizationDataDifferences = null;
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         */
        public NeInitializedEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent) {
            super(neId, originatingEvent);
            this.synchronizationDataDifferences = null;
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         * @param synchronizationDataDifferences The calculated difference between any NE synchronization counters
         *                                       received from mediation and any values currently stored by DCN Manager.
         */
        public NeInitializedEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent, @Nullable NeSynchronizationData synchronizationDataDifferences) {
            super(neId, originatingEvent);
            this.synchronizationDataDifferences = synchronizationDataDifferences;
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         * @param detailedDescription Human-readable event description.
         */
        public NeInitializedEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent, String detailedDescription) {
            super(neId, originatingEvent, detailedDescription);
            this.synchronizationDataDifferences = null;
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param synchronizationDataDifferences The calculated difference between any NE synchronization counters
         *                                       received from mediation and any values currently stored by DCN Manager.
         */
        public NeInitializedEvent(int neId, @Nullable NeSynchronizationData synchronizationDataDifferences) {
            super(neId);
            this.synchronizationDataDifferences = synchronizationDataDifferences;
        }

        /**
         * @return The difference between any NE synchronization counters received from mediation
         * and any values currently stored by DCN Manager.
         */
        public Optional<NeSynchronizationData> getSynchronizationDataDifferences() {
            return Optional.ofNullable(synchronizationDataDifferences);
        }

        @Override
        public int hashCode() {
            return Objects.hash(super.hashCode(), synchronizationDataDifferences);
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (null == obj || !getClass().equals(obj.getClass())) {
                return false;
            }
            final NeInitializedEvent rhs = (NeInitializedEvent) obj;
            return new EqualsBuilder()
                    .append(getNeId(), rhs.getNeId())
                    .append(getDetailedDescription(), rhs.getDetailedDescription())
                    .append(getOriginatingPhysicalEvent(), rhs.getOriginatingPhysicalEvent())
                    .append(synchronizationDataDifferences, rhs.synchronizationDataDifferences)
                    .isEquals();
        }

        @Override
        public String toString() {
            return new ToStringBuilder(this)
                    .appendSuper(super.toString())
                    .append("synchronizationDataDifferences", synchronizationDataDifferences)
                    .toString();
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE is starting up (pending connection).
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class NeStartingUpEvent extends ActualNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         */
        public NeStartingUpEvent(int neId) {
            super(neId);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param detailedDescription Human-readable event description.
         */
        public NeStartingUpEvent(int neId, String detailedDescription) {
            super(neId, detailedDescription);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         */
        public NeStartingUpEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent) {
            super(neId, originatingEvent);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         * @param detailedDescription Human-readable event description.
         */
        public NeStartingUpEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent, String detailedDescription) {
            super(neId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE is shutting down (pending disconnection).
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class NeShuttingDownEvent extends ActualNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         */
        public NeShuttingDownEvent(int neId) {
            super(neId);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param detailedDescription Human-readable event description.
         */
        public NeShuttingDownEvent(int neId, String detailedDescription) {
            super(neId, detailedDescription);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         */
        public NeShuttingDownEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent) {
            super(neId, originatingEvent);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         * @param detailedDescription Human-readable event description.
         */
        public NeShuttingDownEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent, String detailedDescription) {
            super(neId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Maps all mediation failure events related to activation: connection
     * failure, initialization failure, synchronization lost... As far as
     * we're concerned, an NE is in a failed state regardless of the exact
     * failure condition.
     */
    @Immutable
    public static final class NeActivationFailedEvent extends ActualNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         */
        public NeActivationFailedEvent(int neId) {
            super(neId);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param detailedDescription Human-readable event description.
         */
        public NeActivationFailedEvent(int neId, String detailedDescription) {
            super(neId, detailedDescription);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         */
        public NeActivationFailedEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent) {
            super(neId, originatingEvent);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param neId The affected NE identifier.
         * @param originatingEvent The physical event that originated this logical event.
         * @param detailedDescription Human-readable event description.
         */
        public NeActivationFailedEvent(int neId, @Nonnull PhysicalNeStateEvent originatingEvent, String detailedDescription) {
            super(neId, originatingEvent, detailedDescription);
        }
    }
}
