package com.ossnms.dcn_manager.core.entities.ne.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import com.google.common.base.Strings;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.DataTransferSettingsAdapter;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.DirectRouteAdapter;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.utils.ClearableOptional;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Contains all data that should be changed on {@link NeUserPreferencesData},
 * when applied as a single atomic mutation by the repository.
 */
/**
 * @author vveloso
 *
 */
public class NeUserPreferencesMutationDescriptor
        extends DynamicBusinessObjectMutationDescriptor<NeUserPreferencesData, NeUserPreferencesMutationDescriptor>
        implements NePropertySetters<NeUserPreferencesMutationDescriptor> {

    private Optional<String> idName = Optional.empty();
    private Optional<Boolean> usesGne = Optional.empty();
    private Optional<Boolean> usesFlatIp = Optional.empty();
    private Optional<Integer> reconnectInterval = Optional.empty();
    private Optional<String> globalId = Optional.empty();
    private Optional<String> userName = Optional.empty();
    private Optional<String> userText = Optional.empty();
    private Optional<String> password = Optional.empty();
    private DataTransferSettingsAdapter dataTransferSettingsAdapter = new DataTransferSettingsAdapter();
    private Optional<RouteSortingMode> routeSortingMode = Optional.empty();
    private ClearableOptional<Integer> containerId = ClearableOptional.absent();

    private final Map<String, String> routePropertyBag = new HashMap<>();
    private ClearableOptional<String> routeKey = ClearableOptional.absent();

    public NeUserPreferencesMutationDescriptor(NeUserPreferencesData target) {
        super(target);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .omitNullValues()
                .add("idName", idName.orElse(null))
                .add("usesGne", usesGne.orElse(null))
                .add("usesFlatIp", usesFlatIp.orElse(null))
                .add("reconnectInterval", reconnectInterval.orElse(null))
                .add("globalId", globalId.orElse(null))
                .add("directRouteKey", routeKey.orNull())
                .add("containerId", containerId.orNull())
                .add("directRouteProperties", routePropertyBag.isEmpty() ? null : routePropertyBag)
                .addValue(super.toString())
                .toString();
    }

    @Override
    protected NeUserPreferencesMutationDescriptor self() {
        return this;
    }

    @Override
    protected NeUserPreferencesData doApply() {
        final Map<String, String> properties = getProperties();
        if (isDirectRouteChanged() || isDataTransferSettingsChanged() || isChanged() || !properties.isEmpty()) {
            final RouteSortingMode currentRouteSortingMode = routeSortingMode.orElse(getTarget().getRouteSortingMode());
            final NeUserPreferencesBuilder builder = new NeUserPreferencesBuilder()
                .setName(idName.orElse(getTarget().getName()))
                .setUsesGne(usesGne.orElse(getTarget().usesGne()))
                .setUsesFlatIp(usesFlatIp.orElse(getTarget().usesFlatIp()))
                .setReconnectInterval(reconnectInterval.orElse(getTarget().getReconnectInterval()))
                .setGlobalId(globalId.map(Optional::of).orElse(getTarget().getGlobalId()))
                .setProperties(getTarget().getAllOpaqueProperties())
                .setUserName(userName.map(Optional::of).orElse(getTarget().getUserName()))
                .setUserText(userText.map(Optional::of).orElse(getTarget().getUserText()))
                .setPassword(password.map(Optional::of).orElse(getTarget().getPassword()))
                .setContainerId(containerId.or(getTarget().getContainerId()))
                .enableRouteSorting(currentRouteSortingMode != RouteSortingMode.NONE)
                .enableRouteSortingByUsage(currentRouteSortingMode == RouteSortingMode.AUTO_PRIORITY)
                .setDataTransferSettings(dataTransferSettingsAdapter.mergeWith(getTarget().getDataTransferSettings()))
                .setProperties(properties);

            builder.getDirectRouteAdapter()
                .setKey(calculateDirectRouteKey())
                .setProperties(getTarget().getDirectRoute().getAllOpaqueProperties())
                .setProperties(routePropertyBag);

            return builder.build(getTarget().getId(), getTarget().getVersion());
        }
        return getTarget();
    }

    private String calculateDirectRouteKey() {
        final String existingKey = getTarget().getDirectRoute().getKey();
        return routeKey.or(Optional.ofNullable(existingKey)).orElse(null);
    }

    private boolean isChanged() {
        return isIdentificationChanged() || isAuthenticationChanged() ||
               isConnectionConfigurationChanged() || userText.isPresent();
    }

    private boolean isConnectionConfigurationChanged() {
        return usesGne.isPresent() || reconnectInterval.isPresent() || routeSortingMode.isPresent() || usesFlatIp.isPresent();
    }

    private boolean isIdentificationChanged() {
        return idName.isPresent() || globalId.isPresent() || containerId.isPresent();
    }

    private boolean isAuthenticationChanged() {
        return userName.isPresent() || password.isPresent();
    }

    private boolean isDirectRouteChanged() {
        return !routePropertyBag.isEmpty() || routeKey.isPresent();
    }

    private boolean isDataTransferSettingsChanged() {
        return dataTransferSettingsAdapter.getIpAddress().isPresent() || dataTransferSettingsAdapter.getIsScp().isPresent() ||
               dataTransferSettingsAdapter.getPassword().isPresent()|| dataTransferSettingsAdapter.getUploadpath().isPresent() ||
               dataTransferSettingsAdapter.getUsername().isPresent();
    }
    
    /**
     * @return NE name.
     */
    public Optional<String> getName() {
        return idName;
    }

    /**
     * @param idName New NE name.
     */
    @Override
    public NeUserPreferencesMutationDescriptor setName(@Nonnull String idName) {
        final Optional<String> newValue = Optional.of(idName);
        if (!Objects.equal(this.idName, newValue)) {
            this.idName = newValue;
        }
        return self();
    }

    /**
     * @return Whether the NE is behind a GNE.
     */
    public Optional<Boolean> getUsesGne() {
        return usesGne;
    }

    /**
     * @param usesGne Whether the NE is behind a GNE.
     */
    @Override
    public NeUserPreferencesMutationDescriptor setUsesGne(boolean usesGne) {
        final Optional<Boolean> newValue = Optional.of(usesGne);
        if (!Objects.equal(this.usesGne, newValue)) {
            this.usesGne = newValue;
        }
        return self();
    }

    /**
     * @return Whether the NE is connected by a Flat IP.
     */
    public Optional<Boolean> getUsesFlatIp() {
        return usesFlatIp;
    }

    /**
     * @param usesFlatIp Whether the NE is connected by a Flat IP.
     */
    @Override
    public NeUserPreferencesMutationDescriptor setUsesFlatIp(boolean usesFlatIp) {
        final Optional<Boolean> newValue = Optional.of(usesFlatIp);
        if (!Objects.equal(this.usesFlatIp, newValue)) {
            this.usesFlatIp = newValue;
        }
        return self();
    }

    /**
     * @return Time to wait between reconnection attempts.
     */
    public Optional<Integer> getReconnectInterval() {
        return reconnectInterval;
    }

    /**
     * @param reconnectInterval New reconnect interval.
     */
    @Override
    public NeUserPreferencesMutationDescriptor setReconnectInterval(int reconnectInterval) {
        final Optional<Integer> newValue = Optional.of(reconnectInterval);
        if (!Objects.equal(this.reconnectInterval, newValue)) {
            this.reconnectInterval = newValue;
        }
        return self();
    }

    /**
     * @return Global identifier.
     */
    public Optional<String> getGlobalId() {
        return globalId;
    }

    /**
     * @param globalId New global identifier.
     */
    @Override
    public NeUserPreferencesMutationDescriptor setGlobalId(@Nonnull Optional<String> globalId) {
        if (!Objects.equal(this.globalId, globalId)) {
            this.globalId = globalId;
        }
        return self();
    }

    @Override
    public NeDataTransferSettingsAdapter<?> getDataTransferSettingsAdapter() {
        return dataTransferSettingsAdapter;
    }
    
    @Override
    public NeRoutePropertyAdapter<?> getDirectRouteAdapter() {
        return new DirectRouteAdapter(routePropertyBag) {
            @Override
            public DirectRouteAdapter setKey(String newKey) {
                routeKey = Strings.isNullOrEmpty(newKey) ? ClearableOptional.clear() : ClearableOptional.of(newKey);
                return this;
            }

            @Override
            public Optional<String> getKey() {
                return routeKey.asOptional();
            }
        };
    }

    /**
     * @param userName New NE login user name.
     */
    @Override
    public NeUserPreferencesMutationDescriptor setUserName(@Nonnull Optional<String> userName) {
        if (!Objects.equal(this.userName, userName)) {
            this.userName = userName;
        }
        return self();
    }

    @Override
    public NeUserPreferencesMutationDescriptor setUserText(@Nonnull Optional<String> userText) {
        this.userText = userText;
        return self();
    }

    /**
     * @param password New NE login password.
     */
    @Override
    public NeUserPreferencesMutationDescriptor setPassword(@Nonnull Optional<String> password) {
        if (!Objects.equal(this.password, password)) {
            this.password = password;
        }
        return self();
    }

    /**
     * @return New NE login user name.
     */
    public Optional<String> getUserName() {
        return userName;
    }

    public Optional<String> getUserText() {
        return userText;
    }

    /**
     * @return New NE login password.
     */
    public Optional<String> getPassword() {
        return password;
    }

    /**
     * @return New gateway route sorting mode.
     */
    public Optional<RouteSortingMode> getRouteSortingMode() {
        return routeSortingMode;
    }

    /**
     * @param containerId New parent NE container identifier.
     */
    @Override
    public NeUserPreferencesMutationDescriptor setContainerId(Optional<Integer> containerId) {
        final ClearableOptional<Integer> newValue =
            containerId.isPresent() ? ClearableOptional.of(containerId) : ClearableOptional.clear();
        if (!Objects.equal(this.containerId, newValue)) {
            this.containerId = newValue;
        }
        return self();
    }

    /**
     * @param dataTransferSettings DataTransferSettings values.
     */
    @Override
    public NeUserPreferencesMutationDescriptor setDataTransferSettings(@Nonnull NeDataTransferSettingsAdapter<?> dataTransferSettings) {
        dataTransferSettingsAdapter = (DataTransferSettingsAdapter) dataTransferSettings;
        return self();
    }

    /**
     * Clears any existing parent NE container identifier.
     */
    public NeUserPreferencesMutationDescriptor clearContainerId() {
        containerId = ClearableOptional.clear();
        return self();
    }

    /**
     * @return New parent NE container identifier.
     */
    public Optional<Integer> getContainerId() {
        return containerId.asOptional();
    }

    /**
     * @param routeSortingMode New gateway route sorting mode.
     */
    @Override
    public NeUserPreferencesMutationDescriptor enableRouteSortingByUsage(@Nonnull boolean routeSortingMode) {
        final RouteSortingMode currentMode = getRouteSortingMode().orElse(getTarget().getRouteSortingMode());
        if (currentMode != RouteSortingMode.NONE) {
            this.routeSortingMode = Optional.of(
                    routeSortingMode ? RouteSortingMode.AUTO_PRIORITY : RouteSortingMode.DEFAULT);
        }
        return self();
    }

    /**
     * @param enabled Whether gateway route sorting should be enabled or disabled.
     */
    @Override
    public NeUserPreferencesMutationDescriptor enableRouteSorting(boolean enabled) {
        if (!enabled) {
            routeSortingMode = Optional.of(RouteSortingMode.NONE);
        } else {
            final RouteSortingMode currentMode = getRouteSortingMode().orElse(getTarget().getRouteSortingMode());
            if (currentMode == RouteSortingMode.NONE) {
                routeSortingMode = Optional.of(RouteSortingMode.DEFAULT);
            }
        }
        return self();
    }
}
