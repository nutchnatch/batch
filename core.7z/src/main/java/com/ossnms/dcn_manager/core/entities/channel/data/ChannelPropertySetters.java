package com.ossnms.dcn_manager.core.entities.channel.data;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Optional;

/**
 * Defines a contract that must be common across all classes that can receive property
 * data. It is intended to allow property management objects to set values both on
 * the mutation descriptors and initial domain object data parameter objects.
 *
 * @param <T> The final implementing type, to allow for a fluent API.
 */
public interface ChannelPropertySetters<T extends ChannelPropertySetters<T>> {

    /**
     * Sets the mutation's new name, to be assigned to the target channel.
     * @param newName The new name.
     * @throws IllegalArgumentException If the channel name is empty or null.
     */
    T setName(String newName);

    /**
     * Sets the mutation's new reconnect interval (expressed in minutes), to be assigned to the target channel.
     * @param reconnectInterval The new reconnect interval.
     */
    T setReconnectInterval(int reconnectInterval);

    /**
     * Stores a new property for the object. It will be stored in the property bag
     * without further handling.
     * @param name The name of the property to change.
     * @param value The new property value.
     */
    T setProperty(@Nonnull String name, @Nullable String value);

    /**
     * @param concurrentActivationsLimited Whether the number of concurrent activations should be limited.
     */
    T setConcurrentActivationsLimited(boolean concurrentActivationsLimited);

    /**
     * @param concurrentActivationsLimit The maximum number of concurrent activations that can be in progress
     *      at any time. Enforced only if {@code concurrentActivationsLimited} is true.
     */
    T setConcurrentActivationsLimit(int concurrentActivationsLimit);

    T setUserText(@Nonnull Optional<String> userText);
}