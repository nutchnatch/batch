/**
 * <p>Contains data and behavior concerning the management of all Channel domain entities, also named domain objects.
 * In the context of this component.</p>
 *
 * <p>Domain entities are immutable and they include the business logic associated to the modeled business entity (e.g.
 * the channel activation sequence is triggered by the domain entity that models the channel activation state). <br />
 * Immutability is used to attain thread-safety without the need to use defensive copying or synchronization.
 *
 * This
 * decision reduces dynamic complexity and because concurrency is addressed at the repository and domain entity instances
 * held by the repository may be
 * takes into account that updates are not frequent
 * </p>
 *
 * <p> Instead of using a modeling approach that captures the essence of the domain entities while disregarding the
 * context in which they are used, the set of domain objects is designed to promote locality of reference</p>
 *
 *
 * <figure>
 * <img src="doc-files/channel-entities-class.png">
 * <figcaption>Class diagram of the channel entity classes</figcaption>
 * </figure>
 */
/*
 * @startuml doc-files/channel-entities-class.png
 * class ChannelEntity <<immutable>> {
 * }
 * class ChannelInstance <<immutable>> {
 * }
 * class ChannelInfoData <<immutable>> {
 *  + channelId
 *  + mediatorId
 *  + type
 *  + isActivationRequired
 *  + coreId
 * }
 * class ChannelConnectionData <<immutable>> {
 *  + channelId
 *  + activation
 *  + additionalInfo
 * }
 * class ChannelUserPreferencesData <<immutable>> {
 *  + channelId
 *  + name
 *  + reconnectInterval
 *  + concurrentActivationsLimit
 *  + concurrentActivationsLimited
 * }
 * class ChannelPhysicalConnectionData <<immutable>> {
 *  + channelInstanceId
 *  + channelId
 *  + active
 *  + activation
 *  + additionalInfo
 *  + mediatorInstanceId
 * }
 * ChannelInfoData "1" --* ChannelEntity
 * ChannelConnectionData "1" --* ChannelEntity
 * ChannelUserPreferencesData "1" --* ChannelEntity
 * ChannelInstance *-- "1" ChannelPhysicalConnectionData
 * ChannelEntity *.. "1..n" ChannelInstance : Indirect relation\nthrough separate\nrepository.
 * @enduml
 */
package com.ossnms.dcn_manager.core.entities.channel;