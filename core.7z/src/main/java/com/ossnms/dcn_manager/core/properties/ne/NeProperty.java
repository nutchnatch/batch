package com.ossnms.dcn_manager.core.properties.ne;

import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNeDataTransferPropertyNames;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNeTypePropertyNames;
import com.ossnms.dcn_manager.core.properties.EntityPropertyOperations;

/**
 * Contains well known EM/NE property names as mentioned in the user interface description files.
 * Is also able to manage property retrieval from a merged set of NE Type and NE Instance
 * (NE entity) properties.
 */
public enum NeProperty implements EntityPropertyOperations {

    /* Well known NE Type properties. */

    DISPLAY_ADDRESS(new NePropertyOperations(WellKnownNeTypePropertyNames.DISPLAY_ADDRESS)),
    GLOBAL_NE_ID_RULE(new NePropertyOperations(WellKnownNeTypePropertyNames.GLOBAL_NE_ID)),
    CAPABILITIES(new NePropertyOperations(WellKnownNeTypePropertyNames.CAPABILITIES)),
    SUPPORTED_LAYERS(new NePropertyOperations(WellKnownNeTypePropertyNames.SUPPORTED_LAYERS)),

    /* Well known NE properties. */

    /** Unique NE name. */
    ID_NAME(new NePropertyOperations(WellKnownNePropertyNames.ID_NAME, Scope.PRIVATE)),

    NE_TYPE(new NePropertyOperations(WellKnownNePropertyNames.NE_TYPE)),
    USE_DEFAULT_ROUTE_SORTING(new NePropertyOperations(WellKnownNePropertyNames.USE_DEFAULT_ROUTE_SORTING)),

    /* These names are used internally and must be translated
     * at the public boundaries to and from the specific NE type nomenclature. */
    PARENT_NE_CONTAINER(new NePropertyOperations(WellKnownNePropertyNames.PARENT_NE_CONTAINER)),
    USES_GNE(new NePropertyOperations(WellKnownNePropertyNames.USES_GNE)),
    USES_FLAT_IP(new NePropertyOperations(WellKnownNePropertyNames.USES_FLAT_IP)),
    GATEWAY_MODE(new NePropertyOperations(WellKnownNePropertyNames.GATEWAY_MODE)),
    RECONNECT_INTERVAL(new NePropertyOperations(WellKnownNePropertyNames.RECONNECT_INTERVAL)),
    USER_NAME(new NePropertyOperations(WellKnownNePropertyNames.USER_NAME)),
    USER_PASSWORD(new NePropertyOperations(WellKnownNePropertyNames.USER_PASSWORD)),
    GLOBAL_NE_ID(new NePropertyOperations(WellKnownNePropertyNames.GLOBAL_NE_ID)),
    NEIGHBOURHOOD_ID(new NePropertyOperations(WellKnownNePropertyNames.NEIGHBOURHOOD_ID)),
    ADDITIONAL_TYPE_INFO(new NePropertyOperations(WellKnownNePropertyNames.ADDITIONAL_TYPE_INFO)),
    USER_TEXT(new NePropertyOperations(WellKnownNePropertyNames.USER_TEXT)),

    DATATRANSFER_USERNAME(new NePropertyOperations(WellKnownNeDataTransferPropertyNames.USERNAME)),
    DATATRANSFER_PASSWORD(new NePropertyOperations(WellKnownNeDataTransferPropertyNames.PASSWORD)),
    DATATRANSFER_UPLOADPATH(new NePropertyOperations(WellKnownNeDataTransferPropertyNames.UPLOADPATH)),
    DATATRANSFER_IP_ADDRESS(new NePropertyOperations(WellKnownNeDataTransferPropertyNames.IP_ADDRESS)),
    DATATRANSFER_IS_SCP(new NePropertyOperations(WellKnownNeDataTransferPropertyNames.IS_SCP)),
    DATATRANSFER_IS_FTP(new NePropertyOperations(WellKnownNeDataTransferPropertyNames.IS_FTP)),
    DATATRANSFER_PROFILE_NAME(new NePropertyOperations(WellKnownNeDataTransferPropertyNames.PROFILE_NAME));


    private final NePropertyOperations delegate;

    private NeProperty(NePropertyOperations delegate) {
        this.delegate = delegate;
    }

    @Override
    public String getName() {
        return delegate.getName();
    }

    @Override
    public Scope getScope() {
        return delegate.getScope();
    }

    @Override
    public String toString() {
        return delegate.toString();
    }
}
