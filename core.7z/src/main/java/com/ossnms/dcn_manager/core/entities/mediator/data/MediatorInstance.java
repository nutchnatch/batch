package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.google.common.base.Predicate;
import com.ossnms.dcn_manager.core.entities.PropertyBag;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * Aggregator class for all objects part of the Mediator Standby
 * object domain. They also belong to the Mediator object domain
 * at large, however the management is separate: standby information
 * refers to actual server instances whereas all other information
 * refers to logical server instances. TNMS will only see one
 * "virtual" server instance in any given point in time.
 */
public final class MediatorInstance implements PropertyBag {

    public static final int PRIMARY_PRIORITY_LEVEL = 0;

    private final MediatorPhysicalData physicalInfo;
    private final MediatorPhysicalConnectionData physicalConnection;

    public MediatorInstance(MediatorPhysicalData info, MediatorPhysicalConnectionData connection) {
        this.physicalInfo = info;
        this.physicalConnection = connection;
    }

    /**
     * @return Mediator server connection information.
     */
    public MediatorPhysicalData getPhysicalInfo() {
        return physicalInfo;
    }

    /**
     * @return Actual server connection/activation status.
     */
    public MediatorPhysicalConnectionData getConnection() {
        return physicalConnection;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.emne.core.entities.PropertyBag#getOpaqueProperty(java.lang.String)
     */
    @Override
    public Optional<String> getOpaqueProperty(String name) {
        return Optional.empty();
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.emne.core.entities.PropertyBag#getAllOpaqueProperties()
     */
    @Override
    public Map<String, String> getAllOpaqueProperties() {
        return Collections.emptyMap();
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return Objects.hash(physicalInfo, physicalConnection);
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || getClass() != obj.getClass()) {
            return false;
        }
        final MediatorInstance rhs = (MediatorInstance) obj;
        return new EqualsBuilder()
                .append(physicalInfo, rhs.physicalInfo)
                .append(physicalConnection, rhs.physicalConnection)
                .isEquals();
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append(physicalInfo)
                .append(physicalConnection)
                .toString();
    }

    public static final Predicate<MediatorInstance> IS_ACTIVE = new Predicate<MediatorInstance>() {
        @Override
        public boolean apply(MediatorInstance input) {
            return null != input && input.getConnection().isActive();
        }
    };

    public static final Predicate<MediatorInstance> IS_PRIMARY = new Predicate<MediatorInstance>() {
        @Override
        public boolean apply(MediatorInstance input) {
            return null != input && input.getPhysicalInfo().getPriority() == PRIMARY_PRIORITY_LEVEL;
        }
    };

}
