package com.ossnms.dcn_manager.core.configuration.loaders;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import com.ossnms.dcn_manager.core.configuration.model.Type;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URL;

import static com.google.common.base.Strings.isNullOrEmpty;

abstract class TypesLoader<T extends Type> {
    private static final Logger LOGGER = LoggerFactory.getLogger(TypesLoader.class);


    public Types<T> load(Iterable<URL> typeUrls) {
        final Builder<String, T> builder = ImmutableMap.builder();
        for (final URL url : typeUrls) {
            final T type = buildType(url);
            final String typeName = type.getName();
            if (!isNullOrEmpty(typeName)) {
                builder.put(typeName, type);
            } else {
                LOGGER.warn("Type for {} is being discarded because it does not have a name.", url);
            }
        }

        return Types.from(builder.build());
    }

    abstract T buildType(URL sourceUrl);
}
