package com.ossnms.dcn_manager.core.entities.ne.data;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;
import java.util.Optional;

/**
 * Defines a contract that must be common across all classes that can receive property
 * data. It is intended to allow property management objects to set values both on
 * the mutation descriptors and initial domain object data parameter objects.
 *
 * @param <T> The final implementing type, to allow for a fluent API.
 */
public interface NePropertySetters<T extends NePropertySetters<T>> {

    /**
     * @param idName New NE name.
     */
    T setName(@Nonnull String idName);

    /**
     * @param usesGne Whether the NE is behind a GNE.
     */
    T setUsesGne(boolean usesGne);

    /**
     * @param usesFlatIp Whether the NE is connected by a Flat IP.
     */
    T setUsesFlatIp(boolean usesFlatIp);

    /**
     * @param reconnectInterval New reconnect interval.
     */
    T setReconnectInterval(int reconnectInterval);

    /**
     * @param globalId New global identifier.
     */
    T setGlobalId(@Nonnull Optional<String> globalId);

    /**
     * @param userName New login user name.
     */
    T setUserName(@Nonnull Optional<String> userName);

    /**
     * @param password New login password.
     */
    T setPassword(@Nonnull Optional<String> password);

    /**
     * @param containerId New parent NE container identifier.
     */
    T setContainerId(@Nonnull Optional<Integer> containerId);

    /**
     * @param dataTransferSettings DataTransferSettings values.
     */
    T setDataTransferSettings(@Nonnull NeDataTransferSettingsAdapter<?> dataTransferSettings);

    /**
     * Enables inclusion of a route "usage" status when sorting the gateway routes automatically.
     * It is only effective if route sorting has been previously enabled.
     * @see #enableRouteSorting(boolean)
     * @param sortByUsage New gateway route sorting mode.
     */
    T enableRouteSortingByUsage(boolean sortByUsage);

    /**
     * @param enabled Whether gateway route sorting should be enabled or disabled.
     */
    T enableRouteSorting(boolean enabled);

    /**
     * Stores a new property for the object. It will be stored in the property bag
     * without further handling.
     * @param name The name of the property to change.
     * @param value The new property value.
     */
    T setProperty(@Nonnull String name, @Nullable String value);

    /**
     * @param properties A map of property values to add or replace in the current set of properties.
     */
    T setProperties(@Nonnull Map<String, String> properties);


    T setUserText(@Nonnull Optional<String> userText);

    /**
     * @return An instance of {@link NeRoutePropertyAdapter} for the NE direct route.
     */
    NeRoutePropertyAdapter<?> getDirectRouteAdapter();
    
    NeDataTransferSettingsAdapter<?> getDataTransferSettingsAdapter();

    interface NeDataTransferSettingsAdapter<T extends NeDataTransferSettingsAdapter<T>> {
        
        Optional<String> getUploadpath();
        
        Optional<String> getUsername();
        
        Optional<String> getPassword();
        
        Optional<String> getIpAddress();
        
        Optional<Boolean> getIsScp();


        T setUploadpath(Optional<String> uploadPath);
        
        T setUsername(Optional<String> username);
        
        T setPassword(Optional<String> password);
        
        T setIpAddress(Optional<String> ipAddress);
        
        T setIsScp(Optional<Boolean> isScp);


    }
    
    /**
     * Allows reading and setting a set of NE Route attributes that should be handled
     * and/or made available to property managers.
     */
    interface NeRoutePropertyAdapter<T extends NeRoutePropertyAdapter<T>> {

        /**
         * @return Route cost. Used for sorting routes.
         */
        Optional<String> getCost();

        /**
         * @return The route priority. Used for sorting routes.
         */
        Optional<String> getPriority();

        /**
         * @return Whether the route is in use, i.e., it is the active route.
         */
        Optional<String> isUsed();

        /**
         * @return The route domain name.
         */
        Optional<String> getDomain();

        /**
         * @return Route key, if already set.
         */
        Optional<String> getKey();

        /**
         * @return Provider GNE name, if already set.
         */
        Optional<String> getGneName();

        /**
         * @return A property value, if present.
         */
        Optional<String> getProperty(@Nonnull String name);

        /**
         * @return All property values.
         */
        Map<String, String> getProperties();

        /**
         * Stores a new property for the object. It will be stored in the property bag
         * without further handling.
         * @param name The name of the property to change.
         * @param value The new property value.
         */
        T setProperty(@Nonnull String name, @Nullable String value);

        /**
         * @param properties A map of property values to add or replace in the current set of properties.
         */
        T setProperties(@Nonnull Map<String, String> properties);

        /**
         * @param newKey New system wide unique route key.
         */
        T setKey(@Nonnull String newKey);

    }
}