package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.EntityEvent;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Wrapper class that will run one work item and request further items from a supplier
 * to be executed within the same context (usually the same thread). This optimizes usage
 * of execution policies with reduced capacity on existing interaction managers: if the manager
 * has spare capacity, it will be able to provide additional work without waiting for an
 * external "push" request.
 *
 * Note: this class has a natural ordering that is inconsistent with equals.
 */
public final class JobWrapper<E extends EntityEvent> implements PolicyJob<E> {

    private final Supplier<Optional<PolicyJob<? extends E>>> jobSupplier;
    private final PolicyJob<? extends E> delegate;

    /**
     * Constructs a new object.
     * @param initialDelegate Initial work item.
     * @param jobSupplier Supplier of additional work items.
     */
    public JobWrapper(PolicyJob<? extends E> initialDelegate, Supplier<Optional<PolicyJob<? extends E>>> jobSupplier) {
        this.jobSupplier = jobSupplier;
        this.delegate = initialDelegate;
    }

    /**
     * Executes the original work item. Then requests further work from the supplier provided
     * for execution until work is no longer available.
     */
    @Override
    public void run() {

        delegate.run();

        Optional<PolicyJob<? extends E>> additionalJob;
        do {
            additionalJob = jobSupplier.get();
            additionalJob.ifPresent(Runnable::run);
        } while (additionalJob.isPresent());
    }

    @Override
    public E getOriginatingEvent() {
        return delegate.getOriginatingEvent();
    }

    @Override
    public Priority getPriority() {
        return delegate.getPriority();
    }

    @Override
    public void cancel() {
        delegate.cancel();
    }

    @Override
    public int compareTo(@Nonnull PolicyJob<?> o) {
        return delegate.compareTo(o);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(delegate.toString())
                .toString();
    }
}
