package com.ossnms.dcn_manager.core.events.channel;

import java.util.Objects;
import java.util.Optional;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>Used to signal actual channel activation state changes. Derived class instances
 * represent specific channel activation events, namely, activation completed, deactivation
 * completed and activation failure events. The following figure depicts the class hierarchy.</p>
 *
 * <p> <figure>
 * <img src="doc-files/channel_actual_activation_state_event-class.png">
 * <figcaption>Class diagram of the events related to operations performed on actual channel
 * state domain objects</figcaption>
 * </figure> </p>
 *
 * <p>The abstract base class ({@link ActualChannelStateEvent}) defines the information associated to all
 * concrete events. Instead of materializing these concrete event types as derived top-level classes, thus
 * increasing the overall solution's complexity (i.e. the total number of top-level classes), concrete event
 * types are materialized as static nested classes, leading to a curious coding pattern in which derived
 * classes are public nested classes of its super class.</p>
 *
 * <p>Despite being a curious coding pattern, the resulting solution reduces overall complexity and increases
 * readability: all related types are contained within the same compilation unit which, given its small size,
 * is not affected by significant complexity increase.</p>
 */
/*
 * @startuml doc-files/channel_actual_activation_state_event-class.png
 * abstract class ActualChannelStateEvent <<Immutable>> {
 *      # ActualChannelStateEvent(channelId: int)
 *      # ActualChannelStateEvent(channelId: int, description: String)
 * }
 * class ChannelActivatedEvent <<Immutable>> {
 *      + ChannelActivatedEvent(channelId: int)
 *      + ChannelActivatedEvent(channelId: int, description: String)
 * }
 * class ChannelDeactivatedEvent <<Immutable>> {
 *      + ChannelDeactivatedEvent(channelId: int)
 *      + ChannelDeactivatedEvent(channelId: int, description: String)
 * }
 * class ChannelActivatingEvent <<Immutable>> {
 *      + ChannelActivatingEvent(channelId: int)
 *      + ChannelActivatingEvent(channelId: int, description: String)
 * }
 * class ChannelDeactivatingEvent <<Immutable>> {
 *      + ChannelDeactivatingEvent(channelId: int)
 *      + ChannelDeactivatingEvent(channelId: int, description: String)
 * }
 * class ChannelActivationFailedEvent <<Immutable>> {
 *      + ChannelActivationFailedEvent(channelId: int)
 *      + ChannelActivationFailedEvent(channelId: int, description: String)
 * }
 * class ChannelCreatingEvent <<Immutable>> {
 *      + ChannelCreatingEvent(channelId: int)
 *      + ChannelCreatingEvent(channelId: int, description: String)
 * }
 * class ChannelStartingUpEvent <<Immutable>> {
 *      + ChannelStartingUpEvent(channelId: int)
 *      + ChannelStartingUpEvent(channelId: int, description: String)
 * }
 * class ChannelShuttingDownEvent <<Immutable>> {
 *      + ChannelShuttingDownEvent(channelId: int)
 *      + ChannelShuttingDownEvent(channelId: int, description: String)
 * }
 * abstract class ChannelEvent <<Immutable>> <|-- ActualChannelStateEvent
 * hide ChannelEvent members
 * ActualChannelStateEvent <|-- ChannelDeactivatedEvent
 * ActualChannelStateEvent <|-- ChannelActivatedEvent
 * ActualChannelStateEvent <|-- ChannelDeactivatingEvent
 * ActualChannelStateEvent <|-- ChannelActivatingEvent
 * ActualChannelStateEvent <|-- ChannelActivationFailedEvent
 * ActualChannelStateEvent <|-- ChannelCreatingEvent
 * ActualChannelStateEvent <|-- ChannelStartingUpEvent
 * ActualChannelStateEvent <|-- ChannelShuttingDownEvent
 * @enduml
 */
@Immutable
public abstract class ActualChannelStateEvent extends ChannelEvent {

    private final PhysicalChannelStateEvent originatingPhysicalEvent;

    /**
     * Initiates an instance with the given arguments.
     * @param id The affected channel identifier.
     */
    protected ActualChannelStateEvent(int channelId) {
        super(channelId);
        originatingPhysicalEvent = null;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param channelId The affected channel ID.
     * @param detailedDescription Human-readable event description.
     */
    protected ActualChannelStateEvent(int channelId, @Nonnull String detailedDescription) {
        super(channelId, detailedDescription);
        originatingPhysicalEvent = null;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param id The affected channel identifier.
     * @param originatingEvent The physical event that originated this logical event.
     */
    protected ActualChannelStateEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent) {
        super(channelId);
        originatingPhysicalEvent = originatingEvent;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param channelId The affected channel ID.
     * @param detailedDescription Human-readable event description.
     * @param originatingEvent The physical event that originated this logical event.
     */
    protected ActualChannelStateEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent, @Nonnull String detailedDescription) {
        super(channelId, detailedDescription);
        originatingPhysicalEvent = originatingEvent;
    }

    /**
     * @return The originating physical event, if present.
     */
    public Optional<PhysicalChannelStateEvent> getOriginatingPhysicalEvent() {
        return Optional.ofNullable(originatingPhysicalEvent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getChannelId(), getDetailedDescription(), originatingPhysicalEvent);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final ActualChannelStateEvent rhs = (ActualChannelStateEvent) obj;
        return new EqualsBuilder()
                .append(getChannelId(), rhs.getChannelId())
                .append(getDetailedDescription(), rhs.getDetailedDescription())
                .append(originatingPhysicalEvent, rhs.originatingPhysicalEvent)
                .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("originatingPhysicalEvent", originatingPhysicalEvent)
                .toString();
    }

    /**
     * Class whose instances represent events used to signal that a channel activation has been scheduled.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class ChannelStartingUpEvent extends ActualChannelStateEvent {

        public ChannelStartingUpEvent(int channelId) {
            super(channelId);
        }

        public ChannelStartingUpEvent(int channelId, @Nonnull String detailedDescription) {
            super(channelId, detailedDescription);
        }

        public ChannelStartingUpEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent) {
            super(channelId, originatingEvent);
        }

        public ChannelStartingUpEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent, @Nonnull String detailedDescription) {
            super(channelId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that an attempt at creating the channel
     * is underway.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class ChannelCreatingEvent extends ActualChannelStateEvent {

        public ChannelCreatingEvent(int channelId) {
            super(channelId);
        }

        public ChannelCreatingEvent(int channelId, @Nonnull String detailedDescription) {
            super(channelId, detailedDescription);
        }

        public ChannelCreatingEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent) {
            super(channelId, originatingEvent);
        }

        public ChannelCreatingEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent, @Nonnull String detailedDescription) {
            super(channelId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel has been created.
     * A created channel is an active channel.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class ChannelCreatedEvent extends ActualChannelStateEvent {

        public ChannelCreatedEvent(int channelId) {
            super(channelId);
        }

        public ChannelCreatedEvent(int channelId, @Nonnull String detailedDescription) {
            super(channelId, detailedDescription);
        }

        public ChannelCreatedEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent) {
            super(channelId, originatingEvent);
        }

        public ChannelCreatedEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent, @Nonnull String detailedDescription) {
            super(channelId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel activation has been initiated.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class ChannelActivatingEvent extends ActualChannelStateEvent {

        public ChannelActivatingEvent(int channelId) {
            super(channelId);
        }

        public ChannelActivatingEvent(int channelId, @Nonnull String detailedDescription) {
            super(channelId, detailedDescription);
        }

        public ChannelActivatingEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent) {
            super(channelId, originatingEvent);
        }

        public ChannelActivatingEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent, @Nonnull String detailedDescription) {
            super(channelId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel activation has succeeded.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class ChannelActivatedEvent extends ActualChannelStateEvent {

        public ChannelActivatedEvent(int channelId) {
            super(channelId);
        }

        public ChannelActivatedEvent(int channelId, @Nonnull String detailedDescription) {
            super(channelId, detailedDescription);
        }

        public ChannelActivatedEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent) {
            super(channelId, originatingEvent);
        }

        public ChannelActivatedEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent, @Nonnull String detailedDescription) {
            super(channelId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel activation has failed.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class ChannelActivationFailedEvent extends ActualChannelStateEvent {

        public ChannelActivationFailedEvent(int channelId) {
            super(channelId);
        }

        public ChannelActivationFailedEvent(int channelId, @Nonnull String detailedDescription) {
            super(channelId, detailedDescription);
        }

        public ChannelActivationFailedEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent) {
            super(channelId, originatingEvent);
        }

        public ChannelActivationFailedEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent, @Nonnull String detailedDescription) {
            super(channelId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel deactivation was scheduled.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class ChannelShuttingDownEvent extends ActualChannelStateEvent {

        public ChannelShuttingDownEvent(int channelId) {
            super(channelId);
        }

        public ChannelShuttingDownEvent(int channelId, @Nonnull String detailedDescription) {
            super(channelId, detailedDescription);
        }

        public ChannelShuttingDownEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent) {
            super(channelId, originatingEvent);
        }

        public ChannelShuttingDownEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent, @Nonnull String detailedDescription) {
            super(channelId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel deactivation was completed.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class ChannelDeactivatedEvent extends ActualChannelStateEvent {

        public ChannelDeactivatedEvent(int channelId) {
            super(channelId);
        }

        public ChannelDeactivatedEvent(int channelId, @Nonnull String detailedDescription) {
            super(channelId, detailedDescription);
        }

        public ChannelDeactivatedEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent) {
            super(channelId, originatingEvent);
        }

        public ChannelDeactivatedEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent, @Nonnull String detailedDescription) {
            super(channelId, originatingEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a channel deactivation has been initiated.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class ChannelDeactivatingEvent extends ActualChannelStateEvent {

        public ChannelDeactivatingEvent(int channelId) {
            super(channelId);
        }

        public ChannelDeactivatingEvent(int channelId, @Nonnull String detailedDescription) {
            super(channelId, detailedDescription);
        }

        public ChannelDeactivatingEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent) {
            super(channelId, originatingEvent);
        }

        public ChannelDeactivatingEvent(int channelId, @Nonnull PhysicalChannelStateEvent originatingEvent, @Nonnull String detailedDescription) {
            super(channelId, originatingEvent, detailedDescription);
        }
    }
}
