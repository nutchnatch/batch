package com.ossnms.dcn_manager.core.properties;

import javax.annotation.Nonnull;

/**
 * Contains well known EM/NE property names as mentioned in the user interface description files.
 * Is also able to manage property retrieval from a merged set of Entity Type and Entity Instance
 * properties.
 */
public abstract class EntityProperty implements EntityPropertyOperations {

    private final String name;
    private final Scope scope;

    /**
     * Creates a new object.
     *
     * @param name Property name.
     */
    protected EntityProperty(@Nonnull String name) {
        this.name = name;
        this.scope = Scope.PUBLIC;
    }

    /**
     * Creates a new object.
     *
     * @param name Property name.
     * @param scope Desired property scope.
     */
    protected EntityProperty(@Nonnull String name, @Nonnull Scope scope) {
        this.name = name;
        this.scope = scope;
    }

    /** @return The property name as it is used in XML files. */
    @Override
    public String getName() {
        return name;
    }

    /**
     * @return The desired property visibility scope.
     */
    @Override
    public Scope getScope() {
        return scope;
    }

    @Override
    public String toString() {
        return String.format("%s[%s,%s]", super.toString(), name, scope.toString());
    }

}
