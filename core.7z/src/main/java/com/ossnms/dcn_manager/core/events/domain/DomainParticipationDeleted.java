package com.ossnms.dcn_manager.core.events.domain;

import com.google.common.base.Objects;

/**
 * Informs that domain membership (participation) has been removed, for a given NE.
 */
public class DomainParticipationDeleted extends DomainEvent {

    private final int neId;

    /**
     * Creates a new object.
     * @param domainId The affected domain ID.
     * @param neId The NE identifier being removed from the domain.
     */
    public DomainParticipationDeleted(int domainId, int neId) {
        super(domainId);
        this.neId = neId;
    }

    /**
     * @return The NE identifier being removed from the domain.
     */
    public int getNeId() {
        return neId;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(super.hashCode(), neId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final DomainParticipationDeleted rhs = (DomainParticipationDeleted) obj;
        return getDomainId() == rhs.getDomainId() && neId == rhs.neId;
    }
}
