package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import org.apache.commons.lang3.builder.EqualsBuilder;

import javax.annotation.Nonnull;
import java.util.Objects;

/**
 * Contains information about a configuration of one real (PHYSICAL)
 * connection to one Mediator server.
 */
public final class MediatorPhysicalData extends BusinessObjectData {

    private final int mediatorId;
    private final int priority;
    private final String host;

    /**
     * Creates a new object with default values (inactive).
     * @param mediatorInstanceId The Physical Mediator ID.
     * @param mediatorId The Logical Mediator ID.
     * @param version This instances' version number.
     * @param prototype Initial instance data.
     */
    public MediatorPhysicalData(int mediatorInstanceId, int mediatorId, int version, MediatorPhysicalDataPrototype<?> prototype) {
        super(mediatorInstanceId, version);
        this.mediatorId = mediatorId;
        this.host = prototype.host;
        this.priority = prototype.priority;
    }

    /**
     * @return Mediator host name in the network.
     */
    public String getHost() {
        return host;
    }

    /**
     * @return Logical Mediator ID.
     */
    public int getLogicalMediatorId() {
        return mediatorId;
    }

    /**
     * @return This instances' priority.
     */
    public int getPriority() {
        return priority;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        final ToStringHelper helper = MoreObjects.toStringHelper(this);
        helper.addValue(super.toString());
        helper.add("mediatorId", getLogicalMediatorId());
        helper.add("host", getHost());
        helper.add("priority", getPriority());
        return helper.toString();
    }

    @Override
    public int hashCode() {
        return Objects.hash(mediatorId, priority, host);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (null == other || getClass() != other.getClass()) {
            return false;
        }
        final MediatorPhysicalData rhs = (MediatorPhysicalData) other;
        return new EqualsBuilder()
                .append(mediatorId, rhs.mediatorId)
                .append(priority, rhs.priority)
                .append(host, rhs.host)
                .isEquals();
    }

    public abstract static class MediatorPhysicalDataPrototype<T extends MediatorPhysicalDataPrototype<T>> {

        private String host = "";
        private int priority;

        protected MediatorPhysicalDataPrototype() {

        }

        protected MediatorPhysicalDataPrototype(MediatorPhysicalDataPrototype<?> other) {
            host = other.host;
            priority = other.priority;
        }

        protected abstract T self();

        /**
         * @param host The new Mediator host name in the network.
         */
        public T setHost(@Nonnull String host) {
            this.host = host;
            return self();
        }

        /**
         * @param priority The new instance priority.
         */
        public T setPriority(int priority) {
            this.priority = priority;
            return self();
        }

        /**
         * @return The new Mediator host name in the network.
         */
        public String getHost() {
            return host;
        }

        /**
         * @return The new instance priority.
         */
        public int getPriority() {
            return priority;
        }

    }

    /**
     * Contains initial data values for the data object (it's a parameter object).
     */
    public static final class MediatorPhysicalDataInitialData extends MediatorPhysicalDataPrototype<MediatorPhysicalDataInitialData> {

        @Override
        protected MediatorPhysicalDataInitialData self() {
            return this;
        }

    }

    /**
     * Helps building a new instance of {@link MediatorPhysicalData} with
     * predefined attribute values.
     */
    public static final class MediatorPhysicalDataBuilder extends MediatorPhysicalDataPrototype<MediatorPhysicalDataBuilder> {

        /**
         * Creates a new instance with values defined in this builder object.
         * @param mediatorInstanceId The Physical Mediator ID.
         * @param logicalMediatorId The Logical Mediator ID.
         * @param version The new instances' version number.
         * @return A new instance of {@link MediatorPhysicalData}.
         */
        public MediatorPhysicalData build(int mediatorInstanceId, int logicalMediatorId, int version) {
            return new MediatorPhysicalData(mediatorInstanceId, logicalMediatorId, version, this);
        }

        @Override
        protected MediatorPhysicalDataBuilder self() {
            return this;
        }

    }
}
