package com.ossnms.dcn_manager.core.events.ne;

import com.google.common.base.MoreObjects;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Fired by mediators when synchronization counters/stamps change for one or
 * more predefined categories.
 */
public class NePhysicalSynchronizationCountersChangedEvent extends NeEvent {

    private final int logicalNeId;
    private final Optional<Long> all;
    private final Optional<Long> alarms;
    private final Optional<Long> packet;

    /**
     * Creates a new object.
     * @param physicalNeId The originating physical NE identifier.
     * @param logicalNeId The affected logical NE identifier.
     * @param all "All" synchronization category stamp value.
     * @param alarms "Alarm" synchronization category stamp value.
     * @param packet "Packet" synchronization category stamp value.
     */
    public NePhysicalSynchronizationCountersChangedEvent(int physicalNeId, int logicalNeId, @Nonnull Optional<Long> all,
                                                         @Nonnull Optional<Long> alarms, @Nonnull Optional<Long> packet) {
        super(physicalNeId);
        this.logicalNeId = logicalNeId;
        this.all = all;
        this.alarms = alarms;
        this.packet = packet;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("logicalNeId", logicalNeId)
                .add("all", all)
                .add("alarms", alarms)
                .add("packet", packet)
                .addValue(super.toString())
                .toString();
    }

    /**
     * @return The affected logical NE identifier.
     */
    public int getLogicalNeId() {
        return logicalNeId;
    }

    /**
     * @return "All" synchronization category stamp value.
     */
    public Optional<Long> getAll() {
        return all;
    }

    /**
     * @return "Alarm" synchronization category stamp value.
     */
    public Optional<Long> getAlarms() {
        return alarms;
    }

    /**
     * @return "Packet" synchronization category stamp value.
     */
    public Optional<Long> getPacket() {
        return packet;
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        final NePhysicalSynchronizationCountersChangedEvent rhs = (NePhysicalSynchronizationCountersChangedEvent) obj;
        return new EqualsBuilder()
            .append(getNeId(), rhs.getNeId())
            .append(getDetailedDescription(), rhs.getDetailedDescription())
            .append(logicalNeId, rhs.logicalNeId)
            .append(all, rhs.all)
            .append(alarms, rhs.alarms)
            .append(packet, rhs.packet)
            .isEquals();
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(getNeId())
            .append(getDetailedDescription())
            .append(logicalNeId)
            .append(all)
            .append(alarms)
            .append(packet)
            .hashCode();
    }

}
