package com.ossnms.dcn_manager.core.storage.domain;

import com.ossnms.dcn_manager.core.entities.domain.DomainCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.BusinessEntityRepository;
import com.ossnms.dcn_manager.core.storage.BusinessObjectRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Describes all operations that must be supported by a repository
 * of Domains.
 */
public interface DomainRepository
        extends BusinessEntityRepository<DomainInfoData, DomainCreationDescriptor, DomainDeletionDescriptor>,
                BusinessObjectRepository<DomainInfoData, DomainInfoMutationDescriptor> {

    /**
     * <b>UNSUPPORTED FOR DOMAINS.</b>
     *
     * Use {@link #tryCreate(DomainCreationDescriptor)} instead to be able to handle potential
     *  race conditions.
     *
     * @throws UnsupportedOperationException Always.
     * @return Nothing. Ever.
     */
    @Override
    default DomainInfoData create(DomainCreationDescriptor descriptor) throws RepositoryException {
        throw new UnsupportedOperationException("Use #tryCreate(DomainCreationDescriptor) instead to be able to handle potential race conditions.");
    }

    /**
     * Attempts to create a new entity.
     *
     * @param descriptor Entity creation descriptor instance.
     * @return The new entity instance, after it is stored in the repository.
     *     It will not be present if another entity already exists in the
     *     repository with the same identity.
     * @throws RepositoryException If an error occurs while dealing with the
     *  underlying data source.
     */
    Optional<DomainInfoData> tryCreate(DomainCreationDescriptor descriptor) throws RepositoryException;

    /**
     * Attempts to find all Domains that contain a Network Element.
     *
     * @param neId Network Element identifier.
     * @return An iterable of {@link DomainInfoData}.
     * @throws RepositoryException If an error has occurred while working with the underlying storage provider.
     */
    Iterable<DomainInfoData> queryAllForNE(int neId);

    /**
     * Attempts to find all Domains that contain a Network Element in a natural membership.
     * Natural domain memberships are those that are configured directly in the NE itself.
     *
     * @param neId Network Element identifier.
     * @return An iterable of {@link DomainInfoData}.
     * @throws RepositoryException If an error has occurred while working with the underlying storage provider.
     */
    Iterable<DomainInfoData> queryNaturalDomainsForNE(int neId);

    /**
     * Attempts to find all Domains that contain a Network Element in a transitive membership.
     * Transitive domain memberships are those that are created by indirect association: for example,
     * when a GNE->RNE route is associated with a GNE domain, the RNE is then a transitive member of the
     * domain.
     *
     * @param neId Network Element identifier.
     * @return An iterable of {@link DomainInfoData}.
     * @throws RepositoryException If an error has occurred while working with the underlying storage provider.
     */
    Iterable<DomainInfoData> queryTransitiveDomainsForNE(int neId);

    /**
     * Attempts to find all Network Elements contained by a Domain.
     * @param domainId Domain identifier.
     * @return An iterable of NE identifiers.
     */
    Iterable<Integer> queryChildrenNEs(int domainId);

    /**
     * Attempts to associate a Network Element with a natural Domain.
     * Natural domain memberships are those that are configured directly in the NE itself.
     *
     * @param domainId Domain identifier.
     * @param neId Network Element identifier.
     * @return True if the association was successful. The attempt will fail if the domain was
     *  modified during the operation or deleted just before it is updated.
     * @throws RepositoryException If an error has occurred while working with the underlying storage provider.
     */
    boolean tryAddNaturalNE(int domainId, int neId) throws RepositoryException;

    /**
     * Attempts to associate a Network Element with a transitive Domain.
     * Transitive domain memberships are those that are created by indirect association: for example,
     * when a GNE->RNE route is associated with a GNE domain, the RNE is then a transitive member of the
     * domain.
     *
     * @param domainId Domain identifier.
     * @param neId Network Element identifier.
     * @return True if the association was successful. The attempt will fail if the domain was
     *  modified during the operation or deleted just before it is updated.
     * @throws RepositoryException If an error has occurred while working with the underlying storage provider.
     */
    boolean tryAddTransitiveNE(int domainId, int neId) throws RepositoryException;

    /**
     * Attempts to remove a Network Element from a natural domain.
     * Natural domain memberships are those that are configured directly in the NE itself.
     *
     * @param domainId Domain identifier.
     * @param neId Network Element identifier.
     * @return True if the removal was successful. The attempt will fail if the domain was
     *  modified during the operation or deleted just before it is updated.
     * @throws RepositoryException If an error has occurred while working with the underlying storage provider.
     */
    boolean tryRemoveNaturalNE(int domainId, int neId) throws RepositoryException;

    /**
     * Attempts to remove a Network Element from a transitive domain.
     * Transitive domain memberships are those that are created by indirect association: for example,
     * when a GNE->RNE route is associated with a GNE domain, the RNE is then a transitive member of the
     * domain.
     *
     * @param domainId Domain identifier.
     * @param neId Network Element identifier.
     * @return True if the removal was successful. The attempt will fail if the domain was
     *  modified during the operation or deleted just before it is updated.
     * @throws RepositoryException If an error has occurred while working with the underlying storage provider.
     */
    boolean tryRemoveTransitiveNE(int domainId, int neId) throws RepositoryException;

    /**
     * Tries to find a Domain with the given name.
     * @param domainName The desired Domain name.
     * @return An instance of {@link DomainInfoData}, if found.
     * @throws RepositoryException If an error has occurred while working with the underlying storage provider.
     */
    Optional<DomainInfoData> queryByName(@Nonnull String domainName) throws RepositoryException;

}
