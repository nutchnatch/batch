package com.ossnms.dcn_manager.core.properties.ne;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Maps.EntryTransformer;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionRouteSetters;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySetters.NeRoutePropertyAdapter;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySource;
import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.core.jaxb.netype.RouteMapping;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.google.common.base.Predicates.notNull;

/**
 * Handles mapping of {@link NeGatewayRouteData} to
 * name/value pairs (a.k.a. properties) and from name/value pairs to gateway route
 * mutation descriptors.
 */
public class NeGatewayRouteProperties extends NeRouteProperties {

    private static final int ROUTE_DATA_VERSION = 1;
    private final NeType neType;

    /**
     * Creates a new object.
     * @param type NE Type that contains applicable property configuration.
     */
    public NeGatewayRouteProperties(NeType type) {
        neType = type;
    }

    /**
     * <p>Produces a collection of gateway route mutation descriptors from a map of
     * name/value pairs (properties).</p>
     *
     * <p>Because this method will produce a collection, properties must be properly
     * indexed. This means that their names must contain a suffix with an underscore
     * followed by an index number (i.e., <code>NAME_000</code>).</p>
     *
     * <p>Property names must be mentioned in the NE Type gateway
     * route attribute list in order to be considered for processing. Route validity
     * is determined by the presence of a route unique key. Other parameters have
     * default values.</p>
     *
     * <p>For example, if the NE Type configuration contains:</p>
     * <pre>
    &lt;ne:gatewayRoute&gt;
        &lt;ne:attribute name="PRIO" mapsTo="priority" /&gt;
        &lt;ne:attribute name="USED" mapsTo="usage" /&gt;
        &lt;ne:attribute name="COST" mapsTo="cost" /&gt;
        &lt;ne:attribute name="ADDRESS" /&gt;
        &lt;ne:attribute name="PORT" /&gt;
        &lt;ne:attribute name="SYSNAME" /&gt;
        &lt;ne:addressKey&gt;${Route.ADDRESS}${Route.PORT}&lt;/ne:addressKey&gt;
    &lt;/ne:gatewayRoute&gt;</pre>
     *
     * <p>Then <code>PRIO_000</code>, <code>USED_001</code>, <code>COST_000</code>,
     * etc. will be processed as gateway route properties but <code>PRIO</code> or
     * <code>SOMETHING_000</code> will not.</p>
     *
     * <p>A unique key must be generated from the script provided. Should the mapped
     * properties mentioned in the route key script be absent or empty, no key will
     * be generated. Hence the route will be discarded.</p>
     *
     * <p>Resulting mutation descriptors will have their attributes filled with data
     * from mapped properties (those with <code>mapTo</code> attributes). Other
     * properties will be stored in the generic route property bag.</p>
     *
     * <p>Should the valid property collections found match existing routes, the mutation
     * descriptors produced will act upon those existing route instances. New instances
     * will be created otherwise.</p>
     *
     * <p>It is the responsibility of the caller to determine which routes need to be updated and
     * which need to be created.</p>
     *
     * @param properties An associative map of name/value pairs.
     * @param neId Target NE identifier.
     * @param contextEntity A source of NE properties used to obtain current property values
     *  used while building or updating gateway routes (for example, to calculate route keys).
     * @param existingGatewayRoutes Existing NE gateway routes. Used to determine whether the
     *  properties being parsed represent new routes or changes to existing routes.
     * @return A collection of {@link NeGatewayRouteMutationDescriptor}.
     */
    public Collection<NeGatewayRouteMutationDescriptor> parseProperties(@Nonnull Map<String, String> properties,
            int neId, @Nonnull NePropertySource contextEntity, @Nonnull Iterable<NeGatewayRouteData> existingGatewayRoutes) {

        final Map<Integer,Collection<PropertyInfo>> gatewayRouteProperties = buildPropertyInfo(properties);

        final Collection<NeGatewayRouteMutationDescriptor> descriptors =
            Maps.transformEntries(gatewayRouteProperties, new TransformRouteInfoIntoMutation(neId, contextEntity, existingGatewayRoutes))
                .values();

        return Collections2.filter(descriptors, notNull());
    }

    /**
     * <p>Produces a collection of gateway route builders from a map of name/value pairs (properties).
     * These builders may be used in the NE entity creation process.</p>
     *
     * <p>The same rules and notes of {@link #parseProperties(Map, int, NePropertySource, Iterable)} apply.</p>
     *
     * @param properties An associative map of name/value pairs.
     * @param context A source of NE property values that can be used to build the gateway route.
     *  NE types can have configurations defined for gateway route properties such that NE property
     *  values are necessary to build or clone the final route properties. See the NE type XSD.
     * @return A collection of {@link NeGatewayRouteBuilder}.
     * @see #parseProperties(Map, NePropertySource)
     */
    public Collection<NeGatewayRouteBuilder> parseProperties(@Nonnull Map<String, String> properties,
            @Nonnull NePropertySource context) {
        final Collection<Entry<Integer, Collection<PropertyInfo>>> gatewayRouteProperties =
                buildPropertyInfo(properties)
                    .entrySet();

        return FluentIterable.from(gatewayRouteProperties)
            .transform(new TransformRouteInfoIntoBuilder(context))
            .filter(notNull())
            .toList();
    }

    /**
     * Recalculates gateway route keys. Used when there are strong possibilities of these
     * having changed independently.
     *
     * @param contextEntity A source of NE properties used to obtain current property values
     *  used while recalculating route keys.
     * @param existingGatewayRoutes Existing NE gateway routes which will have their keys
     *  recalculated.
     *
     * @return Mutation descriptors for all gateway routes which had their keys changed.
     */
    public Iterable<NeGatewayRouteMutationDescriptor> refreshRouteKeys(@Nonnull final NePropertySource contextEntity,
            @Nonnull Iterable<NeGatewayRouteData> existingGatewayRoutes) {
        return FluentIterable.from(existingGatewayRoutes).
                transform(new Function<NeGatewayRouteData, NeGatewayRouteMutationDescriptor>() {
                    @Override
                    public NeGatewayRouteMutationDescriptor apply(@Nonnull NeGatewayRouteData route) {
                        return new NeGatewayRouteMutationDescriptor(route)
                                .setKey(
                                        getFromSource(neType, neType.getGatewayRouteAddressKeySource(),
                                                neType.getGatewayRouteAttributes(),
                                                new NeGatewayRoutePropertyAdapter(route),
                                                contextEntity).orElse(route.getKey()));
                    }
                }).
                filter(new Predicate<NeGatewayRouteMutationDescriptor>() {
                    @Override
                    public boolean apply(@Nonnull NeGatewayRouteMutationDescriptor mutation) {
                        return mutation.getKey().isPresent() &&
                               !mutation.getKey().get().equals(mutation.getTarget().getKey());
                    }
                });
    }

    private Map<Integer,Collection<PropertyInfo>> buildPropertyInfo(Map<String, String> properties) {
        return properties.entrySet().stream()
                .filter(entry -> entry.getValue() != null)
                .filter(entry -> isGatewayRouteProperty(neType, entry.getKey()))
                .map(entry -> new PropertyInfo(entry.getKey(), entry.getValue()))
                .collect(Collectors.toMap(
                        PropertyInfo::getIndex,
                        Lists::newArrayList,
                        (oldEntry, newEntry) -> { oldEntry.addAll(newEntry); return oldEntry; },
                        TreeMap::new
                ));
    }

    /**
     * <p>Produces a map of name/value pairs (properties) from all gateway routes
     * defined in an NE Entity.</p>
     *
     * <p>This is the inverse process of {@link #parseProperties(Map, NePropertySource)}. Again,
     * only gateway route attributes configured in the NE Type will be recognized
     * and processed.</p>
     *
     * @param entity An NE entity instance.
     * @return A map of name/value pairs with gateway route information.
     *
     * @see #parseProperties(Map, NePropertySource)
     */
    public Map<String, String> toProperties(@Nonnull NeEntity entity, @Nonnull Iterable<NeGatewayRouteData> gatewayRoutes) {
        final Map<String, String> properties = new HashMap<>();
        int routeCount = 0;
        for (final NeGatewayRouteData route : gatewayRoutes) {
            final int index = route.getPriority() - 1;
            for (final Entry<String, Attribute> routeProperty : neType.getGatewayRouteAttributes().entrySet()) {
                final Optional<String> value = get(routeProperty.getKey(), new NeGatewayRoutePropertyAdapter(route), entity);
                put(properties, index, routeProperty.getKey(), value);
            }
            routeCount++;
        }
        properties.put(WellKnownNePropertyNames.DEPRECATED_NUM_OF_ADD_NSAPS, String.valueOf(routeCount));
        return properties;
    }

    /**
     * Produces a value from an encoded gateway route property name, if there is a route with
     * the name index and the name is configured and present in the route.
     *
     * @param type NE type.
     * @param entitySource Source of NE property values for the NE entity being queried.
     * @param gatewayRoutes Known NE gateway routes.
     * @param encodedPropertyName Encoded property name (name and index).
     *      See {@link #parseProperties(Map, int, NePropertySource, Iterable)}
     *      for a description of the name encoding format.
     * @return The gateway route property value, if present.
     */
    static Optional<String> getSingleProperty(@Nonnull NeType type, @Nonnull NePropertySource entitySource,
                                              @Nonnull Iterable<NeGatewayRouteData> gatewayRoutes, @Nonnull String encodedPropertyName) {
        Optional<String> value = Optional.empty();
        if (isGatewayRouteProperty(type, encodedPropertyName)) {
            final PropertyInfo info = new PropertyInfo(encodedPropertyName, null);
            final Optional<NeGatewayRouteData> route = tryFindRouteWithIndex(gatewayRoutes, info.getIndex());
            if (route.isPresent()) {
                value = get(type, info.getName(), type.getGatewayRouteAttributes(),
                        new NeGatewayRoutePropertyAdapter(route.get()), entitySource);
            } else {
                LOGGER.debug("Could not find route property '{}' with index {} in NE {}.", info.getName(), info.getIndex(), entitySource);
            }
        }
        return value;
    }

    /**
     * Determines whether a property name belongs to the set of expected gateway
     * route properties for an NE Type.
     * @param type Targeted NE Type.
     * @param key Property name.
     * @return True if the property name belongs to the set of expected gateway
     * route properties for the NE Type given.
     */
    static boolean isGatewayRouteProperty(@Nonnull NeType type, @Nonnull String key) {
        final Matcher matcher = PropertyInfo.INDEXED_PROPERTY_NAME_PATTERN.matcher(key);
        return matcher.matches() && type.getGatewayRouteAttributes().containsKey(matcher.group(PropertyInfo.NAME_GROUP));
    }

    /**
     * Finds or calculates a gateway route property value.
     * Unknown property names and unset properties will be ignored.
     *
     * @param name Property value.
     * @param route Gateway route being processed.
     * @param entity Gateway route owner entity.
     * @return The property value, if present.
     */
    Optional<String> get(String name, NeRoutePropertyAdapter<?> route, NePropertySource entity) {
        return get(neType, name, neType.getGatewayRouteAttributes(), route, entity);
    }

    /**
     * <p>Map entry transformer.</p>
     *
     * <p>Given an associative map of property information collections, produce mutation descriptors for
     * those collections that contain valid routes. Route validity is determined by the presence of
     * a route unique key. Other parameters have default values.</p>
     *
     * <p>Should the valid property information collections found match existing routes, the mutation
     * descriptors produced will act upon those existing route instances. New instances will be created
     * otherwise.</p>
     *
     * <p>It is the responsibility of the user code to determine which routes need to be updated and
     * which need to be created.</p>
     */
    private final class TransformRouteInfoIntoMutation implements
            EntryTransformer<Integer, Collection<PropertyInfo>, NeGatewayRouteMutationDescriptor> {

        private final Optional<String> keySource = neType.getGatewayRouteAddressKeySource();
        private final Map<String, Attribute> gatewayRouteAttributes = neType.getGatewayRouteAttributes();
        private final NeRoutePropertyAdapterWithoutDefaults noDefaults = new NeRoutePropertyAdapterWithoutDefaults();

        private final NePropertySource contextEntity;
        private final int neId;
        private final Iterable<NeGatewayRouteData> existingGatewayRoutes;

        private TransformRouteInfoIntoMutation(int neId, NePropertySource contextEntity, Iterable<NeGatewayRouteData> existingGatewayRoutes) {
            this.neId = neId;
            this.contextEntity = contextEntity;
            this.existingGatewayRoutes = existingGatewayRoutes;
        }

        @Override
        public NeGatewayRouteMutationDescriptor transformEntry(final Integer key, Collection<PropertyInfo> value) {

            final Optional<String> routeKey =
                    getFromSource(neType, keySource, gatewayRouteAttributes,
                            new NePropertyBagAdapter(gatewayRouteAttributes.values(), value, noDefaults),
                            contextEntity);

            if (routeKey.isPresent()) {

                final NeGatewayRouteData data =
                        tryFind(existingGatewayRoutes, input -> {
                            final Optional<String> recalculatedInputRouteKey =
                                getFromSource(neType, keySource, gatewayRouteAttributes,
                                    new NeGatewayRoutePropertyAdapter(input),
                                    contextEntity);

                            return routeKey.equals(recalculatedInputRouteKey);
                        })
                        .orElseGet(() -> new NeGatewayRouteBuilder()
                                .setKey(routeKey.get()) // we need to set the key just to build the underlying route.
                                .setPriority(key + 1) // set the route priority just in case it isn't included in the property bag.
                                .build(neId, ROUTE_DATA_VERSION));

                final NeGatewayRouteMutationDescriptor mutation = new NeGatewayRouteMutationDescriptor(data);
                for (final PropertyInfo info : value) {
                    set(gatewayRouteAttributes.get(info.getName()), mutation, info.getValue());
                }
                mutation.setKey(routeKey.get()); // ensure that the correct key is set, should it depend on any changed context property values.

                return mutation;
            }

            return null;
        }
    }

    private abstract static class ReadOnlyRoutePropertyAdapter
            implements NeRoutePropertyAdapter<ReadOnlyRoutePropertyAdapter> {

        @Override
        public ReadOnlyRoutePropertyAdapter setProperty(@Nonnull String name, @Nullable String value) {
            throw new UnsupportedOperationException();
        }

        @Override
        public ReadOnlyRoutePropertyAdapter setProperties(@Nonnull Map<String, String> properties) {
            throw new UnsupportedOperationException();
        }

        @Override
        public ReadOnlyRoutePropertyAdapter setKey(@Nonnull String newKey) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Map<String, String> getProperties() {
            return Collections.emptyMap();
        }

    }

    private static final class NeGatewayRoutePropertyAdapter
            extends ReadOnlyRoutePropertyAdapter {

        private final NeGatewayRouteData route;

        private NeGatewayRoutePropertyAdapter(NeGatewayRouteData route) {
            this.route = route;
        }

        @Override
        public Optional<String> getProperty(@Nonnull String name) {
            return route.getOpaqueProperty(name);
        }

        @Override
        public Optional<String> getCost() {
            return Optional.of(String.valueOf(route.getCost()));
        }

        @Override
        public Optional<String> getPriority() {
            return Optional.of(String.valueOf(route.getPriority()));
        }

        @Override
        public Optional<String> isUsed() {
            return Optional.of(String.valueOf(route.isUsed()));
        }

        @Override
        public Optional<String> getDomain() {
            return route.getDomain();
        }

        @Override
        public Optional<String> getKey() {
            return Optional.ofNullable(route.getKey());
        }

        @Override
        public Map<String, String> getProperties() {
            return route.getAllOpaqueProperties();
        }

        @Override
        public Optional<String> getGneName() { return Optional.ofNullable(route.getGneName()); }
    }

    private static final class NePropertyBagAdapter
            extends ReadOnlyRoutePropertyAdapter {

        private final Collection<Attribute> attributes;
        private final Collection<PropertyInfo> propertyInfo;
        private final NeRoutePropertyAdapter<?> defaults;

        protected NePropertyBagAdapter(Collection<Attribute> attributes,
                Collection<PropertyInfo> propertyInfo,
                NeRoutePropertyAdapter<?> defaults) {
            this.attributes = attributes;
            this.propertyInfo = propertyInfo;
            this.defaults = defaults;
        }

        @Override
        public Optional<String> getProperty(@Nonnull final String name) {
            final Optional<PropertyInfo> info = tryFind(propertyInfo, input -> input.getName().equals(name));
            return info.isPresent() ? Optional.ofNullable(info.get().getValue()) : defaults.getProperty(name);
        }
        
        private static <T> Optional<T> tryFind(Collection<T> collection, java.util.function.Predicate<T> predicate){
            return collection.stream().filter(predicate).findFirst();
        }

        private Optional<String> getFromMapping(final RouteMapping mapping) {
            final Optional<Attribute> attribute = tryFind(attributes, input -> input.getMapsTo() == mapping);
            return attribute.isPresent() ? getProperty(attribute.get().getName()) : Optional.empty();
        }

        @Override
        public Optional<String> getCost() {
            return getFromMapping(RouteMapping.COST).map(Optional::of).orElse(defaults.getCost());
        }

        @Override
        public Optional<String> getPriority() {
            return getFromMapping(RouteMapping.PRIORITY).map(Optional::of).orElse(defaults.getPriority());
        }

        @Override
        public Optional<String> getDomain() {
            return getFromMapping(RouteMapping.DOMAIN_NAME).map(Optional::of).orElse(defaults.isUsed());
        }

        @Override
        public Optional<String> getGneName() { return getFromMapping(RouteMapping.GNE_NAME).map(Optional::of).orElse(defaults.getGneName()); }

        @Override
        public Optional<String> isUsed() {
            return getFromMapping(RouteMapping.USAGE).map(Optional::of).orElse(defaults.isUsed());
        }

        @Override
        public Optional<String> getKey() {
            return Optional.empty();
        }
    }

    private static final class NeRoutePropertyAdapterDefaults
            extends ReadOnlyRoutePropertyAdapter {

        private final int defaultCost;
        private final int defaultPriority;
        private final boolean defaultUsage;

        protected NeRoutePropertyAdapterDefaults(int defaultCost, int defaultPriority,
                boolean defaultUsage) {
            this.defaultCost = defaultCost;
            this.defaultPriority = defaultPriority;
            this.defaultUsage = defaultUsage;
        }

        @Override
        public Optional<String> getProperty(@Nonnull String name) {
            return Optional.empty();
        }

        @Override
        public Optional<String> getCost() {
            return Optional.of(Integer.toString(defaultCost));
        }

        @Override
        public Optional<String> getPriority() {
            return Optional.of(Integer.toString(defaultPriority));
        }

        @Override
        public Optional<String> isUsed() {
            return Optional.of(Boolean.toString(defaultUsage));
        }

        @Override
        public Optional<String> getDomain() {
            return Optional.empty();
        }

        @Override
        public Optional<String> getGneName() { return Optional.empty(); }

        @Override
        public Optional<String> getKey() {
            return Optional.empty();
        }
    }

    private static final class NeRoutePropertyAdapterWithoutDefaults
            extends ReadOnlyRoutePropertyAdapter {

        @Override
        public Optional<String> getProperty(@Nonnull String name) {
            return Optional.empty();
        }

        @Override
        public Optional<String> getCost() {
            return Optional.empty();
        }

        @Override
        public Optional<String> getPriority() {
            return Optional.empty();
        }

        @Override
        public Optional<String> isUsed() {
            return Optional.empty();
        }

        @Override
        public Optional<String> getDomain() {
            return Optional.empty();
        }

        @Override
        public Optional<String> getGneName() { return Optional.empty(); }

        @Override
        public Optional<String> getKey() {
            return Optional.empty();
        }
    }

    /**
     * Given a collection of {@link PropertyInfo} instances per index,
     * coalesce them all into a single gateway route builder.
     */
    private final class TransformRouteInfoIntoBuilder implements
            Function<Entry<Integer, Collection<PropertyInfo>>, NeGatewayRouteBuilder> {

        private final NePropertySource context;

        protected TransformRouteInfoIntoBuilder(NePropertySource context) {
            this.context = context;
        }

        @Override
        @Nullable
        public NeGatewayRouteBuilder apply(@Nonnull Entry<Integer,Collection<PropertyInfo>> entry) {
            final int defaultPriority = entry.getKey() + 1;
            final NeRoutePropertyAdapterDefaults defaults = new NeRoutePropertyAdapterDefaults(0, defaultPriority, false);
            final Map<String, Attribute> routeAttributes = neType.getGatewayRouteAttributes();
            final Optional<String> key = getFromSource(neType, neType.getGatewayRouteAddressKeySource(), routeAttributes,
                            new NePropertyBagAdapter(routeAttributes.values(), entry.getValue(), defaults), context);
            final NeGatewayRouteBuilder routeBuilder;
            if (key.isPresent()) {
                routeBuilder = new NeGatewayRouteBuilder();
                routeBuilder.setKey(key.get()); // we need to set the key just to build the underlying route.
                routeBuilder.setPriority(defaultPriority); // set the route priority just in case it isn't included in the property bag.
                for (final PropertyInfo property : entry.getValue()) {
                    set(routeAttributes.get(property.getName()), routeBuilder, property.getValue());
                }
            } else {
                LOGGER.warn("Discarding route without key: {}", entry.getValue());
                routeBuilder = null;
            }
            return routeBuilder;
        }

    }

    private void set(Attribute attribute, NeConnectionRouteSetters<?> mutation, String value) {
        final String name = attribute.getName();
        try {
            if (null == attribute.getSource()) { // properties with "source" defined are read-only
                if (null == attribute.getMapsTo()) {
                    mutation.setProperty(name, value);
                } else {
                    switch (attribute.getMapsTo()) {
                    case COST:
                        mutation.setCost(Integer.parseInt(value));
                        break;
                    case PRIORITY:
                        mutation.setPriority(Integer.parseInt(value));
                        break;
                    case USAGE:
                        mutation.setUsed(Boolean.parseBoolean(value));
                        break;
                    case DOMAIN_NAME:
                        mutation.setDomain(Optional.of(value));
                        break;
                    case GNE_NAME:
                        mutation.setGneName(value);
                        break;
                    default:
                    case DOMAIN_STATUS:
                        LOGGER.warn("Unsupported gateway route attribute '{}' = '{}' mapping: {}",
                                name, value, attribute.getMapsTo());
                        break;
                    }
                }
            }
        } catch (final NumberFormatException e) {
            LOGGER.error("Invalid value '{}' for gateway route attribute '{}'", value, name);
        }
    }

    private static Optional<NeGatewayRouteData> tryFindRouteWithIndex(Iterable<NeGatewayRouteData> gatewayRoutes, final int index) {
        return tryFind(
                gatewayRoutes,
                route -> route.getPriority() == index + 1 // indexes are zero-based
                );
    }

    private static <T> Optional<T> tryFind(Iterable<T> iterable, java.util.function.Predicate<T> predicate){
        return StreamSupport.stream(iterable.spliterator(), false).filter(predicate).findFirst();
    }

    private void put(Map<String, String> properties, int index, String field, Optional<String> value) {
        if (value.isPresent()) {
            put(properties, index, field, value.get());
        }
    }

    private void put(Map<String, String> properties, int index, String field, String value) {
        properties.put(String.format("%s_%03d", field, index), value);
    }

}
