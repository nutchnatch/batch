package com.ossnms.dcn_manager.core.entities.ne.data;

import java.util.Map;
import java.util.Optional;

public interface NeConnectionRouteSetters<T extends NeConnectionRouteSetters<?>> {

    /**
     * @param priority New route priority.
     */
    T setPriority(int priority);

    /**
     * @param cost New route cost.
     */
    T setCost(int cost);

    /**
     * @param used New route usage information.
     */
    T setUsed(boolean used);

    /**
     * @param key New route key.
     */
    T setKey(String key);

    /**
     * @param domain New route domain name.
     */
    T setDomain(Optional<String> domain);

    /**
     * @param gneName The new provider GNE name.
     */
    T setGneName(String gneName);

    /**
     * @param key The name of the property to set.
     * @param value Value for the property to set.
     * @throws NullPointerException If the specified key or value is null.
     */
    T setProperty(String key, String value);

    /**
     * @param properties A map of property values to add or replace in the current set of properties.
     */
    T setProperties(Map<String, String> properties);

}