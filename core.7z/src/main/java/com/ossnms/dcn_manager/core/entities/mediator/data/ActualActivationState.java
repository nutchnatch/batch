package com.ossnms.dcn_manager.core.entities.mediator.data;

/**
 * Describes the actual, i.e., real, possible states for activation.
 */
public enum ActualActivationState {
    /** The entity is in an active state, i.e., connected and ready for operation. */
    ACTIVE,
    /** The entity is inactive, i.e., disconnected and not ready for operation. */
    INACTIVE,
    /**
     * Activation has failed in the entity. It is not ready for operation and is
     * most likely disconnected. This state may also occur after a successful activation
     * should connectivity be lost.
     */
    FAILED,
    /** The entity is undergoing activation, i.e., it is connecting and/or getting ready. */
    ACTIVATING,
    /** The entity is undergoing deactivation, i.e., it is disconnecting and cleaning up. */
    DEACTIVATING,
    /** The entity is starting up, as in activation has been scheduled */
    STARTINGUP,
    /** The entity is shutting down, as in deactivation has been scheduled */
    SHUTTINGDOWN    
}
