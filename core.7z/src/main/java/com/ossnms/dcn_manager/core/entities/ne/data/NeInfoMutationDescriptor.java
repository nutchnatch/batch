package com.ossnms.dcn_manager.core.entities.ne.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Optional;

/**
 * Contains all data that should be changed on {@link NeInfoData},
 * when applied as a single atomic mutation by the repository.
 */
public class NeInfoMutationDescriptor extends MutationDescriptor<NeInfoData, NeInfoMutationDescriptor> {

    private Optional<Integer> channelId = Optional.empty();
    private Optional<String> proxyType = Optional.empty();
    private Optional<String> coreId = Optional.empty();
    private Optional<String> usedBy = Optional.empty();
    private Optional<String> iconId = Optional.empty();
    private Optional<RequiredActivationState> activationState = Optional.empty();
    private Optional<Boolean> commsLostAlarmRaised = Optional.empty();

    public NeInfoMutationDescriptor(NeInfoData target) {
        super(target);
    }

    @Override
    protected NeInfoMutationDescriptor self() {
        return this;
    }

    @Override
    protected NeInfoData doApply() {
        final boolean isAnyTypeInfoSet = proxyType.isPresent();
        final boolean isAnyIdInfoSet = coreId.isPresent() || channelId.isPresent();
        final boolean isAnyConnectionStateSet = activationState.isPresent() || commsLostAlarmRaised.isPresent();
        final boolean isUsageOrIconSet = usedBy.isPresent() || iconId.isPresent();
        return isAnyTypeInfoSet || isAnyIdInfoSet || isUsageOrIconSet || isAnyConnectionStateSet
                   ? new NeInfoBuilder()
                        .setProxyType(proxyType.orElse(getTarget().getProxyType()))
                        .setCoreId(coreId.map(Optional::of).orElse(getTarget().getCoreId()))
                        .setUsedBy(usedBy.map(Optional::of).orElse(getTarget().getUsedBy()))
                        .setIconId(iconId.map(Optional::of).orElse(getTarget().getIconId()))
                        .setRequiredActivationState(activationState.orElse(getTarget().getRequiredActivationState()))
                        .setCommsLostAlarmRaised(commsLostAlarmRaised.orElse(getTarget().isCommsLostAlarmRaised()))
                        .build(getTarget().getId(), channelId.orElse(getTarget().getChannelId()), getTarget().getVersion())
                   : getTarget();
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .omitNullValues()
                .add("channelId", channelId.orElse(null))
                .add("proxyType", proxyType.orElse(null))
                .add("coreId", coreId.orElse(null))
                .add("usedBy", usedBy.orElse(null))
                .add("iconId", iconId.orElse(null))
                .add("requiredActivationState", activationState.orElse(null))
                .add("commsLostAlarmRaised", commsLostAlarmRaised.orElse(null))
                .toString();
    }


    /**
     * @return NE proxy type name.
     */
    public Optional<String> getProxyType() {
        return proxyType;
    }

    /**
     * @param proxyType New NE proxy type name.
     */
    public NeInfoMutationDescriptor setProxyType(@Nonnull String proxyType) {
        final Optional<String> newValue = Optional.of(proxyType);
        if (!Objects.equal(this.proxyType, newValue)) {
            this.proxyType = newValue;
        }
        return self();
    }

    /**
     * @return TNMS Core identifier.
     */
    public Optional<String> getCoreId() {
        return coreId;
    }

    /**
     * @param coreId The new TNMS Core identifier.
     */
    public NeInfoMutationDescriptor setCoreId(@Nullable String coreId) {
        final Optional<String> newValue = Optional.ofNullable(coreId);
        if (!Objects.equal(this.coreId, newValue)) {
            this.coreId = newValue;
        }
        return self();
    }

    /**
     * @return NE usage by TNMS components.
     */
    public Optional<String> getUsedBy() {
        return usedBy;
    }

    /**
     * @param usedBy The new NE usage by TNMS components.
     */
    public NeInfoMutationDescriptor setUsedBy(@Nonnull String usedBy) {
        final Optional<String> newValue = Optional.of(usedBy);
        if (!Objects.equal(this.usedBy, newValue)) {
            this.usedBy = newValue;
        }
        return self();
    }

    /**
     * @return NE icon identifier in TNMS.
     */
    public Optional<String> getIconId() {
        return iconId;
    }

    /**
     * @param iconId The new NE icon identifier in TNMS.
     */
    public NeInfoMutationDescriptor setIconId(@Nonnull String iconId) {
        final Optional<String> newValue = Optional.of(iconId);
        if (!Objects.equal(this.iconId, newValue)) {
            this.iconId = newValue;
        }
        return self();
    }

    /**
     * @return New NE channel identifier.
     */
    public Optional<Integer> getChannelId() {
        return channelId;
    }

    /**
     * @param channelId New NE channel identifier.
     */
    public NeInfoMutationDescriptor setChannelId(int channelId) {
        final Optional<Integer> newValue = Optional.of(channelId);
        if (!Objects.equal(this.channelId, newValue)) {
            this.channelId = newValue;
        }
        return self();
    }

    /**
     * @return Whether a loss of communications alarm has been raised.
     */
    public Optional<Boolean> getCommsLostAlarmRaised() {
        return commsLostAlarmRaised;
    }

    /**
     * @param raised Whether a loss of communications alarm
     * has been raised.
     */
    public NeInfoMutationDescriptor setCommsLostAlarmRaised(boolean raised) {
        final Optional<Boolean> newValue = Optional.of(raised);
        if (!Objects.equal(commsLostAlarmRaised, newValue)) {
            commsLostAlarmRaised = newValue;
        }
        return self();
    }

    /**
     * @return The new required activation state.
     */
    public Optional<RequiredActivationState> getRequiredActivationState() {
        return activationState;
    }

    /**
     * @param activationState New required activation state.
     */
    public NeInfoMutationDescriptor setRequiredActivationState(@Nonnull RequiredActivationState activationState) {
        final Optional<RequiredActivationState> newValue = Optional.of(activationState);
        if (!Objects.equal(this.activationState, newValue)) {
            this.activationState = newValue;
        }
        return self();
    }

}
