package com.ossnms.dcn_manager.core.outbound;

import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeStartingUpEvent;
import com.ossnms.dcn_manager.core.events.ne.NeConnectionDescriptionChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeGatewayRoutesChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;

/**
 * Describes an API for sending notifications about NE deletion, creation and modification
 * to other components.
 */
public interface NetworkElementNotifications {

    /**
     * Notifies other components that an NE has been deleted.
     * @param ne The deleted NE.
     */
    void notifyDelete(NeEntity ne);

    /**
     * Notifies other components that an NE has been created.
     * @param ne The new NE.
     */
    void notifyCreate(NeEntity ne);

    /**
     * Notifies other components that some modifications have been applied to an NE.
     * @param preferences The description of the modifications applied to an NE domain object.
     */
    void notifyChanges(NeUserPreferencesMutationDescriptor preferences);

    /**
     * Notifies other components that some modifications have been applied to an NE.
     * @param info The description of the modifications applied to an NE domain object.
     */
    void notifyChanges(NeInfoMutationDescriptor info);

    /**
     * Notifies other components that some modifications have been applied to an NE.
     * @param operation The description of the modifications applied to an NE domain object.
     */
    void notifyChanges(NeOperationMutationDescriptor operation);

    /**
     * Notifies other components that some modifications have been applied to an NE.
     * @param connection The description of the modifications applied to an NE domain object.
     */
    void notifyChanges(NeConnectionMutationDescriptor connection);

    /**
     * Notifies other components that some modifications have been applied to an NE.
     * @param routes The description of the modifications applied to an NE domain object.
     */
    void notifyChanges(NeGatewayRoutesChangedEvent routes);

    /**
     * Notifies other components that the NE activation has failed.
     * @param event Instance of the event description class.
     */
    void notifyChanges(NeActivationFailedEvent event);

    /**
     * Notifies other components that the NE has been disconnected.
     * @param event Instance of the event description class.
     */
    void notifyChanges(NeDisconnectedEvent event);

    /**
     * Notifies other components that the NE is undergoing disconnection.
     * @param event Instance of the event description class.
     */
    void notifyChanges(NeDisconnectingEvent event);

    /**
     * Notifies other components that the NE has been initialized.
     * This is equivalent to say that it is fully active.
     * @param event Instance of the event description class.
     */
    void notifyChanges(NeInitializedEvent event);

    /**
     * Notifies other components that the NE is initializing.
     * @param event Instance of the event description class.
     */
    void notifyChanges(NeInitializingEvent event);

    /**
     * Notifies other components that a connection has been established with the NE.
     * @param event Instance of the event description class.
     */
    void notifyChanges(NeConnectedEvent event);

    /**
     * Notifies other components that a connection to the NE is being created.
     * @param event Instance of the event description class.
     */
    void notifyChanges(NeConnectingEvent event);

    /**
     * Notifies other components that a request to activate an NE has been recorded.
     * @param event Instance of the event description class.
     */
    void notifyChanges(Deactivate event);

    /**
     * Notifies other components that a request to deactivate an NE has been recorded.
     * @param event Instance of the event description class.
     */
    void notifyChanges(Activate event);

    /**
     * Notifies other components that the description of the current NE connection
     * has changed.
     * @param event Instance of the event description class.
     */
    void notifyChanges(NeConnectionDescriptionChangedEvent event);

    /**
     * Notifies other components that the description of the current NE connection
     * will change: a connection has been scheduled but has not started yet.
     * @param event Instance of the event description class.
     */
    void notifyChanges(NeStartingUpEvent event);

    /**
     * Notifies other components that the description of the current NE connection
     * will change: a disconnection has been scheduled but has not started yet.
     * @param event Instance of the event description class.
     */
    void notifyChanges(NeShuttingDownEvent event);

    /**
     * Notifies other components that a physical NE connection instance was deleted.
     * @param logicalNeId Logical NE identifier.
     * @param physicalNeId Physical NE connection identifier.
     */
    void notifyDeleteInstance(int logicalNeId, int physicalNeId);

    /**
     * Notifies other components that a new physical NE connection has been created.
     * @param physicalConnectionData Physical NE connection information.
     */
    void notifyCreateInstance(NePhysicalConnectionData physicalConnectionData);
}
