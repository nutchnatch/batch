package com.ossnms.dcn_manager.core.properties.ne;

import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySetters.NeRoutePropertyAdapter;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySource;
import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.core.jaxb.netype.RouteMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class NeRouteProperties {

    protected static final Logger LOGGER = LoggerFactory.getLogger(NeGatewayRouteProperties.class);

    protected NeRouteProperties() {

    }

    /**
     * Retrieves a value from a route instance, according to the name provided
     * and respecting the NE Type name-to-attribute mappings.
     *
     * @param type NE type.
     * @param name Property name.
     * @param routeAttributeMetadata Route attribute metadata from the NE Type.
     * @param route Adaptor class to retrieve data from both mutable and immutable NE route entities.
     * @param entity Gateway route owner NE.
     * @return The property value, if present.
     */
    protected static Optional<String> get(
            @Nonnull NeType type, @Nonnull String name, @Nonnull Map<String, Attribute> routeAttributeMetadata,
            @Nonnull NeRoutePropertyAdapter<?> route, @Nonnull NePropertySource entity) {
        final Attribute attribute = routeAttributeMetadata.get(name);
        Optional<String> value = Optional.empty();
        if (null != attribute) {
            final RouteMapping mapping = attribute.getMapsTo();
            if (mapping == null) {
                final String propertySource = attribute.getSource();
                value = null != propertySource
                        ? getFromSource(type, Optional.ofNullable(propertySource), routeAttributeMetadata, route, entity)
                        : route.getProperty(name);
            } else {
                switch (mapping) {
                case COST:
                    value = route.getCost();
                    break;
                case PRIORITY:
                    value = route.getPriority();
                    break;
                case USAGE:
                    value = route.isUsed();
                    break;
                case DOMAIN_NAME:
                    value = route.getDomain();
                    break;
                case GNE_NAME:
                    value = route.getGneName();
                    break;
                default:
                case DOMAIN_STATUS:
                    LOGGER.warn("Unsupported gateway route attribute '{}' mapping: {}.", name, mapping);
                    break;
                }
            }
        } else {
            LOGGER.warn("Route property '{}' is unknown for NE Type '{}'.", name, type.getName());
        }
        return value;
    }

    /**
     * <p>Regular expression used to replace route property name place holders with their values.<p>
     *
     * <p>The group matcher<code> (\$\{(Property|Route)\.([^\}]+)\}) </code> will match expressions in
     * the format <code>${Property.PROPERTY_NAME}</code> and <code>${Route.PROPERTY_NAME}</code>,
     * where <code>PROPERTY_NAME</code> represents the name of the property whose value we want to use
     * instead of the whole expression.</p>
     *
     * <p><code>Property</code> references will retrieve their values from NE Entity contents.
     * <code>Route</code> references will retrieve their values from Gateway Route contents.</p>
     */
    static final Pattern SOURCE_VARIABLE_PATTERN = Pattern.compile("(\\$\\{(Property|Route)\\.([^\\}]+)\\})", Pattern.CASE_INSENSITIVE);

    static final String ORIGIN_ROUTE = "route";
    static final String ORIGIN_PROPERTIES = "property";

    /**
     * Calculates a property value given a source script.
     * If the source script is not valid, the original source will be returned.
     * Absent route or entity properties mentioned in the source script will not
     * cause an error but the result will be absent.
     *
     * @param source Source script.
     * @param routeAttributeMetadata Route attribute metadata from the NE Type.
     * @param route Gateway route being processed.
     * @param entity Gateway route owner entity.
     * @return The final property value as a string.
     */
    protected static Optional<String> getFromSource(
            @Nonnull NeType type, @Nonnull Optional<String> source,
            @Nonnull Map<String, Attribute> routeAttributeMetadata,
            @Nonnull NeRoutePropertyAdapter<?> route, @Nonnull NePropertySource entity) {
        if (!source.isPresent()) {
            return source;
        }
        final Matcher matcher = SOURCE_VARIABLE_PATTERN.matcher(source.get());
        if (matcher.find()) {
            final StringBuffer buffer = new StringBuffer();
            final NeProperties neProperties = new NeProperties();
            final NeDirectRouteProperties directRouteProperties = new NeDirectRouteProperties();
            do {
                final String origin = matcher.group(2); // Property or Route
                final String propertyName = matcher.group(3);
                final Optional<String> value;
                switch (origin.toLowerCase(Locale.ENGLISH)) {
                case ORIGIN_PROPERTIES:
                    value = neProperties.getProperty(type, entity, propertyName).map(Optional::of)
                            .orElse(directRouteProperties.get(type, entity, propertyName));
                    break;
                case ORIGIN_ROUTE:
                    value = get(type, propertyName, routeAttributeMetadata, route, entity);
                    break;
                default:
                    LOGGER.warn("Unknown source pattern: {}", origin);
                    value = Optional.empty();
                    break;
                }
                if (!value.isPresent() || value.get().isEmpty()) {
                    return Optional.empty();
                }
                matcher.appendReplacement(buffer, value.get());
            } while (matcher.find());
            return Optional.of(buffer.toString());
        }
        return source;
    }

}