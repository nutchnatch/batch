package com.ossnms.dcn_manager.core.configuration.model;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import com.ossnms.dcn_manager.core.jaxb.defaultproperties.Default;
import com.ossnms.dcn_manager.core.jaxb.defaultproperties.Defaults;

import java.util.Collection;
import java.util.Map;

/**
 * Contains all default property values defined in a collection of
 * XML documents.
 */
public class DefaultPropertyValues extends ImmutableModelMap<Defaults> {

    public DefaultPropertyValues(Map<String, Defaults> map) {
        super(map);
    }

    /**
     * Merges all default values specified in a collection of files.
     * @param fileNames Names of files to merge.
     * @return A map with all default values merged.
     */
    public Map<String, String> getAllDefaults(Collection<String> fileNames) {
        final Builder<String, String> builder = ImmutableMap.builder();
        for (final Defaults defaults : forKeys(fileNames).values()) {
            for (final Default defaultEntry : defaults.getDefault()) {
                builder.put(defaultEntry.getKey(), defaultEntry.getValue());
            }
        }
        return builder.build();
    }
}
