package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.policies.common.PolicyJob;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import static java.util.concurrent.CompletableFuture.runAsync;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>An execution policy that is mindful of job priority. Requires all tasks to extend {@link com.ossnms.dcn_manager.core.policies.common.Job}.</p>
 *
 * <p>All jobs are submitted to the normal system executor regardless of their priority until the
 * system executor is exhausted. Once this happens, only high priority jobs will be submitted to
 * an alternative executor until the latter is exhausted as well.</p>
 *
 * <p>Whenever the alternative high priority executor finishes a job, the execution queue feeding
 * this policy is notified that the policy has capacity available. This way any high priority
 * jobs held at the queue are given the opportunity to execute as soon as possible.</p>
 */
final class PriorityExecutionPolicy implements Executor {

    private static final Logger LOGGER = getLogger(PriorityExecutionPolicy.class);

    private static final int FALLBACK_MAXIMUM_THREADS = 1;

    private final Executor fallbackExecutor;
    private final Executor systemExecutor;
    private final CapacityNotificationObserver capacityObserver;

    private final class FallbackThreadPoolExecutor extends ThreadPoolExecutor {

        // ensure that core size is zero and there's a keep alive time to allow automatic shutdown on finalization.
        private static final int FALLBACK_CORE_THREADS = 0;
        private static final int FALLBACK_KEEP_ALIVE_TIME = 30;

        private FallbackThreadPoolExecutor(@Nonnull ThreadFactory threadFactory) {
           super(
                    FALLBACK_CORE_THREADS, FALLBACK_MAXIMUM_THREADS,
                    FALLBACK_KEEP_ALIVE_TIME, TimeUnit.SECONDS,
                    new ArrayBlockingQueue<>(1),
                    threadFactory,
                    new AbortPolicy()
            );
        }

        @Override
        protected void afterExecute(Runnable r, Throwable t) {
            super.afterExecute(r, t);
            capacityObserver.capacityIsAvailable();
        }

    }

    /**
     * Constructs a priority execution policy instance.
     *
     * @param systemExecutor Implementation of the system job execution for system wide load regulation.
     * @param threadFactory Thread factory for supporting a fallback execution policy
     *                      for high priority jobs.
     * @param capacityObserver Observer that will be notified when the high priority fallback executor
     *                         has capacity available to receive new jobs. We use an adaptation of the
     *                         observer patter to loosen coupling.
     */
    PriorityExecutionPolicy(@Nonnull Executor systemExecutor, @Nonnull ThreadFactory threadFactory,
                            @Nonnull CapacityNotificationObserver capacityObserver) {
        this.systemExecutor = systemExecutor;
        this.fallbackExecutor = new FallbackThreadPoolExecutor(threadFactory);
        this.capacityObserver = capacityObserver;
    }

    @Override
    public void execute(@Nonnull Runnable command) {
        LOGGER.debug("Submitting to executor -> {}", command);
        if (((PolicyJob<?>) command).getPriority() == PolicyJob.Priority.HIGH) {
            highPriorityExecution(command);
        } else {
            standardExecution(command);
        }
    }

    /**
     * High priority jobs must begin execution as soon as possible.
     *
     * However if there is no system capacity for running them, they will be submitted to a
     * "fallback" executor. Because the fallback executor is dedicated to high priority tasks,
     * other tasks will not block it thus reducing the possibility of deadlocks between high
     * and lower priority jobs due to thread starvation.
     */
    private void highPriorityExecution(@Nonnull Runnable command) {
        try {
            standardExecution(command);
        } catch (RejectedExecutionException rejection) {
            LOGGER.warn("Executor full, submitting high priority job to fallback executor! -> {}", command);
            fallbackExecutor.execute(command);
        }
    }

    private void standardExecution(@Nonnull Runnable command) {
        runAsync(command, systemExecutor)
                .thenRun(capacityObserver::capacityIsAvailable);
    }
}
