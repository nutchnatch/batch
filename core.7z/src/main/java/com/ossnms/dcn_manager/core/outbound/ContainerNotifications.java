package com.ossnms.dcn_manager.core.outbound;

import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentUpdatedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentUpdatedEvent;

/**
 * Describes an API for sending notifications to other components about
 * container container deletion, creation and modification.
 */
public interface ContainerNotifications {

    /**
     * Notifies other components that a container has been deleted.
     *
     * @param container The deleted container.
     */
    void notifyDelete(ContainerInfo container);

    /**
     * Notifies other components that a container has been created.
     *
     * @param container The new container.
     */
    void notifyCreate(ContainerInfo container);

    /**
     * Notifies other components that a container has been changed.
     *
     * @param changes Changes applied to the container.
     */
    void notifyChanges(ContainerInfoMutationDescriptor changes);

    /**
     * Notifies other components that a container has a new assignment with a NE.
     *
     * @param added The new container assignment
     */
    void notifyChanges(ContainerNeAssignmentAddedEvent added);

    /**
     * Notifies other components that a container was removed assignment with a NE.
     *
     * @param removed The deleted assignment
     */
    void notifyChanges(ContainerNeAssignmentRemovedEvent removed);

    /**
     * Notifies other components that a container was updated assignment with a NE.
     *
     * @param updated Changes applied to the Assignment
     */
    void notifyChanges(ContainerNeAssignmentUpdatedEvent updated);

    /**
     * Notifies other components that a container has a new assignment with a System Container.
     *
     * @param added The new container assignment
     */
    void notifyChanges(ContainerSystemAssignmentAddedEvent added);

    /**
     * Notifies other components that a container was removed assignment with a System Container.
     *
     * @param removed The deleted assignment
     */
    void notifyChanges(ContainerSystemAssignmentRemovedEvent removed);

    /**
     * Notifies other components that a container was updated assignment with a System Container.
     *
     * @param updated Changes applied to the Assignment
     */
    void notifyChanges(ContainerSystemAssignmentUpdatedEvent updated);
}
