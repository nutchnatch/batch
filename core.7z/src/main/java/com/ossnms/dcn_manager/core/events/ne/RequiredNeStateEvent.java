package com.ossnms.dcn_manager.core.events.ne;

import javax.annotation.concurrent.Immutable;


/**
 * <p>
 * Used to signal required NE activation state changes. Derived class instances
 * represent specific NE activation events, namely, activation required and
 * deactivation required events.
 * <br />
 * The following figure depicts the class hierarchy.
 * </p>
 *
 * <p> <figure>
 * <img src="doc-files/ne_required_activation_state_event-class.png">
 * <figcaption>Class diagram of the events related to operations performed on required NE state domain
 * objects</figcaption>
 * </figure> </p>
 *
 * <p>
 * The abstract base class ({@link RequiredNeStateEvent}) defines the information associated to all
 * concrete events, namely {@link RequiredNeStateEvent.Activate} and {@link RequiredNeStateEvent.Deactivate}
 * events. Instead of materializing these concrete event types has derived top-level classes, which would
 * increase the overall solution's complexity (i.e. the total number of top-level classes), concrete event
 * types are materialized as static nested classes, leading to a curious coding pattern in which derived
 * classes are public nested classes of its super class. <br />
 * Despite being a curious coding pattern, the resulting solution reduces overall complexity and increases
 * readability: all related types are contained within the same compilation unit which, given its small size,
 * is not affected by significant complexity increase.
 * </p>
 */
/*
 * @startuml doc-files/ne_required_activation_state_event-class.png

 * abstract class RequiredNeStateEvent <<Immutable>> {
 *      - channelId: int
 *      # RequiredNeStateEvent(neId: int, channelId: int)
 *      # RequiredNeStateEvent(neId: int, channelId: int, description: String)
 *      + getChannelId(): int
 * }
 * class Activate <<Immutable>> {
 *      + Activate(neId: int, channelId: int)
 *      + Activate(neId: int, channelId: int, , description: String)
 * }
 * class Deactivate <<Immutable>> {
 *      + Deactivate(neId: int, channelId: int)
 *      + Deactivate(neId: int, channelId: int, description: String)
 * }
 * abstract class NeEvent <<Immutable>> <|-- RequiredNeStateEvent
 * hide NeEvent members
 * RequiredNeStateEvent <|-- Activate
 * RequiredNeStateEvent <|-- Deactivate

 * @enduml
 */
@Immutable
public abstract class RequiredNeStateEvent extends IdentifiedNeEvent {

    /**
     * Initiates an instance with the given arguments.
     * @param logicalNeId The affected NE identifier.
     * @param physicalChannelId The identifier of the channel to which the affected NE is associated.
     * @param physicalMediatorId The identifier of the mediator to which the affected NE channel is associated.
     * @param neInstanceId NE instance upon which the required state must be enforced.
     * @param activeInstance Whether this refers to the physical NE instance that is
     * currently active (as opposed to the standby instance).
     */
    protected RequiredNeStateEvent(int logicalNeId, int physicalChannelId, int physicalMediatorId, int neInstanceId,
                                   boolean activeInstance) {
        super(logicalNeId, physicalChannelId, physicalMediatorId, neInstanceId, activeInstance);
    }

    /**
     * Class whose instances represent events used to signal that a NE activation has been required.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class Activate extends RequiredNeStateEvent {
        public Activate(int logicalNeId, int physicalChannelId, int physicalMediatorId, int neInstanceId,
                        boolean activeInstance) {
            super(logicalNeId, physicalChannelId, physicalMediatorId, neInstanceId, activeInstance);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE deactivation has been required.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class Deactivate extends RequiredNeStateEvent {
        public Deactivate(int logicalNeId, int physicalChannelId, int physicalMediatorId, int neInstanceId,
                          boolean activeInstance) {
            super(logicalNeId, physicalChannelId, physicalMediatorId, neInstanceId, activeInstance);
        }
    }
}
