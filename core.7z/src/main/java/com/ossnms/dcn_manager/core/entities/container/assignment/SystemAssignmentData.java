package com.ossnms.dcn_manager.core.entities.container.assignment;

import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import org.apache.commons.lang3.builder.EqualsBuilder;

import java.util.Objects;

/**
 * Contains information about a Systems x Container association.
 * Only one association must be a primary assignment.
 * @see AssignmentType#PRIMARY
 */
public class SystemAssignmentData extends AssignmentBase {
    private final int systemContainerId;

    public SystemAssignmentData(final ContainerInfo containerInfo, final int systemContainerId, final AssignmentType assignmentType) {
        super(containerInfo, assignmentType);
        this.systemContainerId = systemContainerId;
    }

    public int getSystemContainerId() {
        return systemContainerId;
    }

    @Override public int hashCode() {
        return Objects.hash(getContainerInfo().getId(), systemContainerId);
    }

    @Override public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final SystemAssignmentData rhs = (SystemAssignmentData) obj;
        return new EqualsBuilder()
                .append(getContainerInfo().getId(), rhs.getContainerInfo().getId())
                .append(systemContainerId, rhs.systemContainerId)
                .isEquals();
    }
}
