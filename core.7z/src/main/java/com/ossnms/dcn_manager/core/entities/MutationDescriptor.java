package com.ossnms.dcn_manager.core.entities;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.ossnms.dcn_manager.core.utils.Consumer;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;
import java.util.Optional;

/**
 * <p>Abstract class that is the base class for all mutation descriptors, that is,
 * objects that represent mutation requests to be applied (on the repository)
 * to domain objects.</p>
 *
 * Design decisions:
 * <ul>
 * 		<li>A fluent interface is provided to facilitate usage; </li>
 * 		<li>Instances are not thread-safe because they are not to be shared by
 * 		multiple threads. </li>
 * </ul>
 *
 * <p><figure>
 * <img src="doc-files/mutation_use_case_detail.png">
 * <figcaption>Participants in an use case that mutates a given domain object.</figcaption>
 * </figure></p>
 *
 * @param <T> the concrete type of the domain object to which the mutation refers to
 * @param <M> the concrete mutation descriptor type, to enable compile time type
 * verifications
 */
/*
 * @startuml doc-files/mutation_use_case_detail.png

 * !definelong CALL_START(from,to,inMsg,nothing)
 * from -> to : inMsg
 * activate to
 * !enddefinelong

 * !definelong CALL_END(from,to,outMsg,nothing)
 * from <-- to : outMsg
 * deactivate to
 * !enddefinelong

 * !definelong CALL(from,to,inMsg,outMsg,nothing)
 * CALL_START(from,to,inMsg,nothing)
 * CALL_END(from,to,outMsg,nothing)
 * !enddefinelong

 * !define CALL_ASYNC(from,to,msg,nothing) from ->> to : msg

 * !definelong TRIGGER_CALL(from,to,inMsg,nothing)
 * from --\\ to : inMsg
 * activate to
 * !enddefinelong

 * hide footbox
 * autonumber

 * participant MutatingUseCase << command >>
 * participant "repo: SomeDORepository" as SomeDORepository << abstraction >>
 * participant "instance: SomeDO" as SomeDO << domain object >>
 * participant "mutation: SomeDOMutation" as SomeDOMutation << mutation descriptor>>

 * activate MutatingUseCase

 * CALL(MutatingUseCase,SomeDORepository,repo.findDO(id),instance,)
 * CALL_START(MutatingUseCase,SomeDO,instance.doSomething(),)
 * CALL(SomeDO,SomeDOMutation,<<create>>,mutation,)
 * CALL(SomeDO,SomeDOMutation,<<specify continuation>>,,)
 * CALL_END(MutatingUseCase,SomeDO,mutation,)
 * CALL_START(MutatingUseCase,SomeDORepository,repo.tryUpdate(mutation),)

 * CALL_START(SomeDORepository,SomeDOMutation,mutation.apply(),)
 * CALL(SomeDOMutation,SomeDO,<<create>>,newInstance,)
 * CALL_END(SomeDORepository,SomeDOMutation,newInstance,)
 * CALL_START(SomeDORepository,SomeDOMutation,on sucess: mutation.applied(),)
 * CALL_START(SomeDOMutation,SomeDOMutation,<<execute continuation>>,)

 * CALL_END(SomeDORepository,SomeDOMutation,,)
 * deactivate SomeDOMutation
 * CALL_END(MutatingUseCase,SomeDORepository, , )

 * deactivate MutatingUseCase
 * @enduml
 */
@NotThreadSafe
public abstract class MutationDescriptor<T extends BusinessObjectData, M extends MutationDescriptor<T, M>> {

	/** The domain object instance to which the mutation is to be applied. */
	private final T targetDomainObject;

    /** The domain object that resulted from producing the mutation, if present. */
    private Optional<T> mutationResult;

    /** The function to be executed after the mutation is applied, if present. */
    private Optional<Consumer<M>> whenApplied;

	/**
	 * Initiates an instance that will be used to mutate the given domain object instance
	 * @param target the domain object instance to which the mutation will be applied
	 */
	public MutationDescriptor(@Nonnull T target) {
		targetDomainObject = target;
		mutationResult = Optional.empty();
		whenApplied = Optional.empty();
	}

	/**
	 * Abstract method used to obtain a statically typed reference to the concrete mutation
	 * descriptor type.
	 * @return a statically typed version of the this reference
	 */
	protected abstract M self();

	/** @return the domain object instance (i.e. T instance) to which the mutation will be applied */
	public T getTarget() {
		return targetDomainObject;
	}

    /**
     * Gets the domain object instance (i.e. T instance) that resulted from applying the current mutation
     * @throws IllegalStateException if the mutation has not yet been applied (i.e. it's {@link #apply()}
     * method has not yet been called)
     * @return the domain object instance that resulted from applying the mutation
     */
	public T getResult() {
		return mutationResult.get();
	}

	/**
	 * Sets the consumer that will be called once the mutation result is applied on the repository.
	 * The consumer is used to specify the continuation behavior once the mutation has been
	 * successfully applied on the repository.
	 * @param function the consumer that specifies the continuation behavior
	 * @return a statically typed version of the this reference, to enable fluent use
	 */
    public M whenApplied(@Nonnull Consumer<M> function) {
    	this.whenApplied = Optional.ofNullable(function);
    	return self();
    }

    /**
     * Abstract method that actually produces the new domain object instance that results from
     * applying the current mutation to the target domain object.
     * @return the newly created domain object instance, or the original one if the mutation does
     * not actually refers to any modification of the target domain object
     */
    protected abstract T doApply();

    /**
     * Method that produces the current mutation to the target domain object instance, producing the
     * new domain object instance. The mutation result is produced by the {@link MutationDescriptor#doApply()}
     * method, which deals with the concrete instantiation details.
     * @return the newly created domain object instance
     */
    public final T apply() {
    	final T result = doApply();
    	this.mutationResult = Optional.of(result);
    	return result;
    }

    /**
     * Signals that the mutation has been applied on the repository, thus triggering
     * an eventual continuation (i.e. the existing consumer, if one exists)
     * @throws IllegalStateException if the mutation result has not been computed
     * (i.e. through a call to {@link #apply()}.
     */
    public void applied() {
    	if(!mutationResult.isPresent()) {
    		throw new IllegalStateException();
    	}

    	if(this.whenApplied.isPresent()) {
    		this.whenApplied.get().accept(self());
    	}
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        final ToStringHelper helper = MoreObjects.toStringHelper(this);
        helper.add("targetDomainObject", targetDomainObject.toString());
        return helper.toString();
    }
}
