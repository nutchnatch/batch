/**
 * <p>Contains data and behavior concerning the management of all DCN Container domain entities.</p>
 *
 * <p>DCN Containers have simple rules:</p>
 * <ul>
 * <li>They have unique names.</li>
 * <li>They may contain zero or more NEs.</li>
 * <li>They may contain zero or more Containers.</li>
 * <li>They are not associated to Channels or Mediators.</li>
 * </ul>
 *
 * <p>Even though a Container is a simple grouping object, there are specialized containers
 * that have slightly different rules and different purposes. Hence an object hierarchy was created
 * to emphasize their differences and their similarities as depicted below.</p>
 *
 * <p><img src="doc-files/container-classes.png"/></p>
 *
 * <p>Other entity management objects follow the same hierarchical pattern: creation, deletion
 * and mutation descriptors.</p>
 *
 */
/*
 * @startuml doc-files/container-classes.png
 * class ContainerInfoBase <<abstract>> {
 * + id
 * + parentId
 * + name
 * + description
 * # ContainerInfoBase(...)
 * }
 * class ContainerInfo <<final>>
 * class SystemContainerInfo <<final>>
 * ContainerInfoBase <|-- SystemContainerInfo
 * ContainerInfoBase <|-- ContainerInfo
 * @enduml
 */
package com.ossnms.dcn_manager.core.entities.container;
