package com.ossnms.dcn_manager.core.policies.common;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.time.Duration;
import java.time.Instant;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Base class for the implementations of work units to be executed as soon as DCN
 * interaction policies allow it. This is merely an utility class to be used in interaction
 * policies' implementations, thereby eliminating code repetition. </p>
 *
 * @param <RB> The base class for events that originate interaction jobs (Required event
 * base class).
 */
public abstract class Job<RB> implements PolicyJob<RB> {

    private volatile boolean cancelled = false;

    /** The originating event. */
    private final RB event;
    /** Job priority. */
    private final Priority priority;

    /**
     * Initiates the instance with the given event.
     * @param requestEvent The event that corresponds to the job being instantiated.
     */
    public Job(@Nonnull RB requestEvent) {
        this(requestEvent, Priority.MEDIUM);
    }

    /**
     * Initiates the instance with the given event and priority classification.
     * @param requestEvent The event that corresponds to the job being instantiated.
     */
    public Job(@Nonnull RB requestEvent, @Nonnull Priority priority) {
        this.event = requestEvent;
        this.priority = priority;
    }

    @Override
    public RB getOriginatingEvent() {
        return event;
    }

    @Override
    public final void run() {
        if (!cancelled) {
            final Instant started = Instant.now();
            final Logger logger = getLogger(getClass());
            try {
                logger.debug("Running job for event {}", getOriginatingEvent());
                runJob();
            } catch (Exception e) {
                logger.error("FAILING job for event {}: {}", getOriginatingEvent(), getStackTraceAsString(e));
            } finally {
                logger.debug("Finished job for event {}, duration = {} ms", getOriginatingEvent(),
                        Duration.between(started, Instant.now()).toMillis());
            }
        }
    }

    protected abstract void runJob();

    /**
     * Notifies an ongoing job that it is being cancelled. Job implementations
     * are required to override this method whenever further actions are warranted
     * in a cancellation scenario.
     */
    @Override
    public void cancel() {
        if (!cancelled) {
            /*
            Best effort attempt at cancellation.
            Do not attempt to interrupt the thread running the job. We have a free-threaded event/notification
            processing model, which does not guarantee thread affinity. Hence any thread may be processing events
            at some point in time. If we interrupt the job thread we risk interrupting event processing as well.
             */
            cancelled = true;
            getLogger(getClass()).debug("Signalled cancellation of job based on event {}", getOriginatingEvent());
        }
    }

    @Override
    public Priority getPriority() {
        return priority;
    }

    @Override
    public int compareTo(@Nonnull PolicyJob<?> o) {
        return priority.compareTo(o.getPriority());
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("priority", priority)
                .append("event", event)
                .append("canceled", cancelled)
                .toString();
    }
}
