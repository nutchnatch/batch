package com.ossnms.dcn_manager.core.events.domain;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

/**
 * Informs that the name of a domain has been changed.
 */
@Immutable
public final class DomainRenamed extends DomainEvent {

    private final String newName;

    /**
     * Constructs a new object instance.
     * @param domainId Identifier of the existing domain being renamed.
     * @param newName New domain name desired.
     */
    public DomainRenamed(int domainId, @Nonnull String newName) {
        super(domainId);
        this.newName = newName;
    }

    /**
     * @return The new domain name desired.
     */
    public String getNewName() {
        return newName;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("newName", newName)
                .toString();
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        final DomainRenamed rhs = (DomainRenamed) obj;
        return new EqualsBuilder()
                .append(getDomainId(), rhs.getDomainId())
                .append(getDetailedDescription(), rhs.getDetailedDescription())
                .append(getNewName(), rhs.getNewName())
                .isEquals();
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .appendSuper(super.hashCode())
                .append(newName)
                .hashCode();
    }
}
