package com.ossnms.dcn_manager.core.configuration.loaders;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import static com.google.common.base.Predicates.notNull;
import static com.google.common.collect.Iterables.filter;
import static com.google.common.collect.Iterables.transform;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.Configuration;
import com.ossnms.dcn_manager.core.configuration.model.DefaultPropertyValues;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.PasswordPropertyMetadata;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import java.net.URL;
import java.util.Collection;
import java.util.Set;
import java.util.regex.Pattern;
import static java.util.stream.Collectors.toSet;
import javax.annotation.Nonnull;
import org.reflections.Reflections;
import org.reflections.scanners.ResourcesScanner;
import org.reflections.util.ConfigurationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XmlConfigurationLoader {

    private static final Logger LOGGER = LoggerFactory.getLogger(XmlConfigurationLoader.class);
    private final Collection<URL> resourceURLs;
    private Types<NeType> neTypes;
    private Types<ChannelType> channelTypes;
    private Types<MediatorType> mediatorTypes;
    private DefaultPropertyValues defaultPropertyValues;
    private PasswordPropertyMetadata passwordPropertyMetadata;

    public XmlConfigurationLoader(Collection<URL> resourceURLs) {
        this.resourceURLs = resourceURLs;
    }

    public StaticConfiguration load() {
        load(resourceURLs);
        return new Configuration(neTypes, channelTypes, mediatorTypes, defaultPropertyValues, passwordPropertyMetadata);
    }

    /**
     * Creates a new object, loading all static configuration XML files found in a
     * collection of resource URLs.
     *
     * @param resourceURLs The resource URLs to scan for static configuration XML files.
     */
    private void load(Collection<URL> resourceURLs) {
        passwordPropertyMetadata = new PasswordPropertyLoader().load(getResources(resourceURLs, ".*passwordproperties.*"));
        defaultPropertyValues = new DefaultPropertyLoader().load(getResources(resourceURLs, ".*defaultproperties.*"));
        Types<NeType> allNes = new TypeLoaderNe(defaultPropertyValues).load(getResources(resourceURLs, ".*netype.*"));
        Types<ChannelType> allChannels = new TypeLoaderChannel(allNes, defaultPropertyValues).load(getResources(resourceURLs, ".*emtype.*"));
        mediatorTypes = new TypeLoaderMediator(allChannels, defaultPropertyValues).load(getResources(resourceURLs, ".*mediatortype.*"));
        channelTypes = Types.from(collectAll(MediatorType::getSupportedChannelTypes, mediatorTypes.values()));
        neTypes = Types.from(collectAll(ChannelType::getSupportedNeTypes, channelTypes.values()));
    }

    private <P, C> Collection<C> collectAll(java.util.function.Function<P, Collection<C>> getChildren, Collection<P> parents) {
        return parents.stream().map(getChildren).flatMap(Collection::stream).collect(toSet());
    }

    private Iterable<URL> getResources(Collection<URL> resourceURLs, String pattern) {
        final Reflections reflections = new Reflections(
                new ConfigurationBuilder()
                        .setUrls(resourceURLs)
                        .setScanners(new ResourcesScanner())
                        .filterInputsBy(new ContainsPattern(pattern))
        );
        final Set<String> resources = reflections.getResources(Pattern.compile(".*\\.xml"));
        return filter(transform(resources, new ResourceUrlFinder()), notNull());
    }

    private static final class ContainsPattern implements Predicate<String> {
        private final Pattern pattern;

        public ContainsPattern(String string) {
            pattern = Pattern.compile(string);
        }

        @Override
        public boolean apply(String input) {
            LOGGER.trace("Verifying input {}", input);
            return pattern.matcher(input).matches();
        }
    }

    private static final class ResourceUrlFinder implements Function<String, URL> {

        private static final ClassLoader CLASSLOADER = XmlConfigurationLoader.class.getClassLoader();

        @Override
        public URL apply(@Nonnull String resource) {
            LOGGER.debug("Looking up XML configuration resource '{}' in the class path.", resource);
            return CLASSLOADER.getResource(resource);
        }

    }

}
