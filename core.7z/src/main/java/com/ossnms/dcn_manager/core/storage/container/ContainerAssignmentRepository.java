package com.ossnms.dcn_manager.core.storage.container;

import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Describes all operations that must be supported by a repository
 * of DCN Containers Assignment.
 */
public interface ContainerAssignmentRepository {
    /**
     * Add new NE assignment
     *
     * @param neAssignmentData assignment NE x Container
     * @throws RepositoryException
     */
    void addNeAssignment(@Nonnull final NeAssignmentData neAssignmentData) throws RepositoryException;

    /**
     * Add new System assignment
     *
     * @param systemAssignmentData assignment System x Container
     * @throws RepositoryException
     */
    void addSystemAssignment(@Nonnull final SystemAssignmentData systemAssignmentData) throws RepositoryException;

    /**
     * Update the Assignment Type.
     *
     * @param neAssignmentData assignment NE x Container
     * @return true if the assignment was successfully updated
     * @throws RepositoryException
     */
    boolean tryUpdateNeAssignment(@Nonnull final NeAssignmentData neAssignmentData) throws RepositoryException;

    /**
     * Update the Assignment Type.
     *
     * @param systemAssignmentData assignment System x Container
     * @return true if the assignment was successfully updated
     * @throws RepositoryException
     */
    boolean tryUpdateSystemAssignment(@Nonnull final SystemAssignmentData systemAssignmentData)
            throws RepositoryException;

    /**
     * Remove a System assignment.
     *
     * @param systemAssignmentData assignment System x Container
     * @return true if the assignment was successfully removed
     * @throws RepositoryException
     */
    boolean tryRemoveSystemAssignment(@Nonnull final SystemAssignmentData systemAssignmentData)
            throws RepositoryException;

    /**
     * Remove a NE assignment.
     *
     * @param neAssignmentData assignment NE x Container
     * @return true if the assignment was successfully removed
     * @throws RepositoryException
     */
    boolean tryRemoveNeAssignment(@Nonnull final NeAssignmentData neAssignmentData) throws RepositoryException;

    /**
     * Gets all NE Assignment by NE id.
     *
     * @param neId The Ne ID to be query
     * @return The NE x Container assignment collection
     */
    Iterable<NeAssignmentData> queryAllByNE(int neId);

    /**
     * Gets all System Assignment by System id.
     *
     * @param systemContainerId The Ne ID to be query
     * @return The System x Container assignment collection
     */
    Iterable<SystemAssignmentData> queryAllBySystem(int systemContainerId);

    /**
     * Gets a System Assignment by composite ID.
     *
     * @param systemContainerId The system ID to be query
     * @param containerId The container ID to be query
     * @return The System x Container assignment collection
     */
    Optional<SystemAssignmentData> querySystemAssignment(int systemContainerId, int containerId)
            throws RepositoryException;

    /**
     * Gets a NE Assignment by composite ID.
     *
     * @param neId The ne ID to be query
     * @param containerId The container ID to be query
     * @return The NE x Container assignment collection
     */
    Optional<NeAssignmentData> queryNeAssignment(int neId, int containerId)
            throws RepositoryException;

    /**
     * Gets all NE Assignment by Container id.
     *
     * @param containerId Container Ne ID to be query
     * @return The NE x Container assignment collection
     */
    Iterable<Integer> queryAllNeIdByContainer(int containerId);

    /**
     * Gets all System Assignment by Container id.
     *
     * @param containerId The Container ID to be query
     * @return The System x Container assignment collection
     */
    Iterable<Integer> queryAllSystemIdByContainer(int containerId);
}
