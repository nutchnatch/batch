package com.ossnms.dcn_manager.core.outbound;

import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.*;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;

import javax.annotation.Nonnull;

/**
 * Describes an API for sending notifications to other components about mediator deletion, creation
 * and modification.
 *
 * Because the mediator entity is segregated in several facets, update notification methods are overloaded
 * with all facet types and the entity aggregate type. Notice that these overloads are not required in the
 * methods for notification of creation and deletion: these operations are only applied to the aggregate.
 *
 * TODO: Eliminate dependencies to entities and operation descriptors to prevent circular dependencies
 */
public interface MediatorNotifications {

    /**
     * Inform the world that a mediator has been created.
     * @param mediator New mediator entity aggregate.
     */
    void notifyCreate(@Nonnull MediatorEntity mediator);

    /**
     * Inform the world that a mediator has been deleted.
     * @param mediator Old mediator entity aggregate instance.
     */
    void notifyDelete(@Nonnull MediatorEntity mediator);

    /**
     * Inform the world that a mediator has been modified somehow.
     * @param mutation The mutation descriptor that originated the modification.
     */
    void notifyUpdate(@Nonnull MediatorInfoMutationDescriptor mutation);

    /**
     * Inform the world that a mediator has started the activation process.
     * Its actual activation state has been changed to 'activating'.
     * @param mediatorActivatingEvent Event information.
     */
    void notifyChanges(@Nonnull MediatorActivatingEvent mediatorActivatingEvent);

    /**
     * Inform the world that a mediator has been activated, i.e., that its actual activation state
     * has been changed to 'active'.
     * @param mediatorActivatedEvent Event information.
     */
    void notifyChanges(@Nonnull MediatorActivatedEvent mediatorActivatedEvent);

    /**
     * Inform the world that a mediator has started the deactivation process.
     * Its actual activation state has been changed to 'deactivating'.
     * @param mediatorDeactivatingEvent Event information.
     */
    void notifyChanges(@Nonnull MediatorDeactivatingEvent mediatorDeactivatingEvent);

    /**
     * Inform the world that a mediator has been deactivated, i.e., that its actual activation state
     * has been changed to 'inactive'.
     * @param mediatorDeactivatedEvent Event information.
     */
    void notifyChanges(@Nonnull MediatorDeactivatedEvent mediatorDeactivatedEvent);

    /**
     * Inform the world that activation of a mediator has failed, i.e., that its actual activation state
     * has been changed to 'failed'.
     * @param mediatorActivationFailedEvent Event information.
     */
    void notifyChanges(@Nonnull MediatorActivationFailedEvent mediatorActivationFailedEvent);

    /**
     * Inform the world that a mediator has been requested to deactivate, i.e., that its required activation
     * state has been changed to 'inactive'.
     * @param event Event information.
     */
    void notifyChanges(@Nonnull DeactivateMediatorEvent event);

    /**
     * Inform the world that a mediator has been requested to activate, i.e., that its required activation
     * state has been changed to 'active'.
     * @param event Event information.
     */
    void notifyChanges(@Nonnull ActivateMediatorEvent event);

    /**
     * Inform the world that a mediator will start the activation process.
     * Its actual activation state has been changed to 'startingUp'.
     * @param mediatorStartingUpEvent Event information.
     */
    void notifyChanges(@Nonnull MediatorStartingUpEvent mediatorStartingUpEvent);

    
    /**
     * Inform the world that a mediator will start the shutdown process.
     * Its actual activation state has been changed to 'shuttingDown'.
     * @param mediatorShuttingDownEvent Event information.
     */
    void notifyChanges(@Nonnull MediatorShuttingDownEvent mediatorShuttingDownEvent);


    /**
     * Inform the world that a mediator physical instance has been deleted.
     * @param mediatorId Logical mediator identifier.
     * @param physicalInstanceId Physical mediator instance identifier.
     */
    void notifyDeleteInstance(int mediatorId, int physicalInstanceId);

    /**
     * Inform the world that a mediator physical instance has been created.
     * @param created The mediator physical instance that was just created.
     */
    void notifyCreateInstance(MediatorInstance created);

    /**
     * Inform the world that a mediator physical instance has been modified.
     * @param updated The mediator physical instance that was just changed.
     */
    void notifyUpdateInstance(MediatorInstance updated);

}
