package com.ossnms.dcn_manager.core.entities.container;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import java.util.Objects;
import java.util.Optional;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.isNullOrEmpty;

/**
 * Contains information about a DCN Container. DCN Containers represent a logical grouping
 * of NEs in the management system. They may also group other containers.
 */
public abstract class ContainerInfoBase extends BusinessObjectData {

    private final String name;
    private final Optional<Integer> parentId;
    private final Optional<String> description;
    private final Optional<String> userText;

    /**
     * Creates a new object.
     * @param containerId Numeric system identifier.
     * @param version Object version.
     * @param containerName Container name. Must not be empty.
     * @throws IllegalArgumentException If the name is null or empty or if the ID is invalid.
     */
    protected ContainerInfoBase(int containerId, int version, @Nonnull String containerName) {
        super(containerId, version);
        checkArgument(containerId >= 0, "A DCN Container ID must be positive!");
        checkArgument(!isNullOrEmpty(containerName), "A system name must not be empty!");
        name = containerName;
        parentId = Optional.empty();
        description = Optional.empty();
        userText = Optional.empty();
    }

    /**
     * Creates a new object.
     * @param containerId Numeric system identifier.
     * @param version Object version.
     * @param parentId Parent container identifier. Must be positive.
     * @param containerName Container name. Must not be empty.
     * @param description Human readable description.
     * @throws IllegalArgumentException If the name is null or empty or if the ID is invalid.
     */
    protected ContainerInfoBase(int containerId, int version, Optional<Integer> parentId,
                                @Nonnull String containerName, @Nonnull Optional<String> description, @Nonnull Optional<String> userText) {
        super(containerId, version);
        checkArgument(containerId >= 0, "A DCN Container ID must be positive!");
        checkArgument(!isNullOrEmpty(containerName), "A system name must not be empty!");
        name = containerName;
        this.parentId = parentId;
        this.description = description;
        this.userText = userText;
    }

    /**
     * @return The system name.
     */
    public String getName() {
        return name;
    }

    /**
     * @return The parent container identifier.
     */
    public Optional<Integer> getParentId() {
        return parentId;
    }

    /**
     * @return Container description, provided by the operator.
     */
    public Optional<String> getDescription() {
        return description;
    }

    /**
     * @return Container user text, provided by the operator.
     */
    public Optional<String> getUserText() {
        return userText;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), name, parentId, description);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ContainerInfoBase)) {
            return false;
        }
        final ContainerInfoBase rhs = (ContainerInfoBase) other;
        return new EqualsBuilder()
                .append(getId(), rhs.getId())
                .append(getVersion(), rhs.getVersion())
                .append(name, rhs.name)
                .append(parentId, rhs.parentId)
                .append(description, rhs.description)
                .append(userText, rhs.userText)
                .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("name", name)
                .append("parentId", parentId)
                .append("description", description)
                .append("userText", userText)
                .toString();
    }
}
