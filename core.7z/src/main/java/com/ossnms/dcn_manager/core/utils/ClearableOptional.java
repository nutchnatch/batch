package com.ossnms.dcn_manager.core.utils;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;
import java.util.Optional;

/**
 * <p>An encapsulation of Guavas' {@link Optional} that allows a third state: "cleared".</p>
 *
 * <p>A {@code ClearableOptional} may be in one of the following three states:</p><ul>
 * <li><b>Present</b>, which encapsulates a {@link Present} containing a reference to an object.</li>
 * <li><b>Absent</b>, which behaves like a {@link Absent} without a reference to an object.</li>
 * <li><b>Clear</b>, which behaves in the same way as Present but instead encapsulates a
 * {@link Absent} without a reference to an object.</li>
 * </ul>
 *
 * <p>The purpose behind the new Clear state is to allow a semantic whereby a ClearableOptional
 * will force usage of an {@link Absent} whilst ignoring any alternative values.</p>
 */
@Immutable
public abstract class ClearableOptional<T> {

    ClearableOptional() { }

    @Override
    public abstract int hashCode();

    @Override
    public abstract boolean equals(Object other);

    /**
     * @return Whether this object encapsulates a value.
     *  Will be true in the Present and Clear states.
     */
    public abstract boolean isPresent();

    /**
     * @return The value encapsulated by this object.
     * @throws IllegalStateException In the Absent state.
     */
    public abstract T get();

    /**
     * @return An {@link Optional} value encapsulated by this object.
     * @throws IllegalStateException In the Absent state.
     */
    public abstract Optional<T> asOptional();

    /**
     * @param other Alternative value.
     * @return An {@link Optional} with the value encapsulated by this object
     *  or the alternative value when in the Absent state.
     */
    public Optional<T> or(Optional<T> other) {
        return isPresent() ? asOptional() : other;
    }

    /**
     * @return The final value encapsulated by this object, or {@code null}
     *  when not in the Present state.
     */
    public abstract T orNull();

    /**
     * @param value Object to encapsulate.
     * @return An object in the Present state, encapsulating an {@link Optional}
     *  with a reference to an object.
     */
    public static <T> ClearableOptional<T> of(@Nonnull T value) {
        return new Present<>(value);
    }

    /**
     * @param value {@link Optional} to encapsulate.
     * @return An object in the Present state, encapsulating an {@link Optional}
     *  with a reference to an object.
     */
    public static <T> ClearableOptional<T> of(@Nonnull Optional<T> value) {
        return value.isPresent() ? new Present<>(value) : absent();
    }

    /**
     * @return An object in the Absent state without a reference to any object.
     */
    @SuppressWarnings("unchecked")
    public static <T> ClearableOptional<T> absent() {
        return (ClearableOptional<T>) Absent.INSTANCE;
    }

    /**
     * @return An object in the clear state, encapsulating an {@link Absent}.
     */
    @SuppressWarnings("unchecked")
    public static <T> ClearableOptional<T> clear() {
        return (ClearableOptional<T>) Clear.INSTANCE;
    }

    static final class Absent<T> extends ClearableOptional<T> {

        static final Absent<?> INSTANCE = new Absent<>();

        @Override
        public int hashCode() {
            return 161108196;
        }

        @Override
        public boolean equals(Object other) {
            return other == this;
        }

        @Override
        public boolean isPresent() {
            return false;
        }

        @Override
        public T get() {
            throw new IllegalStateException();
        }

        @Override
        public Optional<T> asOptional() {
            return Optional.empty();
        }

        @Override
        public T orNull() {
            return null;
        }

        @Override
        public String toString() {
            return "ClearableOptional.absent()";
        }
    }

    static final class Clear<T> extends ClearableOptional<T> {

        static final Clear<?> INSTANCE = new Clear<>();

        @Override
        public int hashCode() {
            return 143705528;
        }

        @Override
        public boolean equals(Object other) {
            return other == this;
        }

        @Override
        public boolean isPresent() {
            return true;
        }

        @Override
        public T get() {
            throw new IllegalStateException();
        }

        @Override
        public Optional<T> asOptional() {
            return Optional.empty();
        }

        @Override
        public T orNull() {
            return null;
        }

        @Override
        public String toString() {
            return "ClearableOptional.clear()";
        }
    }

    static final class Present<T> extends ClearableOptional<T> {

        private final Optional<T> value;

        Present(@Nonnull T value) {
            this.value = Optional.of(value);
        }

        Present(@Nonnull Optional<T> value) {
            this.value = value;
        }

        @Override
        public int hashCode() {
            return value.hashCode();
        }

        @Override
        public boolean equals(Object other) {
            if (other instanceof Present) {
                return value.equals(((Present<?>) other).value);
            }
            return false;
        }

        @Override
        public boolean isPresent() {
            return true;
        }

        @Override
        public T get() {
            return value.get();
        }

        @Override
        public Optional<T> asOptional() {
            return value;
        }

        @Override
        public T orNull() {
            return value.get();
        }

        @Override
        public String toString() {
            return "ClearableOptional.of(" + value.get() + ")";
        }
    }
}
