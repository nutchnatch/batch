package com.ossnms.dcn_manager.core.policies.common;

/**
 * Something, usually a task, that can be cancelled. Cancellation is performed by the cancel method.
 */
public interface Cancellable {

    /**
     * Attempt to cancel execution of this task. Must be idempotent, i.e., cancellation of an already
     * cancelled task should not be considered an error.
     */
    void cancel();

}
