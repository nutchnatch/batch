package com.ossnms.dcn_manager.core.entities.container;

/**
 * Root Container Global Identification.
 */
public enum RootContainerId {
    /**  The ID = 0 is the Global identification of the Root Container. */
    ID(0);

    private final int id;

    RootContainerId(int id) {
        this.id = id;
    }

    public int get() {
        return id;
    }
}
