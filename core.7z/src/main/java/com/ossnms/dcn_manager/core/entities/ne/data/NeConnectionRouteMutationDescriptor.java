package com.ossnms.dcn_manager.core.entities.ne.data;

import com.google.common.base.MoreObjects;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectMutationDescriptor;
import com.ossnms.dcn_manager.core.utils.ClearableOptional;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.google.common.base.Strings.isNullOrEmpty;

/**
 * Contains all data that should be changed on {@link NeConnectionRouteData},
 * when applied as a single atomic mutation by the repository.
 */
abstract class NeConnectionRouteMutationDescriptor<E extends NeConnectionRouteData, M extends NeConnectionRouteMutationDescriptor<E, M>>
        extends DynamicBusinessObjectMutationDescriptor<E, M>
        implements NeConnectionRouteSetters<M> {

    private Optional<Integer> priority = Optional.empty();
    private Optional<Integer> cost = Optional.empty();
    private Optional<Boolean> used = Optional.empty();
    private Optional<String> key = Optional.empty();
    private ClearableOptional<String> domain = ClearableOptional.absent();
    private Optional<String> gneName = Optional.empty();

    protected NeConnectionRouteMutationDescriptor(E target) {
        super(target);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .omitNullValues()
                .add("priority", priority.orElse(null))
                .add("cost", cost.orElse(null))
                .add("used", used.orElse(null))
                .add("key", key.orElse(null))
                .add("domain", domain.orNull())
                .add("gneName", gneName.orElse(null))
                .addValue(super.toString())
                .toString();
    }

    /**
     * @return The route priority. Used for sorting routes.
     */
    public Optional<Integer> getPriority() {
        return priority;
    }

    /**
     * @param priority New priority value.
     */
    @Override
    public M setPriority(int priority) {
        this.priority = Optional.of(priority);
        return self();
    }

    /**
     * @return Route cost. Used for sorting routes.
     */
    public Optional<Integer> getCost() {
        return cost;
    }

    /**
     * @param cost New route cost.
     */
    @Override
    public M setCost(int cost) {
        this.cost = Optional.of(cost);
        return self();
    }

    /**
     * @return Whether the route is in use, i.e., it is the active route.
     */
    public Optional<Boolean> getUsed() {
        return used;
    }

    /**
     * @param used The new route usage status.
     */
    @Override
    public M setUsed(boolean used) {
        this.used = Optional.of(used);
        return self();
    }

    /**
     * @return Unique route key.
     */
    public Optional<String> getKey() {
        return key;
    }

    /**
     * @param key The unique route key to set.
     */
    @Override
    public M setKey(String key) {
        this.key = Optional.ofNullable(key);
        return self();
    }

    /**
     * @return Domain name associated with the route, if any.
     */
    public ClearableOptional<String> getDomain() {
        return domain;
    }

    /**
     * @param domain The new route domain name.
     */
    public M setDomain(@Nonnull String domain) {
        this.domain = isNullOrEmpty(domain) ? ClearableOptional.clear() : ClearableOptional.of(domain);
        return self();
    }

    /**
     * @param domain The new route domain name.
     */
    @Override
    public M setDomain(@Nonnull Optional<String> domain) {
        this.domain = domain.isPresent() && !domain.get().isEmpty()
            ? ClearableOptional.of(domain)
            : ClearableOptional.clear();
        return self();
    }

    /**
     * @param gneName The new provider GNE name.
     */
    public M setGneName(String gneName) {
        this.gneName = Optional.ofNullable(gneName);
        return self();
    }

    /**
     * @return Provider GNE name, if any.
     */
    public Optional<String> getGneName() {
        return gneName;
    }
}
