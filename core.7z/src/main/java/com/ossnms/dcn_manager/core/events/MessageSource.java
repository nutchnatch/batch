package com.ossnms.dcn_manager.core.events;

import javax.annotation.Nonnull;

/**
 * <p>Represents an object that emits events represented by objects of type {@code T}.
 * Emission is triggered from the outside by calling {@link #push(T)}.</p>
 */
public interface MessageSource<T> {

    /**
     * Triggers emission of an object.
     * @param message The instance that is to be emitted to subscribers.
     */
    void push(@Nonnull T message);

}