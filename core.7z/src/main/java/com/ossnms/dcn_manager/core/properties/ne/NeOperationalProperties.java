package com.ossnms.dcn_manager.core.properties.ne;

import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationPropertySetters;
import com.ossnms.dcn_manager.core.properties.EntityPropertiesSink;
import com.ossnms.dcn_manager.core.properties.NamedPropertyHandler;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Manages property retrieval from a merged set of NE Type and NE Instance
 * (NE entity) properties.
 */
public class NeOperationalProperties
        extends EntityPropertiesSink<NeOperationalProperty, NeType, NeOperationData, NeOperationPropertySetters<?>> {

    public NeOperationalProperties() {
    }

    @Override @Nonnull protected NeOperationalPropertyHandler[] getHandlers() {
        return PROPERTY_HANDLERS;
    }

    public static boolean isOperationalProperty(@Nonnull NeType type, @Nonnull String name) {
        return Stream.of(PROPERTY_HANDLERS).anyMatch(h -> h.handles(type, name));
    }

    private abstract static class NeOperationalPropertyHandler
            extends NamedPropertyHandler<NeType, NeOperationData, NeOperationPropertySetters<?>> {

        protected NeOperationalPropertyHandler() {
            super(null);
        }

        protected NeOperationalPropertyHandler(String name) {
            super(name);
        }
    }

    private static final NeOperationalPropertyHandler[] PROPERTY_HANDLERS = {

            new NeOperationalPropertyHandler(NeOperationalProperty.NEIGHBOURHOOD_ID.getName()) {
                @Override public void set(@Nonnull NeType type, @Nonnull NeOperationPropertySetters<?> descriptor,
                        @Nonnull String name, String value) throws InvalidMutationException {
                    descriptor.setNeighbourhoodId(value);
                }

                @Override public Optional<String> get(@Nonnull NeType type, @Nonnull NeOperationData entity,
                                                            @Nonnull String name) {
                    return entity.getNeighbourhoodId();
                }
            },
            
            new NeOperationalPropertyHandler(NeOperationalProperty.NETWORK_NAME.getName()) {
                @Override public void set(@Nonnull NeType type, @Nonnull NeOperationPropertySetters<?> descriptor,
                        @Nonnull String name, String value) throws InvalidMutationException {
                    descriptor.setRealNeName(value);
                }

                @Override public Optional<String> get(@Nonnull NeType type, @Nonnull NeOperationData entity,
                                                            @Nonnull String name) {
                    return entity.getRealNeName();
                }
            },
            
            new NeOperationalPropertyHandler(NeOperationalProperty.ADDITIONAL_TYPE_INFO.getName()) {
                @Override public void set(@Nonnull NeType type, @Nonnull NeOperationPropertySetters<?> descriptor,
                        @Nonnull String name, String value) throws InvalidMutationException {
                    descriptor.setAdditionalTypeInfo(value);
                }

                @Override public Optional<String> get(@Nonnull NeType type, @Nonnull NeOperationData entity,
                                                            @Nonnull String name) {
                    return entity.getAdditionalTypeInfo();
                }
            }};

}
