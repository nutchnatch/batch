package com.ossnms.dcn_manager.core.events.domain;

import javax.annotation.concurrent.Immutable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.google.common.base.MoreObjects;

/**
 * Informs that the policy regarding automatic NE activation during discovery
 * has changed for a given domain.
 */
@Immutable
public class DomainNeActivationPolicyChanged extends DomainEvent {

    /** The new policy. */
    private final boolean automaticActivationPermitted;

    /**
     * Creates a new object.
     * @param domainId The affected Domain ID.
     * @param automaticActivationPermitted The new policy value.
     */
    public DomainNeActivationPolicyChanged(int domainId, boolean automaticActivationPermitted) {
        super(domainId);
        this.automaticActivationPermitted = automaticActivationPermitted;
    }

    /**
     * @return The modified policy value.
     */
    public boolean isAutomaticActivationPermitted() {
        return automaticActivationPermitted;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("domainId", getDomainId())
                .add("automaticActivationPermitted", automaticActivationPermitted)
                .add("description", getDetailedDescription())
                .toString();
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        final DomainNeActivationPolicyChanged rhs = (DomainNeActivationPolicyChanged) obj;
        return new EqualsBuilder()
            .append(getDomainId(), rhs.getDomainId())
            .append(getDetailedDescription(), rhs.getDetailedDescription())
            .append(automaticActivationPermitted, rhs.automaticActivationPermitted)
            .isEquals();
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(getDomainId())
            .append(getDetailedDescription())
            .append(automaticActivationPermitted)
            .hashCode();
    }
}
