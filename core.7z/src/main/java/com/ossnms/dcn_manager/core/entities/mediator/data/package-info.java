/**
 * <p>Contains exclusively classes that describe data managed by the domain entity.</p>
 *
 * <p>These classes are divided into two groups: Entity and Instance data.</p>
 *
 * <figure>
 * <img src="doc-files/mediator-entities.png"/>
 * <figcaption>Mediator data class diagram</figcaption>
 * </figure>
 *
 * <p>This division is necessary due to the existence of one or more identical mediator
 * server instances. Of these, only one is said to be "active" at any moment. Others are
 * in "standby" should the active instance fail.</p>
 *
 * <p>We are however required to hide this duality from the system at large. Hence we
 * keep a set of attributes that are applicable to all mediator server instances as the
 * Entity. Attributes that apply only to one mediator server instance are kept in
 * separate Instance objects.</p>
 *
 * <p>The Entity actual connection state is calculated from the Instance states;
 * usually it mirrors the "active" Instance state. Instance configuration attributes
 * are presented as such in the DCN Manager user interface.</p>
 */
/*
 * @startuml doc-files/mediator-entities-class.png
 * class MediatorEntity <<immutable>>
 * class MediatorInstance <<immutable>>
 * class MediatorConnectionData <<immutable>> {
 *  + mediatorId
 *  + actualActivationState
 *  + additionalInfo
 * }
 * class MediatorInfoData <<immutable>> {
 *  + mediatorId
 *  + activationRequired
 *  + concurrentActivationsLimit
 *  + concurrentActivationsLimited
 *  + description
 *  + name
 *  + reconnectAttemptInterval
 *  + typeName
 * }
 * class MediatorPhysicalData <<immutable>> {
 *  + mediatorId
 *  + mediatorInstanceId
 *  + host
 *  + priority
 * }
 * class MediatorPhysicalConnectionData <<immutable>> {
 *  + mediatorId
 *  + mediatorInstanceId
 *  + active
 *  + actualActivationState
 *  + additionalInfo
 * }
 * MediatorConnectionData "1" --* MediatorEntity
 * MediatorInfoData "1" --* MediatorEntity
 * MediatorEntity *.. "1..n" MediatorInstance : Indirect relation\nthrough separate\nrepository.
 * MediatorInstance *-- "1" MediatorPhysicalData
 * MediatorInstance *-- "1" MediatorPhysicalConnectionData
 * @enduml
 */
package com.ossnms.dcn_manager.core.entities.mediator.data;