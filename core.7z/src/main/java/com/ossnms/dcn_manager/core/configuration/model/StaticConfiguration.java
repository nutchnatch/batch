package com.ossnms.dcn_manager.core.configuration.model;

public interface StaticConfiguration {

    /** @return All NE Type metadata found. */
    Types<NeType> getNeTypes();

    /** @return All Channel Type metadata found. */
    Types<ChannelType> getChannelTypes();

    /** @return All Mediator Type metadata found. */
    Types<MediatorType> getMediatorTypes();

    /** @return All default property values found. */
    DefaultPropertyValues getDefaultPropertyValues();

    /**
     * @return Password properties
     */
    PasswordPropertyMetadata getPasswordPropertyMetadata();
}