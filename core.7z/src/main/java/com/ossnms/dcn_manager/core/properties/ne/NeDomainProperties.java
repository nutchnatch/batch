package com.ossnms.dcn_manager.core.properties.ne;

import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;

import static com.google.common.base.Strings.isNullOrEmpty;
import static java.util.stream.Collectors.toList;

/**
 * Knows how to extract Domain names from name/value pairs (a.k.a. properties).
 * Usually these properties are present in Network Elements.
 *
 * @see com.ossnms.dcn_manager.core.entities.domain.DomainInfoData
 */
public class NeDomainProperties {

    /**
     * <p>Produces a collection of domain names from a map of name/value pairs (properties).</p>
     * <p/>
     * <p>Because this method will produce an iterable, properties must be properly
     * indexed. This means that their names must contain a suffix with an underscore
     * followed by an index number (i.e., <code>DHCP_NAME_000</code>).</p>
     *
     * @param properties A map of name/value pairs.
     * @return A iterable of all domains found in the properties given.
     */
    public Iterable<NeDomain> parseProperties(@Nonnull Map<String, String> properties) {
        final Map<Integer, Collection<PropertyInfo>> domainProperties = FluentIterable.from(properties.entrySet())
                .filter(new BelongsToDomainProperties())
                .transform(new ParsePropertyInfo())
                .index(new PropertyInfoIndex())
                .asMap();

        return domainProperties.values().stream()
                .map(NeDomain::fromProperties)
                .filter(NeDomain::isValid)
                .collect(toList());
    }

    /**
     * Formalizes the definition of Domain as received within an unstructured bundle
     * of name/value pairs.
     */
    public static final class NeDomain {
        private String name;
        private Status status;

        public NeDomain() {
            status = Status.UNKNOWN;
        }

        public NeDomain(String name, Status status) {
            this.name = name;
            this.status = status;
        }

        public String getName() {
            return name;
        }

        public Status getStatus() {
            return status;
        }

        @Override
        public int hashCode() {
            return new HashCodeBuilder()
                    .append(name)
                    .append(status)
                    .toHashCode();
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || o.getClass() != getClass()) {
                return false;
            }
            if (o == this) {
                return true;
            }
            final NeDomain rhs = (NeDomain) o;
            return new EqualsBuilder()
                    .append(name, rhs.name)
                    .append(status, rhs.status)
                    .isEquals();
        }

        @Override public String toString() {
            return "NeDomain{" +
                    "name='" + name + '\'' +
                    ", status=" + status +
                    '}';
        }

        private void set(String name, String value) {
            switch (name) {
                case "DHCP_NAME":
                    this.name = value;
                    break;
                case "DHCP_STATUS":
                    status = Status.of(value);
                    break;
                default:
                    break;
            }
        }

        private boolean isValid() {
            return !isNullOrEmpty(name) && status != null;
        }

        static NeDomain fromProperties(Collection<PropertyInfo> properties) {
            NeDomain domain = new NeDomain();
            properties.forEach(property ->
                    domain.set(property.getName(), property.getValue()));
            return domain;
        }
    }

    public enum Status {
        /** Unknown or invalid status. */                  UNKNOWN, 
        /** The Domain is no longer known by mediation. */ UNCONFIGURED,
        /** The Domain was already known by both. */       CONFIGURED,
        /** The Domain was previously unknown by TNMS. */  NEW;

        static Status of(String value) {
            try {
                return valueOf(value);
            } catch (IllegalArgumentException e) {
                return UNKNOWN;
            }
        }
    }

    /**
     * Predicate that succeeds whenever a property name fulfills the
     * requirements to be considered as a domain property.
     */
    private static final class BelongsToDomainProperties implements
            Predicate<Entry<String, String>> {

        @Override
        public boolean apply(@Nonnull Entry<String, String> entry) {
            final Matcher matcher = PropertyInfo.INDEXED_PROPERTY_NAME_PATTERN.matcher(entry.getKey());
            return matcher.matches() &&
                    matcher.group(PropertyInfo.NAME_GROUP).startsWith("DHCP_") &&
                    !isNullOrEmpty(entry.getValue());
        }
    }
}
