package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.ne.IdentifiedNeEvent;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManagerStage;
import com.ossnms.dcn_manager.core.policies.common.BoundedExecutor.Signaller;
import com.ossnms.dcn_manager.core.policies.common.ExecutionQueue;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadFactory;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * This execution manager stage limits execution according to system-defined parameters.
 * Because these parameters are set system-wide, they are not linked to any partitioning
 * scheme. Hence this execution manager has only one execution queue.
 */
public class NetworkElementInteractionManagerSystemStage
        implements NetworkElementInteractionManagerStage {

    /** Partition identifier for operations against the "active" mediators. */
    public static final int ACTIVE_ID = 0;
    /** Partition identifier for operations against the "standby", i.e., "not active" mediators. */
    public static final int STANDBY_ID = 1;

    private final ExecutionQueue<PolicyJob<? extends IdentifiedNeEvent>> activeQueue;
    private final ExecutionQueue<PolicyJob<? extends IdentifiedNeEvent>> standbyQueue;

    /**
     * Constructs a new instance with a default limit in the number of ongoing jobs
     * and an execution policy.
     *
     * @param maxSimultaneousInteractions Initial limit for the number of ongoing jobs.
     * @param systemExecutionPolicy Executor implementing the actual job execution policy,
     *                              allowing load regulation at the system level.
     * @param threadFactory Thread factory for supporting a fallback execution policy
     *                      for high priority jobs.
     * @param upstreamWorkSupplier Supplier of work items that will provide work when this stage has
     *                             capacity but is empty.
     */
    public NetworkElementInteractionManagerSystemStage(
            int maxSimultaneousInteractions,
            @Nonnull Executor systemExecutionPolicy,
            @Nonnull ThreadFactory threadFactory,
            @Nonnull Function<Predicate<PolicyJob<? extends IdentifiedNeEvent>>, Optional<PolicyJob<? extends IdentifiedNeEvent>>> upstreamWorkSupplier) {
        this.activeQueue = new ExecutionQueue<>(maxSimultaneousInteractions, "NE.SYSTEM.ACTIVE",
                new PriorityExecutionPolicy(systemExecutionPolicy, threadFactory, this::onActiveCapacityAvailable),
                selector -> upstreamWorkSupplier.apply(item -> item.getOriginatingEvent().isActiveInstance()));
        this.standbyQueue = new ExecutionQueue<>(maxSimultaneousInteractions, "NE.SYSTEM.STANDBY",
                new PriorityExecutionPolicy(systemExecutionPolicy, threadFactory, this::onStandbyCapacityAvailable),
                selector -> upstreamWorkSupplier.apply(item -> ! item.getOriginatingEvent().isActiveInstance()));
    }

    private void onActiveCapacityAvailable() {
        activeQueue.signalCapacityIsAvailable();
    }

    private void onStandbyCapacityAvailable() {
        standbyQueue.signalCapacityIsAvailable();
    }

    private ExecutionQueue<PolicyJob<? extends IdentifiedNeEvent>> selectQueue(@Nonnull PolicyJob<? extends IdentifiedNeEvent> job) {
        return job.getOriginatingEvent().isActiveInstance() ? activeQueue : standbyQueue;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void execute(@Nonnull Runnable command) {
        final PolicyJob<? extends IdentifiedNeEvent> job = (PolicyJob<? extends IdentifiedNeEvent>) command;
        final ExecutionQueue<PolicyJob<? extends IdentifiedNeEvent>> queue = selectQueue(job);
        queue.scheduleWorkItem(
                new JobWrapper<>(job, queue::getRetainedWorkForExecution),
                i -> false);
    }

    @Override
    public void unscheduleNeInteraction(Predicate<PolicyJob<? extends IdentifiedNeEvent>> cancellationSelector) {
        activeQueue.signalWorkItemCancellation(cancellationSelector);
        standbyQueue.signalWorkItemCancellation(cancellationSelector);
    }

    @Override
    public void onNeInteractionEnded(@Nonnull Predicate<PolicyJob<? extends IdentifiedNeEvent>> interactionSelector) {
        activeQueue.signalWorkItemCompletion(interactionSelector);
        standbyQueue.signalWorkItemCompletion(interactionSelector);
    }

    @Override
    public boolean onEvent(@Nonnull Signaller<PolicyJob<? extends IdentifiedNeEvent>> signaller) {
        return activeQueue.signalWorkItem(signaller) || standbyQueue.signalWorkItem(signaller);
    }

    @Override
    public int getPendingJobCount() {
        return activeQueue.getPendingWorkItemCount() + standbyQueue.getPendingWorkItemCount();
    }

    @Override
    public int getOngoingJobCount() {
        return activeQueue.getOngoingWorkItemCount() + standbyQueue.getOngoingWorkItemCount();
    }

    /**
     * Sets the maximum number of allowed simultaneous jobs (i.e. NE interactions). This configuration
     * change may not have immediate effect, meaning, ongoing jobs will not be cancelled.
     * @param newMaxInteractions The new maximum number of allowed simultaneous jobs.
     */
    public void setMaxOngoingJobCount(int newMaxInteractions) {
        activeQueue.setMaxOngoingWorkItemCount(newMaxInteractions);
        standbyQueue.setMaxOngoingWorkItemCount(newMaxInteractions);
    }

    /**
     * Not supported: no-op. The limits are always equal for both queues.
     */
    @Override
    public void setMaxOngoingJobCount(int partitionId, int newMaxInteractions) {

    }

    @Override
    public Stream<PolicyJob<?>> getOngoingJobs() {
        return Stream.concat(activeQueue.getOnGoingWorkItems(),standbyQueue.getOnGoingWorkItems());
    }

    @Override
    public Stream<PolicyJob<?>> getOngoingJobs(int... partitionIds) {
        return getPolicyJobStream(partitionIds, ExecutionQueue::getOnGoingWorkItems);
    }

    @Override
    @SuppressWarnings("unchecked")
    public Stream<PolicyJob<?>> getPendingJobs() {
        return Stream.concat(activeQueue.getPendingWorkItems(), standbyQueue.getPendingWorkItems());
    }

    @Override
    public Stream<PolicyJob<?>> getPendingJobs(int... partitionIds) {
        return getPolicyJobStream(partitionIds, ExecutionQueue::getPendingWorkItems);
    }


    /**
     * @param partitionId ACTIVE_ID = ACTIVE count; any other value or STANDBY_ID = STANDBY count.
     * @return The number of jobs pending on the active or standby partition.
     */
    @Override
    public int getPendingJobCount(int partitionId) {
        // called from user parent interaction manager implementation to sum all statistics.
        return ACTIVE_ID == partitionId ? activeQueue.getPendingWorkItemCount() : standbyQueue.getPendingWorkItemCount();
    }

    /**
     * @param partitionId ACTIVE_ID = ACTIVE count; any other value or STANDBY_ID = STANDBY count.
     * @return The number of jobs currently ongoing on the active or standby partition.
     */
    @Override
    public int getOngoingJobCount(int partitionId) {
        // called from user parent interaction manager implementation to sum all statistics.
        return ACTIVE_ID == partitionId ? activeQueue.getOngoingWorkItemCount() : standbyQueue.getOngoingWorkItemCount();
    }

    /**
     * @param partitionId ACTIVE_ID = ACTIVE count; any other value or STANDBY_ID = STANDBY count.
     * @return The maximum number of jobs that can be ongoing concurrently on the active or standby partition.
     */
    @Override
    public int getMaxOngoingJobCount(int partitionId) {
        // called from user parent interaction manager implementation to sum all statistics.
        return ACTIVE_ID == partitionId ? activeQueue.getMaxOngoingWorkItemCount() : standbyQueue.getMaxOngoingWorkItemCount();
    }

    private Optional<ExecutionQueue<PolicyJob<? extends IdentifiedNeEvent>>> selectExecutionQueueTo(int partitionId){
        Optional<ExecutionQueue<PolicyJob<? extends IdentifiedNeEvent>>> result;
        switch (partitionId){
            case ACTIVE_ID:{
                result = Optional.of(activeQueue);
                break;
            }
            case STANDBY_ID:{
                result = Optional.of(standbyQueue);
                break;
            }
            default:
                result = Optional.empty();
        }
        return result;
    }

    private Stream<PolicyJob<?>> getPolicyJobStream(int[] partitionIds, Function<ExecutionQueue<PolicyJob<? extends  IdentifiedNeEvent>>,
            Stream<PolicyJob<? extends IdentifiedNeEvent>>> supplier) {

        return Arrays.stream(partitionIds)
                .mapToObj(this::selectExecutionQueueTo)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .flatMap(supplier::apply);
    }

}
