package com.ossnms.dcn_manager.core.configuration.loaders;

import com.ossnms.dcn_manager.core.configuration.model.DefaultPropertyValues;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.jaxb.netype.Config;

import java.net.URL;

import static com.ossnms.dcn_manager.core.configuration.loaders.XmlConfiguration.unmarshal;

public class TypeLoaderNe extends TypesLoader<NeType> {
    private final DefaultPropertyValues defaultPropertyValues;

    public TypeLoaderNe(DefaultPropertyValues defaultPropertyValues) {
        this.defaultPropertyValues = defaultPropertyValues;
    }

    @Override NeType buildType(URL sourceUrl) {
        Config configuration = unmarshal(Config.class, sourceUrl, new Config());
        return new NeType(configuration, defaultPropertyValues);
    }
}
