package com.ossnms.dcn_manager.core.events;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Base class for all events related to domain entities.
 *
 * Design constraints pertaining to all derived event types:
 * <ul>
 *      <li> Event instances are immutable;</li>
 *      <li> Event instances contain the associated domain entity identifier,
 *      specified upon initiation.</li>
 * </ul>
 *
 * For a detailed explanation of these design constraints, see the package documentation.
 *
 * @see com.ossnms.dcn_manager.core.events
 */
@Immutable
public abstract class EntityEvent implements Event {

    /** The associated domain entity identifier. */
    private final int entityId;
    /** An optional human-readable string bearing the event's description. */
    private final String detailedDescription;

    /**
     * Creates a new object.
     * @param entityId The affected entity ID.
     */
    public EntityEvent(int entityId) {
        this(entityId, "");
    }

    /**
     * Creates a new object.
     * @param entityId The affected entity ID.
     * @param detailedDescription A human-readable string bearing the event's description.
     */
    public EntityEvent(int entityId, @Nonnull String detailedDescription) {
        this.entityId = entityId;
        this.detailedDescription = detailedDescription;
    }

    /**
     * @return The affected entity ID.
     */
    protected int getEntityId() {
        return entityId;
    }

    /**
     * @return The detailed event description.
     */
    public String getDetailedDescription() {
        return detailedDescription;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("entityId", entityId)
                .append("description", detailedDescription)
                .toString();
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        final EntityEvent rhs = (EntityEvent) obj;
        return new EqualsBuilder()
            .append(entityId, rhs.getEntityId())
            .append(detailedDescription, rhs.getDetailedDescription())
            .isEquals();
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(entityId)
            .append(detailedDescription)
            .hashCode();
    }
}
