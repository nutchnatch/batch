package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.ne.IdentifiedNeEvent;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManagerStage;
import com.ossnms.dcn_manager.core.policies.common.BoundedExecutor.Signaller;
import com.ossnms.dcn_manager.core.policies.common.Job;
import com.ossnms.dcn_manager.core.policies.common.PartitionedInteractionManager;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.concurrent.Executor;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * This execution manager stage limits execution according to parameters defined for each mediator.
 * There is partitioning involved, according to which each mediation ID represents one partition.
 */
public class NetworkElementInteractionManagerMediationStage
        extends PartitionedInteractionManager<PolicyJob<? extends IdentifiedNeEvent>>
        implements NetworkElementInteractionManagerStage {

	/**
	 * Constructs a new instance with a default limit in the number of ongoing jobs
	 * and an execution policy.
	 *
	 * @param maxSimultaneousInteractions Initial limit for the number of ongoing jobs.
	 * @param executionPolicy Executor implementing the actual job execution policy. In this case
	 *                        it will be the "system" load regulator.
	 * @param upstreamWorkSupplier Supplier of work items that will provide work when this stage has
	 *                             capacity but is unable to provide new work.
	 */
	public NetworkElementInteractionManagerMediationStage(
			int maxSimultaneousInteractions,
			@Nonnull Executor executionPolicy,
			@Nonnull Function<Predicate<PolicyJob<? extends IdentifiedNeEvent>>, Optional<PolicyJob<? extends IdentifiedNeEvent>>> upstreamWorkSupplier) {
		super(maxSimultaneousInteractions, "NE.MEDIATION", executionPolicy,
				(mediatorId, predicate) -> upstreamWorkSupplier.apply(item -> item.getOriginatingEvent().getPhysicalMediatorId() == mediatorId && predicate.test(item)));
	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute(@Nonnull Runnable command) {
		final Job<? extends IdentifiedNeEvent> job = (Job<? extends IdentifiedNeEvent>) command;
		final int mediatorId = job.getOriginatingEvent().getPhysicalMediatorId();
		super.schedulePartitionInteraction(mediatorId, job, j -> false);
	}

	/** {@inheritDoc}
	 * @param cancelationSelector*/
	@Override
	public void unscheduleNeInteraction(Predicate<PolicyJob<? extends IdentifiedNeEvent>> cancelationSelector) {
		super.unscheduleInteraction(cancelationSelector);
	}

	/** {@inheritDoc}
	 * @param interactionSelector*/
	@Override
	public void onNeInteractionEnded(@Nonnull Predicate<PolicyJob<? extends IdentifiedNeEvent>> interactionSelector) {
		super.onInteractionEnded(interactionSelector);
	}

	@Override
	public boolean onEvent(@Nonnull Signaller<PolicyJob<? extends IdentifiedNeEvent>> signaller) {
	    return super.onEvent(signaller);
	}

}
