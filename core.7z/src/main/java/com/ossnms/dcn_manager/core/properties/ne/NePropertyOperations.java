package com.ossnms.dcn_manager.core.properties.ne;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.properties.EntityProperty;

class NePropertyOperations
    extends EntityProperty {

    protected NePropertyOperations(@Nonnull String name) {
        super(name);
    }

    protected NePropertyOperations(@Nonnull String name, @Nonnull Scope scope) {
        super(name, scope);
    }

}