package com.ossnms.dcn_manager.core.storage.uow;

import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Consumer;

import static java.util.Objects.requireNonNull;

/**
 * Base implementation of a Unit of Work, which can be reused for technologically specific implementations.
 * @param <A> Result accumulator type.
 */
public abstract class UnitOfWorkImplBase<A> implements UnitOfWork<A> {

    private A accumulator;
    private final List<UowStep<?>> uowSteps;

    protected UnitOfWorkImplBase(A accumulator) {
        this.accumulator = accumulator;
        this.uowSteps = new LinkedList<>();
    }

    protected class UowStep<R> {

        private R result;

        private final UowFunction<R> unit;

        protected UowStep(@Nonnull UowFunction<R> unit) {
            this.unit = unit;
        }

        public void execute(@Nonnull UowContext ctx) throws DcnManagerException {
            result = unit.apply(ctx);
        }

        protected R getResult() {
            return result;
        }

        protected void consumeResult() {

        }
    }

    private final class UowConsumingStep<R> extends UowStep<R> {

        private final Consumer<R> successConsumer;

        private UowConsumingStep(@Nonnull UowFunction<R> unit, @Nonnull Consumer<R> successConsumer) {
            super(unit);
            this.successConsumer = successConsumer;
        }

        @Override
        protected void consumeResult() {
            successConsumer.accept(getResult());
        }
    }

    private final class UowAccumulatingStep<R> extends UowStep<R> {

        private final BiFunction<R, A, A> successConsumer;

        private UowAccumulatingStep(@Nonnull UowFunction<R> unit, @Nonnull BiFunction<R, A, A> successConsumer) {
            super(unit);
            this.successConsumer = successConsumer;
        }

        @Override
        protected void consumeResult() {
            accumulator = successConsumer.apply(getResult(), accumulator);
        }
    }

    @Override
    public <R> UnitOfWork<A> addUnit(@Nonnull UowFunction<R> unit) {
        requireNonNull(unit);
        uowSteps.add(new UowStep<>(unit));
        return this;
    }

    @Override
    public <R> UnitOfWork<A> addUnit(@Nonnull UowFunction<R> unit, @Nonnull Consumer<R> successConsumer) {
        requireNonNull(unit);
        requireNonNull(successConsumer);
        uowSteps.add(new UowConsumingStep<>(unit, successConsumer));
        return this;
    }

    @Override
    public <R> UnitOfWork<A> addUnit(@Nonnull UowFunction<R> unit, @Nonnull BiFunction<R, A, A> successConsumer) {
        requireNonNull(unit);
        requireNonNull(successConsumer);
        uowSteps.add(new UowAccumulatingStep<>(unit, successConsumer));
        return this;
    }

    @Override
    public <M extends MutationDescriptor<?, ?>, R> UnitOfWork<A> addUnit(
            @Nonnull UowBiFunction<M, R> unit, @Nonnull M target, @Nonnull Consumer<R> successConsumer) {
        final Consumer<R> mutationApplied = (r -> target.applied());
        return addUnit(ctx -> unit.apply(ctx, target), mutationApplied.andThen(successConsumer));
    }

    @Override
    public <M extends MutationDescriptor<?, ?>, R> UnitOfWork<A> addUnit(
            @Nonnull UowBiFunction<M, R> unit, @Nonnull M target, @Nonnull BiFunction<R, A, A> successConsumer) {
        return addUnit(ctx -> unit.apply(ctx, target),
                (r, a) -> { target.applied(); return successConsumer.apply(r, a); });
    }

    @Override
    public A apply() throws DcnManagerException {
        executeSteps(uowSteps);
        uowSteps.forEach(UowStep::consumeResult);
        return accumulator;
    }

    protected abstract void executeSteps(Collection<UowStep<?>> uowSteps) throws DcnManagerException;
}
