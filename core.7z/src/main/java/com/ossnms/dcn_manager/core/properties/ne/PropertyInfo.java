package com.ossnms.dcn_manager.core.properties.ne;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.common.base.MoreObjects;

/**
 * Contains information about the property name, value and index.
 * Used in the early stages of name/value pair processing.
 */
final class PropertyInfo {

    static final Pattern INDEXED_PROPERTY_NAME_PATTERN = Pattern.compile("(.*)_([0-9]+)");

    static final int NAME_GROUP = 1;
    static final int INDEX_GROUP = 2;

    private final String name;
    private final Integer index;
    private final String value;

    PropertyInfo(String name, String value) {
        final Matcher nameMatcher = INDEXED_PROPERTY_NAME_PATTERN.matcher(name);
        nameMatcher.matches();
        this.name = nameMatcher.group(NAME_GROUP);
        this.index = Integer.valueOf(nameMatcher.group(INDEX_GROUP));
        this.value = value;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("index", getIndex())
                .add("name", getName())
                .add("value", getValue())
                .toString();
    }
    public String getName() {
        return name;
    }
    public Integer getIndex() {
        return index;
    }
    public String getValue() {
        return value;
    }
}