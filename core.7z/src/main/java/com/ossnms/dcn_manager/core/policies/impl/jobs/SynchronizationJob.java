package com.ossnms.dcn_manager.core.policies.impl.jobs;

import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;

import javax.annotation.Nonnull;

/**
 * Class whose instances represent jobs that trigger the initialization of a given NE.
 * Should only be used within the context of a fully active NE.
 */
public class SynchronizationJob extends NeJob<NeSynchronizationEvent> {

    private final NeConnectionManager connectionManager;

    public SynchronizationJob(
            @Nonnull NeSynchronizationEvent requestEvent, @Nonnull NeConnectionManager connectionManager) {
        super(requestEvent, Priority.MEDIUM);
        this.connectionManager = connectionManager;
    }

    /** {@inheritDoc} */
    @Override
    protected void runJob() {
        connectionManager.alwaysInitialize(getOriginatingEvent());
    }

}