package com.ossnms.dcn_manager.core.entities.ne.data.types;

public enum WriteAccessMode {
    NO,
    EXTERNAL,
    NE_PROXY,
    CLIENT_EM,
    NE_PROXY_AND_CLIENT_EM;

}
