package com.ossnms.dcn_manager.core.entities;

import com.ossnms.dcn_manager.exceptions.InvalidMutationException;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Base class providing utility methods for property handlers implementations.
 */
public abstract class PropertyHandlerBase {

    /**
     * Parses a string into an integer value.
     * Handles parsing errors, wrapping them in an {@link InvalidMutationException}
     * with a descriptive message.
     *
     * @param value The value to be parsed, in base 10.
     * @param name  Property name. Will be used in error messages.
     * @return An integer value.
     * @throws InvalidMutationException If an error occurs while parsing the string
     *                                  into an integer.
     */
    protected Integer integerValueOf(@Nullable String value, @Nonnull String name)
            throws InvalidMutationException {
        try {
            if (null == value) {
                throw new InvalidMutationException("Property " + name + " must not have a null value.");
            }
            return Integer.valueOf(value);
        } catch (final NumberFormatException e) {
            throw new InvalidMutationException("Invalid value for property " + name + ": " + value, e);
        }
    }

    /**
     * Parses a string into a boolean value.
     * Handles parsing errors, wrapping them in an {@link InvalidMutationException}
     * with a descriptive message.
     *
     * @param value The value to be parsed.
     * @param name  Property name. Will be used in error messages.
     * @return A boolean value.
     * @throws InvalidMutationException If an error occurs while parsing the string
     *                                  into a boolean.
     */
    protected Boolean booleanValueOf(@Nullable String value, @Nonnull String name)
            throws InvalidMutationException {
        try {
            if (null == value) {
                throw new InvalidMutationException("Property " + name + " must not have a null value.");
            }
            return Boolean.valueOf(value);
        } catch (final NumberFormatException e) {
            throw new InvalidMutationException("Invalid value for property " + name + ": " + value, e);
        }
    }

    /**
     * Helps to ensure that no null strings are used in calling setters.
     *
     * @param value A string.
     * @return The empty string if the input string is null, or the input string otherwise.
     */
    @Nonnull
    protected String emptyStringIfNull(@Nullable String value) {
        return value == null ? "" : value;
    }
}
