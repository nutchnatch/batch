package com.ossnms.dcn_manager.core.policies;

import com.ossnms.dcn_manager.core.policies.common.PolicyJob;

import java.util.stream.Stream;

/**
 * Interface with job related info for partitioned systems
 */
public interface PartitionedJobsInfo extends PartitionedJobMetrics, JobsInfo {

    /**
     * Gets the ongoing jobs, for the given partition.
     *
     * @param partitionIds The partition identifiers.
     * @return ongoing jobs
     */
    Stream<PolicyJob<?>> getOngoingJobs(int... partitionIds);


    /**
     * Gets the pending jobs, for the given partition.
     *
     * @param partitionIds The partition identifiers.
     * @return pending jobs
     */
    Stream<PolicyJob<?>> getPendingJobs(int... partitionIds);
}
