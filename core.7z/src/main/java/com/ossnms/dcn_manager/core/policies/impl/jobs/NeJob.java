package com.ossnms.dcn_manager.core.policies.impl.jobs;

import com.ossnms.dcn_manager.core.events.ne.IdentifiedNeEvent;
import com.ossnms.dcn_manager.core.policies.common.Job;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;
import com.ossnms.dcn_manager.core.policies.impl.JobWrapper;
import org.apache.commons.lang3.builder.CompareToBuilder;

import javax.annotation.Nonnull;


abstract class NeJob<T extends IdentifiedNeEvent> extends Job<T> {

    NeJob(@Nonnull T requestEvent, @Nonnull Priority priority) {
        super(requestEvent, priority);
    }

    @Override
    public int compareTo(@Nonnull PolicyJob<?> o) {
        if (o instanceof JobWrapper) {
            return - o.compareTo(this); //wrapper knows how extract its content
        }
        if (o instanceof NeJob) {
            final NeJob<? extends IdentifiedNeEvent> rhs = (NeJob<? extends IdentifiedNeEvent>) o;
            return new CompareToBuilder()
                    .appendSuper(super.compareTo(o))
                    .append(getOriginatingEvent().isActiveInstance(), rhs.getOriginatingEvent().isActiveInstance())
                    .toComparison();
        }
        return super.compareTo(o);
    }

}
