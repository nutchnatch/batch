package com.ossnms.dcn_manager.core.events.periodic;

/**
 * This event represents a request for triggering all activities related
 * to validation of object activations.
 *
 * An example of such validations is to issue automatic reconnections
 * should an object be found in "activation failed" state.
 */
public class PeriodicActivationVerificationEvent extends PeriodicEvent {

}
