package com.ossnms.dcn_manager.core.entities.ne.data;


public final class NeDirectRouteData extends NeConnectionRouteData {

    private NeDirectRouteData(int neId, int version, NeDirectRouteBuilder builder) {
        /* direct route unique key is optional on connect because empty objects don't have any routes. */
        super(neId, version, builder);
    }

    /**
     * Facilitates the creation of a {@link NeDirectRouteData} object by allowing
     * individual attributes to be set easily.
     */
    public static final class NeDirectRouteBuilder
            extends NeConnectionRouteBuilder<NeDirectRouteData, NeDirectRouteBuilder> {

        public NeDirectRouteData build(int neId, int version) {
            return new NeDirectRouteData(neId, version, this);
        }

        @Override
        protected NeDirectRouteBuilder self() {
            return this;
        }

    }

}
