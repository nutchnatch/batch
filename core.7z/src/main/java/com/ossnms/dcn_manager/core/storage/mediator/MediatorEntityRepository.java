package com.ossnms.dcn_manager.core.storage.mediator;

import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.BusinessEntityRepository;
import com.ossnms.dcn_manager.core.storage.BusinessObjectRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Contract to be supported by all Mediator entity repositories.
 */
public interface MediatorEntityRepository
    extends BusinessEntityRepository<MediatorEntity, MediatorCreateDescriptor, MediatorDeleteDescriptor> {

    /*
     * The goal with the following inner interface definitions is to increase readability
     * by getting generics out of the way.
     */

    /** Contract to be supported by all repositories of MediatorInfo domain object instances */
    interface MediatorInfoRepository
        extends BusinessObjectRepository<MediatorInfoData, MediatorInfoMutationDescriptor> {

        /**
         * Gets the mediator with the given name, if one exists
         * @param mediatorName The mediator name.
         * @throws RepositoryException When an error occurs while working with the
         * underlying data storage.
         * @return An {@link Optional} instance bearing the domain object, or an
         * absent {@link Optional} if no domain object exists with the given
         * name.
         */
        Optional<MediatorInfoData> query(@Nonnull String mediatorName) throws RepositoryException;

        /**
         * Gets the mediator of a specific type associated with the given host name, if one exists
         * @param mediatorType The desired mediator type.
         * @param hostName The host name.
         * @throws RepositoryException When an error occurs while working with the
         * underlying data storage.
         * @return An {@link Optional} instance bearing the domain object, or an
         * absent {@link Optional} if no domain object exists with the given
         * name.
         */
        Optional<MediatorInfoData> queryByHost(@Nonnull String mediatorType, @Nonnull String hostName) throws RepositoryException;

    }

    /** Contract to be supported by all repositories of MediatorConnection domain object instances */
    interface MediatorConnectionRepository
        extends BusinessObjectRepository<MediatorConnectionData, MediatorConnectionMutationDescriptor> { }

    /**
     * Gets the repository for the entity's MediatorInfo domain object.
     * @return The corresponding repository instance.
     */
    MediatorInfoRepository getMediatorInfoRepository();

    /**
     * Gets the repository for the entity's MediatorConnection domain object.
     * @return The corresponding repository instance.
     */
    MediatorConnectionRepository getMediatorConnectionRepository();

    /**
     * Gets the mediator with the given identifier, if one exists
     * @param id The mediator identifier.
     * @throws RepositoryException When an error occurs while working with the
     * underlying data storage.
     * @return An {@link Optional} instance bearing the mediator instance, or
     * an absent {@link Optional} if no domain object exists with the given
     * identifier.
	 */
    Optional<MediatorEntity> query(int id) throws RepositoryException;

    /**
     * Gets the sequence composed of all mediators. Note that the sequence
     * may be implemented using a lazy technique, meaning, the produced sequence
     * does not require that domain object instances are all simultaneously held
     * in volatile memory.
     *
     * @throws RepositoryException When an error occurs while working with the
     * underlying data storage.
     * @return An {@link Iterable} representing the sequence.
	 */
    Iterable<MediatorEntity> queryAll() throws RepositoryException;

    /**
     * Gets the name of the mediator with the given identifier, if one exists
     * @param id The mediator identifier.
     * @throws RepositoryException When an error occurs while working with the
     * underlying data storage.
     * @return An {@link Optional} instance bearing the mediator instance name,
     * or an absent {@link Optional} if no domain object exists with the given
     * identifier.
     */
    Optional<String> queryMediatorName(int id) throws RepositoryException;
}
