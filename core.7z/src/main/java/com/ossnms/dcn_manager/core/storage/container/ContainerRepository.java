package com.ossnms.dcn_manager.core.storage.container;

import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.BusinessEntityRepository;
import com.ossnms.dcn_manager.core.storage.BusinessObjectRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Describes all operations that must be supported by a repository
 * of DCN Containers.
 */
public interface ContainerRepository
        extends BusinessEntityRepository<ContainerInfo, ContainerCreationDescriptor, ContainerDeletionDescriptor>,
        BusinessObjectRepository<ContainerInfo, ContainerInfoMutationDescriptor>, ContainerAssignmentRepository {

    /**
     * Find a container by its name. DCN containers have unique names.
     *
     * @param containerName Desired container name.
     * @return An instance of a container with the name provided, if found.
     * @throws RepositoryException When an error occurs when working with the database.
     */
    Optional<ContainerInfo> queryByName(@Nonnull String containerName) throws RepositoryException;

    /**
     * Find in Repository the root container entity.
     *
     * @return Must return the Root container from Repository
     * @throws RepositoryException If the root container was not found.
     */
    ContainerInfo getRootContainer() throws RepositoryException;


}
