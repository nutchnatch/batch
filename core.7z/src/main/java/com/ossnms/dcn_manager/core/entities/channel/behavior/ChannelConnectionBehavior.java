package com.ossnms.dcn_manager.core.entities.channel.behavior;

import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * <p>Class that implements the behavior dimension of the domain object that describes the volatile true
 * channel activation state or, in other words, the solution's connectivity to the given channel. This means
 * that the application must ensure that the actual channel activation state converges to the required one.</p>
 *
 * <p>The implementation is based on the State Machine design pattern to deal with actual activation
 * state transitions.</p>
 *
 * <p> Note that transitions are not applied on the on the domain object instance, due to its
 * immutable nature. Instead, state transitions produce a description of the resulting
 * mutation, which will be later applied on the repository. </p>
 *
 * <p> As all types that implement domain objects' behavior dimension, this class instances are
 * not thread-safe, and therefore cannot be shared by multiple threads without explicit synchronization.
 * </p>
 *
 * <p>The behavior implementation is materialized in the {@code ActualActivationEvents} class
 * and is based on the State Machine design pattern to deal with actual activation state
 * transitions. One instance of {@code ActualActivationEvents} must be created for each
 * instance of {@link ChannelConnectionData} that will serve as the base for changing
 * the actual channel activation state. This instance is created through a factory method,
 * {@code ChannelConnectionBehavior#eventHandlerFor(ChannelConnectionState)}.
 * The state machine is depicted in the following figure. State transitions are triggered by
 * firing the depicted events. </p>
 *
 * <p><figure>
 * <img src="doc-files/actual_activation_state-state.png">
 * <figcaption>State diagram of the actual activation state state machine</figcaption>
 * </figure></p>
 *
 * <p> The state machine is materialized in the following class hierarchy, only relevant to the domain
 * object implementation. For this reason the hierarchy is implemented within the state behavior
 * object as a set of static nested classes not accessible from the outside. This solution has the merit
 * of reducing overall complexity (i.e. reducing the number of top-level classes) at the expense of increasing
 * file level complexity (i.e. its size). Nevertheless, and considering the actual file size, the
 * tradeoff is positive. In the case that the current file size increases, this approach must be
 * reevaluated. </p>
 *
 * <p> <figure>
 * <img src="doc-files/actual_activation_state-class.png">
 * <figcaption>Class diagram of the actual activation state hierarchy</figcaption>
 * </figure> </p>
 *
 * <ul> Design decisions:
 * <li> Each state transition is materialized in an independent method,
 * to be overridden in concrete state classes; </li>
 * <li> Invalid transitions are signaled by producing an absent {@link Optional} instance,
 * instead of throwing an exception. Note that the exact reaction to an invalid
 * transition depends on the specific use case, and therefore throwing an exception
 * would be inappropriate; </li>
 * <li> Transitions are not applied on the on the domain object instance, due to its
 * immutable nature. Instead, state transitions produce a description of the resulting
 * mutation, which will be later applied on the repository. </li>
 * </ul>
 * @see ActualActivationState
 */
/*
 * @startuml doc-files/actual_activation_state-state.png
 * [*] --> Inactive
 * Inactive --> Creating : setCreating
 * Creating --> Active : setCreated
 * Activating --> Active : setActivated
 * Activating --> Failed : setFailed
 * Activating --> Deactivating : setDeactivating
 * Active --> Deactivating : setDeactivating
 * Active --> Failed : setFailed
 * Deactivating --> Inactive : setDeactivated
 * Deactivating --> Failed : setFailed
 * Creating --> Failed : setFailed
 * Failed --> Deactivating : setDeactivating
 * Failed --> Activating : setActivating
 * Failed --> Failed : setFailed
 * @enduml
 */
/*
 * @startuml doc-files/actual_activation_state-class.png
 * class ActualActivationEvents <<abstract>> {
 *   activated() : Optional<ChannelConnectionMutationDescriptor>
 *   deactivated() : Optional<ChannelConnectionMutationDescriptor>
 *   activating() : Optional<ChannelConnectionMutationDescriptor>
 *   deactivating() : Optional<ChannelConnectionMutationDescriptor>
 *   creating() : Optional<ChannelConnectionMutationDescriptor>
 *   created() : Optional<ChannelConnectionMutationDescriptor>
 *   failed() : Optional<ChannelConnectionMutationDescriptor>
 * }
 * ActualActivationEvents <|-- Active
 * ActualActivationEvents <|-- Inactive
 * ActualActivationEvents <|-- Activating
 * ActualActivationEvents <|-- Deactivating
 * ActualActivationEvents <|-- Failed
 * ActualActivationEvents <|-- StartingUp
 * ActualActivationEvents <|-- Shutdown
 * ActualActivationEvents <|-- Creating
 * hide fields
 * @enduml
 */
public class ChannelConnectionBehavior {

    private final ActualActivationEvents activationEvents;

	/**
	 * Initiates an instance with the given domain object data.
	 *
	 * @param state The instance containing the domain object data
	 * @param notifications Instance of the class responsible for sending notifications about channels.
	 * @throws NullPointerException if the received domain object data argument is {@code null}
	 */
    public ChannelConnectionBehavior(@Nonnull ChannelConnectionData state, @Nonnull ChannelNotifications notifications) {
        activationEvents = eventHandlerFor(state, notifications);
    }

    /**
     * Signals a channel as being in the process of creation. Channel creation is its initial
     * activation. Spontaneous deactivation/activation sequences may happen during its
     * lifetime should the mediation need to recover from a channel connection or process failure.
     *
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelConnectionMutationDescriptor> setCreating() {
        return activationEvents.creating();
    }

    /**
     * Signals a channel as having been created. The result of a created channel is an active channel.
     *
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelConnectionMutationDescriptor> setCreated(@Nonnull ChannelInteractionManager activationManager) {
        return activationEvents.created(activationManager);
    }

    /**
     * Signals a channel as having started the activation process.
     *
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelConnectionMutationDescriptor> setActivating() {
        return activationEvents.activating();
    }

    /**
     * Signals a channel as having been successfully activated.
     *
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelConnectionMutationDescriptor> setActive(
            @Nonnull ChannelInteractionManager activationManager) {
        return activationEvents.activated(activationManager);
    }

    /**
     * Signals a channel as having started the deactivation process.
     *
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelConnectionMutationDescriptor> setDeactivating() {
        return activationEvents.deactivating();
    }

    /**
     * Signals a channel as having been successfully deactivated.
     *
     * @param activationManager Instance of the class responsible for the activation policies.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelConnectionMutationDescriptor> setInactive(
            @Nonnull ChannelInteractionManager activationManager,
            @Nonnull MessageSource<NeEvent> neEventSource) {
        return activationEvents.deactivated(activationManager, neEventSource);
    }

    /**
     * Signals that activation of a channel has failed.
     *
     * @param activationManager Instance of the class responsible for the activation policies.
     * @param description Human readable failure description. Will be eventually forwarded to the operator.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<ChannelConnectionMutationDescriptor> setFailed(
            @Nonnull ChannelInteractionManager activationManager,
            @Nonnull MessageSource<NeEvent> neEventSource,
            @Nonnull Iterable<Integer> activeChildNes,
            @Nonnull String description) {
        return activationEvents.failed(activationManager, description, neEventSource, activeChildNes);
    }

    /**
     * <p>Creates a new instance of the behavior as a state machine for assistance
     * with changes of the actual activation state on a channel.</p>
     *
     * <p>This extra indirection is necessary because all mutation descriptors created
     * by state transitions must contain a reference to the original (target) entity.
     * However, enums are static instances, therefore they can not have any context
     * information. The solution found was to separate behavior from value and
     * instantiate a new behavior class with the appropriate target reference.</p>
     *
     * @param channelConnection Current channel connection state.
     * @param notifications Instance of the class responsible for sending notifications about channels.
     * @return An instance of the actual activation state machine.
     */
    private ActualActivationEvents eventHandlerFor(ChannelConnectionData channelConnection, ChannelNotifications notifications) {
        final ActualActivationEvents handler;
        switch (channelConnection.getActualActivationState()) {
        case ACTIVE:
            handler = new Active(channelConnection, notifications);
            break;
        case INACTIVE:
            handler = new Inactive(channelConnection, notifications);
            break;
        case ACTIVATING:
            handler = new Activating(channelConnection, notifications);
            break;
        case DEACTIVATING:
            handler = new Deactivating(channelConnection, notifications);
            break;
        case FAILED:
            handler = new Failed(channelConnection, notifications);
            break;
        case CREATING:
            handler = new Creating(channelConnection, notifications);
            break;
        default:
            throw new IllegalStateException("No behavior for actual activation state " +
                channelConnection.getActualActivationState());
        }
        return handler;
    }

    /**
     * Behavior component of the actual activation state. Handles state transitions using the State Machine pattern.
     * To reduce code duplication, allows all state transactions by default. Specific implementations must disallow
     * transitions as appropriate.
     *
     * @see ActualActivationState
     */
    private abstract static class ActualActivationEvents {

        private final ChannelConnectionData data;
        private final ChannelNotifications notifications;

        protected ActualActivationEvents(ChannelConnectionData data, ChannelNotifications notifications)  {
            this.data = data;
            this.notifications = notifications;
        }

        /**
         * Promotes a change to the "creating" state.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelConnectionMutationDescriptor> creating() {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "created" state.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelConnectionMutationDescriptor> created(@Nonnull final ChannelInteractionManager activationManager) {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "activating" state.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelConnectionMutationDescriptor> activating() {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "active" state.
         * @param activationManager Instance of the class responsible for the activation policies.
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelConnectionMutationDescriptor> activated(@Nonnull ChannelInteractionManager activationManager) {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "deactivating" state.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelConnectionMutationDescriptor> deactivating() {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "inactive" state.
         * @param activationManager Instance of the class responsible for the activation policies.
         * @param neEventSource NE event source for publishing events regarding children NE states.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelConnectionMutationDescriptor> deactivated(@Nonnull ChannelInteractionManager activationManager,
                                                                                   @Nonnull MessageSource<NeEvent> neEventSource) {
            return Optional.empty();
        }

        /**
         * Promotes a change to the "failed" state.
         * @param activationManager Instance of the class responsible for the activation policies.
         * @param description Additional, human readable, state description.
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        public Optional<ChannelConnectionMutationDescriptor> failed(
                @Nonnull final ChannelInteractionManager activationManager, @Nonnull final String description,
                @Nonnull final MessageSource<NeEvent> neEventSource, @Nonnull final Iterable<Integer> activeChildNeIds) {
            return switchToFailed(activationManager, neEventSource, activeChildNeIds, description);
        }

        protected Optional<ChannelConnectionMutationDescriptor> switchToFailed(@Nonnull ChannelInteractionManager activationManager, @Nonnull MessageSource<NeEvent> neEventSource, @Nonnull Iterable<Integer> activeChildNeIds, @Nonnull String description) {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.FAILED)
                    .setAdditionalInfo(description)
                    .whenApplied(in -> {
                        final ChannelActivationFailedEvent event =
                                new ChannelActivationFailedEvent(
                                        in.getResult().getId(), in.getResult().getAdditionalInfo());
                        getNotifications().notifyChanges(event);
                        activationManager.onChannelInteractionEnded(event);
                        for (final Integer neId : activeChildNeIds) {
                            neEventSource.push(new NeActivationFailedEvent(neId, tr(Message.CHANNEL_FAILED)));
                        }
                    }));
        }

        protected ChannelConnectionMutationDescriptor buildMutation() {
            return new ChannelConnectionMutationDescriptor(data);
        }

        protected ChannelNotifications getNotifications() {
            return notifications;
        }

    }

    private abstract static class CancellableState extends ActualActivationEvents {

        protected CancellableState(ChannelConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelConnectionMutationDescriptor> deactivating() {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.DEACTIVATING)
                    .setAdditionalInfo("")
                    .whenApplied(in -> getNotifications().notifyChanges(new ChannelDeactivatingEvent(in.getResult().getId())))
            );
        }

    }

    private static final class Creating extends ActualActivationEvents {

        protected Creating(ChannelConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelConnectionMutationDescriptor> created(@Nonnull final ChannelInteractionManager activationManager) {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.ACTIVE)
                    .setAdditionalInfo("")
                    .whenApplied(in ->  {
                            final ChannelActivatedEvent event = new ChannelActivatedEvent(in.getResult().getId());
                            getNotifications().notifyChanges(event);
                            activationManager.onChannelInteractionEnded(event);
                        }
                    ));
        }
    }

    private static final class Activating extends CancellableState {

        protected Activating(ChannelConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelConnectionMutationDescriptor> activated(@Nonnull final ChannelInteractionManager activationManager) {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.ACTIVE)
                    .setAdditionalInfo("")
                    .whenApplied(in -> {
                            final ChannelActivatedEvent event = new ChannelActivatedEvent(in.getResult().getId());
                            getNotifications().notifyChanges(event);
                            activationManager.onChannelInteractionEnded(event);
                        }
                    ));
        }

    }

    private static final class Active extends CancellableState {

        protected Active(ChannelConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

    }

    private static final class Deactivating extends ActualActivationEvents {

        protected Deactivating(ChannelConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelConnectionMutationDescriptor> deactivated(@Nonnull final ChannelInteractionManager activationManager,
                                                                                   @Nonnull final MessageSource<NeEvent> neEventSource) {
            return Optional.of(buildMutation()
                .setConnection(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .whenApplied(in -> {
                        final ChannelDeactivatedEvent event = new ChannelDeactivatedEvent(in.getResult().getId());
                        getNotifications().notifyChanges(event);
                        activationManager.onChannelInteractionEnded(event);
                    }
                ));
        }

    }

    private static class Inactive extends ActualActivationEvents {

        protected Inactive(ChannelConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        @Override
        public Optional<ChannelConnectionMutationDescriptor> creating() {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.CREATING)
                    .setAdditionalInfo("")
                    .whenApplied(in -> getNotifications().notifyChanges(new ChannelActivatingEvent(in.getTarget().getId())))
                );
        }

        /**
         * Promotes a change to the "failed" state.
         * @param activationManager Instance of the class responsible for the activation policies.
         * @param description Additional, human readable, state description.
         * @param neEventSource NE event source for publishing events regarding children NE states.
         * @param activeChildNeIds A collection of children NEs that should be marked as "failed" due to a Channel failure.
         *
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        @Override public Optional<ChannelConnectionMutationDescriptor> failed(
                @Nonnull ChannelInteractionManager activationManager, @Nonnull String description,
                @Nonnull MessageSource<NeEvent> neEventSource, @Nonnull Iterable<Integer> activeChildNeIds) {
            return Optional.empty();
        }

    }

    private static final class Failed extends Inactive {

        protected Failed(ChannelConnectionData data, ChannelNotifications notifications) {
            super(data, notifications);
        }

        /**
         * {@inheritDoc}
         *
         * <p>Mediations will recover failed channels automatically, so we need to allow a switch from Failed to Activating
         * without it going through the scheduler.</p>
         */
        @Override
        public Optional<ChannelConnectionMutationDescriptor> activating() {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.ACTIVATING)
                    .setAdditionalInfo("")
                    .whenApplied(in -> getNotifications().notifyChanges(new ChannelActivatingEvent(in.getResult().getId()))
                    ));
        }

        @Override
        public Optional<ChannelConnectionMutationDescriptor> deactivating() {
            return Optional.of(buildMutation()
                    .setConnection(ActualActivationState.DEACTIVATING)
                    .setAdditionalInfo("")
                    .whenApplied(in -> getNotifications().notifyChanges(new ChannelDeactivatingEvent(in.getResult().getId())))
                    );
        }

        /**
         * Promotes a change to the "failed" state.
         * @param activationManager Instance of the class responsible for the activation policies.
         * @param description Additional, human readable, state description.
         * @return A mutation descriptor with all required data changes and behavior, or an absent value if
         *  the mutation can not be applied.
         */
        @Override public Optional<ChannelConnectionMutationDescriptor> failed(
                @Nonnull final ChannelInteractionManager activationManager, @Nonnull final String description,
                @Nonnull final MessageSource<NeEvent> neEventSource, @Nonnull final Iterable<Integer> activeChildNeIds) {
            return switchToFailed(activationManager, neEventSource, activeChildNeIds, description);
        }

    }

}
