package com.ossnms.dcn_manager.core.entities.ne.data;

import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;

import java.util.Optional;
import java.util.function.Function;

/**
 * A class that contains the same data as {@link NeGatewayRouteData} but that
 * is mutable and not thread safe.
 *
 * It should be used to facilitate mutation and creation with specific
 * derived types.
 */
public class NeGatewayRouteMutationDescriptor
        extends NeConnectionRouteMutationDescriptor<NeGatewayRouteData, NeGatewayRouteMutationDescriptor> {

    public NeGatewayRouteMutationDescriptor(NeGatewayRouteData target) {
        super(target);
    }

    @Override
    protected NeGatewayRouteData doApply() {
        final boolean areAnyAttributesSet =
                areSortingAttributesChanged() || getKey().isPresent() ||
                areNamingAttributesChanged();
        return areAnyAttributesSet || !getProperties().isEmpty()
                   ? new NeGatewayRouteBuilder()
                        .setProperties(getTarget().getAllOpaqueProperties())
                        .setProperties(getProperties())
                        .setPriority(getPriority().orElse(getTarget().getPriority()))
                        .setCost(getCost().orElse(getTarget().getCost()))
                        .setUsed(getUsed().orElse(getTarget().isUsed()))
                        .setKey(getKey().orElse(getTarget().getKey()))
                        .setDomain(getDomain().or(getTarget().getDomain()))
                        .setGneName(getGneName().orElse(getTarget().getGneName()))
                        .build(getTarget().getId(), getTarget().getVersion())
                   : getTarget();
    }

    private boolean areSortingAttributesChanged() {
        return getPriority().isPresent() || getCost().isPresent() || getUsed().isPresent();
    }

    private boolean areNamingAttributesChanged() {
        return getDomain().isPresent() || getGneName().isPresent();
    }

    @Override
    protected NeGatewayRouteMutationDescriptor self() {
        return this;
    }

    /** Obtains the domain name from a connection route mutation object. For usage with transformation streams. */
    public static final Function<NeGatewayRouteMutationDescriptor, Optional<String>> GET_DOMAIN_NAME =
            input -> null != input ? input.getDomain().or(input.getTarget().getDomain()) : null;

}
