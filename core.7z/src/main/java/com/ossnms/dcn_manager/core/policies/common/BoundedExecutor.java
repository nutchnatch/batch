package com.ossnms.dcn_manager.core.policies.common;

import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>A thread-safe implementation of a bounded executor, supported by a backing bounded or unbounded
 * {@link Executor} instance. The goal is to provide regulation of items submitted to the executor
 * instance while maintaining an estimative of the work items currently executing. The implementation
 * rejects execution requests that exceed the specified maximum value.</p>
 *
 * <p>Notice that processing load is expected to be regulated by the underlying {@link Executor} instance,
 * while the load imposed on other components (e.g. mediation) is expected to be regulated by the
 * number of allowed simultaneous work items, parameterized upon construction and eventually modified through
 * {@link #setMaxWorkItemCount(int)}.</p>
 *
 * @param <T> The concrete type of work items (i.e. {@link Job} realizations) that will be executed.
 */
@ThreadSafe
public class BoundedExecutor<T extends PolicyJob<?>> {

    private final Logger logger;

    /**
     * The contract that instances of "signals" to be sent to work items must fulfill.
     * This interface allows the  {@link BoundedExecutor} to remain ignorant of signal
     * types and does not increase the signature footprint of work items.
     *
     * @param <T> The concrete type of work items.
     */
    public interface Signaller<T> {
        /**
         * Predicate that selects a work item that should receive the signal.
         * @param job Work item under evaluation.
         * @return True if the signal should be sent to the work item.
         */
        boolean select(@Nonnull T job);

        /**
         * Signals a work item. The actual interaction with the work item is left to
         * the concrete implementation.
         * @param job Work item instance.
         * @return An instance of {@link Runnable} if a long running task should be executed.
         */
        Optional<Runnable> signal(@Nonnull T job);
    }

    /** The underlying thread mobilization policy (i.e. regulation of processing load). */
    private final Executor executor;
    /** The estimate of the jobs currently running. */
    private final Queue<T> ongoingWorkItems;
    /** The estimate of the current number of elements in the queue.
     * Used to provide constant time complexity in {@link #getWorkItemCount()}. */
    private final AtomicInteger size;
    /** The maximum number of work items that can be executed simultaneously. */
    private volatile int maxWorkItems;

    /**
     * Initiates an instance with the given thread execution policy and maximum
     * number of simultaneous work items allowed.
     * @param executor The executor instance to be used to schedule request servicing execution.
     * @param maxWorkItems The maximum allowed number of simultaneous work items.
     * @throws IllegalArgumentException If {@literal maxWorkItems} is not greater
     * than 0.
     */
    public BoundedExecutor(@Nonnull String classifier, @Nonnull Executor executor, int maxWorkItems) {

        if(maxWorkItems <= 0) {
            throw new IllegalArgumentException();
        }

        this.logger = getLogger(getClass().getName() + "." + classifier);
        this.executor = executor;
        this.ongoingWorkItems = new ConcurrentLinkedQueue<>();
        this.maxWorkItems = maxWorkItems;
        this.size = new AtomicInteger();
    }

    /**
     * Submits the given work item for execution, rejecting it if the maximum allowed number has
     * reached the specified maximum value.
     *
     * Note that high priority jobs will never be rejected if the maximum has been already reached.
     * The intuition is that those jobs must be executed as soon as possible and only depend on
     * available system capacity. They will however increase the count of ongoing work, thus
     * limiting lower priority jobs while appearing on statistics gathered.
     *
     * @param workItem The work item to be submitted for execution.
     * @return A boolean value indicating whether the work item was accepted (true) or
     * rejected (false).
     */
    public boolean trySubmitWorkItem(T workItem) {

        // Make execution permission reservation
        final int currentSize = size.incrementAndGet();

        // Are we allowed to execute the work item?
        if(currentSize <= maxWorkItems || workItem.getPriority() == PolicyJob.Priority.HIGH) {
            // Reservation was successful
            try {
                logger.debug("Executing {} [PUSH]", workItem);
                // careful: may throw an exception. don't update state before this.
                executor.execute(workItem);
                ongoingWorkItems.add(workItem);
                return true;
            } catch (final RejectedExecutionException e) {
                logger.warn("Executor refused work item. {}", e.getMessage());
            }
        }

        // We aren't allowed to execute. Let's re-adjust permissions
        size.decrementAndGet();
        return false;
    }

    public boolean reserveWorkCapacity() {
        // Make execution permission reservation
        final int currentSize = size.incrementAndGet();

        // Are we allowed to execute the work item?
        if (currentSize <= maxWorkItems) {
            return true;
        }

        // We aren't allowed to execute. Let's re-adjust permissions
        size.decrementAndGet();
        return false;
    }

    public void releaseWorkCapacity() {
        size.decrementAndGet();
    }

    public void setItemAsOngoing(T workItem) {
        logger.debug("Executing {} [PULL]", workItem);
        ongoingWorkItems.add(workItem);
    }

    /**
     * Signals the completion of the work item for which the given predicate applies, removing it from
     * the current estimate of ongoing work.
     * @param selector The predicate to be used to select the work item for which completion is being signaled.
     * @return {@link Optional} instance bearing the completed work item, or an absent {@link Optional} if none
     * was selected.
     */
    public Optional<T> signalWorkItemCompletion(@Nonnull Predicate<T> selector) {

        for(final T item : ongoingWorkItems) {
            if(selector.test(item) && ongoingWorkItems.remove(item)) {
                int newSize = size.decrementAndGet();
                logger.debug("Completed {} (remaining = {})", item, newSize);
                return Optional.of(item);
            }
        }
        return Optional.empty();
    }

    /**
     * Signals the cancellation of work items for which the given predicate applies, removing them from
     * the current estimate of ongoing work.
     * @param selector The predicate to be used to select the work items for which cancellation is being signaled.
     */
    public void signalWorkItemCancellation(@Nonnull Predicate<T> selector) {

        for(final T item : ongoingWorkItems) {
            if(selector.test(item) && ongoingWorkItems.remove(item)) {
                item.cancel();
                int newSize = size.decrementAndGet();
                logger.debug("Cancelled {} (remaining = {})", item, newSize);
            }
        }
    }

    /**
     * Propagates a "signal" towards a work item for which a given predicate applies. If the signal produces
     * a piece of runnable code, it will be submitted for execution.
     * @param signaller An instance of {@link Signaller}, which selects and signals a work item.
     * @return True if a work item was signalled.
     */
    public boolean signalWorkItem(@Nonnull final Signaller<T> signaller) {
        for(final T item : ongoingWorkItems) {
            if(signaller.select(item)) {
                final Optional<Runnable> additionalTask = signaller.signal(item);
                if(additionalTask.isPresent()) {
                    executor.execute(additionalTask.get());
                }
                return true;
            }
        }
        return false;
    }

    /**
     * @return An estimate of the number of currently executing work items.
     */
    public int getWorkItemCount() {
        return size.get();
    }

    /**
     * @return The maximum number of work items that can be simultaneously executed.
     */
    public int getMaxWorkItemCount() {
        return maxWorkItems;
    }

    /**
     * The maximum number of work items that can be simultaneously executed.
     * @param value the new maximum value.
     * @throws IllegalArgumentException If {@literal value} is not greater than 0.
     */
    public void setMaxWorkItemCount(int value) {
        if(value <= 0) {
            throw new IllegalArgumentException();
        }
        maxWorkItems = value;
    }

    /**
     * for debug purposes only
     * @return stream for the ongoing work items
     */
    Stream<T> getOngoingWorkItems(){
        return ongoingWorkItems.stream();
    }

}
