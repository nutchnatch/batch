package com.ossnms.dcn_manager.core.storage.uow;

import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;

import javax.annotation.Nonnull;
import java.util.function.BiFunction;
import java.util.function.Consumer;

/**
 * <p>Unit of Work.</p>
 *
 * <p>Implementations must ensure that operations are performed atomically, i.e.,
 * failure of one operation will result in the rollback of any changes made until that point.</p>
 *
 * <p>Operation failures are reported by throwing an exception.</p>
 *
 * <p>Unfortunately callers must be aware of the type of operations that support rollback.
 * Essentially all methods that are able to operate on a specific kind of UowContext instances
 * support rollback.</p>
 *
 * <p>Result consumers are called after all data changing operations have been executed
 * successfully.</p>
 *
 * @param <A> Result accumulator type.
 */
public interface UnitOfWork<A> {

    /**
     * Adds a step to this unit of work.
     * @param unit Work step.
     * @param <R> Type of the result returned by the work step.
     */
    <R> UnitOfWork<A> addUnit(@Nonnull UowFunction<R> unit);
    /**
     * Adds a step to this unit of work together with code that will consume any result generated.
     * @param unit Work step.
     * @param successConsumer Consumer for the result produced by {@code unit}.
     * @param <R> Type of the result returned by the work step.
     */
    <R> UnitOfWork<A> addUnit(@Nonnull UowFunction<R> unit, @Nonnull Consumer<R> successConsumer);
    /**
     * Adds a step to this unit of work together with code that will consume any result generated
     * and accumulate it.
     * @param unit Work step.
     * @param successConsumer Consumer for the result produced by {@code unit}, which also accumulates it
     *                        and returns the new accumulator value.
     * @param <R> Type of the result returned by the work step.
     */
    <R> UnitOfWork<A> addUnit(@Nonnull UowFunction<R> unit, @Nonnull BiFunction<R, A, A> successConsumer);

    /**
     * Specialized worker step for applying mutations. This is necessary because mutations may specify
     * their own continuations, which are executed right before the consumer provided.
     * @param unit Work step.
     * @param target Mutation to be applied.
     * @param successConsumer Consumer for the result produced by applying the mutation.
     * @param <M> Actual mutation type.
     * @param <R> Type of the result returned by the mutation work step.
     */
    <M extends MutationDescriptor<?, ?>, R> UnitOfWork<A> addUnit(@Nonnull UowBiFunction<M, R> unit, @Nonnull M target, @Nonnull Consumer<R> successConsumer);
    /**
     * Specialized worker step for applying mutations. This is necessary because mutations may specify
     * their own continuations, which are executed right before the consumer provided.
     * @param unit Work step.
     * @param target Mutation to be applied.
     * @param successConsumer Consumer for the result produced by applying the mutation, which also accumulates it
     *                        and returns the new accumulator value.
     * @param <M> Actual mutation type.
     * @param <R> Type of the result returned by the mutation work step.
     */
    <M extends MutationDescriptor<?, ?>, R> UnitOfWork<A> addUnit(@Nonnull UowBiFunction<M, R> unit, @Nonnull M target, @Nonnull BiFunction<R, A, A> successConsumer);

    /**
     * Executes all work steps in order.
     * @return Any result accumulated.
     * @throws DcnManagerException If a work step fails.
     */
    A apply() throws DcnManagerException;
}
