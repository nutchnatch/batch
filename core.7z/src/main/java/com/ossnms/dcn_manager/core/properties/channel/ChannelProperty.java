package com.ossnms.dcn_manager.core.properties.channel;

import com.ossnms.dcn_manager.core.configuration.properties.WellKnownChannelPropertyNames;
import com.ossnms.dcn_manager.core.properties.EntityPropertyOperations;

/**
 * Contains well known channel property names as mentioned in the user interface description files.
 * Is also able to manage property retrieval from a merged set of Channel Type and Channel Instance
 * (Channel entity) properties.
 */
public enum ChannelProperty implements EntityPropertyOperations  {

    /** Unique EM/Channel name. */
    ID_NAME(new ChannelPropertyOperations(WellKnownChannelPropertyNames.ID_NAME)),
    DISPLAY_ADDRESS(new ChannelPropertyOperations(WellKnownChannelPropertyNames.DISPLAY_ADDRESS)),
    RECONNECT_INTERVAL(new ChannelPropertyOperations(WellKnownChannelPropertyNames.RECONNECT_INTERVAL)),
    CONCURRENT_ACTIVATIONS_LIMITED(new ChannelPropertyOperations(WellKnownChannelPropertyNames.CONCURRENT_ACTIVATIONS_LIMITED)),
    CONCURRENT_ACTIVATIONS_LIMIT(new ChannelPropertyOperations(WellKnownChannelPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT)),
    USER_TEXT(new ChannelPropertyOperations(WellKnownChannelPropertyNames.USER_TEXT));

    private final ChannelPropertyOperations delegate;

    private ChannelProperty(ChannelPropertyOperations delegate) {
        this.delegate = delegate;
    }

    @Override
    public String getName() {
        return delegate.getName();
    }

    @Override
    public Scope getScope() {
        return delegate.getScope();
    }

}
