package com.ossnms.dcn_manager.core.entities.emne;

import javax.annotation.Nonnull;

/**
 * Discovery policies supported by EM/NE.
 */
public enum DiscoveryPolicy {
    NO_DISCOVERY("No Discovery"),
    DISCOVER_ALL_NETWORK("Discover All Network"),
    DISCOVERY_BY_DOMAIN("Discovery By Domain");

    private final String guiLabel;

    private DiscoveryPolicy(String label) {
        guiLabel = label;
    }

    /** @return This object representation as a string, which is its GUI label. */
    @Override
    public String toString() {
        return guiLabel;
    }

    /**
     * Returns the enum constant with the specified GUI label. The label
     * must match exactly a GUI label used to declare an enum constant in this type.
     *
     * @param label The GUI label
     * @throws IllegalArgumentException If the label does not match any of the known
     *  enum constants.
     * @return The enum constant with the specified GUI label.
     */
    public static DiscoveryPolicy valueOfGuiLabel(@Nonnull String label) {
        for (final DiscoveryPolicy policy : DiscoveryPolicy.values()) {
            if (policy.guiLabel.equals(label)) {
                return policy;
            }
        }
        throw new IllegalArgumentException("Discovery policy does not support label: " + label);
    }
}
