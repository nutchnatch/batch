package com.ossnms.dcn_manager.core.configuration.transformations;

import javax.annotation.Nullable;

import com.google.common.base.Function;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;

/**
 * Transforms instances of {@link MediatorType} into their names.
 */
public final class GetMediatorTypeName implements Function<MediatorType, String> {

    @Override
    public String apply(@Nullable MediatorType input) {
        return null != input ? input.getName() : null;
    }
}