package com.ossnms.dcn_manager.core.properties.channel;

import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPropertySetters;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.properties.EntityProperties;
import com.ossnms.dcn_manager.core.properties.NamedPropertyHandler;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Contains well known EM/NE property names as mentioned in the user interface description files.
 * Is also able to manage property retrieval from a merged set of Channel Type and Channel Instance
 * (channel entity) properties. Notice that all channel entity properties are materialized in its
 * {@link ChannelUserPreferencesData} domain object.
 */
public final class ChannelProperties extends EntityProperties<ChannelProperty, ChannelType, ChannelUserPreferencesData, ChannelPropertySetters<?>> {

    public ChannelProperties() {
        super(ChannelProperty.values());
    }

    @Override
    @Nonnull
    protected ChannelPropertyHandler[] getHandlers() {
        return PROPERTY_HANDLERS;
    }

    private abstract static class ChannelPropertyHandler
            extends NamedPropertyHandler<ChannelType, ChannelUserPreferencesData, ChannelPropertySetters<?>> {

        protected ChannelPropertyHandler(String name) {
            super(name);
        }

    }

    private static final ChannelPropertyHandler[] PROPERTY_HANDLERS = {

            new ChannelPropertyHandler(ChannelProperty.ID_NAME.getName()) {
                @Override
                public void set(@Nonnull ChannelType type, @Nonnull ChannelPropertySetters<?> target, @Nonnull String name, String value) throws InvalidMutationException {
                    try {
                        target.setName(value);
                    } catch (final IllegalArgumentException e) {
                        throw new InvalidMutationException("Property {} is invalid.", e, ChannelProperty.ID_NAME.getName());
                    }
                }

                @Override
                public Optional<String> get(@Nonnull ChannelType type, @Nonnull ChannelUserPreferencesData domainObject, @Nonnull String name) {
                    return Optional.of(domainObject.getName());
                }
            },

            new ChannelPropertyHandler(ChannelProperty.RECONNECT_INTERVAL.getName()) {
                @Override
                public void set(@Nonnull ChannelType type, @Nonnull ChannelPropertySetters<?> target, @Nonnull String name, String value) throws InvalidMutationException {
                    target.setReconnectInterval(integerValueOf(value, name));
                }

                @Override
                public Optional<String> get(@Nonnull ChannelType type, @Nonnull ChannelUserPreferencesData domainObject, @Nonnull String name) {
                    return Optional.of(String.valueOf(domainObject.getReconnectInterval()));
                }
            },

            new ChannelPropertyHandler(ChannelProperty.CONCURRENT_ACTIVATIONS_LIMIT.getName()) {
                @Override
                public void set(@Nonnull ChannelType type, @Nonnull ChannelPropertySetters<?> target, @Nonnull String name, String value) throws InvalidMutationException {
                    target.setConcurrentActivationsLimit(integerValueOf(value, name));
                }

                @Override
                public Optional<String> get(@Nonnull ChannelType type, @Nonnull ChannelUserPreferencesData domainObject, @Nonnull String name) {
                    return Optional.of(String.valueOf(domainObject.getConcurrentActivationsLimit()));
                }
            },

            new ChannelPropertyHandler(ChannelProperty.CONCURRENT_ACTIVATIONS_LIMITED.getName()) {
                @Override
                public void set(@Nonnull ChannelType type, @Nonnull ChannelPropertySetters<?> target, @Nonnull String name, String value) throws InvalidMutationException {
                    target.setConcurrentActivationsLimited(booleanValueOf(value, name));
                }

                @Override
                public Optional<String> get(@Nonnull ChannelType type, @Nonnull ChannelUserPreferencesData domainObject, @Nonnull String name) {
                    return Optional.of(String.valueOf(domainObject.isConcurrentActivationsLimited()));
                }
            },

            new ChannelPropertyHandler(ChannelProperty.USER_TEXT.getName()) {
                @Override
                public void set(@Nonnull ChannelType type, @Nonnull ChannelPropertySetters<?> target, @Nonnull String name, String value) {
                    target.setUserText(Optional.ofNullable(value));
                }

                @Override
                public Optional<String> get(@Nonnull ChannelType type, @Nonnull ChannelUserPreferencesData domainObject, @Nonnull String name) {
                    return domainObject.getUserText();
                }
            },
            new ChannelPropertyHandler(null) {
                @Override
                public void set(@Nonnull ChannelType type, @Nonnull ChannelPropertySetters<?> target, @Nonnull String name, String value) {
                    target.setProperty(name, value);
                }

                @Override
                public Optional<String> get(@Nonnull ChannelType type, @Nonnull ChannelUserPreferencesData domainObject, @Nonnull String name) {
                    return domainObject.getOpaqueProperty(name);
                }

                @Override
                public boolean handles(@Nonnull ChannelType type, @Nonnull String name) {
                    return true; // catch-all
                }
            }
    };

}
