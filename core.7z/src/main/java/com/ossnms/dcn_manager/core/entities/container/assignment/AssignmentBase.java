package com.ossnms.dcn_manager.core.entities.container.assignment;

import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;

/**
 * Contains the common information for Assignments.
 */
public abstract class AssignmentBase {
    private final ContainerInfo containerInfo;
    private final AssignmentType assignmentType;

    public AssignmentBase(final ContainerInfo containerInfo, final AssignmentType assignmentType) {
        this.containerInfo = containerInfo;
        this.assignmentType = assignmentType;
    }

    public ContainerInfo getContainerInfo() {
        return containerInfo;
    }

    public AssignmentType getAssignmentType() {
        return assignmentType;
    }
}
