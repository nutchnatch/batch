package com.ossnms.dcn_manager.core.storage.channel;

import javax.annotation.Nonnull;

import com.mysema.query.collections.CollQuery;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.QChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.storage.BusinessObjectRepository;

/**
 * Contract to be supported by all repositories of physical connection information against
 * Channels when accessed through different Mediator servers.
 */
public interface ChannelPhysicalConnectionRepository
    extends BusinessObjectRepository<ChannelPhysicalConnectionData, ChannelPhysicalConnectionMutationDescriptor> {

    /**
     * Provides a query builder object for conducting ad-hoc searches.
     * @param info Query metadata.
     * @return An instance of a query builder object.
     */
    CollQuery query(QChannelPhysicalConnectionData info);

    /**
     * Gets the sequence composed of all channel physical instances associated
     * with a specific logical channel.
     *
     * @param logicalChannelId Identifier of the logical channel containing the
     *  physical instances we're interested in.
     * @return An {@link Iterable} representing the sequence.
     * @see #queryAll()
     */
    Iterable<ChannelPhysicalConnectionData> queryAll(int logicalChannelId);

    /**
     * Inserts information about a physical channel connection in the repository.
     * @param initialConnectionData Initial domain object data.
     * @param channelId The logical Channel identifier.
     * @param mediatorInstanceId Identifier of the physical Mediator that manages this physical Channel.
     * @return The newly inserted channel connection information.
     */
    ChannelPhysicalConnectionData insert(@Nonnull ChannelPhysicalConnectionData.ChannelConnectionInitialData initialConnectionData,
            int channelId, int mediatorInstanceId);

    /**
     * Removes physical channel connection information from the repository.
     * @param physicalChannelId The identifier of the physical channel connection instance.
     */
    void remove(int physicalChannelId);
}
