package com.ossnms.dcn_manager.core.entities;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;

/**
 * Interface exposed by entities that are able to store properties
 * in addition to their normal attributes. The properties retrieved
 * through this interface have no meaning whatsoever to the domain
 * entity.
 */
public interface PropertyBag {

    /**
     * <p>Exposes individual property values.</p>
     *
     * <p>Remember that these are "unmanaged" properties. Properties
     * with meaning (i.e., "well known" properties) are mapped to
     * object attributes and are not accessible through this method.</p>
     *
     * @param name Desired property name.
     * @return The property value.
     */
    Optional<String> getOpaqueProperty(@Nonnull String name);

    /**
     * <p>Exposes all property name/value pairs.</p>
     *
     * <p>Remember that these are "unmanaged" properties. Properties
     * with meaning (i.e., "well known" properties) are mapped to
     * object attributes and are not accessible through this method.</p>
     *
     * @return A map with property names as keys and
     * property values. May not be immutable but changes
     * must not affect the original entity.
     */
    Map<String, String> getAllOpaqueProperties();

}
