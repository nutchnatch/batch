package com.ossnms.dcn_manager.core.storage.uow;

/**
 * Unit of Work context information.
 */
public interface UowContext {

}
