package com.ossnms.dcn_manager.core.policies.common;

import com.google.common.collect.FluentIterable;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.Queue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static org.slf4j.LoggerFactory.getLogger;


/**
 * <p>An utility class (hence the package accessibility) that implements an unbounded
 * thread-safe and lock-free queue that supports parameterized pruning. </p>
 *
 * @param <T> The type of elements stored in the queue.
 */
@ThreadSafe
class PrunableQueue<T> {

    private final Logger logger = getLogger(getClass());

    /** The underlying queue. */
    private final Queue<T> queue;
    /** The estimate of the current number of elements in the queue.
     * Used to provide constant time complexity in {@link #getSize()}. */
    private final AtomicInteger size;

    /**
     * Initiates an instance.
     */
    public PrunableQueue() {
        queue = new PriorityBlockingQueue<>();
        size = new AtomicInteger(0);
    }

    /**
     * @return Gets an estimate of the number of elements currently in the queue.
     * It's a constant time operation.
     */
    public int getSize() {
        return size.get();
    }

    /**
     * Tries to remove the first element of queue, if one is available.
     * @return An {@link Optional} instance bearing the removed element, or an
     * absent {@link Optional} if no elements were available.
     */
    public Optional<T> tryDequeue() {
        final Optional<T> result = Optional.ofNullable(queue.poll());
        if(result.isPresent()) {
            int newSize = size.decrementAndGet();
            logger.debug("Dequeued {} (remaining = {})", result.get(), newSize);
        }
        return result;
    }

    /**
     * Tries to remove the first element of queue that satisfies a given predicate,
     * if one is available.
     * @return An {@link Optional} instance bearing the removed element, or an
     * absent {@link Optional} if no elements were available.
     */
    public Optional<T> tryDequeue(@Nonnull Predicate<T> condition) {
        for (T element : queue) {
            if (condition.test(element) && queue.remove(element)) {
                int newSize = size.decrementAndGet();
                logger.debug("Dequeued {} (remaining = {})", element, newSize);
                return Optional.of(element);
            }
        }
        return Optional.empty();
    }

    /**
     * Adds the given element to the end of the queue.
     * @param elem The element to be added.
     */
    public void enqueue(@Nonnull T elem) {
        queue.add(elem);
        int newSize = size.incrementAndGet();
        logger.debug("Enqueued {} (remaining = {})", elem, newSize);
    }

    /**
     * Removes from the queue the first element for which the given predicate applies.
     * @param predicate The predicate to be used for selecting the element to be removed.
     * @return An {@link Optional} instance bearing the pruned element, or an absent
     * {@link Optional} if the predicate did not applied to any of the contained elements.
     */
    public Optional<T> prune(@Nonnull Predicate<T> predicate) {
        T result = null;
        for(final T elem : queue) {
            if(predicate.test(elem) && queue.remove(elem)) {
                result = elem;
                int newSize = size.decrementAndGet();
                logger.debug("Pruned {} (remaining = {})", elem, newSize);
                break;
            }
        }
        return Optional.ofNullable(result);
    }

    /**
     * Removes from the queue all elements for which the given predicate applies.
     * @param predicate The predicate to be used for selecting the elements to be removed.
     */
    public Iterable<T> pruneAll(@Nonnull Predicate<T> predicate) {
        final FluentIterable<T> removed =
            FluentIterable.from(queue)
                .filter(predicate::test)
                .filter(queue::remove);
        removed.forEach(elem -> {
                int newSize = size.decrementAndGet();
                logger.debug("Pruned {} (remaining = {})", elem, newSize);
            });
        return removed;
    }

    /**
     * For debug purposes only
     * @return stream with all elements currently in the queue
     */
    public Stream<T> getElements(){
        return queue.stream();
    }

}

