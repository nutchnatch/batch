package com.ossnms.dcn_manager.composables.import_export.mediator;

import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorInstanceValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorValueObject.Builder;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorInstanceValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance.PRIMARY_PRIORITY_LEVEL;

/**
 * Transforms the {@link MediatorEntity} to {@link MediatorValueObject}
 */
public final class ExportMediatorTransformer {

    private ExportMediatorTransformer() {
        // utility class
    }

    public static MediatorValueObject apply(Pair<MediatorEntity, Iterable<MediatorInstance>> mediator) {
        checkNotNull(mediator.getLeft(), "The Mediator Entity cannot be null");
        final MediatorInfoData info = mediator.getLeft().getInfo();

        final Optional<String> primaryHost = getPrimaryPhysicalInfo(mediator);
        final Collection<MediatorInstanceValueObject> secondaries = getSecondariesPhysicalInfo(mediator.getRight());

        final Builder builder = ImmutableMediatorValueObject.builder()
                .mediatorId(info.getId())
                .name(info.getName())
                .type(info.getTypeName())
                .host(primaryHost.orElse(""))
                .mediatorInstances(secondaries)
                .reconnectInterval(info.getReconnectAttemptInterval())
                .concurrentActivationsLimit(info.getConcurrentActivationsLimit())
                .concurrentActivationsLimited(info.isConcurrentActivationsLimited())
                .propertyBag(mediator.getLeft().getAllOpaqueProperties());

        if (info.getDescription().isPresent()) {
            builder.description(info.getDescription().get());
        }

        // TODO export user-text

        return builder.build();
    }

    private static Optional<String> getPrimaryPhysicalInfo(Pair<MediatorEntity, Iterable<MediatorInstance>> mediator) {
        return StreamSupport.stream(mediator.getRight().spliterator(), false)
                .filter(primary -> primary.getPhysicalInfo().getPriority() == PRIMARY_PRIORITY_LEVEL)
                .map(primary -> primary.getPhysicalInfo().getHost())
                .findFirst();
    }

    private static Collection<MediatorInstanceValueObject> getSecondariesPhysicalInfo(
            Iterable<MediatorInstance> mediatorInstances) {
        return StreamSupport.stream(mediatorInstances.spliterator(), false)
                .filter(secondary -> secondary.getPhysicalInfo().getPriority() != PRIMARY_PRIORITY_LEVEL)
                .map(secondary -> ImmutableMediatorInstanceValueObject.builder()
                        .host(secondary.getPhysicalInfo().getHost())
                        .priority(secondary.getPhysicalInfo().getPriority())
                        .build())
                .collect(Collectors.toList());
    }
}