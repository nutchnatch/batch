package com.ossnms.dcn_manager.composables.import_export.channel;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.StreamSupport;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Transforms the {@link ChannelEntity} to {@link ChannelValueObject}
 */
public class ExportChannelTransformer implements Function<ChannelEntity, Optional<ChannelValueObject>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ExportChannelTransformer.class);

    private final MediatorEntityRepository mediatorRepository;
    private final MediatorInstanceEntityRepository mediatorInstanceRepository;

    public ExportChannelTransformer(@Nonnull final MediatorEntityRepository mediatorRepository,
            @Nonnull final MediatorInstanceEntityRepository mediatorInstanceRepository) {
        this.mediatorRepository = mediatorRepository;
        this.mediatorInstanceRepository = mediatorInstanceRepository;
    }

    @Override public Optional<ChannelValueObject> apply(@Nonnull final ChannelEntity input) {
        checkNotNull(input, "The ChannelEntity cannot be null");
        final ChannelUserPreferencesData userPreferences = input.getUserPreferences();
        try {
            final ChannelInfoData info = input.getInfo();
            final MediatorValueObject mediatorValueObject = getMediatorValueObject(info.getMediatorId());

            final ChannelValueObject channel = ImmutableChannelValueObject.builder()
                    .channelId(info.getId())
                    .type(info.getType())
                    .mediator(mediatorValueObject)
                    .name(userPreferences.getName())
                    .concurrentActivationsLimit(userPreferences.getConcurrentActivationsLimit())
                    .concurrentActivationsLimited(userPreferences.isConcurrentActivationsLimited())
                    .propertyBag(input.getAllOpaqueProperties())
                    .build();

            return Optional.of(channel);
        } catch (final RepositoryException e) {
            LOGGER.error("Error on repository for channel={}", userPreferences.getName(), e);
        } catch (final Exception e) {
            LOGGER.error("Critical error to transform Channel={}", input, e);
        }

        return Optional.empty();
    }

    private MediatorValueObject getMediatorValueObject(@Nonnull final Integer id) throws RepositoryException {
        final MediatorInfoData mediatorInfoData = mediatorRepository.getMediatorInfoRepository().query(id)
                .orElseThrow(() -> new RepositoryException("Mediator id={} is not present in DCN", id));

        Iterable<MediatorInstance> mediatorInstances = mediatorInstanceRepository.queryAll(id);

        MediatorPhysicalData mediatorPhysicalData = StreamSupport.stream(mediatorInstances.spliterator(), false)
                .map(MediatorInstance::getPhysicalInfo)
                .filter(primary -> primary.getPriority() == MediatorInstance.PRIMARY_PRIORITY_LEVEL)
                .findFirst()
                .orElseThrow(() -> new RepositoryException("MediatorPhysicalData with PRIMARY_PRIORITY_LEVEL is not present"));

        return ImmutableMediatorValueObject.builder()
                .mediatorId(1)
                .name(mediatorInfoData.getName())
                .host(mediatorPhysicalData.getHost())
                .type(mediatorInfoData.getTypeName())
                .mediatorInstances(Collections.emptyList()) // Don't need put all data. This is only for identification
                .build();
    }
}