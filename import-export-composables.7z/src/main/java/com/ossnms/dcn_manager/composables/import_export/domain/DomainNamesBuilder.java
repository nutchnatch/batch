package com.ossnms.dcn_manager.composables.import_export.domain;

import static java.util.stream.Collectors.toSet;

import java.util.Collection;
import java.util.stream.StreamSupport;

import org.apache.commons.lang3.builder.Builder;

import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;

/**
 * Builds a Set of Domain names associated a NE.
 */
public class DomainNamesBuilder implements Builder<Collection<String>> {

    private final Integer neId;
    private final DomainRepository domainRepository;

    public DomainNamesBuilder(final Integer neId, final DomainRepository domainRepository) {
        this.neId = neId;
        this.domainRepository = domainRepository;
    }

    @Override
    public Collection<String> build() {

        final Iterable<DomainInfoData> domains = domainRepository.queryAllForNE(neId);

        return StreamSupport.stream(domains.spliterator(), false)
                .map(DomainInfoData::getName)
                .collect(toSet());
    }
}
