package com.ossnms.dcn_manager.composables.import_export.mediator;

import com.ossnms.dcn_manager.composables.import_export.Either;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.core.properties.mediator.MediatorProperties;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Strings.isNullOrEmpty;
import static com.ossnms.dcn_manager.composables.import_export.Either.left;
import static com.ossnms.dcn_manager.composables.import_export.Either.right;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.stream.Collectors.toList;

public class ImportMediatorTransformer implements Function<MediatorValueObject, Either<LoggerItem, MediatorCreateDescriptor>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ImportMediatorTransformer.class);

    private final StaticConfiguration configuration;

    public ImportMediatorTransformer(final StaticConfiguration configuration) {
        this.configuration = configuration;
    }

    @Override
    public Either<LoggerItem, MediatorCreateDescriptor> apply(@Nonnull final MediatorValueObject input) {
        checkNotNull(input);

        final Optional<MediatorType> mediatorType = Optional.ofNullable(configuration.getMediatorTypes().get(input.getType()));

        if (!mediatorType.isPresent()) {
            return left(new LoggerItemMediator(input.getName(),
                    tr(Message.UNKNOWN_MEDIATOR_TYPE, input.getName()), MessageSeverity.ERROR));
        }

        if (isNullOrEmpty(input.getHost())) {
            return left(new LoggerItemMediator(input.getName(), 
                    tr(Message.MEDIATOR_HOST_EMPTY, input.getName()), MessageSeverity.ERROR));
        }

        final MediatorCreateDescriptor createDescriptor = new MediatorCreateDescriptor(input.getName(), mediatorType.get().getName());

        buildMediatorInstances(input, createDescriptor);
        buildAttributes(input, createDescriptor);

        try {
            new MediatorProperties().setProperties(mediatorType.get(), createDescriptor.getInfoInitialData(), input.getPropertyBag());
            return right(createDescriptor);
        } catch (final InvalidMutationException e) {
            LOGGER.error("Critical error when trying to transform mediator", e);
            return left(new LoggerItemMediator(input.getName(),
                    tr(Message.MEDIATOR_INVALID_PROPERTIES, input.getName()), MessageSeverity.ERROR));
        }
    }

    private void buildAttributes(@Nonnull MediatorValueObject input, MediatorCreateDescriptor createDescriptor) {
        input.getReconnectInterval().ifPresent(
                createDescriptor.getInfoInitialData()::setReconnectAttemptInterval);
        input.getDescription().ifPresent(
                s -> createDescriptor.getInfoInitialData().setDescription(Optional.of(s)));
        input.getConcurrentActivationsLimit().ifPresent(
                createDescriptor.getInfoInitialData()::setConcurrentActivationsLimit);
        input.getConcurrentActivationsLimited().ifPresent(
                createDescriptor.getInfoInitialData()::setConcurrentActivationsLimited);
    }

    private void buildMediatorInstances(
            @Nonnull MediatorValueObject input, @Nonnull MediatorCreateDescriptor createDescriptor) {
        final MediatorInstanceCreateDescriptor primary = new MediatorInstanceCreateDescriptor(input.getHost());
        primary.getInitialData().setPriority(MediatorInstance.PRIMARY_PRIORITY_LEVEL);
        primary.getConnectionInitialData().setActive(true);

        List<MediatorInstanceCreateDescriptor> secondaries = input.getMediatorInstances().stream()
                .map(secondary -> {
                    MediatorInstanceCreateDescriptor descriptor = new MediatorInstanceCreateDescriptor(secondary.getHost());
                    descriptor.getInitialData().setPriority(secondary.getPriority());
                    return descriptor;
                }).collect(toList());

        createDescriptor.getInstanceCreateDescriptors().add(primary);
        createDescriptor.getInstanceCreateDescriptors().addAll(secondaries);
    }
}
