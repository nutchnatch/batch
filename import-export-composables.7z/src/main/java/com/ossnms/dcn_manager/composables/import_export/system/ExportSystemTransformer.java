package com.ossnms.dcn_manager.composables.import_export.system;

import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.AssignedContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableSystemValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;
import com.ossnms.dcn_manager.core.storage.container.ContainerAssignmentRepository;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.function.Function;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableAssignedContainer.of;
import static java.util.stream.Collectors.toList;
import static java.util.stream.StreamSupport.stream;

/**
 * Transforms the {@link SystemInfo} to {@link SystemValueObject}
 */
public class ExportSystemTransformer implements Function<SystemInfo, SystemValueObject> {

    private final ContainerAssignmentRepository assignments;

    public ExportSystemTransformer(ContainerAssignmentRepository assignmentRepository) {
        assignments = assignmentRepository;
    }

    @Override
    public SystemValueObject apply(@Nonnull SystemInfo input) {
        checkNotNull(input, "The SystemInfo cannot be null");

        return ImmutableSystemValueObject.builder()
                .name(input.getName())
                .description(input.getDescription())
                .userText(input.getUserText())
                .assignedContainers(assignedContainers(input.getId()))
                .build();
    }

    private Collection<AssignedContainer> assignedContainers(int systemId) {
        return stream(assignments.queryAllBySystem(systemId).spliterator(), false)
                .map(assignment -> of(assignment.getContainerInfo().getName(), assignment.getAssignmentType().toFlag()))
                .collect(toList());
    }

}