package com.ossnms.dcn_manager.composables.import_export.ne;

import com.ossnms.dcn_manager.composables.import_export.domain.DomainNamesBuilder;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.container.ContainerInfoBase;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.import_export.ImportConfigurationException;
import com.ossnms.dcn_manager.core.import_export.valueobjects.AssignedContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeAdditionalInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import com.ossnms.dcn_manager.core.properties.ne.NeGatewayRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeProperties;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerAssignmentRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeOperationRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableAssignedContainer.of;
import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeValueObject.builder;
import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toList;
import static java.util.stream.StreamSupport.stream;

/**
 * Transforms the {@link NeEntity} to {@link NeValueObject}
 */
public class ExportNeTransformer implements Function<NeEntity, Optional<NeValueObject>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExportNeTransformer.class);

    private final ChannelEntityRepository channelRepository;
    private final DomainRepository domainRepository;
    private final ContainerAssignmentRepository assignmentRepository;
    private final SystemRepository systemRepository;
    private final NeGatewayRoutesRepository routesRepository;
    private final NeOperationRepository neOperationRepository;
    private final StaticConfiguration configuration;
    private final Map<Integer, NeAdditionalInfo> additionalInfo;

    public ExportNeTransformer(final ChannelEntityRepository channelRepository, NeEntityRepository neRepository, DomainRepository domainRepository, final StaticConfiguration configuration, ContainerAssignmentRepository assignmentRepository, SystemRepository systemRepository, final Map<Integer, NeAdditionalInfo> additionalInfo) {
        this.channelRepository = channelRepository;
        this.domainRepository = domainRepository;
        this.assignmentRepository = assignmentRepository;
        this.systemRepository = systemRepository;
        routesRepository = neRepository.getNeGatewayRoutesRepository();
        neOperationRepository = neRepository.getNeOperationRepository();
        this.configuration = configuration;
        this.additionalInfo = additionalInfo;
    }

    @Override
    public Optional<NeValueObject> apply(@Nonnull NeEntity input) {
        checkNotNull(input, "The NeEntity cannot be null");
        NeUserPreferencesData preferences = input.getPreferences();
        NeInfoData info = input.getInfo();
        
        try {
            Optional<NeOperationData> operational = getNeOperationData(input);

            NeValueObject ne = builder()
                    .neId(info.getNeId())
                    .name(preferences.getName())
                    .type(info.getProxyType())
                    .channel(getChannelName(info.getChannelId()))
                    .familyLabel(operational.flatMap(NeOperationData::getFamily))
                    .subTypeLabel(operational.flatMap(NeOperationData::getNeSubType))
                    .typeLabel(operational.flatMap(NeOperationData::getNeType))
                    .location(operational.flatMap(NeOperationData::getLocation))
                    .propertyBag(getProperties(input))
                    .domainNames(getDomainNames(info))
                    .assignedContainers(fetchContainerAssignments(info.getNeId()))
                    .systemContainer(systemContainer(preferences.getContainerId()))
                    .neAdditionalInfo(ofNullable(additionalInfo.get(info.getNeId())))
                    .build();
            
            return Optional.of(ne);
        } catch (final ImportConfigurationException | RepositoryException e) {
            LOGGER.error("Error to export NE={}", preferences.getName(), e);
        }

        return empty();
    }

	private Optional<String> systemContainer(Optional<Integer> containerId) {
        return containerId
                .flatMap(this::fetchSystem)
                .map(ContainerInfoBase::getName);
    }
    
    private Optional<SystemInfo> fetchSystem(Integer id) {
        try {
            return systemRepository.query(id);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch system container", e);
            return empty();
        }
    }

    private Iterable<? extends AssignedContainer> fetchContainerAssignments(int neId) {
        return stream(assignmentRepository.queryAllByNE(neId).spliterator(), false)
                .map(assignment -> of(assignment.getContainerInfo().getName(), assignment.getAssignmentType().toFlag()))
                .collect(toList());
    }

    public Collection<String> getDomainNames(NeInfoData info) {
        return new DomainNamesBuilder(info.getId(), domainRepository).build();
    }

    public Optional<NeOperationData> getNeOperationData(@Nonnull NeEntity input) throws RepositoryException {
        return neOperationRepository.query(input.getInfo().getId());
    }

    public String getChannelName(@Nonnull Integer id) throws RepositoryException {
        final Optional<String> channelEntity = channelRepository.queryChannelName(id);

        if (!channelEntity.isPresent()) {
            throw new RepositoryException("Channel id={} is not present in DCN", id);
        }

        return channelEntity.get();
    }

    public Map<String, String> getProperties(
            @Nonnull NeEntity neEntity) throws RepositoryException, ImportConfigurationException {
        final NeType type = configuration.getNeTypes().get(neEntity.getInfo().getProxyType());

        if (null == type) {
            throw new ImportConfigurationException("Ne type=''{}'' not found", neEntity.getInfo().getProxyType());
        }

        final Iterable<NeGatewayRouteData> routes = routesRepository.queryRoutes(neEntity.getInfo().getId());

        final Map<String, String> propertyMapping = new HashMap<>();

        propertyMapping.putAll(new NeProperties().getProperties(type, neEntity));
        propertyMapping.putAll(new NeGatewayRouteProperties(type).toProperties(neEntity, routes));

        return propertyMapping;
    }
}