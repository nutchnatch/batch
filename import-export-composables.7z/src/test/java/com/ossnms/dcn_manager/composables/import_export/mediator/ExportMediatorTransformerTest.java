package com.ossnms.dcn_manager.composables.import_export.mediator;

import com.google.common.collect.Iterables;
import com.ossnms.dcn_manager.composables.import_export.EntitiesCreatorForTest;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorInstanceValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Test;

import java.util.Collection;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class ExportMediatorTransformerTest extends EntitiesCreatorForTest {

    @Test public void testApply() {
        final MediatorEntity entity = buildMediatorEntity();
        Collection<MediatorInstance> mediatorInstances = buildMediatorInstances();

        final MediatorValueObject mediator = ExportMediatorTransformer.apply(
                ImmutablePair.of(entity, mediatorInstances));

        assertThat(mediator.getName(), is(entity.getInfo().getName()));
        assertThat(mediator.getType(), is(entity.getInfo().getTypeName()));
        assertThat(mediator.getHost(), is("host1"));

        assertThat(mediator.getConcurrentActivationsLimit().get(), is(entity.getInfo().getConcurrentActivationsLimit()));
        assertThat(mediator.getConcurrentActivationsLimited().get(), is(entity.getInfo().isConcurrentActivationsLimited()));
        assertThat(mediator.getDescription().get(), is(entity.getInfo().getDescription().get()));
        assertThat(mediator.getPropertyBag().size(), is(entity.getAllOpaqueProperties().size()));

        assertThat(mediator.getMediatorInstances().size(), is(1));
        MediatorInstanceValueObject value = Iterables.getFirst(mediator.getMediatorInstances(), null);
        assertNotNull(value);
        assertThat(value.getHost(), is("host2"));
        assertThat(value.getPriority(), is(2));


        for (final String key : mediator.getPropertyBag().keySet()) {
            assertTrue(entity.getAllOpaqueProperties().containsKey(key));
        }
    }

    @Test(expected=NullPointerException.class)
    public void testApply_error() {
        ExportMediatorTransformer.apply(null);
    }
}
