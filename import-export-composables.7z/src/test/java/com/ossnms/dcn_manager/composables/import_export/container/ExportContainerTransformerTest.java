package com.ossnms.dcn_manager.composables.import_export.container;

import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ContainerValueObject;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Test;

import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ExportContainerTransformerTest {
    private ContainerRepository containerRepo(ContainerInfo... containers) throws RepositoryException {
        ContainerRepository containerRepository = mock(ContainerRepository.class);
        when(containerRepository.query(anyInt())).thenReturn(empty());
        for (ContainerInfo container : containers) {
            when(containerRepository.query(container.getId())).thenReturn(of(container));
        }
        return containerRepository;
    }

    @Test public void shouldExportName() throws Exception {
        ContainerInfo containerInfo = new ContainerInfo(1, 1, "Container name");

        ContainerValueObject valueObject = new ExportContainerTransformer(containerRepo()).apply(containerInfo);

        assertThat(valueObject.name(), is("Container name"));
    }

    @Test public void shouldExportUserText() throws Exception {
        ContainerInfo without = new ContainerInfo(1, 1, empty(), "name", empty(), empty());
        ContainerInfo with = new ContainerInfo(1, 1, empty(), "name", empty(), of("User text"));

        ContainerValueObject valueWithout = new ExportContainerTransformer(containerRepo()).apply(without);
        ContainerValueObject valueWith = new ExportContainerTransformer(containerRepo()).apply(with);

        assertThat(valueWith.userText(), is(of("User text")));
        assertThat(valueWithout.userText(), is(empty()));
    }

    @Test public void shouldExportDescription() throws Exception {
        ContainerInfo without = new ContainerInfo(1, 1, empty(), "name", empty(), empty());
        ContainerInfo with = new ContainerInfo(1, 1, empty(), "name", of("Description text"), empty());

        ContainerValueObject valueWithout = new ExportContainerTransformer(containerRepo()).apply(without);
        ContainerValueObject valueWith = new ExportContainerTransformer(containerRepo()).apply(with);

        assertThat(valueWith.description(), is(of("Description text")));
        assertThat(valueWithout.description(), is(empty()));
    }

    @Test public void shouldExportParent() throws Exception {
        ContainerInfo parent = new ContainerInfo(2, 1, "Parent Container");
        ContainerInfo without = new ContainerInfo(1, 1, empty(), "name", empty(), empty());
        ContainerInfo with = new ContainerInfo(1, 1, of(parent.getId()), "name", empty(), empty());

        ContainerValueObject valueWithout = new ExportContainerTransformer(containerRepo(parent)).apply(without);
        ContainerValueObject valueWith = new ExportContainerTransformer(containerRepo(parent)).apply(with);

        assertThat(valueWith.parent(), is(of("Parent Container")));
        assertThat(valueWithout.parent(), is(empty()));
    }
}