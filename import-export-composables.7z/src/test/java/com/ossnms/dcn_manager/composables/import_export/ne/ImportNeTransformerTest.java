package com.ossnms.dcn_manager.composables.import_export.ne;

import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableBiMap.Builder;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.import_export.identification.ChannelIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.Identification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableSystemValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;
import java.util.Optional;

import static java.util.Optional.of;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ImportNeTransformerTest {

    private static final String VALUE = "value";
    private static final String KEY = "key";

    private ChannelIdentification channelIdentification;
    private StaticConfiguration configuration;
    private Types<NeType> neTypes;
    private NeValueObject inputNe;
    private Identification<SystemValueObject, SystemInfo> systemIdentification;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() throws RepositoryException {
        configuration = mock(StaticConfiguration.class);
        channelIdentification = mock(ChannelIdentification.class);
        neTypes = mock(Types.class);
        NeType neType = mock(NeType.class);
        inputNe = ImmutableNeValueObject.of("name", "type", "channel")
                .withCoreId("coreId")
                .withPropertyBag(ImmutableMap.of(KEY, VALUE));

        when(channelIdentification.tryFindByName("channel"))
                .thenReturn(of(new ChannelUserPreferencesBuilder().setName("channel").build(1, 1)));

        systemIdentification = systemValueObject -> Optional.empty();

        when(configuration.getNeTypes()).thenReturn(neTypes);
        when(neTypes.get("type")).thenReturn(neType);

        when(neType.getName()).thenReturn("type");
        when(neType.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of());
        when(neType.getTypeProperties()).thenReturn(ImmutableMap.of());
        when(neType.mapIncomingPropertyName(KEY)).thenReturn(KEY);
        when(neType.getIdentificationControlMap()).thenReturn(buildEmptyNePropertiesControlMap());
        when(neType.getAdditionalTypeInfoControlMap()).thenReturn(buildEmptyNePropertiesControlMap());

    }

    @Test
    public void testApply() {

        final Optional<NeCreateDescriptor> descriptor = new ImportNeTransformer(channelIdentification, systemIdentification, configuration).apply(inputNe).getRight();

        assertTrue(descriptor.isPresent());
        assertThat(descriptor.get().getTypeName(), CoreMatchers.is("type"));
        assertThat(descriptor.get().getOpaqueProperty(KEY).orElse(null), CoreMatchers.is(VALUE));
    }

    @Test(expected = NullPointerException.class)
    public void testApply_input_null() {
        new ImportNeTransformer(channelIdentification, systemIdentification, configuration).apply(null);
    }

    @Test
    public void testApply_netype_not_supported() {
        when(neTypes.get("type")).thenReturn(null);

        final Optional<NeCreateDescriptor> descriptor = new ImportNeTransformer(channelIdentification, systemIdentification, configuration).apply(inputNe).getRight();

        assertFalse(descriptor.isPresent());
    }

    @Test
    public void testApply_channel_not_present() throws RepositoryException {
        when(channelIdentification.tryFindByName("channel")).thenReturn(Optional.empty());

        final Optional<NeCreateDescriptor> descriptor = new ImportNeTransformer(channelIdentification, systemIdentification, configuration).apply(inputNe).getRight();

        assertFalse(descriptor.isPresent());
    }

    @Test public void shouldImportSystemReference() throws Exception {
        NeValueObject ne = ImmutableNeValueObject.copyOf(inputNe).withSystemContainer("Some system");
        Map<SystemValueObject, SystemInfo> sysIds = ImmutableMap.of(ImmutableSystemValueObject.of("Some system"), new SystemInfo(42, 1, "Some system"));
        systemIdentification = systemValueObject -> Optional.ofNullable(sysIds.get(systemValueObject));


        NeCreateDescriptor descriptor = new ImportNeTransformer(channelIdentification, systemIdentification, configuration).apply(ne).getRight()
                .orElseThrow(() -> new AssertionError("Descriptor should be present"));
        Optional<Integer> containerId = new NeUserPreferencesData(1, 1, descriptor.getPreferences()).getContainerId();


        assertThat(containerId, is(of(42)));
    }

    @Test public void shouldNotImportUnknownSystemReference() throws Exception {
        NeValueObject ne = ImmutableNeValueObject.copyOf(inputNe).withSystemContainer("Unknown system");
        Map<SystemValueObject, SystemInfo> sysIds = ImmutableMap.of(ImmutableSystemValueObject.of("system"), new SystemInfo(42, 1, "system"));
        systemIdentification = systemValueObject -> Optional.ofNullable(sysIds.get(systemValueObject));


        NeCreateDescriptor descriptor = new ImportNeTransformer(channelIdentification, systemIdentification, configuration).apply(ne).getRight()
                .orElseThrow(() -> new AssertionError("Descriptor should be present"));
        Optional<Integer> containerId = new NeUserPreferencesData(1, 1, descriptor.getPreferences()).getContainerId();


        assertThat(containerId, is(of(0)));
    }
    
    private BiMap<String, String> buildEmptyNePropertiesControlMap() {
        final Builder<String,String> builder = ImmutableBiMap.builder();
        return builder.build();
    }

}
