package com.ossnms.dcn_manager.composables.import_export.channel;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.import_export.identification.MediatorIdentification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static java.util.Collections.emptyList;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ImportChannelTransformerTest {

    private static final String VALUE = "value";
    private static final String KEY = "id";
    private static final String CHANNEL_TYPE = "channel_type";

    private MediatorIdentification mediatorIdentification;
    private StaticConfiguration configuration;
    private Types<ChannelType> types;
    private ChannelValueObject input;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() throws RepositoryException {
        ChannelType type = mock(ChannelType.class);
        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.<String, String>of());
        when(type.getTypeProperties()).thenReturn(ImmutableMap.<String, String>of());
        when(type.mapIncomingPropertyName(KEY)).thenReturn(KEY);
        when(type.getName()).thenReturn("type_name");
        
        types = mock(Types.class);
        when(types.get(CHANNEL_TYPE)).thenReturn(type);

        configuration = mock(StaticConfiguration.class);
        when(configuration.getChannelTypes()).thenReturn(types);

        MediatorValueObject mediatorValueObject = ImmutableMediatorValueObject.builder()
                .mediatorId(1)
                .name("name")
                .host("127.0.0.1")
                .type("type")
                .concurrentActivationsLimited(false)
                .concurrentActivationsLimit(42)
                .mediatorInstances(emptyList())
                .build();

        MediatorInfoData mediator = new MediatorInfoBuilder()
                .setName("name")
                .setTypeName("type")
                .build(1, 1);

        input = ImmutableChannelValueObject.builder()
                .mediator(mediatorValueObject)
                .type(CHANNEL_TYPE)
                .name("name")
                .channelId(1)
                .propertyBag(ImmutableMap.of(KEY, VALUE))
                .build();

        mediatorIdentification = mock(MediatorIdentification.class);
        when(mediatorIdentification.tryIdentify(mediatorValueObject)).thenReturn(Optional.of(mediator));
    }

    @Test
    public void testApply() {
        final Optional<ChannelCreateDescriptor> descriptor = new ImportChannelTransformer(configuration, mediatorIdentification).apply(input).getRight();

        assertTrue(descriptor.isPresent());
        assertThat(descriptor.get().getTypeName(), is("type_name"));
        assertThat(descriptor.get().getPreferencesInitialData().getName(), is("name"));
        assertThat(descriptor.get().getMediatorId(), is(1));
        assertThat(descriptor.get().getPreferencesInitialData().getPropertyBag().containsKey(KEY), is(true));
        assertThat(descriptor.get().getPreferencesInitialData().getPropertyBag().containsValue(VALUE), is(true));
    }

    @Test(expected = NullPointerException.class)
    public void testApply_invalid_input() {
        new ImportChannelTransformer(configuration, mediatorIdentification).apply(null);
    }

    @Test
    public void testApply_wrong_channelType() {
        when(types.get(CHANNEL_TYPE)).thenReturn(null);

        final Optional<ChannelCreateDescriptor> descriptor = new ImportChannelTransformer(configuration, mediatorIdentification).apply(input).getRight();

        assertFalse(descriptor.isPresent());
    }
}
