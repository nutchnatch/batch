
export class Breadcrumb {
  links: Link[];
}

export class Link {  
  path?: string;
  label: string;
}

