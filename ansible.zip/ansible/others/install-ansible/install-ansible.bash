#!/bin/bash
set -e
echo This script will install ansible with python and pip.
echo This script needs 3 parameters :
echo - a binary repository, examples : nexus or mock_repository.
echo - the python repository, examples : nexus or official one.
echo - a boolean to indicate to install Python from sources and not threw yum.


main () {
  if [[ "$3" == "" ]]; then
     echo "Need 3 arguments: repository_binary<url> repository_python<url> installPythonFromSources<boolean>"
     me=`basename "$0"`
     echo "Example 1: ./$me http://repo/ https://pypi.python.org/simple true"
     echo "Example 2: ./$me http://other/ https://pypi.python.org/simple false"
     exit 1
  fi

  export REPOSITORY=$1
  export PYTHON_REPOSITORY=$2
  export PYTHON_FROM_SOURCES=$3
  export PYTHON_FILE=Python-2.7.13

  #compute the proxy string for use with pip packager
  if [[ -v HTTP_PROXY ]]; then
    export PYTHON_PROXY="--proxy ${HTTP_PROXY#http://}"
  fi

  if [[ "$PYTHON_FROM_SOURCES" == "true" ]]; then
    export PYTHON_BIN=/apps/python2/bin/python2.7
    export PIP_BIN=/apps/python2/bin/pip
    export ANSIBLE_BIN=/apps/python2/bin/ansible
    install_python_from_sources
  else
    export PYTHON_BIN=/bin/python
    export PIP_BIN=/bin/pip
    export ANSIBLE_BIN=/usr/bin/ansible
    install_python_from_package
  fi

  install_pip
  install_ansible
}

###############################
# INSTALL PYTHON FROM PACKAGE #
###############################
install_python_from_package() {
  PYTHON_PACKAGE=python
  echo "Install python from package"
  if yum list installed "$PYTHON_PACKAGE" >/dev/null 2>&1; then
    echo "Package python already installed"
  else
    yum -y install "$PYTHON_PACKAGE"
  fi
  PYTHON_PACKAGE=python-devel
  if yum list installed "$PYTHON_PACKAGE" >/dev/null 2>&1; then
    echo "Package python-devel already installed"
  else
    yum -y install "$PYTHON_PACKAGE"
  fi
}

###############################
# INSTALL PYTHON FROM SOURCES #
###############################
install_python_from_sources() {
  if [ -f "$PYTHON_BIN" ]; then
     echo "Python already installed";
     return
  fi

  mkdir -p /apps
  chown root:root /apps
  chmod 755 /apps
  [ -z "$REPOSITORY" ] && echo "Need to set REPOSITORY" && exit 1;

  mkdir -p install-python
  cd install-python

  echo "Install pre-requisites."
  yum -y install gcc zlib-devel bzip2-devel openssl-devel libffi-devel sqlite-devel wget

  echo "Remove existing sources."
  [ -f "$PYTHON_FILE" ] && rm -rf $PYTHON_FILE
  if ls $PYTHON_FILE.tar.* 1> /dev/null 2>&1; then
      rm -f $PYTHON_FILE.tar.*
  fi

  echo "Download python sources : $PYTHON_FILE.tar.xz"
  curl -s $REPOSITORY/software/python/$PYTHON_FILE.tar.xz -o $PYTHON_FILE.tar.xz

  echo "Untar $PYTHON_FILE sources."
  tar xf $PYTHON_FILE.tar.xz

  cd $PYTHON_FILE
  echo "Configure the build. (logs in configure.log)"
  ./configure --prefix=/apps/python2 1>configure.log 2>&1

  echo "Make (logs in make.log)"
  make 1>make.log 2>&1

  echo "Install (logs in install.log)"
  make altinstall 1>install.log 2>&1
}

###############
# INSTALL PIP #
###############
install_pip() {
  if [ -f "$PIP_BIN" ]; then
    echo "PIP already installed";
    return
  fi
  echo "Latest PIP will be installed";

  [ -z "$REPOSITORY" ] && echo "Need to set REPOSITORY" && exit 1;

  mkdir -p install-pip
  cd install-pip

  echo "Download $REPOSITORY/software/python/get-pip.py"
  curl -s $REPOSITORY/software/python/get-pip.py -o get-pip.py

  $PYTHON_BIN get-pip.py $PYTHON_PROXY -i $PYTHON_REPOSITORY
}

###################
# INSTALL ANSIBLE #
###################
install_ansible() {
  if [ -f "$ANSIBLE_BIN" ]; then
    echo "Ansible already installed";
    return
  fi

  echo "Install pre-requisites."
  yum -y install git openssl-devel libffi-devel sqlite-devel libselinux-python

  mkdir -p install-ansible
  cd install-ansible

  echo "Install ansible with pip"
  $PIP_BIN install ansible docker-py $PYTHON_PROXY -i $PYTHON_REPOSITORY

  if [[ "$PYTHON_FROM_SOURCES" == "true" ]]; then
    echo "Add symbolic link to binaries"
    # LINK_PATH=/usr/local/bin bug in jenkins ansible plugin doesn't see runnable in /usr/local/bin
    LINK_PATH=/usr/bin
    ln -fs /apps/python2/bin/ansible $LINK_PATH/ansible
    ln -fs /apps/python2/bin/ansible-playbook $LINK_PATH/ansible-playbook
    ln -fs /apps/python2/bin/ansible-galaxy $LINK_PATH/ansible-galaxy
    ln -fs /apps/python2/bin/ansible-console $LINK_PATH/ansible-console
    ln -fs /apps/python2/bin/ansible-doc $LINK_PATH/ansible-doc
    ln -fs /apps/python2/bin/ansible-pull $LINK_PATH/ansible-pull
    ln -fs /apps/python2/bin/ansible-vault $LINK_PATH/ansible-vault
  fi

}

main $@
