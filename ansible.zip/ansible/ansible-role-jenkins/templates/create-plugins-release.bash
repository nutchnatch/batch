#!/bin/bash

echo This script will create a new release of jenkins plugins based on this installation

TEMP=`ls tsp_plugin_v* 2>/dev/null`
if [[ ! ${TEMP:0:12} == "tsp_plugin_v" ]]; then
   echo Impossible to find current version; exit 1
fi

TEMP=${TEMP:12}
echo - installed version  : $TEMP

re='^[0-9]+$'
if ! [[ $TEMP =~ $re ]] ; then
   echo "error: Not a number" >&2; exit 1
fi

TEMP=$((1 + TEMP))
echo - created version     : $TEMP


RESOURCE="http://world-tsp-ci-assurance.is.echonet/nexus/repository/raw-internal/repository/jenkins/jenkins-plugins-$TEMP.tar.xz"


echo - created package     : $RESOURCE


RESPONSE=`curl -I --write-out "%{http_code}" --silent --output /dev/null $RESOURCE`


if [[ ! $RESPONSE == "404" ]]; then
   echo "The resource already exist ! (code:$RESPONSE)"
   exit 1
fi

read -rsp $'Press enter to create package and upload it...\n'

echo creation...
cd plugins
tar cfJ /tmp/jenkins-plugins-$TEMP.tar.xz *.jpi
echo upload...
curl -v --user '{{ nexus_admin_username }}:{{ nexus_admin_password }}' --upload-file /tmp/jenkins-plugins-$TEMP.tar.xz $RESOURCE

echo done