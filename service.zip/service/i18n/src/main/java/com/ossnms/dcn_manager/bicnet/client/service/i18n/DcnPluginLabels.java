package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;

/**
 * Generic labels for the plug-in. 
 */
public enum DcnPluginLabels {
    PLUGIN_NAME,
    PLUGIN_DESCRIPTION,    
    NOT_APPLICABLE,
    DCN_MENU_NAME,
    MENU_NAME;
    
    public JfxText guiName() {
        return Dcn18nSupport.getGuiName(this);
    }

    @Override
    public String toString() {
        return guiName().getText();
    }
}
