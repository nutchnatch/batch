package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;

public enum ImportExportProcessMessages {
    IMPORTING_MEDIATOR,
    IMPORTING_CHANNEL,
    IMPORTING_SYSTEMS,
    IMPORTING_CONTAINERS,
    EXPORTING_MEDIATOR,
    EXPORTING_MEDIATOR_FAIL,
    EXPORTING_CHANNEL,
    EXPORTING_CHANNEL_FAIL,
    EXPORTING_NE_FAIL,
    EXPORTING_CONTAINERS,
    EXPORTING_CONTAINERS_FAIL,
    EXPORTING_SYSTEMS,
    EXPORTING_SYSTEMS_FAIL;

    public JfxText guiName() {
        return Dcn18nSupport.getGuiName(this);
    }

    @Override
    public String toString() {
        return guiName().getText();
    }
}
