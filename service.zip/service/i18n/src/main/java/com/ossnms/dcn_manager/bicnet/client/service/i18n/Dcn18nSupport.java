package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.bicnet.framework.client.i18n.FrameworkMessages;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;

import javax.annotation.Nonnull;
import java.util.Locale;

/**
 * Support for internationalization.
 */
final class Dcn18nSupport extends JfxStringTable {

    private static final ClassLoader CLASSLOADER = Dcn18nSupport.class.getClassLoader();
    private static final String PROPERTIES_LOCATION = Dcn18nSupport.class.getPackage().getName() + ".dcnmgrpluginstrings";

    private static final FrameworkMessages FRAMEWORK_MSG = new FrameworkMessages(Dcn18nSupport.PROPERTIES_LOCATION,
            Locale.getDefault(), Dcn18nSupport.CLASSLOADER);

    private Dcn18nSupport() {
    }

    /**
     * Gets the GUI Name value from a ENUM.
     *
     * @param value the ENUM value.
     * @return the GUI Name.
     */
    public static JfxText getGuiName(@Nonnull Enum<?> value) {
        return new JfxText(FRAMEWORK_MSG.getString(value.getClass().getSimpleName() + "." + value.name()));
    }
}
