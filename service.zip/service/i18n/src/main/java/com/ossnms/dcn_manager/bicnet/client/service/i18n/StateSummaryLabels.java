package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;

/**
 * Labels for the presentation views module 
 */
public enum StateSummaryLabels {
    TITLE,
    MENU_NAME,
    MENU_SHORT_DESCRIPTION,
    MENU_LONG_DESCRIPTION,
    MEDIATORS_TITLE,
    CHANNELS_TITLE,
    NETWORKELEMENTS_TITLE,
    SELECT_PIECHART,
    ACTIVE,
    ACTIVATING,
    INACTIVE,
    FAILED,
    UNMANAGED,
    MEDIATOR_PIECHART,
    CHANNEL_PIECHART,
    NE_PIECHART;
    
    public JfxText guiName() {
        return Dcn18nSupport.getGuiName(this);
    }

    @Override
    public String toString() {
        return guiName().getText();
    }
}
