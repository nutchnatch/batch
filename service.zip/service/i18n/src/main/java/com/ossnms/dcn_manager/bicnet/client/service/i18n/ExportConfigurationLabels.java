package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;

/**
 * Labels for the Export module 
 */
public enum ExportConfigurationLabels {

    VIEW_TITLE,
    SELECT_FILE,
    BUTTON_BROWSER,
    MSG_EXPORTING,
    MSG_SUCCESS,
    MSG_ERROR,
    BUTTON_EXPORT,
    COMMAND_NAME;
    
    public JfxText guiName() {
        return Dcn18nSupport.getGuiName(this);
    }

    @Override
    public String toString() {
        return guiName().getText();
    }
}
