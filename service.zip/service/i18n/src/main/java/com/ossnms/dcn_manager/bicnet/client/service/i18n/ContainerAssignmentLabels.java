package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;

public enum ContainerAssignmentLabels {
    CONTAINER_ASSIGNMENT_TITLE,
    CONTAINER_TREE,
    NO_CONTAINERS_AVAILABLE,
    CONTAINER_SMART_FILTER,
    SET_PRIMARY
    ;

    public JfxText guiName() {
        return Dcn18nSupport.getGuiName(this);
    }

    @Override
    public String toString() {
        return guiName().getText();
    }
}
