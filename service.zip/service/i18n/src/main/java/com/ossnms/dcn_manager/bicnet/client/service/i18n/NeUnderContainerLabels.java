package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;

public enum NeUnderContainerLabels {
    NEW_NE_UNDER_CONTAINER,
    NE_TYPE,
    CHANNEL,
    MEDIATOR,
    MESSAGE_SELECT_NE,
    MESSAGE_NOT_FOUND,
    ;

    public JfxText guiName() {
        return Dcn18nSupport.getGuiName(this);
    }

    @Override
    public String toString() {
        return guiName().getText();
    }
}
