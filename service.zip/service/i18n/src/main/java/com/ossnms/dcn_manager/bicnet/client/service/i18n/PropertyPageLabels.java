package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;

/**
 * Labels for the Property pages module 
 */
public enum PropertyPageLabels {
    MSG_OPEN_FOR_UPDATE,
    MSG_OPEN_FOR_CREATE,
    
    MENU_PROPERTIES_DESCRIPTION,
    MENU_PROPERTIES,

    NO_ASSOCIATION,

    ERROR_ON_OPEN,
    ERROR_DUPLICATED_ROUTES,
    ERROR_REQUIRED_VALUE_EMPTY,
    ERROR_TABLE_CANNOT_BE_EMPTY,
    ERROR,
    ERROR_SAVE,
    ERROR_CRITICAL,
    ERROR_BUILD_PROPERTIES,
    ERROR_LOAD_PROPERTIES;
      
    public JfxText guiName() {
        return Dcn18nSupport.getGuiName(this);
    }
    
    @Override
    public String toString() {
        return guiName().getText();
    }
}
