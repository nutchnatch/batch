package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;

/**
 * Labels for the Settings module 
 */
public enum GlobalSettingsLabels {
    DCN_MANAGER,
    
    ENABLE_SCALED_STARTUP,
    SCALED_STARTUP,
    MEDIATOR_RETRY,
    CHANNEL_RETRY,
    NE_RETRY,
    RETRY_INTERVAL,
    UNIT,
    
    DISCOVER_POLICY_MODE,
    
    SHOW_NATIVE_NE_NAMING,

    DEFAULT_CONTAINER_NAME,

    FREEZE_NE_POSITION;
        
    public JfxText guiName() {
        return Dcn18nSupport.getGuiName(this);
    }

    @Override
    public String toString() {
        return guiName().getText();
    }
}
