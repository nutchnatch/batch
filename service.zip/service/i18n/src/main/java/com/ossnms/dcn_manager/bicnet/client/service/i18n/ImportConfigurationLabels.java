package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;

/**
 * Labels for the Import module 
 */
public enum ImportConfigurationLabels {

    CONFIRMATION_SFTP;
    
    public JfxText guiName() {
        return Dcn18nSupport.getGuiName(this);
    }

    @Override
    public String toString() {
        return guiName().getText();
    }
}
