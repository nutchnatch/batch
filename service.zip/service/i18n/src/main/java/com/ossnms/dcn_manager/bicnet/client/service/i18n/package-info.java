/**
 * Contains the resources for i18n stands. 
 */
package com.ossnms.dcn_manager.bicnet.client.service.i18n;