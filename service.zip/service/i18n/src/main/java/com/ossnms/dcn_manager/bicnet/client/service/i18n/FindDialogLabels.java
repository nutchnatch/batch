package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;

public enum FindDialogLabels {
    FIND_MENU,
    FIND_IN_DCN_TREE,
    FIND_IN_MAP,
    FIND_IN_DCN_TREE_DESC,
    FIND_IN_MAP_DESC;

    public JfxText guiName() {
        return Dcn18nSupport.getGuiName(this);
    }

    @Override
    public String toString() {
        return guiName().getText();
    }
}
