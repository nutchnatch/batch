package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import org.junit.Test;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

public class NeUnderContainerLabelsTest {
    @Test public void shouldContainALabelForEachEnumValue() throws Exception {
        String className = NeUnderContainerLabels.class.getSimpleName();
        NeUnderContainerLabels[] values = NeUnderContainerLabels.values();

        for (NeUnderContainerLabels value : values) {
            assertThat("Missing a label in resources for enum value: " + value.name(),
                    value.toString(), not(containsString(className)));
        }
    }
}