package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class StateSummaryLabelsTest {
    @Test public void testToString() {
        final String name = StateSummaryLabels.ACTIVATING.toString();

        assertThat(name, is("Activating"));
    }

    @Test public void testGuiName() {
        final JfxText name = StateSummaryLabels.ACTIVATING.guiName();

        assertThat(name.getText(), is("Activating"));
    }

    @Test public void testValues() {
        for (final StateSummaryLabels label : StateSummaryLabels.values()) {
            assertNotNull(label.guiName());
            assertTrue(StringUtils.isNotBlank(label.toString()));
        }
    }
}