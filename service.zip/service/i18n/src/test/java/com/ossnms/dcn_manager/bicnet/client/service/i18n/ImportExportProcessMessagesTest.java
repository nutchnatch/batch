package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import org.junit.Test;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

public class ImportExportProcessMessagesTest {
    @Test public void shouldContainALabelForEachEnumValue() throws Exception {
        String className = ImportExportProcessMessages.class.getSimpleName();
        ImportExportProcessMessages[] values = ImportExportProcessMessages.values();

        for (ImportExportProcessMessages value : values) {
            assertThat("Missing a label in resources for enum value: " + value.name(),
                    value.toString(), not(containsString(className)));
        }
    }
}