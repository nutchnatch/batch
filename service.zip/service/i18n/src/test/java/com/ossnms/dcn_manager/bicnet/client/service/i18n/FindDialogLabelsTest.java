package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class FindDialogLabelsTest {

    @Test
    public void testValues() {
        for (final FindDialogLabels label : FindDialogLabels.values()) {
            assertNotNull(label.guiName());
            assertTrue(StringUtils.isNotBlank(label.toString()));
        }
    }
}