package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class ImportConfigurationLabelsTest {
    @Test public void testToString() {
        final String name = ImportConfigurationLabels.CONFIRMATION_SFTP.toString();

        assertThat(name, is("Do you want to import the (S)FTP settings?"));
    }

    @Test public void testGuiName() {
        final JfxText name = ImportConfigurationLabels.CONFIRMATION_SFTP.guiName();

        assertThat(name.getText(), is("Do you want to import the (S)FTP settings?"));
    }

    @Test public void testValues() {
        for (final ImportConfigurationLabels label : ImportConfigurationLabels.values()) {
            assertNotNull(label.guiName());
            assertTrue(StringUtils.isNotBlank(label.toString()));
        }
    }
}