package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import com.ossnms.tools.jfx.JfxText;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class ExportConfigurationLabelsTest {
    @Test public void testToString() {
        final String name = ExportConfigurationLabels.MSG_SUCCESS.toString();

        assertThat(name, is("DCN Configuration exported with success"));
    }

    @Test public void testGuiName() {
        final JfxText name = ExportConfigurationLabels.MSG_SUCCESS.guiName();

        assertThat(name.getText(), is("DCN Configuration exported with success"));
    }

    @Test public void testValues() {
        for (final ExportConfigurationLabels label : ExportConfigurationLabels.values()) {
            assertNotNull(label.guiName());
            assertTrue(StringUtils.isNotBlank(label.toString()));
        }
    }
}