package com.ossnms.dcn_manager.bicnet.client.service.i18n;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import com.ossnms.tools.jfx.JfxText;

public class PropertyPageLabelsTest {

    @Test
    public void testToString() {
        final String name = PropertyPageLabels.MENU_PROPERTIES.toString();

        assertThat(name, is("&Properties"));
    }

    @Test
    public void testGuiName() {
        final JfxText name = PropertyPageLabels.MENU_PROPERTIES.guiName();

        assertThat(name.getText(), is("&Properties"));
    }

    @Test
    public void testValues() {
        for (final PropertyPageLabels label : PropertyPageLabels.values()) {
            assertNotNull(label.guiName());
            assertTrue(StringUtils.isNotBlank(label.toString()));
        }
    }
}
