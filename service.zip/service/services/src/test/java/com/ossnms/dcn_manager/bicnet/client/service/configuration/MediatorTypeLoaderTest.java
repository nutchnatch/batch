package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.net.URL;

import org.junit.Assert;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.mediatortype.Config;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorTypeLoader;



public class MediatorTypeLoaderTest {
    private static final URL XML_URL = MediatorTypeLoaderTest.class.getClassLoader().getResource("dcn-manager/mediatortype/MEDIATOR-TEST-mediator.xml");
    
    @Test
    public void testLoader() {
        final MediatorTypeLoader loader = new MediatorTypeLoader(XML_URL);
        final Config config = loader.loadConfiguration();
        
        Assert.assertNotNull(loader);
        Assert.assertNotNull(loader.loadConfiguration());
        Assert.assertNotNull(config.getName());
    }
}
