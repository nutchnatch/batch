package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.net.URL;

import org.junit.Assert;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.containertype.Config;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ContainerTypeLoader;


public class ContainerTypeLoaderTest {
    private static final URL XML_URL = ContainerTypeLoaderTest.class.getClassLoader().getResource("dcn-manager/containertype/DCN-TEST-containertype.xml");
    
    @Test
    public void testLoader() {
        final ContainerTypeLoader loader = new ContainerTypeLoader(XML_URL);
        final Config config = loader.loadConfiguration();
        
        Assert.assertNotNull(loader);
        Assert.assertNotNull(loader.loadConfiguration());
        Assert.assertNotNull(config.getName());
    }
}
