package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapabilities;
import com.ossnms.dcn_manager.core.jaxb.netype.Config;
import com.ossnms.dcn_manager.core.jaxb.type.DefaultIcon;
import com.ossnms.dcn_manager.core.jaxb.type.Element;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import com.ossnms.dcn_manager.core.jaxb.type.TypeProperties;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NeTypeTest {

    private NeType type;
    
    private TypeLoader<Config> typeLoader;
    private Config config;
    private DefaultIcon defaultIcon;
    private PropertyPageFiles propertyPageFiles;
    private TypeProperties typeProperties;
    
    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        typeLoader = mock(TypeLoader.class);
        config = mock(Config.class);
        defaultIcon = mock(DefaultIcon.class);
        propertyPageFiles = mock(PropertyPageFiles.class);
        typeProperties = mock(TypeProperties.class);
        
        when(typeLoader.loadConfiguration()).thenReturn(config);
        when(defaultIcon.getName()).thenReturn("ico_name");
                
        when(config.getDefaultIcon()).thenReturn(defaultIcon);
        when(config.getName()).thenReturn("name");
        when(config.getPropertyPageFiles()).thenReturn(propertyPageFiles);
        when(config.getTypeProperties()).thenReturn(typeProperties);
        when(typeProperties.getElement()).thenReturn(ImmutableList.of(createElement()));
        
        when(propertyPageFiles.getHelpID()).thenReturn("help_id");
                
        type = new NeType(typeLoader);
    }

    private Element createElement() {
        final Element element = new Element();
        element.setKey("CAPABILITIES");
        element.setContent("100111000100110101110110010000100000");
        return element;
    }
        
    @Test
    public void testName() {
        assertThat(type.getName(), is("name"));
    }
    
    @Test
    public void testDefaultIcon() {
        assertThat(type.getDefaultIcon(), is("ico_name"));
    }
    
    @Test
    public void testHelpID() {
        assertThat(type.getHelpID(), is("help_id"));
    }
    
    @Test
    public void testSupportedPropertyPageFiles() {
        assertThat(type.getSupportedPropertyPageFiles(), is(propertyPageFiles));
    }
    
    @Test
    public void testCapabilities() {
        assertThat(type.getCapabilities(), is(NeCapabilities.fromDbString("100111000100110101110110010000100000")));
    }

    @Test
    public void testCapabilitiesNotPresent() {
        when(typeProperties.getElement()).thenReturn(new ArrayList<Element>());

        assertThat(type.getCapabilities(), is(NeCapabilities.none()));
    }
}
