package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import com.ossnms.dcn_manager.core.jaxb.type.Element;
import com.ossnms.dcn_manager.core.jaxb.type.TypeProperties;
import org.junit.Test;

import static com.ossnms.dcn_manager.bicnet.client.service.configuration.WellKnownTypeProperties.CAPABILITIES;
import static java.util.Arrays.asList;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class WellKnownTypePropertiesTest {
    
    @Test public void shouldExtractContent() throws Exception {
        TypeProperties properties = type(element("CAPABILITIES", "01010101010"));

        assertThat(CAPABILITIES.from(properties), is(of("01010101010")));
    }

    @Test public void shouldNotFailOnNullContent() throws Exception {
        TypeProperties properties = type(element("CAPABILITIES", null));

        assertThat(CAPABILITIES.from(properties), is(empty()));
    }

    @Test public void shouldBeEmptyForMissingProperty() throws Exception {
        TypeProperties properties = type(element("wrong", "value"));

        assertThat(CAPABILITIES.from(properties), is(empty()));
    }

    @Test public void shouldNotFailOnNullKey() throws Exception {
        TypeProperties properties = type(element(null, null));

        assertThat(CAPABILITIES.from(properties), is(empty()));
    }

    @Test public void shouldNotFailOnEmptyProperties() throws Exception {
        assertThat(CAPABILITIES.from(type()), is(empty()));
    }


    private TypeProperties type(Element... elements) {
        TypeProperties properties = mock(TypeProperties.class);
        when(properties.getElement()).thenReturn(asList(elements));
        return properties;
    }

    private Element element(String key, String content) {
        final Element element = new Element();
        element.setKey(key);
        element.setContent(content);
        return element;
    }
}