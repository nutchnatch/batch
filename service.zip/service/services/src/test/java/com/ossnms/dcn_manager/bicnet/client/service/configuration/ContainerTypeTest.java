package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.containertype.Config;
import com.ossnms.dcn_manager.core.jaxb.type.DefaultIcon;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ContainerType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.TypeLoader;

public class ContainerTypeTest {

    private ContainerType containerType;
    
    private TypeLoader<Config> typeLoader;
    private Config config;
    private DefaultIcon defaultIcon;
    private PropertyPageFiles propertyPageFiles;
    
    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        typeLoader = mock(TypeLoader.class);
        config = mock(Config.class);
        defaultIcon = mock(DefaultIcon.class);
        propertyPageFiles = mock(PropertyPageFiles.class);
                
        when(typeLoader.loadConfiguration()).thenReturn(config);
        when(defaultIcon.getName()).thenReturn("ico_name");
                
        when(config.getDefaultIcon()).thenReturn(defaultIcon);
        when(config.getName()).thenReturn("name");
        when(config.getPropertyPageFiles()).thenReturn(propertyPageFiles);
        
        when(propertyPageFiles.getHelpID()).thenReturn("help_id");
                
        containerType = new ContainerType(typeLoader);
    }
        
    @Test
    public void testGetName() {
        assertThat(containerType.getName(), CoreMatchers.is("name"));
    }
    
    @Test
    public void testDefaultIcon() {
        assertThat(containerType.getDefaultIcon(), CoreMatchers.is("ico_name"));
    }
    
    @Test
    public void testHelpID() {
        assertThat(containerType.getHelpID(), CoreMatchers.is("help_id"));
    }
    
    @Test
    public void testSupportedPropertyPageFiles() {
        assertThat(containerType.getSupportedPropertyPageFiles(), CoreMatchers.is(propertyPageFiles));
    }
}
