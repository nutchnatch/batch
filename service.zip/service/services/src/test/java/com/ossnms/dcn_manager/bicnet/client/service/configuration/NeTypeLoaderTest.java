package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.net.URL;

import org.junit.Assert;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.netype.Config;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeTypeLoader;

public class NeTypeLoaderTest {
    private static final URL XML_URL = NeTypeLoaderTest.class.getClassLoader().getResource("dcn-manager/netype/NE-TEST-netype.xml");
    
    @Test
    public void testLoader() {
        final NeTypeLoader loader = new NeTypeLoader(XML_URL);
        final Config config = loader.loadConfiguration();
        
        Assert.assertNotNull(loader);
        Assert.assertNotNull(loader.loadConfiguration());
        Assert.assertNotNull(config.getName());
    }
}
