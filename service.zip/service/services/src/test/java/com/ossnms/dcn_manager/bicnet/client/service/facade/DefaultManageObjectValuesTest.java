package com.ossnms.dcn_manager.bicnet.client.service.facade;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import static org.junit.Assert.assertThat;

public class DefaultManageObjectValuesTest {

    @Test
    public void testNewBasicNeItem() {
        
        final INE ne = DefaultManageObjectValues.newBasicNeItem("type", "name", new EMIdItem(1), 0);
        
        assertThat(ne.getNeProxyType(), CoreMatchers.is("type"));
        assertThat(ne.getIdName(), CoreMatchers.is("name"));
        assertThat(ne.getAssociatedEm(), CoreMatchers.is((IEMId)new EMIdItem(1)));
    }
    
    @Test
    public void testNewBasicEmItem() {
        
        final IEM em = DefaultManageObjectValues.newBasicEmItem("type", "name", new MediatorIdItem(1));
        
        assertThat(em.getEmType(), CoreMatchers.is("type"));
        assertThat(em.getIdName(), CoreMatchers.is("name"));
        assertThat(em.getAssociatedMediator(), CoreMatchers.is((IMediatorId)new MediatorIdItem(1)));
    }
    
    @Test
    public void testNewBasicMediatorItem() {
        
        final IMediator mediator = DefaultManageObjectValues.newBasicMediatorItem("GM", "name");
        
        assertThat(mediator.getMediatorType(), CoreMatchers.is(MediatorType.GM));
        assertThat(mediator.getIdName(), CoreMatchers.is("name"));
    }
}
