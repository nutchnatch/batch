package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFile;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import org.junit.Before;
import org.junit.Test;

import java.net.URL;
import java.util.Optional;

import static java.util.Collections.singletonList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class PropertyPagesTest {
    private static final String NAME = "propertypage-TEST";
    private static final URL PAGE_1 = PropertyPagesTest.class.getClassLoader().getResource("dcn-manager/propertypages/propertypage-TEST.xml");

    private PropertyPages propertyPages;

    @Before public void setUp() throws Exception {
        propertyPages = new PropertyPages(singletonList(PAGE_1));
    }

    @Test public void get() throws Exception {
        final Optional<Page> page = propertyPages.get(NAME);

        assertThat(page.isPresent(), is(true));
        page.ifPresent(p -> {
            assertThat(p.getTitle(), is("NE Properties"));
            assertThat(p.getVersion(), is("5.0.0"));
        });
    }

    @Test public void getPages() throws Exception {
        final ImmutableMap<String, Page> pages = propertyPages.getPages();

        final Page page = pages.get(NAME);
        assertThat(page, notNullValue());
        assertThat(pages.size(), is(1));
    }

    @Test public void joinPages() throws Exception {
        PropertyPageFiles files = new PropertyPageFiles();
        PropertyPageFile file = new PropertyPageFile();
        file.setName(NAME);
        files.getPropertyPageFile().add(file);

        final Page page = propertyPages.joinPages(files);

        assertThat(page, notNullValue());
        assertThat(page.getTitle(), is("NE Properties"));
        assertThat(page.getVersion(), is("5.0.0"));
    }
}