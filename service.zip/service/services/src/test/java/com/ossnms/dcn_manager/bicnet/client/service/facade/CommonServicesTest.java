package com.ossnms.dcn_manager.bicnet.client.service.facade;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class CommonServicesTest {
    private CommonServices commonServices;

    @Before public void setUp() throws Exception {
        commonServices = new CommonServices();
    }

    @Test public void getIconManager() throws Exception {
        assertThat(commonServices.getIconManager(), notNullValue());
        assertThat(commonServices.getIconManager(), is(commonServices.getIconManager()));
    }

    @Test public void getSecureActionValidation() throws Exception {
        assertThat(commonServices.getSecureActionValidation(), notNullValue());
        assertThat(commonServices.getSecureActionValidation(), is(commonServices.getSecureActionValidation()));
    }

    @Test public void getLoggerManager() throws Exception {
        assertThat(commonServices.getLoggerManager(), notNullValue());
        assertThat(commonServices.getLoggerManager(), is(commonServices.getLoggerManager()));
    }

    @Test public void getMessageBox() throws Exception {
        assertThat(commonServices.getMessageBox(), notNullValue());
        assertThat(commonServices.getMessageBox(), is(commonServices.getMessageBox()));
    }

    @Test public void getStaticConfiguration() throws Exception {
        assertThat(commonServices.getStaticConfiguration(), notNullValue());
        assertThat(commonServices.getStaticConfiguration(), is(commonServices.getStaticConfiguration()));
    }

    @Test public void getFrameworkPluginHelper() throws Exception {
        assertThat(commonServices.getFrameworkPluginHelper(), notNullValue());
        assertThat(commonServices.getFrameworkPluginHelper(), is(commonServices.getFrameworkPluginHelper()));
    }

    @Test public void getDcnPluginHelper() throws Exception {
        assertThat(commonServices.getDcnPluginHelper(), notNullValue());
        assertThat(commonServices.getDcnPluginHelper(), is(commonServices.getDcnPluginHelper()));
    }

    @Test public void getBicnetServerFacade() throws Exception {
        assertThat(commonServices.getBicnetServerFacade(), notNullValue());
        assertThat(commonServices.getBicnetServerFacade(), is(commonServices.getBicnetServerFacade()));
    }
}