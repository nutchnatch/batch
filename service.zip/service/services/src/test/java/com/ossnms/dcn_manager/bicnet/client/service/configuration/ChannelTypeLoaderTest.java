package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.net.URL;

import org.junit.Assert;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.emtype.Config;


public class ChannelTypeLoaderTest {
    private static final URL XML_URL = ChannelTypeLoaderTest.class.getClassLoader().getResource("dcn-manager/emtype/EM-TEST-emtype.xml");
    
    @Test
    public void testLoader() {
        final ChannelTypeLoader loader = new ChannelTypeLoader(XML_URL);
        final Config config = loader.loadConfiguration();
        
        Assert.assertNotNull(loader);
        Assert.assertNotNull(loader.loadConfiguration());
        Assert.assertNotNull(config.getName());
    }
}
