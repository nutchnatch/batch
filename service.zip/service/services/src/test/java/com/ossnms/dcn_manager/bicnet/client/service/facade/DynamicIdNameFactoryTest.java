package com.ossnms.dcn_manager.bicnet.client.service.facade;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.NeRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.NeService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import net.sf.ehcache.Element;

import java.util.ArrayList;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DynamicIdNameFactoryTest {

    private BicnetServerFacade facade;
    private IEMObjectMgrFacade publicFacade;
    private NeService neService;
    private NeRepository repository;

    @Before
    public void setup() throws BcbException {
        facade = mock(BicnetServerFacade.class);
        publicFacade = Mockito.mock(IEMObjectMgrFacade.class);
        neService = Mockito.mock(NeService.class);

        when(facade.getDcnPublicServices()).thenReturn(publicFacade);
        when(facade.getNeService()).thenReturn(neService);
        
        repository = new NeRepository(facade, NeCacheManager.getInstance().cache());
        NeCacheManager.getInstance().cache().fetch(new ArrayList<Element>());
    }
    
    @After
    public void destroy() throws CacheException {
        NeCacheManager.getInstance().cache().clear();
    }

    @Test
    public void testNewName() throws RepositoryException {
        final String name = DynamicIdNameFactory.build(repository, "name");
        
        Assert.assertThat(name, is("name_1"));
    }
    
    @Test
    public void testExistsNewName() throws CacheException, RepositoryException {
        INE ne = DefaultManageObjectValues.newBasicNeItem("type", "name_1", new EMIdItem(1), 0);
        NeCacheManager.getInstance().cache().put(
                1, new FullNeData(ne, new NeInfo(ne.getId()), null));

        INE ine = DefaultManageObjectValues.newBasicNeItem("type", "name_2", new EMIdItem(1), 0);
        NeCacheManager.getInstance().cache().put(
                2, new FullNeData(ine, new NeInfo(ine.getId()), null));
        
        final String name = DynamicIdNameFactory.build(repository, "name");
        
        Assert.assertThat(name, is("name_3"));
    }
}
