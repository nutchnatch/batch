package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.net.URL;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.emtype.Config;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlFileLoader;


public class XmlFileLoaderTest {
    private static final URL XML_URL = XmlFileLoaderTest.class.getClassLoader().getResource("dcn-manager/emtype/EM-TEST-emtype.xml");
    private static final URL NO_FILE_FOUND = XmlFileLoaderTest.class.getClassLoader().getResource("XX");
    
    @Test
    public void testLoader() {
        final XmlFileLoader loader = new XmlFileLoader();
        final Config config = loader.loadConfiguration(Config.class, XML_URL, null);
        
        assertNotNull(loader);
        assertNotNull(config);
        assertNotNull(config.getName());
    }
    
    @Test
    public void testLoaderWithDefault() {
        final Config configDefault = new Config();
        final XmlFileLoader loader = new XmlFileLoader();
        final Config configLoaded = loader.loadConfiguration(Config.class, NO_FILE_FOUND, configDefault);
        
        assertNotNull(loader);
        assertNotNull(configLoaded);
        assertThat(configDefault, CoreMatchers.is(configLoaded));
    }
}
