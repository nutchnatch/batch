package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class XmlStaticTypesConfigurationTest {

    private XmlStaticTypesConfiguration configuration;

    @Before
    public void setup() {
        configuration = new XmlStaticTypesConfiguration();
    }
    
    @Test
    public void testNeTypes() {
        final NeTypes types = configuration.getNeTypes();        
        final NeType type = types.get("NE_TEST");
        
        assertFalse(types.isEmpty());
        assertNotNull(type);
    }
    
    @Test
    public void testEmTypes() {
        final ChannelTypes types = configuration.getChannelTypes();
        final ChannelType type = types.get("EM_TEST");
        
        assertFalse(types.isEmpty());
        assertNotNull(type);
    }
    
    @Test
    public void testMediatorTypes() {
        final MediatorTypes types = configuration.getMediatorTypes();        
        final MediatorType type = types.get("Mediator_TEST");
        
        assertFalse(types.isEmpty());
        assertNotNull(type);
    }
    
    @Test
    public void testContainerTypes() {
        final ContainerTypes types = configuration.getContainerTypes();        
        final ContainerType type = types.get("Container_TEST");
        
        assertFalse(types.isEmpty());
        assertNotNull(type);
    }
}
