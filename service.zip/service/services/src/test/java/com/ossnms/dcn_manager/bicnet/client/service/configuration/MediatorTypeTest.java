package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.core.jaxb.mediatortype.Config;
import com.ossnms.dcn_manager.core.jaxb.type.DefaultIcon;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.TypeLoader;

public class MediatorTypeTest {

    private MediatorType type;
    
    private TypeLoader<Config> typeLoader;
    private Config config;
    private DefaultIcon defaultIcon;
    private PropertyPageFiles propertyPageFiles;
    
    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        typeLoader = mock(TypeLoader.class);
        config = mock(Config.class);
        defaultIcon = mock(DefaultIcon.class);
        propertyPageFiles = mock(PropertyPageFiles.class);
                
        when(typeLoader.loadConfiguration()).thenReturn(config);
        when(defaultIcon.getName()).thenReturn("ico_name");
                
        when(config.getDefaultIcon()).thenReturn(defaultIcon);
        when(config.getName()).thenReturn("name");
        when(config.getPropertyPageFiles()).thenReturn(propertyPageFiles);
        
        when(propertyPageFiles.getHelpID()).thenReturn("help_id");
                
        type = new MediatorType(typeLoader);
    }
        
    @Test
    public void testGetName() {
        assertThat(type.getName(), CoreMatchers.is("name"));
    }
    
    @Test
    public void testDefaultIcon() {
        assertThat(type.getDefaultIcon(), CoreMatchers.is("ico_name"));
    }
    
    @Test
    public void testHelpID() {
        assertThat(type.getHelpID(), CoreMatchers.is("help_id"));
    }
    
    @Test
    public void testSupportedPropertyPageFiles() {
        assertThat(type.getSupportedPropertyPageFiles(), CoreMatchers.is(propertyPageFiles));
    }
}
