package com.ossnms.dcn_manager.bicnet.client.service.facade;

import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ContainerType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeType;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertThat;

public class StaticConfigurationSingletonTest {

    @Test
    public void testNeTypes() {
        final Optional<NeType> type = StaticConfigurationSingleton.getInstance().findNeType("NE_TEST");

        assertTrue(type.isPresent());
        assertThat(type.get().getName(), CoreMatchers.is("NE_TEST"));
    }

    @Test
    public void testEmTypes() {
        final Optional<ChannelType> type = StaticConfigurationSingleton.getInstance().findChannelType("EM_TEST");

        assertTrue(type.isPresent());
        assertThat(type.get().getName(), CoreMatchers.is("EM_TEST"));
    }

    @Test
    public void testMediatorTypes() {
        final Optional<MediatorType> type = StaticConfigurationSingleton.getInstance().findMediatorType("Mediator_TEST");

        assertTrue(type.isPresent());
        assertThat(type.get().getName(), CoreMatchers.is("Mediator_TEST"));
    }

    @Test
    public void testContainerTypes() {
        final Optional<ContainerType> type = StaticConfigurationSingleton.getInstance().findContainerType("Container_TEST");

        assertTrue(type.isPresent());
        assertThat(type.get().getName(), CoreMatchers.is("Container_TEST"));
    }
}
