package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import com.ossnms.dcn_manager.core.jaxb.type.Element;
import com.ossnms.dcn_manager.core.jaxb.type.TypeProperties;

import java.util.Objects;
import java.util.Optional;

enum WellKnownTypeProperties {
    CAPABILITIES("CAPABILITIES"),
    GUI_LABEL_LONG("GUI_LABEL_LONG"),
    GUI_LABEL_SHORT("GUI_LABEL_SHORT");

    private final String key;

    WellKnownTypeProperties(String key) {
        this.key = key;
    }

    Optional<String> from(TypeProperties typeProperties) {
        return typeProperties.getElement().stream()
                .filter(element -> Objects.equals(element.getKey(), key))
                .findAny()
                .map(Element::getContent);
    }
}
