package com.ossnms.dcn_manager.bicnet.client.service.facade;

import com.google.common.base.Joiner;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByName;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.Repository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Try create a unique IdName relative the {@link Repository} based on the object type name. 
 * 
 * Creation Pattern: {@code TYPE + '_' + SEQUENCE}
 * 
 * Examples:
 * <p><b>{@code MVM_12}</b></p>
 * <p><b>{@code 7090 M 3.x_12}</b></p>
 * 
 */
public final class DynamicIdNameFactory {

    private DynamicIdNameFactory() {
    }

    public static <K, V> String build(@Nonnull Repository<K, V> repository, @Nonnull String type) throws RepositoryException {
        Optional<V> ne = Optional.empty();

        int count = 1;
        String generatedIdName;

        do {
            generatedIdName = Joiner.on('_').join(type, count++);
            ne = ((SearchByName<V>) repository.queries()).findByIdName(generatedIdName);
        } while (ne.isPresent());

        return generatedIdName;
    }
}
