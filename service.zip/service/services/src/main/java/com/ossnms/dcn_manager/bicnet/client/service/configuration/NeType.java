package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapabilities;
import com.ossnms.dcn_manager.core.jaxb.netype.Config;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;

import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.service.configuration.WellKnownTypeProperties.CAPABILITIES;
import static com.ossnms.dcn_manager.bicnet.client.service.configuration.WellKnownTypeProperties.GUI_LABEL_SHORT;

/**
 * Provides the description of NE Type.
 */
public class NeType implements Type {

    private final Config configuration;
    
    /**
     * Creates a new object.
     * @param loader NE Type information loader.
     */
    NeType(TypeLoader<Config> loader) {
        configuration = loader.loadConfiguration();
    }

    @Override
    public String getName() {
        return configuration.getName();
    }

    @Override
    public String getDefaultIcon() {
        return configuration.getDefaultIcon().getName();
    }

    @Override
    public String getHelpID() {
        return configuration.getPropertyPageFiles().getHelpID();
    }

    @Override
    public PropertyPageFiles getSupportedPropertyPageFiles() {
        return configuration.getPropertyPageFiles();
    }

    public NeCapabilities getCapabilities() {
        return CAPABILITIES.from(configuration.getTypeProperties())
                .map(NeCapabilities::fromDbString)
                .orElse(NeCapabilities.none());
    }

    @Override public Optional<String> guiLabel() {
        return GUI_LABEL_SHORT.from(configuration.getTypeProperties());
    }
}
