package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.net.URL;

/**
 * Contains a list of EM Types loaded for a set of XML files.
 */
public class ChannelTypes extends Types<ChannelType> {

    /**
     * Creates a new map of EM Types.
     * @param neTypeUrls URLs to load NE Types from.
     */
    ChannelTypes(Iterable<URL> neTypeUrls) {
        super(
            new TypeBuilder<ChannelType>() {
                @Override
                public ChannelType build(URL sourceUrl) {
                    return new ChannelType(new ChannelTypeLoader(sourceUrl));
                }
            },
            neTypeUrls
        );
    }

}
