package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.net.URL;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.jaxb.mediatortype.Config;

/**
 * Loader for Mediator Type configuration files.
 */
public class MediatorTypeLoader extends XmlFileLoader implements TypeLoader<Config> {

    private final URL source;

    MediatorTypeLoader(@Nonnull URL source) {
        this.source = source;
    }

    @Override
    @Nonnull
    public Config loadConfiguration() {
        return loadConfiguration(Config.class, source, new Config());
    }
}