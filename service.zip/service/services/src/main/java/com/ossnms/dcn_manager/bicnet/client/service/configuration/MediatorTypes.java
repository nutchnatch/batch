package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.net.URL;

/**
 * Contains a list of Mediator Types loaded for a set of XML files.
 */
public class MediatorTypes extends Types<MediatorType> {

    /**
     * Creates a new map of EM Types.
     * @param propertyPages All property pages known to EM/NE.
     * @param neTypes All NE Types known to EM/NE.
     * @param neTypeUrls URLs to load NE Types from.
     */
    MediatorTypes(Iterable<URL> mediatorTypeUrls) {
        super(
            new TypeBuilder<MediatorType>() {
                @Override
                public MediatorType build(URL sourceUrl) {
                    return new MediatorType(new MediatorTypeLoader(sourceUrl));
                }
            },
            mediatorTypeUrls
        );
    }
}
