package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import static com.google.common.base.Predicates.notNull;
import static com.google.common.collect.Iterables.filter;
import static com.google.common.collect.Iterables.transform;

import java.io.IOException;
import java.net.URL;
import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import org.reflections.Reflections;
import org.reflections.scanners.ResourcesScanner;
import org.reflections.util.ConfigurationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Function;
import com.google.common.base.Predicate;

/**
 * Static DCN configuration loaded from XML files.
 */
public final class XmlStaticTypesConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(XmlStaticTypesConfiguration.class);
    private static final String RESOURCES_RELATIVE_FOLDER = "dcn-manager/";

    private final NeTypes neTypes;
    private final ChannelTypes channelTypes;
    private final MediatorTypes mediatorTypes;
    private final ContainerTypes containerTypes;

    /**
     * Creates a new object, loading all static configuration XML files found in a
     * collection of resource URLs.
     * @param resourceURLs The resource URLs to scan for static configuration XML files.
     */
    public XmlStaticTypesConfiguration() {
        final Collection<URL> resourceURLs;
        
        try {
            resourceURLs = Collections.list(XmlStaticTypesConfiguration.class.getClassLoader().getResources(RESOURCES_RELATIVE_FOLDER));
        } catch (final IOException e) {
            throw new UnsupportedOperationException(e);
        }
        
        neTypes = new NeTypes(getResources(resourceURLs, ".*netype.*"));
        channelTypes = new ChannelTypes(getResources(resourceURLs, ".*emtype.*"));
        mediatorTypes = new MediatorTypes(getResources(resourceURLs, ".*mediatortype.*"));
        containerTypes = new ContainerTypes(getResources(resourceURLs, ".*containertype.*"));
    }

    /** @return All NE Type metadata found. */
    public NeTypes getNeTypes() {
        return neTypes;
    }

    /** @return All EM Type metadata found */
    public ChannelTypes getChannelTypes() {
        return channelTypes;
    }

    /** @return All Mediator Type metadata found */
    public MediatorTypes getMediatorTypes() {
        return mediatorTypes;
    }
    
    /** @return All Container Type metadata found */
    public ContainerTypes getContainerTypes() {
        return containerTypes;
    }

    private Iterable<URL> getResources(Collection<URL> resourceURLs, String pattern) {
        final Reflections reflections = new Reflections(
                new ConfigurationBuilder()
                    .setUrls(resourceURLs)
                    .setScanners(new ResourcesScanner())
                    .filterInputsBy(new ContainsPattern(pattern))
                );
        final Set<String> resources = reflections.getResources(Pattern.compile(".*\\.xml"));
        return filter(transform(resources, new ResourceUrlFinder()), notNull());
    }

    private static final class ContainsPattern implements Predicate<String> {
        private final Pattern pattern;

        public ContainsPattern(String string) {
            pattern = Pattern.compile(string);
        }

        @Override
        public boolean apply(String input) {
            LOGGER.trace("Verifying input {}", input);
            return pattern.matcher(input).matches();
        }
    }

    private static final class ResourceUrlFinder implements Function<String, URL> {

        private static final ClassLoader CLASSLOADER = XmlStaticTypesConfiguration.class.getClassLoader();

        @Override
        public URL apply(@Nonnull String resource) {
            LOGGER.debug("Looking up XML configuration resource '{}' in the class path.", resource);
            final URL url = CLASSLOADER.getResource(resource);
            return url != null ? url : CLASSLOADER.getResource(RESOURCES_RELATIVE_FOLDER + resource);
        }
    }
}
