package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.net.URL;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.jaxb.emtype.Config;

/**
 * Loader for Channel Type configuration files.
 */
class ChannelTypeLoader extends XmlFileLoader implements TypeLoader<Config> {

    private final URL source;

    ChannelTypeLoader(@Nonnull URL source) {
        this.source = source;
    }

    @Override
    @Nonnull
    public Config loadConfiguration() {
        return loadConfiguration(Config.class, source, new Config());
    }

}
