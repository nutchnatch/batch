package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import com.ossnms.dcn_manager.core.jaxb.propertypage.Page;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFile;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import org.apache.commons.io.FilenameUtils;

import javax.annotation.Nonnull;
import java.net.URL;
import java.util.Optional;

/**
 * Contains a list of PropertyPages Types loaded for a set of XML files.
 */
public class PropertyPages {

    private final ImmutableMap<String, Page> pages; 
    
    /**
     * Loads PropertyPages from URLs
     * @param propertyPageUrls
     */
    PropertyPages(Iterable<URL> propertyPageUrls) {
        final Builder<String, Page>  builder = ImmutableMap.builder();
        
        for (final URL url : propertyPageUrls) {
            builder.put(FilenameUtils.getBaseName(url.getPath()), new PropertyPageLoader(url).loadConfiguration());
        }
        
        pages = builder.build();
    }

    /**
     * @param fileName
     * @return The Page object when present.
     */
    public Optional<Page> get(@Nonnull final String fileName) {
        return Optional.ofNullable(pages.get(fileName));
    }
    
    /**
     * @return The loaded propertyPages
     */
    public ImmutableMap<String, Page> getPages() {
        return pages;
    }
    
    /**
     * @param propertyPageFiles Load and join the property page list.
     * @return
     */
    @Nonnull
    public Page joinPages(@Nonnull final PropertyPageFiles propertyPageFiles) {
        final Page pageJoined = new Page();
        
        for (final PropertyPageFile pageFile : propertyPageFiles.getPropertyPageFile()) {
            final Page page = get(pageFile.getName()).get();
            
            clonePage(pageJoined, page);
        }
                        
        return pageJoined;
    }

    private void clonePage(final Page pageJoined, final Page nextPage) {
        pageJoined.getGlobalVariable().addAll(nextPage.getGlobalVariable());
        pageJoined.getStatic().addAll(nextPage.getStatic());
        pageJoined.getTabbedPane().addAll(nextPage.getTabbedPane());
        
        pageJoined.setTitle(nextPage.getTitle());
        pageJoined.setVersion(nextPage.getVersion());
    }
    
    private static class PropertyPageLoader extends XmlFileLoader implements TypeLoader<Page> {

        private final URL source;

        PropertyPageLoader(@Nonnull URL source) {
            this.source = source;
        }

        @Override
        @Nonnull
        public Page loadConfiguration() {
            return loadConfiguration(Page.class, source, new Page());
        }
    }
}
