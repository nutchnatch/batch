package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import com.ossnms.dcn_manager.core.jaxb.containertype.Config;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.service.configuration.WellKnownTypeProperties.GUI_LABEL_SHORT;

/**
 * Static Container configuration, loaded from a XML file.
 */
public class ContainerType implements Type {

    private final Config configuration;

    /**
     * Creates a new object.
     * @param loader Container Type information loader.
     */
    ContainerType(@Nonnull TypeLoader<Config> loader) {
        configuration = loader.loadConfiguration();
    }

    @Override
    public String getName() {
        return configuration.getName();
    }

    @Override
    public String getDefaultIcon() {
        return configuration.getDefaultIcon().getName();
    }
    
    @Override
    public String getHelpID() {
        return configuration.getPropertyPageFiles().getHelpID();
    }

    @Override
    public PropertyPageFiles getSupportedPropertyPageFiles() {
        return configuration.getPropertyPageFiles();
    }

    @Override public Optional<String> guiLabel() {
        return GUI_LABEL_SHORT.from(configuration.getTypeProperties());
    }
}
