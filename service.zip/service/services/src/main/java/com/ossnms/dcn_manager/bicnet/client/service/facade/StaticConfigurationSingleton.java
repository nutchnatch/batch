package com.ossnms.dcn_manager.bicnet.client.service.facade;

import com.ossnms.dcn_manager.bicnet.client.service.configuration.ChannelType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.ContainerType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.MediatorType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.NeType;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.StaticConfiguration;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.XmlStaticTypesConfiguration;

import javax.annotation.Nonnull;
import java.util.Optional;

import static java.util.Optional.ofNullable;

/**
 * The static configuration to be loaded at the EM/NE plug-in startup. 
 */
public final class StaticConfigurationSingleton implements StaticConfiguration {
    
    private static final StaticConfiguration INSTANCE = new StaticConfigurationSingleton();

    private final XmlStaticTypesConfiguration configuration;

    private StaticConfigurationSingleton() {
        configuration = new XmlStaticTypesConfiguration();
    }

    /**
     * @return The Singleton instance.
     */
    @Nonnull
    public static StaticConfiguration getInstance() {
        return INSTANCE;
    }
    
    /* 
     * @see com.ossnms.dcn_manager.bicnet.client.service.facade.ImmutableRepository#findNeType(java.lang.String)
     */
    @Override
    @Nonnull
    public Optional<NeType> findNeType(@Nonnull final String type) {
        return ofNullable(configuration.getNeTypes().get(type));
    }
    
    /* 
     * @see com.ossnms.dcn_manager.bicnet.client.service.facade.ImmutableRepository#findChannelType(java.lang.String)
     */
    @Override
    @Nonnull
    public Optional<ChannelType> findChannelType(@Nonnull final String type) {
        return ofNullable(configuration.getChannelTypes().get(type));
    }
    
    /* 
     * @see com.ossnms.dcn_manager.bicnet.client.service.facade.ImmutableRepository#findMediatorType(java.lang.String)
     */
    @Override
    @Nonnull
    public Optional<MediatorType> findMediatorType(@Nonnull final String type) {
        return ofNullable(configuration.getMediatorTypes().get(type));
    }
    
    /* 
     * @see com.ossnms.dcn_manager.bicnet.client.service.facade.ImmutableRepository#findContainerType(java.lang.String)
     */
    @Override
    @Nonnull
    public Optional<ContainerType> findContainerType(@Nonnull final String type) {
        return ofNullable(configuration.getContainerTypes().get(type));
    }
    
    /*
     * @see com.ossnms.bicnet.emne.client.service.configuration.StaticConfiguration#findMediatorTypeByChannel(java.lang.String)
     */
    @Override
    public Optional<MediatorType> findMediatorTypeByChannel(@Nonnull final String channelName) {
        return configuration.getMediatorTypes().values().stream()
                .filter(input -> input.getSupportedChannels().getChannel().contains(channelName))
                .findFirst();
    }
}
