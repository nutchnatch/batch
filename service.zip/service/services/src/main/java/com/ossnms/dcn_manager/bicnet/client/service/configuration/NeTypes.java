package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.net.URL;

/**
 * Contains a list of NE Types loaded for a set of XML files.
 */
public class NeTypes extends Types<NeType> {

    /**
     * Creates a new map of NE Types.
     * @param propertyPages All property pages known to EM/NE.
     * @param neTypeUrls URLs to load NE Types from.
     */
    NeTypes(Iterable<URL> neTypeUrls) {
        super(
            new TypeBuilder<NeType>() {
                @Override
                public NeType build(URL sourceUrl) {
                    return new NeType(new NeTypeLoader(sourceUrl));
                }
            },
            neTypeUrls
        );
    }

}
