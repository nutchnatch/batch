package com.ossnms.dcn_manager.bicnet.client.service.help;

public enum DefaultHelpIds {

    EXPORT_VIEW(1),
    IMPORT_VIEW(2),
    DCN_MANAGEMENT_MAIN_VIEW(12333),
    STATE_SUMMARY_VIEW(12334),
    NEW_CHANNEL(12335),
    NEW_NE(12336),
    TREE_NODE_FINDER(12337),
    GENERAL_PROPERTY_PAGE(12338),
    NEW_CONTAINER(12344),
    NEW_MEDIATOR(12345),
    NEW_NE_UNDER_CONTAINER(12346),
    CONTAINER_ASSIGNMENT(12347),
    DCN_TABLE_VIEW(12348);

    private final int value;

    DefaultHelpIds(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
