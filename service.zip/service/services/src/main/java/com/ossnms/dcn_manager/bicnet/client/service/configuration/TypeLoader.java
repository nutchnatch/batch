package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import javax.annotation.Nonnull;

/**
 * Describes a class that knows how to load a block of configuration settings
 * rooted on a specific type.
 * @param <T> The configuration root type.
 */
interface TypeLoader<T> {

    /**
     * @return An instance of the configuration root type with any settings
     * found, or with default/empty values as appropriate.
     */
    @Nonnull
    T loadConfiguration();

}