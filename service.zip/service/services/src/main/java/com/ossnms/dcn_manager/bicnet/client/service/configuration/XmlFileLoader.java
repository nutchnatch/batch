package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.net.URL;

import javax.annotation.Nonnull;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Loader for XML configuration files that uses bound with JAXB.
 */
public class XmlFileLoader {

    private static final Logger LOGGER = LoggerFactory.getLogger(XmlFileLoader.class);

    @Nonnull
    public <T> T loadConfiguration(Class<T> configurationClass, @Nonnull URL source, @Nonnull T defaultValue) {
        try {
            final Unmarshaller unmarshaller = JAXBContext.newInstance(configurationClass).createUnmarshaller();
            return configurationClass.cast(unmarshaller.unmarshal(source));
        } catch (final JAXBException | IllegalArgumentException e) {
            LOGGER.warn("Failed to unmarshal {}. {}", source, e);
        }
        return defaultValue;
    }
}
