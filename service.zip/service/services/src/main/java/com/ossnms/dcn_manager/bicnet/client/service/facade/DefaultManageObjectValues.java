package com.ossnms.dcn_manager.bicnet.client.service.facade;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Creates ManageObjects instances with basic values.
 */
public final class DefaultManageObjectValues {

    private static final int UNSIGNED_ID = 0;

    private DefaultManageObjectValues() {
    }

    public static FullNeData newDummyFullNeData(@Nonnull final FullNeData fullNeData, @Nonnull final String dummyName) {
        return new FullNeData(
                newBasicNeItem(
                        fullNeData.getNe().getNeProxyType(),
                        dummyName,
                        fullNeData.getNe().getAssociatedEm(),
                        fullNeData.getNe().getAssociatedSystemContainerId()),
                new NeInfo(UNSIGNED_ID),
                new ScsSynchronizationState(UNSIGNED_ID, ScsSyncState.OUT_OF_SYNC));
    }

    public static FullNeData newDummyFullNeData(@Nonnull final String type, @Nonnull final String name, int channelId, Optional<Integer> systemId) {

        return new FullNeData(
                newBasicNeItem(type, name, new EMIdItem(channelId), systemId.orElse(UNSIGNED_ID)),
                new NeInfo(UNSIGNED_ID),
                new ScsSynchronizationState(UNSIGNED_ID, ScsSyncState.OUT_OF_SYNC));
    }

    /**
     * Creates a basic #NEItem instance.
     */
    @Nonnull
    public static INE newBasicNeItem(@Nonnull final String type, @Nonnull final String name, @Nonnull final IEMId em, int systemId) {
        final INE ne = new NEItem();

        ne.setIdName(name);
        ne.setAssociatedEm(em);
        ne.setNeProxyType(type);
        ne.setAssociatedSystemContainerId(systemId);

        return ne;
    }

    /**
     * Creates a basic #EMItem instance.
     */
    @Nonnull
    public static IEM newBasicEmItem(@Nonnull final String type, @Nonnull final String name, @Nonnull final IMediatorId mediatorId) {
        final IEM em = new EMItem();

        em.setIdName(name);
        em.setEmType(type);
        em.setAssociatedMediator(mediatorId);

        return em;
    }

    /**
     * Creates a basic #MediatorItem instance.
     */
    @Nonnull
    public static IMediator newBasicMediatorItem(@Nonnull final String type, @Nonnull final String name) {
        final IMediator mediator = new MediatorItem();

        mediator.setIdName(name);
        mediator.setMediatorType(MediatorType.fromName(type));

        return mediator;
    }

    /**
     * Creates a basic #GenericContainerItem instance.
     */
    @Nonnull
    public static IGenericContainer newBasicNeContainerItem(@Nonnull final String name, @Nonnull
            Integer containerId) {
        final IGenericContainer neContainer = new GenericContainerItem();

        neContainer.setIdName(name);
        neContainer.setParentId(containerId);

        return neContainer;
    }

    /**
     * Creates a basic #SystemContainerItem instance.
     */
    @Nonnull
    public static ISystemContainer newBasicSystemContainerItem(@Nonnull final String name) {
        final ISystemContainer systemContainer = new SystemContainerItem();

        systemContainer.setIdName(name);

        return systemContainer;
    }
}
