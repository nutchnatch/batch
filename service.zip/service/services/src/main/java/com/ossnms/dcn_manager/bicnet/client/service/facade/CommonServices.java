package com.ossnms.dcn_manager.bicnet.client.service.facade;

import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacadeSingleton;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.logger.LoggerManager;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.security.SecureActionValidation;
import com.ossnms.dcn_manager.bicnet.client.api.view.MessageBox;
import com.ossnms.dcn_manager.bicnet.client.service.configuration.StaticConfiguration;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;

import javax.annotation.Nonnull;

/**
 * Lazy initialization of the all common services needed through DCN Manager Plug-in.
 */
public class CommonServices {
    private IconManager iconManager;
    private LoggerManager loggerManager;
    private MessageBox messageBox;

    @Nonnull public IconManager getIconManager() {
        if (null == iconManager) {
            iconManager = new IconManager();
        }
        return iconManager;
    }

    @Nonnull public SecureActionValidation getSecureActionValidation() {
        return SecureActionValidation.getInstance(getDcnPluginHelper());
    }

    @Nonnull public LoggerManager getLoggerManager() {
        if (null == loggerManager) {
            loggerManager = new LoggerManager(getDcnPluginHelper().getCfPluginSite());
        }
        return loggerManager;
    }

    @Nonnull public MessageBox getMessageBox() {
        if (null == messageBox) {
            messageBox = new MessageBox();
        }
        return messageBox;
    }

    @Nonnull public StaticConfiguration getStaticConfiguration() {
        return StaticConfigurationSingleton.getInstance();
    }

    @Nonnull public FrameworkPluginHelper getFrameworkPluginHelper() {
        return DcnPluginHelperSingleton.getInstance();
    }

    @Nonnull public DcnPluginHelper getDcnPluginHelper() {
        return DcnPluginHelperSingleton.getInstance();
    }

    @Nonnull public BicnetServerFacade getBicnetServerFacade() {
        return BicnetServerFacadeSingleton.getInstance();
    }
}
