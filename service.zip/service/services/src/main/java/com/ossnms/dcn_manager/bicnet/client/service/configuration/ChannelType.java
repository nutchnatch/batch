package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import com.ossnms.dcn_manager.core.jaxb.emtype.Config;
import com.ossnms.dcn_manager.core.jaxb.emtype.SupportedNeType;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.service.configuration.WellKnownTypeProperties.GUI_LABEL_SHORT;
import static java.util.stream.Collectors.toList;

public class ChannelType implements Type {

    private final Config configuration;

    /**
     * Creates a new object.
     * @param loader EM Type information loader.
     */
    ChannelType(@Nonnull TypeLoader<Config> loader) {
        configuration = loader.loadConfiguration();
    }

    @Override
    public String getName() {
        return configuration.getName();
    }

    @Override
    public String getDefaultIcon() {
        return configuration.getDefaultIcon().getName();
    }

    @Override
    public String getHelpID() {
        return configuration.getPropertyPageFiles().getHelpID();
    }
    
    @Override
    public PropertyPageFiles getSupportedPropertyPageFiles() {
        return configuration.getPropertyPageFiles();
    }

    /**
     * @return True if the Channel supports creation of new NEs by operator.
     */
    public boolean supportsNeCreation() {
        return configuration.isSupportsNeCreation();
    }

    public Collection<String> getSupportedNeTypes() {
        return configuration.getSupportedNeTypes().getSupportedNeType()
                .stream()
                .map(SupportedNeType::getName)
                .collect(toList());
    }
    
    @Override public Optional<String> guiLabel() {
        return GUI_LABEL_SHORT.from(configuration.getTypeProperties());
    }
}
