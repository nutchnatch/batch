package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import com.ossnms.dcn_manager.core.jaxb.mediatortype.Config;
import com.ossnms.dcn_manager.core.jaxb.mediatortype.SupportedChannels;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.service.configuration.WellKnownTypeProperties.GUI_LABEL_SHORT;

/**
 * Static Mediator configuration, loaded from a XML file.
 */
public class MediatorType implements Type {

    private final Config configuration;

    /**
     * Creates a new object.
     *
     * @param loader Mediator Type information loader.
     */
    MediatorType(@Nonnull final TypeLoader<Config> loader) {
        configuration = loader.loadConfiguration();
    }

    @Override
    public String getName() {
        return configuration.getName();
    }

    @Override
    public String getDefaultIcon() {
        return configuration.getDefaultIcon().getName();
    }

    @Override
    public String getHelpID() {
        return configuration.getPropertyPageFiles().getHelpID();
    }

    @Override
    public PropertyPageFiles getSupportedPropertyPageFiles() {
        return configuration.getPropertyPageFiles();
    }

    public SupportedChannels getSupportedChannels() {
        return configuration.getSupportedChannels();
    }

    public Boolean isAllowManyOnSameHost() {
        return configuration.isAllowManyOnSameHost();
    }

    public Boolean supportsHotStandby() {
        return configuration.isSupportsHotStandby();
    }

    @Override public Optional<String> guiLabel() {
        return GUI_LABEL_SHORT.from(configuration.getTypeProperties());
    }
}
