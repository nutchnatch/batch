package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import static com.google.common.base.Strings.isNullOrEmpty;

import java.net.URL;
import java.util.Map;

import javax.annotation.Nonnull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ForwardingMap;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;

/**
 * Holds an immutable map of Types, built and loaded from a number of files.
 * Types without names are ignored.
 * @param <T> The actual Type.
 */
abstract class Types<T extends Type> extends ForwardingMap<String, T>  {

    private static final Logger LOGGER = LoggerFactory.getLogger(Types.class);

    private final Map<String, T> types;

    /**
     * Creates a new object. Types that do not have names will be ignored.
     * @param typeBuilder The class that knows how to build instances of T.
     * @param neTypeUrls URLs representing the resources that will be used to build
     * instances of T.
     */
    protected Types(TypeBuilder<T> typeBuilder, Iterable<URL> neTypeUrls) {
        final Builder<String, T> builder = ImmutableMap.<String, T>builder();
        for (final URL url : neTypeUrls) {
            final T type = typeBuilder.build(url);
            final String typeName = type.getName();
            if (!isNullOrEmpty(typeName)) {
                builder.put(typeName, type);
            } else {
                LOGGER.warn("Type for {} is being discarded because it does not have a name.", url);
            }
        }
        types = builder.build();
    }

    @Override
    protected Map<String, T> delegate() {
        return types;
    }

    /**
     * Describes a class that knows how to build an instance of Type
     * based on the contents of a resource described by an URL.
     *
     * @param <T> The actual Type.
     */
    protected interface TypeBuilder<T extends Type> {

        /**
         * Builds an instance of Type.
         * @param The URL that describes the resource containing the information
         * necessary to build a Type.
         * @return An instance of Type.
         */
        @Nonnull
        T build(@Nonnull URL sourceUrl);
    }
}
