package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.util.Optional;

/**
 * Interface to work with the configuration Types
 * 
 * @see NeType
 * @see ChannelType
 * @see MediatorType
 * @see ContainerType
 */
public interface StaticConfiguration {

    /**
     * Gets the NeType.
     * 
     * @param type
     * @return
     */
    Optional<NeType> findNeType(String type);

    /**
     * Gets the Channel type.
     * 
     * @param type
     * @return
     */
    Optional<ChannelType> findChannelType(String type);

    /**
     * Gets the MEDIATOR type.
     * @param type
     * @return
     */
    Optional<MediatorType> findMediatorType(String type);
    
    /**
     * Gets the Container type.
     * @param type
     * @return
     */
    Optional<ContainerType> findContainerType(String type);
    
    /**
     * Gets the MEDIATOR by supported channel type name
     * 
     * @param channelTypeName
     * @return
     */
    Optional<MediatorType> findMediatorTypeByChannel(String channelTypeName);
}
