package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;

import java.util.Optional;

/**
 * Generic type of the DCN configuration. 
 */
public interface Type {

    /** @return The Type name. */
    String getName();
    
    /** @return The Help Id associated with the TNMS on-line Help. */
    String getHelpID();
    
    /** @return The Default network icon. */
    String getDefaultIcon();
    
    /** @return The PropertyPages file names. */
    PropertyPageFiles getSupportedPropertyPageFiles();

    /** @return The GUI Label for current type */
    Optional<String> guiLabel();
}
