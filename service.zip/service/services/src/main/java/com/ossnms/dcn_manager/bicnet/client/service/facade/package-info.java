/**
 * Facade to exposes the commons services for the EM/NE Plug-in.
 */
package com.ossnms.dcn_manager.bicnet.client.service.facade;