package com.ossnms.dcn_manager.bicnet.client.service.configuration;

import java.net.URL;

/**
 * Contains a list of Container Types loaded for a set of XML files.
 */
public class ContainerTypes extends Types<ContainerType> {

    /**
     * Creates a new map of Container Types.
     * @param propertyPages All property pages known to DCN Manager.
     * @param neTypes All NE Types known to DCN Manager.
     * @param neTypeUrls URLs to load NE Types from.
     */
    ContainerTypes(Iterable<URL> containerTypeUrls) {
        super(
            new TypeBuilder<ContainerType>() {
                @Override
                public ContainerType build(URL sourceUrl) {
                    return new ContainerType(new ContainerTypeLoader(sourceUrl));
                }
            },
            containerTypeUrls
        );
    }
}
