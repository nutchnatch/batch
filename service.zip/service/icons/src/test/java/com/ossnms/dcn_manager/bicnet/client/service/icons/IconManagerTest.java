package com.ossnms.dcn_manager.bicnet.client.service.icons;

import com.ossnms.bicnet.bcb.facade.common.IconPairIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.resources.ResourcesIconFactory.NetworkIcon;
import com.ossnms.tools.jfx.JfxUtils;
import org.junit.Test;

import org.junit.Assert;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class IconManagerTest {

    private final IconManager iconManager = new IconManager();
    
    private final INE ne;
    private final IEM em;
    private final IMediator mediator;
    
    public IconManagerTest() {
        this.ne = getNe();
        this.em = getEm();
        this.mediator = getMediator();
    }
                
    @Test
    public void testFindNEIcon() throws Exception {
       final ImageIcon icon = iconManager.findNetworkIcon(ne, JfxUtils.DEFAULT_ICON_SIZE).get();
       
       assertThat(icon, is((ImageIcon)ResourcesIconFactory.getNetworkIcon(NetworkIcon.NE_hit7300, JfxUtils.DEFAULT_ICON_SIZE)));
    }
    
    @Test
    public void testFindEMIcon() throws Exception {
       final ImageIcon icon = iconManager.findNetworkIcon(em, JfxUtils.DEFAULT_ICON_SIZE).get();
       
       assertThat(icon, is((ImageIcon)ResourcesIconFactory.getNetworkIcon(NetworkIcon.EM_GM, JfxUtils.DEFAULT_ICON_SIZE)));
    }
    
    @Test
    public void testFindMediatorIcon() throws Exception {
       final ImageIcon icon = iconManager.findNetworkIcon(mediator, JfxUtils.DEFAULT_ICON_SIZE).get();
       
       assertThat(icon, is((ImageIcon)ResourcesIconFactory.getNetworkIcon(NetworkIcon.MEDIATOR, JfxUtils.DEFAULT_ICON_SIZE)));
    }
    
    @Test
    public void testFindNeOverlayIconCommission16() throws Exception {       
       ne.setCommissioningStatus(CommissioningStatusSummary.PARTIALLY_COMMISSIONED);
       
       final Icon icon = iconManager.findNeOverlayIcon(ne, JfxUtils.DEFAULT_ICON_SIZE).orElse(null);
       
       Assert.assertNotNull(icon);
    }
    
    @Test
    public void testFindNeOverlayIconCommission32() throws Exception {       
       ne.setCommissioningStatus(CommissioningStatusSummary.PARTIALLY_COMMISSIONED);
       
       final Icon icon = iconManager.findNeOverlayIcon(ne, JfxUtils.EXTENDED_ICON_SIZE).orElse(null);
       
       Assert.assertNotNull(icon);
    }
    
    @Test
    public void testFindNeOverlayIconNotCommission16() throws Exception {       
       ne.setCommissioningStatus(CommissioningStatusSummary.NOT_COMMISSIONED);
       
       final Icon icon = iconManager.findNeOverlayIcon(ne, JfxUtils.DEFAULT_ICON_SIZE).orElse(null);
       
       Assert.assertNotNull(icon);
    }
    
    @Test
    public void testFindNeOverlayIconNotCommission32() throws Exception {       
       ne.setCommissioningStatus(CommissioningStatusSummary.NOT_COMMISSIONED);
       
       final Icon icon = iconManager.findNeOverlayIcon(ne, JfxUtils.EXTENDED_ICON_SIZE).orElse(null);
       
       Assert.assertNotNull(icon);
    }

    @Test
    public void testFindNeOverlayIconIdle() throws Exception {       
       ne.setOperationalState(OperationalState.DISABLED);
       
       final Icon icon = iconManager.findNeOverlayIcon(ne, JfxUtils.DEFAULT_ICON_SIZE).orElse(null);
       
       Assert.assertNotNull(icon);
    }

    @Test
    public void testFindNeOverlayIconIdle32() throws Exception {       
       ne.setOperationalState(OperationalState.DISABLED);
       
       final Icon icon = iconManager.findNeOverlayIcon(ne, JfxUtils.EXTENDED_ICON_SIZE).orElse(null);
       
       Assert.assertNotNull(icon);
    }

    private INE getNe() {
        final INE ne = new NEItem();        
        ne.setId(1);
        ne.setIconIdId(IconsType.NE_TL7100.key());
        
        final IconPairIdItem id = new IconPairIdItem();
        id.setId(IconsType.NE_TL7100.key());
        id.setContext(BiCNetComponentType.DCN_MANAGER);
        
        ne.setIconId(id);
        
        return ne;
    }
    
    private IEM getEm() {
        final IEM em = new EMItem();
        em.setId(1);
        em.setIconIdId(IconsType.EM_GM.key());
        
        final IconPairIdItem id = new IconPairIdItem();
        id.setId(IconsType.EM_GM.key());
        id.setContext(BiCNetComponentType.DCN_MANAGER);
        
        em.setIconId(id);
        
        return em;
    }
    
    private IMediator getMediator() {
        final IMediator mediator = new MediatorItem();
        mediator.setId(1);
        mediator.setIconIdId(IconsType.MEDIATOR_MVM.key());
        
        final IconPairIdItem id = new IconPairIdItem();
        id.setId(IconsType.MEDIATOR_MVM.key());
        id.setContext(BiCNetComponentType.DCN_MANAGER);
        
        mediator.setIconId(id);
        
        return mediator;
    }
}
