package com.ossnms.dcn_manager.bicnet.client.service.icons.state;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class EventForwardingStateIconTest {
    
    @Test
    public void testStates() {
        assertThat(EventForwardingStateIcon.MAINTENANCE, is(EventForwardingStateIcon.of(EnableSwitch.DISABLED).get()));
        
        assertFalse(EventForwardingStateIcon.of(null).isPresent());
        assertFalse(EventForwardingStateIcon.of(EnableSwitch.ENABLED).isPresent());        
    }
}
