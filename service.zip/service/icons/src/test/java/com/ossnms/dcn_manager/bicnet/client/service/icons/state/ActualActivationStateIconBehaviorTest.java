package com.ossnms.dcn_manager.bicnet.client.service.icons.state;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import org.junit.Test;

import javax.swing.Icon;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ActualActivationStateIconBehaviorTest {

    @Test
    public void testStateIconOfActive() {
        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(GuiActualActivationState.ACTIVE);
        assertThat(CommunicationStateIcon.ACTIVE.icon(), is(icon));
    }

    @Test
    public void testStateIconOfInactive() {
        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(GuiActualActivationState.INACTIVE);
        assertThat(CommunicationStateIcon.INACTIVE.icon(), is(icon));
    }

    @Test
    public void testStateIconOfFailed() {
        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(GuiActualActivationState.FAILED);
        assertThat(CommunicationStateIcon.FAILED.icon(), is(icon));
    }

    @Test
    public void testStateIconOfActivating() {
        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(GuiActualActivationState.ACTIVATING);
        assertThat(CommunicationStateIcon.ACTIVATING.icon(), is(icon));
    }

    @Test
    public void testStateIconOfDeactivating() {
        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(GuiActualActivationState.DEACTIVATING);
        assertThat(CommunicationStateIcon.DEACTIVATING.icon(), is(icon));
    }

    @Test
    public void testNeInactive() {
        final FullNeData ne = getNe();
        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.INACTIVE);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(CommunicationStateIcon.INACTIVE.icon(), is(icon));
    }

    @Test
    public void testNeFailed() {
        final FullNeData ne = getNe();
        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.FAILED);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(CommunicationStateIcon.FAILED.icon(), is(icon));
    }

    @Test
    public void testNeActivating() {
        final FullNeData ne = getNe();
        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVATING);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(CommunicationStateIcon.ACTIVATING.icon(), is(icon));
    }

    @Test
    public void testNeDeactivating() {
        final FullNeData ne = getNe();
        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.DEACTIVATING);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(CommunicationStateIcon.DEACTIVATING.icon(), is(icon));
    }

    @Test
    public void testNeInitializedEventForwardingStateDisable() {
        final FullNeData ne = getNe();
        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);
        ne.getNe().setEventForwarding(EnableSwitch.DISABLED);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(EventForwardingStateIcon.MAINTENANCE.icon(), is(icon));
    }

    @Test
    public void testNeInitializedEventForwardingStateEnable() {
        final FullNeData ne = getNe();
        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);
        ne.getNe().setEventForwarding(EnableSwitch.ENABLED);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(CommunicationStateIcon.ACTIVE.icon(), is(icon));
    }

    @Test
    public void testNeInitializedEventForwardingStateNull() {
        final FullNeData ne = getNe();
        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);
        ne.getNe().setEventForwarding(null);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(CommunicationStateIcon.ACTIVE.icon(), is(icon));
    }

    @Test
    public void testNeInitializedOperationEnable() {
        final FullNeData ne = getNe();
        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);
        ne.getNe().setOperationalState(OperationalState.ENABLED);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(CommunicationStateIcon.ACTIVE.icon(), is(icon));
    }

    @Test
    public void testNeInitializedOperationNull() {
        final FullNeData ne = getNe();
        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);
        ne.getNe().setOperationalState(null);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(CommunicationStateIcon.ACTIVE.icon(), is(icon));
    }

    @Test
    public void testNeInitializedSyncStateNull() {
        final FullNeData ne = getNe();
        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(CommunicationStateIcon.ACTIVE.icon(), is(icon));
    }

    @Test
    public void testNeInitializedSyncStateOutOfSync() {
        final FullNeData ne = getNe(ScsSyncState.OUT_OF_SYNC);

        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(SyncStateIcon.OUT_OF_SYNC.icon(), is(icon));
    }

    @Test
    public void testNeInitializedSyncStateSynchronizing() {
        final FullNeData ne = getNe(ScsSyncState.SYNCHRONIZING);

        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(SyncStateIcon.SYNCHRONIZING.icon(), is(icon));
    }

    @Test
    public void testNeInitializedSyncStateNotPresent() {
        final FullNeData ne = getNe();

        ne.getInfo().setGuiActualActivationState(GuiActualActivationState.ACTIVE);

        final Icon icon = ActualActivationStateIconBehavior.stateIconOf(ne);
        assertThat(CommunicationStateIcon.ACTIVE.icon(), is(icon));
    }

    private FullNeData getNe() {
        NEItem ne = new NEItem();
        return new FullNeData(ne, new NeInfo(ne.getId()), null);
    }

    private FullNeData getNe(ScsSyncState scsSyncState) {
        NEItem neItem = new NEItem();
        return new FullNeData(neItem, new NeInfo(neItem.getId()), new ScsSynchronizationState(0, scsSyncState));
    }
}
