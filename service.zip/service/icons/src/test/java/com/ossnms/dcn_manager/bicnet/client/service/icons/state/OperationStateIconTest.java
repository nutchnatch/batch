package com.ossnms.dcn_manager.bicnet.client.service.icons.state;

import com.ossnms.bicnet.bcb.model.common.OperationalState;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class OperationStateIconTest {

    @Test
    public void testStates() {
        assertThat(OperationStateIcon.IDLE, is(OperationStateIcon.of(OperationalState.DISABLED).get()));
        
        assertFalse(OperationStateIcon.of(null).isPresent());
        assertFalse(OperationStateIcon.of(OperationalState.ENABLED).isPresent());        
    }
}
