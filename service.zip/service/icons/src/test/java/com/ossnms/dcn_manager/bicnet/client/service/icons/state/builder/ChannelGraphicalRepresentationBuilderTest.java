package com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.coriant.widgets.icons.DoubleIcon;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconsType;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;

public class ChannelGraphicalRepresentationBuilderTest {
    
    private ChannelGraphicalRepresentationBuilder builder;
    
    @Before
    public void setup() {
        builder = new ChannelGraphicalRepresentationBuilder(new IconManager());
    }
    
    @Test
    public void testBuild_ne_requireEnable() {
        final IEM em = new EMItem();
        em.setActivation(EnableSwitch.ENABLED);
        em.setIconIdId(IconsType.EM_MVM.key());
        FullChannelData fullChannelData = new FullChannelData(em, new ChannelInfo(em.getId()));

        final DoubleIcon icon = builder.build(fullChannelData);
        
        assertNotNull(icon);
    }
    
    @Test
    public void testBuild_ne_enable_invalid_icon() {
        final IEM em = new EMItem();
        em.setActivation(EnableSwitch.ENABLED);
        em.setIconIdId("");
        FullChannelData fullChannelData = new FullChannelData(em, new ChannelInfo(em.getId()));

        final DoubleIcon icon = builder.build(fullChannelData);
        
        assertNotNull(icon);
    }
    
    @Test
    public void testBuild_disable() {
        final IEM em = new EMItem();
        em.setActivation(EnableSwitch.DISABLED);
        FullChannelData fullChannelData = new FullChannelData(em, new ChannelInfo(em.getId()));
        
        final DoubleIcon icon = builder.build(fullChannelData);
        
        assertNotNull(icon);
    }
}
