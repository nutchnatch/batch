package com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder;

import com.coriant.widgets.icons.DoubleIcon;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import org.junit.Test;

import javax.swing.Icon;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class SystemContainerGraphicalRepresentationBuilderTest {

    @Test public void buildDefault() throws Exception {
        final DoubleIcon error = new DoubleIcon(ResourcesIconFactory.ICON_TOOL_EMPTY_ICON_16,
                ResourcesIconFactory.ICON_LIST_CARD_16);

        final Icon icon = new SystemContainerGraphicalRepresentationBuilder(new IconManager())
                .build(new SystemContainerItem());

        assertThat(icon, notNullValue());
        assertThat(error.toString(), not(is(icon.toString())));
    }
}