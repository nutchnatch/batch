package com.ossnms.dcn_manager.bicnet.client.service.icons.state;


import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class CommunicationStateIconTest {

    @Test
    public void testStates() {
        assertThat(CommunicationStateIcon.ACTIVE, is(CommunicationStateIcon.of(GuiActualActivationState.ACTIVE).get()));
        assertThat(CommunicationStateIcon.INACTIVE, is(CommunicationStateIcon.of(GuiActualActivationState.INACTIVE).get()));
        
        assertThat(CommunicationStateIcon.FAILED, is(CommunicationStateIcon.of(GuiActualActivationState.FAILED).get()));
        
        assertThat(CommunicationStateIcon.ACTIVATING, is(CommunicationStateIcon.of(GuiActualActivationState.ACTIVATING).get()));
        assertThat(CommunicationStateIcon.DEACTIVATING, is(CommunicationStateIcon.of(GuiActualActivationState.DEACTIVATING).get()));
        
        assertThat(CommunicationStateIcon.STARTINGUP, is(CommunicationStateIcon.of(GuiActualActivationState.STARTINGUP).get()));
        assertThat(CommunicationStateIcon.SHUTINGDOWN, is(CommunicationStateIcon.of(GuiActualActivationState.SHUTTINGDOWN).get()));
    }
}
