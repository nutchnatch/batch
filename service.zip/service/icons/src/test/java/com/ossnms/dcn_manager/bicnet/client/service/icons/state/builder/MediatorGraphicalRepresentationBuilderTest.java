package com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder;

import com.coriant.widgets.icons.DoubleIcon;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconsType;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class MediatorGraphicalRepresentationBuilderTest {

    private MediatorGraphicalRepresentationBuilder builder;

    @Before public void setUp() throws Exception {
        builder = new MediatorGraphicalRepresentationBuilder(new IconManager());
    }

    @Test
    public void testBuild_ne_requireEnable() {
        final IMediator mediator = new MediatorItem();
        mediator.setActivation(EnableSwitch.ENABLED);
        mediator.setIconIdId(IconsType.MEDIATOR_GM.key());

        final DoubleIcon icon = builder.build(new FullMediatorData(mediator, new MediatorInfo(mediator.getId())));

        assertNotNull(icon);
    }

    @Test
    public void testBuild_ne_enable_invalid_icon() {
        final IMediator mediator = new MediatorItem();
        mediator.setActivation(EnableSwitch.ENABLED);
        mediator.setIconIdId("");

        final DoubleIcon icon = builder.build(new FullMediatorData(mediator, new MediatorInfo(mediator.getId())));

        assertNotNull(icon);
    }

    @Test
    public void testBuild_disable() {
        final IMediator mediator = new MediatorItem();
        mediator.setActivation(EnableSwitch.DISABLED);

        final DoubleIcon icon = builder.build(new FullMediatorData(mediator, new MediatorInfo(mediator.getId())));

        assertNotNull(icon);
    }
}