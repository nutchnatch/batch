package com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder;

import com.coriant.widgets.icons.DoubleIcon;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconsType;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class NeGraphicalRepresentationBuilderTest {
    
    private NeGraphicalRepresentationBuilder builder;
    
    @Before
    public void setup() {
        builder = new NeGraphicalRepresentationBuilder(new IconManager());
    }
    
    @Test
    public void testBuild_ne_requireEnable() {
        final INE ne = new NEItem();
        ne.setActivation(EnableSwitch.ENABLED);
        ne.setIconIdId(IconsType.NE_TL7100.key());
        
        final DoubleIcon icon = builder.build(new FullNeData(ne, new NeInfo(ne.getId()), null));
        
        assertNotNull(icon);
    }
    
    @Test
    public void testBuild_ne_enable_invalid_icon() {
        final INE ne = new NEItem();
        ne.setActivation(EnableSwitch.ENABLED);
        ne.setIconIdId("");
        
        final DoubleIcon icon = builder.build(new FullNeData(ne, new NeInfo(ne.getId()), null));
        
        assertNotNull(icon);
    }
    
    @Test
    public void testBuild_disable() {
        final INE ne = new NEItem();
        ne.setActivation(EnableSwitch.DISABLED);
        
        final DoubleIcon icon = builder.build(new FullNeData(ne, new NeInfo(ne.getId()), null));
        
        assertNotNull(icon);
    }
}
