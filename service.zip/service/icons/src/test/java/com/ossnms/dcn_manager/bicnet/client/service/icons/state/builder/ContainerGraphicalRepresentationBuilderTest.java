package com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import org.junit.Test;

import javax.swing.Icon;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

public class ContainerGraphicalRepresentationBuilderTest {
    @Test public void buildDefault() throws Exception {
        final Icon error = ResourcesIconFactory.ICON_LIST_CARD_16;

        final Icon icon = new ContainerGraphicalRepresentationBuilder(new IconManager())
                .build(new GenericContainerItem());

        assertThat(icon, notNullValue());
        assertThat(error.toString(), not(is(icon.toString())));
    }
}