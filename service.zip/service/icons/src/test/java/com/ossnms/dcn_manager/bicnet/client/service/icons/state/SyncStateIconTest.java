package com.ossnms.dcn_manager.bicnet.client.service.icons.state;

import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class SyncStateIconTest {
    
    @Test
    public void testStates() {
        assertThat(SyncStateIcon.OUT_OF_SYNC, is(SyncStateIcon.of(ScsSyncState.OUT_OF_SYNC).get()));
        assertThat(SyncStateIcon.SYNCHRONIZING, is(SyncStateIcon.of(ScsSyncState.SYNCHRONIZING).get()));
        
        assertFalse(SyncStateIcon.of(null).isPresent());
    }
}
