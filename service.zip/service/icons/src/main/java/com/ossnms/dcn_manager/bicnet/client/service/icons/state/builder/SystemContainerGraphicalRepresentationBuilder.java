package com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder;

import com.coriant.widgets.icons.DoubleIcon;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.tools.jfx.JfxUtils;

import javax.annotation.Nonnull;
import javax.swing.Icon;

import static com.ossnms.bicnet.resources.ResourcesIconFactory.getNetworkIcon;

public class SystemContainerGraphicalRepresentationBuilder extends GraphicalRepresentationBuilder<ISystemContainer>{

    public SystemContainerGraphicalRepresentationBuilder(IconManager iconManager) {
        super(iconManager);
    }

    @Override
    public Icon build(@Nonnull final ISystemContainer container) {
        try {
        	final Icon networkIcon = getNetworkIcon(ResourcesIconFactory.NetworkIcon.NE_hit7300, JfxUtils.DEFAULT_ICON_SIZE);
        	final Icon stateIcon = ResourcesIconFactory.ICON_TOOL_EMPTY_ICON_16;
        	
        	return new DoubleIcon(stateIcon, networkIcon);
        } catch (final Exception e) {
            return new DoubleIcon(ResourcesIconFactory.ICON_TOOL_EMPTY_ICON_16, ResourcesIconFactory.ICON_LIST_CARD_16);
        }
    }
    
}
