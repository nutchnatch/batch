/**
 * Contains the managers and configuration for the DCN icons.
 */
package com.ossnms.dcn_manager.bicnet.client.service.icons;