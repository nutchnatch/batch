package com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder;

import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;

import javax.annotation.Nonnull;
import javax.swing.*;

public abstract class GraphicalRepresentationBuilder<ELEMENT> {
    private final IconManager iconManager;

    public GraphicalRepresentationBuilder(IconManager iconManager) {
        this.iconManager = iconManager;
    }

    /**
     * Builds the Double Icon for the element.
     * @param element
     * @return
     */
    public abstract Icon build(@Nonnull final ELEMENT element);

    public IconManager getIconManager() {
        return iconManager;
    }
}
