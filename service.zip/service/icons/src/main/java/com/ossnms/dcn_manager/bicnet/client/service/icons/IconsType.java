package com.ossnms.dcn_manager.bicnet.client.service.icons;

import java.util.Arrays;
import java.util.Optional;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * DCN private icons type
 */
public enum IconsType {

    NE_7090("icon_pair_7090_default"),
    NE_TL7100("icon_pair_TL7100_default"),
    NE_hit7300("icon_pair_7300_default"),

    NE_OADM("icon_pair_OADM"),
    NE_7300_ONN("icon_pair_7300_ONN"),
    NE_OADMU("{FEFC80F6-0337-4F88-BFFE-C3977817D152}"),

    NE_OLA("icon_pair_OLA"),
    NE_7300_OLR("icon_pair_7300_OLR"),
    NE_OLRU("{EA2FF1C1-052B-43C4-93DB-293953FDC43E}"),

    NE_DC("icon_pair_DC"),
    NE_7300_SON("icon_pair_7300_SON"),
    NE_OCU("{28E2DF37-C693-4477-9113-F8E489F9B0EB}"),

    NE_GNE_DEFAULT("icon_pair_GNE"),
    NE_GNE("{438AD64F-4706-470A-A20E-F7ACC5C456DB}"),

    NE_hit7020("{C164C46B-8B6C-4989-9930-35F0582A17DF}"),
    NE_hit7025("{9D77B455-C77A-44b3-8CCD-298DA3EC703B}"),
    NE_hit7030("{3F6C5B2E-56FD-4647-B75D-F9D2A66C6EF8}"),
    NE_hit7035("{80750453-BED1-4e7e-8B20-409345017843}"),
    NE_hit7060("{1D373C7D-6FD7-4fab-A6C5-C89369459FD6}"),
    NE_hit7060HC("{F0F9953A-9B6E-4848-AFFF-7BF526416F11}"),
    NE_hit7065("{7CD7547C-B3B6-4B08-98C0-8b2A93E72F4F}"),
    NE_hit7070("{98054527-5A4A-49ca-9597-C48CB4E4F297}"),
    NE_hit7080("{CC767243-3446-4ec5-AB7A-BD5BB1B4B426}"),
    NE_hit7100("icon_pair_7100_default"),
    NE_hit7500("icon_pair_7500_default"),
    NE_OTTU("{2B75709A-0E3E-41C5-9D1F-9AF0CB70BE5D}"),
    NE_OTTC("{5557B156-F6D5-4599-B153-229C33536DF2}"),
    NE_CCU("{098B4141-78EF-4DF9-BBC9-0E904A47C3AB}"),
    NE_OADM100("{285EBAA1-EAE8-4A64-84AC-0AEDEAA6A119}"),
    NE_PXC100("{4B6D1F0B-7146-46C4-9244-FF91E74D924C}"),
    NE_FSP3000("{5E427BC0-A5E6-46c0-8A62-54E790C7F5D9}"),
    NE_juniper("icon_pair_juniper_default"),
    NE_UNO("icon_pair_uno_default"),
    NE_GROOVE("icon_pair_Groove_default"),
    NE_7100E("icon_pair_7100E_default"),

    NE_HIT70XX_SL("icon_SL_Default"),
    NE_HIT70XX_SLD("icon_SLD_Default"),
    NE_HIT70XX_SMA("icon_SMA_Default"),
    NE_HIT7X00_WLS("icon_WLS_Default"),
    NE_UNKNOWN("icon_unknown"),

    MEDIATOR_MVM(IconsMapper.MEDIATOR_ICON),
    MEDIATOR_GM(IconsMapper.MEDIATOR_ICON),
    MEDIATOR_BCB(IconsMapper.MEDIATOR_ICON),
    MEDIATOR_UNO(IconsMapper.MEDIATOR_ICON),

    EM_MVM("EM-MVM"),
    EM_GM("EM-GM"),
    EM_SNMP("SNMP"),
    EM_QB3M("QB3M"),
    EM_UNO("UNO");

    private final String key;


    IconsType(@Nonnull String key) {
        this.key = key;
    }

    public String key() {
        return key;
    }

    public static Optional<IconsType> of(@Nullable String text) {
        return Arrays.stream(IconsType.values())
                .filter(type -> type.key.equalsIgnoreCase(text))
                .findAny();
    }
}
