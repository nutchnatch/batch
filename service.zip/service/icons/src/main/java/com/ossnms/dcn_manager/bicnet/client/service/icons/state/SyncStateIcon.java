package com.ossnms.dcn_manager.bicnet.client.service.icons.state;

import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.bicnet.resources.ResourcesIconFactory;

import javax.annotation.Nonnull;
import javax.swing.Icon;
import java.util.Arrays;
import java.util.Optional;

/**
 * Associates a ScsSyncState with a common framework icon.
 */
enum SyncStateIcon {

    SYNCHRONIZING(ScsSyncState.SYNCHRONIZING , ResourcesIconFactory.ICON_STATUS_DCN_OBJ_SYNCHRONIZING_16),
    OUT_OF_SYNC(ScsSyncState.OUT_OF_SYNC , ResourcesIconFactory.ICON_STATUS_SYNC_NOTOK_16);
    
    private Icon iconState;
    private ScsSyncState bcbState;

    private SyncStateIcon(@Nonnull ScsSyncState bcbState, @Nonnull Icon iconState) {
        this.bcbState = bcbState;
        this.iconState = iconState;
    }

    /**
     * @return The icon associated with a ScsSyncState
     */
    @Nonnull
    public Icon icon() {
        return iconState;
    }

    /**
     * @return The BCB ScsSyncState
     */
    @Nonnull
    public ScsSyncState bcbState() {
        return bcbState;
    }
    
    /**
     * Gets a #SyncStateIcon by a BCB ScsSyncState.
     * 
     * @param bcbState
     * @return
     */
    @Nonnull
    public static Optional<SyncStateIcon> of(@Nonnull final ScsSyncState bcbState) {        
        return Arrays.asList(SyncStateIcon.values()).stream()
                .filter(input -> input.bcbState().equals(bcbState))
                .findFirst();
    }
}
