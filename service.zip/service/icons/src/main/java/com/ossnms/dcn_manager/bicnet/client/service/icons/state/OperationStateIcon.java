package com.ossnms.dcn_manager.bicnet.client.service.icons.state;

import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.resources.ResourcesIconFactory;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.Icon;
import java.util.Arrays;
import java.util.Optional;

/**
 * Associates a OperationalState with a common framework icon.
 */
enum OperationStateIcon {
    IDLE(OperationalState.DISABLED, ResourcesIconFactory.ICON_STATUS_NE_IDLE_16);

    private Icon iconState;
    private OperationalState bcbState;

    private OperationStateIcon(@Nonnull OperationalState bcbState, @Nonnull Icon iconState) {
        this.bcbState = bcbState;
        this.iconState = iconState;
    }
    
    /**
     * @return The icon associated with a OperationalState
     */
    @Nonnull
    public Icon icon() {
        return iconState;
    }
    
    /**
     * @return The BCB operational state
     */
    @Nonnull
    public OperationalState bcbState() {
        return bcbState;
    }
    
    /**
     * Gets a #OperationStateIcon by a BCB operational state.
     * 
     * @param bcbState
     * @return
     */
    @Nonnull
    public static Optional<OperationStateIcon> of(@Nullable final OperationalState bcbState) {
       
        if (bcbState == null) {
            return Optional.empty();
        }
       
        
        return Arrays.asList(OperationStateIcon.values()).stream()
                .filter(input -> input.bcbState() == bcbState)
                .findFirst();
    }
}
