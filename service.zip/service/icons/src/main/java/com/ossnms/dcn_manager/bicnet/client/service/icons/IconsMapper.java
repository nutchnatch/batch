package com.ossnms.dcn_manager.bicnet.client.service.icons;

import java.util.Optional;

import javax.annotation.Nonnull;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import com.ossnms.bicnet.resources.ResourcesIconFactory.NetworkIcon;

/**
 * Maps the DCN icon types to the common framework network icon types.
 * 
 * @see IconsType
 * @see NetworkIcon
 */
public final class IconsMapper {
    protected static final String MEDIATOR_ICON = "n_Mediator";
    
    private static final ImmutableMap<IconsType, NetworkIcon> ICONS;

    static {
        final Builder<IconsType, NetworkIcon> builder = ImmutableMap.builder();

        builder.put(IconsType.NE_7090, NetworkIcon.NE_7090);
        builder.put(IconsType.NE_TL7100, NetworkIcon.NE_hit7300);
        builder.put(IconsType.NE_hit7300, NetworkIcon.NE_hit7300);

        builder.put(IconsType.NE_OADM, NetworkIcon.NE_OADMU);
        builder.put(IconsType.NE_7300_ONN, NetworkIcon.NE_OADMU);
        builder.put(IconsType.NE_OADMU, NetworkIcon.NE_OADMU);

        builder.put(IconsType.NE_OLA, NetworkIcon.NE_OLRU);
        builder.put(IconsType.NE_7300_OLR, NetworkIcon.NE_OLRU);
        builder.put(IconsType.NE_OLRU, NetworkIcon.NE_OLRU);

        builder.put(IconsType.NE_DC, NetworkIcon.NE_OCUa);
        builder.put(IconsType.NE_7300_SON, NetworkIcon.NE_OCUa);
        builder.put(IconsType.NE_OCU, NetworkIcon.NE_OCUa);

        builder.put(IconsType.NE_GNE_DEFAULT, NetworkIcon.NE_GNE);
        builder.put(IconsType.NE_GNE, NetworkIcon.NE_GNE);

        builder.put(IconsType.NE_7100E, NetworkIcon.NE_hit7020);

        builder.put(IconsType.NE_hit7020, NetworkIcon.NE_hit7020);
        builder.put(IconsType.NE_hit7025, NetworkIcon.NE_hit7025);
        builder.put(IconsType.NE_hit7030, NetworkIcon.NE_hit7030);
        builder.put(IconsType.NE_hit7035, NetworkIcon.NE_hit7035);
        builder.put(IconsType.NE_hit7060, NetworkIcon.NE_hit7060);
        builder.put(IconsType.NE_hit7060HC, NetworkIcon.NE_hit7060HC);
        builder.put(IconsType.NE_hit7065, NetworkIcon.NE_hit7065);
        builder.put(IconsType.NE_hit7070, NetworkIcon.NE_hit7070);
        builder.put(IconsType.NE_hit7080, NetworkIcon.NE_hit7080);
        builder.put(IconsType.NE_hit7100, NetworkIcon.NE_hit7100);
        builder.put(IconsType.NE_hit7500, NetworkIcon.NE_hit7500);
        builder.put(IconsType.NE_OTTU, NetworkIcon.NE_OTTU);
        builder.put(IconsType.NE_OTTC, NetworkIcon.NE_OTTC);
        builder.put(IconsType.NE_CCU, NetworkIcon.NE_CCU);
        builder.put(IconsType.NE_OADM100, NetworkIcon.NE_OADM100);
        builder.put(IconsType.NE_PXC100, NetworkIcon.NE_PXC100);
        builder.put(IconsType.NE_FSP3000, NetworkIcon.NE_FSP3000);
        builder.put(IconsType.NE_juniper, NetworkIcon.NE_juniper);
        builder.put(IconsType.NE_UNO, NetworkIcon.NE_UNO);
        builder.put(IconsType.NE_GROOVE, NetworkIcon.NE_GROOVE);

        builder.put(IconsType.NE_HIT70XX_SL, NetworkIcon.NE_hit70xx_Sxx);
        builder.put(IconsType.NE_HIT70XX_SLD, NetworkIcon.NE_hit70xx_Sxx);
        builder.put(IconsType.NE_HIT70XX_SMA, NetworkIcon.NE_hit70xx_Sxx);
        builder.put(IconsType.NE_HIT7X00_WLS, NetworkIcon.NE_hit7x00_WLS);
        builder.put(IconsType.NE_UNKNOWN, NetworkIcon.NE_UNKNOWN);

        builder.put(IconsType.EM_GM, NetworkIcon.EM_GM);
        builder.put(IconsType.EM_MVM, NetworkIcon.EM_MVM);
        builder.put(IconsType.EM_QB3M, NetworkIcon.EM_QB3M);        
        builder.put(IconsType.EM_SNMP, NetworkIcon.EM_SNMP);
        builder.put(IconsType.EM_UNO, NetworkIcon.EM_UNO);

        builder.put(IconsType.MEDIATOR_BCB, NetworkIcon.MEDIATOR);
        builder.put(IconsType.MEDIATOR_GM, NetworkIcon.MEDIATOR);
        builder.put(IconsType.MEDIATOR_MVM, NetworkIcon.MEDIATOR);
        builder.put(IconsType.MEDIATOR_UNO, NetworkIcon.MEDIATOR);

        ICONS = builder.build();
    }
    
    private IconsMapper() {        
    }
    
    @Nonnull
    public static Optional<NetworkIcon> get(@Nonnull IconsType icon) {
        return Optional.ofNullable(ICONS.get(icon));
    }
    
    @Nonnull
    public static Optional<NetworkIcon> get(@Nonnull String text) {
        return IconsType.of(text).flatMap(IconsMapper::get);
    }
}
