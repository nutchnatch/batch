package com.ossnms.dcn_manager.bicnet.client.service.icons;

import static com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary.NOT_COMMISSIONED;
import static com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary.PARTIALLY_COMMISSIONED;
import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;

import java.awt.Image;
import java.util.Optional;
import java.util.function.Function;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.GatewayRole;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.resources.ResourcesIconFactory.NetworkIcon;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.tools.jfx.JfxUtils;

/**
 * Manage the Icons static configuration.
 */
public class IconManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(IconManager.class);

    private enum GatewayRoleOverlayLabel {
        NONE,
        PRIMARY,
        SECONDARY;
        
        static GatewayRoleOverlayLabel fromBcbGatewayRole(@Nonnull GatewayRole bcbGatewayRole) {
            if(GatewayRole.NONE.equals(bcbGatewayRole)) {
                return GatewayRoleOverlayLabel.NONE;
            }
            if(GatewayRole.PRIMARY.equals(bcbGatewayRole)) {
                return GatewayRoleOverlayLabel.PRIMARY;
            }
            if(GatewayRole.SECONDARY.equals(bcbGatewayRole)) {
                return GatewayRoleOverlayLabel.SECONDARY;
            }
            
            return GatewayRoleOverlayLabel.NONE;

        }
    }
    
    private GatewayRoleOverlayLabel mapGatewayRoleFromNeData(INE ne, NeInfo neInfo) {
        return GatewayRoleOverlayLabel.fromBcbGatewayRole(ne.getGatewayRole());
    }
    
    /**
     * Find the Container Icon
     * @param containerId
     * @return
     */
    @Nonnull
    public Optional<ImageIcon> findNetworkIcon(@Nonnull IGenericContainerId containerId) {
        return getNetworkIcon(ResourcesIconFactory.NetworkIcon.CONTAINER, JfxUtils.DEFAULT_ICON_SIZE);
    }

    /**
     * Find the Container Icon
     * @param systemId
     * @return
     */
    @Nonnull
    public Optional<ImageIcon> findNetworkIcon(@Nonnull ISystemContainerId systemId) {
        return getNetworkIcon(ResourcesIconFactory.NetworkIcon.NE_hit7300, JfxUtils.DEFAULT_ICON_SIZE);
    }

    /**
     * Find network icon by EmId
     *
     * @param em
     * @param size For default size uses JfxUtils.DEFAULT_ICON_SIZE
     * @return
     */
    @Nonnull
    public Optional<ImageIcon> findNetworkIcon(@Nonnull IEM em, int size) {
        return getIconFromResource(em.getIconIdId(), size);
    }

    /**
     * Find network icon by NeId
     *
     * @param ne
     * @param size For default size uses JfxUtils.DEFAULT_ICON_SIZE
     * @return
     */
    @Nonnull
    public Optional<ImageIcon> findNetworkIcon(@Nonnull INE ne, int size) {
        return getIconFromResource(ne.getIconIdId(), size);
    }

    /**
     * Find network icon by MediadorId
     *
     * @param mediator
     * @param size     For default size uses JfxUtils.DEFAULT_ICON_SIZE
     * @return
     */
    @Nonnull
    public Optional<ImageIcon> findNetworkIcon(@Nonnull IMediator mediator, int size) {
        return getIconFromResource(mediator.getIconIdId(), size);
    }

    /**
     * Find network icon by ASId
     *
     * @param domain
     * @param size   For default size uses JfxUtils.DEFAULT_ICON_SIZE
     * @return
     */
    @Nonnull
    public Optional<ImageIcon> findNetworkIcon(@Nonnull IAS domain, int size) {
        return getIconFromResource(domain.getIconIdId(), size);
    }

    /**
     * Find network icon by Container Id
     *
     * @param sc   id
     * @param size For default size uses JfxUtils.DEFAULT_ICON_SIZE
     * @return
     */
    @Nonnull
    public Optional<ImageIcon> findNetworkIcon(@Nonnull IGenericContainer sc, int size) {
        return getIconFromResource(sc.getIconIdId(), size);
    }

    /**
     * Find OverlayIcon icon from FullNeData.
     * <p>
     * The Icon is dynamic build using the current Commissioning Status.
     *
     * @param ne
     * @param size For default size uses JfxUtils.DEFAULT_ICON_SIZE
     * @return
     */
    @Nonnull
    public Optional<Icon> findNeOverlayIcon(@Nonnull FullNeData ne, int size) {
        return findNeOverlayIcon(ne.getNe(), ne.getInfo(), size);
    }


    /**
     * Find OverlayIcon icon by NeId.
     * <p>
     * The Icon is dynamic build using the current Commissioning Status.
     *
     * @param ne
     * @param size For default size uses JfxUtils.DEFAULT_ICON_SIZE
     * @return
     */
    @Nonnull
    public Optional<Icon> findNeOverlayIcon(@Nonnull INE ne, int size) {
        return findNeOverlayIcon(ne, null, size);
    }


    /**
     * Find OverlayIcon icon by NeId.
     * <p>
     * The Icon is dynamic build using the current Commissioning Status.
     *
     * @param ne
     * @param size For default size uses JfxUtils.DEFAULT_ICON_SIZE
     * @return
     */
    @Nonnull
    private Optional<Icon> findNeOverlayIcon(@Nonnull INE ne, NeInfo neInfo,  int size) {
        return findNetworkIcon(ne, size)
                .map(addOverlay(getIdleStateOverlay(ne.getOperationalState(), size)))
                .map(addOverlay(getCommissionStatusIcon(ne.getCommissioningStatus(), size)))
                .map(addOverlay(getGneOverlay(mapGatewayRoleFromNeData(ne, neInfo), size)))
                .map(addOverlay(getMaintenanceOverlay(ne.getEventForwarding(), size)));
    }
    

    /*
     * Gets the Icon from common framework.
     */
    @Nonnull
    public Optional<ImageIcon> getIconFromResource(@Nonnull String iconId, int size) {
        return IconsMapper.get(iconId).flatMap(iconType -> getNetworkIcon(iconType, size));
    }

    @Nonnull private Optional<ImageIcon> getNetworkIcon(NetworkIcon iconType, int size) {
        try {
            return ofNullable(ResourcesIconFactory.getNetworkIcon(iconType, size));
        } catch (Exception e) {
            LOGGER.error("Error on getIconFromSystemCache for {}", iconType, e);
            return empty();
        }
    }

    @Nonnull public static Function<Icon, Icon> addOverlay(@Nonnull Optional<ImageIcon> overlay) {
        return baseIcon -> overlay
                .map(overlayIcon -> scaleToSizeOf(baseIcon, overlayIcon))
                .map(overlayIcon -> (Icon) ResourcesIconFactory.getIconWithOverlay(baseIcon, overlayIcon, baseIcon.getIconWidth() - overlayIcon.getIconWidth(), 0))
                .orElse(baseIcon);
    }

    @Nonnull private static Icon scaleToSizeOf(@Nonnull Icon base, @Nonnull ImageIcon scalable) {
        return base.getIconHeight() == scalable.getIconHeight()
                ? scalable
                : new ImageIcon(scalable.getImage().getScaledInstance(base.getIconWidth(), base.getIconHeight(), Image.SCALE_SMOOTH));
    }

    @Nonnull
    private Optional<ImageIcon> getCommissionStatusIcon(
            @Nullable final CommissioningStatusSummary statusSummary, final int iconSize) {
        ImageIcon statusIcon = null;

        if (PARTIALLY_COMMISSIONED.equals(statusSummary)) {
            statusIcon = iconSize == JfxUtils.DEFAULT_ICON_SIZE
                    ? ResourcesIconFactory.ICON_STATUS_NE_NOT_YET_COMMISSIONED_OVERLAY_16
                    : ResourcesIconFactory.ICON_STATUS_NE_NOT_YET_COMMISSIONED_32;
        } else if (NOT_COMMISSIONED.equals(statusSummary)) {
            statusIcon = iconSize == JfxUtils.DEFAULT_ICON_SIZE
                    ? ResourcesIconFactory.ICON_STATUS_NE_NOT_COMMISSIONED_OVERLAY_16
                    : ResourcesIconFactory.ICON_STATUS_NE_NOT_COMMISSIONED_32;
        }

        return ofNullable(statusIcon);
    }

    @Nonnull private Optional<ImageIcon> getGneOverlay(GatewayRoleOverlayLabel gatewayType, int size) {
        ImageIcon gneIcon = null;

        // deal with gateway type here
        switch(gatewayType) {
            case PRIMARY:
                // Load a Primary gateway overlay
                gneIcon = size == JfxUtils.DEFAULT_ICON_SIZE
                ? ResourcesIconFactory.ICON_OVERLAY_PRIMARY_GATEWAY_16
                : ResourcesIconFactory.ICON_OVERLAY_PRIMARY_GATEWAY_32;
                break;
            case SECONDARY:
                // Load a Secondary gateway overlay
                gneIcon = size == JfxUtils.DEFAULT_ICON_SIZE
                ? ResourcesIconFactory.ICON_OVERLAY_SECONDARY_GATEWAY_16
                : ResourcesIconFactory.ICON_OVERLAY_SECONDARY_GATEWAY_32;
                break;
            case NONE:
                // Non gateway NE
                gneIcon = null;
                break;

            default:
                break;
        }
        return ofNullable(gneIcon);
    }

    @Nonnull private Optional<ImageIcon> getMaintenanceOverlay(EnableSwitch eventForwarding, int size) {
        ImageIcon maintenanceIcon = null;
        if (EnableSwitch.DISABLED.equals(eventForwarding)) {
            maintenanceIcon = size == JfxUtils.DEFAULT_ICON_SIZE
                    ? ResourcesIconFactory.ICON_STATUS_NE_ICON_MAINTENA_16
                    : ResourcesIconFactory.ICON_STATUS_NE_ICON_MAINTENA32;
        }
        return ofNullable(maintenanceIcon);
    }

    @Nonnull public Optional<ImageIcon> getWarningOverlay(boolean isWarning) {
        return isWarning ? ofNullable(ResourcesIconFactory.ICON_OVERLAY_WARNING_16) : empty();
    }

    @Nonnull
    private Optional<ImageIcon> getIdleStateOverlay(
            @Nullable final OperationalState operationalState, final int iconSize) {
        ImageIcon statusIcon = null;

        if (OperationalState.DISABLED == operationalState) {
            statusIcon = iconSize == JfxUtils.DEFAULT_ICON_SIZE
                    ? ResourcesIconFactory.ICON_OVERLAY_STATUS_NE_IDLE_16
                    : ResourcesIconFactory.ICON_STATUS_NE_IDLE_32;
        }

        return ofNullable(statusIcon);
    }
}
