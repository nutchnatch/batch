package com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder;

import com.coriant.widgets.icons.DoubleIcon;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.api.state.RequiredStateVerification;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.ActualActivationStateIconBehavior;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.tools.jfx.JfxUtils;

import javax.annotation.Nonnull;
import javax.swing.Icon;

public class NeGraphicalRepresentationBuilder extends GraphicalRepresentationBuilder<FullNeData>{

    public NeGraphicalRepresentationBuilder(@Nonnull final IconManager iconManager) {
        super(iconManager);
    }

    @Override
    public DoubleIcon build(@Nonnull final FullNeData ne) {
        final Icon neTypeOverlayIcon = getIconManager()
                .findNeOverlayIcon(ne, JfxUtils.DEFAULT_ICON_SIZE)
                .orElse(ResourcesIconFactory.ICON_OVERLAY_UNKNOWN_16);

        final Icon stateIcon = ( RequiredStateVerification.isDisable(ne.getNe()) && ne.getInfo().getGuiActiveActualActivationState().orElse(GuiActualActivationState.INACTIVE) ==  GuiActualActivationState.INACTIVE)  ?
                ResourcesIconFactory.ICON_STATUS_DEACTIVATED_16 :
                    ActualActivationStateIconBehavior.stateIconOf(ne);

        return new DoubleIcon(stateIcon, neTypeOverlayIcon);
    }
}
