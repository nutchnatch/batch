package com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.tools.jfx.JfxUtils;

import javax.annotation.Nonnull;
import javax.swing.*;

import static com.ossnms.bicnet.resources.ResourcesIconFactory.getNetworkIcon;

public class DomainGraphicalRepresentationBuilder extends GraphicalRepresentationBuilder<IAS>{

    public DomainGraphicalRepresentationBuilder(IconManager iconManager) {
        super(iconManager);
    }

    @Override
    public Icon build(@Nonnull final IAS domain) {
        try {
            return getNetworkIcon(ResourcesIconFactory.NetworkIcon.DOMAIN, JfxUtils.DEFAULT_ICON_SIZE);
        } catch (final Exception e) {
            return ResourcesIconFactory.ICON_LIST_CARD_16;
        }
    }
}
