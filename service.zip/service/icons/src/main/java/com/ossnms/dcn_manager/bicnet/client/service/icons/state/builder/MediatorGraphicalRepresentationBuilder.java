package com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder;

import com.coriant.widgets.icons.DoubleIcon;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.api.state.RequiredStateVerification;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.ActualActivationStateIconBehavior;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.tools.jfx.JfxUtils;

import javax.annotation.Nonnull;
import javax.swing.Icon;

public class MediatorGraphicalRepresentationBuilder extends GraphicalRepresentationBuilder<FullMediatorData> {

    public MediatorGraphicalRepresentationBuilder(
            @Nonnull final IconManager iconManager) {
        super(iconManager);
    }

    @Override
    public DoubleIcon build(@Nonnull final FullMediatorData mediator) {

        final Icon networkIcon = getIconManager()
                .findNetworkIcon(mediator.getMediator(), JfxUtils.DEFAULT_ICON_SIZE)
                .orElse(ResourcesIconFactory.ICON_LIST_EM_16);

        final Icon stateIcon = ( RequiredStateVerification.isDisable(mediator.getMediator()) && mediator.getInfo().getGuiActiveActualActivationState().orElse(GuiActualActivationState.INACTIVE) ==  GuiActualActivationState.INACTIVE)  ?
                ResourcesIconFactory.ICON_STATUS_DEACTIVATED_16 :
                    ActualActivationStateIconBehavior.stateIconOf(mediator.getInfo().getGuiActiveActualActivationState());

        return new DoubleIcon(stateIcon, networkIcon);
    }
}
