package com.ossnms.dcn_manager.bicnet.client.service.icons.state;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;

import javax.annotation.Nonnull;
import javax.swing.Icon;
import java.util.Arrays;
import java.util.Optional;

/**
 * Associates a  CommunicationState with a common framework icon.
 */
public enum CommunicationStateIcon {

    ACTIVE(GuiActualActivationState.ACTIVE, ResourcesIconFactory.ICON_STATUS_DCN_OBJ_RUNNING_16),
    INACTIVE(GuiActualActivationState.INACTIVE, ResourcesIconFactory.ICON_STATUS_DCN_OBJ_DISCONNECTED_16),

    FAILED(GuiActualActivationState.FAILED, ResourcesIconFactory.ICON_STATUS_DCN_OBJ_CONNECTION_FAILURE_16),

    // Icon mappings below are odd, but have been explicitly requested to be like that.
    
    ACTIVATING(GuiActualActivationState.ACTIVATING, ResourcesIconFactory.ICON_STATUS_DCN_OBJ_STARTING_UP_16),
    DEACTIVATING(GuiActualActivationState.DEACTIVATING, ResourcesIconFactory.ICON_STATUS_DCN_OBJ_SHUTTINGDOWN_16),
    
    STARTINGUP(GuiActualActivationState.STARTINGUP, ResourcesIconFactory.ICON_STATUS_DCN_OBJ_CONNECTING_16),
    SHUTINGDOWN(GuiActualActivationState.SHUTTINGDOWN, ResourcesIconFactory.ICON_STATUS_DCN_OBJ_DISCONNECTING_16),
    
    NONE(GuiActualActivationState.NONE, ResourcesIconFactory.ICON_TOOL_EMPTY_ICON_16),
    DEACTIVATED(GuiActualActivationState.DEACTIVATED, ResourcesIconFactory.ICON_STATUS_DEACTIVATED_16),
    SYNCHRONIZING(GuiActualActivationState.SYNCHRONIZING, ResourcesIconFactory.ICON_STATUS_DCN_OBJ_SYNCHRONIZING_16),
	OUT_OF_SYNCH(GuiActualActivationState.OUT_OF_SYNCH, ResourcesIconFactory.ICON_STATUS_SYNC_NOTOK_16);
	
    private Icon iconState;
    private GuiActualActivationState activationState;

    private CommunicationStateIcon(@Nonnull GuiActualActivationState activationState, @Nonnull Icon iconState) {
        this.activationState = activationState;
        this.iconState = iconState;
    }
   
    /**
     * @return The icon associated with a CommunicationState
     */
    @Nonnull
    public Icon icon() {
        return iconState;
    }
    
    /**
     * @return The BCB communication state
     */
    @Nonnull
    public GuiActualActivationState activationState() {
        return activationState;
    }
    
    /**
     * Gets a #CommunicationStateIcon by a GuiActualActivationState.
     * 
     * @param activationState
     * @return
     */
    @Nonnull
    public static Optional<CommunicationStateIcon> of(@Nonnull final GuiActualActivationState activationState) {
        return Arrays.asList(CommunicationStateIcon.values()).stream()
                .filter(input -> input.activationState() == activationState)
                .findFirst();
    }
}
