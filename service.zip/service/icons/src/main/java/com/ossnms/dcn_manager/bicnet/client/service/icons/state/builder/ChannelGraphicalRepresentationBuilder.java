package com.ossnms.dcn_manager.bicnet.client.service.icons.state.builder;

import com.coriant.widgets.icons.DoubleIcon;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.dcn_manager.bicnet.client.api.state.RequiredStateVerification;
import com.ossnms.dcn_manager.bicnet.client.service.icons.IconManager;
import com.ossnms.dcn_manager.bicnet.client.service.icons.state.ActualActivationStateIconBehavior;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.tools.jfx.JfxUtils;

import javax.annotation.Nonnull;
import javax.swing.Icon;

import static com.ossnms.bicnet.resources.ResourcesIconFactory.ICON_LIST_EM_16;

public class ChannelGraphicalRepresentationBuilder extends GraphicalRepresentationBuilder<FullChannelData> {

    public ChannelGraphicalRepresentationBuilder(IconManager iconManager) {
        super(iconManager);
    }

    @Override
    public DoubleIcon build(@Nonnull final FullChannelData channel) {
        final Icon networkIcon = getIconManager()
                .findNetworkIcon(channel.getChannel(), JfxUtils.DEFAULT_ICON_SIZE)
                .orElse(ICON_LIST_EM_16);

        final Icon stateIcon = ( RequiredStateVerification.isDisable(channel.getChannel()) && channel.getInfo().getGuiActiveActualActivationState().orElse(GuiActualActivationState.INACTIVE) ==  GuiActualActivationState.INACTIVE)  ?
                ResourcesIconFactory.ICON_STATUS_DEACTIVATED_16 :
                    ActualActivationStateIconBehavior.stateIconOf(channel.getInfo().getGuiActiveActualActivationState());

        return new DoubleIcon(stateIcon, networkIcon);
    }
}
