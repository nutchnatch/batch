package com.ossnms.dcn_manager.bicnet.client.service.icons.state;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.resources.ResourcesIconFactory;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.Icon;
import java.util.Arrays;
import java.util.Optional;

/**
 * Associates a  EventForwarding with a common framework icon.
 */
enum EventForwardingStateIcon {
    MAINTENANCE(EnableSwitch.DISABLED , ResourcesIconFactory.ICON_STATUS_DCN_OBJ_RUNNING_16);

    private Icon iconState;
    private EnableSwitch bcbState;

    private EventForwardingStateIcon(@Nonnull EnableSwitch bcbState, @Nonnull Icon iconState) {
        this.bcbState = bcbState;
        this.iconState = iconState;
    }
   
    /**
     * @return The icon associated with a EventForwarding
     */
    @Nonnull
    public Icon icon() {
        return iconState;
    }
    
    /**
     * @return The BCB state
     */
    @Nonnull
    public EnableSwitch bcbState() {
        return bcbState;
    }
    
    /**
     * Gets a #EventForwardingStateIcon by a BCB state.
     * 
     * @param bcbState
     * @return
     */
    @Nonnull
    public static Optional<EventForwardingStateIcon> of(@Nullable final EnableSwitch bcbState) {
        
        if (bcbState == null) {
            return Optional.empty();
        }
        
        return Arrays.asList(EventForwardingStateIcon.values()).stream()
                .filter(input -> input.bcbState() == bcbState)
                .findFirst();
    }
}
