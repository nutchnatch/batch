package com.ossnms.dcn_manager.bicnet.client.service.icons.state;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;

import javax.annotation.Nonnull;
import javax.swing.Icon;

import java.util.Optional;

import static com.ossnms.bicnet.resources.ResourcesIconFactory.ICON_OVERLAY_UNKNOWN_16;

/**
 * Associate a icon for a connection/synchronization state.
 */
public final class ActualActivationStateIconBehavior {

    private ActualActivationStateIconBehavior() {        
    }

    /**
     * Gets the associated icon for a certain #GuiActualActivationState.
     *
     * @param activationState
     * @return
     */
    public static Icon stateIconOf(@Nonnull GuiActualActivationState activationState) {
        final Optional<CommunicationStateIcon> communicationStateIcon = CommunicationStateIcon.of(activationState);
        return getIconOrDefault(communicationStateIcon);
    }

    private static Icon getIconOrDefault(Optional<CommunicationStateIcon> communicationStateIcon) {
        return communicationStateIcon.map(CommunicationStateIcon::icon).orElse(ICON_OVERLAY_UNKNOWN_16);
    }

    /**
     * Gets the associated icon for a certain #GuiActualActivationState.
     *
     * @param activationState
     * @return
     */
    public static Icon stateIconOf(@Nonnull Optional<GuiActualActivationState> activationState) {
        final Optional<CommunicationStateIcon> communicationStateIcon = CommunicationStateIcon.of(activationState.orElse(GuiActualActivationState.INACTIVE));
        return getIconOrDefault(communicationStateIcon);
    }

    /**
     * Gets the associated icon for a certain #GuiActualActivationState and #ScsSyncState.
     * 
     * @param ne
     * @return
     */
    public static Icon stateIconOf(@Nonnull FullNeData ne) {
        final Optional<CommunicationStateIcon> communicationStateIcon = CommunicationStateIcon.of(ne.getInfo().getGuiActiveActualActivationState()
                .orElse(GuiActualActivationState.INACTIVE));

        if (communicationStateIcon.isPresent() && CommunicationStateIcon.ACTIVE == communicationStateIcon.get()) {
            Optional<Icon> operationalIcon = getOperationalIcon(ne);

            if (operationalIcon.isPresent()) {
                return operationalIcon.get();
            }
        }
        
        return getIconOrDefault(communicationStateIcon);        
    }
    
    /* Icon when the NE is Active */
    @Nonnull
    private static Optional<Icon> getOperationalIcon(@Nonnull FullNeData ne) {

        if (ne.getSynchronizationState() != null) {
            final Optional<SyncStateIcon> syncIcon = SyncStateIcon.of(ne.getSynchronizationState().getState());
            if (syncIcon.isPresent()) {
                return syncIcon.map(SyncStateIcon::icon);
            }
        }

        final Optional<EventForwardingStateIcon> eventStateIcon = EventForwardingStateIcon.of(ne.getNe().getEventForwarding());
        if (eventStateIcon.isPresent()) {
            return eventStateIcon.map(EventForwardingStateIcon::icon);
        }


        return Optional.empty();
    }
}
