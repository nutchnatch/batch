package com.book.lambdaexpressions;

/**
 * Created by b48489 on 02-11-2017.
 */
public enum CaloricLevel {

    DIET,
    NORMAL,
    FAT
}
