package com.book.lambdaexpressions;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.function.DoubleFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by b48489 on 19-09-2017.
 */
public class ComposingFunctions {

    private List<Dish> menu = Arrays.asList(
            new Dish("pork", false, 800, Dish.Type.MEAT),
            new Dish("beef", false, 700, Dish.Type.MEAT),
            new Dish("chicken", false, 400, Dish.Type.MEAT),
            new Dish("french fries", true, 530, Dish.Type.OTHER),
            new Dish("rice", true, 350, Dish.Type.OTHER),
            new Dish("season fruit", true, 120, Dish.Type.OTHER),
            new Dish("pizza", true, 550, Dish.Type.OTHER),
            new Dish("prawns", false, 300, Dish.Type.FISH),
            new Dish("salmon", false, 450, Dish.Type.FISH) );

    public static void main(String[] args) {
        ComposingFunctions composingFunctions = new ComposingFunctions();
        System.out.println("AndThen: " + composingFunctions.andThenFunction());
        System.out.println("Compose: " + composingFunctions.composeFunction());

        System.out.println("Integration: (x + 7 -> 3, 7) =>" + composingFunctions.integrate((double x) -> x + 10, 3, 7));

        System.out.println("3 Dishes with number of calories bigger than 300:\n");
        composingFunctions.streamOperations().forEach(System.out::println);
        composingFunctions.decrementValue();
    }

    private void decrementValue() {
        int pageNumber = 1;
        pageNumber = pageNumber > 0 ? -- pageNumber : pageNumber;
        System.out.println("Page Number: " + pageNumber);
    }

    private int andThenFunction() {
        Function<Integer, Integer> f = x -> x + 1;
        Function<Integer, Integer> g = x -> x * 2;
        Function<Integer, Integer> h = f.andThen(g);

        return h.apply(1);
    }

    private int composeFunction() {
        Function<Integer, Integer> f = x -> x + 1;
        Function<Integer, Integer> g = x -> x * 2;
        Function<Integer, Integer> h = f.compose(g);

        return h.apply(1);
    }

    private double integrate(DoubleFunction<Double> function, double a, double b) {

        return (function.apply(a) + function.apply(b)) * (b - a) / 2.0;
    }

    private List<String> streamOperations() {
        return menu.stream()
                .filter(dish -> dish.getCalories() > 300)
                .map(Dish::getName)
                .limit(3)
                .collect(Collectors.toList());
    }

    private void dishByeType() {


    }
}
