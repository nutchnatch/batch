package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Mediator;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import org.junit.Test;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.MediatorTransformer.toMediatorVO;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class MediatorTransformerTest {
    @Test public void activationLimitPresent_shouldBeLimited() throws Exception {
        Mediator mediator = newMediator("10");
        
        MediatorValueObject valueObject = toMediatorVO(mediator, mediator.getType());

        assertThat(valueObject.getConcurrentActivationsLimited(), is(of(true)));
    }

    @Test public void activationLimitInvalid_shouldNotBeLimited() throws Exception {
        Mediator mediator = newMediator("a");

        MediatorValueObject valueObject = toMediatorVO(mediator, mediator.getType());

        assertThat(valueObject.getConcurrentActivationsLimited(), is(of(false)));
    }

    @Test public void activationLimitIsZero_shouldNotBeLimited() throws Exception {
        Mediator mediator = newMediator("0");

        MediatorValueObject valueObject = toMediatorVO(mediator, mediator.getType());

        assertThat(valueObject.getConcurrentActivationsLimited(), is(of(false)));
        assertThat(valueObject.getConcurrentActivationsLimit(), is(empty()));
    }

    private Mediator newMediator(String concurrentActivationsLimit) {
        Mediator mediator = new Mediator();
        mediator.setConcurrentActivationsLimit(concurrentActivationsLimit);
        mediator.setType("some type");
        return mediator;
    }
}