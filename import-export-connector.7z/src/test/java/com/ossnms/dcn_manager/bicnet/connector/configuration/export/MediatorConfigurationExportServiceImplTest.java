package com.ossnms.dcn_manager.bicnet.connector.configuration.export;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorsReply;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaMediatorInstanceRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaMediatorRepositoryBean;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;

import static org.bouncycastle.asn1.x509.X509ObjectIdentifiers.id;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class) public class MediatorConfigurationExportServiceImplTest {

    @Mock private ISessionContext sessionContext;
    @Mock private JpaMediatorRepositoryBean mediatorRepository;
    @Mock private JpaMediatorInstanceRepositoryBean mediatorInstanceRepository;

    @InjectMocks private MediatorConfigurationExportServiceImpl service;

    @Before public void setUp() throws Exception {
        when(mediatorRepository.queryAll()).thenReturn(buildMediators());

        final MediatorPhysicalData primaryInfo = new MediatorPhysicalDataBuilder().setHost("host_primary_" + id)
                .setPriority(MediatorInstance.PRIMARY_PRIORITY_LEVEL).build(2, 1, 0);
        final MediatorPhysicalData secondaryInfo = new MediatorPhysicalDataBuilder().setHost("host_secondary_" + id)
                .setPriority(1).build(3, 1, 0);
        final MediatorPhysicalConnectionData connectionData = new MediatorPhysicalConnectionBuilder()
                .build(1, 1, 0);

        when(mediatorInstanceRepository.queryAll(anyInt())).thenReturn(ImmutableList
                .of(new MediatorInstance(primaryInfo, connectionData),
                        new MediatorInstance(secondaryInfo, connectionData)));
    }

    @Test public void export_index_out_of_range() throws Exception {
        final MediatorsReply export = service.export(sessionContext, 2000, 10);

        assertThat(export.getEof(), is(true));
        assertThat(export.getData().length, is(0));
    }

    @Test public void export_none() throws Exception {
        final MediatorsReply export = service.export(sessionContext, 0, 0);

        assertThat(export.getEof(), is(true));
        assertThat(export.getData().length, is(0));
    }

    @Test public void export_all() throws Exception {
        final MediatorsReply export = service.export(sessionContext, 0, -1);

        assertThat(export.getEof(), is(true));
        assertThat(export.getData().length, is(10));
    }

    @Test public void export_paging() throws Exception {
        final MediatorsReply exportPage1 = service.export(sessionContext, 0, 5);

        assertThat(exportPage1.getEof(), is(false));
        assertThat(exportPage1.getData().length, is(5));

        for (int i = 0; i < 5; i++) {
            assertThat(exportPage1.getData()[i].getMediatorId(), is(i+1));
        }

        final MediatorsReply exportPage2 = service.export(sessionContext, 5, 6);

        assertThat(exportPage2.getEof(), is(true));
        assertThat(exportPage2.getData().length, is(5));

        int id = 6;
        for (int i = 0; i < 5; i++) {
            assertThat(exportPage2.getData()[i].getMediatorId(), is(id++));
        }
    }

    private Iterable<MediatorEntity> buildMediators() throws Exception {
        Collection<MediatorEntity> entities = new ArrayList<>();

        for (int id = 1; id <= 10; id++) {
            final MediatorEntity mediatorEntity = new MediatorEntity(
                    new MediatorInfoBuilder().setProperty("bag_id", "bag_value").setName("name_" + id)
                            .setDescription(Optional.of("description")).setConcurrentActivationsLimited(true)
                            .setReconnectAttemptInterval(10).setConcurrentActivationsLimit(11).setTypeName("type")
                            .build(id, 0), new MediatorConnectionData.MediatorConnectionBuilder().build(id, 0));
            entities.add(mediatorEntity);
        }

        return entities;
    }
}
