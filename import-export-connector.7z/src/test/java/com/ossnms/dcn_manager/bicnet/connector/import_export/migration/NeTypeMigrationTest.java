package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import static com.google.common.collect.ImmutableMap.of;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.Map;

import org.junit.Test;

public class NeTypeMigrationTest {
    @Test public void shouldNotChangeTypeWithoutMappings() throws Exception {
        NeTypeMigration migration = new NeTypeMigration(of("type v1", "type v2"));

        assertThat(migration.apply("no mappings"), is("no mappings"));
        assertThat(migration.apply("type v2"), is("type v2"));
    }

    @Test public void shouldMigrateTypeThatHasMapping() throws Exception {
        NeTypeMigration migration = new NeTypeMigration(of("type v1", "type v2"));

        assertThat(migration.apply("type v1"), is("type v2"));
    }

    @Test public void shouldMigrateTypeThroughSequenceOfMappings() throws Exception {
        Map<String, String> v1_v2 = of("type v1", "type v2", "some type", "some type 2");
        Map<String, String> v2_v3 = of("type v2", "type v3", "another type", "another type 2");
        Map<String, String> v3_v4 = of("type v3", "type v4");
        NeTypeMigration migration = new NeTypeMigration(v1_v2, v2_v3, v3_v4);

        assertThat(migration.apply("type v1"), is("type v4"));
        assertThat(migration.apply("type v2"), is("type v4"));
        assertThat(migration.apply("type v3"), is("type v4"));
    }

    @Test public void shouldMigrateTypeThroughSequenceWithGaps() throws Exception {
        Map<String, String> v1_v2 = of("type v1", "type v2");
        Map<String, String> gap = of("another type", "another type 2");
        Map<String, String> v2_v3 = of("type v2", "type v3");
        NeTypeMigration migration = new NeTypeMigration(v1_v2, gap, v2_v3);

        assertThat(migration.apply("type v1"), is("type v3"));
        assertThat(migration.apply("type v2"), is("type v3"));
    }
}