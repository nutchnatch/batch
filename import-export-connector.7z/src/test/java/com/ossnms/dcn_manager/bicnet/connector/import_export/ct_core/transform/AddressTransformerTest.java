package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import org.junit.Test;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.AddressTransformer.ipFor;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;
import static org.junit.Assume.assumeThat;

public class AddressTransformerTest {
    @Test public void shouldResolveUnknownHostIntoLoopback() throws Exception {
        assertThat(ipFor("wrong host"), is("127.0.0.1"));
        assertThat(ipFor(null), is("127.0.0.1"));
    }

    @Test public void shouldResolveLocalhostIntoLoopback() throws Exception {
        assertThat(ipFor("localhost"), is("127.0.0.1"));
    }

    @Test public void shouldResolveDomainIntoIp() throws Exception {
        //assume we have internet address
        assumeThat(ipFor("google-public-dns-a.google.com"), is("8.8.8.8"));

        assertThat(ipFor("coriant.com"), is(not("127.0.0.1")));
    }

    @Test public void shouldResolveIpIntoItself() throws Exception {
        assertThat(ipFor("10.10.10.10"), is("10.10.10.10"));
        assertThat(ipFor("8.8.8.8"), is("8.8.8.8"));
    }
}