package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Channel;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import org.junit.Test;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.ChannelTransformer.toChannelVO;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.PropertyBuilder.container;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.PropertyBuilder.property;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.PropertyBuilder.store;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownChannelPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT;
import static java.util.Collections.emptyList;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class ChannelTransformerTest {
    @Test public void shouldAddTypeToChannelName() throws Exception {
        Channel channel = channel("Name", "Type");

        ChannelValueObject channelVO = toChannelVO(someMediator(), channel, "Type");

        assertThat(channelVO.getName(), is("Name_Type"));
    }

    @Test public void shouldContainProvidedType() throws Exception {
        Channel channel = channel("Name", "ChannelType");

        ChannelValueObject channelVO = toChannelVO(someMediator(), channel, "ProvidedType");

        assertThat(channelVO.getType(), is("ProvidedType"));
    }

    @Test public void shouldContainPropertiesBag() throws Exception {
        Channel channel = channel("Name", "ChannelType");
        channel.getPropContainer().getPropStore().add(store("store", property("property", "value")));

        ChannelValueObject channelVO = toChannelVO(someMediator(), channel, "ChannelType");

        assertThat(channelVO.getPropertyBag(), hasKey("store/property"));
    }

    @Test public void shouldContainEmptyPropertiesBagWhenProvidedTypeIsDifferent() throws Exception {
        Channel channel = channel("Name", "ChannelType");
        channel.getPropContainer().getPropStore().add(store("store", property("property", "value")));

        ChannelValueObject channelVO = toChannelVO(someMediator(), channel, "ProvidedType");

        assertThat(channelVO.getPropertyBag().values(), is(empty()));
    }

    @Test public void shouldRemoveInvalidScheduledStartup() throws Exception {
        Channel channel = channel("Name", "ChannelType");
        channel.getPropContainer().getPropStore().add(store("E1DF2CFE-5E9C-4915-B982-91BE1689D1B9", property("MaxNeInitCount", "0")));

        ChannelValueObject channelVO = toChannelVO(someMediator(), channel, "ChannelType");

        assertThat(channelVO.getPropertyBag(), not(hasKey(CONCURRENT_ACTIVATIONS_LIMIT)));
    }

    @Test public void shouldKeepValidScheduledStartup() throws Exception {
        Channel channel = channel("Name", "ChannelType");
        channel.getPropContainer().getPropStore().add(store("E1DF2CFE-5E9C-4915-B982-91BE1689D1B9", property("MaxNeInitCount", "1")));

        ChannelValueObject channelVO = toChannelVO(someMediator(), channel, "ChannelType");

        assertThat(channelVO.getPropertyBag(), hasKey(CONCURRENT_ACTIVATIONS_LIMIT));
    }

    private MediatorValueObject someMediator() {
        return ImmutableMediatorValueObject.of("", "", "", emptyList());
    }

    private Channel channel(String name, String channelType) {
        Channel channel = new Channel();
        channel.setIDName(name);
        channel.setPropContainer(container(store("38250635-F75A-4F6B-8D66-50A014D40A55", property("NecTypeName", channelType))));
        return channel;
    }
}