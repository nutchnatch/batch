package com.ossnms.dcn_manager.bicnet.connector.import_export.outbound;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ossnms.bicnet.bcb.facade.elementMgmt.MTera7100NetworkPropertiesFacetItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.ManagementInterfaceFacetItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.MountDetailsPkgItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementReply;
import com.ossnms.bicnet.bcb.facade.elementMgmt.SoftwareManagerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.ndm.INetworkDataManagerFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.elementMgmt.ApsDescription;
import com.ossnms.bicnet.bcb.model.elementMgmt.ApsDetails;
import com.ossnms.bicnet.bcb.model.elementMgmt.EonType;
import com.ossnms.bicnet.bcb.model.elementMgmt.IMTera7100NetworkPropertiesFacet;
import com.ossnms.bicnet.bcb.model.elementMgmt.IManagementInterfaceFacet;
import com.ossnms.bicnet.bcb.model.elementMgmt.IMountDetailsPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElement;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementId;
import com.ossnms.bicnet.bcb.model.elementMgmt.ISoftwareManager;
import com.ossnms.bicnet.bcb.model.elementMgmt.IpNetworkAddress;
import com.ossnms.bicnet.bcb.model.elementMgmt.MemoryBankDetails;
import com.ossnms.bicnet.bcb.model.elementMgmt.MountDirection;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeAdditionalInfo;

@RunWith(MockitoJUnitRunner.class)
public class ExportNeAdditionalInfoTest {
	
	private static final int NE_ID = 1;
	private static final String NE_SW_VERSION = "FP10";

	@Mock private INetworkDataManagerFacade ndmFacade;
	@Mock private ISessionContext systemContext;
	@InjectMocks private ExportNeAdditionalInfo neInfo;

	@Test
	public void testAllOptionalFacetsPresent() throws BcbException {
		INE ne = new NEItem();
		ne.setId(NE_ID);
		
		when(ndmFacade.getNetworkElementList(any(ISessionContext.class), any(INetworkElementId.class), any(), anyInt())).thenReturn(createNetworkElementReply(true));
		Map<Integer, NeAdditionalInfo> neInfoMap = neInfo.getExportNeAdditionalInfo(systemContext, Arrays.asList(ne));
		
		assertEquals(MountDirection.HORIZONTAL.name(), neInfoMap.get(NE_ID).getMountMode().get());
		assertEquals(EonType.PRNE.name(), neInfoMap.get(NE_ID).getEonType().get());
		assertEquals("10.46.88.100", neInfoMap.get(NE_ID).getLocalInterface().get());
		assertEquals("255.255.255.255", neInfoMap.get(NE_ID).getLocalInterfaceMask().get());
		assertFalse(neInfoMap.get(NE_ID).getDcnInterface().isPresent());
		assertFalse(neInfoMap.get(NE_ID).getDcnInterfaceMask().isPresent());
		assertFalse(neInfoMap.get(NE_ID).getRouterInterface().isPresent());
		assertFalse(neInfoMap.get(NE_ID).getRouterInterfaceMask().isPresent());
		assertEquals("10.46.88.200", neInfoMap.get(NE_ID).getManagementInterface().get());
		assertEquals("255.255.255.257", neInfoMap.get(NE_ID).getManagementInterfaceMask().get());
		assertEquals("gateway", neInfoMap.get(NE_ID).getGateway().get());
		assertEquals(NE_SW_VERSION, neInfoMap.get(NE_ID).getNeSwVersion().get());
	}
	
	@Test
	public void testNoneOptionalFacetsPresent() throws BcbException {
		INE ne = new NEItem();
		ne.setId(NE_ID);
		
		when(ndmFacade.getNetworkElementList(any(ISessionContext.class), any(INetworkElementId.class), any(), anyInt())).thenReturn(createNetworkElementReply(false));
		Map<Integer, NeAdditionalInfo> neInfoMap = neInfo.getExportNeAdditionalInfo(systemContext, Arrays.asList(ne));
		
		assertNull(neInfoMap.get(NE_ID));
	}
	
	private NetworkElementReply createNetworkElementReply(boolean addOptionalFacets) {
		INetworkElement networkElement = new NetworkElementItem();
		networkElement.setNeId(NE_ID);

		if (addOptionalFacets) {
			addOptionalFacets(networkElement);
		}

		return new NetworkElementReply(new INetworkElement[] { networkElement }, false, null);
	}
	
	private void addOptionalFacets(INetworkElement networkElement) {
		IMountDetailsPkg mountMode = new MountDetailsPkgItem(MountDirection.HORIZONTAL);
		IMTera7100NetworkPropertiesFacet networkProperties = new MTera7100NetworkPropertiesFacetItem(EonType.PRNE,
				new IpNetworkAddress("10.46.88.100", "255.255.255.255"), null, null, "gateway");
		IManagementInterfaceFacet managementInterface = new ManagementInterfaceFacetItem(
				new IpNetworkAddress("10.46.88.200", "255.255.255.257"));
		ISoftwareManager softwareManager = new SoftwareManagerItem();
		softwareManager.setApsList(createApsDetails());
		networkElement.addOptionalFacet(networkProperties);
		networkElement.addOptionalFacet(managementInterface);
		networkElement.addOptionalFacet(mountMode);
		networkElement.addOptionalFacet(softwareManager);
	}
	
	private ApsDetails[] createApsDetails() {
		ApsDescription apsDescription = new ApsDescription();
		apsDescription.setVersion(NE_SW_VERSION);
		MemoryBankDetails memoryBankDetails = new MemoryBankDetails();
		memoryBankDetails.setApsDescription(apsDescription);
		ApsDetails apsDtls = new ApsDetails();
		apsDtls.setMemoryBank(memoryBankDetails);
		
		ApsDetails[] apsList = new ApsDetails[2];
		apsList[0] = apsDtls;
		return apsList;
	}

}
