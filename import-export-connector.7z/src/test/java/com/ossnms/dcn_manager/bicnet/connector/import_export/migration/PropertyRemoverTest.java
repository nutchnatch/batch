package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import com.google.common.collect.ImmutableMap;
import org.junit.Test;

import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class PropertyRemoverTest {

    @Test
    public void testApply() throws Exception {

        final Map<String, String> result =
            new PropertyRemover("k3", "k1", "k3")
                .apply(ImmutableMap.of("k1", "1", "k2", "2", "k3", "3", "k4", "4"));

        assertThat(result, is(ImmutableMap.of("k2", "2", "k4", "4")));
    }

    @Test
    public void testApply_withEmptyFilter() throws Exception {

        final Map<String, String> result =
                new PropertyRemover()
                        .apply(ImmutableMap.of("k1", "1", "k2", "2", "k3", "3", "k4", "4"));

        assertThat(result, is(ImmutableMap.of("k1", "1", "k2", "2", "k3", "3", "k4", "4")));
    }

}