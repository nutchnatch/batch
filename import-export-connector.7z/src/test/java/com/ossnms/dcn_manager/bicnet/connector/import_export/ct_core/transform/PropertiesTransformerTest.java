package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.PropContainer;
import org.junit.Test;

import java.util.Map;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.PropertiesTransformer.toPropertiesBag;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.PropertyBuilder.*;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

public class PropertiesTransformerTest {

    @Test public void shouldAcceptNull() throws Exception {
        Map<String, String> bag = toPropertiesBag(null);

        assertThat(bag, is(notNullValue()));
        assertThat(bag.values(), is(empty()));
    }

    @Test public void shouldCombineStoreGuidWithPropertyName() throws Exception {
        PropContainer container = container(store("store", property("name", "content")));

        Map<String, String> bag = toPropertiesBag(container);

        assertThat(bag, hasEntry("store/name", "content"));
    }

    @Test public void shouldSkipEmptyStores() throws Exception {
        PropContainer container = container(
                store("notEmptyStore", property("some property", "with value")),
                store("emptyStore"));

        Map<String, String> bag = toPropertiesBag(container);

        assertThat(bag.values(), hasSize(1));
    }

    @Test public void shouldSkipEmptyProperties() throws Exception {
        PropContainer container = container(store("guid", property("valid", "some value"), property("empty", null)));

        Map<String, String> bag = toPropertiesBag(container);

        assertThat(bag, hasKey("guid/valid"));
        assertThat(bag, not(hasKey("guid/empty")));
    }

    @Test public void shouldProcessMultipleStores() throws Exception {
        PropContainer container = container(
                store("store1",
                        property("prop1", "some value"),
                        property("prop2", "another value")),
                store("store2",
                        property("prop1", "some value"),
                        property("prop2", "another value")));

        Map<String, String> bag = toPropertiesBag(container);

        assertThat(bag, is(ImmutableMap.of(
                "store1/prop1", "some value",
                "store1/prop2", "another value",
                "store2/prop1", "some value",
                "store2/prop2", "another value")));
    }
}