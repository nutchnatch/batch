package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import com.google.common.collect.ImmutableMap;
import org.junit.Test;

import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;

public class NePropertyMigrationTest {

    private static final Map<String, String> PROPERTIES = ImmutableMap.<String, String>builder()
            .put("TL1_FTP_IP_ADDRESS", "value11")
            .put("TL1_FTP_USERNAME", "value12")
            .put("TL1_FTP_PASSWORD", "value13")
            .put("TL1_FTP_UPLOADPATH", "value14")
            .put("other", "other_value")
            .build();

    @Test public void testMigrationFP11() throws Exception {
        final Map<String, String> propertiesApplied = new NePropertyMigration("7100 PICO FP11.x").apply(PROPERTIES);

        assertions(propertiesApplied);
    }

    @Test public void testMigrationFP12() throws Exception {
        final Map<String, String> propertiesApplied = new NePropertyMigration("7100 PICO FP12.x").apply(PROPERTIES);

        assertions(propertiesApplied);
    }

    @Test public void testMigrationNoChanges() throws Exception {
        final Map<String, String> propertiesApplied = new NePropertyMigration("7100 PICO FP10.x").apply(PROPERTIES);

        assertThat(PROPERTIES.keySet(), containsInAnyOrder(propertiesApplied.keySet().toArray()));
    }

    private void assertions(Map<String, String> propertiesApplied) {
        assertThat(propertiesApplied.containsKey("TL1_SFTP_IP_ADDRESS"), is(true));
        assertThat(propertiesApplied.containsKey("TL1_SFTP_USERNAME"), is(true));
        assertThat(propertiesApplied.containsKey("TL1_SFTP_PASSWORD"), is(true));
        assertThat(propertiesApplied.containsKey("TL1_SFTP_UPLOADPATH"), is(true));
        assertThat(propertiesApplied.containsKey("other"), is(true));
    }
}
