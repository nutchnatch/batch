package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.PropContainer;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.PropContainer.PropStore;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Property;

import static java.util.Arrays.asList;

class PropertyBuilder {

    static Property property(String name, String content) {
        return property(name, content, "VT_BSTR");
    }

    static Property property(String name, String content, String type) {
        Property property = new Property();
        property.setName(name);
        property.setContent(content);
        property.setType(type);
        return property;
    }

    static PropStore store(String id, Property... properties) {
        PropStore store = new PropStore();
        store.setGUID(id);
        store.getProperty().addAll(asList(properties));
        return store;
    }

    static PropContainer container(PropStore... stores) {
        PropContainer container = new PropContainer();
        container.getPropStore().addAll(asList(stores));
        return container;
    }
}
