package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import org.junit.Test;

import java.util.Collection;
import java.util.Map;

import static com.google.common.collect.ImmutableMap.of;
import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DataTransferSettingsMigrationTest {

    @Test public void shouldRemoveSftpSettings() throws Exception {
        boolean importSftp = false;
        Collection<String> ftpKeys = asList("ftp_user", "ftp_password");
        Map<String, String> properties = of(
                "ftp_user", "user",
                "ftp_password", "pass",
                "other key", "other value");

        Map<String, String> result = new DataTransferSettingsMigration(importSftp, ftpKeys).apply(properties);

        assertThat(result, is(of("other key", "other value")));
    }

    @Test public void shouldNotRemoveSftpSettings() throws Exception {
        boolean importSftp = true;
        Collection<String> ftpKeys = asList("ftp_user", "ftp_password");
        Map<String, String> properties = of(
                "ftp_user", "user",
                "ftp_password", "pass",
                "other key", "other value");

        Map<String, String> result = new DataTransferSettingsMigration(importSftp, ftpKeys).apply(properties);

        assertThat(result, is(properties));
    }

    @Test public void shouldResolveSftpKeys() throws Exception {
        String type = "neType";
        Map<String, String> dataTransferSettings = of("user", "ftp_user", "password", "ftp_password");
        StaticConfiguration configuration = staticConfiguration(neType(type, dataTransferSettings));

        Collection<String> ftpKeys = DataTransferSettingsMigration.ftpKeys(type, configuration);

        assertThat(ftpKeys, containsInAnyOrder("user", "ftp_user", "password", "ftp_password"));
    }

    @Test public void shouldNotResolveSftpKeysForMissingType() throws Exception {
        Map<String, String> dataTransferSettings = of("user", "ftp_user", "password", "ftp_password");
        StaticConfiguration configuration = staticConfiguration(neType("neType", dataTransferSettings));

        Collection<String> ftpKeys = DataTransferSettingsMigration.ftpKeys("missingType", configuration);

        assertThat(ftpKeys, is(empty()));
    }

    private NeType neType(String name, Map<String, String> dataTransferSettings) {
        NeType type = mock(NeType.class);
        when(type.getName()).thenReturn(name);
        when(type.getDataTransferSettings()).thenReturn(dataTransferSettings);
        return type;
    }

    private StaticConfiguration staticConfiguration(NeType... types) {
        Types<NeType> neTypes = Types.from(asList(types));
        StaticConfiguration staticConfiguration = mock(StaticConfiguration.class);
        when(staticConfiguration.getNeTypes()).thenReturn(neTypes);
        return staticConfiguration;
    }
}