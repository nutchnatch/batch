package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.Mediator;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import org.junit.Test;

import java.util.Collections;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class MediatorsTest {
    @Test public void shouldTransformFields() throws Exception {
        MediatorValueObject valueObject = ImmutableMediatorValueObject.builder()
                .mediatorId(1)
                .name("name").type("type").host("host")
                .reconnectInterval(17)
                .concurrentActivationsLimited(true)
                .concurrentActivationsLimit(43)
                .mediatorInstances(Collections.emptyList())
                .description("some description")
                .build();

        Mediator mediator = Mediators.transform(valueObject);

        assertThat(mediator.getIDName(), is("name"));
        assertThat(mediator.getType(), is("type"));
        assertThat(mediator.getHost(), is("host"));
        assertThat(mediator.getReconnectInterval(), is("17"));
        assertThat(mediator.getConcurrentActivationsLimit(), is("43"));
        assertThat(mediator.isConcurrentActivationsLimited(), is(true));
        assertThat(mediator.getDescription(), is("some description"));
    }

    @Test public void shouldAcceptEmptyFields() throws Exception {
        MediatorValueObject valueObject = ImmutableMediatorValueObject.of("name", "type", "host", Collections.emptyList());

        Mediator mediator = Mediators.transform(valueObject);

        assertThat(mediator.getConcurrentActivationsLimit(), is(nullValue()));
        assertThat(mediator.isConcurrentActivationsLimited(), is(nullValue()));
        assertThat(mediator.getReconnectInterval(), is(nullValue()));
        assertThat(mediator.getDescription(), is(nullValue()));
    }

    @Test public void shouldTransformPropertyBag() throws Exception {
        ImmutableMap<String, String> propertyBag = ImmutableMap.of("key", "value", "another key", "some value");
        MediatorValueObject valueObject = ImmutableMediatorValueObject.of("name", "type", "host", Collections.emptyList()).withPropertyBag(propertyBag);

        Mediator mediator = Mediators.transform(valueObject);

        assertThat(mediator.getProperty(), hasSize(2));
        assertThat(mediator.getProperty().get(0).getName(), is("key"));
        assertThat(mediator.getProperty().get(0).getValue(), is("value"));
        assertThat(mediator.getProperty().get(1).getName(), is("another key"));
        assertThat(mediator.getProperty().get(1).getValue(), is("some value"));
    }
}