package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.GenericContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ContainerValueObject;
import org.junit.Test;

import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableContainerValueObject.of;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

public class ContainersTransformerTest {
    @Test public void shouldExportName() throws Exception {
        ContainerValueObject valueObject = of("Some name");

        GenericContainer container = ContainersTransformer.fromValue(valueObject);

        assertThat(container.getIDName(), is("Some name"));
    }

    @Test public void shouldExportUserText() throws Exception {
        ContainerValueObject withUserText = of("")
                .withUserText("User text");
        ContainerValueObject withoutUserText = of("");

        GenericContainer containerWithText = ContainersTransformer.fromValue(withUserText);
        GenericContainer containerWithoutText = ContainersTransformer.fromValue(withoutUserText);

        assertThat(containerWithText.getUserText(), is("User text"));
        assertThat(containerWithoutText.getUserText(), is(nullValue()));
    }


    @Test public void shouldExportDescription() throws Exception {
        ContainerValueObject withDescription = of("")
                .withDescription("Some description");
        ContainerValueObject withoutDescription = of("");

        GenericContainer containerWithDescription = ContainersTransformer.fromValue(withDescription);
        GenericContainer containerWithoutDescription = ContainersTransformer.fromValue(withoutDescription);

        assertThat(containerWithDescription.getDescription(), is("Some description"));
        assertThat(containerWithoutDescription.getDescription(), is(nullValue()));
    }

    @Test public void shouldExportParentContainer() throws Exception {
        ContainerValueObject withParent = of("")
                .withParent("Parent Container");
        ContainerValueObject withoutParent = of("");

        GenericContainer containerWithParent = ContainersTransformer.fromValue(withParent);
        GenericContainer containerWithoutParent = ContainersTransformer.fromValue(withoutParent);

        assertThat(containerWithParent.getParentContainer(), is("Parent Container"));
        assertThat(containerWithoutParent.getParentContainer(), is(nullValue()));
    }
    
    @Test public void shouldImportName() throws Exception {
        GenericContainer genericContainer = basicContainer("name");

        ContainerValueObject result = ContainersTransformer.toValue(genericContainer);

        assertThat(result, is(of("name")));
    }

    @Test public void shouldImportUserText() throws Exception {
        GenericContainer withValue = basicContainer("name");
        withValue.setUserText("user text");

        ContainerValueObject without = ContainersTransformer.toValue(basicContainer("name"));
        ContainerValueObject with = ContainersTransformer.toValue(withValue);

        assertThat(without, is(of("name")));
        assertThat(with, is(of("name").withUserText("user text")));
    }

    @Test public void shouldImportDescription() throws Exception {
        GenericContainer withValue = basicContainer("name");
        withValue.setDescription("some description");

        ContainerValueObject without = ContainersTransformer.toValue(basicContainer("name"));
        ContainerValueObject with = ContainersTransformer.toValue(withValue);

        assertThat(without, is(of("name")));
        assertThat(with, is(of("name").withDescription("some description")));
    }

    @Test public void shouldImportParen() throws Exception {
        GenericContainer withValue = basicContainer("name");
        withValue.setParentContainer("parent name");

        ContainerValueObject without = ContainersTransformer.toValue(basicContainer("name"));
        ContainerValueObject with = ContainersTransformer.toValue(withValue);

        assertThat(without, is(of("name")));
        assertThat(with, is(of("name").withParent("parent name")));
    }

    private GenericContainer basicContainer(String name) {
        GenericContainer genericContainer = new GenericContainer();
        genericContainer.setIDName(name);
        return genericContainer;
    }
}