package com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportChannel;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.dcn_manager.connector.storage.mediator.MediatorRepository;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static java.util.Arrays.asList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.contains;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ExportConfigurationChannelsTransformerTest {

    private static final int CHANNEL_ID = 1;
    private static final int VERSION = 0;
    private static final int MEDIATOR_ID = 2;

    @Mock private MediatorRepository mediatorRepository;
    private ChannelEntity entity;

    @Before public void setUp() throws Exception {
        entity = new ChannelEntity(
                new ChannelInfoBuilder().setType("type")
                        .build(CHANNEL_ID, VERSION, MEDIATOR_ID),
                new ChannelConnectionBuilder().setAdditionalInfo("info")
                        .build(CHANNEL_ID, VERSION),
                new ChannelUserPreferencesBuilder().setConcurrentActivationsLimit(10)
                        .setConcurrentActivationsLimited(true).setName("name").setReconnectInterval(11)
                        .setProperty("bag_id", "bag_value")
                        .build(CHANNEL_ID, VERSION));
    }

    @Test public void testTransform() throws Exception {
        when(mediatorRepository.queryMediatorName(MEDIATOR_ID)).thenReturn(Optional.of("mediator_name"));

        final ExportChannel transform = ExportConfigurationChannelsTransformer.transform(entity, mediatorRepository);

        assertThat(transform.getIdName(),is(entity.getUserPreferences().getName()));
        assertThat(transform.getChannelId(),is(entity.getInfo().getId()));
        assertThat(transform.getConcurrentActivationsLimit(),is("10"));
        assertThat(transform.getConcurrentActivationsLimited(),is(entity.getUserPreferences().isConcurrentActivationsLimited()));
        assertThat(transform.getMediator(),is("mediator_name"));
        assertThat(transform.getType(),is(entity.getInfo().getType()));

        assertThat(asList(transform.getProperties()), contains(new Property("bag_id","bag_value")));
    }

    @Test public void testTransform_error_mediator() throws Exception {
        when(mediatorRepository.queryMediatorName(MEDIATOR_ID)).thenReturn(Optional.empty());

        final ExportChannel transform = ExportConfigurationChannelsTransformer.transform(entity, mediatorRepository);

        assertThat(transform.getMediator(), nullValue());
    }
}