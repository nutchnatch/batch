package com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PasswordMigration;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.PasswordPropertyMetadata;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.migration.jaxb.passwordproperties.Password;
import com.ossnms.dcn_manager.migration.jaxb.passwordproperties.Properties;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PasswordMigration.MAPPINGS_ENCTYPT;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PasswordMigration.MAPPINGS_RECRYPT;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames.USER_PASSWORD;
import static java.util.Collections.singleton;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PasswordMigrationTest {

    @Mock private StaticConfiguration configuration;
    @Mock private Types<NeType> neTypes;
    @Mock private NeType neType;
    @Mock private PasswordPropertyMetadata propertiesMetadata;
    private Password passwordConfig;
    public static final String PASSWORD_FIELD = "password";
    private PasswordMigration migration;
    private String neTypeValue;

    @Before public void setUp() throws Exception {
        String propertyFile = "file";
        neTypeValue = 
                "neType";

        when(neType.getSupportedPropertyFileNames()).thenReturn(singletonList(propertyFile));
        when(neType.mapOutgoingPropertyName(USER_PASSWORD)).thenReturn(PASSWORD_FIELD);
        when(neTypes.get(neTypeValue)).thenReturn(neType);
        when(configuration.getNeTypes()).thenReturn(neTypes);

        passwordConfig = new Password();
        passwordConfig.setName(PASSWORD_FIELD);
        Properties property = new Properties();
        property.getPassword().add(passwordConfig);
        when(propertiesMetadata.entrySet()).thenReturn(singleton(ImmutablePair.of(propertyFile, property)));
        when(configuration.getPasswordPropertyMetadata()).thenReturn(propertiesMetadata);

        migration = new PasswordMigration(MAPPINGS_RECRYPT, neTypeValue, configuration);
    }

    @Test public void shouldAcceptEmptyProperties() throws Exception {
        HashMap<String, String> properties = new HashMap<>();

        Map<String, String> migrated = migration.migrate(properties);

        assertThat(migrated, is(properties));
    }


    @Test public void shouldNotChangeOtherProperties() throws Exception {
        ImmutableMap<String, String> properties = ImmutableMap.of("some key", "some value");

        Map<String, String> migrated = migration.migrate(new HashMap<>(properties));

        assertThat(migrated, is(properties));
    }

    @Test public void shouldNotChangePasswordWithNoCoding() throws Exception {
        ImmutableMap<String, String> properties = ImmutableMap.of(PASSWORD_FIELD, "encoded password");
        passwordConfig.setCoding(null);

        Map<String, String> migrated = migration.migrate(new HashMap<>(properties));

        assertThat(migrated, is(properties));
    }

    @Test public void shouldRecryptPasswordWithMd5Coding() throws Exception {
        String encryptedMd5Password = "4C14F4C06C147DCCEF3631C46BCA9C1986F4121392EF3A78B00ACE9609E5A346223A88FEDAF35388";
        ImmutableMap<String, String> properties = ImmutableMap.of(PASSWORD_FIELD, encryptedMd5Password);
        passwordConfig.setCoding("md5");

        Map<String, String> migrated = migration.migrate(new HashMap<>(properties));

        assertThat(migrated, is(ImmutableMap.of(PASSWORD_FIELD, "63623145E7F2AF21943C959D90C7A7DD997855C47C4312EA")));
    }

    @Test public void shouldEcryptCoreMd5Password() throws Exception {
        String encryptedMd5Password = "04A891B0CF189FA26157A751C02BE30A";
        ImmutableMap<String, String> properties = ImmutableMap.of(PASSWORD_FIELD, encryptedMd5Password);
        passwordConfig.setCoding("md5");

        migration = new PasswordMigration(MAPPINGS_ENCTYPT, neTypeValue, configuration);
        Map<String, String> migrated = migration.migrate(new HashMap<>(properties));

        assertThat(migrated, is(ImmutableMap.of(PASSWORD_FIELD, "63623145E7F2AF21943C959D90C7A7DD997855C47C4312EA")));
    }
}