package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import org.junit.Test;

import java.util.Map;

import static com.google.common.collect.ImmutableMap.of;
import static java.util.Collections.emptyMap;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class PropertiesKeysMapperTest {
    @Test public void shouldTranslateKeys() throws Exception {
        Map<String, String> properties = of("oldKey", "some value");
        PropertiesKeysMapper mapper = new PropertiesKeysMapper(of("oldKey", "newKey"));

        Map<String, String> result = mapper.translateKeys(properties);

        assertThat(result, hasEntry("newKey", "some value"));
    }

    @Test public void shouldNotChangeOtherKeys() throws Exception {
        Map<String, String> properties = of("otherKey", "some value");
        PropertiesKeysMapper mapper = new PropertiesKeysMapper(of("oldKey", "newKey"));

        Map<String, String> result = mapper.translateKeys(properties);

        assertThat(result, hasEntry("otherKey", "some value"));
    }

    @Test public void shouldNotFailOnDuplicatedKeyAfterTranslation() throws Exception {
        Map<String, String> properties = of("oldKey", "first value", "newKey", "second value");
        PropertiesKeysMapper mapper = new PropertiesKeysMapper(of("oldKey", "newKey"));

        Map<String, String> result = mapper.translateKeys(properties);

        assertThat(result, hasEntry("newKey", "second value"));
    }

    @Test public void shouldAcceptEmpty() throws Exception {
        Map<String, String> mapping = emptyMap();
        Map<String, String> properties = emptyMap();
        PropertiesKeysMapper mapper = new PropertiesKeysMapper(mapping);

        Map<String, String> result = mapper.translateKeys(properties);

        assertThat(result, is(emptyMap()));
    }
}