package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.PropContainer;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.PropContainer.PropStore;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Property;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Collection;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.PropertiesNormalizer.normalizedValue;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toMap;
import static org.apache.commons.lang3.tuple.ImmutablePair.of;

class PropertiesTransformer implements Function<PropContainer, Map<String, String>> {

    /**
     * Given Core/CT properties container produces map of nonempty properties
     */
    static Map<String, String> toPropertiesBag(PropContainer container) {
        Stream<PropStore> propStores = ofNullable(container)
                .map(PropContainer::getPropStore)
                .map(Collection::stream).orElseGet(Stream::empty);

        return propStores
                .flatMap(PropertiesTransformer::propValues)
                .collect(toMap(Pair::getLeft, Pair::getRight, (oldV, newV) -> newV));
    }

    private static Stream<Pair<String, String>> propValues(PropStore store) {
        return store.getProperty().stream()
                .filter(PropertiesTransformer::hasValue)
                .map(property -> of(key(store, property), normalizedValue(property)));
    }

    private static String key(PropStore store, Property property) {
        return store.getGUID() + '/' + property.getName();
    }

    private static boolean hasValue(Property property) {
        return property.getContent() != null;
    }

    @Override public Map<String, String> apply(PropContainer container) {
        return toPropertiesBag(container);
    }
}
