package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import java.util.Map;
import java.util.Set;
import java.util.function.Function;

import static com.google.common.collect.ImmutableSet.copyOf;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.filterOut;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.testingKey;

/**
 * Removes entries from a given map and returns the new map.
 */
public class PropertyRemover implements Function<Map<String, String>, Map<String, String>> {

    private final Set<String> keysToRemove;

    public PropertyRemover(Set<String> keysToRemove) {
        this.keysToRemove = keysToRemove;
    }

    public PropertyRemover(String... keysToRemove) {
        this(copyOf(keysToRemove));
    }

    @Override
    public Map<String, String> apply(Map<String, String> map) {
        return filterOut(map, testingKey(keysToRemove::contains));
    }
}
