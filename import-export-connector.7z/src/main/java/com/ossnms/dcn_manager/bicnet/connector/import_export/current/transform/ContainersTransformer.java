package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.GenericContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ContainerValueObject;

import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableContainerValueObject.builder;
import static java.util.Optional.ofNullable;

public final class ContainersTransformer {

    private ContainersTransformer() {
    }

    public static GenericContainer fromValue(ContainerValueObject container) {
        GenericContainer genericContainer = new GenericContainer();
        genericContainer.setIDName(container.name());
        genericContainer.setUserText(container.userText().orElse(null));
        genericContainer.setDescription(container.description().orElse(null));
        genericContainer.setParentContainer(container.parent().orElse(null));
        return genericContainer;
    }

    public static ContainerValueObject toValue(GenericContainer container) {
        return builder()
                .name(container.getIDName())
                .parent(ofNullable(container.getParentContainer()))
                .userText(ofNullable(container.getUserText()))
                .description(ofNullable(container.getDescription()))
                .build();
    }
}
