package com.ossnms.dcn_manager.bicnet.connector.configuration.export;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorsReply;
import com.ossnms.dcn_manager.bicnet.configuration.export.MediatorConfigurationExportService;
import com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform.ExportConfigurationMediatorsTransformer;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaMediatorInstanceRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaMediatorRepositoryBean;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import java.util.stream.StreamSupport;

import static com.mysema.util.ArrayUtils.isEmpty;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.Comparator.comparing;
import static org.slf4j.LoggerFactory.getLogger;

public class MediatorConfigurationExportServiceImpl implements MediatorConfigurationExportService {
    private static final Logger LOGGER = getLogger(MediatorConfigurationExportServiceImpl.class);


    @Inject @DcnManager private JpaMediatorInstanceRepositoryBean mediatorInstanceRepository;
    @Inject @DcnManager private JpaMediatorRepositoryBean mediatorRepository;

    /**
     * @see MediatorConfigurationExportService#export(ISessionContext, int, int)
     */
    @Override public MediatorsReply export(ISessionContext sessionContext, int startIndex, int howMany)
            throws BcbException {

        final ExportMediator[] mediators;
        try {
            mediators = StreamSupport.stream(mediatorRepository.queryAll().spliterator(), false)
                    .sorted(comparing(mediator -> mediator.getInfo().getId()))
                    .filter(mediator -> mediator.getInfo().getId() > startIndex)
                    .map(this::fetchMediator)
                    .limit(howMany >= 0 ? howMany : Integer.MAX_VALUE)
                    .map(ExportConfigurationMediatorsTransformer::transform)
                    .toArray(ExportMediator[]::new);

            // Working with the worse case. If the page size is the same length of the last objects size,
            // that implies a new call with empty collection
            final boolean isEof = howMany < 0 || isEmpty(mediators) || mediators.length < howMany;

            return new MediatorsReply(isEof, mediators);
        } catch (RepositoryException exception) {
            throw logAndRethrowAsBcb(exception, LOGGER);
        }
    }

    private Pair<MediatorEntity, Iterable<MediatorInstance>> fetchMediator(
            @Nonnull final MediatorEntity mediatorEntity) {
        try {
            final Iterable<MediatorInstance> mediatorInstances = mediatorInstanceRepository
                    .queryAll(mediatorEntity.getInfo().getId());
            return ImmutablePair.of(mediatorEntity, mediatorInstances);
        } catch (RepositoryException e) {
            Throwables.propagate(e);
            return null; // never will be called
        }
    }
}
