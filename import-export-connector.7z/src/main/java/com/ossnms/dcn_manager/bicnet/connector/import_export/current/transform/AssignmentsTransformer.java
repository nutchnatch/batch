package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.ContainerAssignment;
import com.ossnms.dcn_manager.core.import_export.valueobjects.AssignedContainer;

import java.util.Collection;
import java.util.List;

import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableAssignedContainer.builder;
import static java.util.stream.Collectors.toList;

final class AssignmentsTransformer {

    private AssignmentsTransformer() {
    }

    static Collection<ContainerAssignment> fromValue(List<AssignedContainer> assignedContainers) {
        return assignedContainers.stream()
                .map(AssignmentsTransformer::fromValue)
                .collect(toList());
    }

    private static ContainerAssignment fromValue(AssignedContainer assignedContainer) {
        ContainerAssignment assignment = new ContainerAssignment();
        assignment.setIDName(assignedContainer.idName());
        assignment.setIsPrimary(assignedContainer.isPrimary());
        return assignment;
    }

    static Collection<AssignedContainer> toValue(Collection<ContainerAssignment> assignments) {
        return assignments.stream()
                .map(AssignmentsTransformer::toValue)
                .collect(toList());
    }

    private static AssignedContainer toValue(ContainerAssignment assignment) {
        return builder()
                .idName(assignment.getIDName())
                .isPrimary(assignment.isIsPrimary())
                .build();
    }
}
