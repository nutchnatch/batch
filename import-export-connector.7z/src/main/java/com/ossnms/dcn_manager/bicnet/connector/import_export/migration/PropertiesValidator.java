package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;

import static com.google.common.collect.ImmutableMap.copyOf;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.testingKey;

public class PropertiesValidator implements Function<Map<String, String>, Map<String, String>> {

    private final Map<String, Predicate<String>> validators;

    /**
     * Configuration for validation
     *
     * @param validators map of 'key' -> 'value predicate'
     */
    public PropertiesValidator(Map<String, Predicate<String>> validators) {
        this.validators = validators;
    }

    /**
     * For each key from mapping if value does not satisfy predicate it is removed from properties
     */
    @Override public Map<String, String> apply(Map<String, String> properties) {
        Map<String, String> result = new HashMap<>(properties);

        validators.entrySet().stream()
                .filter(testingKey(result::containsKey))
                .forEach(validator -> validateProperty(validator.getKey(), validator.getValue(), result));

        return copyOf(result);
    }

    /**
     * If value in map for specified key does not satisfy predicate value is removed from map
     */
    private void validateProperty(String key, Predicate<String> predicate, Map<String, String> map) {
        map.merge(key, "ignored value",
                (value, ignoredValue) -> predicate.test(value) ? value : null);
    }
}
