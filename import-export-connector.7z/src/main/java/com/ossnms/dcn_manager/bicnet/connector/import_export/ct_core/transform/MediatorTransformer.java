package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Mediator;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;

import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.AddressTransformer.ipFor;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.parseInt;
import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorValueObject.builder;
import static java.lang.String.join;
import static java.util.Collections.emptyList;

public final class MediatorTransformer {

    private MediatorTransformer() {
    }

    public static MediatorValueObject toMediatorVO(Mediator mediator, String type) {
        String name = join("_", mediator.getName(), type);
        Optional<Integer> concurrentActivationsLimit = parseInt(mediator.getConcurrentActivationsLimit())
                .filter(limit -> limit > 0); // 0 is invalid value - property should be removed

        return builder()
                .mediatorId(1)
                .name(name)
                .type(type)
                .host(ipFor(host(type, mediator)))
                .mediatorInstances(emptyList())
                .reconnectInterval(parseInt(mediator.getReconnectInterval()))
                .concurrentActivationsLimit(concurrentActivationsLimit)
                .concurrentActivationsLimited(concurrentActivationsLimit.isPresent())
                .build();
    }

    private static String host(String type, Mediator mediator) {
        return "UNO".equals(type) 
                ? "127.0.0.1" 
                : mediator.getHost();
    }
}
