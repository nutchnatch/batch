package com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.legacy.NE;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.DataTransferSettingsMigration;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.NeTypeMigration;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PasswordMigration;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PropertiesValuesMapper;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.function.Function;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.DataTransferSettingsMigration.ftpKeys;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PasswordMigration.MAPPINGS_RECRYPT;
import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeValueObject.builder;

public class TransformNE implements Function<NE, NeValueObject> {

    private final StaticConfiguration configuration;
    private final boolean importSftp;

    public TransformNE(StaticConfiguration configuration, boolean importSftp) {
        this.configuration = configuration;
        this.importSftp = importSftp;
    }

    @Override public NeValueObject apply(@Nonnull final NE ne) {
        String neType = new NeTypeMigration().migrate(ne.getType());

        Map<String, String> properties = new TransformProperties()
                .andThen(new RemoveUnsupportedProperties())
                .andThen(new PropertiesValuesMapper(of(ne.getType(), neType)))
                .andThen(new PasswordMigration(MAPPINGS_RECRYPT, neType, configuration))
                .andThen(new ReadWriteCommunityMigration())
                .andThen(new DataTransferSettingsMigration(importSftp, ftpKeys(neType, configuration)))
                .apply(ne.getProperty());

        return builder()
                .name(ne.getIDName())
                .type(neType)
                .channel(ne.getParentEM())
                .propertyBag(properties)
                .build();
    }
}
