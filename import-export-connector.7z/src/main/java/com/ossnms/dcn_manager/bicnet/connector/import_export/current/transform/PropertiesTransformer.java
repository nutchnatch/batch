package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.Property;

import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.mappingEntry;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

public class PropertiesTransformer implements Function<Collection<Property>, Map<String, String>> {

    public static Collection<Property> transform(Map<String, String> propertiesBag) {
        return propertiesBag.entrySet().stream()
                .map(mappingEntry(PropertiesTransformer::newProperty))
                .collect(toList());
    }

    private static Property newProperty(String name, String value) {
        Property property = new Property();
        property.setName(name);
        property.setValue(value);
        return property;
    }

    public static Map<String, String> transform(Collection<Property> properties) {
        return properties.stream().collect(toMap(Property::getName, Property::getValue, (oldV, newV) -> newV));
    }

    @Override public Map<String, String> apply(Collection<Property> properties) {
        return transform(properties);
    }

}
