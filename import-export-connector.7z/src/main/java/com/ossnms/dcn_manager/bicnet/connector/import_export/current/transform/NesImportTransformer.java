package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.NeTypeTaxonomy;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.NetworkElement;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.DataTransferSettingsMigration;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.NePropertyMigration;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.NeTypeMigration;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PropertiesValuesMapper;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PropertyRemover;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeValueObject.Builder;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;

import java.util.Map;
import java.util.function.Function;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform.NesExportTransformer.EXPORT_ONLY_PROPERTIES;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.DataTransferSettingsMigration.ftpKeys;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames.RECONNECT_INTERVAL;
import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeValueObject.builder;
import static java.util.Optional.ofNullable;

public class NesImportTransformer implements Function<NetworkElement, NeValueObject> {

    private final boolean importSftp;
    private final StaticConfiguration configuration;

    public NesImportTransformer(boolean importSftp, StaticConfiguration configuration) {
        this.importSftp = importSftp;
        this.configuration = configuration;
    }

    @Override public NeValueObject apply(NetworkElement networkElement) {
        return toValue(networkElement);
    }

    private NeValueObject toValue(NetworkElement ne) {
        String neType = new NeTypeMigration().apply(ne.getType());

        Map<String, String> properties = new PropertiesTransformer()
                .andThen(new PropertiesValuesMapper(of(ne.getType(), neType)))
                .andThen(new NePropertyMigration(ne.getType()))
                .andThen(new PropertyRemover(RECONNECT_INTERVAL)) // remove internal properties exported when there was no mapping and that now will clear valid values.
                .andThen(new PropertyRemover(EXPORT_ONLY_PROPERTIES.keySet()))
                .andThen(new DataTransferSettingsMigration(importSftp, ftpKeys(neType, configuration)))
                .apply(ne.getProperty());

        Builder builder = builder()
                .name(ne.getIDName())
                .type(neType)
                .channel(ne.getParentEM())
                .systemContainer(ofNullable(ne.getSystemContainer()))
                .familyLabel(ofNullable(ne.getNeTypeTaxonomy()).map(NeTypeTaxonomy::getNeFamilyLabel))
                .typeLabel(ofNullable(ne.getNeTypeTaxonomy()).map(NeTypeTaxonomy::getNeTypeLabel))
                .subTypeLabel(ofNullable(ne.getNeTypeTaxonomy()).map(NeTypeTaxonomy::getNeSubTypeLabel))
                .assignedContainers(AssignmentsTransformer.toValue(ne.getAssignedContainer()))
                .propertyBag(properties);

        return builder.build();
    }
}
