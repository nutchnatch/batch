package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.NE;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.DataTransferSettingsMigration;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PropertiesKeysMapper;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.KeysMapping.NE_KEYS;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.DataTransferSettingsMigration.ftpKeys;
import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeValueObject.builder;
import static java.util.Optional.ofNullable;

public class NeTransformerCT implements NeTransformer {

    private final NeTypeResolver neTypeResolver;
    private final StaticConfiguration configuration;
    private final boolean importSftp;

    public NeTransformerCT(StaticConfiguration configuration, boolean importSftp) {
        this.importSftp = importSftp;
        this.configuration = configuration;
        neTypeResolver = new NeTypeResolver(configuration.getNeTypes());
    }

    @Override public Optional<NeValueObject> apply(NE ne) {
        return transform(ne);
    }

    public Optional<NeValueObject> transform(NE ne) {
        Map<String, String> properties = new PropertiesTransformer()
                .andThen(new PropertiesKeysMapper(NE_KEYS))
                .andThen(importSftp())
                .apply(ne.getPropContainer());

        return ofNullable(neTypeResolver.neTypeFrom(properties))
                .map(type -> neFrom(ne, properties, type));
    }

    private NeValueObject neFrom(NE ne, Map<String, String> properties, String type) {
        return builder()
                .name(ne.getIDName())
                .type(type)
                .channel("") // channel is resolved later
                .propertyBag(properties)
                .build();
    }

    private Function<Map<String, String>, Map<String, String>> importSftp() {
        return map -> ofNullable(neTypeResolver.neTypeFrom(map))
                .map(type -> new DataTransferSettingsMigration(importSftp, ftpKeys(type, configuration)))
                .map(migration -> migration.apply(map))
                .orElse(map);
    }
}
