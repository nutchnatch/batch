package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.mappingKey;
import static java.util.stream.Collectors.toMap;

public class PropertiesKeysMapper implements Function<Map<String, String>, Map<String, String>> {

    private final Map<String, String> keyMapping;

    /**
     * Configuration for mapper 'old key' -> 'new key'
     */
    public PropertiesKeysMapper(Map<String, String> keyMapping) {
        this.keyMapping = keyMapping;
    }

    /**
     * Replaces keys in bag with new according to mapping
     *
     * @return new map with replaced keys
     */
    Map<String, String> translateKeys(Map<String, String> bag) {
        return bag.entrySet().stream()
                .map(mappingKey(key -> keyMapping.getOrDefault(key, key)))
                .collect(toMap(Entry::getKey, Entry::getValue, (oldV, newV) -> newV));
    }

    @Override public Map<String, String> apply(Map<String, String> map) {
        return translateKeys(map);
    }
}
