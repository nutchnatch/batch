package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toMap;
import static org.apache.commons.lang3.StringUtils.contains;
import static org.apache.commons.lang3.StringUtils.replaceOnce;

/**
 * Splits address properties into pair of properties for each IP and PORT 
 */
public class AddressSplit implements Function<Map<String, String>, Map<String, String>> {

    private static final String DEFAULT_PORT = "161";
    private final Map<String, String> addressPortPrefix;

    /**
     * @param addressPortPrefix map from address prefix to port prefix key
     */
    public AddressSplit(Map<String, String> addressPortPrefix) {
        this.addressPortPrefix = addressPortPrefix;
    }

    @Override public Map<String, String> apply(Map<String, String> properties) {
        return properties.entrySet().stream()
                .flatMap(this::splitAddressEntry)
                .collect(toMap(Entry::getKey, Entry::getValue));
    }

    /**
     * Given entry splits it into 2 ip/port entries or returns original one
     */
    private Stream<Entry<String, String>> splitAddressEntry(Entry<String, String> entry) {
        return splitKey(entry.getKey())
                .map(keys -> {
                    Pair<String, String> ipPort = splitAddressValue(entry.getValue());
                    return Stream.<Entry<String, String>>of(
                            Pair.of(keys.getLeft(), ipPort.getLeft()),
                            Pair.of(keys.getRight(), ipPort.getRight())
                    );
                })
                .orElse(Stream.of(entry));
    }

    /**
     * Given an property key returns pair of ip/port keys or nothing if it is not a address key
     */
    private Optional<Pair<String, String>> splitKey(String addressKey) {
        return addressPortPrefix.keySet().stream()
                .filter(addressKey::startsWith).findAny()
                .map(addressPrefix -> replaceOnce(addressKey, addressPrefix, addressPortPrefix.get(addressPrefix)))
                .map(portKey -> Pair.of(addressKey, portKey));
    }

    /**
     * Given address value splits it into ip/port pair
     */
    private Pair<String, String> splitAddressValue(String address) {
        if (contains(address, ":")) {
            String[] pair = StringUtils.split(address, ":");
            String ip = pair[0];
            String port = pair[1];
            return Pair.of(ip, port);
        } else {
            return Pair.of(address, DEFAULT_PORT);
        }

    }
}
