package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.filterOut;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.testingKey;
import static java.util.Collections.emptyList;

public class DataTransferSettingsMigration implements Function<Map<String, String>, Map<String, String>> {

    private final Boolean importSftp;
    private final Collection<String> ftpKeys;

    public DataTransferSettingsMigration(Boolean importSftp, Collection<String> ftpKeys) {
        this.importSftp = importSftp;
        this.ftpKeys = ftpKeys;
    }

    @Override public Map<String, String> apply(Map<String, String> map) {
        return importSftp
                ? map
                : filterOut(map, testingKey(ftpKeys::contains));
    }

    /**
     * For given neType resolves configured ftp/sftp properties keys
     */
    public static Collection<String> ftpKeys(String neType, StaticConfiguration configuration) {
        return Optional.ofNullable(configuration.getNeTypes().get(neType))
                .map(NeType::getDataTransferSettings)
                .map(DataTransferSettingsMigration::keysAndValues)
                .orElse(emptyList());
    }

    /**
     * Flattens map of keys and values into collection of keys and values
     */
    private static <T> Collection<T> keysAndValues(Map<T, T> map) {
        return ImmutableSet.<T>builder()
                .addAll(map.values())
                .addAll(map.keySet())
                .build();
    }
}
