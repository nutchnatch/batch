package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.Domain;

import java.util.List;

import static java.util.stream.Collectors.toList;

public final class Domains {

    private Domains() {
    }

    public static List<Domain> transform(List<String> domainNames) {
        return domainNames.stream()
                .map(Domains::newDomain)
                .collect(toList());
    }

    private static Domain newDomain(String domainName) {
        Domain domain = new Domain();
        domain.setName(domainName);
        return domain;
    }
}
