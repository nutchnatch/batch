package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import com.google.common.collect.ImmutableMap;
import org.apache.commons.lang3.StringUtils;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.filterOut;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.mappingValue;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.testingKey;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.testingValue;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toMap;
import static java.util.stream.Collectors.toSet;
import static org.apache.commons.lang3.StringUtils.substring;

public class MergeProperties implements Function<Map<String, String>, Map<String, String>> {
    private final Map<String, Collection<String>> mapping;
    private final int limit;

    /**
     * @param mapping configuration for merging 'new property' -> [old properties]
     * @param limit maximum number of characters for merged value
     */
    public MergeProperties(Map<String, Collection<String>> mapping, int limit) {
        this.mapping = mapping;
        this.limit = limit;
    }

    /**
     * For given properties merges set of properties under new key
     */
    @Override public Map<String, String> apply(Map<String, String> properties) {
        return ImmutableMap.<String, String>builder()
                .putAll(joinedValues(properties, mapping))
                .putAll(withoutJoiningValues(properties, mapping))
                .build();
    }

    /**
     * For given properties provide only entries that are not going to be merged
     */
    private Map<String, String> withoutJoiningValues(Map<String, String> properties, Map<String, Collection<String>> mapping) {
        Collection<String> joiningKeys = mapping.values().stream().flatMap(Collection::stream).collect(toSet());
        return filterOut(properties, testingKey(joiningKeys::contains));
    }

    /**
     * For given properties provides only merged entries
     */
    private Map<String, String> joinedValues(Map<String, String> properties, Map<String, Collection<String>> mapping) {
        return mapping.entrySet().stream()
                .map(mappingValue(joiningKeys -> joinValues(joiningKeys, properties, ", ")))
                .filter(testingValue(StringUtils::isNoneEmpty))
                .map(mappingValue(value -> substring(value, 0, limit)))
                .collect(toMap(Entry::getKey, Entry::getValue));
    }

    private String joinValues(Collection<String> keys, Map<String, String> properties, String delimiter) {
        return keys.stream()
                .map(properties::get)
                .filter(StringUtils::isNoneEmpty)
                .collect(joining(delimiter));
    }
}
