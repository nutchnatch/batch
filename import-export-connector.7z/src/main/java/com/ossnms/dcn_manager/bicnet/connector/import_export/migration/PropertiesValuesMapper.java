package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.mappingValue;
import static java.util.stream.Collectors.toMap;

public class PropertiesValuesMapper implements Function<Map<String, String>, Map<String, String>> {

    private final Map<String, String> valueMapping;

    public PropertiesValuesMapper(Map<String, String> valueMapping) {
        this.valueMapping = valueMapping;
    }

    /**
     * Replaces keys in bag for new according to mapping
     *
     * @return new map with replaced keys
     */
    private Map<String, String> translateValues(Map<String, String> bag) {
        return bag.entrySet().stream()
                .map(mappingValue(value -> valueMapping.getOrDefault(value, value)))
                .collect(toMap(Entry::getKey, Entry::getValue));
    }

    @Override public Map<String, String> apply(Map<String, String> map) {
        return translateValues(map);
    }
}
