package com.ossnms.dcn_manager.bicnet.connector.import_export;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.Channel;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.GenericContainer;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.Mediator;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.NetworkElement;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.SystemContainer;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportExportService;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform.Channels;
import com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform.ContainersTransformer;
import com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform.Mediators;
import com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform.NesExportTransformer;
import com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform.NesImportTransformer;
import com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform.SystemsTransformer;
import com.ossnms.dcn_manager.bicnet.connector.import_export.outbound.ExportNeAdditionalInfo;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.commands.import_export.ExportChannels;
import com.ossnms.dcn_manager.commands.import_export.ExportContainers;
import com.ossnms.dcn_manager.commands.import_export.ExportMediators;
import com.ossnms.dcn_manager.commands.import_export.ExportNes;
import com.ossnms.dcn_manager.commands.import_export.ExportSystems;
import com.ossnms.dcn_manager.commands.import_export.ImportChannels;
import com.ossnms.dcn_manager.commands.import_export.ImportContainers;
import com.ossnms.dcn_manager.commands.import_export.ImportMediators;
import com.ossnms.dcn_manager.commands.import_export.ImportNEs;
import com.ossnms.dcn_manager.commands.import_export.ImportSystems;
import com.ossnms.dcn_manager.composables.channel.ChannelCreationBase;
import com.ossnms.dcn_manager.composables.container.ContainerCreationBase;
import com.ossnms.dcn_manager.composables.container.ContainersNeAssignmentUpdater;
import com.ossnms.dcn_manager.composables.container.ContainersSystemAssignmentUpdater;
import com.ossnms.dcn_manager.composables.container.SystemCreationBase;
import com.ossnms.dcn_manager.composables.container.SystemValidator;
import com.ossnms.dcn_manager.composables.import_export.channel.ExportChannelTransformer;
import com.ossnms.dcn_manager.composables.import_export.channel.ImportChannelTransformer;
import com.ossnms.dcn_manager.composables.import_export.container.ExportContainerTransformer;
import com.ossnms.dcn_manager.composables.import_export.container.ImportContainerTransformer;
import com.ossnms.dcn_manager.composables.import_export.mediator.ImportMediatorTransformer;
import com.ossnms.dcn_manager.composables.import_export.ne.ExportNeTransformer;
import com.ossnms.dcn_manager.composables.import_export.ne.ImportNeTransformer;
import com.ossnms.dcn_manager.composables.import_export.system.ExportSystemTransformer;
import com.ossnms.dcn_manager.composables.import_export.system.ImportSystemTransformer;
import com.ossnms.dcn_manager.composables.mediator.MediatorCreationBase;
import com.ossnms.dcn_manager.composables.ne.NeCreationBase;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.import_export.identification.ChannelIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.GenericContainerIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.MediatorIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.NeIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.SystemContainerIdentification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ContainerValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.outbound.SystemNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.Collection;
import java.util.function.Function;

import static java.util.Objects.requireNonNull;
import static java.util.stream.Collectors.toList;

@Stateless(name = "ImportExportServiceBean")
@Local(ImportExportService.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ImportExportServiceBean implements ImportExportService {

    @Inject private MediatorManagers mediatorManagers;
    @Inject private ChannelManagers channelManagers;
    @Inject private NetworkElementManagers neManagers;
    @Inject private LoggerManagerImpl loggerManager;
    @Inject private StaticConfiguration configuration;
    @Inject private DomainManagers domainManagers;
    @Inject private ContainerNotifications containerNotifications;
    @Inject private SystemNotifications systemNotifications;
    @Inject private ExportNeAdditionalInfo neAdditionalInfo;
    @Inject @DcnManager private JpaContainerRepositoryBean containerRepository;
    @Inject @DcnManager private JpaSettingsRepositoryBean settingsRepository;
    @Inject @DcnManager private ChannelSchedulingConfiguration channelScheduling;
    @Inject @DcnManager private MediatorSchedulingConfiguration mediatorScheduling;
    @Inject @DcnManager private JpaSystemRepositoryBean systemRepository;

    @Override
    public Collection<Mediator> exportMediators(ISessionContext context, Collection<IMediator> mediators) {
        requireNonNull(context);
        requireNonNull(mediators);

        Collection<MediatorValueObject> mediatorValues = new ExportMediators<>(
                new BicnetCallContext(context),
                mediators,
                mediatorManagers,
                loggerManager
        ).call();

        return forAll(mediatorValues, Mediators::transform);
    }

    @Override public Collection<Channel> exportChannels(ISessionContext context, Collection<IEM> ems) {
        requireNonNull(context);
        requireNonNull(ems);

        Collection<ChannelValueObject> chanelValues = new ExportChannels<>(
                new BicnetCallContext(context),
                ems,
                channelManagers.getChannelRepository(),
                loggerManager,
                new ExportChannelTransformer(
                        mediatorManagers.getMediatorRepository(),
                        mediatorManagers.getMediatorInstanceRepository())
        ).call();

        return forAll(chanelValues, Channels::transform);
    }

    @Override public Collection<NetworkElement> exportNes(ISessionContext context, Collection<INE> nes) {
        requireNonNull(context);
        requireNonNull(nes);

        Collection<NeValueObject> neValues = new ExportNes<>(
                new BicnetCallContext(context),
                nes, 
                neManagers.getNeRepository(),
                loggerManager,
                new ExportNeTransformer(
                        channelManagers.getChannelRepository(),
                        neManagers.getNeRepository(),
                        domainManagers.getDomainRepository(),
                        configuration,
                        containerRepository,
                        systemRepository,
                        neAdditionalInfo.getExportNeAdditionalInfo(context, nes))
        ).call();

        return forAll(neValues, new NesExportTransformer());
    }

	@Override public Collection<GenericContainer> exportContainers(ISessionContext context) {
        requireNonNull(context);

        Collection<ContainerValueObject> containerValues = new ExportContainers<>(
                new BicnetCallContext(context),
                containerRepository,
                new ExportContainerTransformer(containerRepository)
        ).call();

        return forAll(containerValues, ContainersTransformer::fromValue);
    }

    @Override public Collection<SystemContainer> exportSystems(ISessionContext context) {
        requireNonNull(context);

        Collection<SystemValueObject> systemValues = new ExportSystems<>(
                new BicnetCallContext(context),
                systemRepository,
                new ExportSystemTransformer(containerRepository)
        ).call();

        return forAll(systemValues, SystemsTransformer::fromValue);
    }

    @Override public Collection<String> importMediators(ISessionContext context, Collection<Mediator> mediators) {
        requireNonNull(context);
        requireNonNull(mediators);

        BicnetCallContext callContext = new BicnetCallContext(context);
        return new ImportMediators<>(
                callContext,
                forAll(mediators, Mediators::transform),
                loggerManager,
                new ImportMediatorTransformer(configuration),
                new MediatorCreationBase<>(
                        callContext,
                        mediatorManagers.getMediatorRepository(),
                        mediatorManagers.getMediatorInstanceRepository(),
                        mediatorManagers.getMediatorNotifications(),
                        configuration,
                        mediatorScheduling,
                        loggerManager),
                new MediatorIdentification(
                        configuration.getMediatorTypes(),
                        mediatorManagers.getMediatorRepository().getMediatorInfoRepository())
        ).call();
    }

    @Override public Collection<String> importChannels(ISessionContext context, Collection<Channel> channels) {
        requireNonNull(context);
        requireNonNull(channels);

        BicnetCallContext callContext = new BicnetCallContext(context);
        return new ImportChannels<>(
                callContext,
                forAll(channels, Channels::transform),
                loggerManager,
                new ChannelIdentification(
                        channelManagers.getChannelRepository()),
                new ChannelCreationBase<>(
                        callContext,
                        channelManagers.getChannelRepository(),
                        channelManagers.getChannelNotifications(),
                        channelManagers.getChannelInstanceConnections(),
                        channelScheduling,
                        mediatorManagers.getMediatorRepository(),
                        mediatorManagers.getMediatorInstanceRepository(),
                        loggerManager),
                new ImportChannelTransformer(
                        configuration,
                        new MediatorIdentification(
                                configuration.getMediatorTypes(),
                                mediatorManagers.getMediatorRepository().getMediatorInfoRepository()))
        ).call();
    }

    @Override
    public Collection<String> importNes(ISessionContext context, Collection<NetworkElement> networkElements, boolean importSftp) {
        requireNonNull(context);
        requireNonNull(networkElements);

        final BicnetCallContext bicnetCallContext = new BicnetCallContext(context);
        return new ImportNEs<>(
                bicnetCallContext,
                forAll(networkElements, new NesImportTransformer(importSftp, configuration)),
                loggerManager,
                new ContainersNeAssignmentUpdater<>(
                        settingsRepository,
                        containerRepository,
                        systemRepository,
                        containerNotifications,
                        loggerManager,
                        bicnetCallContext),
                new NeIdentification(neManagers.getNeRepository().getNeUserPreferencesRepository()),
                new GenericContainerIdentification(containerRepository),
                new ImportNeTransformer(
                        new ChannelIdentification(channelManagers.getChannelRepository()),
                        new SystemContainerIdentification(systemRepository),
                        configuration),
                new NeCreationBase<>(bicnetCallContext,
                        neManagers.getNeRepository(),
                        neManagers.getNeInstanceRepository(),
                        neManagers.getNeNotifications(),
                        channelManagers.getChannelRepository(),
                        systemRepository,
                        channelManagers.getChannelInstanceConnections(),
                        loggerManager)
        ).call();
    }

    @Override
    public Collection<String> importContainers(ISessionContext sessionContext, Collection<GenericContainer> containers) {
        requireNonNull(sessionContext);
        requireNonNull(containers);

        return new ImportContainers<>(
                new BicnetCallContext(sessionContext),
                forAll(containers, ContainersTransformer::toValue),
                new ContainerCreationBase<>(
                        new BicnetCallContext(sessionContext),
                        containerRepository,
                        systemRepository,
                        containerNotifications,
                        loggerManager),
                new ImportContainerTransformer(
                        new GenericContainerIdentification(containerRepository))
        ).call();
    }

    @Override
    public Collection<String> importSystems(ISessionContext sessionContext, Collection<SystemContainer> systems) {
        requireNonNull(sessionContext);
        requireNonNull(systems);

        return new ImportSystems<>(
                new BicnetCallContext(sessionContext),
                forAll(systems, SystemsTransformer::toValue),
                new ImportSystemTransformer(new SystemContainerIdentification(systemRepository)),
                new SystemCreationBase<>(
                        new BicnetCallContext(sessionContext),
                        systemRepository,
                        systemNotifications,
                        loggerManager,
                        new SystemValidator(
                                neManagers.getNeRepository().getNeUserPreferencesRepository(), 
                                systemRepository, 
                                containerRepository)),
                new ContainersSystemAssignmentUpdater<>(
                        settingsRepository,
                        containerRepository,
                        systemRepository,
                        containerNotifications,
                        loggerManager,
                        new BicnetCallContext(sessionContext)),
                new GenericContainerIdentification(containerRepository)
        ).call();
    }

    private <I, O> Collection<O> forAll(Collection<I> collection, Function<I, O> mapping) {
        return collection.stream().map(mapping).collect(toList());
    }
}
