package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.Types;

import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;

import static java.util.stream.Collectors.toMap;
import static org.apache.commons.lang3.StringUtils.substringBetween;
import static org.apache.commons.lang3.StringUtils.upperCase;
import static org.apache.commons.lang3.tuple.ImmutablePair.of;

class NeTypeResolver implements Function<Map<String, String>, String> {
    private final Map<String, String> controllerIdToType;

    private static final String NEC_TYPE_ID = "38250635-F75A-4F6B-8D66-50A014D40A55/NecTypeId";
    private static final String NE_CONTROLLER_ID = "NE_CONTROLLER_ID";

    NeTypeResolver(Types<NeType> neTypes) {
        controllerIdToType = neTypes.values().stream()
                .map(neType -> of(controllerId(neType), neType.getName()))
                .collect(toMap(Entry::getKey, Entry::getValue, (s1, s2) -> s1));
    }

    /**
     * Given Core/CT properties resolves NE Type name
     */
    String neTypeFrom(Map<String, String> properties) {
        return controllerIdToType.get(controllerId(properties));
    }

    private String controllerId(NeType neType) {
        return upperCase(neType.getTypeProperties().get(NE_CONTROLLER_ID));
    }

    private String controllerId(Map<String, String> properties) {
        return upperCase(substringBetween(properties.get(NEC_TYPE_ID), "{", "}"));
    }

    @Override public String apply(Map<String, String> properties) {
        return neTypeFrom(properties);
    }
}
