package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.dcn_manager.bicnet.client.api.exception.DcnClientException;

/**
 * Exception for repository use cases. 
 */
public class RepositoryException extends DcnClientException {

    private static final long serialVersionUID = -7038118489784978781L;

    public RepositoryException() {
    }

    public RepositoryException(String message) {
        super(message);
    }

    public RepositoryException(Throwable cause) {
        super(cause);
    }

    public RepositoryException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public RepositoryException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    public RepositoryException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }
}
