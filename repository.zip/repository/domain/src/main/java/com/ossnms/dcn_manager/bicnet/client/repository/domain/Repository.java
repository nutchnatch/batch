package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.Searchable;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

/**
 * Manage a element to abstracts the repository access (remote services, cache).
 *  
 * @param <K> element Key
 * @param <V> element Value
 */
public interface Repository<K, V> {

    /**
     * Gets a element by id.
     * 
     * @param key
     * @return
     */
    Optional<V> get(K key) throws RepositoryException;

    /**
     * Gets elements by id.
     * 
     * @param key The elements keys
     * @return A collection of elements
     */
    Collection<V> get(Collection<K> key) throws RepositoryException;

    /**
     * @return All elements
     */
    Collection<V> getAll() throws RepositoryException;

    /**
     * @return A searchable interface with a collection of queries.
     */
    Searchable<V> queries() throws RepositoryException;

    /**
     * Remove a group of elements.
     * 
     * @param sessionContext
     * @param keys
     * @throws RepositoryException
     */
    void remove(ISessionContext sessionContext, Collection<K> keys) throws RepositoryException;
    
    /**
     * Remove a element.
     * 
     * @param sessionContext
     * @param key
     * @throws RepositoryException
     */
    void remove(ISessionContext sessionContext, K key) throws RepositoryException;

    /**
     * Creates a new element.
     * 
     * @param sessionContext
     * @param element
     * @param properties
     * @throws RepositoryException
     */
    void create(ISessionContext sessionContext, V element, Map<String, String> properties)
            throws RepositoryException;

    /**
     * Create a new element with through a template.
     *
     * @param sessionContext
     * @param template contains the base attributes to create a new element
     * @param properties
     * @throws RepositoryException
     */
    default void duplicate(ISessionContext sessionContext, V template, Map<String, String> properties)
            throws RepositoryException {
        throw new RepositoryException("Unsupported operation.");
    }

    /**
     * Updates a element properties.
     * 
     * @param sessionContext
     * @param element
     * @param properties
     * @throws RepositoryException
     */
    void update(ISessionContext sessionContext, V element, Map<String, String> properties)
            throws RepositoryException;
    
    /**
     * Gets the element properties.
     * 
     * @param sessionContext
     * @param key
     * @return
     * @throws RepositoryException
     */
    Map<String, String> getProperties(ISessionContext sessionContext, K key) throws RepositoryException;
    
    /**
     * @return The registered types on installation.
     * @param sessionContext
     * @param parentType
     */
    Collection<String> getRegisteredTypes(@Nonnull final ISessionContext sessionContext, @Nonnull
            Optional<String> parentType)
            throws RepositoryException;
}