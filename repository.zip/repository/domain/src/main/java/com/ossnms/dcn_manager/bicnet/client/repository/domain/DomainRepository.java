package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.DomainSearchable;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

/**
 * Facade to access the InMemoryRepository based on client cache and the Remote Server Repository facade.
 */
public class DomainRepository extends CacheInMemoryRepository<Integer, IAS> {

    public DomainRepository(@Nonnull final CacheWrapper<Integer, IAS> cache) {
        super(cache);
    }
    
    /**
     * Method not supported for Domains.
     * @throws UnsupportedOperationException
     */
    @Override
    public void update(@Nonnull ISessionContext sessionContext, @Nonnull IAS em,@Nonnull Map<String, String> properties) throws RepositoryException {
        throw new UnsupportedOperationException();
    }

    /**
     * Method not supported for Domains.
     * @throws UnsupportedOperationException
     */
    @Override
    public void remove(ISessionContext sessionContext, Collection<Integer> keys) throws RepositoryException {
        throw new UnsupportedOperationException();
    }

    /**
     * Method not supported for Domains.
     * @throws UnsupportedOperationException
     */
    @Override
    public void remove(ISessionContext sessionContext, Integer key) throws RepositoryException {
        throw new UnsupportedOperationException();
    }

    /**
     * Method not supported for Domains.
     * @throws UnsupportedOperationException
     */
    @Override
    public void create(ISessionContext sessionContext, IAS element, Map<String, String> properties) throws RepositoryException {
        throw new UnsupportedOperationException();
    }

    /**
     * Method not supported for Domains.
     * @throws UnsupportedOperationException
     */
    @Override
    public Map<String, String> getProperties(ISessionContext sessionContext, Integer key) throws RepositoryException {
        throw new UnsupportedOperationException();
    }

    /**
     * Method not supported for Domains.
     * @throws UnsupportedOperationException
     */
    @Override
    public Collection<String> getRegisteredTypes(ISessionContext sessionContext, Optional<String> parentType) throws RepositoryException {
        throw new UnsupportedOperationException();
    }

    @Override public DomainSearchable queries() throws RepositoryException {
        return (DomainSearchable) super.queries();
    }
}
