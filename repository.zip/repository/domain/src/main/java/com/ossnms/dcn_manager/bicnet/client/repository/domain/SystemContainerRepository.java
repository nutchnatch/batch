package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerMarkable;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.SystemSearchable;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.google.common.collect.Maps.filterKeys;
import static com.ossnms.dcn_manager.bicnet.client.api.Containers.ROOT_CONTAINER_ID;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownContainerPropertyNames.DESCRIPTION;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownContainerPropertyNames.ID_NAME;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownContainerPropertyNames.USER_TEXT;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.CONTAINER_ID;
import static org.apache.commons.lang3.math.NumberUtils.toInt;

/**
 * Facade to access the InMemoryRepository based on client cache and the Remote Server Repository facade.
 */
public class SystemContainerRepository extends CacheInMemoryRepository<Integer, ISystemContainer> {

    private final BicnetServerFacade serverFacade;

    public SystemContainerRepository(@Nonnull final BicnetServerFacade serverFacade,
            @Nonnull final CacheWrapper<Integer, ISystemContainer> cache) {
        super(cache);
        this.serverFacade = serverFacade;
    }

    @Override public void remove(ISessionContext sessionContext, Integer key) throws RepositoryException {
        try {
            serverFacade.getDcnPublicServices().deleteSystemContainer(sessionContext, new SystemContainerIdItem(key));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override public void remove(@Nonnull final ISessionContext sessionContext, @Nonnull final Collection<Integer> keys)
            throws RepositoryException {
        try {
            serverFacade.getSystemContainerService().deleteSystemContainers(sessionContext,
                    keys.stream().map(SystemContainerIdItem::new).collect(Collectors.toList()));
        } catch (BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override public void create(@Nonnull final ISessionContext sessionContext, @Nonnull final ISystemContainer element,
            @Nonnull final Map<String, String> properties) throws RepositoryException {
        final Collection<String> transientKeys = Collections.singletonList(CONTAINER_ID);
        final Map<String, String> transientProperties = filterKeys(properties, transientKeys::contains);

        final Integer containerId = toInt(transientProperties.get(CONTAINER_ID), ROOT_CONTAINER_ID);
        final GenericContainerIdItem container = new GenericContainerIdItem(containerId);

        try {
            element.setDescription(properties.get(DESCRIPTION));
            element.setIdName(properties.get(ID_NAME));
            element.setUserLabel(properties.get(USER_TEXT));

            serverFacade.getSystemContainerService().createSystemContainer(sessionContext, element, container);
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override public void update(ISessionContext sessionContext, ISystemContainer element,
            Map<String, String> properties) throws RepositoryException {

        final ISystemContainerMarkable markable = SystemContainerItem.markableSystemContainer(null);

        markable.setId(element.getId());

        if (properties.get(ID_NAME) != null) {
            markable.setIdName(properties.get(ID_NAME));
        }

        if (properties.get(DESCRIPTION) != null) {
            markable.setDescription(properties.get(DESCRIPTION));
        }

        if (properties.get(USER_TEXT) != null) {
            markable.setUserLabel(properties.get(USER_TEXT));
        }

        try {
            serverFacade.getDcnPublicServices().modifySystemContainer(sessionContext, markable);
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override public Map<String, String> getProperties(ISessionContext sessionContext, Integer key)
            throws RepositoryException {
        ISystemContainer container = get(key).orElseThrow(() -> new RepositoryException("Container not found"));
        final Map<String, String> properties = new HashMap<>();
        properties.put(ID_NAME, container.getIdName());
        properties.put(DESCRIPTION, container.getDescription());
        properties.put(USER_TEXT, container.getUserLabel());
        return properties;
    }

    @Override public Collection<String> getRegisteredTypes(@Nonnull ISessionContext sessionContext,
            @Nonnull Optional<String> parentType) throws RepositoryException {
        return Collections.emptyList();
    }

    @Override public SystemSearchable queries() throws RepositoryException {
        return (SystemSearchable) super.queries();
    }
}
