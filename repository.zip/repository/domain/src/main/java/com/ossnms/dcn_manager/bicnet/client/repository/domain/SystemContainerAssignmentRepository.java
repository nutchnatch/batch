package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.SystemAssignmentSearchable;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;

public class SystemContainerAssignmentRepository extends CacheInMemoryRepository<ISystemGenericContainerAssignmentId, ISystemGenericContainerAssignment> {

    public SystemContainerAssignmentRepository(CacheWrapper<ISystemGenericContainerAssignmentId, ISystemGenericContainerAssignment> cache) {
        super(cache);
    }

    @Override
    public void remove(ISessionContext sessionContext, Collection<ISystemGenericContainerAssignmentId> keys) throws RepositoryException {
        
    }

    @Override
    public void remove(ISessionContext sessionContext, ISystemGenericContainerAssignmentId key) throws RepositoryException {

    }

    @Override
    public void create(ISessionContext sessionContext, ISystemGenericContainerAssignment element, Map<String, String> properties) throws RepositoryException {

    }

    @Override
    public void update(ISessionContext sessionContext, ISystemGenericContainerAssignment element, Map<String, String> properties) throws RepositoryException {

    }

    @Override
    public Map<String, String> getProperties(ISessionContext sessionContext, ISystemGenericContainerAssignmentId key) throws RepositoryException {
        return emptyMap();
    }

    @Override
    public Collection<String> getRegisteredTypes(@Nonnull ISessionContext sessionContext, @Nonnull Optional<String> parentType) throws RepositoryException {
        return emptyList();
    }

    /**
     * Get all Systems ids associated to a container.
     *
     * @param containerId Assigned Container.
     * @return List of System ids that belongs to a container.
     * @throws RepositoryException
     */
    public Collection<Integer> getSystemIdList(final int containerId) throws RepositoryException {
        return  queries().findByContainerId(containerId)
                .stream()
                .map(ISystemGenericContainerAssignment::getSystemContainerId)
                .collect(Collectors.toList());
    }

    @Override public SystemAssignmentSearchable queries() throws RepositoryException {
        return (SystemAssignmentSearchable) super.queries();
    }
}
