package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.MediationSearchable;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Facade to access the InMemoryRepository based on client cache and the Remote Server Repository facade.
 */
public class MediatorRepository extends CacheInMemoryRepository<Integer, FullMediatorData> {

    private final BicnetServerFacade serverFacade;

    public MediatorRepository(@Nonnull final BicnetServerFacade serverFacade, @Nonnull final CacheWrapper<Integer, FullMediatorData> cache) {
        super(cache);
        this.serverFacade = serverFacade;
    }

    @Override
    public void update(@Nonnull ISessionContext sessionContext, @Nonnull FullMediatorData mediator,
            @Nonnull Map<String, String> properties) throws RepositoryException {
        try {
            serverFacade.getMediatorService().updateProperties(sessionContext, mediator.getMediator(), properties);
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void remove(@Nonnull ISessionContext sessionContext, @Nonnull Collection<Integer> keys)
            throws RepositoryException {
        try {
            serverFacade.getMediatorService().deleteMediators(sessionContext,
                    keys.stream().map(MediatorIdItem::new).collect(Collectors.toList()));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void remove(@Nonnull ISessionContext sessionContext, @Nonnull Integer key) throws RepositoryException {
        try {
            serverFacade.getMediatorService().deleteMediator(sessionContext, new MediatorIdItem(key));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void create(@Nonnull ISessionContext sessionContext, @Nonnull FullMediatorData element,
            @Nonnull Map<String, String> properties) throws RepositoryException {
        try {
            serverFacade.getMediatorService().store(sessionContext, element.getMediator(), properties);
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Collection<String> getRegisteredTypes(@Nonnull final ISessionContext sessionContext,
            @Nonnull Optional<String> type) throws RepositoryException {
        try {
            return Arrays.asList(serverFacade.getMediatorService().getRegisteredMediatorTypes(sessionContext));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Map<String, String> getProperties(ISessionContext sessionContext, Integer key) throws RepositoryException {
        try {
            return serverFacade.getMediatorService().getProperties(sessionContext, new MediatorIdItem(key));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override public MediationSearchable queries() throws RepositoryException {
        return (MediationSearchable) super.queries();
    }
}
