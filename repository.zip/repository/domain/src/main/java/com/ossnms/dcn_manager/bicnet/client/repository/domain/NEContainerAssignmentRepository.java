package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeContainerAssignmentSearchable;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;

public class NEContainerAssignmentRepository extends CacheInMemoryRepository<INeGenericContainerAssignmentId, INeGenericContainerAssignment> {

    public NEContainerAssignmentRepository(CacheWrapper<INeGenericContainerAssignmentId, INeGenericContainerAssignment> cache) {
        super(cache);
    }

    @Override
    public void remove(ISessionContext sessionContext, Collection<INeGenericContainerAssignmentId> keys) throws RepositoryException {
        
    }

    @Override
    public void remove(ISessionContext sessionContext, INeGenericContainerAssignmentId key) throws RepositoryException {

    }

    @Override
    public void create(ISessionContext sessionContext, INeGenericContainerAssignment element, Map<String, String> properties) throws RepositoryException {

    }

    @Override
    public void update(ISessionContext sessionContext, INeGenericContainerAssignment element, Map<String, String> properties) throws RepositoryException {

    }

    @Override
    public Map<String, String> getProperties(ISessionContext sessionContext, INeGenericContainerAssignmentId key) throws RepositoryException {
        return emptyMap();
    }

    @Override
    public Collection<String> getRegisteredTypes(@Nonnull ISessionContext sessionContext, @Nonnull Optional<String> parentType) throws RepositoryException {
        return emptyList();
    }

    /**
     * Get all NE ids associated to a container.
     *
     * @param containerId Assigned Container.
     * @return List of NE ids that belongs to a container.
     * @throws RepositoryException
     */
    public Collection<Integer> getNeIdList(final int containerId) throws RepositoryException {
        return  queries().findByContainerId(containerId)
                .stream()
                .map(INeGenericContainerAssignment::getNetworkElementId)
                .collect(Collectors.toList());
    }

    @Override public NeContainerAssignmentSearchable queries() throws RepositoryException {
        return (NeContainerAssignmentSearchable) super.queries();
    }
}
