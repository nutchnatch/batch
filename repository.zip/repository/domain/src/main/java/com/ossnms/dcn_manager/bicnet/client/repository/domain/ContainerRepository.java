package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerMarkable;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.ContainerSearchable;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownContainerPropertyNames.DESCRIPTION;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownContainerPropertyNames.ID_NAME;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownContainerPropertyNames.USER_TEXT;

/**
 * Facade to access the InMemoryRepository based on client cache and the Remote Server Repository facade.
 */
public class ContainerRepository extends CacheInMemoryRepository<Integer, IGenericContainer> {

    private final BicnetServerFacade serverFacade;

    public ContainerRepository(@Nonnull final BicnetServerFacade serverFacade, @Nonnull final CacheWrapper<Integer, IGenericContainer> cache) {
        super(cache);
        this.serverFacade = serverFacade;
    }

    @Override
    public void remove(ISessionContext sessionContext, Integer key) throws RepositoryException {
        try {
            serverFacade.getContainerService().deleteGenericContainer(sessionContext, new GenericContainerIdItem(key));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void remove(ISessionContext sessionContext, Collection<Integer> keys) throws RepositoryException {
        try {
            serverFacade.getContainerService().deleteGenericContainers(sessionContext,
                    keys.stream().map(GenericContainerIdItem::new).collect(Collectors.toList()));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void create(ISessionContext sessionContext, IGenericContainer element, Map<String, String> properties)
            throws RepositoryException {
        try {
            element.setDescription(properties.get(DESCRIPTION));
            element.setIdName(properties.get(ID_NAME));
            element.setUserLabel(properties.get(USER_TEXT));

            serverFacade.getContainerService().createGenericContainer(sessionContext, element);
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void update(ISessionContext sessionContext, IGenericContainer element, Map<String, String> properties)
            throws RepositoryException {

        final IGenericContainerMarkable markable = GenericContainerItem.markableGenericContainer(null);

        markable.setId(element.getId());

        if (properties.get(ID_NAME) != null) {
            markable.setIdName(properties.get(ID_NAME));
        }

        if (properties.get(DESCRIPTION) != null) {
            markable.setDescription(properties.get(DESCRIPTION));
        }

        if (properties.get(USER_TEXT) != null) {
            markable.setUserLabel(properties.get(USER_TEXT));
        }

        try {
            serverFacade.getContainerService().modifyGenericContainer(sessionContext, markable);
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Map<String, String> getProperties(ISessionContext sessionContext, Integer key) throws RepositoryException {
        IGenericContainer container = get(key)
                .orElseThrow(() -> new RepositoryException("Container not found"));
        final Map<String, String> properties = new HashMap<>();
        properties.put(ID_NAME, container.getIdName());
        properties.put(DESCRIPTION, container.getDescription());
        properties.put(USER_TEXT, container.getUserLabel());
        return properties;
    }

    @Override
    public Collection<String> getRegisteredTypes(ISessionContext sessionContext, Optional<String> parentType)
            throws RepositoryException {
        return Collections.emptyList();
    }

    @Override public ContainerSearchable queries() throws RepositoryException {
        return (ContainerSearchable) super.queries();
    }
}
