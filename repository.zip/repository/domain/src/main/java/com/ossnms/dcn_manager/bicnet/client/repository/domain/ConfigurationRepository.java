package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;

import javax.annotation.Nonnull;
import java.util.Map;

public class ConfigurationRepository {

    private final BicnetServerFacade serverFacade;
    
    public ConfigurationRepository(@Nonnull final BicnetServerFacade serverFacade) {
        this.serverFacade = serverFacade;
    }

    /**
     * Loads the Global Settings
     * 
     * @param context
     * @return
     * @throws RepositoryException
     */
    public Map<String, String> getGlobalSettings(@Nonnull final ISessionContext context) throws RepositoryException {
        try {
            return serverFacade.getConfigurationService().getGlobalSettings(context);
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    /**
     * Update the Global Settings.
     * 
     * @param context
     * @param updatedProperties
     * @throws RepositoryException
     */
    public void updateGlobalSettings(@Nonnull final ISessionContext context,
            @Nonnull final Map<String, String> updatedProperties) throws RepositoryException {
        try {
            serverFacade.getConfigurationService().updateGlobalSettings(context, updatedProperties);
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    public boolean isNodeManagerSelected()  {
        try {
            return serverFacade.getConfigurationService().isNodeManagerSelected();
        } catch (final BcbException e) {
            Throwables.propagate(e);
        }
        return false;
    }
}
