package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.Searchable;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

public abstract class CacheInMemoryRepository<K, V> implements Repository<K, V> {

    private final CacheWrapper<K, V> cache;

    protected CacheInMemoryRepository(@Nonnull final CacheWrapper<K, V> cache) {
        this.cache = cache;
    }

    @Override
    @Nonnull
    public Optional<V> get(K id) throws RepositoryException {
        try {
            return cache.findOrFetch(id);
        } catch (final CacheException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    @Nonnull
    public Collection<V> get(@Nonnull Collection<K> keys) throws RepositoryException {
        try {
            return cache.findAllKeys(keys);
        } catch (final CacheException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    @Nonnull
    public Collection<V> getAll() throws RepositoryException {
        try {
            return cache.all();
        } catch (final CacheException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Searchable<V> queries() throws RepositoryException {
        try {
            return cache.queries();
        } catch (final CacheException e) {
            throw new RepositoryException(e);
        }
    }

    @Nonnull
    protected Property[] transform(@Nonnull Map<String, String> properties) {
        return properties.entrySet().stream()
                .map(entry -> new Property(entry.getKey(), entry.getValue()))
                .toArray(Property[]::new);
    }
}
