package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.ChannelSearchable;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Facade to access the InMemoryRepository based on client cache and the Remote Server Repository facade.
 */
public class ChannelRepository extends CacheInMemoryRepository<Integer, FullChannelData> {
    private final BicnetServerFacade serverFacade;

    public ChannelRepository(@Nonnull final BicnetServerFacade serverFacade, @Nonnull final CacheWrapper<Integer, FullChannelData> cache) {
        super(cache);
        this.serverFacade = serverFacade;
    }

    @Override
    public void remove(@Nonnull ISessionContext sessionContext, @Nonnull Integer id) throws RepositoryException {
        try {
            serverFacade.getDcnPublicServices().deleteEM(sessionContext, new EMIdItem(id));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void remove(@Nonnull ISessionContext sessionContext, @Nonnull Collection<Integer> ids)
            throws RepositoryException {
        try {
            serverFacade.getChannelService().deleteChannels(sessionContext,
                    ids.stream().map(EMIdItem::new).collect(Collectors.toList()));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void create(@Nonnull ISessionContext sessionContext, @Nonnull FullChannelData em, @Nonnull Map<String, String> properties)
            throws RepositoryException {
        try {
            serverFacade.getChannelService().createEM(sessionContext, em.getChannel().getEmType(), em.getChannel().getIdName(),
                    em.getChannel().getAssociatedMediator(), transform(properties));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void update(@Nonnull ISessionContext sessionContext, @Nonnull FullChannelData em, @Nonnull Map<String, String> properties)
            throws RepositoryException {
        try {
            serverFacade.getChannelService().updateProperties(sessionContext, em.getChannel(), properties);
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Collection<String> getRegisteredTypes(@Nonnull final ISessionContext sessionContext,
            @Nonnull Optional<String> type) throws RepositoryException {
        try {
            return type.isPresent() 
                    ? Arrays.asList(serverFacade.getChannelService().getRegisteredEmTypes(sessionContext, type.get())) 
                    : Collections.emptyList();
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Map<String, String> getProperties(ISessionContext sessionContext, Integer key) throws RepositoryException {
        try {
            return serverFacade.getChannelService().getProperties(sessionContext, new EMIdItem(key));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override public ChannelSearchable queries() throws RepositoryException {
        return (ChannelSearchable) super.queries();
    }
}
