package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacadeSingleton;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ChannelCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ContainerCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.DomainCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.MediatorCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NEContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.SystemContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.SystemContainerCacheManager;

/**
 * Factory to create the Repositories facade for the Client Domains Objects.
 */
public class RepositoryManager {
    private static final BicnetServerFacade BICNET_SERVER_FACADE = BicnetServerFacadeSingleton.getInstance();

    private ChannelRepository channelRepository;
    private ConfigurationRepository configurationRepository;
    private ContainerRepository containerRepository;
    private SystemContainerRepository systemContainerRepository;
    private MediatorRepository mediatorRepository;
    private NeRepository neRepository;
    private DomainRepository domainRepository;
    private SystemContainerAssignmentRepository systemContainerAssignmentRepository;
    private NEContainerAssignmentRepository neContainerAssignmentRepository;

    public ChannelRepository getChannelRepository() {
        if (null == channelRepository) {
            channelRepository = new ChannelRepository(BICNET_SERVER_FACADE, ChannelCacheManager.getInstance().cache());
        }
        return channelRepository;
    }

    public ConfigurationRepository getConfigurationRepository() {
        if (null == configurationRepository) {
            configurationRepository = new ConfigurationRepository(BICNET_SERVER_FACADE);
        }
        return configurationRepository;
    }

    public ContainerRepository getContainerRepository() {
        if (null == containerRepository) {
            containerRepository = new ContainerRepository(BICNET_SERVER_FACADE,
                    ContainerCacheManager.getInstance().cache());
        }
        return containerRepository;
    }

    public SystemContainerRepository getSystemContainerRepository() {
        if (null == systemContainerRepository) {
            systemContainerRepository = new SystemContainerRepository(BICNET_SERVER_FACADE,
                    SystemContainerCacheManager.getInstance().cache());
        }
        return systemContainerRepository;
    }

    public SystemContainerAssignmentRepository getSystemContainerAssignmentRepository() {
        if (null == systemContainerAssignmentRepository) {
            systemContainerAssignmentRepository = new SystemContainerAssignmentRepository(
                    SystemContainerAssignmentCacheManager.getInstance().cache());
        }
        return systemContainerAssignmentRepository;
    }

    public NEContainerAssignmentRepository getNEContainerAssignmentRepository() {
        if (null == neContainerAssignmentRepository) {
            neContainerAssignmentRepository = new NEContainerAssignmentRepository(
                    NEContainerAssignmentCacheManager.getInstance().cache());
        }
        return neContainerAssignmentRepository;
    }

    public MediatorRepository getMediatorRepository() {
        if (null == mediatorRepository) {
            mediatorRepository = new MediatorRepository(BICNET_SERVER_FACADE,
                    MediatorCacheManager.getInstance().cache());
        }
        return mediatorRepository;
    }

    public NeRepository getNeRepository() {
        if (null == neRepository) {
            neRepository = new NeRepository(BICNET_SERVER_FACADE, NeCacheManager.getInstance().cache());
        }
        return neRepository;
    }

    public DomainRepository getDomainRepository() {
        if (null == domainRepository) {
            domainRepository = new DomainRepository(DomainCacheManager.getInstance().cache());
        }
        return domainRepository;
    }
}
