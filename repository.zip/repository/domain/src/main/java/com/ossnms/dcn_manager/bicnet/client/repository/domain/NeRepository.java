package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeSearchable;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import static com.google.common.collect.Maps.filterKeys;
import static com.ossnms.dcn_manager.bicnet.client.api.Containers.ROOT_CONTAINER_ID;
import static com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames.CONTAINER_ID;
import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toList;
import static org.apache.commons.lang3.math.NumberUtils.toInt;

/**
 * Facade to access the InMemoryRepository based on client cache and the Remote Server Repository facade.
 */
public class NeRepository extends CacheInMemoryRepository<Integer, FullNeData> {

    private static final int UNDEFINED = 0;
    private final BicnetServerFacade serverFacade;

    public NeRepository(@Nonnull final BicnetServerFacade serverFacade, @Nonnull final CacheWrapper<Integer, FullNeData> cache) {
        super(cache);
        this.serverFacade = serverFacade;
    }

    @Override
    public void create(@Nonnull ISessionContext sessionContext, @Nonnull FullNeData fullNe,
                       @Nonnull Map<String, String> properties) throws RepositoryException {
        try {
            Collection<String> transientKeys = asList(CONTAINER_ID); //transient properties should not go to server
            Map<String, String> transientProperties = filterKeys(properties, transientKeys::contains);
            Map<String, String> neProperties = filterKeys(properties, key -> !transientKeys.contains(key));

            INE ne = fullNe.getNe();
            String type = ne.getNeProxyType();
            IEMId em = ne.getAssociatedEm();
            INEId parentNe = ne.getParentNe();
            String name = ne.getIdName();
            Property[] property = transform(neProperties);

            int systemId = ne.getAssociatedSystemContainerId();
            final Optional<String> containerIdOptional = Optional.ofNullable(transientProperties.get(CONTAINER_ID));

            if (systemId != UNDEFINED) {
                SystemContainerIdItem system = new SystemContainerIdItem(systemId);
                serverFacade.getNeService().createNE(sessionContext, type, em, parentNe, system, name, property);
            } else if (containerIdOptional.isPresent()){
                Integer containerId = toInt(containerIdOptional.get(), ROOT_CONTAINER_ID);
                GenericContainerIdItem container = new GenericContainerIdItem(containerId);
                serverFacade.getNeService().createNE(sessionContext, type, em, parentNe, container, name, property);
            } else {
                serverFacade.getDcnPublicServices().createNE(sessionContext, type, em, parentNe, name, property);
            }

        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void duplicate(@Nonnull final ISessionContext sessionContext,@Nonnull final FullNeData template,
            @Nonnull final Map<String, String> properties)
            throws RepositoryException {
        try {
            serverFacade.getNeService().duplicate(sessionContext, template.getNe(), transform(properties));
        } catch (BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void update(@Nonnull ISessionContext sessionContext, @Nonnull FullNeData ne,
                       @Nonnull Map<String, String> properties) throws RepositoryException {
        try {
            serverFacade.getNeService().updateProperties(sessionContext, ne.getNe().getNEId(), properties);
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void remove(@Nonnull ISessionContext sessionContext, @Nonnull Collection<Integer> keys)
            throws RepositoryException {
        try {
            serverFacade.getNeService().deleteNEs(sessionContext, keys.stream().map(NEIdItem::new).collect(toList()));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public void remove(@Nonnull ISessionContext sessionContext, @Nonnull Integer key) throws RepositoryException {
        try {
            serverFacade.getDcnPublicServices().deleteNE(sessionContext, new NEIdItem(key));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Collection<String> getRegisteredTypes(@Nonnull final ISessionContext sessionContext,
                                                 @Nonnull Optional<String> type) throws RepositoryException {
        try {
            return type.isPresent()
                    ? asList(serverFacade.getNeService().getSupportedNeTypes(sessionContext, type.get()))
                    : Collections.emptyList();
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Map<String, String> getProperties(ISessionContext sessionContext, Integer key) throws RepositoryException {
        try {
            return serverFacade.getNeService().getProperties(sessionContext, new NEIdItem(key));
        } catch (final BcbException e) {
            throw new RepositoryException(e);
        }
    }

    @Override public NeSearchable queries() throws RepositoryException {
        return (NeSearchable) super.queries();
    }
}
