package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.MediatorCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.MediatorService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static java.util.Optional.of;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MediatorRepositoryTest {
    private final CacheWrapper<Integer, FullMediatorData> cache = MediatorCacheManager.getInstance().cache();
    private final IMediator mediator;
    private final FullMediatorData fullMediatorData;
    
    private BicnetServerFacade facade;
    private MediatorService mediatorService;
    private ISessionContext context;
    private MediatorRepository repository;
    
    public MediatorRepositoryTest() {
        mediator = new MediatorItem();
        mediator.setId(1);
        mediator.setIdName("name");

        fullMediatorData = new FullMediatorData(mediator, new MediatorInfo(mediator.getId()));
        
        cache.fetch(new ArrayList<>());
    }
    
    @Before
    public void setup() throws CacheException, BcbException {
        facade = mock(BicnetServerFacade.class);
        mediatorService = mock(MediatorService.class);
        context = mock(ISessionContext.class);
        
        when(facade.getMediatorService()).thenReturn(mediatorService);        
        
        repository = new MediatorRepository(facade, cache);
        
        cache.put(mediator.getId(), fullMediatorData);
    }
    
    @After
    public void release() throws CacheException {
        cache.remove(mediator.getId());
    }
    
    @Test
    public void testRemove() throws Exception {
        repository.remove(context, 1);
        
        verify(mediatorService, times(1)).deleteMediator(context, new MediatorIdItem(1));
    }
    
    @Test
    public void testCreate() throws Exception {
        final Map<String, String> map = new HashMap<>();
        
        repository.create(context, fullMediatorData, map);
        
        verify(mediatorService, times(1)).store(context, mediator, map);
    }
    
    @Test
    public void testUpdate() throws Exception {
        final Map<String, String> map = new HashMap<>();
        
        repository.update(context, fullMediatorData, map);
        
        verify(mediatorService, times(1)).updateProperties(context, mediator.getMediatorId(), map);
    }
    
    @Test
    public void testGetRegisteredTypes() throws Exception {
        when(mediatorService.getRegisteredMediatorTypes(context)).thenReturn(new String[0]);
        
        repository.getRegisteredTypes(context, of("type"));
        
        verify(mediatorService, times(1)).getRegisteredMediatorTypes(context);
    }
    
    @Test
    public void testProperties() throws Exception {
        when(mediatorService.getProperties(context, mediator.getMediatorId())).thenReturn(new HashMap<>());
        
        repository.getProperties(context, mediator.getId());
        
        verify(mediatorService, times(1)).getProperties(context, mediator.getMediatorId());
    }
    
    @Test
    public void testGet() throws RepositoryException {
        final Optional<FullMediatorData> emItem = repository.get(1);
        
        assertThat(emItem.get().getMediator(), equalTo(mediator));
    }
    
    @Test
    public void testGetByKeys() throws RepositoryException {
        final Collection<FullMediatorData> items = repository.get(ImmutableList.of(1));
        
        assertTrue(items.contains(fullMediatorData));
    }
    
    @Test
    public void testGetAll() throws RepositoryException {
        final Collection<FullMediatorData> items = repository.getAll();
        
        assertTrue(items.contains(fullMediatorData));
    }
    
    @Test
    public void testQuery() throws RepositoryException {
        final Optional<FullMediatorData> emItem = repository.queries().findByIdName("name");
        
        assertThat(emItem.get().getMediator(), equalTo(mediator));
    }
}
