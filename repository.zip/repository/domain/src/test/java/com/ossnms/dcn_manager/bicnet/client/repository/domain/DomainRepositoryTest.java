package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.DomainCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import net.sf.ehcache.Element;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class DomainRepositoryTest {

    private final CacheWrapper<Integer, IAS> cache = DomainCacheManager.getInstance().cache();
    private final IAS domain;

    private DomainRepository repository;

    public DomainRepositoryTest() {
        domain = new ASItem();
        domain.setId(1);
        domain.setIdName("name");

        cache.fetch(new ArrayList<Element>());
    }

    @Before
    public void setup() throws CacheException {
        repository = new DomainRepository(cache);

        cache.put(domain.getId(), domain);
    }

    @After
    public void release() throws CacheException {
        cache.remove(domain.getId());
    }

    @Test
    public void testGet() throws RepositoryException {
        final Optional<IAS> emItem = repository.get(1);

        assertThat(emItem.get(), equalTo(domain));
    }

    @Test
    public void testGetByKeys() throws RepositoryException {
        final Collection<IAS> items = repository.get(ImmutableList.of(1));

        assertTrue(items.contains(domain));
    }

    @Test
    public void testGetAll() throws RepositoryException {
        final Collection<IAS> items = repository.getAll();

        assertTrue(items.contains(domain));
    }

    @Test
    public void testQuery() throws RepositoryException {
        final Optional<IAS> emItem = repository.queries().findByIdName("name");

        assertThat(emItem.get(), equalTo(domain));
    }

    @Test
    public void testTransform() {
        final Map<String, String> map = ImmutableMap.of("k1", "v1", "k2", "v2");

        final Property[] items = repository.transform(map);

        assertTrue(items[0].getName().equals("k1"));
        assertTrue(items[0].getValue().equals("v1"));

        assertTrue(items[1].getName().equals("k2"));
        assertTrue(items[1].getValue().equals("v2"));
    }
}
