package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.NeService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static java.util.Collections.emptyMap;
import static java.util.Optional.of;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class NeRepositoryTest {
    private final CacheWrapper<Integer, FullNeData> cache = NeCacheManager.getInstance().cache();
    private final FullNeData ne;
    
    private BicnetServerFacade facade;
    private IEMObjectMgrFacade publicFacade;
    private NeService neService;
    private ISessionContext context;
    private NeRepository repository;
    
    public NeRepositoryTest() {
        final INE neItem = new NEItem();
        neItem.setId(1);
        neItem.setIdName("name");
        neItem.setNeProxyType("neProxyType");
        neItem.setAssociatedEm(new EMIdItem(1));
        
        ne = new FullNeData(neItem, new NeInfo(neItem.getId()), null);
        
        cache.fetch(new ArrayList<>());
    }
    
    @Before
    public void setup() throws CacheException, BcbException {
        facade = mock(BicnetServerFacade.class);
        publicFacade = mock(IEMObjectMgrFacade.class);
        neService = mock(NeService.class);
        context = mock(ISessionContext.class);

        when(facade.getDcnPublicServices()).thenReturn(publicFacade);
        when(facade.getNeService()).thenReturn(neService);
        
        repository = new NeRepository(facade, cache);
        
        cache.put(ne.getNe().getId(), ne);
    }
    
    @After
    public void release() throws CacheException {
        cache.remove(ne.getNe().getId());
    }
    
    @Test
    public void testRemove() throws Exception {
        repository.remove(context, 1);
        
        verify(publicFacade, times(1)).deleteNE(context, new NEIdItem(1));
    }
    
    @Test
    public void testCreateUnderSystem() throws Exception {
        final Map<String, String> map = new HashMap<>();
        ne.getNe().setAssociatedSystemContainerId(42);
        
        repository.create(context, ne, map);
        
        verify(neService, times(1)).createNE(context, ne.getNe().getNeProxyType(), ne.getNe().getAssociatedEm(), 
                ne.getNe().getParentNe(), new SystemContainerIdItem(42), ne.getNe().getIdName(), repository.transform(map));
    }

    @Test public void testCreateUnderContainer() throws Exception {
        final Map<String, String> map = ImmutableMap.of(WellKnownNePropertyNames.CONTAINER_ID, "14");
        ne.getNe().setAssociatedSystemContainerId(0); // no system

        repository.create(context, ne, map);

        verify(neService, times(1)).createNE(context, ne.getNe().getNeProxyType(), ne.getNe().getAssociatedEm(),
                ne.getNe().getParentNe(), new GenericContainerIdItem(14), ne.getNe().getIdName(), repository.transform(emptyMap()));
    }
    
    @Test
    public void testUpdate() throws Exception {
        final Map<String, String> map = new HashMap<>();
        
        repository.update(context, ne, map);
        
        verify(neService, times(1)).updateProperties(context, ne.getNe().getNEId(), map);
    }
    
    @Test
    public void testGetRegisteredTypes() throws Exception {
        when(neService.getSupportedNeTypes(context, "type")).thenReturn(new String[0]);
        
        repository.getRegisteredTypes(context, of("type"));
        
        verify(neService, times(1)).getSupportedNeTypes(context, "type");
    }
    
    @Test
    public void testGetProperties() throws Exception {
        when(neService.getProperties(context, ne.getNe().getNEId())).thenReturn(new HashMap<>());
        
        repository.getProperties(context, ne.getNe().getId());
        
        verify(neService, times(1)).getProperties(context, ne.getNe().getNEId());
    }
    
    @Test
    public void testGetByKeys() throws RepositoryException {
        final Collection<FullNeData> items = repository.get(ImmutableList.of(1));
        
        assertTrue(items.contains(ne));
    }
    
    @Test
    public void testGetAll() throws RepositoryException {
        final Collection<FullNeData> items = repository.getAll();
        
        assertTrue(items.contains(ne));
    }
    
    @Test
    public void testQuery() throws RepositoryException {
        final Optional<FullNeData> emItem = repository.queries().findByIdName("name");
        
        assertThat(emItem.get(), equalTo(ne));
    }
}
