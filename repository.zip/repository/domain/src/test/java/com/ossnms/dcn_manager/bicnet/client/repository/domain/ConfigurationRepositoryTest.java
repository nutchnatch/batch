package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.mockito.Mockito;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.ConfigurationRepository;
import com.ossnms.dcn_manager.bicnet.client.repository.domain.RepositoryException;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ConfigurationService;

public class ConfigurationRepositoryTest {

    private BicnetServerFacade facade;
    private ConfigurationService configurationService;
    private ConfigurationRepository repository;
    private ISessionContext context;

    @Before
    public void setup() throws BcbException {
        facade = mock(BicnetServerFacade.class);
        configurationService = mock(ConfigurationService.class);
        context =  mock(ISessionContext.class);
        
        when(facade.getConfigurationService()).thenReturn(configurationService);
        
        repository = new ConfigurationRepository(facade);
    }

    @Ignore
    public void testLoad() throws BcbException, RepositoryException {
        repository.getGlobalSettings(context);

        verify(configurationService, Mockito.only()).getGlobalSettings(context);
    }
    
    @Ignore
    public void testUpdate() throws BcbException, RepositoryException {
        final Map<String,String> map = new HashMap<>();
        
        repository.updateGlobalSettings(context, map);

        verify(configurationService, Mockito.only()).updateGlobalSettings(context, map);
    }
}
