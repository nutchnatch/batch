package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeContainerAssignmentSearchable;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;

import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.contains;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class) public class NEContainerAssignmentRepositoryTest {
    private static final int CONTAINER_ID = 1;
    private static final int NETWORK_ELEMENT_ID = 2;

    @Mock private CacheWrapper<INeGenericContainerAssignmentId, INeGenericContainerAssignment> cache;
    @Mock private NeContainerAssignmentSearchable neAssignmentSearchable;

    private NEContainerAssignmentRepository repository;

    @Before public void setUp() throws Exception {
        repository = new NEContainerAssignmentRepository(cache);
    }

    @Test public void getNeIdList() throws Exception {
        INeGenericContainerAssignment assignment = new NeGenericContainerAssignmentItem();
        assignment.setGenericContainerId(CONTAINER_ID);
        assignment.setNetworkElementId(NETWORK_ELEMENT_ID);

        when(cache.queries()).thenReturn(neAssignmentSearchable);
        when(neAssignmentSearchable.findByContainerId(CONTAINER_ID)).thenReturn(singletonList(assignment));

        IGenericContainer genericContainer = new GenericContainerItem();
        genericContainer.setId(1);

        final Collection<Integer> neIdList = repository.getNeIdList(genericContainer.getId());

        assertThat(neIdList, contains(NETWORK_ELEMENT_ID));

        verify(cache).queries();
        verify(neAssignmentSearchable, atLeastOnce()).findByContainerId(CONTAINER_ID);
    }

}