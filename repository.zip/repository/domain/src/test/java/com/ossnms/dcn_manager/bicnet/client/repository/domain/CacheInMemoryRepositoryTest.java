package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.model.common.Property;
import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.assertEquals;

public class CacheInMemoryRepositoryTest {
    @Test
    public void testTransform() {
        final Map<String,String> map = ImmutableMap.of("k1","v1", "k2", "v2");
        CacheInMemoryRepository repository = new NeRepository(null, null); //any repository instance

        final Property[] items = repository.transform(map);

        assertEquals("k1", items[0].getName());
        assertEquals("v1", items[0].getValue());

        assertEquals("k2", items[1].getName());
        assertEquals("v2", items[1].getValue());
    }
}