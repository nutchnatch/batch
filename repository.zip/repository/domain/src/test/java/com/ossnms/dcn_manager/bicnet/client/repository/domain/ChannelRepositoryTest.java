package com.ossnms.dcn_manager.bicnet.client.repository.domain;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheWrapper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ChannelCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ChannelService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import net.sf.ehcache.Element;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static java.util.Optional.of;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ChannelRepositoryTest {
    private final CacheWrapper<Integer, FullChannelData> cache = ChannelCacheManager.getInstance().cache();
    private final IEM em;

    private BicnetServerFacade facade;
    private IEMObjectMgrFacade publicFacade;
    private ChannelService channelService;
    private ISessionContext context;
    private ChannelRepository repository;
    
    public ChannelRepositoryTest() {
        em = new EMItem();
        em.setId(1);
        em.setIdName("name");
        cache.fetch(new ArrayList<Element>());
    }
    
    @Before
    public void setup() throws CacheException, BcbException {
        facade = mock(BicnetServerFacade.class);
        publicFacade = Mockito.mock(IEMObjectMgrFacade.class);
        channelService = Mockito.mock(ChannelService.class);
        context = Mockito.mock(ISessionContext.class);
                        
        when(facade.getDcnPublicServices()).thenReturn(publicFacade);
        when(facade.getChannelService()).thenReturn(channelService);

        repository = new ChannelRepository(facade, cache);
        
        cache.put(em.getId(), new FullChannelData(em, new ChannelInfo(em.getId())));
    }
    
    @After
    public void release() throws CacheException {
        cache.remove(em.getId());
    }
    
    @Test
    public void testRemove() throws BcbException, RepositoryException {
        repository.remove(context, 1);
        
        verify(publicFacade, times(1)).deleteEM(context, new EMIdItem(1));
    }
    
    @Test
    public void testCreate() throws BcbException, RepositoryException {
        final Map<String, String> map = new HashMap<>();
        
        repository.create(context, new FullChannelData(em, new ChannelInfo(em.getId())), map);
        
        verify(channelService, times(1)).createEM(context, em.getEmType(), em.getIdName(), em.getAssociatedMediator(), repository.transform(map));
    }
    
    @Test
    public void testUpdate() throws BcbException, RepositoryException {
        final Map<String, String> map = new HashMap<>();
        
        repository.update(context, new FullChannelData(em, new ChannelInfo(em.getId())), map);
        
        verify(channelService, times(1)).updateProperties(context, em.getEMId(), map);
    }
    
    @Test
    public void testGetRegisteredTypes() throws BcbException, RepositoryException {
        when(channelService.getRegisteredEmTypes(context, "type")).thenReturn(new String[0]);
        
        repository.getRegisteredTypes(context, of("type"));
        
        verify(channelService, times(1)).getRegisteredEmTypes(context, "type");
    }
    
    @Test
    public void testProperties() throws BcbException, RepositoryException {
        when(publicFacade.getProperties(context, em.getEMId())).thenReturn(new Property[0]);
        
        repository.getProperties(context, em.getId());
        
        verify(channelService, times(1)).getProperties(context, em.getEMId());
    }
    
    @Test
    public void testGet() throws RepositoryException {
        final Optional<FullChannelData> emItem = repository.get(1);
        
        assertThat(emItem.get(), equalTo(new FullChannelData(em, new ChannelInfo(em.getId()))));
    }
    
    @Test
    public void testGetByKeys() throws RepositoryException {
        final Collection<FullChannelData> items = repository.get(ImmutableList.of(1));
        
        assertTrue(items.contains(new FullChannelData(em, new ChannelInfo(em.getId()))));
    }
    
    @Test
    public void testGetAll() throws RepositoryException {
        final Collection<FullChannelData> items = repository.getAll();
        
        assertTrue(items.contains(new FullChannelData(em, new ChannelInfo(em.getId()))));
    }
    
    @Test
    public void testQuery() throws RepositoryException {
        final Optional<FullChannelData> emItem = repository.queries().findByIdName("name");
        
        assertThat(emItem.get().getChannel(), equalTo(em));
    }
    
    @Test
    public void testTransform() {
        final Map<String,String> map = ImmutableMap.of("k1","v1", "k2", "v2");
        
        final Property[] items = repository.transform(map);
        
        assertTrue(items[0].getName().equals("k1"));
        assertTrue(items[0].getValue().equals("v1"));
        
        assertTrue(items[1].getName().equals("k2"));
        assertTrue(items[1].getValue().equals("v2"));
    }
}
