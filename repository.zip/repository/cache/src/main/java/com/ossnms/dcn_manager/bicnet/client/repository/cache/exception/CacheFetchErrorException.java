package com.ossnms.dcn_manager.bicnet.client.repository.cache.exception;

public class CacheFetchErrorException extends CacheException {

    private static final long serialVersionUID = -7455461313580090021L;
    
    /** @see CacheException#Exception() */
    public CacheFetchErrorException() {

    }

    /** @see CacheException#Exception(String) */
    public CacheFetchErrorException(String message) {
        super(message);
    }
}
