package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IASId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IASMarkable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;

public final class DomainCacheManager extends AbstractVisitor<IASId, IAS, IASMarkable> implements CacheManager<Integer, IAS> {

    private static final Logger LOGGER = LoggerFactory.getLogger(DomainCacheManager.class);
    private static final DomainCacheManager INSTANCE = new DomainCacheManager();

    private DomainCacheManager() {
        super(CacheInMemoryFactory.getBicnetChangeListener(), IASId.class, IAS.class, IASMarkable.class);
    }

    /**
     * @return The singleton instance.
     */
    public static DomainCacheManager getInstance() {
        return INSTANCE;
    }

    @Override protected void delete(IASId managedObjectId) throws CacheException {
        cache().remove(managedObjectId.getId());
    }

    @Override protected void create(IAS managedObject) throws CacheException {
        cache().put(managedObject.getId(), managedObject);
    }

    @Override protected boolean update(IASMarkable markable) throws CacheException {
        final Optional<IAS> domain = cache().find(markable.getId());

        if (domain.isPresent()) {
            domain.get().update(markable);
            cache().update(domain.get().getId(), domain.get());
            return true;
        }
        LOGGER.error("The Domain cache not contains the neId={}", markable.getId());
        return false;
    }

    @Override public ActivationAwareCacheWrapper<Integer, IAS> cache() {
        return CacheInMemoryFactory.getDomainCache();
    }

}