/**
 * Contains the ehCache event listeners.
 */
package com.ossnms.dcn_manager.bicnet.client.repository.cache.listener;