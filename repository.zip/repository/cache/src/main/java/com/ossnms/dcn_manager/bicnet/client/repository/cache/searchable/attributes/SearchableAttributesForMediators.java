package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes;

import org.apache.commons.lang3.builder.Builder;

import net.sf.ehcache.config.SearchAttribute;
import net.sf.ehcache.config.Searchable;

/**
 * Define the searchable attributes for cache element "Mediators".
 */
public class SearchableAttributesForMediators implements Builder<Searchable>{

    /**
     * Builds the Searchable attributes for the Mediators cache. 
     */
    @Override
    public Searchable build() {
        final Searchable searchable = new Searchable();
        
        searchable.searchAttribute(new SearchAttribute().name(QueryAttribute.NAME.name()).expression("value.getMediator().getIdName()"));
        searchable.searchAttribute(new SearchAttribute().name(QueryAttribute.ADDRESS.name()).expression("value.getMediator().getDisplayAddress()"));
        
        searchable.allowDynamicIndexing(true);
        
        return searchable;
    }
}
