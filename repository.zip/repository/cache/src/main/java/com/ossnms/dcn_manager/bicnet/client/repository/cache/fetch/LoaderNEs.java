package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;

import static java.util.Optional.ofNullable;

/**
 * Loads NEs from DCN Manager private facade {@link BicnetServerFacade}.
 */
public class LoaderNEs implements Loader<Integer, FullNeData> {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoaderNEs.class);

    private final BicnetServerFacade service;
    private final DcnPluginHelper pluginHelper;

    public LoaderNEs(@Nonnull final BicnetServerFacade service, @Nonnull final DcnPluginHelper pluginHelper) {
        this.service = service;
        this.pluginHelper = pluginHelper;
    }

    @Override public Collection<FullNeData> loadValues() throws CacheException {
        Collection<FullNeData> nesData = Collections.emptyList();
        final long startTime = System.currentTimeMillis();
        try{
            nesData = getPrivileged(() ->
                    service.getNeService().getFullNeList(pluginHelper.getSessionContext()));
            return nesData;
        }finally {
            LOGGER.warn("elapsed time fetching {} nes from server ( {} ms)", nesData.size(), System.currentTimeMillis() - startTime );
        }
    }

    @Override public Optional<FullNeData> loadValue(Integer id) throws CacheException {
        return ofNullable(getPrivileged(() ->
                service.getNeService().getFullNe(pluginHelper.getSessionContext(), id)));
    }

    @Override public Integer keyFor(FullNeData neData) {
        return neData.getNe().getId();
    }
}