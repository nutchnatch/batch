package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentMarkable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheInMemoryFactory.getNEContainerAssignmentCache;

public final class NEContainerAssignmentCacheManager
        extends AbstractVisitor<INeGenericContainerAssignmentId, INeGenericContainerAssignment, INeGenericContainerAssignmentMarkable>
        implements CacheManager<INeGenericContainerAssignmentId, INeGenericContainerAssignment>{

    private static final Logger LOGGER = LoggerFactory.getLogger(NEContainerAssignmentCacheManager.class);
    private static final NEContainerAssignmentCacheManager INSTANCE = new NEContainerAssignmentCacheManager();
    
    private NEContainerAssignmentCacheManager() {
        super(CacheInMemoryFactory.getBicnetChangeListener(), INeGenericContainerAssignmentId.class,
                INeGenericContainerAssignment.class, INeGenericContainerAssignmentMarkable.class);
    }

    public static NEContainerAssignmentCacheManager getInstance() {
        return INSTANCE;
    }

    @Override protected void create(INeGenericContainerAssignment assignment) throws CacheException {
        cache().put(assignment.getNeGenericContainerAssignmentId(), assignment);
    }

    @Override protected void delete(INeGenericContainerAssignmentId id) throws CacheException {
        cache().remove(id);
    }

    @Override protected boolean update(INeGenericContainerAssignmentMarkable markable) throws CacheException {
        INeGenericContainerAssignmentId id = markable.getNeGenericContainerAssignmentId();
        final Optional<INeGenericContainerAssignment> assignmentOpt = cache().find(id);

        if (assignmentOpt.isPresent()) {
            INeGenericContainerAssignment assignment = assignmentOpt.get();
            assignment.update(markable);
            cache().update(id, assignment);
            return true;
        }
        LOGGER.error("The NE Container Assignment cache not contains the id={}", id);
        return false;
    }

    @Override public ActivationAwareCacheWrapper<INeGenericContainerAssignmentId, INeGenericContainerAssignment> cache() {
        return getNEContainerAssignmentCache();
    }
}
