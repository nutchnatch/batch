package com.ossnms.dcn_manager.bicnet.client.repository.cache.listener;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginEmNeChangeListener;

/**
 * Change listener to be able BiCNet Plug-ins, receive changes(create, delete, AVC) from
 * the all private Caches.
 */
public interface ChangeListener extends BiCNetPluginEmNeChangeListener {

    /**
     * Add Bicnet Listener to receive changes of the private caches.
     * @param listener
     */
    void add(BiCNetPluginEmNeChangeListener listener);

    /**
     * Remove Bicnet Listener and stop to receive changes of the private caches.
     * @param listener
     */
    void remove(BiCNetPluginEmNeChangeListener listener);
}
