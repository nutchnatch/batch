package com.ossnms.dcn_manager.bicnet.client.repository.cache;

/**
 * The cache state.
 */
enum CacheState {
	NOT_LOADED,
	LOADING,
	LOADED,
	ERROR
}
