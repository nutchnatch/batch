package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

import static java.util.Arrays.asList;
import static java.util.Optional.ofNullable;

/**
 * Loads Containers from DCN Manager private facade {@link BicnetServerFacade}.
 */
public class LoaderContainers implements Loader<Integer, IGenericContainer> {
    private final BicnetServerFacade service;
    private final DcnPluginHelper pluginHelper;

    public LoaderContainers(@Nonnull final BicnetServerFacade service, @Nonnull final DcnPluginHelper pluginHelper) {
        this.service = service;
        this.pluginHelper = pluginHelper;
    }

    @Override public Collection<IGenericContainer> loadValues() throws CacheException {
        return asList(getPrivileged(() ->
                service.getContainerService().getGenericContainerList(
                        pluginHelper.getSessionContext(), null, null, NO_LIMIT))
                .getData());
    }

    @Override public Optional<IGenericContainer> loadValue(Integer id) throws CacheException {
        return ofNullable(getPrivileged(() ->
                service.getContainerService().getSingleGenericContainer(
                        pluginHelper.getSessionContext(), new GenericContainerIdItem(id))));
    }

    @Override public Integer keyFor(IGenericContainer container) {
        return container.getId();
    }

}