package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByContainer;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchBySystem;

/**
 * Queries for System Assignment cache
 * @see com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchAttributesForSystemAssociation
 */
public interface SystemAssignmentSearchable extends
        SearchByContainer<ISystemGenericContainerAssignment>,
        SearchBySystem<ISystemGenericContainerAssignment> {
}
