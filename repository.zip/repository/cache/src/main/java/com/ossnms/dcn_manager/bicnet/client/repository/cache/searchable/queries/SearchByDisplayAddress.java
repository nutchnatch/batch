package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries;

import net.sf.ehcache.search.Attribute;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.QueryAttribute.ADDRESS;
import static net.sf.ehcache.search.Direction.ASCENDING;
import static net.sf.ehcache.search.Query.KEY;

public interface SearchByDisplayAddress<V> extends Searchable<V> {

    /**
     * Find all Channels and Mediators by Display address.
     *
     * @param displayAddress
     * @return
     */
    default Optional<V> findByDisplayAddress(@Nonnull final String displayAddress) {
        final Attribute<String> attribute = getCache().getSearchAttribute(ADDRESS.name());
        return find(query -> query
                .includeKeys()
                .addOrderBy(KEY, ASCENDING)
                .addCriteria(attribute.eq(displayAddress))
        ).findFirst();
    }
}
