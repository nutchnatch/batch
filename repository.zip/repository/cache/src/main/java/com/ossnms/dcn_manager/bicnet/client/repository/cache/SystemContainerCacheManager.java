package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.SystemAssignmentSearchable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Optional;

/**
 * Contains the CRUD operations to maintain synchronized the System Container CACHE.
 * Throw the ehCache callback methods call events for each CRUD operations for a registered listener.
 */
public final class SystemContainerCacheManager
        extends AbstractVisitor<ISystemContainerId, ISystemContainer, ISystemContainerMarkable>
        implements CacheManager<Integer, ISystemContainer> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SystemContainerCacheManager.class);
    private static final SystemContainerCacheManager INSTANCE = new SystemContainerCacheManager();

    private SystemContainerCacheManager() {
        super(CacheInMemoryFactory.getBicnetChangeListener(), ISystemContainerId.class, ISystemContainer.class,
                ISystemContainerMarkable.class);
    }

    /**
     * @return The singleton instance.
     */
    public static SystemContainerCacheManager getInstance() {
        return INSTANCE;
    }

    @Override protected void delete(ISystemContainerId managedObjectId) throws CacheException {
        clearAssignments(managedObjectId);
        cache().remove(managedObjectId.getId());
    }

    @Override protected void create(ISystemContainer managedObject) throws CacheException {
        cache().put(managedObject.getId(), managedObject);
    }

    @Override protected boolean update(ISystemContainerMarkable markable) throws CacheException {
        final Optional<ISystemContainer> container = cache().find(markable.getId());

        if (container.isPresent()) {
            container.get().update(markable);
            cache().update(container.get().getId(), container.get());
            return true;
        }
        LOGGER.error("The Container cache not contains the neId={}", markable.getId());
        return false;
    }

    @Override public ActivationAwareCacheWrapper<Integer, ISystemContainer> cache() {
        return CacheInMemoryFactory.getSystemContainerCache();
    }

    private void clearAssignments(ISystemContainerId managedObjectId) throws CacheException {
        SystemAssignmentSearchable queries = (SystemAssignmentSearchable) SystemContainerAssignmentCacheManager
                .getInstance().cache().queries();
        final Collection<ISystemGenericContainerAssignment> assignments = queries.findBySystemContainerId(managedObjectId.getId());

        assignments.forEach(n -> {
            try {
                SystemContainerAssignmentCacheManager.getInstance().cache().remove(n);
            } catch (CacheException e) {
                LOGGER.error("Error to delete System assignment:" + n, e);
            }
        });
    }
}
