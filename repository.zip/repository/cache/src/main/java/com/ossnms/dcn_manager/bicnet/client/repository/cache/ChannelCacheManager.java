package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMMarkable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfoNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelDataCreateNotification.IVisitor;

public final class ChannelCacheManager extends AbstractVisitor<IEMId, IEM, IEMMarkable> implements
        CacheManager<Integer, FullChannelData>, ChannelInfoNotification.IVisitor, IVisitor {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelCacheManager.class);
    private static final ChannelCacheManager INSTANCE = new ChannelCacheManager();

    private ChannelCacheManager() {
        super(CacheInMemoryFactory.getBicnetChangeListener(), IEMId.class, IEM.class, IEMMarkable.class);
    }

    /**
     * @return The singleton instance.
     */
    public static ChannelCacheManager getInstance() {
        return INSTANCE;
    }

    @Override protected void delete(IEMId managedObjectId) throws CacheException {
        cache().remove(managedObjectId.getId());
    }

    @Override public boolean onFullChannelDataCreation(FullChannelDataCreateNotification notification) {
        FullChannelData fullChannelData = notification.getFullChannelData();
        try {
            cache().put(fullChannelData.getInfo().getChannelId(), fullChannelData);
            nofifyCreation(fullChannelData.getChannel());
        } catch (CacheException e) {
            LOGGER.error("The Channel cache not contains the channelId=", e);
        }

        return true;
    }

    @Override protected boolean update(IEMMarkable markable) throws CacheException {
        final Optional<FullChannelData> em = cache().find(markable.getId());

        if (em.isPresent()) {
            em.get().getChannel().update(markable);
            cache().update(em.get().getChannel().getId(), em.get());
            return true;
        }
        LOGGER.error("The Channel cache not contains the channelId={}", markable.getId());
        return false;
    }

    /**
     * Allows specific processing of ChannelInfoNotification instances.
     *
     * @param notification {@link ChannelInfoNotification} object to be processed.
     * @return Whether the Notification has been processed.
     */
    @Override public boolean onChannelInfoNotification(ChannelInfoNotification notification) {
        ChannelInfo channelInfo = notification.getChannelInfo();

        try {
            final Optional<FullChannelData> channel = cache().find(channelInfo.getChannelId());

            if (channel.isPresent()) {
                channelInfo.getGuiActiveActualActivationState().ifPresent(state ->
                        channel.get().getInfo().setGuiActualActivationState(state)
                );

                channelInfo.getGuiStandbyActualActivationState().ifPresent(state ->
                        channel.get().getInfo().setGuiStandbyActualActivationState(state)
                );

                channelInfo.getUserText().ifPresent(text ->
                        channel.get().getInfo().setUserText(text)
                );

                channelInfo.getStandbyDisplayState().ifPresent(text ->
                        channel.get().getInfo().setStandbyDisplayState(text)
                );

                cache().update(channel.get().getInfo().getChannelId(), channel.get());
                return true;
            } else {
                LOGGER.error("The Channel cache not contains the channelId={}", channelInfo.getChannelId());
            }
        } catch (final CacheException e) {
            LOGGER.error("Error to update Channel={}", channelInfo.getChannelId(), e);
        }

        return false;
    }

    @Override public ActivationAwareCacheWrapper<Integer, FullChannelData> cache() {
        return CacheInMemoryFactory.getChannelCache();
    }
}
