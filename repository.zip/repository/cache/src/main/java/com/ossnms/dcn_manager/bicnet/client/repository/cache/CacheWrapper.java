package com.ossnms.dcn_manager.bicnet.client.repository.cache;


import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListenerRegistration;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.CacheInitializer;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.Loader;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.Searchable;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

/**
 * Interface to provides the cache access.
 *
 * @param <K> the element key
 * @param <V> the element value
 */
public interface CacheWrapper<K, V> extends CacheInitializer, EventChangeListenerRegistration<V> {

    /**
     * Add a element to the cache.
     */
    void put(K key, V value) throws CacheException;

    /**
     * Update a exist element.
     */
    void update(@Nonnull K key, @Nonnull V value) throws CacheException;

    /**
     * Gets the element.
     */
    Optional<V> find(K key) throws CacheException;

    /**
     * Get elements by keys.
     */
    Collection<V> findAllKeys(@Nonnull Collection<K> keys) throws CacheException;

    /**
     * Remove the element.
     */
    void remove(K key) throws CacheException;

    /**
     * Remove all elements.
     */
    void clear() throws CacheException;

    /**
     * @return All Cache elements.
     */
    Collection<V> all() throws CacheException;

    /**
     * @return The native cache implementation.
     */
    Ehcache getEhcache();

    /**
     * @return The items loader to populate cache
     */
    Loader<K, V> getLoader();

    /**
     * @return The supported queries.
     * @throws CacheException
     */
    Searchable<V> queries() throws CacheException;

    /**
     * Get element from cache or if absent fetches using loader
     */
    default Optional<V> findOrFetch(K key) throws CacheException {
        Optional<V> fromCache = find(key);
        return fromCache.isPresent() ? fromCache : fetch(key);
    }

    /**
     * Fetches element using loader
     */
    default Optional<V> fetch(K key) throws CacheException {
        return getLoader().loadValue(key);
    }

    @SuppressWarnings("unchecked")
    default V objectValue(Element element) {
        return (V) element.getObjectValue();
    }

    @SuppressWarnings("unchecked")
    default void touchAll() throws CacheException {
        Ehcache cache = getEhcache();
        cache.getAll(cache.getKeys())
                .values().forEach(cache::replace);
    }

}
