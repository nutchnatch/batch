package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable;

import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByDisplayAddress;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByName;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;

/**
 * Queries for Mediation cache
 * @see com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchableAttributesForMediators
 */
public interface MediationSearchable extends
        SearchByName<FullMediatorData>,
        SearchByDisplayAddress<FullMediatorData> {
}
