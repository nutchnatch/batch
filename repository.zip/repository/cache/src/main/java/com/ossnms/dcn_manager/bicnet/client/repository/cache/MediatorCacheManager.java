package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorMarkable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorDataCreateNotification.IVisitor;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfoNotification;

public final class MediatorCacheManager extends AbstractVisitor<IMediatorId, IMediator, IMediatorMarkable>
        implements CacheManager<Integer, FullMediatorData>, MediatorInfoNotification.IVisitor, IVisitor {

    private static final Logger LOGGER = LoggerFactory.getLogger(MediatorCacheManager.class);
    private static final MediatorCacheManager INSTANCE = new MediatorCacheManager();

    private MediatorCacheManager() {
        super(CacheInMemoryFactory.getBicnetChangeListener(), IMediatorId.class, IMediator.class,
                IMediatorMarkable.class);
    }

    /**
     * @return The singleton instance.
     */
    public static MediatorCacheManager getInstance() {
        return INSTANCE;
    }

    @Override protected void delete(IMediatorId mediatorId) throws CacheException {
        cache().remove(mediatorId.getId());
    }

    @Override public boolean onFullMediatorDataCreation(FullMediatorDataCreateNotification notification) {
        final FullMediatorData fullMediatorData = notification.getFullMediatorData();
        try {
            cache().put(fullMediatorData.getInfo().getMediatorId(), fullMediatorData);
            nofifyCreation(fullMediatorData.getMediator());
        } catch (final CacheException e) {
            LOGGER.error("The Mediator cache not contains the Id=", e);
        }

        return true;
    }

    @Override protected boolean update(IMediatorMarkable mediatorMarkable) throws CacheException {
        final Optional<FullMediatorData> mediator = cache().find(mediatorMarkable.getId());

        if (mediator.isPresent()) {
            mediator.get().getMediator().update(mediatorMarkable);
            cache().update(mediator.get().getMediator().getId(), mediator.get());
            return true;
        }
        LOGGER.error("The Mediator cache not contains the Id={}", mediatorMarkable.getId());
        return false;
    }

    @Override
    public boolean onMediatorInfoNotification(MediatorInfoNotification notification) throws BcbException {
        final MediatorInfo mediatorInfo = notification.getMediatorInfo();

        try {
            final Optional<FullMediatorData> fullMediator = cache().find(mediatorInfo.getMediatorId());

            if (fullMediator.isPresent()) {
                mediatorInfo.getGuiActiveActualActivationState().ifPresent(state ->
                        fullMediator.get().getInfo().setGuiActualActivationState(state)
                );

                mediatorInfo.getGuiStandbyActualActivationState().ifPresent(state ->
                        fullMediator.get().getInfo().setGuiStandbyActualActivationState(state)
                );

                mediatorInfo.getUserText().ifPresent(text ->
                        fullMediator.get().getInfo().setUserText(text)
                );

                mediatorInfo.getStandbyDisplayState().ifPresent(text ->
                        fullMediator.get().getInfo().setStandbyDisplayState(text)
                );

                mediatorInfo.isStandbyMediatorConfigured().ifPresent( configured ->
                	fullMediator.get().getInfo().setStandbyMediatorConfigured(configured)
                );

                cache().put(mediatorInfo.getMediatorId(), fullMediator.get());
                return true;
            } else {
                LOGGER.error("The Mediator cache not contains the Id={}", mediatorInfo.getMediatorId());
            }
        } catch (final CacheException e) {
            LOGGER.error("Error to update mediator={}", mediatorInfo.getMediatorId(), e);
            throw new BcbException(e);
        }
        return false;
    }

    @Override public ActivationAwareCacheWrapper<Integer, FullMediatorData> cache() {
        return CacheInMemoryFactory.getMediatorCache();
    }
}
