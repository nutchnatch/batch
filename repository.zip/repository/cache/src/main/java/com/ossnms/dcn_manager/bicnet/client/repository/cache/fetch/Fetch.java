package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Job to fetch cache elements.
 */
public class Fetch<K, V> implements Runnable {

    private static final Logger LOGGER = LoggerFactory.getLogger(Fetch.class);
    private final CacheInitializer initializer;
    private final Loader<K, V> loader;

    public Fetch(CacheInitializer initializer, Loader<K, V> loader) {
        this.initializer = initializer;
        this.loader = loader;
    }

    @Override public void run() {
        try {
            initializer.fetchStart();
            initializer.fetch(loader.loadElements());
        } catch (final CacheException e) {
            LOGGER.error("Critical error to load cache elements", e);
            initializer.fetchError();
        }
    }
}
