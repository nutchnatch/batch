package com.ossnms.dcn_manager.bicnet.client.repository.cache.listener;

import com.google.common.collect.Lists;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import net.sf.ehcache.CacheException;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.event.CacheEventListener;

import javax.annotation.Nonnull;
import java.util.Collection;

/**
 * Register callback methods that will be executed when a cache event occurs.
 *
 * @param <E> Cache element
 */
public class CacheEventListenerImpl<E> implements CacheEventListener, Cloneable {

    private final Collection<EventChangeListener<E>> listeners = Lists.newCopyOnWriteArrayList();

    /**
     * @param listener Add a listener to be advised.
     */
    public void addListener(@Nonnull final EventChangeListener<E> listener) {
        listeners.add(listener);
    }

    /**
     * @param listener Add a listener to be advised.
     */
    public void removeListener(@Nonnull final EventChangeListener<E> listener) {
        listeners.remove(listener);
    }

    /**
     * {@inheritDoc}
     */
    @Override @SuppressWarnings("unchecked") public void notifyElementRemoved(@Nonnull Ehcache cache,
            @Nonnull Element element) throws CacheException {
        listeners.iterator().forEachRemaining(next -> next.elementRemoved((E) element.getObjectValue()));
    }

    /**
     * {@inheritDoc}
     */
    @Override @SuppressWarnings("unchecked") public void notifyElementPut(@Nonnull Ehcache cache,
            @Nonnull Element element) throws CacheException {
        listeners.iterator().forEachRemaining(next -> next.elementAdded((E) element.getObjectValue()));
    }

    /**
     * {@inheritDoc}
     */
    @Override @SuppressWarnings("unchecked") public void notifyElementUpdated(@Nonnull Ehcache cache,
            @Nonnull Element element) throws CacheException {
        listeners.iterator().forEachRemaining(next -> next.elementUpdated((E) element.getObjectValue()));
    }

    /**
     * {@inheritDoc}
     */
    @Override public void notifyRemoveAll(@Nonnull Ehcache cache) {
        listeners.iterator().forEachRemaining(EventChangeListener::removeAll);
    }

    /**
     * {@inheritDoc}
     */
    @Override public void notifyElementExpired(@Nonnull Ehcache cache, @Nonnull Element element) {
        notifyElementRemoved(cache, element);
    }

    /**
     * {@inheritDoc}
     */
    @Override public void notifyElementEvicted(@Nonnull Ehcache cache, @Nonnull Element element) {
        notifyElementRemoved(cache, element);
    }

    /**
     * {@inheritDoc}
     */
    @Override public void dispose() {
        // Nothing to do.
    }

    /**
     * {@inheritDoc}
     */
    @Override public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
