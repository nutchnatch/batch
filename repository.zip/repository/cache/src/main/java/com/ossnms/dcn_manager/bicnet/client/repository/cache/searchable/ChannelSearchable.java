package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable;

import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByDisplayAddress;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByName;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByParent;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;

/**
 * Queries to be used in Channel cache
 *
 * @see com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchableAttributesForChannels
 */
public interface ChannelSearchable extends
        SearchByParent<FullChannelData>,
        SearchByName<FullChannelData>,
        SearchByDisplayAddress<FullChannelData> {
}
