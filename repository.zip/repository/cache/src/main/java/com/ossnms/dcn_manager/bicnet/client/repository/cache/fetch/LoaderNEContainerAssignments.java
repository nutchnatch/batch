package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;

import java.util.Collection;
import java.util.Optional;

public class LoaderNEContainerAssignments implements Loader<INeGenericContainerAssignmentId, INeGenericContainerAssignment> {
    private BicnetServerFacade facade;
    private DcnPluginHelper pluginHelper;

    public LoaderNEContainerAssignments(BicnetServerFacade facade, DcnPluginHelper pluginHelper) {
        this.facade = facade;
        this.pluginHelper = pluginHelper;
    }

    @Override public Collection<INeGenericContainerAssignment> loadValues() throws CacheException {
        return getPrivileged(() ->
                facade.getContainerService().getNeContainerAssignments(pluginHelper.getSessionContext()));
    }

    @Override
    public Optional<INeGenericContainerAssignment> loadValue(INeGenericContainerAssignmentId key) throws CacheException {
        return Optional.empty(); // Default - not applicable
    }

    @Override public INeGenericContainerAssignmentId keyFor(INeGenericContainerAssignment value) {
        return value.getNeGenericContainerAssignmentId();
    }
}
