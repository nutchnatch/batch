package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable;

import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByChannel;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByName;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByParent;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchBySystem;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;

import java.util.Collection;

/**
 * Queries for NE cache
 * @see com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchableAttributesForNEs
 */
public interface NeSearchable extends
        SearchByParent<FullNeData>,
        SearchByName<FullNeData>,
        SearchBySystem<FullNeData>,
        SearchByChannel<FullNeData>
{

}
