package com.ossnms.dcn_manager.bicnet.client.repository.cache.exception;

public class CacheNotInitializedException extends CacheException {

    private static final long serialVersionUID = 1L;
    
    /** @see CacheException#Exception() */
    public CacheNotInitializedException() {

    }

    /** @see CacheException#Exception(String) */
    public CacheNotInitializedException(String message) {
        super(message);
    }
}
