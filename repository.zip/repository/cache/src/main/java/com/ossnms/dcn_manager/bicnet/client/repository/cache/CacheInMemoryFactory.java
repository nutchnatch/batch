package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacadeSingleton;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelperSingleton;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.LoaderChannels;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.LoaderContainers;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.LoaderDomains;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.LoaderMediators;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.LoaderNEContainerAssignments;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.LoaderNEs;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.LoaderSystemContainerAssignments;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.LoaderSystemContainers;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.CacheEventListenerImpl;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.ChangeListener;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.ChannelSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.ContainerSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.DomainSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.MediationSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeContainerAssignmentSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.SystemAssignmentSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.SystemSearchable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchAttributesForContainers;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchAttributesForNEAssociation;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchAttributesForSystemAssociation;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchableAttributesForDomains;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchableAttributesForChannels;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchableAttributesForMediators;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchableAttributesForNEs;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.PersistenceConfiguration;
import net.sf.ehcache.config.PersistenceConfiguration.Strategy;
import net.sf.ehcache.event.CacheEventListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.CONTAINER_CACHE_NAME;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.DOMAIN_CACHE_NAME;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.EM_CACHE_NAME;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.ETERNAL;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.MAX_ELEMENTS_IN_MEMORY_ASSIGNMENT;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.MAX_ELEMENTS_IN_MEMORY_CONTAINER;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.MAX_ELEMENTS_IN_MEMORY_DOMAIN;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.MAX_ELEMENTS_IN_MEMORY_EM;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.MAX_ELEMENTS_IN_MEMORY_MEDIATOR;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.MAX_ELEMENTS_IN_MEMORY_NE;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.MEDIATOR_CACHE_NAME;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.NE_CACHE_NAME;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.NE_CONTAINER_ASSIGNMENT_CACHE_NAME;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.SYSTEM_CONTAINER_ASSIGNMENT_CACHE_NAME;
import static com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration.SYSTEM_CONTAINER_CACHE_NAME;

/**
 * Creates the In Memory based Caches.
 * <p>
 * Cache in memory based, in overflow case, the elements will be discarded.
 *
 * @see com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration
 * @see com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.Searchable
 */
public final class CacheInMemoryFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(CacheInMemoryFactory.class);

    private static final ActivationAwareCacheWrapper<Integer, FullNeData> EH_NE_CACHE_WRAPPER;
    private static final ActivationAwareCacheWrapper<Integer, FullChannelData> EH_CHANNEL_CACHE_WRAPPER;
    private static final ActivationAwareCacheWrapper<Integer, FullMediatorData> EH_MEDIATOR_CACHE_WRAPPER;
    private static final ActivationAwareCacheWrapper<Integer, IAS> EH_DOMAIN_CACHE_WRAPPER;
    private static final ActivationAwareCacheWrapper<Integer, IGenericContainer> EH_CONTAINER_CACHE_WRAPPER;
    private static final ActivationAwareCacheWrapper<Integer, ISystemContainer> EH_SYSTEM_CONTAINER_CACHE_WRAPPER;
    private static final ActivationAwareCacheWrapper<ISystemGenericContainerAssignmentId, ISystemGenericContainerAssignment> EH_SYSTEM_CONTAIENR_ASSIGNMENT_CACHE_WRAPPER;
    private static final ActivationAwareCacheWrapper<INeGenericContainerAssignmentId, INeGenericContainerAssignment> EH_NE_CONTAINER_ASSIGNMENT_CACHE_WRAPPER;

    private static final ChangeListener BICNET_CHANGE_LISTENER;

    static {
        EH_NE_CACHE_WRAPPER = buildNeCache();
        EH_CHANNEL_CACHE_WRAPPER = buildChannelsCache();
        EH_MEDIATOR_CACHE_WRAPPER = buildMediatorCache();
        EH_DOMAIN_CACHE_WRAPPER = buildDomainCache();
        EH_CONTAINER_CACHE_WRAPPER = buildContainerCache();
        EH_SYSTEM_CONTAINER_CACHE_WRAPPER = buildSystemContainerCache();
        EH_SYSTEM_CONTAIENR_ASSIGNMENT_CACHE_WRAPPER = buildSystemContainerAssignmentCache();
        EH_NE_CONTAINER_ASSIGNMENT_CACHE_WRAPPER = buildNeContainerAssignmentCache();

        BICNET_CHANGE_LISTENER = new ChangeListenerImpl();
    }

    private CacheInMemoryFactory() {
    }

    /**
     * Creates the Searchable NE cache
     */
    private static ActivationAwareCacheWrapper<Integer, FullNeData> buildNeCache() {
        final Ehcache ehcacheNe = createSearchableCache(NE_CACHE_NAME, new CacheEventListenerImpl<FullNeData>(), new SearchableAttributesForNEs().build(), MAX_ELEMENTS_IN_MEMORY_NE);
        NeSearchable searchableNe = () -> ehcacheNe;
        LoaderNEs loaderNEs = new LoaderNEs(BicnetServerFacadeSingleton.getInstance(), DcnPluginHelperSingleton.getInstance());

        return new ActivationAwareCacheWrapperImpl<>(ehcacheNe, searchableNe, loaderNEs);
    }

    /**
     * Creates the Searchable EM cache
     */
    private static ActivationAwareCacheWrapper<Integer, FullChannelData> buildChannelsCache() {
        final Ehcache ehcacheEm = createSearchableCache(EM_CACHE_NAME, new CacheEventListenerImpl<IEM>(), new SearchableAttributesForChannels().build(), MAX_ELEMENTS_IN_MEMORY_EM);
        ChannelSearchable searchableEm = () -> ehcacheEm;
        LoaderChannels loaderChannels = new LoaderChannels(BicnetServerFacadeSingleton.getInstance(), DcnPluginHelperSingleton.getInstance());

        return new ActivationAwareCacheWrapperImpl<>(ehcacheEm, searchableEm, loaderChannels);
    }

    /**
     * Creates the Searchable Mediator cache
     */
    private static ActivationAwareCacheWrapper<Integer, FullMediatorData> buildMediatorCache() {
        final Ehcache ehcacheMediator = createSearchableCache(MEDIATOR_CACHE_NAME, new CacheEventListenerImpl<IMediator>(), new SearchableAttributesForMediators().build(), MAX_ELEMENTS_IN_MEMORY_MEDIATOR);
        MediationSearchable searchableMediator = () -> ehcacheMediator;
        LoaderMediators loaderMediators = new LoaderMediators(BicnetServerFacadeSingleton.getInstance(), DcnPluginHelperSingleton.getInstance());

        return new ActivationAwareCacheWrapperImpl<>(ehcacheMediator, searchableMediator, loaderMediators);
    }

    /**
     * Creates the Searchable Domain cache
     */
    private static ActivationAwareCacheWrapper<Integer, IAS> buildDomainCache() {
        final Ehcache ehcacheDomain = createSearchableCache(DOMAIN_CACHE_NAME, new CacheEventListenerImpl<IAS>(), new SearchableAttributesForDomains().build(), MAX_ELEMENTS_IN_MEMORY_DOMAIN);
        DomainSearchable searchableDomain = () -> ehcacheDomain;
        LoaderDomains loaderDomains = new LoaderDomains(BicnetServerFacadeSingleton.getInstance(), DcnPluginHelperSingleton.getInstance());

        return new ActivationAwareCacheWrapperImpl<>(ehcacheDomain, searchableDomain, loaderDomains);
    }

    /**
     * Creates the Searchable Container cache
     */
    private static ActivationAwareCacheWrapper<Integer, IGenericContainer> buildContainerCache() {
        final Ehcache ehcacheContainer = createSearchableCache(CONTAINER_CACHE_NAME, new CacheEventListenerImpl<IGenericContainer>(), new SearchAttributesForContainers().build(), MAX_ELEMENTS_IN_MEMORY_CONTAINER);
        ContainerSearchable searchableContainer = () -> ehcacheContainer;
        LoaderContainers loaderContainers = new LoaderContainers(BicnetServerFacadeSingleton.getInstance(),
                DcnPluginHelperSingleton.getInstance());

        return new ActivationAwareCacheWrapperImpl<>(ehcacheContainer, searchableContainer, loaderContainers);
    }

    /**
     * Creates the Searchable System Container cache
     */
    private static ActivationAwareCacheWrapper<Integer, ISystemContainer> buildSystemContainerCache() {
        final Ehcache ehcacheContainer = createSearchableCache(SYSTEM_CONTAINER_CACHE_NAME, new CacheEventListenerImpl<IGenericContainer>(), new SearchAttributesForContainers().build(), MAX_ELEMENTS_IN_MEMORY_CONTAINER);
        SystemSearchable searchableContainer = () -> ehcacheContainer;
        LoaderSystemContainers loaderContainers = new LoaderSystemContainers(BicnetServerFacadeSingleton.getInstance(),
                DcnPluginHelperSingleton.getInstance());

        return new ActivationAwareCacheWrapperImpl<>(ehcacheContainer, searchableContainer, loaderContainers);
    }

    /**
     * Creates the Searchable System Container Assignment cache
     */
    private static ActivationAwareCacheWrapper<ISystemGenericContainerAssignmentId, ISystemGenericContainerAssignment> buildSystemContainerAssignmentCache() {
        final Ehcache ehcacheContainer = createSearchableCache(SYSTEM_CONTAINER_ASSIGNMENT_CACHE_NAME, new CacheEventListenerImpl<ISystemGenericContainerAssignment>(), 
                new SearchAttributesForSystemAssociation().build(), MAX_ELEMENTS_IN_MEMORY_ASSIGNMENT);
        SystemAssignmentSearchable searchableContainer =  () -> ehcacheContainer;
        LoaderSystemContainerAssignments loaderAssignments = new LoaderSystemContainerAssignments(
                BicnetServerFacadeSingleton.getInstance(), DcnPluginHelperSingleton.getInstance());

        return new ActivationAwareCacheWrapperImpl<>(ehcacheContainer, searchableContainer, loaderAssignments);
    }

    /**
     * Creates the Searchable NE Container Assignment cache
     */
    private static ActivationAwareCacheWrapper<INeGenericContainerAssignmentId, INeGenericContainerAssignment> buildNeContainerAssignmentCache() {
        final Ehcache ehcacheContainer = createSearchableCache(NE_CONTAINER_ASSIGNMENT_CACHE_NAME, new CacheEventListenerImpl<INeGenericContainerAssignment>(), 
                new SearchAttributesForNEAssociation().build(), MAX_ELEMENTS_IN_MEMORY_ASSIGNMENT);
        NeContainerAssignmentSearchable searchableContainer = () -> ehcacheContainer;
        LoaderNEContainerAssignments loaderAssignments = new LoaderNEContainerAssignments(
                BicnetServerFacadeSingleton.getInstance(), DcnPluginHelperSingleton.getInstance());

        return new ActivationAwareCacheWrapperImpl<>(ehcacheContainer, searchableContainer, loaderAssignments);
    }

    /**
     * Creates the memory based searchable cache.
     *
     * @see com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration.CacheInMemoryConfiguration
     * @see CacheConfiguration
     * @see CacheEventListener
     */
    private static Ehcache createSearchableCache(
            @Nonnull final String cacheName,
            @Nonnull final CacheEventListener listener,
            @Nonnull final net.sf.ehcache.config.Searchable searchable,
            final int maxElements) {
        LOGGER.info("In Memory CACHE name={}", cacheName);

        final CacheConfiguration configuration = new CacheConfiguration(cacheName, maxElements)
                .persistence(new PersistenceConfiguration()
                        .strategy(Strategy.NONE))
                .searchable(searchable)
                .eternal(ETERNAL);

        final Cache cache = new Cache(configuration);
        cache.getCacheEventNotificationService().registerListener(listener);

        CacheManager.getInstance().addCache(cache);

        return cache;
    }

    /**
     * @return The INE objects cache
     */
    @Nonnull
    public static ActivationAwareCacheWrapper<Integer, FullNeData> getNeCache() {
        return EH_NE_CACHE_WRAPPER;
    }

    /**
     * @return The IEM objects cache
     */
    @Nonnull
    public static ActivationAwareCacheWrapper<Integer, FullChannelData> getChannelCache() {
        return EH_CHANNEL_CACHE_WRAPPER;
    }

    /**
     * @return The IMediator objects cache
     */
    @Nonnull
    public static ActivationAwareCacheWrapper<Integer, FullMediatorData> getMediatorCache() {
        return EH_MEDIATOR_CACHE_WRAPPER;
    }

    /**
     * @return The IAS objects cache
     */
    @Nonnull
    public static ActivationAwareCacheWrapper<Integer, IAS> getDomainCache() {
        return EH_DOMAIN_CACHE_WRAPPER;
    }

    /**
     * @return The IGenericContainer objects cache
     */
    @Nonnull
    public static ActivationAwareCacheWrapper<Integer, IGenericContainer> getContainerCache() {
        return EH_CONTAINER_CACHE_WRAPPER;
    }

    /**
     * @return The ISystemContainer objects cache
     */
    @Nonnull
    public static ActivationAwareCacheWrapper<Integer, ISystemContainer> getSystemContainerCache() {
        return EH_SYSTEM_CONTAINER_CACHE_WRAPPER;
    }

    /**
     * @return The ISystemGenericContainerAssignment objects cache
     */
    @Nonnull
    public static ActivationAwareCacheWrapper<ISystemGenericContainerAssignmentId, ISystemGenericContainerAssignment> getSystemContainerAssignmentCache() {
        return EH_SYSTEM_CONTAIENR_ASSIGNMENT_CACHE_WRAPPER;
    }

    /**
     * @return The ISystemGenericContainerAssignment objects cache
     */
    @Nonnull
    public static ActivationAwareCacheWrapper<INeGenericContainerAssignmentId, INeGenericContainerAssignment> getNEContainerAssignmentCache() {
        return EH_NE_CONTAINER_ASSIGNMENT_CACHE_WRAPPER;
    }


    /**
     * @return The Bicnet Change Listener.
     * @see ChangeListener
     */
    @Nonnull
    public static ChangeListener getBicnetChangeListener() {
        return BICNET_CHANGE_LISTENER;
    }
}
