package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheFetchErrorException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheNotInitializedException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.Loader;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.CacheEventListenerImpl;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.Searchable;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Objects;
import java.util.Optional;

import static com.google.common.base.Preconditions.checkNotNull;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toList;

/**
 * Provides a generic implementation to access the cache instance.
 */
class CacheWrapperImpl<K, V> implements CacheWrapper<K, V> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CacheWrapperImpl.class);

    private static final String MSG_CACHE_NOT_LOADED_YET = "%s Cache is not loaded yet.";
    private static final String MSG_CACHE_ERROR = "Critical error loading cache %s.";

    private static final long TIME_OUT_MS = 120_000;

    private final Ehcache ehCache;
    private final Object mutex;
    private final Searchable<V> searchable;
    private final Loader<K, V> loader;
    private CacheState state;


    CacheWrapperImpl(@Nonnull final Ehcache ehCache, @Nonnull final Searchable<V> searchable, Loader<K, V> loader) {
        this.ehCache = ehCache;
        this.searchable = searchable;
        this.loader = loader;
        state = CacheState.NOT_LOADED;
        mutex = new Object();
    }

    @Override public Loader<K, V> getLoader() {
        return loader;
    }

    @Override
    public Optional<V> find(@Nonnull final K key) throws CacheException {
        checkNotNull(key);
        verifyCacheState();

        return ofNullable(getEhcache().get(key))
                .map(this::objectValue);
    }

    @Override
    public Collection<V> findAllKeys(@Nonnull final Collection<K> keys) throws CacheException {
        checkNotNull(keys);
        verifyCacheState();

        return getEhcache().getAll(keys).values().stream()
                .filter(Objects::nonNull)
                .map(this::objectValue)
                .collect(toList());
    }

    @Override
    public void put(@Nonnull final K key, @Nonnull final V value) throws CacheException {
        checkNotNull(key);
        checkNotNull(value);
        verifyCacheState();

        getEhcache().put(new Element(key, value));
    }

    @Override
    public void update(@Nonnull final K key, @Nonnull final V value) throws CacheException {
        checkNotNull(key);
        checkNotNull(value);
        verifyCacheState();

        getEhcache().replace(new Element(key, value));
    }

    @Override
    public void remove(@Nonnull final K key) throws CacheException {
        checkNotNull(key);
        verifyCacheState();

        getEhcache().remove(key);
    }

    @Override
    public Collection<V> all() throws CacheException {
        verifyCacheState();

        return getEhcache().getAll(getEhcache().getKeys())
                .values().stream()
                .filter(n -> n != null)
                .map(this::objectValue)
                .collect(toList());
    }

    @Override
    public Searchable<V> queries() throws CacheException {
        verifyCacheState();
        return searchable;
    }

    @Override
    public void clear() {
        setState(CacheState.NOT_LOADED);
    }


    @Override
    public void addChangeListener(@Nonnull final EventChangeListener<V> listener) {
        checkNotNull(listener);

        for (final CacheEventListenerImpl<V> cacheEventListener : getListeners()) {
            cacheEventListener.addListener(listener);
        }
    }

    @Override
    public void removeChangeListener(final EventChangeListener<V> listener) {
        if (null == listener) {
            LOGGER.warn("Listener == null for cache={}", getEhcache().getName());
            return;
        }

        for (final CacheEventListenerImpl<V> cacheEventListener : getListeners()) {
            cacheEventListener.removeListener(listener);
        }
    }

    /**
     * Gets all CacheEventListenerImpl from cache.
     */
    private Collection<CacheEventListenerImpl<V>> getListeners() {
        return getEhcache().getCacheEventNotificationService().getCacheEventListeners().stream()
                .filter(listener -> listener instanceof CacheEventListenerImpl)
                .map(listener -> (CacheEventListenerImpl<V>) listener)
                .collect(toList());
    }


    @Override
    public void fetchStart() {
        setState(CacheState.LOADING);
    }

    @Override
    public void fetch(@Nonnull final Collection<Element> elements) {
        setState(CacheState.LOADING);
        getEhcache().putAll(elements);
        setState(CacheState.LOADED);
    }

    @Override
    public void fetchError() {
        setState(CacheState.ERROR);
    }

    private String getCacheName() {
        return getEhcache().getName();
    }

    @Override
    public Ehcache getEhcache() {
        return ehCache;
    }

    private void setState(final CacheState state) {
        synchronized (mutex) {
            this.state = state;
            switch (state) {
                case NOT_LOADED:
                    getEhcache().removeAll();
                    mutex.notifyAll();
                    break;
                case LOADED:
                    mutex.notifyAll();
                    break;
                case ERROR:
                    mutex.notifyAll();
                    break;
                default:
                    break;
            }
        }
    }

    private void verifyCacheState() throws CacheNotInitializedException, CacheFetchErrorException {
        synchronized (mutex) {

            verifyOcurrenceOfAnyRelevantEvent();

            final long end = System.currentTimeMillis() + TIME_OUT_MS;

            while (state == CacheState.LOADING) {
                final long timeout = end - System.currentTimeMillis();

                if (timeout <= 0) {
                    throw new CacheNotInitializedException(String.format(MSG_CACHE_NOT_LOADED_YET, getCacheName()));
                }

                try {
                    mutex.wait(timeout);
                } catch (final InterruptedException e) {
                    throw new IllegalStateException("Shutting down.", e);
                }
            }

            verifyOcurrenceOfAnyRelevantEvent();
        }
    }

    private void verifyOcurrenceOfAnyRelevantEvent() throws CacheNotInitializedException, CacheFetchErrorException {

        //the cache was cleared
        if (state == CacheState.NOT_LOADED){
            throw new CacheNotInitializedException(String.format(MSG_CACHE_NOT_LOADED_YET, getCacheName()));
        }

        //error while fetching the data from server
        if (state == CacheState.ERROR) {
            throw new CacheFetchErrorException(String.format(MSG_CACHE_ERROR, getCacheName()));
        }
    }
}
