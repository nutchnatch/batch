package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerMarkable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;

public final class ContainerCacheManager
        extends AbstractVisitor<IGenericContainerId, IGenericContainer, IGenericContainerMarkable>
        implements CacheManager<Integer, IGenericContainer> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContainerCacheManager.class);
    private static final ContainerCacheManager INSTANCE = new ContainerCacheManager();

    private ContainerCacheManager() {
        super(CacheInMemoryFactory.getBicnetChangeListener(), IGenericContainerId.class, IGenericContainer.class,
                IGenericContainerMarkable.class);
    }

    /**
     * @return The singleton instance.
     */
    public static ContainerCacheManager getInstance() {
        return INSTANCE;
    }

    @Override protected void delete(IGenericContainerId managedObjectId) throws CacheException {
        cache().remove(managedObjectId.getId());
    }

    @Override protected void create(IGenericContainer managedObject) throws CacheException {
        cache().put(managedObject.getId(), managedObject);
    }

    @Override protected boolean update(IGenericContainerMarkable markable) throws CacheException {
        final Optional<IGenericContainer> container = cache().find(markable.getId());

        if (container.isPresent()) {
            container.get().update(markable);
            cache().update(container.get().getId(), container.get());
            return true;
        }
        LOGGER.error("The Container cache not contains the neId={}", markable.getId());
        return false;
    }

    @Override public ActivationAwareCacheWrapper<Integer, IGenericContainer> cache() {
        return CacheInMemoryFactory.getContainerCache();
    }
}