package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;

import java.util.Collection;
import java.util.Optional;

public class LoaderSystemContainerAssignments implements Loader<ISystemGenericContainerAssignmentId, ISystemGenericContainerAssignment> {
    private BicnetServerFacade facade;
    private DcnPluginHelper pluginHelper;

    public LoaderSystemContainerAssignments(BicnetServerFacade facade, DcnPluginHelper pluginHelper) {
        this.facade = facade;
        this.pluginHelper = pluginHelper;
    }

    @Override public Collection<ISystemGenericContainerAssignment> loadValues() throws CacheException {
        return getPrivileged(() -> 
                facade.getContainerService().getSystemContainerAssignments(pluginHelper.getSessionContext()));
    }

    @Override
    public Optional<ISystemGenericContainerAssignment> loadValue(ISystemGenericContainerAssignmentId key) throws CacheException {
        return Optional.empty(); // Default - not applicable
    }

    @Override public ISystemGenericContainerAssignmentId keyFor(ISystemGenericContainerAssignment value) {
        return value.getSystemGenericContainerAssignmentId();
    }
}
