package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginServerAccessController;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import net.sf.ehcache.Element;

import java.security.PrivilegedActionException;
import java.util.Collection;
import java.util.Optional;

import static java.util.stream.Collectors.toList;

public interface Loader<K, V> {
    int NO_LIMIT = -1;

    /**
     * Loads cache values
     */
    Collection<V> loadValues() throws CacheException;

    /**
     * Loads cache value for specified key
     */
    Optional<V> loadValue(K key) throws CacheException;

    /**
     * Function to extract key from value
     */
    K keyFor(V value);

    /**
     * Loads the cache elements.
     *
     * @return Cache elements for the specific implementation.
     */
    default Collection<Element> loadElements() throws CacheException {
        return loadValues().stream().map(this::toElement).collect(toList());
    }

    default Element toElement(V value) {
        return new Element(keyFor(value), value);
    }

    default <T> T getPrivileged(Getter<T> getter) throws CacheException {
        try {
            return (T) BiCNetPluginServerAccessController.doPrivileged(this, getter::get);
        } catch (PrivilegedActionException e) {
            throw new CacheException(e);
        }
    }

    interface Getter<T> {
        T get() throws BcbException;
    }
}
