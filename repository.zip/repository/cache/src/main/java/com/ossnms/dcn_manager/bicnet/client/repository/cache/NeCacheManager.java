package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.NeContainerAssignmentSearchable;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeDataCreateNotification.IVisitor;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfoNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationStateNotification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Optional;

public final class NeCacheManager extends AbstractVisitor<INEId, INE, INEMarkable>
        implements CacheManager<Integer, FullNeData>, ScsSynchronizationStateNotification.IVisitor, NeInfoNotification.IVisitor, IVisitor {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeCacheManager.class);

    private static final NeCacheManager INSTANCE = new NeCacheManager();

    private NeCacheManager() {
        super(CacheInMemoryFactory.getBicnetChangeListener(), INEId.class, INE.class, INEMarkable.class);
    }

    /**
     * @return The singleton instance.
     */
    public static NeCacheManager getInstance() {
        return INSTANCE;
    }

    @Override protected void delete(INEId managedObjectId) throws CacheException {
        LOGGER.debug("NeCacheManager::delete -> Delete Notification NeId={}", managedObjectId.getId());
        clearAssignments(managedObjectId);
        cache().remove(managedObjectId.getId());
    }

    @Override public boolean onFullNeDataCreation(FullNeDataCreateNotification notification) {
        FullNeData fullNeData = notification.getFullNeData();
        LOGGER.debug("NeCacheManager::creation -> Creation Notification NE={}", fullNeData);

        try {
            cache().put(fullNeData.getInfo().getNeId(), fullNeData);
            nofifyCreation(fullNeData.getNe());
            return true;
        } catch (CacheException e) {
            LOGGER.error("The NE cache not contains the id=", e);
        }
        return false;
    }

    @Override protected boolean update(INEMarkable markable) throws CacheException {
        LOGGER.debug("NeCacheManager::updateFromMarkable -> Update Notification NE={}", markable);

        final Optional<FullNeData> ne = cache().find(markable.getId());

        if (ne.isPresent()) {
            ne.get().getNe().update(markable);
            final FullNeData update = new FullNeData(ne.get().getNe(), ne.get().getInfo(), ne.get().getSynchronizationState());
            cache().update(update.getNe().getId(), update);
            return true;
        } else {
            LOGGER.error("The NE cache not contains the neId={}", markable.getId());
            return false;
        }
    }

    @Override
    public boolean onScsSynchronizationStateNotification(final ScsSynchronizationStateNotification notification) {
        final ScsSynchronizationState synchronizationState = notification.getSynchronizationState();
        LOGGER.debug("NeCacheManager::updateScsSyncState -> Update Notification NE={}", synchronizationState);

        try {
            final Optional<FullNeData> ne = cache().find(synchronizationState.getNeId());

            if (ne.isPresent()) {
                final FullNeData update = new FullNeData(ne.get().getNe(), ne.get().getInfo(), synchronizationState);
                cache().update(update.getNe().getId(), update);
                return true;
            } else {
                LOGGER.error("The NE cache not contains the neId={}", synchronizationState.getNeId());
            }
        } catch (final CacheException e) {
            LOGGER.error("Error to update NE={}", synchronizationState.getNeId(), e);
        }
        return false;
    }

    @Override public boolean onNeInfoNotification(NeInfoNotification notification) {
        final NeInfo neInfo = notification.getNeInfo();
        LOGGER.debug("NeCacheManager::updateNeInfo -> Update Notification NE={}", neInfo);

        try {
            final Optional<FullNeData> ne = cache().find(neInfo.getNeId());

            if (ne.isPresent()) {
                neInfo.getGuiActiveActualActivationState().ifPresent( state ->
                        ne.get().getInfo().setGuiActualActivationState(state)
                );

                neInfo.getGuiStandbyActualActivationState().ifPresent( state ->
                        ne.get().getInfo().setGuiStandbyActualActivationState(state)
                );

                neInfo.getUserText().ifPresent( text ->
                        ne.get().getInfo().setUserText(text)
                );

                neInfo.getStandbyDisplayState().ifPresent(text ->
                        ne.get().getInfo().setStandbyDisplayState(text)
                );

                neInfo.getNeRouteInfo().ifPresent(route ->
                        ne.get().getInfo().setNeRouteInfo(route)
                );

                neInfo.getAdditionalTypeInfo().ifPresent(typeInfo ->
                        ne.get().getInfo().setAdditionalTypeInfo(typeInfo)
                );
                cache().update(neInfo.getNeId(), ne.get());
                return true;
            } else {
                LOGGER.error("The NE cache not contains the neId={}", neInfo.getNeId());
            }
        } catch (final CacheException e) {
            LOGGER.error("Error to update NE={}", neInfo.getNeId(), e);
        }
        return false;
    }

    @Override public ActivationAwareCacheWrapper<Integer, FullNeData> cache() {
        return CacheInMemoryFactory.getNeCache();
    }

    private void clearAssignments(INEId managedObjectId) throws CacheException {
        NeContainerAssignmentSearchable queries = (NeContainerAssignmentSearchable) NEContainerAssignmentCacheManager
                .getInstance().cache().queries();
        final Collection<INeGenericContainerAssignment> assignments = queries.findByNetworkElementId(managedObjectId.getId());

        assignments.forEach(n -> {
            try {
                NEContainerAssignmentCacheManager.getInstance().cache().remove(n);
            } catch (CacheException e) {
                LOGGER.error("Error to delete NE assignment:" + n, e);
            }
        });
    }
}
