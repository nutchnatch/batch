package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentMarkable;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheInMemoryFactory.getSystemContainerAssignmentCache;

public final class SystemContainerAssignmentCacheManager
        extends AbstractVisitor<ISystemGenericContainerAssignmentId, ISystemGenericContainerAssignment, ISystemGenericContainerAssignmentMarkable>
        implements CacheManager<ISystemGenericContainerAssignmentId, ISystemGenericContainerAssignment>{

    private static final Logger LOGGER = LoggerFactory.getLogger(SystemContainerAssignmentCacheManager.class);
    private static final SystemContainerAssignmentCacheManager INSTANCE = new SystemContainerAssignmentCacheManager();
    
    private SystemContainerAssignmentCacheManager() {
        super(CacheInMemoryFactory.getBicnetChangeListener(), ISystemGenericContainerAssignmentId.class,
                ISystemGenericContainerAssignment.class, ISystemGenericContainerAssignmentMarkable.class);
    }

    public static SystemContainerAssignmentCacheManager getInstance() {
        return INSTANCE;
    }

    @Override protected void create(ISystemGenericContainerAssignment assignment) throws CacheException {
        cache().put(assignment.getSystemGenericContainerAssignmentId(), assignment);
    }

    @Override protected void delete(ISystemGenericContainerAssignmentId id) throws CacheException {
        cache().remove(id);
    }

    @Override protected boolean update(ISystemGenericContainerAssignmentMarkable markable) throws CacheException {
        ISystemGenericContainerAssignmentId id = markable.getSystemGenericContainerAssignmentId();
        final Optional<ISystemGenericContainerAssignment> assignmentOpt = cache().find(id);

        if (assignmentOpt.isPresent()) {
            ISystemGenericContainerAssignment assignment = assignmentOpt.get();
            assignment.update(markable);
            cache().update(id, assignment);
            return true;
        }
        LOGGER.error("The System Container Assignment cache not contains the id={}", id);
        return false;
    }

    @Override public ActivationAwareCacheWrapper<ISystemGenericContainerAssignmentId, ISystemGenericContainerAssignment> cache() {
        return getSystemContainerAssignmentCache();
    }
}
