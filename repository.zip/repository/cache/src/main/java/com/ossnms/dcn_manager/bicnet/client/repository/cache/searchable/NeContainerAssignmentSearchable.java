package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByContainer;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByNetworkElement;

/**
 * Queries for NeContainerAssignment cache
 * @see com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchAttributesForNEAssociation
 */
public interface NeContainerAssignmentSearchable extends
        SearchByContainer<INeGenericContainerAssignment>,
        SearchByNetworkElement<INeGenericContainerAssignment> {
}
