package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.facade.security.ILogonListener;

public interface CacheManager<K, V> {

    /**
     * @return The Plug-in Log-on/Log-off Listener
     */
    default ILogonListener buildListener() {
        return new CacheLogonListener<>(cache());
    }

    /**
     * @return The objects cache
     */
    ActivationAwareCacheWrapper<K, V> cache();
    
}
