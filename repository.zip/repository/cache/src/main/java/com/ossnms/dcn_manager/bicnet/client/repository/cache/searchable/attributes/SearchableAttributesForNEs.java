package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes;

import net.sf.ehcache.config.SearchAttribute;
import net.sf.ehcache.config.Searchable;

import org.apache.commons.lang3.builder.Builder;

/**
 * Define the searchable attributes for cache element "NE".
 */
public class SearchableAttributesForNEs implements Builder<Searchable>{

    /**
     * Builds the Searchable attributes for the NE cache. 
     */
    @Override
    public Searchable build() {
        final Searchable searchable = new Searchable();
        
        searchable.searchAttribute(new SearchAttribute().name(QueryAttribute.PARENT.name()).expression("value.getNe().getAssociatedEmId()"));
        searchable.searchAttribute(new SearchAttribute().name(QueryAttribute.NAME.name()).expression("value.getNe().getIdName()"));
        searchable.searchAttribute(new SearchAttribute().name(QueryAttribute.SYSTEM_ID.name()).expression("value.getNe().getAssociatedSystemContainerId()"));
        
        searchable.allowDynamicIndexing(true);
        
        return searchable;
    }
}
