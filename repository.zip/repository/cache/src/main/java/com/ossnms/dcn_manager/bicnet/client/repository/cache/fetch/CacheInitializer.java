package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import net.sf.ehcache.Element;

import java.util.Collection;

/**
 * Initialize the caches elements.
 */
public interface CacheInitializer {

    /**
     * Changes the cache state to {@link com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheState#LOADING}
     */
    void fetchStart();

    /**
     * Load the Elements to cache.
     * After all elements was loaded,  changes the cache state to {@link com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheState#LOADED}
     */
    void fetch(Collection<Element> elements);

    /**
     * Changes the cache state to {@link com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheState#NOT_LOADED}
     */
    void fetchError();
}
