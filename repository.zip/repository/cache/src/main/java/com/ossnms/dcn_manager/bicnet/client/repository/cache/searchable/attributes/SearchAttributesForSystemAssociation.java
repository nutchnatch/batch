package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes;

import net.sf.ehcache.config.SearchAttribute;
import net.sf.ehcache.config.Searchable;
import org.apache.commons.lang3.builder.Builder;

public class SearchAttributesForSystemAssociation implements Builder<Searchable>{

    @Override
    public Searchable build() {
        final Searchable searchable = new Searchable();

        searchable.searchAttribute(new SearchAttribute()
                .name(QueryAttribute.CONTAINER_ID.name())
                .expression("value.getGenericContainerId()"));

        searchable.searchAttribute(new SearchAttribute()
                .name(QueryAttribute.SYSTEM_ID.name())
                .expression("value.getSystemContainerId()"));
        
        searchable.allowDynamicIndexing(true);
        
        return searchable;
    }

}
