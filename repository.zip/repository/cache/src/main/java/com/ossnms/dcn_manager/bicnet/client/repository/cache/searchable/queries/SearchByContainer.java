package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries;

import net.sf.ehcache.search.Attribute;

import java.util.Collection;

import static com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.QueryAttribute.CONTAINER_ID;
import static java.util.stream.Collectors.toList;

public interface SearchByContainer<V> extends Searchable<V> {

    /**
     * Find all by container ID.
     */
    default Collection<V> findByContainerId(final int containerId) {
        final Attribute<Integer> attribute = getCache().getSearchAttribute(CONTAINER_ID.name());
        return find(query -> query
                .includeKeys()
                .addCriteria(attribute.eq(containerId))
        ).collect(toList());
    }
}
