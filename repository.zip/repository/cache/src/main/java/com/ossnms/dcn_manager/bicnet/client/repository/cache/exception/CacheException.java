package com.ossnms.dcn_manager.bicnet.client.repository.cache.exception;

import com.ossnms.dcn_manager.bicnet.client.api.exception.DcnClientException;

public class CacheException extends DcnClientException {

    private static final long serialVersionUID = -2558282048553071973L;

    /**
     * @see DcnClientException#Exception()
     */
    public CacheException() {

    }

    /**
     * @see DcnClientException#Exception(Throwable)
     */
    public CacheException(final Throwable cause) {
        super(cause);
    }

    /**
     * @see DcnClientException#Exception(String)
     */
    public CacheException(final String message) {
        super(message);
    }

    /**
     * @see DcnClientException#Exception(String, Object...)
     */
    public CacheException(final String format, final Object... formatParameters) {
        super(format, formatParameters);
    }
}
