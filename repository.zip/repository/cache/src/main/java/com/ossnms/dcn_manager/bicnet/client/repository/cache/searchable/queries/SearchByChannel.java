package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries;

import net.sf.ehcache.search.Attribute;

import java.util.Collection;

import static com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.QueryAttribute.PARENT;
import static java.util.stream.Collectors.toList;
import static net.sf.ehcache.search.Direction.ASCENDING;
import static net.sf.ehcache.search.Query.KEY;

public interface SearchByChannel<V>  extends Searchable<V> {

    default Collection<V> findByChannel(final int emId) {
        final Attribute<Integer> attribute = getCache().getSearchAttribute(PARENT.name());
        return find(query -> query
                .includeKeys()
                .addOrderBy(KEY, ASCENDING)
                .addCriteria(attribute.eq(emId))
        ).collect(toList());
    }
}
