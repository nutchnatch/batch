package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByName;

/**
 * Queries for Domain cache
 * @see com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchableAttributesForDomains
 */
public interface DomainSearchable extends SearchByName<IAS> {
}
