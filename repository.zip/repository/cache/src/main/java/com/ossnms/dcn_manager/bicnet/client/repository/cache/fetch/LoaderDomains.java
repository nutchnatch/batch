package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

import static java.util.Arrays.asList;
import static java.util.Optional.ofNullable;

/**
 * Loads Domains from DCN Manager private facade {@link BicnetServerFacade}.
 */
public class LoaderDomains implements Loader<Integer, IAS> {
    private final BicnetServerFacade service;
    private final DcnPluginHelper pluginHelper;

    public LoaderDomains(@Nonnull final BicnetServerFacade service, @Nonnull final DcnPluginHelper pluginHelper) {
        this.service = service;
        this.pluginHelper = pluginHelper;
    }

    @Override public Collection<IAS> loadValues() throws CacheException {
        return asList(getPrivileged(() ->
                service.getDomainService().getASList(pluginHelper.getSessionContext())));
    }

    @Override public Optional<IAS> loadValue(Integer id) throws CacheException {
        return ofNullable(getPrivileged(() ->
                service.getDomainService().getSingleAS(pluginHelper.getSessionContext(), new ASIdItem(id))));
    }

    @Override public Integer keyFor(IAS domain) {
        return domain.getId();
    }

}