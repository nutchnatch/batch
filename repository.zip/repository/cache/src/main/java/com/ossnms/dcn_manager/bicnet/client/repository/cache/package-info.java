/**
 * Contains the EM/NE objects cache.  
 */
package com.ossnms.dcn_manager.bicnet.client.repository.cache;