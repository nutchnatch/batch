package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByName;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByParent;

/**
 * Queries for System cache
 * @see com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchAttributesForContainers
 */
public interface SystemSearchable extends
        SearchByParent<ISystemContainer>,
        SearchByName<ISystemContainer> {
}
