package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

import static java.util.Arrays.asList;
import static java.util.Optional.ofNullable;

/**
 * Loads System Containers from DCN Manager private facade {@link BicnetServerFacade}.
 */
public class LoaderSystemContainers implements Loader<Integer, ISystemContainer> {
    private final BicnetServerFacade service;
    private final DcnPluginHelper pluginHelper;

    public LoaderSystemContainers(@Nonnull final BicnetServerFacade service, @Nonnull final DcnPluginHelper pluginHelper) {
        this.service = service;
        this.pluginHelper = pluginHelper;
    }

    @Override public Collection<ISystemContainer> loadValues() throws CacheException {
        return asList(getPrivileged(() ->
                service.getDcnPublicServices().getSystemContainerList(
                        pluginHelper.getSessionContext(), null, null, NO_LIMIT))
                .getData());
    }

    @Override public Optional<ISystemContainer> loadValue(Integer id) throws CacheException {
        return ofNullable(getPrivileged(() ->
                service.getDcnPublicServices().getSingleSystemContainer(
                        pluginHelper.getSessionContext(), new SystemContainerIdItem(id))));
    }

    @Override public Integer keyFor(ISystemContainer container) {
        return container.getId();
    }
}