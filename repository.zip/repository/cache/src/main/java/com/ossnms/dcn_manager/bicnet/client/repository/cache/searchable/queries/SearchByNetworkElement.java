package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries;

import net.sf.ehcache.search.Attribute;

import java.util.Collection;

import static com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.QueryAttribute.NE_ID;
import static java.util.stream.Collectors.toList;

public interface SearchByNetworkElement<V> extends Searchable<V> {

    /**
     * Find all by container network element id.
     */
    default Collection<V> findByNetworkElementId(final int neId) {
        final Attribute<Integer> attribute = getCache().getSearchAttribute(NE_ID.name());
        return find(query -> query
                .includeKeys()
                .addCriteria(attribute.eq(neId))
        ).collect(toList());
    }
}
