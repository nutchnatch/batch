package com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginEmNeChangeListener;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.CacheInMemoryFactory;

/**
 * Created by chfranco on 13-11-2015.
 */
public class BicnetChangeListenerManager {

    public final void add(BiCNetPluginEmNeChangeListener listener) {
        CacheInMemoryFactory.getBicnetChangeListener().add(listener);
    }

    public final void remove(BiCNetPluginEmNeChangeListener listener) {
        CacheInMemoryFactory.getBicnetChangeListener().remove(listener);
    }
}
