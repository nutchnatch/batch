package com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ChannelCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ContainerCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.DomainCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.MediatorCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NEContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.SystemContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.SystemContainerCacheManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;

/**
 * Add/remove the Cache listeners.
 */
public class CacheListenersRegistrationManager implements ListenersRegistrationManager {

    @Override
    public void addNeListener(EventChangeListener<FullNeData> listener) {
        NeCacheManager.getInstance().cache().addChangeListener(listener);
    }

    @Override
    public void addChannelListener(EventChangeListener<FullChannelData> listener) {
        ChannelCacheManager.getInstance().cache().addChangeListener(listener);
    }

    @Override
    public void addMediatorListener(EventChangeListener<FullMediatorData> listener) {
        MediatorCacheManager.getInstance().cache().addChangeListener(listener);
    }

    @Override
    public void addContainerListener(EventChangeListener<IGenericContainer> listener) {
        ContainerCacheManager.getInstance().cache().addChangeListener(listener);
    }

    /**
     * Add a change listener for ISystemContainer objects.
     */
    @Override public void addSystemContainerListener(EventChangeListener<ISystemContainer> listener) {
        SystemContainerCacheManager.getInstance().cache().addChangeListener(listener);
    }

    @Override
    public void addDomainListener(EventChangeListener<IAS> listener) {
        DomainCacheManager.getInstance().cache().addChangeListener(listener);
    }

    @Override public void addSystemContainerAssignmentListener(EventChangeListener<ISystemGenericContainerAssignment> listener) {
        SystemContainerAssignmentCacheManager.getInstance().cache().addChangeListener(listener);
    }

    @Override
    public void addNEContainerAssignmentListener(EventChangeListener<INeGenericContainerAssignment> listener) {
        NEContainerAssignmentCacheManager.getInstance().cache().addChangeListener(listener);
    }

    @Override
    public void removeNeListener(EventChangeListener<FullNeData> listener) {
        NeCacheManager.getInstance().cache().removeChangeListener(listener);
    }

    @Override
    public void removeChannelListener(EventChangeListener<FullChannelData> listener) {
        ChannelCacheManager.getInstance().cache().removeChangeListener(listener);
    }

    @Override
    public void removeMediatorListener(EventChangeListener<FullMediatorData> listener) {
        MediatorCacheManager.getInstance().cache().removeChangeListener(listener);
    }

    @Override
    public void removeContainerListener(EventChangeListener<IGenericContainer> listener) {
        ContainerCacheManager.getInstance().cache().removeChangeListener(listener);
    }

    @Override public void removeSystemContainerListener(EventChangeListener<ISystemContainer> listener) {
        SystemContainerCacheManager.getInstance().cache().removeChangeListener(listener);
    }

    @Override
    public void removeSystemContainerAssignmentListener(EventChangeListener<ISystemGenericContainerAssignment> listener) {
        SystemContainerAssignmentCacheManager.getInstance().cache().removeChangeListener(listener);
    }

    @Override
    public void removeNEContainerAssignmentListener(EventChangeListener<INeGenericContainerAssignment> listener) {
        NEContainerAssignmentCacheManager.getInstance().cache().removeChangeListener(listener);
    }

    @Override
    public void removeDomainListener(EventChangeListener<IAS> listener) {
        DomainCacheManager.getInstance().cache().removeChangeListener(listener);
    }
}
