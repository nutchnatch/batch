package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.ChangeListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

/**
 * Implements the BCB Manage Object visitors for Creation, AVC, Deletion.
 */
public abstract class AbstractVisitor<ID extends IManagedObjectId, MO extends  IManagedObject, MARKABLE extends  IManagedObjectMarkable>
        implements ObjectCreation.IVisitor, AttributeValueChange.IVisitor, ObjectDeletion.IVisitor {

    private static final Logger LOGGER = LoggerFactory.getLogger(MediatorCacheManager.class);
    private final ChangeListener changeListener;
    private final Class<ID> idClass;
    private final Class<MO> moClass;
    private final Class<MARKABLE> markableClass;

    protected AbstractVisitor(@Nonnull final ChangeListener changeListener, Class<ID> idClass, Class<MO> moClass, Class<MARKABLE> markableClass) {
        this.changeListener = changeListener;
        this.idClass = idClass;
        this.moClass = moClass;
        this.markableClass = markableClass;
    }

    @Override public final boolean onObjectDeletion(ObjectDeletion objectDeletion) throws BcbException {
        IManagedObjectId managedObjectId = objectDeletion.getDeletedObject();

        if (idClass.isInstance(managedObjectId)) {
            try {
                delete((ID)objectDeletion.getDeletedObject());
                changeListener.onDelete(managedObjectId);
                return true;
            } catch (final CacheException e) {
                LOGGER.error("Error to delete element=" + managedObjectId.key(), e);
                throw new BcbException(e);
            }
        }
        return false;
    }

    @Override public final boolean onObjectCreation(ObjectCreation objectCreation) throws BcbException {
        IManagedObject managedObject = objectCreation.getCreatedObject();

        if (moClass.isInstance(managedObject)) {
            try {
                create((MO)objectCreation.getCreatedObject());
                changeListener.onCreate(managedObject);
                return true;
            } catch (final CacheException e) {
                LOGGER.error("Error to create element=" + managedObject.key(), e);
                throw new BcbException(e);
            }
        }
        return false;
    }

    @Override public final boolean onAttributeValueChange(AttributeValueChange attributeValueChange) throws BcbException {
        IManagedObjectMarkable managedObjectMarkable = attributeValueChange.getChangedObject();

        if (markableClass.isInstance(managedObjectMarkable)) {
            try {
                if (update((MARKABLE)attributeValueChange.getChangedObject())) {
                    changeListener.onChanged(managedObjectMarkable);
                    return true;
                }
            } catch (final CacheException e) {
                LOGGER.error("Error to update mediator=" + managedObjectMarkable.key(), e);
                throw new BcbException(e);
            }
        }
        return false;
    }

    protected abstract void delete(ID managedObjectId) throws CacheException;

    protected void create(MO managedObject) throws CacheException {};

    protected void nofifyCreation(MO managedObject) throws CacheException {
        changeListener.onCreate(managedObject);
    };

    protected abstract boolean update(MARKABLE markable) throws CacheException;
}
