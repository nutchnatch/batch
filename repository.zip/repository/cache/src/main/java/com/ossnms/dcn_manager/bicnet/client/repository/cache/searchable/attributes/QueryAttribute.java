package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes;

/**
 * Attribute names to be associate with the attributes of the cache elements.
 */
public enum QueryAttribute {
    PARENT, NAME, SYSTEM_ID, STATE, ADDRESS, CONTAINER_ID, NE_ID
}