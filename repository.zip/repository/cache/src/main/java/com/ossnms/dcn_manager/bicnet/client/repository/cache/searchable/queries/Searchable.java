package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries;

import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.search.Query;
import net.sf.ehcache.search.Result;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;

public interface Searchable<V> {

    Ehcache getCache();

    default Stream<V> find(Function<Query, Query> queryBuilder) {
        Function<Result, V> toCacheValue = result -> {
            final Element element = getCache().get(result.getKey());
            return (V) element.getObjectValue();
        };
        Query query = queryBuilder.apply(getCache().createQuery());
        List<Result> results = query.execute().all();
        return results.stream().map(toCacheValue);
    }
}
