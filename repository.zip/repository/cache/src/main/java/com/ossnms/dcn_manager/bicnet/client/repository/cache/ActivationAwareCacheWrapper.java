/*
* Copyright (C) Coriant
* The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
* Offenders will be liable for damages.
* All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
* Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
*
*/

package com.ossnms.dcn_manager.bicnet.client.repository.cache;

/**
 * Adds the activation capacity to the cache. A deactivated cache will throw IllegalStateException
 * if there are attempts to interact with it. To restore the cache functionality, the activate method
 * must be invoked
 *
 * @param <K>
 * @param <V>
 */
public interface ActivationAwareCacheWrapper<K, V> extends CacheWrapper<K,V> {

    /**
     * Deactivates the cache so it cannot be used anymore. All methods invoked which
     * are operating in cache elements will throw an IllegalStateException
     *
     */
    void deactivate();

    /**
     * Activates the cache so it can be used again.
     *
     */
    void activate();


}
