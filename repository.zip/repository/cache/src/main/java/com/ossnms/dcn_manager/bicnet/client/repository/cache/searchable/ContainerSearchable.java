package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByName;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.SearchByParent;

/**
 * Queries for Container cache
 * @see com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.SearchAttributesForContainers
 */
public interface ContainerSearchable extends
        SearchByParent<IGenericContainer>,
        SearchByName<IGenericContainer>{
}
