/*
* Copyright (C) Coriant
* The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
* Offenders will be liable for damages.
* All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
* Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
*
*/

package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.Loader;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.Searchable;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;


/**
 *
 * Decorator for the base implementation of CacheWrapper interface. The main purpose
 * of this decorator is to validate if cache is active, if not, it should throw an exception.
 * Usually the activate and deactivate methods will be called from logon and logoff events
 * respectively
 *
 * @param <K>
 * @param <V>
 */
class ActivationAwareCacheWrapperImpl<K,V> implements ActivationAwareCacheWrapper<K,V> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ActivationAwareCacheWrapperImpl.class);

    private static final String MSG_CACHE_NOT_ACTIVE = "%s Cache is not active!";

    private final CacheWrapper<K,V> delegate;

    private volatile boolean isActive;

    private final String cacheName;

    public ActivationAwareCacheWrapperImpl(@Nonnull final Ehcache ehCache, @Nonnull final Searchable<V> searchable, Loader<K, V> loader){
        delegate = new CacheWrapperImpl<>(ehCache,searchable,loader);
        this.isActive = true;
        this.cacheName = ehCache.getName();
    }

    @Override
    public void put(K key, V value) throws CacheException {
        validateIfCacheIsActive();
        delegate.put(key, value);
    }

    @Override
    public void update(@Nonnull K key, @Nonnull V value) throws CacheException {
        validateIfCacheIsActive();
        delegate.update(key, value);
    }

    @Override
    public Optional<V> find(K key) throws CacheException {
        validateIfCacheIsActive();
        return delegate.find(key);
    }

    @Override
    public Collection<V> findAllKeys(@Nonnull Collection<K> keys) throws CacheException {
        validateIfCacheIsActive();
        return delegate.findAllKeys(keys);
    }

    @Override
    public void remove(K key) throws CacheException {
        validateIfCacheIsActive();
        delegate.remove(key);
    }

    @Override
    public void clear() throws CacheException {
        validateIfCacheIsActive();
        delegate.clear();
    }

    @Override
    public Collection<V> all() throws CacheException {
        validateIfCacheIsActive();
        return delegate.all();
    }

    @Override
    public Ehcache getEhcache() {
        return delegate.getEhcache();
    }

    @Override
    public Loader<K, V> getLoader() {
        return delegate.getLoader();
    }

    @Override
    public Searchable<V> queries() throws CacheException {
        validateIfCacheIsActive();
        return delegate.queries();
    }

    @Override
    public Optional<V> findOrFetch(K key) throws CacheException {
        validateIfCacheIsActive();
        return delegate.findOrFetch(key);
    }

    @Override
    public Optional<V> fetch(K key) throws CacheException {
        validateIfCacheIsActive();
        return delegate.fetch(key);
    }

    @Override
    public void fetchStart() {
        validateIfCacheIsActive();
        delegate.fetchStart();
    }

    @Override
    public void fetch(Collection<Element> elements) {
        validateIfCacheIsActive();
        delegate.fetch(elements);
    }

    @Override
    public void fetchError() {
        validateIfCacheIsActive();
        delegate.fetchError();
    }

    @Override
    public void addChangeListener(EventChangeListener<V> listener) {
        delegate.addChangeListener(listener);
    }

    @Override
    public void removeChangeListener(EventChangeListener<V> listener) {
        delegate.removeChangeListener(listener);
    }

    @Override
    public void deactivate() {
        this.isActive = false;
        try{
            delegate.clear();
        }catch (CacheException e){
            LOGGER.error("Error to clear cache=" + cacheName, e);
        }

    }

    @Override
    public void activate() {
        this.isActive = true;
    }

    private void validateIfCacheIsActive(){
        if (!isActive){
            throw new IllegalStateException(String.format(MSG_CACHE_NOT_ACTIVE, cacheName));
        }
    }
}
