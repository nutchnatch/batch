package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries;

import net.sf.ehcache.search.Attribute;

import java.util.Collection;

import static com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.QueryAttribute.SYSTEM_ID;
import static java.util.stream.Collectors.toList;
import static net.sf.ehcache.search.Direction.ASCENDING;
import static net.sf.ehcache.search.Query.KEY;

public interface SearchBySystem<V> extends Searchable<V> {

    /**
     * Find all by system container ID.
     */
    default Collection<V> findBySystemContainerId(final int systemContainerId) {
        final Attribute<Integer> attribute = getCache().getSearchAttribute(SYSTEM_ID.name());
        return find(query -> query
                .includeKeys()
                .addOrderBy(KEY, ASCENDING)
                .addCriteria(attribute.eq(systemContainerId))
        ).collect(toList());
    }
}
