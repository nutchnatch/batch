package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

import static java.util.Optional.ofNullable;

/**
 * Loads Channels from DCN Manager public facade {@link BicnetServerFacade}.
 */
public class LoaderChannels implements Loader<Integer, FullChannelData> {
    private final BicnetServerFacade service;
    private final DcnPluginHelper pluginHelper;

    public LoaderChannels(@Nonnull final BicnetServerFacade service, @Nonnull final DcnPluginHelper pluginHelper) {
        this.service = service;
        this.pluginHelper = pluginHelper;
    }

    @Override public Collection<FullChannelData> loadValues() throws CacheException {
        return getPrivileged(() ->
                service.getChannelService().getFullChannelList(pluginHelper.getSessionContext()));
    }

    @Override public Optional<FullChannelData> loadValue(Integer id) throws CacheException {
        return ofNullable(getPrivileged(() ->
                service.getChannelService().getFullChannel(pluginHelper.getSessionContext(), id)));
    }

    @Override public Integer keyFor(FullChannelData channelData) {
        return channelData.getChannel().getId();
    }

}
