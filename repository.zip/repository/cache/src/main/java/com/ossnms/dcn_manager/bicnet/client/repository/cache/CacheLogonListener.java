package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.facade.security.ILogonListener;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.Fetch;

/**
 * Log-on listener for DCN caches.
 */
class CacheLogonListener<K, V> implements ILogonListener {

    private final ActivationAwareCacheWrapper<K, V> cache;

    private Thread loaderThread;

    CacheLogonListener(ActivationAwareCacheWrapper<K, V> cache) {
        this.cache = cache;
    }

    /**
     * Release the cache on user log-off.
     *
     * @param context Session context identifying the session that has terminated.
     */
    @Override
    public void onUserLoggedOff(ISessionContext context) {
        cache.deactivate();
    }

    /**
     * Load the cache on user log-on.
     *
     * @param context current context
     */
    @Override
    public void onUserLoggedOn(ISessionContext context) {
        cache.activate();
        loaderThread = new Thread(new Fetch<>(cache, cache.getLoader()));
        loaderThread.start();
    }

    @Override
    public void onUserLoggingOff(ISessionContext context) {
        //loaderThread should not be null... anyway we validate before interrupting the thread
        if (loaderThread != null && loaderThread.isAlive()){
            loaderThread.interrupt();
        }
    }

    @Override
    public void onUserPermissionsChanged(ISessionContext context) {
    }
}
