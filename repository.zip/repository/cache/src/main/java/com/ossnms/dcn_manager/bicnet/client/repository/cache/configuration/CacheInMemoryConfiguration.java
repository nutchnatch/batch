package com.ossnms.dcn_manager.bicnet.client.repository.cache.configuration;

import com.ossnms.bicnet.util.ApplicationProperties;
import org.apache.commons.lang3.math.NumberUtils;

import java.util.Optional;

/**
 *  Configuration for Cache Memory based implementation.
 *  
 *  Loads configuration from the cache-config.properties file, if the value not exists or is invalid
 *  a default value will be loaded.
 */
public final class CacheInMemoryConfiguration {
    private static final ApplicationProperties CONFIGURATION = ApplicationProperties.getInstance("cache-config.properties");

    private static final int DEFAULT_NE_MAX_ELEMENTS = 100_000;
    private static final int DEFAULT_EM_MAX_ELEMENTS = 100_000;
    private static final int DEFAULT_MEDIATOR_MAX_ELEMENTS = 100_000;
    private static final int DEFAULT_DOMAIN_MAX_ELEMENTS = 100_000;
    private static final int DEFAULT_CONTAINER_MAX_ELEMENTS = 100_000;
    private static final int DEFAULT_ASSIGNMENT_MAX_ELEMENTS = 100_000;
    
    /** whether the elements in the cache are eternal, i.e. never expire */
    public static final boolean ETERNAL;

    /** The maximum number of elements in memory, before they are evicted (0 == no limit) */
    public static final int MAX_ELEMENTS_IN_MEMORY_NE;
    public static final int MAX_ELEMENTS_IN_MEMORY_EM;
    public static final int MAX_ELEMENTS_IN_MEMORY_MEDIATOR;
    public static final int MAX_ELEMENTS_IN_MEMORY_DOMAIN;
    public static final int MAX_ELEMENTS_IN_MEMORY_CONTAINER;
    public static final int MAX_ELEMENTS_IN_MEMORY_ASSIGNMENT;

    public static final String NE_CACHE_NAME;
    public static final String EM_CACHE_NAME;
    public static final String MEDIATOR_CACHE_NAME;
    public static final String DOMAIN_CACHE_NAME;
    public static final String SCS_SYNC_STATE_CACHE_NAME;
    public static final String CONTAINER_CACHE_NAME;
    public static final String SYSTEM_CONTAINER_CACHE_NAME;
    public static final String SYSTEM_CONTAINER_ASSIGNMENT_CACHE_NAME;
    public static final String NE_CONTAINER_ASSIGNMENT_CACHE_NAME;

    static {
        ETERNAL = Optional.ofNullable(Boolean.valueOf(CONFIGURATION.getProperty("ELEMENTS_ARE_ETERNAL"))).orElse(true);

        NE_CACHE_NAME = Optional.ofNullable(CONFIGURATION.getProperty("NE_CACHE_NAME")).orElse("DCN.NECache");
        EM_CACHE_NAME = Optional.ofNullable(CONFIGURATION.getProperty("EM_CACHE_NAME")).orElse("DCN.EMCache");
        MEDIATOR_CACHE_NAME = Optional.ofNullable(CONFIGURATION.getProperty("MEDIATOR_CACHE_NAME")).orElse("DCN.MediatorCache");
        DOMAIN_CACHE_NAME = Optional.ofNullable(CONFIGURATION.getProperty("DOMAIN_CACHE_NAME")).orElse("DCN.DomainCache");
        SCS_SYNC_STATE_CACHE_NAME = Optional.ofNullable(CONFIGURATION.getProperty("SCS_SYNC_STATE_CACHE_NAME")).orElse("DCN.ScsSyncState");
        CONTAINER_CACHE_NAME = Optional.ofNullable(CONFIGURATION.getProperty("CONTAINER_CACHE_NAME")).orElse("DCN.ContainerCache");
        SYSTEM_CONTAINER_CACHE_NAME = Optional.ofNullable(CONFIGURATION.getProperty("SYSTEM_CONTAINER_CACHE_NAME")).orElse("DCN.SystemContainerCache");
        SYSTEM_CONTAINER_ASSIGNMENT_CACHE_NAME = Optional.ofNullable(CONFIGURATION.getProperty("SYSTEM_CONTAINER_ASSIGNMENT_CACHE_NAME")).orElse("DCN.SystemContainerAssignmentCache");
        NE_CONTAINER_ASSIGNMENT_CACHE_NAME = Optional.ofNullable(CONFIGURATION.getProperty("NE_CONTAINER_ASSIGNMENT_CACHE_NAME")).orElse("DCN.NEContainerAssignmentCache");

        MAX_ELEMENTS_IN_MEMORY_NE = NumberUtils.toInt(CONFIGURATION.getProperty("MAX_ELEMENTS_IN_MEMORY_NE"), DEFAULT_NE_MAX_ELEMENTS);
        MAX_ELEMENTS_IN_MEMORY_EM = NumberUtils.toInt(CONFIGURATION.getProperty("MAX_ELEMENTS_IN_MEMORY_EM"), DEFAULT_EM_MAX_ELEMENTS);
        MAX_ELEMENTS_IN_MEMORY_MEDIATOR = NumberUtils.toInt(CONFIGURATION.getProperty("MAX_ELEMENTS_IN_MEMORY_MEDIATOR"), DEFAULT_MEDIATOR_MAX_ELEMENTS);
        MAX_ELEMENTS_IN_MEMORY_DOMAIN = NumberUtils.toInt(CONFIGURATION.getProperty("MAX_ELEMENTS_IN_MEMORY_DOMAIN"), DEFAULT_DOMAIN_MAX_ELEMENTS);
        MAX_ELEMENTS_IN_MEMORY_CONTAINER = NumberUtils.toInt(CONFIGURATION.getProperty("MAX_ELEMENTS_IN_MEMORY_CONTAINER"), DEFAULT_CONTAINER_MAX_ELEMENTS);
        MAX_ELEMENTS_IN_MEMORY_ASSIGNMENT = NumberUtils.toInt(CONFIGURATION.getProperty("MAX_ELEMENTS_IN_MEMORY_ASSIGNMENT"), DEFAULT_ASSIGNMENT_MAX_ELEMENTS);
    }

    private CacheInMemoryConfiguration() {
    }
}
