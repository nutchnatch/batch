package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries;

import net.sf.ehcache.search.Attribute;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.attributes.QueryAttribute.NAME;
import static net.sf.ehcache.search.Direction.ASCENDING;
import static net.sf.ehcache.search.Query.KEY;

public interface SearchByName<V> extends Searchable<V> {
    /**
     * Find all MOs by id name.
     *
     * @param idName
     * @return
     */
    default Optional<V> findByIdName(@Nonnull final String idName) {
        final Attribute<String> attribute = getCache().getSearchAttribute(NAME.name());
        return find(query -> query
                .includeKeys()
                .addOrderBy(KEY, ASCENDING)
                .addCriteria(attribute.eq(idName))
        ).findFirst();
    }

}
