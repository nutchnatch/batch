package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import com.ossnms.dcn_manager.bicnet.client.api.plugin.BicnetServerFacade;
import com.ossnms.dcn_manager.bicnet.client.api.plugin.DcnPluginHelper;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

import static java.util.Optional.ofNullable;

/**
 * Loads Mediators from DCN Manager private facade {@link BicnetServerFacade}.
 */
public class LoaderMediators implements Loader<Integer, FullMediatorData> {
    private final BicnetServerFacade service;
    private final DcnPluginHelper pluginHelper;

    public LoaderMediators(@Nonnull final BicnetServerFacade service, @Nonnull final DcnPluginHelper pluginHelper) {
        this.service = service;
        this.pluginHelper = pluginHelper;
    }

    @Override public Collection<FullMediatorData> loadValues() throws CacheException {
        return getPrivileged(() ->
                service.getMediatorService().getFullMediatorList(pluginHelper.getSessionContext()));
    }

    @Override public Optional<FullMediatorData> loadValue(Integer id) throws CacheException {
        return ofNullable(getPrivileged(() ->
                service.getMediatorService().getFullMediator(pluginHelper.getSessionContext(), id)));
    }

    @Override public Integer keyFor(FullMediatorData mediatorData) {
        return mediatorData.getMediator().getId();
    }

}
