package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.google.common.collect.Lists;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginEmNeChangeListener;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.ChangeListener;

import javax.annotation.Nonnull;
import java.util.Collection;

/**
 * ChangeListener implementation.
 */
class ChangeListenerImpl implements ChangeListener {

    private final Collection<BiCNetPluginEmNeChangeListener> listeners;

    ChangeListenerImpl() {
        this.listeners = Lists.newCopyOnWriteArrayList();
    }

    @Override public void onCreate(@Nonnull final IManagedObject managedObject) {
        listeners.iterator().forEachRemaining(listener -> listener.onCreate(managedObject));
    }

    @Override public void onChanged(@Nonnull final IManagedObjectMarkable managedObject) {
        listeners.iterator().forEachRemaining(listener -> listener.onChanged(managedObject));
    }

    @Override public void onDelete(@Nonnull final IManagedObjectId managedObject) {
        listeners.iterator().forEachRemaining(listener -> listener.onDelete(managedObject));
    }

    @Override public void add(@Nonnull final BiCNetPluginEmNeChangeListener listener) {
        listeners.add(listener);
    }

    @Override public void remove(@Nonnull final BiCNetPluginEmNeChangeListener listener) {
        listeners.remove(listener);
    }
}
