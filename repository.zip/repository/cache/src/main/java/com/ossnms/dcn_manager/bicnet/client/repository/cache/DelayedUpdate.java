package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 * Invalidates cache only once per specified time <br/>
 * The goal is to invalidate cache only once for burst of events
 */
public class DelayedUpdate implements ActionListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(DelayedUpdate.class);
    private final Timer timer;
    private final CacheManager<?, ?> cacheManager;

    public DelayedUpdate(CacheManager<?, ?> cacheManager, int delay) {
        this.cacheManager = cacheManager;
        timer = new Timer(delay, this);
        timer.setCoalesce(true);
    }

    /**
     * Requests cache update <br/>
     * If there is another request it is replaced
     */
    public void touchAll() {
        timer.restart();
    }


    /**
     * Invalidates cache when time expires
     */
    @Override public void actionPerformed(ActionEvent e) {
        try {
            cacheManager.cache().touchAll();
        } catch (CacheException ex) {
            LOGGER.error("Failed to touch all cache elements", ex);
        }
        timer.stop();
    }

}
