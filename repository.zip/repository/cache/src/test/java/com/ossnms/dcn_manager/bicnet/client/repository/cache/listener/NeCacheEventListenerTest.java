package com.ossnms.dcn_manager.bicnet.client.repository.cache.listener;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import net.sf.ehcache.Element;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

public class NeCacheEventListenerTest {

    private final ListenersRegistrationManager listenersManager;
    private final EventListenerTest eventListenerTest;
    private FullNeData ne;
    
    public NeCacheEventListenerTest() {
        eventListenerTest = new EventListenerTest();
        listenersManager = new CacheListenersRegistrationManager();       
    }

    @Before
    public void setup() {
        final INE neItem = new NEItem();
        neItem.setId(1);
        neItem.setIdName("NAME");
        ne = new FullNeData(neItem, new NeInfo(neItem.getId()),null);
        
        NeCacheManager.getInstance().cache().fetch(new ArrayList<Element>());
        listenersManager.addNeListener(eventListenerTest);
    }
    
    @After
    public void release() throws CacheException {
        eventListenerTest.removeAll();
        NeCacheManager.getInstance().cache().clear();
        listenersManager.removeNeListener(eventListenerTest);
    }

    @Test
    public void testElementAdded() throws CacheException {
        NeCacheManager.getInstance().cache().put(ne.getNe().getId(), ne);

        assertTrue(eventListenerTest.getElements().contains(ne.getNe().getNEId()));
        assertThat(eventListenerTest.getElements().size(), is(1));
    }

    @Test
    public void testElementRemoved() throws CacheException {
        NeCacheManager.getInstance().cache().put(ne.getNe().getId(), ne);
        NeCacheManager.getInstance().cache().remove(ne.getNe().getId());

        assertFalse(eventListenerTest.getElements().contains(ne.getNe().getNEId()));
        assertTrue(eventListenerTest.getElements().isEmpty());
    }
    
    @Test
    public void elementUpdated() throws CacheException {
        final INE neUpdated = new NEItem();
        neUpdated.setId(1);
        neUpdated.setIdName("NEW_NAME");
        
        final FullNeData mutation = new FullNeData(neUpdated, new NeInfo(neUpdated.getId()), null);

        NeCacheManager.getInstance().cache().put(ne.getNe().getId(), ne);
        NeCacheManager.getInstance().cache().update(ne.getNe().getId(), mutation);

        assertTrue(eventListenerTest.getElements().contains(ne.getNe().getNEId()));
        assertThat(eventListenerTest.getElements().size(), is(1));
    }
    
    @Test
    public void removeListener() throws CacheException {
        final INE neUpdated = new NEItem();
        neUpdated.setId(1);
        neUpdated.setIdName("NEW_NAME");

        listenersManager.removeNeListener(eventListenerTest);

        NeCacheManager.getInstance().cache().put(ne.getNe().getId(), ne);

        assertTrue(eventListenerTest.getElements().isEmpty());
    }
    
    @Test
    public void elementClear() throws CacheException {
        NeCacheManager.getInstance().cache().put(ne.getNe().getId(), ne);
        NeCacheManager.getInstance().cache().clear();

        assertTrue(eventListenerTest.getElements().isEmpty());
    }

    private static class EventListenerTest implements EventChangeListener<FullNeData> {

        private final Set<INEId> elements = new HashSet<>();

        public Set<INEId> getElements() {
            return elements;
        }

        @Override
        public void elementRemoved(FullNeData element) {
            elements.remove(element.getNe().getNEId());
        }

        @Override
        public void elementAdded(FullNeData element) {
            elements.add(element.getNe().getNEId());
        }

        @Override
        public void elementUpdated(FullNeData element) {
            elements.add(element.getNe().getNEId());
        }

        @Override
        public void removeAll() {
            elements.clear();
        }        
    }
}
