package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import net.sf.ehcache.Element;
import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MediatorCacheManagerTest {

    private static final int ID = 1;

    private final MediatorCacheManager cache;

    private FullMediatorDataCreateNotification objectCreation;
    private ObjectDeletion objectDeletion;
    private AttributeValueChange attributeValueChange;

    private IMediator mediator;
    private FullMediatorData fullMediatorData;
    private IMediatorId mediatorId;
    private IMediatorMarkable markable;

    public MediatorCacheManagerTest() {
        cache = MediatorCacheManager.getInstance();
    }

    @Before
    public void setup() {
        cache.cache().fetch(new ArrayList<Element>());

        objectDeletion = mock(ObjectDeletion.class);
        attributeValueChange = mock(AttributeValueChange.class);

        mediator = mock(IMediator.class);
        mediatorId = mock(IMediatorId.class);
        markable = mock(IMediatorMarkable.class);

        fullMediatorData = new FullMediatorData(mediator, new MediatorInfo(ID));
        objectCreation = new FullMediatorDataCreateNotification(fullMediatorData);

        when(mediator.getId()).thenReturn(ID);
        when(mediatorId.getId()).thenReturn(ID);
        when(markable.getId()).thenReturn(ID);
    }

    @After
    public void destroy() throws CacheException {
        cache.cache().clear();
    }

    @Test
    public void testCache() {
        assertNotNull(cache.cache());
    }

    @Test
    public void testOnObjectCreation() throws BcbException, CacheException {
        assertTrue(cache.onFullMediatorDataCreation(objectCreation));
        assertThat(cache.cache().find(ID).get().getMediator(), CoreMatchers.is(mediator));
    }
  
    @Test
    public void testOnObjectDeletion() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(mediatorId);

        assertTrue(cache.onObjectDeletion(objectDeletion));

        verify(objectDeletion, Mockito.times(2)).getDeletedObject();
        verify(mediatorId, Mockito.times(1)).getId();
    }

    @Test
    public void testOnAttributeValueChange() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(markable);

        cache.cache().put(ID, fullMediatorData);

        assertTrue(cache.onAttributeValueChange(attributeValueChange));

        verify(attributeValueChange, Mockito.times(2)).getChangedObject();
        verify(markable, Mockito.times(1)).getId();
        verify(mediator, Mockito.times(1)).update(markable);
        verify(mediator, Mockito.times(1)).getId();
    }

    @Test
    public void testOnObjectDeletion_wrong_object_type() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(new EMItem());

        assertFalse(cache.onObjectDeletion(objectDeletion));

        verify(objectDeletion, Mockito.times(1)).getDeletedObject();
        verify(mediatorId, Mockito.never()).getId();
    }

    @Test
    public void testOnAttributeValueChange_wrong_object_type() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(new EMItem().toMarkable());

        cache.cache().put(ID, fullMediatorData);

        assertFalse(cache.onAttributeValueChange(attributeValueChange));

        verify(attributeValueChange, Mockito.times(1)).getChangedObject();
        verify(markable, Mockito.never()).getId();
        verify(mediator, Mockito.never()).update(markable);
        verify(mediator, Mockito.never()).getId();
    }
    
    @Test(expected=BcbException.class)
    public void testOnObjectDeletion_error() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(mediatorId);

        doThrow(BcbException.class).when(mediatorId).getId();
        
        cache.onObjectDeletion(objectDeletion);
    }

    @Test(expected=BcbException.class)
    public void testOnAttributeValueChange_error() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(markable);

        doThrow(BcbException.class).when(markable).getId();
        
        cache.cache().put(ID, fullMediatorData);
        cache.onAttributeValueChange(attributeValueChange);
    }
}
