package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class NEContainerAssignmentCacheManagerTest {


    private NEContainerAssignmentCacheManager cache;

    @Before
    public void setUp() throws Exception {
        cache = NEContainerAssignmentCacheManager.getInstance();
        cache.cache().fetch(new ArrayList<>());
    }

    @After
    public void tearDown() throws Exception {
        cache.cache().clear();
    }

    @Test public void shouldStoreObjectInCache() throws Exception {
        INeGenericContainerAssignment assignment = assignment(1, 101);
        
        boolean created = cache.onObjectCreation(new ObjectCreation(new Date(), assignment));
        Optional<INeGenericContainerAssignment> stored = cache.cache().find(assignment.getNeGenericContainerAssignmentId());

        assertThat(created, is(true));
        assertThat(stored, is(of(assignment)));
    }

    @Test public void shouldRemoveObjectFromCache() throws Exception {
        INeGenericContainerAssignment assignment = assignment(2, 202);
        cache.cache().put(assignment.getNeGenericContainerAssignmentId(),assignment);

        boolean deleted = cache.onObjectDeletion(new ObjectDeletion(new Date(), assignment));
        Optional<INeGenericContainerAssignment> stored = cache.cache().find(assignment.getNeGenericContainerAssignmentId());

        assertThat(deleted, is(true));
        assertThat(stored, is(empty()));
    }
    
    @Test public void shouldUpdateCacheObject() throws Exception {
        INeGenericContainerAssignment assignment = assignment(1, 202);
        IManagedObjectMarkable changedObject = assignment.toMarkable();
        cache.cache().put(assignment.getNeGenericContainerAssignmentId(),assignment);

        boolean updated = cache.onAttributeValueChange(new AttributeValueChange(new Date(), changedObject));
        Optional<INeGenericContainerAssignment> stored = cache.cache().find(assignment.getNeGenericContainerAssignmentId());

        assertThat(updated, is(true));
        assertThat(stored, is(of(changedObject)));
    }

    private INeGenericContainerAssignment assignment(int containerId, int neId) {
        NeGenericContainerAssignmentItem assignment = new NeGenericContainerAssignmentItem();
        assignment.setGenericContainerId(containerId);
        assignment.setNetworkElementId(neId);
        return assignment;
    }
}