package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class NeCacheManagerTest {

    private static final int ID = 1;

    private final NeCacheManager cache;

    private FullNeDataCreateNotification objectCreation;
    private ObjectDeletion objectDeletion;
    private AttributeValueChange attributeValueChange;

    private FullNeData ne;
    private INE bcbNe;
    private INEId neId;
    private INEMarkable markable;

    public NeCacheManagerTest() {
        cache = NeCacheManager.getInstance();
    }

    @Before
    public void setup() throws CacheException {
        cache.cache().fetch(new ArrayList<>());
        NEContainerAssignmentCacheManager.getInstance().cache().fetch(new ArrayList<>());

        objectDeletion = mock(ObjectDeletion.class);
        attributeValueChange = mock(AttributeValueChange.class);

        bcbNe = mock(INE.class);
        neId = mock(INEId.class);
        markable = mock(INEMarkable.class);

        ne = new FullNeData(bcbNe, new NeInfo(ID), new ScsSynchronizationState(ID, ScsSyncState.OUT_OF_SYNC));
        objectCreation = new FullNeDataCreateNotification(ne);

        when(bcbNe.getId()).thenReturn(ID);
        when(neId.getId()).thenReturn(ID);
        when(markable.getId()).thenReturn(ID);
    }

    @After
    public void destroy() throws CacheException {
        cache.cache().clear();
    }

    @Test
    public void testCache() {
        assertNotNull(cache.cache());
    }

    @Test
    public void testOnObjectCreation() throws BcbException, CacheException {
        assertTrue(cache.onFullNeDataCreation(objectCreation));

        assertThat(cache.cache().find(ID).get().getNe(), CoreMatchers.is(bcbNe));
        assertThat(cache.cache().find(ID).get(), CoreMatchers.is(ne));
    }

    @Test
    public void testOnObjectDeletion() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(neId);

        assertTrue(cache.onObjectDeletion(objectDeletion));

        verify(objectDeletion, Mockito.times(2)).getDeletedObject();
        verify(neId, Mockito.atLeast(1)).getId();
    }

    @Test
    public void testOnAttributeValueChange() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(markable);

        cache.cache().put(ID, ne);

        assertTrue(cache.onAttributeValueChange(attributeValueChange));

        verify(attributeValueChange, Mockito.times(2)).getChangedObject();

        verify(markable, Mockito.times(1)).getId();

        verify(ne.getNe(), Mockito.times(1)).update(markable);
        verify(ne.getNe(), Mockito.atLeast(1)).getId();
    }

    @Test
    public void testOnObjectDeletion_wrong_object_type() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(new EMItem());

        assertFalse(cache.onObjectDeletion(objectDeletion));

        verify(objectDeletion, Mockito.times(1)).getDeletedObject();
        verify(neId, Mockito.never()).getId();
    }

    @Test
    public void testOnAttributeValueChange_wrong_object_type() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(new EMItem().toMarkable());

        cache.cache().put(ID, ne);

        assertFalse(cache.onAttributeValueChange(attributeValueChange));

        verify(attributeValueChange, Mockito.times(1)).getChangedObject();
        verify(markable, Mockito.never()).getId();
        verify(bcbNe, Mockito.never()).update(markable);
//        verify(bcbNe, Mockito.never()).getId();
    }

    @Test(expected=BcbException.class)
    public void testOnObjectDeletion_error() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(neId);

        doThrow(BcbException.class).when(neId).getId();
        
        cache.onObjectDeletion(objectDeletion);
    }

    @Test(expected=BcbException.class)
    public void testOnAttributeValueChange_error() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(markable);

        doThrow(BcbException.class).when(markable).getId();
        
        cache.cache().put(ID, ne);
        cache.onAttributeValueChange(attributeValueChange);
    }
}
