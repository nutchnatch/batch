package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.Loader;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.CacheEventListenerImpl;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.Searchable;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.PersistenceConfiguration;
import net.sf.ehcache.config.PersistenceConfiguration.Strategy;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class CacheWrapperTest {

    private static final String CACHE_NAME = "CacheWrapperTest";
    private static final int MAX_ELEMENTS = 20;
    private static final int AUTO_CREATE_TOTAL = 5;

    private CacheWrapper<Integer, String> cache;

    private EventChangeListener<String> listener;
    private CacheEventListenerImpl<String> event;
    private Searchable<String> searchable;

    public CacheWrapperTest() {
        final CacheConfiguration configuration = new CacheConfiguration(CACHE_NAME, MAX_ELEMENTS).persistence(
                new PersistenceConfiguration().strategy(Strategy.NONE)).eternal(true);

        final Cache cache = new Cache(configuration);

        CacheManager.getInstance().addCache(cache);
    }

    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        listener = mock(EventChangeListener.class);
        event = mock(CacheEventListenerImpl.class);
        searchable = mock(Searchable.class);

        loadCache();
    }

    private void loadCache() {
        cache = new CacheWrapperImpl<>(CacheManager.getInstance().getEhcache(CACHE_NAME), searchable, mock(Loader.class));

        final ImmutableList<Pair<Integer, String>> items = createList(AUTO_CREATE_TOTAL);

        cache.fetch(items.stream().map(input -> new Element(input.getLeft(), input.getRight())).collect(Collectors.toList()));
    }

    @After
    public void release() throws CacheException {
        cache.clear();
        CacheManager.getInstance().removeCache(CACHE_NAME);
        cache = null;
    }

    @Test
    public void testFind() throws CacheException {
        assertTrue(cache.find(1).isPresent());
    }

    @Test
    public void testFind_notExists() throws CacheException {
        assertFalse(cache.find(30).isPresent());
    }

    @Test
    public void testFindAllKeys() throws CacheException {
        final Collection<String> keys = cache.findAllKeys(ImmutableList.of(1, 2, 3));

        for (int i = 0; i < keys.size(); i++) {
            assertTrue(keys.contains("value" + 1));
        }
    }

    @Test
    public void testPut() throws CacheException {
        cache.put(20, "value20");

        final Optional<String> value = cache.find(20);

        assertTrue(value.isPresent());
        assertThat(value.get(), CoreMatchers.is("value20"));
    }

    @Test
    public void testUpdate() throws CacheException {
        cache.update(1, "valueUpdated");

        final Optional<String> value = cache.find(1);

        assertTrue(value.isPresent());
        assertThat(value.get(), CoreMatchers.is("valueUpdated"));
    }

    @Test
    public void testRemove() throws CacheException {
        cache.remove(1);

        final Optional<String> value = cache.find(1);

        assertFalse(value.isPresent());
    }

    @Test
    public void testAll() throws CacheException {
        final Collection<String> allElements = cache.all();

        assertNotNull(allElements);
        assertThat(allElements.size(), CoreMatchers.is(AUTO_CREATE_TOTAL));

        for (int i = 0; i < allElements.size(); i++) {
            assertTrue(allElements.contains("value" + 1));
        }
    }

    @Test
    public void testAddListener() {
        cache.getEhcache().getCacheEventNotificationService().registerListener(event);
        cache.addChangeListener(listener);

        verify(event, Mockito.times(1)).addListener(listener);
    }

    @Test
    public void testRemoveListener() {
        cache.getEhcache().getCacheEventNotificationService().registerListener(event);
        cache.addChangeListener(listener);

        cache.removeChangeListener(listener);

        verify(event, Mockito.times(1)).removeListener(listener);
    }

    @Test
    public void testRemoveListener_null() {
        cache.removeChangeListener(null);

        verify(event, Mockito.never()).removeListener(listener);
    }

    @Test(expected = CacheException.class)
    public void testFetchError() throws CacheException {
        cache.fetchError();
        cache.put(20, "value20");
    }


    @Test(expected = CacheException.class)
    public void testClear() throws CacheException {
        cache.clear();
        cache.put(20, "value20");
    }

    @Test
    public void testGetEhcache() {
        assertNotNull(cache.getEhcache());
    }

    private ImmutableList<Pair<Integer, String>> createList(final int total) {

        final Builder<Pair<Integer, String>> builder = ImmutableList.builder();

        for (int i = 1; i <= total; i++) {
            builder.add(ImmutablePair.of(i, "value" + 1));
        }

        return builder.build();
    }
}
