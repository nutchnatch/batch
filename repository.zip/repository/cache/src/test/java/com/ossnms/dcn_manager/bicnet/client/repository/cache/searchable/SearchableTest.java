package com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable;

import com.google.common.collect.FluentIterable;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ChannelCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.MediatorCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NEContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.NeCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.SystemContainerAssignmentCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import net.sf.ehcache.Element;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class SearchableTest {

    private static final int MAX_MEDIATOR_OBJECTS = 3;
    private static final int MAX_EM_OBJECTS_BY_MEDIATOR = 5;
    private static final int MAX_NE_OBJECTS_BY_EM = 10;

    public SearchableTest() {
        setupMediatorCache();
        setupEmCache();
        setupNeCache();
    }

    @Test
    public void testFindNEsByEm() throws CacheException {
        for (int id = 1; id <= MAX_EM_OBJECTS_BY_MEDIATOR; id++) {
            final Collection<FullNeData> nes = ((NeSearchable) NeCacheManager.getInstance().cache().queries()).findByParentId(id);

            assertThat(nes.size(), is(MAX_NE_OBJECTS_BY_EM));
        }
    }

    @Test
    public void testFindEMsByMediator() throws CacheException {
        for (int id = 1; id <= MAX_MEDIATOR_OBJECTS; id++) {
            final Collection<FullChannelData> channels = ((ChannelSearchable)ChannelCacheManager.getInstance().cache().queries()).findByParentId(id);

            assertThat(channels.size(), is(MAX_EM_OBJECTS_BY_MEDIATOR));
        }
    }

    @Test public void shouldFindNeAssociationByContainer() throws Exception {
        int containerId = 51;
        INeGenericContainerAssignment[] assignments = {assignmentNe(containerId, 1), assignmentNe(containerId, 2),};

        Collection<INeGenericContainerAssignment> byContainer = neAssignmentQueries(assignments).findByContainerId(containerId);

        assertThat(byContainer, containsInAnyOrder(assignments));
    }

    @Test public void shouldFilterOutNeAssociationNotMatchingContainer() throws Exception {
        int containerId = 71;
        INeGenericContainerAssignment[] assignments = {assignmentNe(containerId, 1), assignmentNe(containerId, 2),};

        int anotherContainer = containerId + 42;
        Collection<INeGenericContainerAssignment> byAnotherContainer = neAssignmentQueries(assignments).findByContainerId(anotherContainer);

        assertThat(byAnotherContainer, is(empty()));
    }

    @Test public void shouldFindNeAssociationByNE() throws Exception {
        int neId = 67;
        INeGenericContainerAssignment[] assignments = {assignmentNe(1, neId), assignmentNe(2, neId),};

        Collection<INeGenericContainerAssignment> byNE = neAssignmentQueries(assignments).findByNetworkElementId(neId);

        assertThat(byNE, containsInAnyOrder(assignments));
    }

    @Test public void shouldFilterOutNeAssociationNotMatchingNE() throws Exception {
        int neId = 17;
        INeGenericContainerAssignment[] assignments = {assignmentNe(1, neId), assignmentNe(2, neId),};

        int anotherNE = neId + 42;
        Collection<INeGenericContainerAssignment> byAnotherNE = neAssignmentQueries(assignments).findByNetworkElementId(anotherNE);

        assertThat(byAnotherNE, is(empty()));
    }

    @Test public void shouldFindSystemAssociationByContainer() throws Exception {
        int containerId = 15;
        ISystemGenericContainerAssignment[] assignments = {assignmentSystem(containerId, 1), assignmentSystem(containerId, 2),};

        Collection<ISystemGenericContainerAssignment> byContainer = systemAssignmentQueries(assignments).findByContainerId(containerId);

        assertThat(byContainer, containsInAnyOrder(assignments));
    }

    @Test public void shouldFilterOutSystemAssociationNotMatchingContainer() throws Exception {
        int containerId = 13;
        ISystemGenericContainerAssignment[] assignments = {assignmentSystem(containerId, 1), assignmentSystem(containerId, 2),};

        int anotherContainer = containerId + 42;
        Collection<ISystemGenericContainerAssignment> byAnotherContainer = systemAssignmentQueries(assignments).findByContainerId(anotherContainer);

        assertThat(byAnotherContainer, is(empty()));
    }

    @Test public void shouldFindSystemAssociationBySystem() throws Exception {
        int systemId = 41;
        ISystemGenericContainerAssignment[] assignments = {assignmentSystem(1, systemId), assignmentSystem(2, systemId),};

        Collection<ISystemGenericContainerAssignment> bySystem = systemAssignmentQueries(assignments).findBySystemContainerId(systemId);

        assertThat(bySystem, containsInAnyOrder(assignments));
    }

    @Test public void shouldFilterOutSystemAssociationByNotMatchingSystem() throws Exception {
        int systemId = 32;
        ISystemGenericContainerAssignment[] assignments = {assignmentSystem(1, systemId), assignmentSystem(2, systemId),};

        int anotherSystem = systemId + 17;
        Collection<ISystemGenericContainerAssignment> byAnotherSystem = systemAssignmentQueries(assignments).findBySystemContainerId(anotherSystem);

        assertThat(byAnotherSystem, is(empty()));
    }

    private NeContainerAssignmentSearchable neAssignmentQueries(INeGenericContainerAssignment[] assignments) throws CacheException {
        NEContainerAssignmentCacheManager manager = NEContainerAssignmentCacheManager.getInstance();
        List<Element> elements = Stream.of(assignments).map(assignment -> new Element(assignment.getNeGenericContainerAssignmentId(), assignment)).collect(toList());
        manager.cache().fetch(elements);
        return (NeContainerAssignmentSearchable) manager.cache().queries();
    }

    private SystemAssignmentSearchable systemAssignmentQueries(ISystemGenericContainerAssignment[] assignments) throws CacheException {
        SystemContainerAssignmentCacheManager manager = SystemContainerAssignmentCacheManager.getInstance();
        List<Element> elements = Stream.of(assignments).map(assignment -> new Element(assignment.getSystemGenericContainerAssignmentId(), assignment)).collect(toList());
        manager.cache().fetch(elements);
        return (SystemAssignmentSearchable) manager.cache().queries();
    }

    private INeGenericContainerAssignment assignmentNe(int containerId, int networkElementId) {
        INeGenericContainerAssignment assignment = new NeGenericContainerAssignmentItem();
        assignment.setGenericContainerId(containerId);
        assignment.setNetworkElementId(networkElementId);
        return assignment;
    }

    private ISystemGenericContainerAssignment assignmentSystem(int containerId, int systemId) {
        ISystemGenericContainerAssignment assignment = new SystemGenericContainerAssignmentItem();
        assignment.setGenericContainerId(containerId);
        assignment.setSystemContainerId(systemId);
        return assignment;
    }

    private void setupMediatorCache() {

        final List<IMediator> mediators = new ArrayList<>();

        for (int i = 1; i <= MAX_MEDIATOR_OBJECTS; i++) {
            final IMediator em = new MediatorItem();
            em.setId(i);
            mediators.add(em);
        }

        MediatorCacheManager.getInstance().cache().fetch(FluentIterable.from(mediators)
                .transform(input -> new Element(input.getId(), input)).toList());
    }

    private void setupEmCache() {
        final List<FullChannelData> channels = new ArrayList<>();

        int emId = 1;

        for (int mediatorId = 1; mediatorId <= MAX_MEDIATOR_OBJECTS; mediatorId++) {
            for (int i = 0; i < MAX_EM_OBJECTS_BY_MEDIATOR; i++) {
                final IEM em = new EMItem();
                em.setId(emId);
                em.setAssociatedMediator(new MediatorIdItem(mediatorId));
                FullChannelData fullChannelData = new FullChannelData(em, new ChannelInfo(em.getId()));
                channels.add(fullChannelData);

                emId++;
            }
        }

        ChannelCacheManager.getInstance().cache().fetch(FluentIterable.from(channels)
                .transform(input -> new Element(input.getChannel().getId(), input)).toList());
    }

    private void setupNeCache() {

        final List<FullNeData> nes = new ArrayList<>();

        int neId = 1;

        for (int emId = 1; emId <= MAX_EM_OBJECTS_BY_MEDIATOR; emId++) {
            for (int i = 0; i < MAX_NE_OBJECTS_BY_EM; i++) {
                final INE ne = new NEItem();
                ne.setId(neId);
                ne.setAssociatedEm(new EMIdItem(emId));

                nes.add(new FullNeData(ne, new NeInfo(ne.getId()), null));

                neId++;
            }
        }

        NeCacheManager.getInstance().cache().fetch(FluentIterable.from(nes)
                .transform(input -> new Element(input.getNe().getId(), input)).toList());
    }
}
