package com.ossnms.dcn_manager.bicnet.client.repository.cache.listener;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.MediatorCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import net.sf.ehcache.Element;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class MediatorCacheEventListenerTest {

    private final ListenersRegistrationManager listenersManager;
    private final EventListenerTest eventListenerTest;
    private FullMediatorData fullMediator;
    
    public MediatorCacheEventListenerTest() {
        eventListenerTest = new EventListenerTest();
        listenersManager = new CacheListenersRegistrationManager();        
    }

    @Before
    public void setup() {

        IMediator mediator = new MediatorItem();
        mediator.setId(1);        
        mediator.setIdName("name");
        MediatorInfo mediatorInfo = new MediatorInfo(mediator.getId());
        fullMediator = new FullMediatorData(mediator, mediatorInfo);
        
        MediatorCacheManager.getInstance().cache().fetch(new ArrayList<Element>());
        listenersManager.addMediatorListener(eventListenerTest);
    }
    
    @After
    public void release() throws CacheException {
        eventListenerTest.removeAll();
        MediatorCacheManager.getInstance().cache().clear();
        listenersManager.removeMediatorListener(eventListenerTest);
    }

    @Test
    public void testElementAdded() throws CacheException {
        MediatorCacheManager.getInstance().cache().put(fullMediator.getMediator().getId(), fullMediator);

        assertTrue(eventListenerTest.getElements().contains(fullMediator.getMediator().getMediatorId()));
        assertThat(eventListenerTest.getElements().size(), is(1));
    }

    @Test
    public void testElementRemoved() throws CacheException {
        MediatorCacheManager.getInstance().cache().put(fullMediator.getMediator().getId(), fullMediator);
        MediatorCacheManager.getInstance().cache().remove(fullMediator.getMediator().getId());

        assertFalse(eventListenerTest.getElements().contains(fullMediator.getMediator().getMediatorId()));
        assertTrue(eventListenerTest.getElements().isEmpty());
    }
    
    @Test
    public void elementUpdated() throws CacheException {

        final IMediator emUpdated = new MediatorItem();
        emUpdated.setId(1);
        emUpdated.setIdName("NEW_NAME");

        FullMediatorData fullMediatorDataUpdated = new FullMediatorData(emUpdated, new MediatorInfo(emUpdated.getId()));

        MediatorCacheManager.getInstance().cache().put(fullMediator.getMediator().getId(), fullMediator);
        MediatorCacheManager.getInstance().cache().update(fullMediator.getMediator().getId(), fullMediatorDataUpdated);

        assertTrue(eventListenerTest.getElements().contains(fullMediator.getMediator().getMediatorId()));
        assertThat(eventListenerTest.getElements().size(), is(1));
    }
    
    @Test
    public void removeListener() throws CacheException {
        final INE neUpdated = new NEItem();
        neUpdated.setId(1);
        neUpdated.setIdName("NEW_NAME");

        listenersManager.removeMediatorListener(eventListenerTest);

        MediatorCacheManager.getInstance().cache().put(fullMediator.getMediator().getId(), fullMediator);
        
        assertTrue(eventListenerTest.getElements().isEmpty());
    }
    
    @Test
    public void elementClear() throws CacheException {
        MediatorCacheManager.getInstance().cache().put(fullMediator.getMediator().getId(), fullMediator);
        MediatorCacheManager.getInstance().cache().clear();

        assertTrue(eventListenerTest.getElements().isEmpty());
    }

    private static class EventListenerTest implements EventChangeListener<FullMediatorData> {

        private final Set<IMediatorId> elements = new HashSet<>();

        public Set<IMediatorId> getElements() {
            return elements;
        }

        @Override
        public void elementRemoved(FullMediatorData element) {
            elements.remove(element.getMediator().getMediatorId());
        }

        @Override
        public void elementAdded(FullMediatorData element) {
            elements.add(element.getMediator().getMediatorId());
        }

        @Override
        public void elementUpdated(FullMediatorData element) {
            elements.add(element.getMediator().getMediatorId());
        }

        @Override
        public void removeAll() {
            elements.clear();
        }        
    }
}
