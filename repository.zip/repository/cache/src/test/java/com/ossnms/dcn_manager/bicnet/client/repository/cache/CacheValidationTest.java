package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import java.util.stream.Collectors;

import org.junit.After;
import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;

import net.sf.ehcache.Element;

public class CacheValidationTest {

    private final CacheWrapper<Integer, FullChannelData> emCache;

    public CacheValidationTest() {
        emCache = CacheInMemoryFactory.getChannelCache();
    }

    @After
    public void release() throws CacheException {
        CacheInMemoryFactory.getChannelCache().clear();
    }

    @Test
    public void testValidateCache() throws CacheException {
        emCache.fetchStart();
        final ImmutableList<IEM> ems = createList(10);
        final Builder<FullChannelData> cacheElements = ImmutableList.builder();

        emCache.fetch(ems.stream().map(input -> new Element(input.getId(), input)).collect(Collectors.toList()));

        for (final IEM iem : ems) {
            cacheElements.add(emCache.find(iem.getId()).get());
        }

        Assert.assertNotNull(emCache.find(1).orElse(null));
        Assert.assertTrue(ems.containsAll(cacheElements.build()));
    }

    private ImmutableList<IEM> createList(int total) {

        final Builder<IEM> builder = ImmutableList.builder();

        for (int i = 1; i <= total; i++) {
            final IEM em = new EMItem();
            em.setId(i);
            builder.add(em);
        }

        return builder.build();
    }
}
