package com.ossnms.dcn_manager.bicnet.client.repository.cache.listener;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import net.sf.ehcache.Element;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IASId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.DomainCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;

public class DomainCacheEventListenerTest {

    private final ListenersRegistrationManager listenersManager;
    private final EventListenerTest eventListenerTest;
    private IAS domain;
    
    public DomainCacheEventListenerTest() {
        eventListenerTest = new EventListenerTest();
        listenersManager = new CacheListenersRegistrationManager();        
    }

    @Before
    public void setup() {
        domain = new ASItem();
        domain.setId(1);        
        domain.setIdName("name");
        
        DomainCacheManager.getInstance().cache().fetch(new ArrayList<Element>());
        listenersManager.addDomainListener(eventListenerTest);
    }
    
    @After
    public void release() throws CacheException {
        eventListenerTest.removeAll();
        DomainCacheManager.getInstance().cache().clear();
        listenersManager.removeDomainListener(eventListenerTest);
    }

    @Test
    public void testElementAdded() throws CacheException {
        DomainCacheManager.getInstance().cache().put(domain.getId(), domain);

        assertTrue(eventListenerTest.getElements().contains(domain.getASId()));
        assertThat(eventListenerTest.getElements().size(), is(1));
    }

    @Test
    public void testElementRemoved() throws CacheException {
        DomainCacheManager.getInstance().cache().put(domain.getId(), domain);
        DomainCacheManager.getInstance().cache().remove(domain.getId());

        assertFalse(eventListenerTest.getElements().contains(domain.getASId()));
        assertTrue(eventListenerTest.getElements().isEmpty());
    }
    
    @Test
    public void elementUpdated() throws CacheException {
        final IAS emUpdated = new ASItem();
        emUpdated.setId(1);
        emUpdated.setIdName("NEW_NAME");
        
        DomainCacheManager.getInstance().cache().put(domain.getId(), domain);
        DomainCacheManager.getInstance().cache().update(domain.getId(), emUpdated);

        assertTrue(eventListenerTest.getElements().contains(domain.getASId()));
        assertThat(eventListenerTest.getElements().size(), is(1));
    }
    
    @Test
    public void removeListener() throws CacheException {
        final INE neUpdated = new NEItem();
        neUpdated.setId(1);
        neUpdated.setIdName("NEW_NAME");

        listenersManager.removeDomainListener(eventListenerTest);

        DomainCacheManager.getInstance().cache().put(domain.getId(), domain);
        
        assertTrue(eventListenerTest.getElements().isEmpty());
    }
    
    @Test
    public void elementClear() throws CacheException {
        DomainCacheManager.getInstance().cache().put(domain.getId(), domain);
        DomainCacheManager.getInstance().cache().clear();

        assertTrue(eventListenerTest.getElements().isEmpty());
    }

    private static class EventListenerTest implements EventChangeListener<IAS> {

        private final Set<IASId> elements = new HashSet<>();

        public Set<IASId> getElements() {
            return elements;
        }

        @Override
        public void elementRemoved(IAS element) {
            elements.remove(element.getASId());
        }

        @Override
        public void elementAdded(IAS element) {
            elements.add(element.getASId());
        }

        @Override
        public void elementUpdated(IAS element) {
            elements.add(element.getASId());
        }

        @Override
        public void removeAll() {
            elements.clear();
        }        
    }
}
