package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import javax.swing.SwingUtilities;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;

public class CacheLogonListenerTest {

    private ActivationAwareCacheWrapper<Integer, Integer> cache;
    private Runnable job;

    private CacheLogonListener<Integer, Integer> listener;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        cache = mock(ActivationAwareCacheWrapper.class);
        job = mock(Runnable.class);

        listener = new CacheLogonListener<>(cache);
    }

    @Test
    public void testOnUserLoggedOff() throws CacheException {
        listener.onUserLoggedOff(null);

        verify(cache, Mockito.only()).deactivate();
    }


    @Test
    public void testOnUserLoggedOn() {
        listener.onUserLoggedOn(null);

        SwingUtilities.invokeLater(() -> verify(job, Mockito.only()).run());
    }
    
    @Test
    public void testOnUserLoggingOff() throws CacheException {
        listener.onUserLoggingOff(null);
        
        verify(cache, Mockito.never()).deactivate();
        verify(job, Mockito.never()).run();
    }
 
    @Test
    public void testOnUserPermissionsChanged() throws CacheException {
        listener.onUserPermissionsChanged(null);
        
        verify(cache, Mockito.never()).deactivate();
        verify(job, Mockito.never()).run();
    }
}
