package com.ossnms.dcn_manager.bicnet.client.repository.cache.listener;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ChannelCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import net.sf.ehcache.Element;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

public class ChannelCacheEventListenerTest {

    private final ListenersRegistrationManager listenersManager;
    private final EventListenerTest eventListenerTest;
    private FullChannelData channel;
    
    public ChannelCacheEventListenerTest() {
        eventListenerTest = new EventListenerTest();
        listenersManager = new CacheListenersRegistrationManager();        
    }

    @Before
    public void setup() {
        EMItem em = new EMItem();
        em.setId(1);
        em.setIdName("name");
        channel = new FullChannelData(em, new ChannelInfo(em.getId()));

        ChannelCacheManager.getInstance().cache().fetch(new ArrayList<Element>());
        listenersManager.addChannelListener(eventListenerTest);
    }
    
    @After
    public void release() throws CacheException {
        eventListenerTest.removeAll();
        ChannelCacheManager.getInstance().cache().clear();
        listenersManager.removeChannelListener(eventListenerTest);
    }

    @Test
    public void testElementAdded() throws CacheException {
        ChannelCacheManager.getInstance().cache().put(channel.getChannel().getId(), channel);

        assertTrue(eventListenerTest.getElements().contains(channel.getChannel().getEMId()));
        assertThat(eventListenerTest.getElements().size(), is(1));
    }

    @Test
    public void testElementRemoved() throws CacheException {
        ChannelCacheManager.getInstance().cache().put(channel.getChannel().getId(), channel);
        ChannelCacheManager.getInstance().cache().remove(channel.getChannel().getId());

        assertFalse(eventListenerTest.getElements().contains(channel.getChannel().getEMId()));
        assertTrue(eventListenerTest.getElements().isEmpty());
    }
    
    @Test
    public void elementUpdated() throws CacheException {
        final IEM emUpdated = new EMItem();
        emUpdated.setId(1);
        emUpdated.setIdName("NEW_NAME");

        FullChannelData channelUpdated = new FullChannelData(emUpdated, new ChannelInfo(emUpdated.getId()));

        ChannelCacheManager.getInstance().cache().put(channel.getChannel().getId(), channel);
        ChannelCacheManager.getInstance().cache().update(channel.getChannel().getId(), channelUpdated);

        assertTrue(eventListenerTest.getElements().contains(channel.getChannel().getEMId()));
        assertThat(eventListenerTest.getElements().size(), is(1));
    }
    
    @Test
    public void removeListener() throws CacheException {
        final INE neUpdated = new NEItem();
        neUpdated.setId(1);
        neUpdated.setIdName("NEW_NAME");

        listenersManager.removeChannelListener(eventListenerTest);

        ChannelCacheManager.getInstance().cache().put(channel.getChannel().getId(), channel);
        
        assertTrue(eventListenerTest.getElements().isEmpty());
    }
    
    @Test
    public void elementClear() throws CacheException {
        ChannelCacheManager.getInstance().cache().put(channel.getChannel().getId(), channel);
        ChannelCacheManager.getInstance().cache().clear();

        assertTrue(eventListenerTest.getElements().isEmpty());
    }

    private static class EventListenerTest implements EventChangeListener<FullChannelData> {

        private final Set<IEMId> elements = new HashSet<>();

        public Set<IEMId> getElements() {
            return elements;
        }

        @Override
        public void elementRemoved(FullChannelData element) {
            elements.remove(element.getChannel().getEMId());
        }

        @Override
        public void elementAdded(FullChannelData element) {
            elements.add(element.getChannel().getEMId());
        }

        @Override
        public void elementUpdated(FullChannelData element) {
            elements.add(element.getChannel().getEMId());
        }

        @Override
        public void removeAll() {
            elements.clear();
        }        
    }
}
