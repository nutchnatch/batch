package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelDataCreateNotification;
import net.sf.ehcache.Element;
import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ChannelCacheManagerTest {

    private static final int ID = 1;

    private final ChannelCacheManager cache;
    
    private FullChannelDataCreateNotification objectCreation;
    private ObjectDeletion objectDeletion;
    private AttributeValueChange attributeValueChange;
    
    private IEM channel;
    private FullChannelData fullChannelData;
    private IEMId channelId;
    private IEMMarkable markable;

    public ChannelCacheManagerTest() {
        cache = ChannelCacheManager.getInstance();
    }

    @Before
    public void setup() {
        cache.cache().fetch(new ArrayList<Element>());
        
        objectDeletion = mock(ObjectDeletion.class);
        attributeValueChange = mock(AttributeValueChange.class);

        channel = mock(IEM.class);
        channelId = mock(IEMId.class);
        markable = mock(IEMMarkable.class);

        fullChannelData = new FullChannelData(channel, new ChannelInfo(ID));
        objectCreation = new FullChannelDataCreateNotification(fullChannelData);

        when(channel.getId()).thenReturn(ID);
        when(channelId.getId()).thenReturn(ID);
        when(markable.getId()).thenReturn(ID);
    }

    @After
    public void destroy() throws CacheException {
        cache.cache().clear();
    }
    
    @Test
    public void testOnObjectCreation() throws BcbException, CacheException {
        assertTrue(cache.onFullChannelDataCreation(objectCreation));
        assertThat(cache.cache().find(ID).get().getChannel(), CoreMatchers.is(channel));
    }
    
    @Test
    public void testOnObjectDeletion() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(channelId);
        
        assertTrue(cache.onObjectDeletion(objectDeletion));
        
        verify(objectDeletion, Mockito.times(2)).getDeletedObject();
        verify(channelId, Mockito.times(1)).getId();
    }
    
    @Test
    public void testOnAttributeValueChange() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(markable);
        
        cache.cache().put(ID, fullChannelData);
        
        assertTrue(cache.onAttributeValueChange(attributeValueChange));
        
        verify(attributeValueChange, Mockito.times(2)).getChangedObject();
        
        verify(markable, Mockito.times(1)).getId();
        
        verify(channel, Mockito.times(1)).update(markable);
        verify(channel, Mockito.times(1)).getId();
    }

    @Test
    public void testOnObjectDeletion_wrong_object_type() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(new MediatorItem());

        assertFalse(cache.onObjectDeletion(objectDeletion));

        verify(objectDeletion, Mockito.times(1)).getDeletedObject();
        verify(channelId, Mockito.never()).getId();
    }

    @Test
    public void testOnAttributeValueChange_wrong_object_type() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(new MediatorItem().toMarkable());

        cache.cache().put(ID, fullChannelData);

        assertFalse(cache.onAttributeValueChange(attributeValueChange));

        verify(attributeValueChange, Mockito.times(1)).getChangedObject();
        verify(markable, Mockito.never()).getId();
        verify(channel, Mockito.never()).update(markable);
        verify(channel, Mockito.never()).getId();
    }
    
    @Test(expected=BcbException.class)
    public void testOnObjectDeletion_error() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(channelId);

        doThrow(BcbException.class).when(channelId).getId();
        
        cache.onObjectDeletion(objectDeletion);
    }

    @Test(expected=BcbException.class)
    public void testOnAttributeValueChange_error() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(markable);

        doThrow(BcbException.class).when(markable).getId();
        
        cache.cache().put(ID, fullChannelData);
        cache.onAttributeValueChange(attributeValueChange);
    }
}
