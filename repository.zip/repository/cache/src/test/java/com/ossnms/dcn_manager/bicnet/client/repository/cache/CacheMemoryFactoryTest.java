package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class CacheMemoryFactoryTest {

    @Test
    public void testGetNeCache() {
        assertNotNull(CacheInMemoryFactory.getNeCache());
    }

    @Test
    public void testGetEmCache() {
        assertNotNull(CacheInMemoryFactory.getChannelCache());
    }

    @Test
    public void testGetMediatorCache() {
        assertNotNull(CacheInMemoryFactory.getMediatorCache());
    }

    @Test
    public void testGetDomainCache() {
        assertNotNull(CacheInMemoryFactory.getDomainCache());
    }

    @Test
    public void testGetContainerCache() {
        assertNotNull(CacheInMemoryFactory.getContainerCache());
    }
}
