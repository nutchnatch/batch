package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class SystemContainerAssignmentCacheManagerTest {


    private SystemContainerAssignmentCacheManager cache;

    @Before
    public void setUp() throws Exception {
        cache = SystemContainerAssignmentCacheManager.getInstance();
        cache.cache().fetch(new ArrayList<>());
    }

    @After
    public void tearDown() throws Exception {
        cache.cache().clear();
    }

    @Test public void shouldStoreObjectInCache() throws Exception {
        ISystemGenericContainerAssignment assignment = assignment(1, 101);
        
        boolean created = cache.onObjectCreation(new ObjectCreation(new Date(), assignment));
        Optional<ISystemGenericContainerAssignment> stored = cache.cache().find(assignment.getSystemGenericContainerAssignmentId());

        assertThat(created, is(true));
        assertThat(stored, is(of(assignment)));
    }

    @Test public void shouldRemoveObjectFromCache() throws Exception {
        ISystemGenericContainerAssignment assignment = assignment(2, 202);
        cache.cache().put(assignment.getSystemGenericContainerAssignmentId(),assignment);

        boolean deleted = cache.onObjectDeletion(new ObjectDeletion(new Date(), assignment));
        Optional<ISystemGenericContainerAssignment> stored = cache.cache().find(assignment.getSystemGenericContainerAssignmentId());

        assertThat(deleted, is(true));
        assertThat(stored, is(empty()));
    }
    
    @Test public void shouldUpdateCacheObject() throws Exception {
        ISystemGenericContainerAssignment assignment = assignment(1, 202);
        IManagedObjectMarkable changedObject = assignment.toMarkable();
        cache.cache().put(assignment.getSystemGenericContainerAssignmentId(),assignment);

        boolean updated = cache.onAttributeValueChange(new AttributeValueChange(new Date(), changedObject));
        Optional<ISystemGenericContainerAssignment> stored = cache.cache().find(assignment.getSystemGenericContainerAssignmentId());

        assertThat(updated, is(true));
        assertThat(stored, is(of(changedObject)));
    }

    private ISystemGenericContainerAssignment assignment(int containerId, int systemId) {
        SystemGenericContainerAssignmentItem assignment = new SystemGenericContainerAssignmentItem();
        assignment.setGenericContainerId(containerId);
        assignment.setSystemContainerId(systemId);
        return assignment;
    }
}