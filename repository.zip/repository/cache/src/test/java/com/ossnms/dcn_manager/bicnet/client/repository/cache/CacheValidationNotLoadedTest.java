package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheNotInitializedException;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

public class CacheValidationNotLoadedTest {

    private final CacheWrapper<Integer, FullChannelData> cache;

    public CacheValidationNotLoadedTest() {
        cache = CacheInMemoryFactory.getChannelCache();
    }

    @Before public void setUp() throws Exception {
        cache.clear();
    }

    @After public void tearDown() throws Exception {
        cache.clear();
    }

    @Test(expected = CacheNotInitializedException.class)
    public void testFind() throws CacheException {
        cache.find(1);
    }

    @Test(expected = CacheNotInitializedException.class)
    public void testFindAllKeys() throws CacheException {
        cache.findAllKeys(new ArrayList<>());
    }

    @Test(expected = CacheNotInitializedException.class)
    public void testPut() throws CacheException {
        EMItem em = new EMItem();
        cache.put(1, new FullChannelData(em, new ChannelInfo(em.getId())));
    }

    @Test(expected = CacheNotInitializedException.class)
    public void testUpdate() throws CacheException {
        EMItem em = new EMItem();
        cache.update(1, new FullChannelData(em, new ChannelInfo(em.getId())));
    }

    @Test(expected = CacheNotInitializedException.class)
    public void testRemove() throws CacheException {
        cache.remove(1);
    }

    @Test(expected = CacheNotInitializedException.class)
    public void testAll() throws CacheException {
        cache.all();
    }
}
