package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import net.sf.ehcache.Element;

import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ContainerCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;

public class ContainerCacheManagerTest {

    private static final int ID = 1;

    private final ContainerCacheManager cache;

    private ObjectCreation objectCreation;
    private ObjectDeletion objectDeletion;
    private AttributeValueChange attributeValueChange;

    private IGenericContainer container;
    private IGenericContainerId containerId;
    private IGenericContainerMarkable markable;

    public ContainerCacheManagerTest() {
        cache = ContainerCacheManager.getInstance();
    }

    @Before
    public void setup() {
        cache.cache().fetch(new ArrayList<Element>());

        objectCreation = mock(ObjectCreation.class);
        objectDeletion = mock(ObjectDeletion.class);
        attributeValueChange = mock(AttributeValueChange.class);

        container = mock(IGenericContainer.class);
        containerId = mock(IGenericContainerId.class);
        markable = mock(IGenericContainerMarkable.class);

        when(container.getId()).thenReturn(ID);
        when(containerId.getId()).thenReturn(ID);
        when(markable.getId()).thenReturn(ID);
    }

    @After
    public void destroy() throws CacheException {
        cache.cache().clear();
    }

    @Test
    public void testCache() {
        assertNotNull(cache.cache());
    }

    @Test
    public void testOnObjectCreation() throws BcbException, CacheException {
        when(objectCreation.getCreatedObject()).thenReturn(container);

        assertTrue(cache.onObjectCreation(objectCreation));
        assertThat(cache.cache().find(ID).get(), CoreMatchers.is(container));

        verify(objectCreation, Mockito.times(2)).getCreatedObject();
        verify(container, Mockito.times(1)).getId();
    }

    @Test
    public void testOnObjectDeletion() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(containerId);

        assertTrue(cache.onObjectDeletion(objectDeletion));

        verify(objectDeletion, Mockito.times(2)).getDeletedObject();
        verify(containerId, Mockito.times(1)).getId();
    }

    @Test
    public void testOnAttributeValueChange() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(markable);

        cache.cache().put(ID, container);

        assertTrue(cache.onAttributeValueChange(attributeValueChange));

        verify(attributeValueChange, Mockito.times(2)).getChangedObject();

        verify(markable, Mockito.times(1)).getId();

        verify(container, Mockito.times(1)).update(markable);
        verify(container, Mockito.times(1)).getId();
    }
    
    @Test
    public void testOnObjectCreation_wrong_object_type() throws BcbException, CacheException {
        when(objectCreation.getCreatedObject()).thenReturn(new EMItem());

        assertFalse(cache.onObjectCreation(objectCreation));

        verify(objectCreation, Mockito.times(1)).getCreatedObject();
        verify(container, Mockito.never()).getId();
    }
    
    @Test
    public void testOnObjectDeletion_wrong_object_type() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(new EMItem());

        assertFalse(cache.onObjectDeletion(objectDeletion));

        verify(objectDeletion, Mockito.times(1)).getDeletedObject();
        verify(containerId, Mockito.never()).getId();
    }

    @Test
    public void testOnAttributeValueChange_wrong_object_type() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(new EMItem().toMarkable());

        cache.cache().put(ID, container);

        assertFalse(cache.onAttributeValueChange(attributeValueChange));

        verify(attributeValueChange, Mockito.times(1)).getChangedObject();
        verify(markable, Mockito.never()).getId();
        verify(container, Mockito.never()).update(markable);
        verify(container, Mockito.never()).getId();
    }
    
    @Test(expected=BcbException.class)
    public void testOnObjectCreation_error() throws BcbException, CacheException {
        when(objectCreation.getCreatedObject()).thenReturn(container);

        doThrow(BcbException.class).when(container).getId();
        
        cache.onObjectCreation(objectCreation);
    }
    
    @Test(expected=BcbException.class)
    public void testOnObjectDeletion_error() throws BcbException {
        when(objectDeletion.getDeletedObject()).thenReturn(containerId);

        doThrow(BcbException.class).when(containerId).getId();
        
        cache.onObjectDeletion(objectDeletion);
    }

    @Test(expected=BcbException.class)
    public void testOnAttributeValueChange_error() throws BcbException, CacheException {
        when(attributeValueChange.getChangedObject()).thenReturn(markable);

        doThrow(BcbException.class).when(markable).getId();
        
        cache.cache().put(ID, container);
        cache.onAttributeValueChange(attributeValueChange);
    }
}
