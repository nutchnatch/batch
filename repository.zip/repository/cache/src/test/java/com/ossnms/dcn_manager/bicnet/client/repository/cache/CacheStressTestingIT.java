package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.ContainerSearchable;
import net.sf.ehcache.Element;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Stress test on Container Cache queries.
 */
public class CacheStressTestingIT {

    private static final ActivationAwareCacheWrapper<Integer, IGenericContainer> CACHE = ContainerCacheManager
            .getInstance().cache();

    private static final String NAME = "name_";
    private static final String DESCRIPTION = "description_";
    private static final String LABEL = "label_";

    private static final int NUM_ELEMENTS = 1000;
    private static final int NUM_ELEMENTS_CHILD = 50;
    private static final int ROOT_ID = 0;
    private static final int TOTAL_ELEMENTS = 50951;

    private Collection<Element> elements;

    @Before public void setUp() throws Exception {
        elements = loadScenario();
        CACHE.fetch(loadScenario());
    }

    @After public void tearDown() throws Exception {
        elements.clear();
        CACHE.clear();
    }

    @Test public void testSize() throws Exception {
        assertThat(elements.size(), is(TOTAL_ELEMENTS));
        assertThat(CACHE.all().size(), is(TOTAL_ELEMENTS));
    }

    @Test public void testNumChild() throws Exception {
        assertThat(((ContainerSearchable) CACHE.queries()).findByParentId(ROOT_ID).size(), is(NUM_ELEMENTS + 1));

        for (int i = 1; i < NUM_ELEMENTS; i++) {
            final int childrenElements = ((ContainerSearchable) CACHE.queries()).findByParentId(1).size();
            assertThat(childrenElements, is(NUM_ELEMENTS_CHILD));
        }
    }

    private Collection<Element> loadScenario() {
        Collection<Element> elements = new ArrayList<>();
        int id = 0;

        // ROOT
        elements.add(buildElement(ROOT_ID, ROOT_ID));

        for (int i = 0; i < NUM_ELEMENTS; i++) {
            elements.add(buildElement(++id, ROOT_ID));
        }

        for (int i = 1; i < NUM_ELEMENTS; i++) {
            for (int j = 0; j < NUM_ELEMENTS_CHILD; j++) {
                elements.add(buildElement(++id, i));
            }
        }

        return elements;
    }

    private Element buildElement(int id, int parentId) {
        final IGenericContainer genericContainerItem = new GenericContainerItem();
        genericContainerItem.setId(id);
        genericContainerItem.setIdName(NAME + id);
        genericContainerItem.setParentId(parentId);
        genericContainerItem.setDescription(DESCRIPTION + id);
        genericContainerItem.setUserLabel(LABEL + id);

        return new Element(id, genericContainerItem);
    }
}