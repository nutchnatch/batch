/*
* Copyright (C) Coriant
* The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
* Offenders will be liable for damages.
* All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
* Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
*
*/

package com.ossnms.dcn_manager.bicnet.client.repository.cache;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch.Loader;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.searchable.queries.Searchable;
import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.PersistenceConfiguration;
import net.sf.ehcache.config.PersistenceConfiguration.Strategy;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.stream.Collectors;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

public class ActivationAwareCacheWrapperTest {

    private static final String CACHE_NAME = "ActivationAwareCacheWrapperTest";
    private static final int MAX_ELEMENTS = 20;
    private static final int AUTO_CREATE_TOTAL = 5;

    private ActivationAwareCacheWrapper<Integer, String> cache;

    private Searchable<String> searchable;

    public ActivationAwareCacheWrapperTest() {
    }

    @Before
    @SuppressWarnings("unchecked")
    public void setup() {
        searchable = mock(Searchable.class);

        loadCache();
        cache.activate();
    }

    @After
    public void release() throws CacheException {
        cache.deactivate();
        net.sf.ehcache.CacheManager.getInstance().removeCache(CACHE_NAME);
        cache = null;
    }

    private void loadCache() {
        final CacheConfiguration configuration = new CacheConfiguration(CACHE_NAME, MAX_ELEMENTS).persistence(
                new PersistenceConfiguration().strategy(Strategy.NONE)).eternal(true);

        final Cache ehcache = new Cache(configuration);

        net.sf.ehcache.CacheManager.getInstance().addCache(ehcache);

        cache = new ActivationAwareCacheWrapperImpl<>(net.sf.ehcache.CacheManager.getInstance().getEhcache(CACHE_NAME), searchable, mock(Loader.class));

        final ImmutableList<Pair<Integer, String>> items = createList(AUTO_CREATE_TOTAL);

        cache.fetch(items.stream().map(input -> new Element(input.getLeft(), input.getRight())).collect(Collectors.toList()));
    }


    @Test(expected = IllegalStateException.class)
    public void testInterationsAfterDeactivation() throws CacheException {
        cache.deactivate();
        assertTrue(cache.find(1).isPresent());
    }

    @Test(expected = IllegalStateException.class)
    public void testPutMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.put(2, "test");
    }

    @Test(expected = IllegalStateException.class)
    public void testUpdateMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.update(2, "test");
    }

    @Test(expected = IllegalStateException.class)
    public void testFindMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.find(2);
    }

    @Test(expected = IllegalStateException.class)
    public void testFindAllKeysMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.findAllKeys(Arrays.asList(1, 2));
    }

    @Test(expected = IllegalStateException.class)
    public void testRemoveMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.remove(1);
    }

    @Test(expected = IllegalStateException.class)
    public void testAllMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.all();
    }

    @Test(expected = IllegalStateException.class)
    public void testClearMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.clear();
    }

    @Test(expected = IllegalStateException.class)
    public void testQueriesMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.queries();
    }

    @Test(expected = IllegalStateException.class)
    public void testFindOrFetchMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.findOrFetch(1);
    }

    @Test(expected = IllegalStateException.class)
    public void testFetchMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.fetch(1);
    }

    @Test(expected = IllegalStateException.class)
    public void testFetchStartMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.fetchStart();
    }

    @Test(expected = IllegalStateException.class)
    public void testFetchCollectionMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.fetch(Arrays.asList(new Element(1, "1"), new Element(2, "2")));
    }

    @Test(expected = IllegalStateException.class)
    public void testFetchErrorMethodAfterDeactivation() throws CacheException {
        cache.deactivate();
        cache.fetchError();
    }


    private ImmutableList<Pair<Integer, String>> createList(final int total) {

        final Builder<Pair<Integer, String>> builder = ImmutableList.builder();

        for (int i = 1; i <= total; i++) {
            builder.add(ImmutablePair.of(i, "value" + 1));
        }

        return builder.build();
    }


}
