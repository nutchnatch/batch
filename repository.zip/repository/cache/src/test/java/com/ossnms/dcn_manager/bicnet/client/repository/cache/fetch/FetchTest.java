package com.ossnms.dcn_manager.bicnet.client.repository.cache.fetch;

import static java.util.Arrays.asList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Test;

import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;

import net.sf.ehcache.Element;

public class FetchTest {

    private final CacheInitializer initializer = mock(CacheInitializer.class);
    private final Loader<String, String> loader = mock(Loader.class);
    private final Fetch<String, String> fetch = new Fetch<>(initializer, loader);

    @Test public void shouldStartInitializer() throws Exception {
        fetch.run();

        verify(initializer, times(1)).fetchStart();
    }

    @Test public void shouldReportErrorOnCacheException() throws Exception {
        when(loader.loadElements()).thenThrow(new CacheException());

        fetch.run();

        verify(initializer, times(1)).fetchError();
    }

    @Test public void shouldProvideInitializerValues() throws Exception {
        List<Element> elements = asList(new Element("key", "value"), new Element("another key", "some value"));
        when(loader.loadElements()).thenReturn(elements);

        fetch.run();

        verify(initializer, times(1)).fetch(elements);
    }

}