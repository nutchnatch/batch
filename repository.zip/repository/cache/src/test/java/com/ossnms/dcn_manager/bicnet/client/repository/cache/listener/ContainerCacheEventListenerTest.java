package com.ossnms.dcn_manager.bicnet.client.repository.cache.listener;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import net.sf.ehcache.Element;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.client.api.listener.EventChangeListener;
import com.ossnms.dcn_manager.bicnet.client.api.listener.ListenersRegistrationManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.ContainerCacheManager;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.exception.CacheException;
import com.ossnms.dcn_manager.bicnet.client.repository.cache.listener.manager.CacheListenersRegistrationManager;

public class ContainerCacheEventListenerTest {

    private final ListenersRegistrationManager listenersManager;
    private final EventListenerTest eventListenerTest;
    private IGenericContainer container;
    
    public ContainerCacheEventListenerTest() {
        eventListenerTest = new EventListenerTest();
        listenersManager = new CacheListenersRegistrationManager();        
    }

    @Before
    public void setup() {
        container = new GenericContainerItem();
        container.setId(1);        
        container.setIdName("name");
        
        ContainerCacheManager.getInstance().cache().fetch(new ArrayList<Element>());
        listenersManager.addContainerListener(eventListenerTest);
    }
    
    @After
    public void release() throws CacheException {
        eventListenerTest.removeAll();
        ContainerCacheManager.getInstance().cache().clear();
        listenersManager.removeContainerListener(eventListenerTest);
    }

    @Test
    public void testElementAdded() throws CacheException {
        ContainerCacheManager.getInstance().cache().put(container.getId(), container);

        assertTrue(eventListenerTest.getElements().contains(container.getGenericContainerId()));
        assertThat(eventListenerTest.getElements().size(), is(1));
    }

    @Test
    public void testElementRemoved() throws CacheException {
        ContainerCacheManager.getInstance().cache().put(container.getId(), container);
        ContainerCacheManager.getInstance().cache().remove(container.getId());

        assertFalse(eventListenerTest.getElements().contains(container.getGenericContainerId()));
        assertTrue(eventListenerTest.getElements().isEmpty());
    }
    
    @Test
    public void elementUpdated() throws CacheException {
        final IGenericContainer emUpdated = new GenericContainerItem();
        emUpdated.setId(1);
        emUpdated.setIdName("NEW_NAME");
        
        ContainerCacheManager.getInstance().cache().put(container.getId(), container);
        ContainerCacheManager.getInstance().cache().update(container.getId(), emUpdated);

        assertTrue(eventListenerTest.getElements().contains(container.getGenericContainerId()));
        assertThat(eventListenerTest.getElements().size(), is(1));
    }
    
    @Test
    public void removeListener() throws CacheException {
        final INE neUpdated = new NEItem();
        neUpdated.setId(1);
        neUpdated.setIdName("NEW_NAME");

        listenersManager.removeContainerListener(eventListenerTest);

        ContainerCacheManager.getInstance().cache().put(container.getId(), container);
        
        assertTrue(eventListenerTest.getElements().isEmpty());
    }
    
    @Test
    public void elementClear() throws CacheException {
        ContainerCacheManager.getInstance().cache().put(container.getId(), container);
        ContainerCacheManager.getInstance().cache().clear();

        assertTrue(eventListenerTest.getElements().isEmpty());
    }

    private static class EventListenerTest implements EventChangeListener<IGenericContainer> {

        private final Set<IGenericContainerId> elements = new HashSet<>();

        public Set<IGenericContainerId> getElements() {
            return elements;
        }

        @Override
        public void elementRemoved(IGenericContainer element) {
            elements.remove(element.getGenericContainerId());
        }

        @Override
        public void elementAdded(IGenericContainer element) {
            elements.add(element.getGenericContainerId());
        }

        @Override
        public void elementUpdated(IGenericContainer element) {
            elements.add(element.getGenericContainerId());
        }

        @Override
        public void removeAll() {
            elements.clear();
        }        
    }
}
