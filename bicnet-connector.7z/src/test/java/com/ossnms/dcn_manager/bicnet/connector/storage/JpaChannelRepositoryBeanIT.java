package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.unitils.dbunit.annotation.DataSet;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

@DataSet
public class JpaChannelRepositoryBeanIT extends HelperItTestBase {

    @InjectMocks private JpaChannelRepositoryBean repositoryBean;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        repositoryBean.initialize();
        repositoryBean.start();
    }

    @Test
    public void testName() throws Exception {

        assertThat(repositoryBean.queryChannelName(1), hasValue("testChannelName"));
        assertThat(repositoryBean.queryChannelName(2), is(absent()));

    }

    @Test
    public void testQueryByRequiredActivation() throws Exception {

        Iterable<ChannelInfoData> activationRequired;

        activationRequired = repositoryBean.queryActivationRequiredIs(20, true);
        assertThat(activationRequired, is(Matchers.iterableWithSize(1)));
        activationRequired = repositoryBean.queryActivationRequiredIs(20, false);
        assertThat(activationRequired, is(emptyIterable()));

        activationRequired = repositoryBean.queryActivationRequiredIs(99, true);
        assertThat(activationRequired, is(emptyIterable()));
        activationRequired = repositoryBean.queryActivationRequiredIs(99, false);
        assertThat(activationRequired, is(emptyIterable()));
    }

}
