package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.dcn_manager.bicnet.connector.outbound.SecurityManagerImpl;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.test.util.ReturnFirstArgumentAsString;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SecurityManagerHelperTest {

    @Mock private DomainRepository domainRepo;
    @Mock private NeEntityRepository repo;
    @Mock private StaticConfiguration config;
    @Mock private NeType type;
    @Mock private Types<NeType> types;
    @Mock private ChannelEntityRepository channelRepository;
    @Mock private MediatorEntityRepository mediatorRepository;
    @Mock private ContainerRepository containerRepository;
    @Mock private SystemRepository systemRepository;

    @InjectMocks private SecurityManagerImpl securityManager;

    private SecurityManagerHelper helper;

    @Before
    public void setUp() throws RepositoryException {
        final ReturnFirstArgumentAsString returnFirstArgumentAsString = new ReturnFirstArgumentAsString();

        helper = new SecurityManagerHelper(repo, securityManager);

        when(domainRepo.queryAllForNE(anyInt())).thenReturn(Collections.emptyList());
        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.empty());

        when(type.getName()).thenReturn("typeName");
        when(type.mapIncomingPropertyName(anyString())).then(returnFirstArgumentAsString);
        when(type.mapOutgoingPropertyName(anyString())).then(returnFirstArgumentAsString);
        when(type.getTypeProperties()).thenReturn(Collections.emptyMap());
        when(type.getDefaultIcon()).thenReturn("iconId");
        when(types.get(any(String.class))).thenReturn(type);
        when(config.getNeTypes()).thenReturn(types);

        when(containerRepository.query(anyInt())).thenReturn(Optional.empty());
        when(containerRepository.queryAllByNE(anyInt())).thenReturn(Collections.emptyList());
        when(containerRepository.queryAllBySystem(anyInt())).thenReturn(Collections.emptyList());
    }

    @Test
    public void testOperations() {
        final String[] operations = helper.getOperations();

        assertThat(operations, is(notNullValue()));
        assertThat(operations.length, not(is(0)));
    }

    @Test
    public void testSecurableObjects() throws RepositoryException {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(99, type);
        createDescriptor.getPreferences().setName("name");
        final NeEntity ne1 = NeEntity.build(1, 1, createDescriptor);
        final NeEntity ne2 = NeEntity.build(2, 1, createDescriptor);

        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.empty());
        when(repo.queryAll()).thenReturn(ImmutableList.of(ne1, ne2));

        final ISecurableObject[] objects = helper.getSecurableObjects();

        assertThat(objects, is(notNullValue()));
        assertThat(objects.length, is(2));
    }

    @Test
    public void testSecurableObjects_repositoryError() throws RepositoryException {
        when(repo.queryAll()).thenThrow(new RepositoryException());

        final ISecurableObject[] objects = helper.getSecurableObjects();

        assertThat(objects, is(notNullValue()));
        assertThat(objects.length, is(0));
    }

}
