package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalDataMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceUpdates;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.unitils.dbunit.annotation.DataSet;

import java.util.Collections;
import java.util.Optional;

import static com.google.common.collect.Iterables.getOnlyElement;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.emptyIterableOf;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

@DataSet
public class JpaMediatorInstanceRepositoryBeanIT extends HelperItTestBase {

    @InjectMocks private JpaMediatorInstanceRepositoryBean repositoryBean;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        repositoryBean.initialize();
        repositoryBean.start();
    }

    @Test
    public void updateInstance() throws Exception {

        final Optional<MediatorInstance> found = repositoryBean.query(10);
        assertThat(found, is(present()));

        final MediatorPhysicalData existingPhysicalInfo = found.get().getPhysicalInfo();
        assertThat(existingPhysicalInfo.getId(), is(10));

        final MediatorPhysicalDataMutationDescriptor dataMutation = new MediatorPhysicalDataMutationDescriptor(existingPhysicalInfo);
        dataMutation.setHost("mutated host");

        final MediatorInstanceCreateDescriptor instanceCreation = new MediatorInstanceCreateDescriptor("additional host");
        instanceCreation.getInitialData().setPriority(0);

        final MediatorInstanceUpdates updates =
                repositoryBean.updateInstance(1, Collections.singleton(dataMutation), Collections.singleton(instanceCreation));

        assertThat(updates.getCreatedInstances(), contains(
                new MediatorInstance(
                        new MediatorPhysicalDataBuilder().setPriority(0).setHost("additional host").setPriority(0).build(1000, 1, 0),
                        new MediatorPhysicalConnectionBuilder().build(1000, 1, 0)
                    )));
        assertThat(updates.getUpdatedInstances(), contains(
                new MediatorInstance(
                        new MediatorPhysicalDataBuilder().setPriority(0).setHost("mutated host").setPriority(1).build(10, 1, 1),
                        new MediatorPhysicalConnectionBuilder().build(10, 1, 0)
                    )));

        final Iterable<MediatorInstance> instances = ImmutableList.copyOf(repositoryBean.queryAll(1));
        assertThat(instances, containsInAnyOrder(
            new MediatorInstance(
                    new MediatorPhysicalDataBuilder().setPriority(0).setHost("additional host").setPriority(0).build(1000, 1, 0),
                    new MediatorPhysicalConnectionBuilder().build(1000, 1, 0)
                ),
            new MediatorInstance(
                    new MediatorPhysicalDataBuilder().setPriority(0).setHost("mutated host").setPriority(1).build(10, 1, 1),
                    new MediatorPhysicalConnectionBuilder().build(10, 1, 0)
                )));

    }

    @Test
    public void switchHosts() throws Exception {

        final Optional<MediatorPhysicalData> instance0 = repositoryBean.getMediatorPhysicalDataRepository().query(10);
        final Optional<MediatorPhysicalData> instance1 = repositoryBean.getMediatorPhysicalDataRepository().query(11);

        assertThat(instance0, is(present()));
        assertThat(instance1, is(present()));

        final MediatorPhysicalDataMutationDescriptor mutation0 = new MediatorPhysicalDataMutationDescriptor(instance0.get());
        final MediatorPhysicalDataMutationDescriptor mutation1 = new MediatorPhysicalDataMutationDescriptor(instance1.get());

        final String host0 = instance0.get().getHost();
        mutation0.setHost(instance1.get().getHost());
        mutation1.setHost(host0);

        repositoryBean.updateInstance(1, ImmutableList.of(mutation0, mutation1), Collections.emptyList());

        final Iterable<MediatorInstance> instances = ImmutableList.copyOf(repositoryBean.queryAll(1));
        assertThat(instances, containsInAnyOrder(
            new MediatorInstance(
                    new MediatorPhysicalDataBuilder().setPriority(0).setHost(instance1.get().getHost()).build(10, 1, 1),
                    new MediatorPhysicalConnectionBuilder().build(10, 1, 0)
                ),
            new MediatorInstance(
                    new MediatorPhysicalDataBuilder().setPriority(1).setHost(instance0.get().getHost()).build(11, 1, 1),
                    new MediatorPhysicalConnectionBuilder().build(11, 1, 0)
                )));
    }

    @Test
    public void query() throws Exception {

        final Optional<MediatorInstance> found = repositoryBean.query(10);
        assertThat(found, is(present()));

        final MediatorInstance instance = found.get();
        final MediatorPhysicalData info = instance.getPhysicalInfo();
        final MediatorPhysicalConnectionData connection = instance.getConnection();

        assertThat(info, is(notNullValue()));
        assertThat(connection, is(notNullValue()));

        assertThat(info.getHost(), is("localhost"));
        assertThat(info.getId(), is(10));
        assertThat(connection.getLogicalMediatorId(), is(1));

        assertThat(connection.getActualActivationState(), is(ActualActivationState.INACTIVE));
        assertThat(connection.isActive(), is(false));
        assertThat(connection.getLogicalMediatorId(), is(1));
        assertThat(connection.getId(), is(10));
    }

    @Test
    public void query_notFound_returnsAbsent() throws Exception {

        final Optional<MediatorInstance> found = repositoryBean.query(98756);
        assertThat(found, is(absent()));
    }

    @Test
    public void queryAll() throws Exception {

        final Iterable<MediatorInstance> all = repositoryBean.queryAll();
        assertThat(all, is(Matchers.<MediatorInstance>iterableWithSize(1)));

        final MediatorInstance instance = getOnlyElement(all);
        final MediatorPhysicalData info = instance.getPhysicalInfo();
        final MediatorPhysicalConnectionData connection = instance.getConnection();

        assertThat(info, is(notNullValue()));
        assertThat(connection, is(notNullValue()));

        assertThat(info.getHost(), is("localhost"));
        assertThat(info.getId(), is(10));
        assertThat(connection.getLogicalMediatorId(), is(1));

        assertThat(connection.getActualActivationState(), is(ActualActivationState.INACTIVE));
        assertThat(connection.isActive(), is(false));
        assertThat(connection.getLogicalMediatorId(), is(1));
        assertThat(connection.getId(), is(10));
    }

    @Test
    public void empty() throws Exception {

        final Iterable<MediatorInstance> all = repositoryBean.queryAll();
        assertThat(all, is(emptyIterableOf(MediatorInstance.class)));

        final Optional<MediatorInstance> found = repositoryBean.query(10);
        assertThat(found, is(absent()));
    }
}
