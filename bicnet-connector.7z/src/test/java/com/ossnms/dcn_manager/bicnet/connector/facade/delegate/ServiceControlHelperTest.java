package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.codahale.metrics.JmxReporter;
import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherConfig;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherFactory;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.outbound.MediatorConnectionManager;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static com.ossnms.bicnet.bcb.messaging.BiCNetMessageLayer.ATP_SCHEDULER;
import static com.ossnms.bicnet.bcb.messaging.BiCNetMessageLayer.SOURCE;
import static java.util.Collections.emptyList;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ServiceControlHelperTest {

    @Mock private ISessionContext ctx;
    @Mock private JmxReporter jmxReporter;
    @Mock private ServiceControlHelperData serviceControlHelperData;
    @Mock private MediatorConnectionManager mediatorConnectionManager;
    @Mock private MediatorInstanceEntityRepository mediatorInstanceEntityRepository;
    @Mock private MediatorPhysicalConnectionRepository mediatorPhysicalConnectionRepository;
    @Mock private IBiCNetMessageDispatcherFactory dispatcherFactory;
    @Mock private IBiCNetMessageDispatcherConfig dispatcherConfig;

    @InjectMocks private ServiceControlHelper sch;

    @Before
    public void setUp() throws Exception {
        when(mediatorInstanceEntityRepository.getMediatorPhysicalConnectionRepository())
                .thenReturn(mediatorPhysicalConnectionRepository);
        when(dispatcherFactory.getDispatcherConfig(BiCNetComponentType.DCN_MANAGER)).thenReturn(dispatcherConfig);
    }

    @Test
    public void stop() throws Exception {

        sch.stop(ctx);

        verify(serviceControlHelperData).unsubscribeFromEvents();
        verify(jmxReporter).stop();
    }

    @Test
    public void shutdown_closeActiveMediatorConnections() throws Exception {

        when(serviceControlHelperData.isComponentStarted()).thenReturn(false);

        when(mediatorPhysicalConnectionRepository.queryAll()).thenReturn(ImmutableList.of(
                new MediatorPhysicalConnectionBuilder().build(1, 1, 0),
                new MediatorPhysicalConnectionBuilder().setActualActivationState(ActualActivationState.ACTIVE).build(2, 2, 0)
        ));

        sch.shutDown(ctx);

        verify(mediatorConnectionManager, never()).disconnect(1);
        verify(mediatorConnectionManager).disconnect(2);

        verify(serviceControlHelperData, never()).setComponentStarted(false);
    }

    @Test
    public void shutdown_notStopped_stopAndCloseActiveMediatorConnections() throws Exception {

        when(serviceControlHelperData.isComponentStarted()).thenReturn(true);

        when(mediatorPhysicalConnectionRepository.queryAll()).thenReturn(ImmutableList.of(
                new MediatorPhysicalConnectionBuilder().build(1, 1, 0),
                new MediatorPhysicalConnectionBuilder().setActualActivationState(ActualActivationState.ACTIVE).build(2, 2, 0),
                new MediatorPhysicalConnectionBuilder().setActualActivationState(ActualActivationState.FAILED).build(3, 3, 0)
        ));

        sch.shutDown(ctx);

        verify(serviceControlHelperData).unsubscribeFromEvents();
        verify(jmxReporter).stop();

        verify(mediatorConnectionManager, never()).disconnect(1);
        verify(mediatorConnectionManager).disconnect(2);
        verify(mediatorConnectionManager, never()).disconnect(3);

        verify(serviceControlHelperData).setComponentStarted(false);
    }

    @Test
    public void shutdown_closeActiveMediatorConnections_errorOnMediatorRepo_ignores() throws Exception {

        when(mediatorPhysicalConnectionRepository.queryAll()).thenThrow(new RepositoryException());

        sch.shutDown(ctx);

        verifyZeroInteractions(mediatorConnectionManager);

    }

    @Test public void shouldRemoveMessageListenerOnShutdown() throws Exception {
        when(mediatorPhysicalConnectionRepository.queryAll()).thenReturn(emptyList());

        sch.shutDown(ctx);

        verify(dispatcherConfig).removeListener(eq(ATP_SCHEDULER), any());
        verify(dispatcherConfig).removeListener(eq(SOURCE), any());
    }
}