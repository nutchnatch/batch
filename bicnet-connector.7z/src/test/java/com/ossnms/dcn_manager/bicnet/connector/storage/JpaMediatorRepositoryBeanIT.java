package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.unitils.dbunit.annotation.DataSet;
import org.unitils.inject.util.InjectionUtils;
import org.unitils.inject.util.PropertyAccess;

import static com.google.common.collect.Iterables.getOnlyElement;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.emptyIterableOf;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

@DataSet
public class JpaMediatorRepositoryBeanIT extends HelperItTestBase {

    @InjectMocks private JpaMediatorRepositoryBean logicalRepositoryBean;
    @InjectMocks private JpaMediatorInstanceRepositoryBean instanceRepositoryBean;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        InjectionUtils.injectIntoByType(instanceRepositoryBean, JpaMediatorInstanceRepositoryBean.class, logicalRepositoryBean, PropertyAccess.FIELD);

        instanceRepositoryBean.initialize();
        instanceRepositoryBean.start();

        logicalRepositoryBean.initialize();
        logicalRepositoryBean.start();
    }


    @Test
    public void testName() throws Exception {

        assertThat(logicalRepositoryBean.queryMediatorName(1), hasValue("testMediatorName"));
        assertThat(logicalRepositoryBean.queryMediatorName(2), is(absent()));

    }

    @Test
    public void create() throws Exception {

        final MediatorCreateDescriptor createDescriptor = new MediatorCreateDescriptor("new mediator", "some type");
        final MediatorInstanceCreateDescriptor instanceCreateDescriptor = new MediatorInstanceCreateDescriptor("some host");

        instanceCreateDescriptor.getInitialData().setPriority(1);
        createDescriptor.getInstanceCreateDescriptors().add(instanceCreateDescriptor);

        final MediatorEntity entity = logicalRepositoryBean.create(createDescriptor);

        assertThat(entity, is(notNullValue()));
        assertThat(entity.getInfo(), is(notNullValue()));
        assertThat(entity.getConnection(), is(notNullValue()));
        assertThat(entity.getInfo().getId(), is(greaterThan(0)));
        assertThat(entity.getInfo().getName(), is("new mediator"));
        assertThat(entity.getInfo().getTypeName(), is("some type"));

        final Iterable<MediatorInstance> allInstances = instanceRepositoryBean.queryAll();
        assertThat(allInstances, is(Matchers.iterableWithSize(1)));
        final MediatorInstance mediatorInstance = getOnlyElement(allInstances);
        final MediatorPhysicalConnectionData connection = mediatorInstance.getConnection();
        final MediatorPhysicalData physicalInfo = mediatorInstance.getPhysicalInfo();
        assertThat(connection, is(notNullValue()));
        assertThat(physicalInfo, is(notNullValue()));
        assertThat(physicalInfo.getId(), is(greaterThan(0)));
        assertThat(physicalInfo.getLogicalMediatorId(), is(entity.getInfo().getId()));
        assertThat(physicalInfo.getHost(), is("some host"));
        assertThat(connection.getId(), is(physicalInfo.getId()));
        assertThat(connection.getLogicalMediatorId(), is(entity.getInfo().getId()));
        assertThat(connection.getActualActivationState(), is(ActualActivationState.INACTIVE));
    }

    @Test
    public void delete() throws Exception {
        Iterable<MediatorInstance> instances;
        Iterable<MediatorEntity> logicals;

        // sanity check
        logicals = logicalRepositoryBean.queryAll();
        instances = instanceRepositoryBean.queryAll();
        assertThat(logicals, is(Matchers.iterableWithSize(1)));
        assertThat(instances, is(Matchers.iterableWithSize(1)));

        // actual test
        logicalRepositoryBean.delete(new MediatorDeleteDescriptor(1));

        logicals = logicalRepositoryBean.queryAll();
        instances = instanceRepositoryBean.queryAll();
        assertThat(logicals, is(emptyIterableOf(MediatorEntity.class)));
        assertThat(instances, is(emptyIterableOf(MediatorInstance.class)));

        assertThat(logicalRepositoryBean.getMediatorConnectionRepository().queryAll(), is(emptyIterableOf(MediatorConnectionData.class)));

        assertThat(logicalRepositoryBean.getMediatorInfoRepository().queryAll(), is(emptyIterableOf(MediatorInfoData.class)));

        assertThat(instanceRepositoryBean.getMediatorPhysicalConnectionRepository().queryAll(), is(emptyIterableOf(MediatorPhysicalConnectionData.class)));

        assertThat(instanceRepositoryBean.getMediatorPhysicalDataRepository().queryAll(), is(emptyIterableOf(MediatorPhysicalData.class)));
    }
}
