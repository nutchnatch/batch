package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEReply;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;
import com.ossnms.bicnet.bcb.model.elementMgmt.NeFamily;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeActivationState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapabilities;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapability;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.scs.ScsSiteConfiguration;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.connection.NeConnectionManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.NeNotificationsManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.ChannelInstanceConnectionRepository;
import com.ossnms.dcn_manager.bicnet.connector.storage.HelperItTestBase;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaChannelRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaDomainRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.NeInstanceConnectionRepository;
import com.ossnms.dcn_manager.composables.configuration.HardwareConfigurationType;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeConnectionRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.unitils.dbunit.annotation.DataSet;
import org.unitils.inject.util.InjectionUtils;
import org.unitils.inject.util.PropertyAccess;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.arrayWithSize;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@DataSet
public class NeHelperIT extends HelperItTestBase {

    private static final int CHANNEL_ID = 10;
    private static final String NE_TYPE = "proxy-type";
    private static final String PROXY_TYPE_OTHER = "proxy-type-other";

    @Mock private ISessionContext context;
    @Mock private StaticConfiguration configuration;
    @Mock private Types<NeType> types;
    @Mock private NeNotificationsManagerImpl neNotifications;
    @Mock private NeConnectionManagerImpl neConnectionManager;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private ISystemControlEjbFacade scs;
    @Mock private ContainerNotifications containerNotifications;
    @Mock private StaticConfigurationSingleton hwConfiguration;

    @InjectMocks private JpaNetworkElementRepositoryBean neRepository;
    @InjectMocks private JpaDomainRepositoryBean domainRepository;
    @InjectMocks private JpaChannelRepositoryBean channelRepository;
    @InjectMocks private JpaContainerRepositoryBean containerRepository;
    @InjectMocks private JpaSettingsRepositoryBean settingsRepository;
    @InjectMocks private JpaSystemRepositoryBean systemRepositoryBean;
    @InjectMocks private NeHelper helper;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        when(hwConfiguration.getHWConfiguration()).thenReturn(HardwareConfigurationType.MED);
        
        channelRepository.initialize();
        neRepository.initialize();
        settingsRepository.initialize();
        channelRepository.start();
        neRepository.start();
        settingsRepository.start();

        final NeType proxyType = MockFactory.mockNeType();
        when(proxyType.getDefaultIcon()).thenReturn("defaultIconId");
        when(proxyType.getName()).thenReturn("proxy-type");
        when(proxyType.getCapabilities()).thenReturn(NeCapabilities.of(NeCapability.ALARM_SUPPRESSION, NeCapability.ADMIN_STATE_NO_CHANGE).toDbString());
        when(proxyType.getDirectRouteAddressKeySource()).thenReturn(Optional.empty());
        when(proxyType.getDirectRouteAttributes()).thenReturn(Collections.emptyMap());
        when(proxyType.getProtocol()).thenReturn("SNMP");
        when(proxyType.getIdentificationControlMap()).thenReturn(ImmutableBiMap.of());
        when(proxyType.getAdditionalTypeInfoControlMap()).thenReturn(ImmutableBiMap.of());

        final NeType otherProxyType = MockFactory.mockNeType();
        when(otherProxyType.getDefaultIcon()).thenReturn("defaultIconId");
        when(otherProxyType.getName()).thenReturn("proxy-type-other");
        when(otherProxyType.getCapabilities()).thenReturn(NeCapabilities.of(NeCapability.ALARM_SUPPRESSION, NeCapability.ALARM_SEVERITY_PROFILE_MANAGEMENT).toDbString());
        when(otherProxyType.getDirectRouteAddressKeySource()).thenReturn(Optional.empty());
        when(otherProxyType.getDirectRouteAttributes()).thenReturn(Collections.emptyMap());
        when(otherProxyType.getProtocol()).thenReturn("SNMP");
        when(otherProxyType.getIdentificationControlMap()).thenReturn(ImmutableBiMap.of());

        when(types.get(NE_TYPE)).thenReturn(proxyType);
        when(types.get(PROXY_TYPE_OTHER)).thenReturn(otherProxyType);
        when(types.values()).thenReturn(ImmutableList.of(proxyType, otherProxyType));
        when(configuration.getNeTypes()).thenReturn(types);

        when(scs.getSiteConfiguration(context)).thenReturn(ScsSiteConfiguration.PRIMARY);
        when(scs.isStandbyConfigured(context)).thenReturn(true);

        NeInstanceConnectionRepository neInstanceRepository = new NeInstanceConnectionRepository();
        ChannelInstanceConnectionRepository channelInstanceRepository = new ChannelInstanceConnectionRepository();

        final NetworkElementManagers networkElementManagers = new NetworkElementManagers(neRepository, neInstanceRepository, null, neNotifications, null);

        InjectionUtils.injectIntoByType(domainRepository, domainRepository.getClass(), helper, PropertyAccess.FIELD);
        InjectionUtils.injectIntoByType(neRepository, neRepository.getClass(), helper, PropertyAccess.FIELD);
        InjectionUtils.injectIntoByType(channelRepository, channelRepository.getClass(), helper, PropertyAccess.FIELD);
        InjectionUtils.injectIntoByType(channelInstanceRepository, ChannelPhysicalConnectionRepository.class, helper, PropertyAccess.FIELD);
        InjectionUtils.injectIntoByType(containerRepository, containerRepository.getClass(), helper, PropertyAccess.FIELD);
        InjectionUtils.injectIntoByType(settingsRepository, settingsRepository.getClass(), helper, PropertyAccess.FIELD);
        InjectionUtils.injectIntoByType(systemRepositoryBean, systemRepositoryBean.getClass(), helper, PropertyAccess.FIELD);

        InjectionUtils.injectIntoByType(networkElementManagers, networkElementManagers.getClass(), helper, PropertyAccess.FIELD);
    }

    private void verifyEntity(INE ne, int id, int channelId, int sysId, String name, String realName) {
        assertThat(ne.getId(), is(id));
        assertThat(ne.getAssociatedEmId(), is(channelId));
        assertThat(ne.getAssociatedSystemContainerId(), is(sysId));
        assertThat(ne.getRealNeName(), is(realName));
        assertThat(ne.getIdName(), is(name));
    }

    private void changeActualActivationState(int neId, ActualActivationState state) throws RepositoryException {
        final NeConnectionRepository connectionRepository = neRepository.getNeConnectionRepository();
        final Optional<NeConnectionData> current = connectionRepository.query(neId);
        assertThat(current, is(present()));
        final NeConnectionMutationDescriptor mutation = new NeConnectionMutationDescriptor(current.get());
        mutation.setActivationState(state);
        final Optional<NeConnectionData> updated = connectionRepository.tryUpdate(mutation);
        assertThat(updated, is(present()));
    }

    @Test public void duplicate_under_system() throws Exception {
        final NEIdItem neIdItem = new NEIdItem(1);
        final INE template = helper.getSingleNE(context, neIdItem);
        template.setIdName("duplicated_new_name");

        final Map<String, String> properties = helper.getProperties(context, neIdItem);
        properties.put(WellKnownNePropertyNames.ID_NAME, "duplicated_new_name");

        helper.duplicate(context, template, transform(properties));

        final Optional<NeUserPreferencesData> duplicatedNe= neRepository.getNeUserPreferencesRepository()
                .query("duplicated_new_name");

        assertThat(duplicatedNe.isPresent(), is(true));
        assertThat(duplicatedNe.get().getContainerId().get(), is(template.getAssociatedSystemContainerId()));
    }

    @Test public void duplicate_under_container() throws Exception {
        final NEIdItem neIdItem = new NEIdItem(1);
        final INE template = helper.getSingleNE(context, neIdItem);
        template.setIdName("duplicated_new_name");
        template.setAssociatedSystemContainerId(0);

        final Map<String, String> properties = helper.getProperties(context, neIdItem);
        properties.put(WellKnownNePropertyNames.ID_NAME, "duplicated_new_name");

        helper.duplicate(context, template, transform(properties));

        final Optional<NeUserPreferencesData> duplicatedNe= neRepository.getNeUserPreferencesRepository()
                .query("duplicated_new_name");

        assertThat(duplicatedNe.isPresent(), is(true));
        assertThat(duplicatedNe.get().getContainerId().get(), is(0));

        final Collection<String> fromDuplicated = StreamSupport.stream(
                containerRepository.queryAllByNE(duplicatedNe.get().getId()).spliterator(), false)
                .map(assignment -> assignment.getContainerInfo().getName()).collect(Collectors.toList());

        final Iterable<String> fromTemplate =  StreamSupport.stream(containerRepository
                .queryAllByNE(template.getId()).spliterator(), false)
                .map(assignment -> assignment.getContainerInfo().getName()).collect(Collectors.toList());

        assertThat(fromDuplicated, is(fromTemplate));
    }

    @Test
    public void updateProperties() throws Exception {

        Map<String, String> neProperties = helper.getProperties(context, new NEIdItem(2));
        assertThat(neProperties, not(hasEntry("Some", "Property")));
        assertThat(neProperties, hasEntry(WellKnownNePropertyNames.ID_NAME, "testNeName2"));

        helper.updateProperties(context, new NEIdItem(2), ImmutableMap.of(
                "Some", "Property",
                WellKnownNePropertyNames.ID_NAME, "newTestNeName2"));

        neProperties = helper.getProperties(context, new NEIdItem(2));
        assertThat(neProperties, allOf(
                hasEntry("Some", "Property"),
                hasEntry(WellKnownNePropertyNames.ID_NAME, "newTestNeName2")));

        final INE ne = helper.getSingleNE(context, new NEIdItem(2));
        assertThat(ne.getIdName(), is("newTestNeName2"));

    }

    @Test
    public void updateProperties_flat_ip() throws Exception {

        Map<String, String> neProperties = helper.getProperties(context, new NEIdItem(2));
        assertThat(neProperties, not(hasEntry("Some", "Property")));
        assertThat(neProperties, hasEntry(WellKnownNePropertyNames.USES_FLAT_IP, "false"));

        helper.updateProperties(context, new NEIdItem(2), ImmutableMap.of(
                "Some", "Property",
                WellKnownNePropertyNames.USES_FLAT_IP, "true"));

        neProperties = helper.getProperties(context, new NEIdItem(2));
        assertThat(neProperties, allOf(
                hasEntry("Some", "Property"),
                hasEntry(WellKnownNePropertyNames.USES_FLAT_IP, "true")));

        final Optional<NeUserPreferencesData> ne = neRepository.getNeUserPreferencesRepository().query(2);
        assertThat(ne.isPresent(), is(true));
        assertThat(ne.get().usesFlatIp(),is(true));
    }

    @Test
    public void getNEListWithCapability() throws BcbException {
        // Get by capability
        INEMarkable filter = NEItem.markableNE(null);

        NEReply reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL, NeCapability.ADMIN_STATE_NO_CHANGE);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");

        filter = NEItem.markableNE(null);
        filter.setCapabilities(NeCapabilities.of(NeCapability.ALARM_SUPPRESSION));
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");
        verifyEntity(reply.getData()[1], 2, 11, 23, "testNeName2", "realNeName2");
    }

    @Test
    public void getNEList_all() throws BcbException {

        NEReply reply;

        reply = helper.getNEList(context, null, null, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        assertThat(reply.endOfFile(), is(true));
        assertThat(reply.getLastReadId(), is(nullValue()));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");
        verifyEntity(reply.getData()[1], 2, 11, 23, "testNeName2", "realNeName2");

        // limited

        reply = helper.getNEList(context, null, null, 1); // limited to the 1st of 2 records

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.endOfFile(), is(false));
        assertThat(reply.getLastReadId(), is(new NEIdItem(1)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");

        // start after

        reply = helper.getNEList(context, new NEIdItem(1), null, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 2, 11, 23, "testNeName2", "realNeName2");
    }

    @Test
    public void getNEList_filteredByActualActivationState() throws BcbException, RepositoryException {

        INEMarkable filter;
        NEReply reply;

        // connected & initializing = activating

        changeActualActivationState(1, ActualActivationState.CONNECTED);
        changeActualActivationState(2, ActualActivationState.INITIALIZING);

        filter = NEItem.markableNE(null);
        filter.setCommunicationState(CommunicationState.CONNECTED);
        filter.setInitState(InitState.NOT_INITIALIZED);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");

        filter = NEItem.markableNE(null);
        filter.setCommunicationState(CommunicationState.CONNECTED);
        filter.setInitState(InitState.INITIALIZING);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 2, 11, 23, "testNeName2", "realNeName2");

        filter = NEItem.markableNE(null);
        filter.setCommunicationState(CommunicationState.CONNECTED);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");
        verifyEntity(reply.getData()[1], 2, 11, 23, "testNeName2", "realNeName2");

        filter = NEItem.markableNE(null);
        filter.setActualActivationState(NeActivationState.ACTIVATING);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");
        verifyEntity(reply.getData()[1], 2, 11, 23, "testNeName2", "realNeName2");

        final INEMarkable filter2 = NEItem.markableNE(null);
        filter.setCommunicationState(CommunicationState.CONNECTED);
        filter.setInitState(InitState.INITIALIZING);
        filter2.setCommunicationState(CommunicationState.CONNECTED);
        filter2.setInitState(InitState.NOT_INITIALIZED);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter, filter2 }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");
        verifyEntity(reply.getData()[1], 2, 11, 23, "testNeName2", "realNeName2");

        changeActualActivationState(1, ActualActivationState.INITIALIZED);
        changeActualActivationState(2, ActualActivationState.INITIALIZED);

        filter = NEItem.markableNE(null);
        filter.setCommunicationState(CommunicationState.CONNECTED);
        filter.setInitState(InitState.INITIALIZED);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");
        verifyEntity(reply.getData()[1], 2, 11, 23, "testNeName2", "realNeName2");

        changeActualActivationState(1, ActualActivationState.DISCONNECTED);

        filter = NEItem.markableNE(null);
        filter.setCommunicationState(CommunicationState.DISCONNECTED);
        filter.setInitState(InitState.NOT_INITIALIZED);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");

        filter = NEItem.markableNE(null);
        filter.setActualActivationState(NeActivationState.ACTIVE);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 2, 11, 23, "testNeName2", "realNeName2");

        filter = NEItem.markableNE(null);
        filter.setActualActivationState(NeActivationState.INACTIVE);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");
    }

    @Ignore // takes too long, can be reenabled to validateNewName that stack overflows do not happen
    @Test
    public void getNEList_aLotOfFilters() throws BcbException {

        final int size = 2000;
        final INEMarkable[] filter = new INEMarkable[size];
        for (int i = 0; i < size; ++i) {
            final INEMarkable markable = NEItem.markableNE(null);
            markable.setId(i);
            markable.setIdName("testNeName2");
            filter[i] = markable;
        }

        final NEReply reply = helper.getNEList(context, null, filter, ALL);
        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 2, 11, 23, "testNeName2", "realNeName2");
    }

    @Test
    public void getNEList_filtered() throws BcbException {

        INEMarkable filter;
        NEReply reply;

        // Get by ID

        filter = NEItem.markableNE(null);
        filter.setId(2);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 2, 11, 23, "testNeName2", "realNeName2");

        // Get by proxy type

        filter = NEItem.markableNE(null);
        filter.setNeProxyType("proxy-type-other");
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 2, 11, 23, "testNeName2", "realNeName2");

        // Get by channel ID

        filter = NEItem.markableNE(null);
        filter.setAssociatedEmId(11);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 2, 11, 23, "testNeName2", "realNeName2");

        // Get by system ID

        filter = NEItem.markableNE(null);
        filter.setAssociatedSystemContainerId(23);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");
        verifyEntity(reply.getData()[1], 2, 11, 23, "testNeName2", "realNeName2");

        // Get by ID Name

        filter = NEItem.markableNE(null);
        filter.setIdName("testNeName2");
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 2, 11, 23, "testNeName2", "realNeName2");

        // Get by TID

        filter = NEItem.markableNE(null);
        filter.setNeighbourhoodId("targetIdentifier");
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");

        // Get by real name

        filter = NEItem.markableNE(null);
        filter.setRealNeName("realNeName2");
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 2, 11, 23, "testNeName2", "realNeName2");

        // Get by activation required

        filter = NEItem.markableNE(null);
        filter.setActivation(EnableSwitch.ENABLED);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");

        // Get by capability

        filter = NEItem.markableNE(null);
        filter.setCapabilities(NeCapabilities.of(NeCapability.ADMIN_STATE_NO_CHANGE));
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");

        filter = NEItem.markableNE(null);
        filter.setCapabilities(NeCapabilities.of(NeCapability.ALARM_SUPPRESSION));
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");
        verifyEntity(reply.getData()[1], 2, 11, 23, "testNeName2", "realNeName2");

        // Get by NeFamily

        filter = NEItem.markableNE(null);
        filter.setNeFamilyEnum(NeFamily.HI_T7300);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");

        // Get by NeType

        filter = NEItem.markableNE(null);
        filter.setNeTypeEnum(com.ossnms.bicnet.bcb.model.elementMgmt.NeType.ONN);
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 1, 10, 23, "testNeName", "realNeName");

        // Get by Global NE ID

        filter = NEItem.markableNE(null);
        filter.setGlobalId("globalId2");
        reply = helper.getNEList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        verifyEntity(reply.getData()[0], 2, 11, 23, "testNeName2", "realNeName2");
    }

    @Test
    public void getNEIdList_all() throws BcbException {

        NEIdReply reply;

        reply = helper.getNEIdList(context, null, null, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        assertThat(reply.endOfFile(), is(true));
        assertThat(reply.getLastReadId(), is(nullValue()));

        assertThat(reply.getData()[0].getId(), is(1));
        assertThat(reply.getData()[1].getId(), is(2));

        // limited

        reply = helper.getNEIdList(context, null, null, 1);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.endOfFile(), is(false));
        assertThat(reply.getLastReadId(), is(new NEIdItem(1)));

        assertThat(reply.getData()[0].getId(), is(1));

        // start after

        reply = helper.getNEIdList(context, new NEIdItem(1), null, 1);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));

        assertThat(reply.getData()[0].getId(), is(2));
    }

    @Test
    public void getNEIdList_filtered() throws BcbException {

        INEMarkable filter;
        NEIdReply reply;

        // Get by ID

        filter = NEItem.markableNE(null);
        filter.setId(2);
        reply = helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.getData()[0].getId(), is(2));

        // Get by proxy type

        filter = NEItem.markableNE(null);
        filter.setNeProxyType("proxy-type-other");
        reply = helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.getData()[0].getId(), is(2));

        // Get by channel ID

        filter = NEItem.markableNE(null);
        filter.setAssociatedEmId(11);
        reply = helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.getData()[0].getId(), is(2));

        // Get by system ID

        filter = NEItem.markableNE(null);
        filter.setAssociatedSystemContainerId(23);
        reply = helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        assertThat(reply.getData()[0].getId(), is(1));
        assertThat(reply.getData()[1].getId(), is(2));

        // Get by ID Name

        filter = NEItem.markableNE(null);
        filter.setIdName("testNeName2");
        reply = helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.getData()[0].getId(), is(2));

        // Get by TID

        filter = NEItem.markableNE(null);
        filter.setNeighbourhoodId("targetIdentifier");
        reply = helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.getData()[0].getId(), is(1));

        // Get by real name

        filter = NEItem.markableNE(null);
        filter.setRealNeName("realNeName2");
        reply = helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.getData()[0].getId(), is(2));

        // Get by activation required

        filter = NEItem.markableNE(null);
        filter.setActivation(EnableSwitch.ENABLED);
        reply = helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.getData()[0].getId(), is(1));

        // Get by capability

        filter = NEItem.markableNE(null);
        filter.setCapabilities(NeCapabilities.of(NeCapability.ADMIN_STATE_NO_CHANGE));
        reply = helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.getData()[0].getId(), is(1));

        filter = NEItem.markableNE(null);
        filter.setCapabilities(NeCapabilities.of(NeCapability.ALARM_SUPPRESSION));
        reply = helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        assertThat(reply.getData()[0].getId(), is(1));
        assertThat(reply.getData()[1].getId(), is(2));

        // Get by Core ID

        filter = NEItem.markableNE(null);
        filter.setCoreId("coreId2");
        reply = helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.getData()[0].getId(), is(2));
    }

    @Test
    @DataSet("NeHelperIT.empty.xml")
    public void getNEList_empty() throws BcbException {

        final NEReply reply = helper.getNEList(context, null, null, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(0)));
    }

    @Test
    @DataSet("NeHelperIT.empty.xml")
    public void getNEIdList_empty() throws BcbException {

        final NEIdReply reply = helper.getNEIdList(context, null, null, ALL);

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getData(), is(arrayWithSize(0)));
    }

    @Test(expected=BcbException.class)
    @DataSet("NeHelperIT.empty.xml")
    public void getNEIdList_filteredByCommAndInitState_unsupported() throws BcbException {

        INEMarkable filter;

        filter = NEItem.markableNE(null);
        filter.setCommunicationState(CommunicationState.CONNECTED);
        filter.setInitState(InitState.NOT_INITIALIZED);

        helper.getNEIdList(context, null, new INEMarkable[] { filter }, ALL);
    }

    @Test
    public void createThenDeleteNE() throws BcbException, RepositoryException {
        final INE ne = new NEItem();
        ne.setNeProxyType(NE_TYPE);
        ne.setAssociatedEmId(CHANNEL_ID);
        ne.setIdName("neIdName");
        ne.setReconnectInterval(43);
        ne.setRealNeName("realName");

        final INE newNe = helper.createNE(null, ne);

        assertThat(newNe.getId(), is(greaterThan(0)));
        assertThat(newNe.getRealNeName(), is("realName"));
        assertThat(newNe.getReconnectInterval(), is(43));
        assertThat(newNe.getIdName(), is("neIdName"));
        assertThat(newNe.getNeProxyType(), is(NE_TYPE));
        assertThat(newNe.getAssociatedEmId(), is(CHANNEL_ID));

        final INE singleNE = helper.getSingleNE(context, newNe.getNEId());
        assertThat(singleNE, is(newNe));

        helper.deleteNE(context, newNe.getNEId());

        assertThat(helper.getSingleNE(context, newNe.getNEId()), is(nullValue()));
    }

    @Test(expected = BcbException.class)
    public void tryCreateNeWithSameNameOfSystem() throws Exception {
        final INE ne = new NEItem();
        ne.setNeProxyType(NE_TYPE);
        ne.setAssociatedEmId(CHANNEL_ID);
        ne.setIdName("system_1");
        ne.setReconnectInterval(43);
        ne.setRealNeName("realName");

        helper.createNE(null, ne);
    }

    @Test(expected = BcbException.class)
    public void tryUpdateNeWithSameNameOfSystem() throws Exception {

        Map<String, String> neProperties = helper.getProperties(context, new NEIdItem(2));
        assertThat(neProperties, not(hasEntry("Some", "Property")));
        assertThat(neProperties, hasEntry(WellKnownNePropertyNames.ID_NAME, "testNeName2"));

        helper.updateProperties(context, new NEIdItem(2), ImmutableMap.of(
                "Some", "Property",
                WellKnownNePropertyNames.ID_NAME, "system_1"));
    }

    private Property[] transform(@Nonnull Map<String, String> properties) {
        return properties.entrySet().stream()
                .map(entry -> new Property(entry.getKey(), entry.getValue()))
                .toArray(Property[]::new);
    }
}
