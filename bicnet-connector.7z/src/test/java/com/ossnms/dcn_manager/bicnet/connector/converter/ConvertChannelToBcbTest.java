package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.i18n.Message;
import org.junit.Before;
import org.junit.Test;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertChannelToBcb.convert;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class ConvertChannelToBcbTest {

    private static final String ICON_ID = "iconId";
    private static final int MEDIATOR_ID = 2;
    private static final int CHANNEL_ID = 1;
    private ChannelType type;

    @Before
    public void setUp() {
        type = MockFactory.mockEmType();
        when(type.getDefaultIcon()).thenReturn(ICON_ID);
    }

    @Test
    public void testBasicInfo() {
        final IEM iem = convert(type, new ChannelEntity(
            new ChannelInfoBuilder().setType("channelType").setActivationRequired(true).build(CHANNEL_ID, 1, MEDIATOR_ID),
            new ChannelConnectionBuilder().setActivation(ActualActivationState.INACTIVE).build(CHANNEL_ID, 1),
            new ChannelUserPreferencesBuilder().setName("channelName").setReconnectInterval(321).build(CHANNEL_ID, 1)));

        assertThat(iem.getAssociatedMediatorId(), is(MEDIATOR_ID));
        assertThat(iem.getId(), is(CHANNEL_ID));
        assertThat(iem.getActivation(), is(EnableSwitch.ENABLED));
        assertThat(iem.getEmType(), is("channelType"));
        assertThat(iem.getIdName(), is("channelName"));
        assertThat(iem.getReconnectInterval(), is(321));
        assertThat(iem.getDisplayState(), is(Message.INACTIVE.toString()));
        assertThat(iem.getIconIdId(), is(ICON_ID));
    }

}
