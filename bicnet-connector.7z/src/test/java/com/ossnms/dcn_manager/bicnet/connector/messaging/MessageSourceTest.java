package com.ossnms.dcn_manager.bicnet.connector.messaging;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import com.ossnms.dcn_manager.bicnet.connector.messaging.MessageSourceImpl;

import rx.Subscription;
import rx.functions.Action1;

public class MessageSourceTest {

    private MessageSourceImpl<Object> source;

    @Before
    public void setUp() {
        source = new MessageSourceImpl<Object>();
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void testPushMessage() {

        final Object notif = new Object();
        final Action1 action = mock(Action1.class);

        source.observe()
            .subscribe(action);

        source.push(notif);

        final ArgumentCaptor<Object> notifCaptor = ArgumentCaptor.forClass(Object.class);
        verify(action).call(notifCaptor.capture());
        assertThat(notifCaptor.getValue(), is(notif));
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void testUnsubscribe() {

        final Object notif = new Object();
        final Action1 action = mock(Action1.class);

        final Subscription subscription = source.observe()
            .subscribe(action);

        source.push(notif);

        subscription.unsubscribe();

        source.push(notif);

        verify(action).call(any());
    }

}
