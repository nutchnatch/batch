package com.ossnms.dcn_manager.bicnet.connector.outbound.connection;

import com.ossnms.bicnet.bcb.facade.elementMgmt.INetworkElementFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.ISoftwareManagerFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.IWriteAccessStatePkgFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementIdItem;
import com.ossnms.bicnet.bcb.facade.platform.IConnectionManager;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElement;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.composables.outbound.exception.AccessControlException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertIntegerToBcbNe.convert;
import static org.mockito.Mockito.*;

public class NeAccessControlManagerImplTest {

    private static final int NE_ID = 1;
    private static final String WRITE_ACCESS_STATE_PKG = "elementMgmt.WriteAccessStatePkg";
    private static final String NETWORK_ELEMENT_FACADE = "elementMgmt.NetworkElement";
    private static final String SOFTWARE_MANAGER = "elementMgmt.SoftwareManager";

    private IConnectionManager connectionManager;
    private BicnetCallContext context;
    private ISessionContext sessionContext;

    private IWriteAccessStatePkgFacade statePkgFacade;
    private ISoftwareManagerFacade softwareManagerFacade;
    private INetworkElementFacade networkElementFacade;
    private INetworkElement networkElement;

    private NeAccessControlManagerImpl accessControlManagerImpl;

    private INE bcbNe;

    @Before
    public void setup() throws UnsupportedOperationException, BcbException {
        connectionManager = mock(IConnectionManager.class);
        sessionContext = mock(ISessionContext.class);
        context = mock(BicnetCallContext.class);

        statePkgFacade = mock(IWriteAccessStatePkgFacade.class);
        softwareManagerFacade = mock(ISoftwareManagerFacade.class);
        networkElementFacade = mock(INetworkElementFacade.class);
        networkElement = mock(INetworkElement.class);

        accessControlManagerImpl = new NeAccessControlManagerImpl(connectionManager);

        bcbNe = convert(NE_ID);

        when(context.getSessionContext()).thenReturn(sessionContext);

        when(connectionManager.getFacadeStrict(sessionContext, WRITE_ACCESS_STATE_PKG, bcbNe.getNEId())).thenReturn(
                statePkgFacade);

        when(connectionManager.getFacadeStrict(sessionContext, NETWORK_ELEMENT_FACADE, bcbNe.getNEId())).thenReturn(
                networkElementFacade);

        when(connectionManager.getFacadeStrict(sessionContext, SOFTWARE_MANAGER, bcbNe)).thenReturn(softwareManagerFacade);

        when(networkElementFacade.getSingleNetworkElement(sessionContext, new NetworkElementIdItem(bcbNe.getId())))
                .thenReturn(networkElement);
    }

    @Test
    public void testRequestWriteAccess() throws AccessControlException, BcbException {
        accessControlManagerImpl.requestWriteAccess(context, NE_ID);

        verify(statePkgFacade, Mockito.times(1)).requestWriteAccess(sessionContext, bcbNe.neId());
    }

    @Test(expected = AccessControlException.class)
    public void testRequestWriteAccessError() throws AccessControlException, BcbException {
        doThrow(new BcbException()).when(statePkgFacade).requestWriteAccess(sessionContext, bcbNe.neId());

        accessControlManagerImpl.requestWriteAccess(context, NE_ID);
    }

    @Test
    public void testReleaseWriteAccess() throws AccessControlException, BcbException {
        accessControlManagerImpl.releaseWriteAccess(context, NE_ID);

        verify(statePkgFacade, Mockito.times(1)).releaseWriteAccess(sessionContext, bcbNe.neId());
    }

    @Test(expected = AccessControlException.class)
    public void testReleaseWriteAccessError() throws AccessControlException, BcbException {
        doThrow(new BcbException()).when(statePkgFacade).releaseWriteAccess(sessionContext, bcbNe.neId());

        accessControlManagerImpl.releaseWriteAccess(context, NE_ID);
    }

    @Test
    public void testEnforceWriteAccess() throws AccessControlException, BcbException {
        accessControlManagerImpl.enforceWriteAccess(context, NE_ID);

        verify(statePkgFacade, Mockito.times(1)).enforceWriteAccess(sessionContext, bcbNe.neId());
    }

    @Test(expected = AccessControlException.class)
    public void testEnforceWriteAccessError() throws AccessControlException, BcbException {
        doThrow(new BcbException()).when(statePkgFacade).enforceWriteAccess(sessionContext, bcbNe.neId());

        accessControlManagerImpl.enforceWriteAccess(context, NE_ID);
    }

    @Test
    public void testToActiveStateMode() throws AccessControlException, BcbException {
        accessControlManagerImpl.toActiveStateMode(context, NE_ID);

        verify(softwareManagerFacade, Mockito.times(1)).setToActive(sessionContext, bcbNe.neId());
    }

    @Test(expected = AccessControlException.class)
    public void testToActiveStateModeError() throws AccessControlException, BcbException {
        doThrow(new BcbException()).when(softwareManagerFacade).setToActive(sessionContext, bcbNe.neId());

        accessControlManagerImpl.toActiveStateMode(context, NE_ID);
    }

    @Test
    public void testToOperationalMode() throws AccessControlException, BcbException {
        accessControlManagerImpl.toOperationalMode(context, NE_ID);

        verify(networkElement, Mockito.times(1)).setEventForwarding(EnableSwitch.ENABLED);
    }

    @Test(expected=AccessControlException.class)
    public void testToOperationalModeError() throws AccessControlException, BcbException {
        doThrow(new BcbException()).when(networkElementFacade).modifyNetworkElement(
                Mockito.any(ISessionContext.class), Mockito.any(INetworkElementMarkable.class));
        
        accessControlManagerImpl.toOperationalMode(context, NE_ID);        
    }

    @Test
    public void testToMaitenanceMode() throws AccessControlException, BcbException {
        accessControlManagerImpl.toMaitenanceMode(context, NE_ID);

        verify(networkElement, Mockito.times(1)).setEventForwarding(EnableSwitch.DISABLED);
    }

    @Test(expected = AccessControlException.class)
    public void testToMaitenanceModeError() throws AccessControlException, BcbException {
        doThrow(new BcbException()).when(networkElementFacade).modifyNetworkElement(
                Mockito.any(ISessionContext.class), Mockito.any(INetworkElementMarkable.class));

        accessControlManagerImpl.toMaitenanceMode(context, NE_ID);
    }
}
