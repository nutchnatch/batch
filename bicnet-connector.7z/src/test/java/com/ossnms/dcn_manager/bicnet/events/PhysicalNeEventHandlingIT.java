package com.ossnms.dcn_manager.bicnet.events;

import com.codahale.metrics.MetricRegistry;
import com.google.common.collect.ImmutableMap;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.ossnms.bicnet.bcb.facade.elementMgmt.*;
import com.ossnms.bicnet.bcb.facade.platform.IMediationFacadeManager;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IMoFacet;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.elementMgmt.*;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.factory.Metrics;
import com.ossnms.dcn_manager.bicnet.connector.messaging.DecoratedNotification;
import com.ossnms.dcn_manager.bicnet.connector.messaging.ne.NeEventSource;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.connection.NeConnectionManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.NeNotificationsManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.policies.NetworkElementConnectionSchedulerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.HelperItTestBase;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaChannelRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.composables.configuration.AppProperties;
import com.ossnms.dcn_manager.composables.metrics.NeInitializationMetrics;
import com.ossnms.dcn_manager.composables.outbound.NeInformationRetrieval;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.connector.storage.channel.InMemoryChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.connector.storage.ne.InMemoryNePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.*;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.periodic.PeriodicEvent;
import com.ossnms.dcn_manager.core.outbound.Alarms;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManagerStage;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.policies.impl.NetworkElementInteractionManagerImpl;
import com.ossnms.dcn_manager.core.policies.impl.NetworkElementInteractionManagerMediationStage;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.events.ne.NeDispatcher;
import com.ossnms.dcn_manager.events.ne.NeInitializationRetriesEventHandler;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.unitils.dbunit.annotation.DataSet;
import org.unitils.inject.util.InjectionUtils;
import org.unitils.inject.util.PropertyAccess;
import rx.observers.TestSubscriber;
import rx.subjects.PublishSubject;
import rx.subjects.SerializedSubject;

import java.util.Collections;
import java.util.Date;
import java.util.Observable;
import java.util.Optional;
import java.util.concurrent.RejectedExecutionException;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.*;

@DataSet
public class PhysicalNeEventHandlingIT extends HelperItTestBase {

    private static final int NE_ID = 1;
    private static final int CHANNEL_ID = 10;
    private static final int MEDIATOR_INSTANCE_ID = 3000;

    @Mock private IBiCNetMessageDispatcher messageDispatcher;
    private NePhysicalConnectionRepository neInstanceRepository;
    private NeConnectionRepository neConnectionRepository;
    @InjectMocks private JpaNetworkElementRepositoryBean neRepository;
    @InjectMocks private NeNotificationsManagerImpl notifications;
    @InjectMocks private JpaSystemRepositoryBean systemRepository;
    @InjectMocks private JpaChannelRepositoryBean channelRepository;

    @Mock private InMemoryChannelPhysicalConnectionRepository channelInstanceRepository;

    @Mock private DomainRepository domainRepository;

    @Mock private StaticConfigurationSingleton configuration;
    @Mock private BicnetCallContext context;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private SecurityManager securityManager;
    @Mock private NeInformationRetrieval neInfoRetrieval;
    @Mock private SettingsRepository settings;
    @Mock private Alarms alarms;
    @Mock private AppProperties appProperties;
    private TunableObservableExecutorImpl executor;

    @Mock private Metrics metrics;
    @Mock private IGctMgrFacade gctMgrFacade;
    @Mock private IMediationFacadeManager mediationFacadeManager;
    @Mock private INetworkElementProxyFacade neFacade;
    @Mock private IElementManagerFacade elementManagerFacade;
    @Mock private INetworkElementProxy neProxy;
    @Mock private ICommunicationStatePkgFacade proxyFacade;

    @Mock private IInitStatePkgFacade initFacade;
    private ChannelPhysicalConnectionData channelPhysicalConnectionData;
    private NePhysicalConnectionData nePhysicalConnectionData;
    private SerializedSubject<DecoratedNotification, DecoratedNotification> decoratedNotificationPublisher;
    private NeDispatcher<BicnetCallContext> neDispatcher; // keep this reference around during the test.
    private NetworkElementInteractionManager activationManager;
    private NeConnectionManagerImpl neConnectionManager;

    @Override @Before
    public void setUp() throws Exception {
        super.setUp();

        channelRepository.initialize();
        channelRepository.start();

        neRepository.initialize();
        neRepository.start();

        channelInstanceRepository = new InMemoryChannelPhysicalConnectionRepository();
        neInstanceRepository = new InMemoryNePhysicalConnectionRepository();

        executor = new TunableObservableExecutorImpl();

        final NeType neType = MockFactory.mockNeType();
        when(neType.getDefaultIcon()).thenReturn("default-icon");
        when(neType.getName()).thenReturn("proxy-type");
        when(neType.getProtocol()).thenReturn("SNMP");
        final Types<NeType> neTypes = Types.from(ImmutableMap.of("proxy-type", neType));
        when(configuration.getNeTypes()).thenReturn(neTypes);

        when(domainRepository.queryAllForNE(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryNaturalDomainsForNE(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryTransitiveDomainsForNE(anyInt())).thenReturn(Collections.emptyList());

        neConnectionRepository = neRepository.getNeConnectionRepository();
        neConnectionRepository.tryUpdate(
                neConnectionRepository.query(NE_ID)
                        .map(NeConnectionMutationDescriptor::new)
                        .map(mutation -> mutation.setActivationState(ActualActivationState.INITIALIZED))
                        .get());

        channelPhysicalConnectionData = channelInstanceRepository.insert(
                new ChannelConnectionInitialData()
                        .setActive(true)
                        .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE),
                CHANNEL_ID, MEDIATOR_INSTANCE_ID
        );

        nePhysicalConnectionData = neInstanceRepository.insert(
                new NePhysicalConnectionInitialData()
                        .setActive(true)
                        .setActivationState(ActualActivationState.INITIALIZED)
                        .setActivationMode(ActualActivationMode.STANDARD),
                NE_ID, channelPhysicalConnectionData.getId());

        when(neInfoRetrieval.updateNeDataFromMediator(anyInt())).then(invocation ->
                neRepository.query(NE_ID).get()
        );

        when(mediationFacadeManager.getFacade(any(ISessionContext.class), eq("elementMgmt.NetworkElementProxy"),
                isA(IMediatorId.class), isA(IEMId.class))).thenReturn(neFacade);
        when(mediationFacadeManager.getFacade(any(ISessionContext.class), eq("elementMgmt.ElementManager"),
                isA(IMediatorId.class), isA(IEMId.class))).thenReturn(elementManagerFacade);
        when(mediationFacadeManager.getFacade(any(ISessionContext.class), eq("elementMgmt.CommunicationStatePkg"),
                isA(IMediatorId.class), isA(IEMId.class))).thenReturn(proxyFacade);
        when(mediationFacadeManager.getFacade(any(ISessionContext.class), eq("elementMgmt.InitStatePkg"),
                isA(IMediatorId.class), isA(IEMId.class))).thenReturn(initFacade);

        when(elementManagerFacade.activateNetworkElementProxy(any(ISessionContext.class),
                isA(IElementManagerId.class), isA(INE.class), isA(Property[].class))).thenReturn(neProxy);

        final NeEventSource neEventSource = new NeEventSource();

        neConnectionManager = new NeConnectionManagerImpl(context, configuration, gctMgrFacade, mediationFacadeManager,
                neRepository, neInstanceRepository, channelInstanceRepository, loggerManager, neEventSource);

        activationManager = new NetworkElementConnectionSchedulerImpl(executor, new ThreadFactoryBuilder().build(),
                neConnectionManager, metrics);

        final NetworkElementManagers neManagers = new NetworkElementManagers(neRepository, neInstanceRepository, activationManager, notifications, neEventSource);
        final ChannelManagers channelManagers = new ChannelManagers(channelRepository, channelInstanceRepository, null, null, null);
        final DomainManagers domainManagers = new DomainManagers(domainRepository, null);

        InjectionUtils.injectIntoByType(neRepository, NeEntityRepository.class, notifications, PropertyAccess.FIELD);
        InjectionUtils.injectIntoByType(neInstanceRepository, NePhysicalConnectionRepository.class, notifications, PropertyAccess.FIELD);

        decoratedNotificationPublisher = PublishSubject.<DecoratedNotification>create().toSerialized();

        when(metrics.getMetricsRegistry()).thenReturn(mock(MetricRegistry.class));

        neDispatcher = new NeDispatcher<>(context, configuration, loggerManager, neManagers, channelManagers,
               neInfoRetrieval, domainManagers, settings, systemRepository, alarms, appProperties, neConnectionManager,
               new NeInitializationMetrics(metrics.getMetricsRegistry()));

        neEventSource.subscribe(decoratedNotificationPublisher.asObservable());
        neDispatcher.initialize(neEventSource.observe());
    }

    @Test
    public void testNeRestart() throws RepositoryException, BcbException {

        // sanity check: we start on an INITIALIZED NE on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZED));

        // (have the mediation report connecting when it is asked to connect and initializing when asked to initialize)
        doAnswer(invocation -> {
                decoratedNotificationPublisher.onNext(buildConnectionStateChange(CommunicationState.CONNECTING));
                return null;
            })
            .when(proxyFacade).connect(any(ISessionContext.class), isA(INetworkElementProxyId.class));
        doAnswer(invocation -> {
                decoratedNotificationPublisher.onNext(buildConnectionStateChange(InitState.INITIALIZING));
                return null;
            })
            .when(initFacade)
            .initialize(any(ISessionContext.class), isA(INetworkElementProxyId.class), isA(InitMode.class), isA(InitScope.class));

        // now request a reconnection. connections should shutdown and startup automatically.
        decoratedNotificationPublisher.onNext(
            buildNotification(new NePropertiesChanged(new Date(), NE_ID, new Property[]{new Property(WellKnownNePropertyNames.RESTART_NE, "RESTART")}))
        );

        // at this point both the physical and the logical instance should be CONNECTING on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.CONNECTING));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.CONNECTING));

        verify(proxyFacade).connect(any(ISessionContext.class), eq(new NetworkElementProxyIdItem(NE_ID)));

        // tell it that the instance is connected...
        decoratedNotificationPublisher.onNext(
            buildConnectionStateChange(CommunicationState.CONNECTED)
        );

        // verify that it is now INITIALIZING on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZING));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZING));

        verify(initFacade).initialize(any(ISessionContext.class), eq(new NetworkElementProxyIdItem(NE_ID)), eq(InitMode.INIT_FULL), eq(InitScope.INIT_ALL));

        // tell it that the instance has initialized...
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(InitState.INITIALIZED)
        );

        // verify that it is now INITIALIZED on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZED));
    }

    @Test
    public void testSyncLost() throws RepositoryException, BcbException {

        // sanity check: we start on an INITIALIZED NE on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZED));

        // now report synchronization lost. the connection should reinitialize automatically.
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(InitState.NOT_SYNCHRONIZED)
        );

        // at this point both the physical and the logical instance should be INITIALIZING on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZING));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZING));

        verify(initFacade).initialize(any(ISessionContext.class), eq(new NetworkElementProxyIdItem(NE_ID)), eq(InitMode.INIT_FULL), eq(InitScope.INIT_ALL));

        // tell it that the instance has initialized...
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(InitState.INITIALIZED)
        );

        // verify that it is now INITIALIZED on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZED));
    }

    @Test
    public void testSyncLostWithChangedCounters() throws RepositoryException, BcbException {

        // sanity check: we start on an INITIALIZED NE on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZED));

        
        // now report synchronization lost with changed counters. the connection should reinitialize automatically in delta init mode.
        final INeConfigurationCounterPkg counterPkg = NeConfigurationCounterPkgItem.markableNeConfigurationCounterPkg();
        counterPkg.setAllCategoryCounterHash(10);
        counterPkg.setAlarmsCategoryCounterHash(0);
        final INetworkElementProxyMarkable proxyMarkable = NetworkElementProxyItem.markableNetworkElementProxy(
                new IMoFacet[]{ counterPkg });
        proxyMarkable.setNeId(NE_ID);
        proxyMarkable.setInitState(InitState.NOT_SYNCHRONIZED);

        decoratedNotificationPublisher.onNext(
                buildNotification(new AttributeValueChange(new Date(), proxyMarkable))
        );

        // the counters must have been updated.
        final NeSynchronizationData syncCounters = neRepository.getNeSynchronizationRepository().query(NE_ID).get();
        assertThat(syncCounters.getAll().get(), is(10L));
        assertThat(syncCounters.getAlarms().get(), is(0L));
        assertThat(syncCounters.getPacket().get(), is(30L));
        
        
        // at this point both the physical and the logical instance should be INITIALIZING on CONNECT_RECOVER mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.CONNECT_RECOVER));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZING));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZING));

        verify(initFacade).initialize(any(ISessionContext.class), eq(new NetworkElementProxyIdItem(NE_ID)), eq(InitMode.INIT_DELTA), eq(InitScope.INIT_ALL));

        // tell it that the instance has initialized...
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(InitState.INITIALIZED)
        );

        // verify that it is now INITIALIZED on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZED));
    }


    @Test
    public void testEarlyNeActivationFailure() throws Exception {
        // we want to test a scenario where we're unable to do anything with CM

        // modify the starting state to DISCONNECTED.
        final Optional<NePhysicalConnectionData> disconnectedPhysicalConnection =
            neInstanceRepository.tryUpdate(
                neInstanceRepository.query(NE_ID)
                        .map(NePhysicalConnectionMutationDescriptor::new)
                        .map(mutation -> mutation.setActivationState(ActualActivationState.DISCONNECTED))
                        .get());
        neConnectionRepository.tryUpdate(
            neConnectionRepository.query(NE_ID)
                    .map(NeConnectionMutationDescriptor::new)
                    .map(mutation -> mutation.setActivationState(ActualActivationState.DISCONNECTED))
                    .get());

        // make believe that CM is f*cked up...
        when(mediationFacadeManager.getFacade(any(ISessionContext.class), anyString(), any(IMediatorId.class), any(IEMId.class)))
                .thenThrow(new NullPointerException());

        // now try to activate
        final Optional<NePhysicalConnectionMutationDescriptor> activationMutation =
            new NePhysicalConnectionBehavior(disconnectedPhysicalConnection.get(), notifications)
                .startUp(activationManager, MEDIATOR_INSTANCE_ID);
        assertThat(activationMutation, is(present()));
        neInstanceRepository.tryUpdate(activationMutation.get());

        // both instances must have been set to FAILED
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.FAILED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.FAILED));
    }

    @Test
    public void testInitializationRetry_afterExplicitFailure() throws Exception {

        // modify the starting state to INITIALIZING.
        neInstanceRepository.tryUpdate(
                neInstanceRepository.query(NE_ID)
                        .map(NePhysicalConnectionMutationDescriptor::new)
                        .map(mutation -> mutation.setActivationState(ActualActivationState.INITIALIZING))
                        .get());
        neConnectionRepository.tryUpdate(
                neConnectionRepository.query(NE_ID)
                        .map(NeConnectionMutationDescriptor::new)
                        .map(mutation -> mutation.setActivationState(ActualActivationState.INITIALIZING))
                        .get());

        // now report some initialization failure.
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(InitState.FAILED)
        );

        // both instances must have been set to FAILED on INIT_RECOVER mode
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.INIT_RECOVER));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.FAILED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.FAILED));

        // make believe that there is no waiting time (not really a supported scenario but we're not going to stop the test for this)
        when(settings.getSettings()).thenReturn(
                GlobalSettings.build().setNeRetries(1).setRetryInterval(0).toGlobalSettings(1, 0));

        // the periodic checker fires up, it should try to reactivate
        new NeInitializationRetriesEventHandler<>(context,
                new NetworkElementManagers(neRepository, neInstanceRepository, activationManager, notifications, null),
                new ChannelManagers(channelRepository, channelInstanceRepository, null, null, null),
                settings)
            .call(new PeriodicEvent() {});

        // both instances must have been set to CONNECTING on STANDARD mode
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.CONNECTING));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getRetryCounter).get(), is(1));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.CONNECTING));
    }

    @Test
    public void testNeConnectionLost() throws RepositoryException, BcbException {

        // sanity check: we start on an INITIALIZED NE on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZED));

        // now report a connection failure.
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(CommunicationState.FAILED)
        );

        // at this point both the physical and the logical instance should be FAILED on CONNECT_RECOVER mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.CONNECT_RECOVER));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.FAILED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.FAILED));

        // (report an initialization in progress the mediation is called to initialize)
        doAnswer(invocation -> {
                decoratedNotificationPublisher.onNext(buildConnectionStateChange(InitState.INITIALIZING));
                return null;
            })
            .when(initFacade)
                .initialize(any(ISessionContext.class), eq(new NetworkElementProxyIdItem(NE_ID)), eq(InitMode.INIT_DELTA), eq(InitScope.INIT_ALL));

        // now report a reconnection...
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(CommunicationState.CONNECTING)
        );
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(CommunicationState.CONNECTED)
        );

        // verify that it is now INITIALIZING on CONNECT_RECOVER mode after requesting a DELTA INIT.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.CONNECT_RECOVER));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZING));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZING));

        verify(initFacade).initialize(any(ISessionContext.class), eq(new NetworkElementProxyIdItem(NE_ID)), eq(InitMode.INIT_DELTA), eq(InitScope.INIT_ALL));

        // tell it that the instance has initialized...
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(InitState.INITIALIZED)
        );

        // verify that it is now INITIALIZED on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZED));
    }

    @Test
    public void testMvmSwitchbackProcedure() throws RepositoryException, BcbException {

        // sanity check: we start on an INITIALIZED NE on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZED));

        // now report a spontaneous disconnection on mediation.
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(CommunicationState.DISCONNECTING, InitState.SHUTTING_DOWN)
        );

        // at this point both the physical and the logical instance should be FAILED on CONNECT_RECOVER mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.CONNECT_RECOVER));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.FAILED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.FAILED));

        // complete the disconnection.
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(CommunicationState.DISCONNECTED, InitState.NOT_SYNCHRONIZED)
        );

        // at this point both the physical and the logical instance should still be FAILED on CONNECT_RECOVER mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.CONNECT_RECOVER));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.FAILED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.FAILED));

        // now the mediation has started to reconnect.
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(CommunicationState.CONNECTING)
        );

        // at this point both the physical and the logical instance should be CONNECTING on CONNECT_RECOVER mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.CONNECT_RECOVER));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.CONNECTING));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.CONNECTING));

        // finally the connection succeeded.
        decoratedNotificationPublisher.onNext(
                buildConnectionStateChange(CommunicationState.CONNECTED)
        );

        // verify that it is now INITIALIZING on CONNECT_RECOVER mode after requesting a DELTA INIT.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.CONNECT_RECOVER));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZING));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZING));

        verify(initFacade).initialize(any(ISessionContext.class), eq(new NetworkElementProxyIdItem(NE_ID)), eq(InitMode.INIT_DELTA), eq(InitScope.INIT_ALL));
    }

    @Test
    public void testPhysicalNeSynchronizationCountersChanged() throws Exception {

        // now report new counter values.
        final INeConfigurationCounterPkg counterPkg = NeConfigurationCounterPkgItem.markableNeConfigurationCounterPkg();
        counterPkg.setAllCategoryCounterHash(987);
        counterPkg.setAlarmsCategoryCounterHash(654);
        counterPkg.setPacketCategoryCounterHash(321);
        final INetworkElementProxyMarkable proxyMarkable = NetworkElementProxyItem.markableNetworkElementProxy(
                new IMoFacet[]{ counterPkg });
        proxyMarkable.setNeId(NE_ID);
        decoratedNotificationPublisher.onNext(
                buildNotification(new AttributeValueChange(new Date(), proxyMarkable))
        );

        // the counters must have been updated.
        final NeSynchronizationData syncCounters = neRepository.getNeSynchronizationRepository().query(NE_ID).get();
        assertThat(syncCounters.getAlarms().get(), is(654L));
        assertThat(syncCounters.getAll().get(), is(987L));
        assertThat(syncCounters.getPacket().get(), is(321L));
    }

    @Test
    public void testPhysicalNeSynchronizationCountersChanged_uponInitialization() throws Exception {

        // catch NE Initialized events.
        final TestSubscriber<NeEvent> notificationsSubscriber = new TestSubscriber<>();
        notifications.observe().subscribe(notificationsSubscriber);

        // modify the starting state to INITIALIZING.
        neInstanceRepository.tryUpdate(
                neInstanceRepository.query(NE_ID)
                        .map(NePhysicalConnectionMutationDescriptor::new)
                        .map(mutation -> mutation.setActivationState(ActualActivationState.INITIALIZING))
                        .get());
        neConnectionRepository.tryUpdate(
                neConnectionRepository.query(NE_ID)
                        .map(NeConnectionMutationDescriptor::new)
                        .map(mutation -> mutation.setActivationState(ActualActivationState.INITIALIZING))
                        .get());

        // now report an initialization complete with new counter values.
        final INeConfigurationCounterPkg counterPkg = NeConfigurationCounterPkgItem.markableNeConfigurationCounterPkg();
        counterPkg.setAllCategoryCounterHash(987);
        counterPkg.setAlarmsCategoryCounterHash(654);
        counterPkg.setPacketCategoryCounterHash(321);
        final INetworkElementProxyMarkable proxyMarkable = NetworkElementProxyItem.markableNetworkElementProxy(
                new IMoFacet[]{ counterPkg });
        proxyMarkable.setNeId(NE_ID);
        proxyMarkable.setInitState(InitState.INITIALIZED);
        decoratedNotificationPublisher.onNext(
                buildNotification(new AttributeValueChange(new Date(), proxyMarkable))
        );

        // the counters must have been updated.
        final NeSynchronizationData syncCounters = neRepository.getNeSynchronizationRepository().query(NE_ID).get();
        assertThat(syncCounters.getAlarms().get(), is(654L));
        assertThat(syncCounters.getAll().get(), is(987L));
        assertThat(syncCounters.getPacket().get(), is(321L));

        // verify that it is now INITIALIZED on STANDARD mode.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.INITIALIZED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.INITIALIZED));

        // verify that the Initialized event contained differences.
        notificationsSubscriber.assertNoErrors();
        final NeInitializedEvent desiredInitializedEvent =
            new NeInitializedEvent(NE_ID,
                new NeSynchronizationBuilder()
                        .setAll(Optional.of(987L)).setAlarms(Optional.of(654L)).setPacket(Optional.of(321L)).build(NE_ID, 0));
        assertThat(notificationsSubscriber.getOnNextEvents(), hasItem(desiredInitializedEvent));
    }

    @Test
    public void testShutdownOnFailedNewithFailedReconnectAttempts() throws RepositoryException, BcbException {
        
        // This test depicts a scenario where load on the system causes deactivate NE operator requests to be held back by "Scaled Startup".
        
        // Using reduced stage activation manager, so that inner fallback executor is not reachable by last stage ( system stage) without really deep modifications.
        
        NetworkElementInteractionManagerMediationStage mediationStage = new NetworkElementInteractionManagerMediationStage(
                1, executor, (pred) -> null);
        
        NetworkElementInteractionManagerImpl reducedStageActivationManager = new NetworkElementInteractionManagerImpl(
                1,
                new NetworkElementInteractionManagerStage[] { mediationStage },
                neConnectionManager);

        // Start by modifying the starting state to FAILED.
        final Optional<NePhysicalConnectionData> failedPhysicalConnection =
            neInstanceRepository.tryUpdate(
                neInstanceRepository.query(NE_ID)
                        .map(NePhysicalConnectionMutationDescriptor::new)
                        .map(mutation -> mutation.setActivationState(ActualActivationState.FAILED))
                        .get());
        neConnectionRepository.tryUpdate(
            neConnectionRepository.query(NE_ID)
                    .map(NeConnectionMutationDescriptor::new)
                    .map(mutation -> mutation.setActivationState(ActualActivationState.FAILED))
                    .get());

        // Have the job scheduler really busy so that the deactivate interaction with mediation is held back. Using the tunable executor to prevent immediate execution.
        executor.setAllowExec(false);
        
        // Issue a deactivate NE, enter shutting down but do not got trough the call to mediation because executor is not allowing execution.
        final Optional<NePhysicalConnectionMutationDescriptor> deactivationMutation =
            new NePhysicalConnectionBehavior(failedPhysicalConnection.get(), notifications)
                .shutdown(reducedStageActivationManager, MEDIATOR_INSTANCE_ID);
        assertThat(deactivationMutation, is(present()));
        neInstanceRepository.tryUpdate(deactivationMutation.get());

        // Physical connection must have been set to SHUTDOWN since deactivation job to mediation didn't get the chance to run yet, but logical connection is expected to remain FAILED.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.SHUTDOWN));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.FAILED));


        // Before deactivate request is made  to mediation, have it start a failed reconnected attempt: fire a connecting notification followed by a failed to connect notification
        decoratedNotificationPublisher.onNext( buildConnectionStateChange(CommunicationState.CONNECTING));
        decoratedNotificationPublisher.onNext( buildConnectionStateChange(CommunicationState.FAILED));

        // Check state is FAILED as a result of mediation notifications.
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.FAILED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.FAILED));
        
        // Finally, simulate the awareness of executor availability to  issue the deactivate call to mediation. Getting disconnecting notification followed by disconnected notification from mediation.
        mediationStage.getRetainedWorkForExecution(j -> true).ifPresent(Runnable::run);
        
        // Verify that the NE is disconnected. Both instances must have been set to DISCONNECTED
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationMode).get(), is(ActualActivationMode.STANDARD));
        assertThat(neInstanceRepository.query(NE_ID).map(NePhysicalConnectionData::getActualActivationState).get(), is(ActualActivationState.DISCONNECTED));
        assertThat(neConnectionRepository.query(NE_ID).map(NeConnectionData::getActivationState).get(), is(ActualActivationState.DISCONNECTED));
        
    }
    
    
    private DecoratedNotification buildNotification(Notification bcbNotification) {
        return new DecoratedNotification(bcbNotification)
                    .setOriginatingPhysicalNe(nePhysicalConnectionData)
                    .setOriginatingPhysicalChannel(channelPhysicalConnectionData);
    }

    private DecoratedNotification buildConnectionStateChange(InitState newState) {
        final INetworkElementProxyMarkable proxyMarkable = NetworkElementProxyItem.markableNetworkElementProxy(null);
        proxyMarkable.setInitState(newState);
        proxyMarkable.setNeId(NE_ID);
        return buildNotification(new AttributeValueChange(new Date(), proxyMarkable));
    }

    private DecoratedNotification buildConnectionStateChange(CommunicationState commState) {
        final INetworkElementProxyMarkable proxyMarkable = NetworkElementProxyItem.markableNetworkElementProxy(null);
        proxyMarkable.setCommunicationState(commState);
        proxyMarkable.setNeId(NE_ID);
        return buildNotification(new AttributeValueChange(new Date(), proxyMarkable));
    }

    private DecoratedNotification buildConnectionStateChange(CommunicationState commState, InitState initState) {
        final INetworkElementProxyMarkable proxyMarkable = NetworkElementProxyItem.markableNetworkElementProxy(null);
        proxyMarkable.setCommunicationState(commState);
        proxyMarkable.setInitState(initState);
        proxyMarkable.setNeId(NE_ID);
        return buildNotification(new AttributeValueChange(new Date(), proxyMarkable));
    }
    
    
    /**
     *
     * Observable executer that enables allows/prevents job execution on demand. 
     *
     */
    public class TunableObservableExecutorImpl extends Observable implements ObservableExecutor {

        private boolean allowExec = true;

        public boolean isAllowExec() {
            return allowExec;
        }

        public void setAllowExec(boolean allowExec) {
            this.allowExec = allowExec;
            notifyTaskCompletion();
        }

        /**
         * {@inheritDoc}
         *
         * <p>When the command given is complete, a registered observer will be notified of
         * potentially available capacity.
         *
         * The notification will occur from within the thread that executed the command.</p>
         *
         */
        @Override
        public void execute(@Nonnull Runnable command) {
            
            if(allowExec) {
                command.run();
                notifyTaskCompletion();
            }
            else {
                throw new RejectedExecutionException();
            }
        }

        public void notifyTaskCompletion() {
            setChanged();
            notifyObservers();
        }
    }
    
}
