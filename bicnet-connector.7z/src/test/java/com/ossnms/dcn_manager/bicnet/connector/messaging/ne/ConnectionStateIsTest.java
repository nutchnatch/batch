package com.ossnms.dcn_manager.bicnet.connector.messaging.ne;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementProxyItem;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxyMarkable;
import com.ossnms.dcn_manager.bicnet.connector.messaging.ne.ConnectionStateIs;

public class ConnectionStateIsTest {

    @Test
    public void equality() {
        assertTrue(new ConnectionStateIs(CommunicationState.CONNECTED).call(buildMarkable(CommunicationState.CONNECTED)));
        assertTrue(new ConnectionStateIs(CommunicationState.DISCONNECTED).call(buildMarkable(CommunicationState.DISCONNECTED)));
        assertTrue(new ConnectionStateIs(CommunicationState.DISCONNECTING).call(buildMarkable(CommunicationState.DISCONNECTING)));
        assertTrue(new ConnectionStateIs(CommunicationState.CONNECTING).call(buildMarkable(CommunicationState.CONNECTING)));
        assertTrue(new ConnectionStateIs(CommunicationState.FAILED).call(buildMarkable(CommunicationState.FAILED)));
    }

    @Test
    public void nullState_notEquals() {
        assertFalse(new ConnectionStateIs(CommunicationState.CONNECTED).call(buildMarkable(null)));
        assertFalse(new ConnectionStateIs(CommunicationState.DISCONNECTED).call(buildMarkable(null)));
        assertFalse(new ConnectionStateIs(CommunicationState.DISCONNECTING).call(buildMarkable(null)));
        assertFalse(new ConnectionStateIs(CommunicationState.CONNECTING).call(buildMarkable(null)));
        assertFalse(new ConnectionStateIs(CommunicationState.FAILED).call(buildMarkable(null)));
    }

    @Test
    public void unmarked_notEquals() {
        assertFalse(new ConnectionStateIs(CommunicationState.CONNECTED).call(buildUnmarked(CommunicationState.CONNECTED)));
        assertFalse(new ConnectionStateIs(CommunicationState.DISCONNECTED).call(buildUnmarked(CommunicationState.DISCONNECTED)));
        assertFalse(new ConnectionStateIs(CommunicationState.DISCONNECTING).call(buildUnmarked(CommunicationState.DISCONNECTING)));
        assertFalse(new ConnectionStateIs(CommunicationState.CONNECTING).call(buildUnmarked(CommunicationState.CONNECTING)));
        assertFalse(new ConnectionStateIs(CommunicationState.FAILED).call(buildUnmarked(CommunicationState.FAILED)));
    }

    private INetworkElementProxyMarkable buildMarkable(CommunicationState state) {
        final INetworkElementProxyMarkable nem = new NetworkElementProxyItem().toMarkableNetworkElementProxy();
        nem.setCommunicationState(state);
        return nem;
    }

    private INetworkElementProxyMarkable buildUnmarked(CommunicationState state) {
        final NetworkElementProxyItem nep = new NetworkElementProxyItem();
        nep.setCommunicationState(state);
        return nep.toMarkableNetworkElementProxy();
    }
}
