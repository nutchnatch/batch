package com.ossnms.dcn_manager.bicnet.connector.converter;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertIntegerToBcbEm;

public class ConvertIntegerToBcbEmTest {

    @Test
    public void testConverterToBcbEmItem() {
        IEM bcbNe = ConvertIntegerToBcbEm.convert(1);

        assertThat(bcbNe.getId(), is(1));
        assertThat(bcbNe.getEMId(), is((IEMId) new EMIdItem(1)));
    }
    
    @Test
    public void testConverterToBcbEmIdItem() {
        IEMId bcbNe = ConvertIntegerToBcbEm.convert(1);
        assertThat(bcbNe.getId(), is(1));
    }
}
