package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import org.hamcrest.Matchers;
import org.junit.Test;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;

public class InMemoryNeSyncStateRepositoryTest {

    @Test
    public void addAndQuery() {
        final ScsSynchronizationState state1 = new ScsSynchronizationState(1, ScsSyncState.SYNCHRONIZED);
        final ScsSynchronizationState state2 = new ScsSynchronizationState(2, ScsSyncState.OUT_OF_SYNC, "ops");
        final InMemoryNeSyncStateRepository repo = new InMemoryNeSyncStateRepository();

        repo.tryUpdate(state1);
        repo.tryUpdate(state2);

        final Iterable<ScsSynchronizationState> all = repo.queryAll();
        assertThat(all, is(Matchers.iterableWithSize(2)));
        assertThat(all, containsInAnyOrder(state1, state2));

        assertThat(repo.query(1), hasValue(state1));
        assertThat(repo.query(2), hasValue(state2));
    }

    @Test
    public void addAndUpdate() {
        final ScsSynchronizationState state1 = new ScsSynchronizationState(1, ScsSyncState.SYNCHRONIZED);
        final ScsSynchronizationState state2 = new ScsSynchronizationState(1, ScsSyncState.OUT_OF_SYNC, "ops");
        final InMemoryNeSyncStateRepository repo = new InMemoryNeSyncStateRepository();

        repo.tryUpdate(state1);
        assertThat(repo.query(1), hasValue(state1));

        repo.tryUpdate(state2);
        assertThat(repo.query(1), hasValue(state2));
    }

}
