package com.ossnms.dcn_manager.bicnet.connector.outbound;

import com.ossnms.bicnet.bcb.facade.faultMgmt.IFaultMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.common.TimeOrigin;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarm;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmLogRecordId;
import com.ossnms.bicnet.bcb.model.faultMgmt.IFaultManagerId;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class AlarmsImplTest {

    private static final int CHANNEL_ID = 2;

    private static final int NE_ID = 1;

    private IFaultMgrFacade faultManager;
    private NeEntityRepository neRepository;
    private NeInfoRepository infoRepository;
    private NeUserPreferencesRepository preferencesRepository;
    private ChannelEntityRepository channelRepository;
    private ChannelUserPreferencesRepository channelUserPreferencesRepository;
    private ISessionContext sessionContext;
    private AlarmsImpl alarms;

    @Before
    public void setUp() {
        faultManager = mock(IFaultMgrFacade.class);
        neRepository = mock(NeEntityRepository.class);
        infoRepository = mock(NeInfoRepository.class);
        preferencesRepository = mock(NeUserPreferencesRepository.class);
        channelRepository = mock(ChannelEntityRepository.class);
        channelUserPreferencesRepository = mock(ChannelUserPreferencesRepository.class);
        sessionContext = mock(ISessionContext.class);

        when(neRepository.getNeInfoRepository()).thenReturn(infoRepository);
        when(neRepository.getNeUserPreferencesRepository()).thenReturn(preferencesRepository);

        when(channelRepository.getChannelUserPreferencesRepository()).thenReturn(channelUserPreferencesRepository);

        alarms = new AlarmsImpl(faultManager, sessionContext, neRepository, channelRepository);
    }

    @Test
    public void testRaise() throws Exception {
        final IAlarmLogRecordId newLogRecordId = mock(IAlarmLogRecordId.class);
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, 1)
            ));
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeInfoBuilder().setCommsLostAlarmRaised(false).setProxyType("proxy").build(NE_ID, CHANNEL_ID, 1)
            ));
        when(channelUserPreferencesRepository.query(CHANNEL_ID)).thenReturn(Optional.of(
                new ChannelUserPreferencesBuilder().setName("channel name").build(CHANNEL_ID, 1)
            ));
        when(faultManager.raiseAlarm(any(ISessionContext.class), any(IFaultManagerId.class), any(IAlarm.class), any(TimeOrigin.class)))
            .thenReturn(newLogRecordId);

        final boolean result = alarms.raiseConnectionLost(NE_ID, Optional.of("ooops"));

        assertThat(result, is(true));

        verify(faultManager).raiseAlarm(eq(sessionContext), isA(IFaultManagerId.class), isA(IAlarm.class), eq(TimeOrigin.POSTDATED));
        verify(infoRepository).tryUpdate(isA(NeInfoMutationDescriptor.class));
    }

}
