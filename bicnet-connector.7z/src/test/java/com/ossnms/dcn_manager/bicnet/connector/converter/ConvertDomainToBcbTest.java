package com.ossnms.dcn_manager.bicnet.connector.converter;

import static org.hamcrest.Matchers.arrayContaining;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertDomainToBcb;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public class ConvertDomainToBcbTest {

    private DomainRepository domainRepository;

    @Before
    public void setUp() {
        domainRepository = mock(DomainRepository.class);
    }

    @Test
    public void testConvert() {
        final IAS ias = ConvertDomainToBcb.convert(new DomainInfoData(1, 1, "name", true), Collections.singletonList(20));
        assertThat(ias.getId(), is(1));
        assertThat(ias.getIdName(), is("name"));
        assertThat(ias.getDiscoveryPermited(), is(true));
        assertThat(ias.getNeList(), is(arrayContaining((INEId) new NEIdItem(20))));
    }

    @Test
    public void testApply() throws RepositoryException {
        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(Collections.singletonList(10));

        final IAS ias = new ConvertDomainToBcb(domainRepository).apply(new DomainInfoData(2, 1, "name2", false));
        assertThat(ias.getId(), is(2));
        assertThat(ias.getIdName(), is("name2"));
        assertThat(ias.getDiscoveryPermited(), is(false));
        assertThat(ias.getNeList(), is(arrayContaining((INEId) new NEIdItem(10))));
    }

}
