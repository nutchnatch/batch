package com.ossnms.dcn_manager.bicnet.connector.messaging.ne;

import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NeConfigurationCounterPkgItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementProxyIdItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementProxyItem;
import com.ossnms.bicnet.bcb.model.IMoFacet;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.INeConfigurationCounterPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.INeConfigurationCounterPkgMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxyMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;
import com.ossnms.bicnet.bcb.model.elementMgmt.NePropertiesChanged;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.connector.messaging.DecoratedNotification;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.NeOperationInfoChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.NePhysicalSynchronizationCountersChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.NePropertiesChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeTypeChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeRestartRequestEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeConnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeConnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializingEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeSynchronizationLostEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import rx.Observable;
import rx.observers.TestSubscriber;

import java.util.Collections;
import java.util.Date;
import java.util.Optional;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class NeEventSourceTest {

    private static final int NE_INSTANCE_ID = 3200;
    private static final int NE_ID = 32;
    private static final int CHANNEL_INSTANCE_ID = 2000;
    private static final int CHANNEL_ID = 2;

    private static final String NE_TYPE = "neType";
    private static final int VERSION = 0;

    @Mock private JpaNetworkElementRepositoryBean neRepository;
    @Mock private NeEntityRepository.NeInfoRepository neInfoRepository;
    @Mock private NeType type;
    @Mock private StaticConfiguration configuration;
    @Mock private Types<NeType> neTypes;
    private NeInfoData neInfoData;
    private BiMap<String, String> neIdControlMap;

    @InjectMocks
    private NeEventSource eventSource;

    @Before
    public void setUp() throws RepositoryException {
        neIdControlMap = ImmutableBiMap.of(WellKnownNePropertyNames.NEIGHBOURHOOD_ID, WellKnownNePropertyNames.TL1_ID);
        neInfoData = new NeInfoData.NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_ID, VERSION);

        when(configuration.getNeTypes()).thenReturn(neTypes);
        when(neTypes.get(anyString())).thenReturn(type);
        when(neRepository.getNeInfoRepository()).thenReturn(neInfoRepository);
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(neInfoData));
        when(type.getIdentificationControlMap()).thenReturn(neIdControlMap);
    }

    @Test
    public void events_inactiveStateNe_areDropped() throws Exception {

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(Observable.just(
            new DecoratedNotification(new NePropertiesChanged(new Date(), NE_ID, new Property[] { new Property("a", "b") }))
                .setOriginatingPhysicalNe(new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.DISCONNECTED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION))
        ));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.emptyList());
    }

    @Test
    public void events_noPhysicalNeInformation_areDropped() throws Exception {

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(Observable.just(
            new DecoratedNotification(new NePropertiesChanged(new Date(), NE_ID, new Property[] { new Property("a", "b") }))
        ));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.emptyList());
    }

    @Test
    public void events_noMarkable() throws Exception {

        final NeEventSource source = eventSource;

        source.subscribe(buildObservable());

        final TestSubscriber<NeEvent> subscriber = subscribe(source);
        subscriber.assertReceivedOnNext(Collections.<NeEvent>emptyList());
        subscriber.assertNoErrors();
    }

    @Test
    public void events_markableWithoutMarks() throws Exception {

        final NeEventSource source = eventSource;

        source.subscribe(buildObservable(NetworkElementProxyItem.markableNetworkElementProxy(null)));

        final TestSubscriber<NeEvent> subscriber = subscribe(source);
        subscriber.assertReceivedOnNext(Collections.<NeEvent>emptyList());
        subscriber.assertNoErrors();
    }

    @Test
    public void configurationCounters_noFacet() throws Exception {

        final NeEventSource source = eventSource;

        final INetworkElementProxyMarkable markable = NetworkElementProxyItem.markableNetworkElementProxy(null);
        markable.setNeId(NE_ID);
        source.subscribe(buildObservable(markable));

        final TestSubscriber<NeEvent> subscriber = subscribe(source);
        subscriber.assertReceivedOnNext(Collections.<NeEvent>emptyList());
        subscriber.assertNoErrors();
    }

    @Test
    public void configurationCounters_unmarkedFacet() throws Exception {

        final NeEventSource source = eventSource;

        source.subscribe(buildObservable(NeConfigurationCounterPkgItem.markableNeConfigurationCounterPkg()));

        final TestSubscriber<NeEvent> subscriber = subscribe(source);
        subscriber.assertReceivedOnNext(Collections.<NeEvent>emptyList());
        subscriber.assertNoErrors();
    }

    @Test
    public void configurationCounters_nullCounters() throws Exception {

        final INeConfigurationCounterPkgMarkable counterPkg = NeConfigurationCounterPkgItem.markableNeConfigurationCounterPkg();
        counterPkg.setAlarmsCategoryCounterHash(0);
        counterPkg.setAllCategoryCounterHash(0);
        counterPkg.setPacketCategoryCounterHash(0);

        final NeEventSource source = eventSource;
        source.subscribe(buildObservable(counterPkg));

        final TestSubscriber<NeEvent> subscriber = subscribe(source);
        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>emptyList());
    }

    @Test
    public void configurationCounters_allCounters() throws Exception {

        final INeConfigurationCounterPkgMarkable counterPkg = NeConfigurationCounterPkgItem.markableNeConfigurationCounterPkg();
        counterPkg.setAlarmsCategoryCounterHash(1);
        counterPkg.setAllCategoryCounterHash(2);
        counterPkg.setPacketCategoryCounterHash(3);

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(counterPkg));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new NePhysicalSynchronizationCountersChangedEvent(NE_INSTANCE_ID, NE_ID, Optional.of(2L), Optional.of(1L), Optional.of(3L))));
    }

    @Test
    public void configurationCounters_someCounters() throws Exception {

        final INeConfigurationCounterPkgMarkable counterPkg = NeConfigurationCounterPkgItem.markableNeConfigurationCounterPkg();
        counterPkg.setAlarmsCategoryCounterHash(1);
        counterPkg.setPacketCategoryCounterHash(0);

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(counterPkg));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new NePhysicalSynchronizationCountersChangedEvent(NE_INSTANCE_ID, NE_ID, Optional.empty(), Optional.of(1L), Optional.of(0L))));
    }

    @Test
    public void neInitialized() throws Exception {

        final INetworkElementProxyMarkable markable =
            NetworkElementProxyItem.markableNetworkElementProxy(null);

        markable.setNeId(NE_ID);
        markable.setInitState(InitState.INITIALIZED);

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(markable));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new PhysicalNeInitializedEvent(NE_INSTANCE_ID, NE_ID, true)));
    }

    @Test
    public void neInitializing() throws Exception {

        final INetworkElementProxyMarkable markable =
            NetworkElementProxyItem.markableNetworkElementProxy(null);

        markable.setNeId(NE_ID);
        markable.setInitState(InitState.INITIALIZING);

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(markable));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new PhysicalNeInitializingEvent(NE_INSTANCE_ID, NE_ID, true)));
    }

    @Test
    public void neConnected() throws Exception {

        final INetworkElementProxyMarkable markable =
            NetworkElementProxyItem.markableNetworkElementProxy(null);

        markable.setNeId(NE_ID);
        markable.setCommunicationState(CommunicationState.CONNECTED);

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(markable));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new PhysicalNeConnectedEvent(NE_INSTANCE_ID, NE_ID, true)));
    }

    @Test
    public void neConnecting() throws Exception {

        final INetworkElementProxyMarkable markable =
            NetworkElementProxyItem.markableNetworkElementProxy(null);

        markable.setNeId(NE_ID);
        markable.setCommunicationState(CommunicationState.CONNECTING);

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(markable));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new PhysicalNeConnectingEvent(NE_INSTANCE_ID, NE_ID, true)));
    }

    @Test
    public void neDisconnected() throws Exception {

        final INetworkElementProxyMarkable markable =
            NetworkElementProxyItem.markableNetworkElementProxy(null);

        markable.setNeId(NE_ID);
        markable.setCommunicationState(CommunicationState.DISCONNECTED);

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(markable));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new PhysicalNeDisconnectedEvent(NE_INSTANCE_ID, NE_ID, true)));
    }

    @Test
    public void neDisconnecting() throws Exception {

        final INetworkElementProxyMarkable markable =
            NetworkElementProxyItem.markableNetworkElementProxy(null);

        markable.setNeId(NE_ID);
        markable.setCommunicationState(CommunicationState.DISCONNECTING);

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(markable));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new PhysicalNeDisconnectingEvent(NE_INSTANCE_ID, NE_ID, true)));
    }

    @Test
    public void neFailed() throws Exception {

        final INetworkElementProxyMarkable markable =
            NetworkElementProxyItem.markableNetworkElementProxy(null);

        markable.setNeId(NE_ID);
        markable.setCommunicationState(CommunicationState.FAILED);
        markable.setCommunicationStateAdditionalInfo("barfed");

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(markable));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new PhysicalNeActivationFailedEvent(NE_INSTANCE_ID, NE_ID, true, "barfed")));
    }

    @Test
    public void neOutOfSync() throws Exception {

        final INeConfigurationCounterPkg counterPkg = NeConfigurationCounterPkgItem.markableNeConfigurationCounterPkg();
        counterPkg.setAllCategoryCounterHash(987);
        counterPkg.setAlarmsCategoryCounterHash(654);
        counterPkg.setPacketCategoryCounterHash(321);
        final INetworkElementProxyMarkable proxyMarkable = NetworkElementProxyItem.markableNetworkElementProxy(
                new IMoFacet[]{ counterPkg });
        proxyMarkable.setNeId(NE_ID);
        proxyMarkable.setInitState(InitState.NOT_SYNCHRONIZED);

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(proxyMarkable));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(ImmutableList.of(
                new PhysicalNeSynchronizationLostEvent(NE_INSTANCE_ID, NE_ID, true, new NeSynchronizationData.NeSynchronizationBuilder().setAll(Optional.of(987L)).setAlarms(Optional.of(654L)).setPacket(Optional.of(321L)).build(NE_ID, 0)),
                new NePhysicalSynchronizationCountersChangedEvent(NE_INSTANCE_ID, NE_ID, Optional.of(987L), Optional.of(654L), Optional.of(321L))));
    }

    @Test
    public void neTypeChanged() throws Exception {

        final INetworkElementProxyMarkable markable =
            NetworkElementProxyItem.markableNetworkElementProxy(null);

        markable.setNeId(NE_ID);
        markable.setType("new type");

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(markable));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new NeTypeChangedEvent(NE_ID, "new type")));
    }

    @Test
    public void neRestartRequest_correctValue() throws Exception {

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(Observable.just(
            new DecoratedNotification(new NePropertiesChanged(new Date(), NE_ID, new Property[] { new Property(WellKnownNePropertyNames.RESTART_NE, "RESTART") }))
                .setOriginatingPhysicalNe(new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION))
        ));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(ImmutableList.of(
                new NePropertiesChangedEvent(NE_ID, ImmutableMap.of(WellKnownNePropertyNames.RESTART_NE, "RESTART")),
                new PhysicalNeRestartRequestEvent(NE_ID, NE_INSTANCE_ID)));
    }

    @Test
    public void neRestartRequest_incorrectValue() throws Exception {

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(Observable.just(
                new DecoratedNotification(new NePropertiesChanged(new Date(), NE_ID, new Property[] { new Property(WellKnownNePropertyNames.RESTART_NE, "") }))
                        .setOriginatingPhysicalNe(new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION))
        ));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(ImmutableList.of(
                new NePropertiesChangedEvent(NE_ID, ImmutableMap.of(WellKnownNePropertyNames.RESTART_NE, ""))));
    }

    @Test
    public void nePropertiesChanged_activeInstance() throws Exception {

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(Observable.just(
            new DecoratedNotification(new NePropertiesChanged(new Date(), NE_ID, new Property[] { new Property("a", "b") }))
                .setOriginatingPhysicalNe(new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION))
            ));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new NePropertiesChangedEvent(NE_ID, ImmutableMap.of("a", "b"))));
    }

    @Test
    public void nePropertiesChanged_inactiveInstance() throws Exception {

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(Observable.just(
            new DecoratedNotification(new NePropertiesChanged(new Date(), NE_ID, new Property[] { new Property("a", "b") }))
                .setOriginatingPhysicalNe(new NePhysicalConnectionBuilder().setActive(false).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION))
            ));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>emptyList());
    }

    @Test
    public void configurationCounters_neInitialized_sameTime_generatesTwoEvents() throws Exception {

        final INeConfigurationCounterPkgMarkable counterPkg = NeConfigurationCounterPkgItem.markableNeConfigurationCounterPkg();
        counterPkg.setAlarmsCategoryCounterHash(1);
        counterPkg.setPacketCategoryCounterHash(0);

        final INetworkElementProxyMarkable markable =
            NetworkElementProxyItem.markableNetworkElementProxy(new IMoFacet[] { counterPkg });

        markable.setNeId(NE_ID);
        markable.setInitState(InitState.INITIALIZED);

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        source.subscribe(buildObservable(markable));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(ImmutableList.of(
            new PhysicalNeInitializedEvent(NE_INSTANCE_ID, NE_ID, true, new NeSynchronizationData.NeSynchronizationBuilder().setAlarms(Optional.of(1L)).setPacket(Optional.of(0L)).build(NE_ID, 0)),
            new NePhysicalSynchronizationCountersChangedEvent(NE_INSTANCE_ID, NE_ID, Optional.empty(), Optional.of(1L), Optional.of(0L))));
    }

    @Test
    public void neOperationInfoChanged() throws Exception {

        final INetworkElementMarkable markable = NetworkElementItem.markableNetworkElement(null);
        markable.setNeId(NE_ID);
        markable.setName("new name");

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        final AttributeValueChange avc = new AttributeValueChange();
        avc.setChangedObject(markable);

        source.subscribe(Observable.just(
            new DecoratedNotification(avc)
                .setOriginatingPhysicalNe(new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION))));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(ImmutableList.<NeEvent>of(
            new NeOperationInfoChangedEvent(NE_ID)));
    }

    @Test
    public void neDeleted_onActiveInstance() throws Exception {

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        final ObjectDeletion del = new ObjectDeletion(new Date(), new NetworkElementProxyIdItem(NE_ID));
        source.subscribe(Observable.just(
            new DecoratedNotification(del)
                .setOriginatingPhysicalNe(new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION))));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new PhysicalNeDisconnectedEvent(NE_INSTANCE_ID, NE_ID, true)));
    }

    @Test
    public void neDeleted_onInactiveInstance() throws Exception {

        final NeEventSource source = eventSource;
        final TestSubscriber<NeEvent> subscriber = subscribe(source);

        final ObjectDeletion del = new ObjectDeletion(new Date(), new NetworkElementProxyIdItem(NE_ID));
        source.subscribe(Observable.just(
            new DecoratedNotification(del)
                .setOriginatingPhysicalNe(new NePhysicalConnectionBuilder().setActive(false).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION))));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<NeEvent>singletonList(
            new PhysicalNeDisconnectedEvent(NE_INSTANCE_ID, NE_ID, false)));
    }

    private TestSubscriber<NeEvent> subscribe(NeEventSource source) {
        final Observable<NeEvent> observable = source.observe();
        final TestSubscriber<NeEvent> subscriber = new TestSubscriber<>();
        observable.subscribe(subscriber);
        return subscriber;
    }

    private Observable<DecoratedNotification> buildObservable(INeConfigurationCounterPkgMarkable facet) {
        final INetworkElementProxyMarkable markable =
            NetworkElementProxyItem.markableNetworkElementProxy(null != facet ? new IMoFacet[] { facet } : null);
        markable.setNeId(NE_ID);
        return buildObservable(markable);
    }

    private Observable<DecoratedNotification> buildObservable(INetworkElementProxyMarkable markable) {
        final AttributeValueChange avc = new AttributeValueChange();
        avc.setChangedObject(markable);
        return Observable.just(
            new DecoratedNotification(avc)
                .setOriginatingPhysicalNe(new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
    }

    private Observable<DecoratedNotification> buildObservable() {
        return Observable.from(new DecoratedNotification[] {
            new DecoratedNotification(new AttributeValueChange())
                .setOriginatingPhysicalNe(new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION))
        });
    }
}
