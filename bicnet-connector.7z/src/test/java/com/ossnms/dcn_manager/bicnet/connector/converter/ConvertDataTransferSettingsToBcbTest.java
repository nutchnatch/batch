package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeDataTransferSettingsItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeDataTransferSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDataTransferSettings;
import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Test;

import java.util.Map;
import java.util.Optional;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class ConvertDataTransferSettingsToBcbTest {

    @Test
    public void testFromGlobalSettings() {
        Map<String, String> settings = ImmutableMap.of(
                "SFTP_IP", "host",
                "SFTP_USER", "user_name",
                "SFTP_PASSWORD", "pass",
                "SFTP_ROOTPATH", "path"
        );

        INeDataTransferSettings data = ConvertDataTransferSettingsToBcb.from(settings,"type");

        asserts(data);
    }

    @Test
    public void testFromDataSettings() {
        NeDataTransferSettings neDataTransferSettings = new NeDataTransferSettings(
                Optional.of("path"),
                Optional.of("user_name"),
                Optional.of("pass"),
                Optional.of("host"),
                false
        );

        INeDataTransferSettings data = ConvertDataTransferSettingsToBcb.from(neDataTransferSettings,"type");

        asserts(data);
    }

    @Test
    public void testLoopbackToServerHost_empty() {
        INeDataTransferSettings data = new NeDataTransferSettingsItem();
        data.setIpAddress("");

        INeDataTransferSettings replaced = ConvertDataTransferSettingsToBcb.loopbackToServerHost(Optional.of(data), "server_host");

        assertThat(replaced.getIpAddress(), CoreMatchers.is("server_host"));
    }

    @Test
    public void testLoopbackToServerHost_null() {
        INeDataTransferSettings data = new NeDataTransferSettingsItem();
        data.setIpAddress(null);

        INeDataTransferSettings replaced = ConvertDataTransferSettingsToBcb.loopbackToServerHost(Optional.of(data), "server_host");

        assertThat(replaced.getIpAddress(), CoreMatchers.is("server_host"));
    }

    @Test
    public void testLoopbackToServerHost_localhost() {
        INeDataTransferSettings data = new NeDataTransferSettingsItem();
        data.setIpAddress("localhost");

        INeDataTransferSettings replaced = ConvertDataTransferSettingsToBcb.loopbackToServerHost(Optional.of(data), "server_host");

        assertThat(replaced.getIpAddress(), CoreMatchers.is("server_host"));
    }

    @Test
    public void testLoopbackToServerHost_loopback() {
        INeDataTransferSettings data = new NeDataTransferSettingsItem();
        data.setIpAddress("127.0.0.1");

        INeDataTransferSettings replaced = ConvertDataTransferSettingsToBcb.loopbackToServerHost(Optional.of(data), "server_host");

        assertThat(replaced.getIpAddress(), CoreMatchers.is("server_host"));
    }

    @Test
    public void testLoopbackToServerHost_no_changes() {
        INeDataTransferSettings data = new NeDataTransferSettingsItem();
        data.setIpAddress("host_from_ne");

        INeDataTransferSettings replaced = ConvertDataTransferSettingsToBcb.loopbackToServerHost(Optional.of(data), "server_host");

        assertThat(replaced.getIpAddress(), CoreMatchers.is("host_from_ne"));
    }

    @Test
    public void testLoopbackToServerHost_noData() {
        INeDataTransferSettings data = ConvertDataTransferSettingsToBcb.loopbackToServerHost(Optional.empty(), "server_host");

        assertNull(data);
    }

    private void asserts(INeDataTransferSettings data) {
        Assert.assertNotNull(data);

        assertThat(data.getIpAddress(), CoreMatchers.is("host"));
        assertThat(data.getUserName(), CoreMatchers.is("user_name"));
        assertThat(data.getPassword(), CoreMatchers.is("pass"));
        assertThat(data.getUploadPath(), CoreMatchers.is("path"));
        assertThat(data.getNeType(), CoreMatchers.is("type"));
        assertThat(data.getScpMode(), CoreMatchers.is(false));
    }
}