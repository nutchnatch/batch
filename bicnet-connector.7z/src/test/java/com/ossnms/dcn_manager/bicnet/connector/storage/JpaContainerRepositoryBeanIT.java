package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.google.common.collect.Iterables;
import com.ossnms.dcn_manager.connector.jpa.JpaUnitOfWorkContext;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.utils.Consumer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.unitils.dbunit.annotation.DataSet;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@DataSet
public class JpaContainerRepositoryBeanIT extends HelperItTestBase {

    private static final ContainerInfo PARENT = new ContainerInfo(23, 1, "testSystem");
    private static final ContainerInfo CHILD = new ContainerInfo(32, 1, Optional.of(23), "testSystemChild", Optional.of("Child"), Optional.of("userText"));
    public static final int NE_ID = 1;

    public static final int SYSTEM_ID = 2;

    @InjectMocks JpaContainerRepositoryBean repositoryBean;

    @Test
    public void queryAll() throws Exception {
        final Iterable<ContainerInfo> all = repositoryBean.queryAll();
        assertThat(Iterables.isEmpty(all), is(false));
    }

    @Test
    public void delete() throws Exception {
        repositoryBean.delete(new ContainerDeletionDescriptor(32));
        Optional<ContainerInfo> result = repositoryBean.query(32);
        assertThat(result.isPresent(), is(false));

        repositoryBean.delete(new ContainerDeletionDescriptor(23));
        result = repositoryBean.query(23);
        assertThat(result.isPresent(), is(false));
    }

    @Test
    public void queryById() throws Exception {
        Optional<ContainerInfo> result = repositoryBean.query(32);
        assertThat(result, hasValue(CHILD));

        result = repositoryBean.query(98766);
        assertThat(result, is(absent()));
    }

    @Test
    public void queryByName() throws Exception {
        Optional<ContainerInfo> result = repositoryBean.queryByName("testSystem");
        assertThat(result, hasValue(PARENT));

        result = repositoryBean.queryByName("blah");
        assertThat(result, is(absent()));
    }

    @Test
    public void update() throws Exception {
        @SuppressWarnings("unchecked")
        final
        Consumer<ContainerInfoMutationDescriptor> consumer = mock(Consumer.class);
        final ContainerInfoMutationDescriptor descriptor =
                new ContainerInfoMutationDescriptor(repositoryBean.query(32).get())
                        .setDescription(Optional.of("new description"))
                        .whenApplied(consumer);
        final Optional<ContainerInfo> updated = repositoryBean.tryUpdate(descriptor);

        assertThat(updated, is(present()));
        verify(consumer).accept(descriptor);

        assertThat(updated.get().getDescription(), hasValue("new description"));
        assertThat(repositoryBean.query(32).get().getDescription(), hasValue("new description"));
    }

    @Test
    public void update_unitOfWork() throws Exception {
        @SuppressWarnings("unchecked")
        final Consumer<ContainerInfoMutationDescriptor> consumer = mock(Consumer.class);
        final ContainerInfoMutationDescriptor descriptor =
                new ContainerInfoMutationDescriptor(repositoryBean.query(32).get())
                        .setDescription(Optional.of("new description"))
                        .setUserText(Optional.of("new userText"))
                        .whenApplied(consumer);

        final Optional<ContainerInfo> updated;
        try (JpaUnitOfWorkContext ctx = new JpaUnitOfWorkContext(repositoryBean.getTransaction())) {
            updated = repositoryBean.tryUpdate(ctx, descriptor);
        }

        assertThat(updated, is(present()));
        verify(consumer, never()).accept(descriptor);

        assertThat(updated.get().getDescription(), hasValue("new description"));
        assertThat(repositoryBean.query(32).get().getDescription(), hasValue("new description"));

        assertThat(updated.get().getUserText(), hasValue("new userText"));
        assertThat(repositoryBean.query(32).get().getUserText(), hasValue("new userText"));
    }

    @Test
    public void concurrentUpdate() throws Exception {

        final ContainerInfo target = repositoryBean.query(32).get();
        final ContainerInfoMutationDescriptor descriptor1 =
                new ContainerInfoMutationDescriptor(target)
                        .setDescription(Optional.of("new description"))
                        .setUserText(Optional.of("new userText"));
        final ContainerInfoMutationDescriptor descriptor2 =
                new ContainerInfoMutationDescriptor(target)
                        .setDescription(Optional.of("new description"))
                        .setUserText(Optional.of("new userText"));

        Optional<ContainerInfo> updated = repositoryBean.tryUpdate(descriptor1);
        assertThat(updated, is(present()));

        updated = repositoryBean.tryUpdate(descriptor2);
        assertThat(updated, is(absent()));
    }

    @Test(expected = RepositoryException.class)
    public void invalidUpdateData() throws Exception {

        final ContainerInfo target = repositoryBean.query(32).get();
        final ContainerInfoMutationDescriptor descriptor =
                new ContainerInfoMutationDescriptor(target)
                        .setParentId(987);

        repositoryBean.tryUpdate(descriptor);
    }

    @Test
    public void create() throws Exception {

        final ContainerInfo created = repositoryBean.create(
                new ContainerCreationDescriptor(23, "newContainer")
                        .setDescription(Optional.of("look@me"))
                        .setUserText(Optional.of("userText")));
        assertThat(created, is(new ContainerInfo(created.getId(), created.getVersion(), Optional.of(23), "newContainer", Optional.of("look@me"), Optional.of("userText"))));

        final Optional<ContainerInfo> found = repositoryBean.queryByName("newContainer");
        assertThat(found, hasValue(created));
    }

    @Test(expected = RepositoryException.class)
    public void createDuplicate() throws Exception {

        repositoryBean.create(new ContainerCreationDescriptor(PARENT.getName()));
    }

    @Test public void addAndRemoveSystemAssignment() throws Exception {
        final Optional<ContainerInfo> container = repositoryBean.query(60);
        assertTrue(container.isPresent());

        SystemAssignmentData assignmentData = new SystemAssignmentData(container.get(), SYSTEM_ID, AssignmentType.PRIMARY);
        repositoryBean.addSystemAssignment(assignmentData);

        assertTrue(repositoryBean.tryRemoveSystemAssignment(assignmentData));
    }

    @Test public void queryAllBySystem() throws Exception {
        final Iterable<SystemAssignmentData> assignments = repositoryBean.queryAllBySystem(61);
        assertFalse(Iterables.isEmpty(assignments));
    }

    @Test public void queryAllByNE() throws Exception {
        final Iterable<NeAssignmentData> assignments = repositoryBean.queryAllByNE(1);
        assertFalse(Iterables.isEmpty(assignments));
    }

    @Test public void queryAllNeIdByContainer() throws Exception {
        final Iterable<Integer> assignments = repositoryBean.queryAllNeIdByContainer(60);
        assertFalse(Iterables.isEmpty(assignments));
    }

    @Test public void queryAllSystemIdByContainer() throws Exception {
        final Iterable<Integer> assignments = repositoryBean.queryAllSystemIdByContainer(60);
        assertFalse(Iterables.isEmpty(assignments));
    }
}
