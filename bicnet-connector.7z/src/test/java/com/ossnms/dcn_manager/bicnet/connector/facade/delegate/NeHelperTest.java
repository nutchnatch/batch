package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.scs.ScsSiteConfiguration;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.messaging.ne.NeEventSource;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.connection.NeAccessControlManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.connection.NeConnectionManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.NeNotificationsManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.policies.NetworkElementConnectionSchedulerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.InMemoryNeSyncStateRepository;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.*;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySetters.NeRoutePropertyAdapter;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.core.jaxb.netype.RouteMapping;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.*;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.core.test.UnitOfWorkImplBaseStub;
import com.ossnms.dcn_manager.core.test.UowMutationAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import com.ossnms.dcn_manager.identification.ne.globalneid.GlobalNeId;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.unitils.inject.util.InjectionUtils;
import org.unitils.inject.util.PropertyAccess;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import static com.google.common.collect.Iterables.getOnlyElement;
import static com.google.common.collect.Lists.transform;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anySet;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class NeHelperTest {

    private static final int NE_ID = 1;
    private static final String NE_TYPE = "neType";
    private static final int CHANNEL_ID = 2;
    private static final int CONTAINER_ID = 64;
    private static final int VERSION = 0;
    private static final int NE_INSTANCE_ID = 1000;
    private static final int CHANNEL_INSTANCE_ID = 2000;
    private static final int MEDIATOR_INSTANCE_ID = 7600;

    @Mock private JpaNetworkElementRepositoryBean neRepository;
    @Mock private JpaContainerRepositoryBean containerRepository;
    @Mock private NeInfoRepository infoRepository;
    @Mock private NeOperationRepository operationRepository;
    @Mock private NeUserPreferencesRepository preferencesRepository;
    @Mock private NeGatewayRoutesRepository routesRepository;
    @Mock private NeSynchronizationRepository synchronizationRepository;
    @Mock private InMemoryNeSyncStateRepository syncStateRepository;
    @Mock private NeConnectionRepository connectionRepository;
    @Mock private DomainRepository domainRepository;
    @Mock private ChannelPhysicalConnectionRepository channelInstanceRepository;
    @Mock private ChannelEntityRepository channelRepository;
    @Mock private ChannelUserPreferencesRepository channelPreferencesRepository;
    @Mock private ChannelInfoRepository channelInfoRepository;
    @Mock private StaticConfiguration configuration;
    @Mock private NetworkElementConnectionSchedulerImpl activationManager;
    @Mock private NeNotificationsManagerImpl notifications;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private DomainNotifications domainNotifications;
    @Mock private NeConnectionManagerImpl connectionManager;
    @Mock private NeAccessControlManagerImpl accessControlManager;
    @Mock private NeEventSource neEventSource;
    @Mock private NePhysicalConnectionRepository neInstanceRepository;
    @Mock private ISystemControlEjbFacade scs;
    @Mock private ContainerNotifications containerNotifications;
    @Mock private SettingsRepository settingsRepository;
    @Mock private JpaSystemRepositoryBean systemRepository;

    @InjectMocks private NeHelper helper;

    @Mock private ISessionContext context;
    @Mock private Types<NeType> types;
    private NeType type;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws RepositoryException {
        type = MockFactory.mockNeType();

        final NetworkElementManagers neManagers = new NetworkElementManagers(neRepository,
                neInstanceRepository, activationManager, notifications, neEventSource);
        InjectionUtils.injectIntoByType(neManagers, NetworkElementManagers.class, helper, PropertyAccess.FIELD);

        when(type.getProtocol()).thenReturn(GlobalNeId.SNMP.name());
        when(type.getDefaultIcon()).thenReturn("iconId");
        when(type.getName()).thenReturn(NE_TYPE);
        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of(
                WellKnownNePropertyNames.RECONNECT_INTERVAL, "987",
                WellKnownNePropertyNames.USES_GNE, "true",
                "Stuff", "Extra"
            ));
        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.empty());

        when(type.getIdentificationControlMap()).thenReturn(ImmutableBiMap.of());
        when(type.getAdditionalTypeInfoControlMap()).thenReturn(ImmutableBiMap.of());
        
        when(configuration.getNeTypes()).thenReturn(types);
        when(systemRepository.queryByName(anyString())).thenReturn(Optional.empty());
        when(preferencesRepository.query(anyString())).thenReturn(Optional.empty());
        when(routesRepository.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(routesRepository.tryFindRouteKeys(anySet())).thenReturn(Collections.emptySet());

        when(containerRepository.queryByName(anyString())).thenReturn(Optional.of(new ContainerInfo(1,1,"c")));
        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().toGlobalSettings(1,1));

        when(neRepository.getNeInfoRepository()).thenReturn(infoRepository);
        when(neRepository.getNeUserPreferencesRepository()).thenReturn(preferencesRepository);
        when(neRepository.getNeOperationRepository()).thenReturn(operationRepository);
        when(neRepository.getNeGatewayRoutesRepository()).thenReturn(routesRepository);
        when(neRepository.getNeConnectionRepository()).thenReturn(connectionRepository);
        when(neRepository.getNeSyncStateRepository()).thenReturn(syncStateRepository);
        when(neRepository.getNeSynchronizationRepository()).thenReturn(synchronizationRepository);
        when(neRepository.create(any(NeCreateDescriptor.class))).then(new Answer<NeEntity>() {
            @Override
            public NeEntity answer(InvocationOnMock invocation) throws Throwable {
                final NeCreateDescriptor create = (NeCreateDescriptor) invocation.getArguments()[0];
                return new NeEntity(
                    new NeConnectionData(NE_ID, 1, create.getConnection()),
                    new NeOperationData(NE_ID,  1, create.getOperation()),
                    new NeInfoData(NE_ID, create.getChannelId(), 1, create.getInfo()),
                    new NeSynchronizationBuilder().build(NE_ID, 1),
                    new NeUserPreferencesData(NE_ID, 1, create.getPreferences()));
            }
        });

        when(containerRepository.queryAllByNE(NE_ID)).thenReturn(Collections.emptyList());

        when(neInstanceRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());

        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
        when(channelRepository.getChannelUserPreferencesRepository()).thenReturn(channelPreferencesRepository);

        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesData(NE_ID, 1, new NeUserPreferencesInitialData().setName("name"))));

        when(operationRepository.tryUpdate(isA(NeOperationMutationDescriptor.class))).then(new MutationAnswer<>());
    }

    private ChannelEntity buildChannel() {
        return new ChannelEntity(
            new ChannelInfoBuilder().setType("typeName").build(CHANNEL_ID, 1, 1),
            new ChannelConnectionBuilder().build(CHANNEL_ID, 1),
            new ChannelUserPreferencesBuilder().setName("name").setProperty("Custom", "Value").setReconnectInterval(345).build(CHANNEL_ID, 1));
    }

    private Attribute attribute(String name, RouteMapping mapping) {
        final Attribute attr = attribute(name);
        attr.setMapsTo(mapping);
        return attr;
    }

    private Attribute attribute(String name) {
        final Attribute attr = new Attribute();
        attr.setName(name);
        return attr;
    }

    @Test
    public void testGetFullNeList_connectedThroughGne_working() throws Exception {

        final ScsSynchronizationState syncState = new ScsSynchronizationState(NE_ID, ScsSyncState.SYNCHRONIZED, "info");

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, 1),
                new NeOperationBuilder().build(NE_ID, 1),
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_ID, 1),
                new NeSynchronizationBuilder().build(NE_ID, 1),
                new NeUserPreferencesBuilder().setName("name").setUserText(Optional.of("text")).setUsesGne(true).build(NE_ID, 1));

        when(types.get(anyString())).thenReturn(type);
        when(syncStateRepository.query(NE_ID)).thenReturn(Optional.of(syncState));
        when(neRepository.queryAll()).thenReturn(Collections.singleton(entity));
        when(domainRepository.queryAllForNE(NE_ID)).thenReturn(Collections.emptyList());
        when(routesRepository.queryRoutes(ImmutableSet.of(NE_ID))).thenReturn(ImmutableMap.of(NE_ID,
                Collections.singleton(
                new NeGatewayRouteBuilder().setKey("r1").setUsed(true).setPriority(1).setCost(1).build(NE_ID, 0))
        ));
        when(neInstanceRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());

        final Iterable<FullNeData> fullNeList = helper.getFullNeList(context);

        final FullNeData fullData = getOnlyElement(fullNeList);

        assertThat(fullData.getInfo().getUserText().get(), is("text"));
        assertThat(fullData.getInfo().getGuiActiveActualActivationState().get(), is(GuiActualActivationState.ACTIVE));
        assertThat(fullData.getNe().getConnectedVia(), is("r1 (" + Message.WORKING + ")"));
    }

    @Test
    public void testGetFullNeList_connectedThroughGne_protecting() throws Exception {

        final ScsSynchronizationState syncState = new ScsSynchronizationState(NE_ID, ScsSyncState.SYNCHRONIZED, "info");

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, 1),
                new NeOperationBuilder().build(NE_ID, 1),
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_ID, 1),
                new NeSynchronizationBuilder().build(NE_ID, 1),
                new NeUserPreferencesBuilder().setName("name").setUserText(Optional.of("text")).setUsesGne(true).build(NE_ID, 1));

        when(types.get(anyString())).thenReturn(type);
        when(syncStateRepository.query(NE_ID)).thenReturn(Optional.of(syncState));
        when(neRepository.queryAll()).thenReturn(Collections.singleton(entity));
        when(domainRepository.queryAllForNE(NE_ID)).thenReturn(Collections.emptyList());
        when(routesRepository.queryRoutes(ImmutableSet.of(NE_ID))).thenReturn(ImmutableMap.of(NE_ID,
                ImmutableList.of(new NeGatewayRouteBuilder().setKey("r1").setUsed(false).setPriority(1).setCost(1).build(NE_ID, 0),
                new NeGatewayRouteBuilder().setKey("r2").setUsed(true).setPriority(2).setCost(1).build(NE_ID, 0))
        ));
        when(neInstanceRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());

        final Iterable<FullNeData> fullNeList = helper.getFullNeList(context);

        final FullNeData fullData = getOnlyElement(fullNeList);

        assertThat(fullData.getInfo().getUserText().get(), is("text"));
        assertThat(fullData.getInfo().getGuiActiveActualActivationState().get(), is(GuiActualActivationState.ACTIVE));
        assertThat(fullData.getNe().getConnectedVia(), is("r2 (" + Message.PROTECTING + ")"));
    }

    @Test
    public void testGetFullNeList_connectedDirectly() throws Exception {

        final ScsSynchronizationState syncState = new ScsSynchronizationState(NE_ID, ScsSyncState.SYNCHRONIZED, "info");

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, 1),
                new NeOperationBuilder().build(NE_ID, 1),
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_ID, 1),
                new NeSynchronizationBuilder().build(NE_ID, 1),
                new NeUserPreferencesBuilder().setName("name").setUserText(Optional.of("text")).setUsesGne(false).build(NE_ID, 1));

        when(types.get(anyString())).thenReturn(type);
        when(syncStateRepository.query(NE_ID)).thenReturn(Optional.of(syncState));
        when(neRepository.queryAll()).thenReturn(Collections.singleton(entity));
        when(domainRepository.queryAllForNE(NE_ID)).thenReturn(Collections.emptyList());
        when(routesRepository.queryRoutes(ImmutableSet.of(NE_ID))).thenReturn(ImmutableMap.of());
        when(neInstanceRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());

        final Iterable<FullNeData> fullNeList = helper.getFullNeList(context);

        final FullNeData fullData = getOnlyElement(fullNeList);

        assertThat(fullData.getInfo().getUserText().get(), is("text"));
        assertThat(fullData.getInfo().getGuiActiveActualActivationState().get(), is(GuiActualActivationState.ACTIVE));
        assertThat(fullData.getNe().getConnectedVia(), is(Message.DIRECT_CONNECTION.toString()));
    }

    @Test
    public void testGetFullNeList_disconnected_noSyncState() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(NE_ID, 1),
                new NeOperationBuilder().build(NE_ID, 1),
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_ID, 1),
                new NeSynchronizationBuilder().build(NE_ID, 1),
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, 1));

        when(types.get(anyString())).thenReturn(type);
        when(syncStateRepository.query(NE_ID)).thenReturn(Optional.empty());
        when(neRepository.queryAll()).thenReturn(Collections.singleton(entity));
        when(domainRepository.queryAllForNE(NE_ID)).thenReturn(Collections.emptyList());
        when(routesRepository.queryRoutes(ImmutableSet.of(NE_ID))).thenReturn(ImmutableMap.of());
        when(neInstanceRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());

        final Iterable<FullNeData> fullNeList = helper.getFullNeList(context);

        final FullNeData fullData = getOnlyElement(fullNeList);

        assertThat(fullData.getInfo().getUserText(), is(Optional.empty()));
        assertThat(fullData.getSynchronizationState().getState(), is(ScsSyncState.OUT_OF_SYNC));
    }

    @Test(expected=BcbException.class)
    public void testGetFullNeList_neRepoError() throws Exception {

        when(neRepository.queryAll()).thenThrow(new RepositoryException());

        helper.getFullNeList(context);
    }

    @Test
    public void testGetProperties_includesStandbyConfiguration() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, 1),
                new NeOperationBuilder().build(NE_ID, 1),
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_ID, 1),
                new NeSynchronizationBuilder().build(NE_ID, 1),
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, 1));

        when(types.get(anyString())).thenReturn(type);
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(entity));

        when(scs.getSiteConfiguration(context)).thenReturn(ScsSiteConfiguration.PRIMARY);
        when(scs.isStandbyConfigured(context)).thenReturn(true);

        final Map<String, String> properties = helper.getProperties(context, new NEIdItem(NE_ID));

        assertThat(properties, hasEntry("SITE_ROLE", "primary"));
        assertThat(properties, hasEntry("STANDBY_CONFIGURED", "true"));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testUpdateProperties() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, 1),
                new NeOperationBuilder().build(NE_ID, 1),
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_ID, 1),
                new NeSynchronizationBuilder().build(NE_ID, 1),
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, 1));

        final NePhysicalConnectionData neInstance = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(neInstance));

        when(types.get(anyString())).thenReturn(type);
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(entity));
        when(neRepository.unitOfWork(any())).then(invocation -> new UnitOfWorkImplBaseStub(invocation.getArguments()[0]));
        when(preferencesRepository.tryUpdate(isA(UowContext.class), any(NeUserPreferencesMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(operationRepository.tryUpdate(isA(UowContext.class), isA(NeOperationMutationDescriptor.class))).then(new UowMutationAnswer<>());
        when(domainRepository.queryTransitiveDomainsForNE(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryNaturalDomainsForNE(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryAllForNE(anyInt())).thenReturn(Collections.emptyList());

        helper.updateProperties(context, new NEIdItem(NE_ID), ImmutableMap.of("Some", "Property"));

        verify(preferencesRepository).tryUpdate(isA(UowContext.class), any(NeUserPreferencesMutationDescriptor.class));
        verify(notifications).notifyChanges(any(NeUserPreferencesMutationDescriptor.class));
        verify(connectionManager).updateNeProperties(any(NeEntity.class), any(NePhysicalConnectionData.class), any(NeUserPreferencesMutationDescriptor.class), any(Map.class));
        verify(loggerManager).createCommandLog(any(BicnetCallContext.class), any(LoggerItemNe[].class));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testUpdateProperties_empty_ignores() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(NE_ID, 1),
                new NeOperationBuilder().build(NE_ID, 1),
                new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_ID, 1),
                new NeSynchronizationBuilder().build(NE_ID, 1),
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, 1));

        final NePhysicalConnectionData neInstance = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(neInstance));

        when(types.get(anyString())).thenReturn(type);
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(entity));
        when(preferencesRepository.tryUpdate(any(NeUserPreferencesMutationDescriptor.class))).then(new MutationAnswer<>());

        helper.updateProperties(context, new NEIdItem(NE_ID), ImmutableMap.of());

        verify(preferencesRepository, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));
        verify(notifications, never()).notifyChanges(any(NeUserPreferencesMutationDescriptor.class));
        verify(connectionManager, never()).updateNeProperties(any(NeEntity.class), any(NePhysicalConnectionData.class), any(NeUserPreferencesMutationDescriptor.class), any(Map.class));
        verify(loggerManager, never()).createCommandLog(any(BicnetCallContext.class), any(LoggerItemNe[].class));
    }

    @Test(expected=BcbException.class)
    public void testUpdateProperties_unknownNe_throws() throws Exception {

        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.empty());

        helper.updateProperties(context, new NEIdItem(NE_ID), ImmutableMap.of("a", "A"));
    }

    @Test(expected=BcbException.class)
    public void testUpdateProperties_error_throws() throws Exception {

        when(neRepository.queryNe(NE_ID)).thenThrow(new RepositoryException());

        helper.updateProperties(context, new NEIdItem(NE_ID), ImmutableMap.of("a", "A"));
    }

    @Test
    public void testDeleteNE() throws Exception {

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(NE_ID, 1),
                null,
                new NeInfoBuilder().setProxyType("type").build(NE_ID, CHANNEL_ID, 1),
                null,
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, 1));

        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(entity));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));
        when(domainRepository.queryAllForNE(NE_ID)).thenReturn(Collections.emptyList());

        helper.deleteNE(null, new NEIdItem(NE_ID));

        verify(neRepository).delete(new NeDeleteDescriptor(NE_ID));
        verify(notifications).notifyDelete(entity);
    }

    @Test
    public void testDeleteNE_unknownNE_ignores() throws Exception {

        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.empty());

        helper.deleteNE(null, new NEIdItem(NE_ID));

        verify(neRepository, never()).delete(any(NeDeleteDescriptor.class));
        verify(notifications, never()).notifyDelete(any(NeEntity.class));
    }

    @Test(expected=BcbException.class)
    public void testDeleteNE_repoError_throws() throws Exception {

        when(neRepository.queryNe(NE_ID)).thenThrow(new RepositoryException());

        helper.deleteNE(null, new NEIdItem(NE_ID));
    }

    @Test
    public void testCreateNE() throws Exception {
        final INE ne = new NEItem();
        ne.setNeProxyType(NE_TYPE);
        ne.setAssociatedEmId(CHANNEL_ID);
        ne.setIdName("neIdName");
        ne.setReconnectInterval(43);
        ne.setRealNeName("realName");
        ne.setAssociatedSystemContainerId(CONTAINER_ID);

        when(types.get(anyString())).thenReturn(type);
        when(channelRepository.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(buildChannel()));
        when(channelInstanceRepository.queryAll(CHANNEL_ID)).thenReturn(Collections.singleton(
                new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)));

        when(containerRepository.getRootContainer()).thenReturn(new ContainerInfo(0, VERSION, "Root"));

        final INE newNe = helper.createNE(null, ne);

        assertThat(newNe.getId(), is(1));
        assertThat(newNe.getRealNeName(), is("realName"));
        assertThat(newNe.getReconnectInterval(), is(43));
        assertThat(newNe.getIdName(), is("neIdName"));
        assertThat(newNe.getNeProxyType(), is(NE_TYPE));
        assertThat(newNe.getAssociatedEmId(), is(CHANNEL_ID));
        assertThat(newNe.getUsesGNE(), is(true));
        assertThat(newNe.getAssociatedSystemContainerId(), is(CONTAINER_ID));
    }

    @Test(expected=BcbException.class)
    public void testCreateNE_unknownType() throws Exception {
        final INE ne = new NEItem();
        ne.setNeProxyType(NE_TYPE);
        ne.setAssociatedEmId(CHANNEL_ID);
        ne.setIdName("neIdName");
        ne.setReconnectInterval(43);
        ne.setRealNeName("realName");

        when(types.get(anyString())).thenReturn(null);

        helper.createNE(null, ne);
    }

    @Test(expected=BcbException.class)
    public void testCreateNE_unknownChannel_throws() throws Exception {
        final INE ne = new NEItem();
        ne.setNeProxyType(NE_TYPE);
        ne.setAssociatedEmId(CHANNEL_ID);
        ne.setIdName("neIdName");
        ne.setReconnectInterval(43);
        ne.setRealNeName("realName");

        when(types.get(anyString())).thenReturn(type);
        when(channelRepository.queryChannel(CHANNEL_ID)).thenReturn(Optional.empty());

        helper.createNE(null, ne);
    }

    @Test
    public void testCreateNE_withProperties() throws Exception {

        when(types.get(anyString())).thenReturn(type);
        when(channelRepository.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(buildChannel()));
        when(channelInstanceRepository.queryAll(CHANNEL_ID)).thenReturn(Collections.singleton(
                new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)));
        when(containerRepository.getRootContainer()).thenReturn(new ContainerInfo(0, VERSION, "Root"));

        final INE newNe = helper.createNE(null, NE_TYPE, new EMIdItem(CHANNEL_ID), "neIdName", new Property[] {
            new Property(WellKnownNePropertyNames.RECONNECT_INTERVAL, "42"),
            new Property("Stuff", "Other"),
            new Property(WellKnownNePropertyNames.PARENT_NE_CONTAINER, String.valueOf(CONTAINER_ID))
        });

        assertThat(newNe.getId(), is(1));
        assertThat(newNe.getRealNeName(), is(nullValue()));
        assertThat(newNe.getReconnectInterval(), is(42));
        assertThat(newNe.getIdName(), is("neIdName"));
        assertThat(newNe.getNeProxyType(), is(NE_TYPE));
        assertThat(newNe.getAssociatedEmId(), is(CHANNEL_ID));
        assertThat(newNe.getUsesGNE(), is(true));
        assertThat(newNe.getAssociatedSystemContainerId(), is(CONTAINER_ID));
    }

    @Test
    public void testCreateNE_withPropertiesAndRoutes() throws Exception {

        when(channelRepository.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(buildChannel()));
        when(channelInstanceRepository.queryAll(CHANNEL_ID)).thenReturn(Collections.singleton(
                new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)));

        when(type.getGatewayRouteAttributes())
            .thenReturn(ImmutableMap.of(
                    "routeCost", attribute("routeCost", RouteMapping.COST),
                    "routePrio", attribute("routePrio", RouteMapping.PRIORITY),
                    "routeUse", attribute("routeUse", RouteMapping.USAGE),
                    "routeDomain", attribute("routeDomain", RouteMapping.DOMAIN_NAME),
                    "routeStuff", attribute("routeStuff"))
            );
        when(type.getGatewayRouteAddressKeySource())
            .thenReturn(Optional.of("${Route.routeDomain}-${Route.routeStuff}-${Property.keySuffix}"));

        when(type.getDirectRouteAttributes())
            .thenReturn(ImmutableMap.of("directTarget", attribute("directTarget")));
        when(type.getDirectRouteAddressKeySource())
            .thenReturn(Optional.of("${Route.directTarget}#${Property.keySuffix}"));

        when(types.get(anyString())).thenReturn(type);
        when(containerRepository.getRootContainer()).thenReturn(new ContainerInfo(0, VERSION, "Root"));

        final INE newNe = helper.createNE(null, NE_TYPE, new EMIdItem(CHANNEL_ID), "neIdName", new Property[] {
            new Property(WellKnownNePropertyNames.RECONNECT_INTERVAL, "42"),
            new Property("Stuff", "Other"),
            new Property("routeCost_000", "1"),
            new Property("routePrio_000", "1"),
            new Property("routeUse_000", "true"),
            new Property("routeDomain_000", "domain"),
            new Property("routeStuff_000", "blah"),
            new Property("directTarget", "address"),
            new Property("keySuffix", "checkMe")
        });

        final ArgumentCaptor<NeCreateDescriptor> createCaptor = ArgumentCaptor.forClass(NeCreateDescriptor.class);
        verify(neRepository).create(createCaptor.capture());

        assertThat(newNe.getId(), is(1));
        assertThat(newNe.getRealNeName(), is(nullValue()));
        assertThat(newNe.getReconnectInterval(), is(42));
        assertThat(newNe.getIdName(), is("neIdName"));
        assertThat(newNe.getNeProxyType(), is(NE_TYPE));
        assertThat(newNe.getAssociatedEmId(), is(CHANNEL_ID));
        assertThat(newNe.getUsesGNE(), is(true));

        final NeCreateDescriptor createDescriptor = createCaptor.getValue();

        final NeRoutePropertyAdapter<?> directRouteAdapter = createDescriptor.getPreferences().getDirectRouteAdapter();
        assertThat(directRouteAdapter.getKey(), hasValue("address#checkMe"));
        assertThat(directRouteAdapter.getProperty("directTarget"), hasValue("address"));

        final Collection<NeGatewayRouteBuilder> routeBuilders = createDescriptor.getGatewayRoutes();
        assertThat(routeBuilders, is(Matchers.iterableWithSize(1)));
        final NeGatewayRouteData route = getOnlyElement(routeBuilders).build(NE_ID, 1);
        assertThat(route.getKey(), is("domain-blah-checkMe"));
        assertThat(route.getCost(), is(1));
        assertThat(route.getPriority(), is(1));
        assertThat(route.getDomain(), hasValue("domain"));
        assertThat(route.getOpaqueProperty("routeStuff"), hasValue("blah"));
    }

    @Test(expected=BcbException.class)
    public void testCreateNE_withBadProperties_throws() throws Exception {

        when(types.get(anyString())).thenReturn(type);

        helper.createNE(null, NE_TYPE, new EMIdItem(CHANNEL_ID), "neIdName", new Property[] {
            new Property(WellKnownNePropertyNames.RECONNECT_INTERVAL, "blah")
        });

    }

    @Test(expected=BcbException.class)
    public void testCreateNE_withProperties_badType_throws() throws Exception {

        when(types.get(anyString())).thenReturn(null);

        helper.createNE(null, NE_TYPE, new EMIdItem(CHANNEL_ID), "neIdName", new Property[0]);
    }

    @Test(expected=BcbException.class)
    public void testCreateNE_withProperties_badChannel_throws() throws Exception {

        when(types.get(anyString())).thenReturn(type);
        when(channelRepository.queryChannel(CHANNEL_ID)).thenReturn(Optional.empty());

        helper.createNE(null, NE_TYPE, new EMIdItem(CHANNEL_ID), "neIdName", new Property[0]);
    }

    @Test
    public void testResynchronizeNEs() throws Exception {

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)));

        when(connectionRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_ID, VERSION)));
        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_ID, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName("name").build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActive(true).setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeSynchronizationBuilder().setAlarms(Optional.of(1L)).setAll(Optional.of(2L)).setPacket(Optional.of(3L)).build(NE_ID, 0)
        ));

        when(synchronizationRepository.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
        when(connectionRepository.tryUpdate(isA(NeConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        helper.resynchronizeNEs(context, new INEId[] { new NEIdItem(NE_ID) });

        verify(connectionRepository).tryUpdate(isA(NeConnectionMutationDescriptor.class));
        verify(activationManager).scheduleSynchronization(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));
        verify(loggerManager).createCommandLog(isA(BicnetCallContext.class), isA(LoggerItemNe.class));
    }

    @Test(expected=BcbException.class)
    public void testResynchronizeNEs_repoError_throws() throws Exception {

        when(infoRepository.query(NE_ID)).thenThrow(new RepositoryException());
        when(connectionRepository.query(NE_ID)).thenThrow(new RepositoryException());
        when(preferencesRepository.query(NE_ID)).thenThrow(new RepositoryException());

        helper.resynchronizeNEs(context, new INEId[] { new NEIdItem(NE_ID) });
    }

    @Test
    public void testCopyNetworkNamesToNeNames() throws Exception {
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationCaptor =
                ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        when(operationRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeOperationBuilder().setRealNeName(Optional.of("netName")).build(NE_ID, 1)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName("operatorName").build(NE_ID, 1)));

        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class)))
                .then(new MutationAnswer<>());

        NeInfoData state = new NeInfoBuilder()
            .setProxyType("neType")
            .build(NE_ID, 1, VERSION);
        NeUserPreferencesData prefs = new NeUserPreferencesBuilder()
            .setName("neName")
            .build(NE_ID, VERSION);
        
        final NeEntity entity = new NeEntity(new NeConnectionBuilder().build(NE_ID, VERSION), new NeOperationBuilder().build(NE_ID, VERSION),
                state, new NeSynchronizationBuilder().build(NE_ID, VERSION), prefs);        
        when(neRepository.queryNe(anyInt())).thenReturn(Optional.of(entity));
        
        helper.copyNetworkNamesToNeNames(context, Collections.singletonList(new NEIdItem(NE_ID)));

        verify(loggerManager).createCommandLog(any(BicnetCallContext.class), isA(LoggerItemNe.class));
        verify(notifications).notifyChanges(mutationCaptor.capture());

        assertThat(mutationCaptor.getValue().getName(), hasValue("netName"));
    }

    @Test(expected=BcbException.class)
    public void testCopyNetworkNamesToNeNames_repoError_throws() throws Exception {

        when(operationRepository.query(NE_ID)).thenThrow(new RepositoryException());

        helper.copyNetworkNamesToNeNames(context, Collections.singletonList(new NEIdItem(NE_ID)));
    }

    @Test
    public void testMoveNeToAnotherChannel() throws Exception {
        final ArgumentCaptor<NeInfoMutationDescriptor> mutationCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);

        final int oldChannelId = 1;
        final int newChannelId = 2;
        final String channelType = "channelType";

        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, oldChannelId, VERSION)));
        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName("name").build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
                ));

        when(channelInfoRepository.query(oldChannelId)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(channelType).build(oldChannelId, VERSION, 0)));
        when(channelPreferencesRepository.query(oldChannelId)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName("nameO").build(oldChannelId, VERSION)));

        when(channelInfoRepository.query(newChannelId)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(channelType).build(newChannelId, VERSION, 0)));
        when(channelPreferencesRepository.query(newChannelId)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName("nameN").build(newChannelId, VERSION)));

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)));
        when(channelInstanceRepository.queryAll(newChannelId)).thenReturn(Collections.singleton(
                new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, newChannelId, VERSION)));

        when(infoRepository.tryUpdate(isA(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        helper.moveNesToAnotherChannel(context, Collections.singleton(new NEIdItem(NE_ID)), new EMIdItem(newChannelId));

        verify(notifications).notifyChanges(mutationCaptor.capture());
        verify(loggerManager).createCommandLog(any(BicnetCallContext.class), isA(LoggerItemNe.class));

        assertThat(mutationCaptor.getValue().getChannelId(), hasValue(newChannelId));
    }

    @Test(expected=BcbException.class)
    public void testMoveNeToAnotherChannel_repoError_fails() throws Exception {

        final int newChannelId = 2;

        when(channelInfoRepository.query(newChannelId)).thenThrow(new RepositoryException());
        when(channelPreferencesRepository.query(newChannelId)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName("nameN").build(newChannelId, VERSION)));

        helper.moveNesToAnotherChannel(context, Collections.singleton(new NEIdItem(NE_ID)), new EMIdItem(newChannelId));
    }

    @Test
    public void testSetToActiveStateMode() throws Exception {
        helper.setToActiveStateMode(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(1)).toActiveStateMode(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test(expected=BcbException.class)
    public void testSetToActiveStateMode_error() throws Exception  {
        doThrow(RepositoryException.class).when(preferencesRepository).query(NE_ID);
        helper.setToActiveStateMode(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(0)).toActiveStateMode(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test
    public void testSetToMaintenanceMode() throws Exception {
        helper.setToMaintenanceMode(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(1)).toMaitenanceMode(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test(expected=BcbException.class)
    public void testSetToMaintenanceMode_error() throws Exception  {
        doThrow(RepositoryException.class).when(preferencesRepository).query(NE_ID);
        helper.setToMaintenanceMode(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(0)).toMaitenanceMode(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test
    public void testSetToOperationalMode() throws Exception {
        helper.setToOperationalMode(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(1)).toOperationalMode(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test(expected=BcbException.class)
    public void testSetToOperationalMode_error() throws Exception  {
        doThrow(RepositoryException.class).when(preferencesRepository).query(NE_ID);
        helper.setToOperationalMode(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(0)).toOperationalMode(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test
    public void testWriteAccessRelease() throws Exception {
        helper.writeAccessRelease(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(1)).releaseWriteAccess(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test(expected=BcbException.class)
    public void testWriteAccessRelease_error() throws Exception  {
        doThrow(RepositoryException.class).when(preferencesRepository).query(NE_ID);
        helper.writeAccessRelease(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(0)).releaseWriteAccess(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test
    public void testWriteAccessRequest() throws Exception {
        helper.writeAccessRequest(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(1)).requestWriteAccess(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test(expected=BcbException.class)
    public void testWriteAccessRequest_error() throws Exception  {
        doThrow(RepositoryException.class).when(preferencesRepository).query(NE_ID);
        helper.writeAccessRequest(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(0)).requestWriteAccess(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test
    public void testWriteAccessEnforce() throws Exception {
        helper.writeAccessEnforce(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(1)).enforceWriteAccess(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test(expected=BcbException.class)
    public void testWriteAccessEnforce_error() throws Exception  {
        doThrow(RepositoryException.class).when(preferencesRepository).query(NE_ID);
        helper.writeAccessEnforce(null, new NEIdItem(NE_ID));

        verify(accessControlManager, times(0)).enforceWriteAccess(any(BicnetCallContext.class), any(Integer.class));
    }

    @Test
    public void testGetScsSynchronizationStates() {
        final Iterable<ScsSynchronizationState> states = Collections.singletonList(
                new ScsSynchronizationState(1, ScsSyncState.SYNCHRONIZED));
        final InMemoryNeSyncStateRepository syncRepo = mock(InMemoryNeSyncStateRepository.class);
        when(syncRepo.queryAll()).thenReturn(states);
        when(neRepository.getNeSyncStateRepository()).thenReturn(syncRepo);

        final Iterable<ScsSynchronizationState> exposedStates = helper.getScsSynchronizationStates();
        assertThat(exposedStates, is(states));
    }

    @Test
    public void testChangeContainerId() throws Exception {
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> captor =
                ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        final Map<INEId, ISystemContainerId> changes = ImmutableMap.of(
            new NEIdItem(1), new SystemContainerIdItem(10),
            new NEIdItem(2), new SystemContainerIdItem(20));

        when(preferencesRepository.query(1)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName("a").build(1, VERSION)));
        when(preferencesRepository.query(2)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName("b").build(2, VERSION)));
        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class)))
            .then(new MutationAnswer<>());

        helper.changeSystemContainerId(context, changes);

        verify(notifications, times(2)).notifyChanges(captor.capture());
        verify(loggerManager, times(2)).createCommandLog(isA(BicnetCallContext.class), isA(LoggerItemNe.class));

        assertThat(
                transform(captor.getAllValues(), new Function<NeUserPreferencesMutationDescriptor, NeUserPreferencesData>() {
                    @Override
                    public NeUserPreferencesData apply(NeUserPreferencesMutationDescriptor input) {
                        return input.getResult();
                    }
                }),
                containsInAnyOrder(
                    new NeUserPreferencesBuilder().setName("a").setContainerId(Optional.of(10)).build(1, VERSION),
                    new NeUserPreferencesBuilder().setName("b").setContainerId(Optional.of(20)).build(2, VERSION)
                )
            );
    }

    @Test(expected=BcbException.class)
    public void testChangeContainerId_fails_throws() throws Exception {

        when(preferencesRepository.query(anyInt())).thenThrow(new RepositoryException());

        helper.changeSystemContainerId(context,
                ImmutableMap.of(new NEIdItem(1), new SystemContainerIdItem(10)));
    }
}
