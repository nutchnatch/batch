package com.ossnms.dcn_manager.bicnet.connector.policies;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.bicnet.connector.factory.Metrics;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.test.RunRunnableAnswer;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class NetworkElementConnectionSchedulerImplTest {

    private static final int MEDIATOR_ID = 3;
    private static final int CHANNEL_ID = 2;
    private static final int NE_ID = 1;
    private static final int NE_INSTANCE_ID = 1000;

    private ObservableExecutor executor;
    private ThreadFactory threadFactory;
    private NeConnectionManager connectionManager;
    private Metrics metrics;

    @Before
    public void setUp() {
        metrics = mock(Metrics.class);
        threadFactory = mock(ThreadFactory.class);
        executor = mock(ObservableExecutor.class);
        doAnswer(new RunRunnableAnswer()).when(executor).execute(any(Runnable.class));

        connectionManager = mock(NeConnectionManager.class);
    }

    private NeEntity buildNeEntity() {
        return new NeEntity(
                new NeConnectionData.NeConnectionBuilder().build(NE_ID, 0),
                new NeOperationData.NeOperationBuilder().build(NE_ID, 0),
                new NeInfoData.NeInfoBuilder().setProxyType("type").build(NE_ID, CHANNEL_ID, 0),
                new NeSynchronizationData.NeSynchronizationBuilder().build(NE_ID, 0),
                new NeUserPreferencesData.NeUserPreferencesBuilder().setName("name").build(NE_ID, 0));
    }

    @Test
    public void activation() throws Exception {

        new NetworkElementConnectionSchedulerImpl(executor, threadFactory, connectionManager, metrics)
            .scheduleActivation(new Activate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, true));

        verify(connectionManager).activate(new Activate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, true));
    }

    @Test
    public void deactivation() throws Exception {

        new NetworkElementConnectionSchedulerImpl(executor, threadFactory, connectionManager, metrics)
            .scheduleDeactivation(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, true));

        verify(connectionManager).deactivate(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, true));
    }

    @Test
    public void onNeConnected() throws Exception {
        final NetworkElementConnectionSchedulerImpl schedulerImpl =
                new NetworkElementConnectionSchedulerImpl(executor, threadFactory, connectionManager, metrics);

        schedulerImpl.scheduleActivation(new Activate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, true));
        assertThat(schedulerImpl.getOngoingMediatorJobCount(), is(1));
        assertThat(schedulerImpl.getOngoingSystemJobCount(), is(1));
        schedulerImpl.onNeConnected(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_ID, MEDIATOR_ID, true));
        assertThat(schedulerImpl.getOngoingMediatorJobCount(), is(1));
        assertThat(schedulerImpl.getOngoingSystemJobCount(), is(1));

        verify(connectionManager).activate(new Activate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, true));
        verify(connectionManager).lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_ID, MEDIATOR_ID, true));
    }

    @Test
    public void testNePropertiesUpdated_runsAsynchronously() throws Exception {

        final NeEntity ne = buildNeEntity();
        final NePhysicalConnectionData conn = new NePhysicalConnectionData.NePhysicalConnectionBuilder().build(1, 1, 1, 1);
        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(
                new NeUserPreferencesData.NeUserPreferencesBuilder().setName("n").build(1, 1)
        );
        final Map<String, String> props = ImmutableMap.of();

        final NetworkElementConnectionSchedulerImpl schedulerImpl =
                new NetworkElementConnectionSchedulerImpl(executor, threadFactory, connectionManager, metrics);

        schedulerImpl.onNePropertiesUpdated(ne, conn, mutation);

        verify(executor).execute(isA(Runnable.class));
        verify(connectionManager).updateNeProperties(ne, conn, mutation, Collections.emptyMap());
    }

    @Test
    public void testNePropertiesUpdated_executorError_runsSynchronously() throws Exception {

        final NeEntity ne = buildNeEntity();
        final NePhysicalConnectionData conn = new NePhysicalConnectionData.NePhysicalConnectionBuilder().build(1, 1, 1, 1);
        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(
                new NeUserPreferencesData.NeUserPreferencesBuilder().setName("n").build(1, 1)
        );

        doThrow(new RejectedExecutionException()).when(executor).execute(any(Runnable.class));

        final NetworkElementConnectionSchedulerImpl schedulerImpl =
                new NetworkElementConnectionSchedulerImpl(executor, threadFactory, connectionManager, metrics);

        schedulerImpl.onNePropertiesUpdated(ne, conn, mutation);

        verify(connectionManager).updateNeProperties(ne, conn, mutation, Collections.emptyMap());

    }
}
