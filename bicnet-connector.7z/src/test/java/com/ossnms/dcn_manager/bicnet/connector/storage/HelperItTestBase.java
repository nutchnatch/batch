package com.ossnms.dcn_manager.bicnet.connector.storage;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.unitils.UnitilsJUnit4TestClassRunner;
import org.unitils.orm.jpa.JpaUnitils;
import org.unitils.orm.jpa.annotation.JpaEntityManagerFactory;

import com.ossnms.dcn_manager.bicnet.connector.storage.JpaRepositoryBean;

@JpaEntityManagerFactory(persistenceUnit = "DCN-MANAGER", configFile = "/META-INF/persistence.xml")
@RunWith(UnitilsJUnit4TestClassRunner.class)
public abstract class HelperItTestBase {

    protected static final int ALL = -1;

    @Spy protected JpaRepositoryBean repositoryBean;

    @Before
    public void setUp() throws Exception {
        repositoryBean = new JpaRepositoryBean();
        JpaUnitils.injectEntityManagerInto(repositoryBean);

        MockitoAnnotations.initMocks(this);
    }

}
