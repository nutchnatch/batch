package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.composables.configuration.HardwareConfigurationType;
import com.ossnms.dcn_manager.connector.storage.settings.entities.GlobalSettingsDb;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class JpaSettingsRepositoryBeanTest {

    @Mock
    private ISystemControlEjbFacade scs;
    @Mock
    private ISessionContext systemContext;
    @Mock
    private StaticConfigurationSingleton configuration;

    @InjectMocks
    JpaSettingsRepositoryBean bean;

    @Test
    public void areStandbyConnectionsAllowed() throws Exception {

        when(scs.isStandbyConfigured(systemContext)).thenReturn(true, false);

        assertThat(bean.areStandbyConnectionsAllowed(), is(true));
        assertThat(bean.areStandbyConnectionsAllowed(), is(false));
    }

    @Test
    public void areStandbyConnectionsAllowed_scsException_returnsFalse() throws Exception {

        when(scs.isStandbyConfigured(systemContext)).thenThrow(new BcbException());

        assertThat(bean.areStandbyConnectionsAllowed(), is(false));

    }

    @Test
    public void testInjectStartupLimit() throws Exception {
        when(configuration.getHWConfiguration()).thenReturn(HardwareConfigurationType.MED);
        
        GlobalSettingsDb globalSettingsDb = new GlobalSettingsDb(1, 2);
        bean.injectStartupLimit(globalSettingsDb);
        
        assertThat(globalSettingsDb.toGlobalSettings().getScaledStartupLimit(), is(HardwareConfigurationType.MED.getValue()));        
    }
}