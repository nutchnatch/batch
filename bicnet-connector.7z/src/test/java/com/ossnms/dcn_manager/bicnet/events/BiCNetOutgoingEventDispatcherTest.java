package com.ossnms.dcn_manager.bicnet.events;

import com.ossnms.bicnet.bcb.facade.scs.IScsFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.common.SyncCategory;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncMode;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.composables.outbound.SharedResources;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializedEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeSynchronizationRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import rx.Observable;

import java.util.Collections;
import java.util.Optional;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class BiCNetOutgoingEventDispatcherTest {

    private static final int CHANNEL_ID = 42;
    private static final int NE_ID = 21;
    private static final int NE_INSTANCE_ID = 2100;
    private static final int CHANNEL_INSTANCE_ID = 4200;

    private NeEntityRepository neRepository;
    private NeInfoRepository infoRepo;
    private NeSynchronizationRepository syncRepo;
    private IScsFacade scs;
    private ISessionContext systemContext;
    private SharedResources<BicnetCallContext> sharedResources;

    private BiCNetOutgoingEventDispatcher dispatcher;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        neRepository = mock(NeEntityRepository.class);
        infoRepo = mock(NeInfoRepository.class);
        syncRepo = mock(NeSynchronizationRepository.class);
        scs = mock(IScsFacade.class);
        systemContext = mock(ISessionContext.class);
        sharedResources = mock(SharedResources.class);

        when(neRepository.getNeInfoRepository()).thenReturn(infoRepo);
        when(neRepository.getNeSynchronizationRepository()).thenReturn(syncRepo);

        dispatcher = new BiCNetOutgoingEventDispatcher(neRepository, scs, sharedResources, systemContext);
    }

    private NeEntity buildEntity() {
        return new NeEntity(
                new NeConnectionBuilder().build(NE_ID, 1),
                new NeOperationBuilder().build(NE_ID, 1),
                new NeInfoBuilder().setProxyType("type").build(NE_ID, CHANNEL_ID, 1),
                new NeSynchronizationBuilder().build(NE_ID, 1),
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, 1));
    }

    @Test
    public void testInitialized() throws Exception {
        final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor = ArgumentCaptor.forClass(IBiCNetComponentId[].class);

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));

        dispatcher.initialize(observablesWithEvent(new NeInitializedEvent(NE_ID)));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
        verify(scs).triggerForcedSync(eq(systemContext), componentIdCaptor.capture(), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.ALL));
    }

    @Test
    public void testInitialized_errorOnScs_onlyAcquires() throws Exception {

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));

        doThrow(new BcbException())
            .when(scs)
                .triggerForcedSync(any(ISessionContext.class), any(IBiCNetComponentId[].class), any(ScsSyncMode.class), any(SyncCategory.class));

        dispatcher.initialize(observablesWithEvent(new NeInitializedEvent(NE_ID)));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
    }

    @Test
    public void testInitialized_infoNotFound_doesNothing() throws Exception {

        when(infoRepo.query(NE_ID)).thenReturn(Optional.empty());
        when(syncRepo.query(NE_ID)).thenReturn(Optional.empty());

        dispatcher.initialize(observablesWithEvent(new NeInitializedEvent(NE_ID)));

        verifyZeroInteractions(scs, sharedResources);
    }

    @Test
    public void testInitialized_withPhysicalEventOnActiveInstance_doesNothing() throws Exception {

        dispatcher.initialize(observablesWithEvent(new NeInitializedEvent(NE_ID, new PhysicalNeInitializedEvent(NE_INSTANCE_ID, NE_ID, true))));

        verifyZeroInteractions(scs, sharedResources, neRepository);
    }

    @Test
    public void testInitialized_withPhysicalEventOnInactiveInstance_doesNothing() throws Exception {

        dispatcher.initialize(observablesWithEvent(new NeInitializedEvent(NE_ID, new PhysicalNeInitializedEvent(NE_INSTANCE_ID, NE_ID, false))));

        verifyZeroInteractions(scs, sharedResources, neRepository);
    }

    @Test
    public void testNeDisconnected() {

        dispatcher.initialize(observablesWithEvent(new NeDisconnectedEvent(NE_ID)));

        verify(sharedResources).releaseNeResources(any(BicnetCallContext.class), eq(NE_ID));
    }

    @Test
    public void testNeDisconnected_withPhysicalEventOnActiveInstance_doesNothing() {

        dispatcher.initialize(observablesWithEvent(new NeDisconnectedEvent(NE_ID, new PhysicalNeDisconnectedEvent(NE_INSTANCE_ID, NE_ID, true))));

        verifyZeroInteractions(scs, sharedResources, neRepository);
    }

    @Test
    public void testNeDisconnected_withPhysicalEventOnInactiveInstance_doesNothing() {

        dispatcher.initialize(observablesWithEvent(new NeDisconnectedEvent(NE_ID, new PhysicalNeDisconnectedEvent(NE_INSTANCE_ID, NE_ID, false))));

        verifyZeroInteractions(scs, sharedResources, neRepository);
    }

    @Test
    public void testChannelDisconnected() {

        dispatcher.initialize(observablesWithEvent(new ChannelDeactivatedEvent(CHANNEL_ID)));

        verify(sharedResources).releaseChannelResources(any(BicnetCallContext.class), eq(CHANNEL_ID));
    }

    @Test
    public void testChannelDisconnected_withPhysicalEventOnActiveInstance_doesNothing() {

        dispatcher.initialize(observablesWithEvent(new ChannelDeactivatedEvent(CHANNEL_ID, new PhysicalChannelDeactivatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true))));

        verifyZeroInteractions(scs, sharedResources, neRepository);
    }

    @Test
    public void testChannelDisconnected_withPhysicalEventOnInactiveInstance_doesNothing() {

        dispatcher.initialize(observablesWithEvent(new ChannelDeactivatedEvent(CHANNEL_ID, new PhysicalChannelDeactivatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, false))));

        verifyZeroInteractions(scs, sharedResources, neRepository);
    }

    private Iterable<Observable<? extends Event>> observablesWithEvent(Event event) {
        final Observable<Event> source = Observable.just(event);
        return Collections.singletonList(source);
    }

}
