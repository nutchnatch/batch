package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.ossnms.dcn_manager.core.entities.ne.data.NeDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDirectRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.RouteSortingMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.unitils.dbunit.annotation.DataSet;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

@DataSet
public class JpaNetworkElementRepositoryBeanIT extends HelperItTestBase {

    @InjectMocks private JpaNetworkElementRepositoryBean repositoryBean;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        repositoryBean.initialize();
        repositoryBean.start();
    }

    @Test
    public void validateEntityMapping() throws Exception {

        final Optional<NeEntity> ne = repositoryBean.query(1);

        assertThat(ne, is(present()));

        final NeEntity entity = ne.get();
        assertThat(entity.getInfo(), is(notNullValue()));
        assertThat(entity.getConnection(), is(notNullValue()));
        assertThat(entity.getOperation(), is(notNullValue()));
        assertThat(entity.getPreferences(), is(notNullValue()));
        assertThat(entity.getSync(), is(notNullValue()));
    }

    @Test
    public void validateRouteMapping() throws Exception {

        final Optional<NeEntity> ne = repositoryBean.query(1);

        assertThat(ne, is(present()));

        final NeEntity entity = ne.get();
        final NeUserPreferencesData preferences = entity.getPreferences();

        assertThat(preferences, is(notNullValue()));

        final NeDirectRouteData directRoute = preferences.getDirectRoute();
        assertThat(directRoute, is(notNullValue()));
        assertThat(directRoute.getKey(), is("route2"));
        assertThat(directRoute.getOpaqueProperty("prop2"), hasValue("value2"));
    }

    @Test
    public void testName() throws Exception {

        assertThat(repositoryBean.queryNeName(1), hasValue("testNeName"));
        assertThat(repositoryBean.queryNeName(2), is(absent()));

    }

    @Test
    public void testQueryByRequiredActiveUnderChannel() throws Exception {

        Iterable<NeInfoData> activationRequired;

        activationRequired = repositoryBean.queryActivationRequiredIs(10, RequiredActivationState.ACTIVE);
        assertThat(activationRequired, is(Matchers.iterableWithSize(1)));
        activationRequired = repositoryBean.queryActivationRequiredIs(10, RequiredActivationState.INACTIVE);
        assertThat(activationRequired, is(emptyIterable()));

        activationRequired = repositoryBean.queryActivationRequiredIs(11, RequiredActivationState.ACTIVE);
        assertThat(activationRequired, is(emptyIterable()));
        activationRequired = repositoryBean.queryActivationRequiredIs(11, RequiredActivationState.INACTIVE);
        assertThat(activationRequired, is(emptyIterable()));

    }

    @Test
    public void disallowInsertOnUpdate() throws Exception {

        final NeEntity ne = repositoryBean.query(1).get();

        final NeInfoData info = repositoryBean.getNeInfoRepository().query(1).get();

        repositoryBean.delete(new NeDeleteDescriptor(ne.getInfo().getId()));

        final Optional<NeInfoData> updated = repositoryBean.getNeInfoRepository().tryUpdate(new NeInfoMutationDescriptor(info).setUsedBy("0"));

        assertThat(updated, is(absent()));
    }

    @Test
    public void updateDirectRoute() throws Exception {

        NeUserPreferencesData preferences = repositoryBean.getNeUserPreferencesRepository().query(1).get();
        assertThat(preferences.getDirectRoute().getKey(), is("route2"));

        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(preferences);
        mutation.getDirectRouteAdapter().setKey("newRouteKey");

        final Optional<NeUserPreferencesData> updated = repositoryBean.getNeUserPreferencesRepository().tryUpdate(mutation);
        assertThat(updated, is(present()));
        assertThat(updated.get().getDirectRoute().getKey(), is("newRouteKey"));

        preferences = repositoryBean.getNeUserPreferencesRepository().query(1).get();
        assertThat(preferences.getDirectRoute().getKey(), is("newRouteKey"));
    }

    @Test
    public void updateDirectRoute_unitOfWork() throws Exception {

        final NeUserPreferencesRepository preferencesRepository = repositoryBean.getNeUserPreferencesRepository();

        NeUserPreferencesData preferences = preferencesRepository.query(1).get();
        assertThat(preferences.getDirectRoute().getKey(), is("route2"));

        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(preferences);
        mutation.getDirectRouteAdapter().setKey("newRouteKey");

        final Optional<NeUserPreferencesData> updated =
                repositoryBean.<Optional<NeUserPreferencesData>>unitOfWork(null)
                        .addUnit(preferencesRepository::tryUpdate, mutation, (r, a) -> r)
                        .apply();
        assertThat(updated, is(present()));
        assertThat(updated.get().getDirectRoute().getKey(), is("newRouteKey"));

        preferences = preferencesRepository.query(1).get();
        assertThat(preferences.getDirectRoute().getKey(), is("newRouteKey"));
    }

    @Test
    public void testRouteSortingModeStorage() throws Exception {

        final NeUserPreferencesRepository preferencesRepository = repositoryBean.getNeUserPreferencesRepository();

        NeUserPreferencesData preferences = preferencesRepository.query(1).get();
        assertThat(preferences.getRouteSortingMode(), is(RouteSortingMode.DEFAULT));

        final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(preferences);
        mutation.enableRouteSortingByUsage(true);

        final Optional<NeUserPreferencesData> updated = repositoryBean.getNeUserPreferencesRepository().tryUpdate(mutation);
        assertThat(updated, is(present()));
        assertThat(updated.get().getRouteSortingMode(), is(RouteSortingMode.AUTO_PRIORITY));
    }
}
