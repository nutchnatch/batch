package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMMarkable;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.HelperItTestBase;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaChannelRepositoryBean;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.test.MockFactory;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.unitils.dbunit.annotation.DataSet;
import org.unitils.inject.util.InjectionUtils;
import org.unitils.inject.util.PropertyAccess;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.arrayWithSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@DataSet
public class ChannelHelperImplIT extends HelperItTestBase {

    private static final int MEDIATOR_ID = 10;

    @Mock private StaticConfiguration configuration;
    @Mock private ISessionContext context;
    @Mock private LoggerManagerImpl logger;

    @InjectMocks private JpaChannelRepositoryBean channelRepository;

    @InjectMocks private ChannelHelper helper;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        final ChannelType channelType = MockFactory.mockEmType();
        final Types<ChannelType> channelTypes = mock(Types.class);

        when(channelTypes.get(anyString())).thenReturn(channelType);
        when(configuration.getChannelTypes()).thenReturn(channelTypes);

        channelRepository.initialize();
        channelRepository.start();

        InjectionUtils.injectIntoByType(channelRepository, channelRepository.getClass(), helper, PropertyAccess.FIELD);
    }

    private void checkChannel(IEM em, EnableSwitch activation, String type, int id, String name, int reconnect) {
        assertThat(em.getActivation(), is(activation));
        assertThat(em.getAssociatedMediatorId(), is(MEDIATOR_ID));
        assertThat(em.getEmType(), is(type));
        assertThat(em.getId(), is(id));
        assertThat(em.getIdName(), is(name));
        assertThat(em.getReconnectInterval(), is(reconnect));
    }

    @Test
    public void getChannelList() throws Exception {

        final EMReply reply = helper.getEMList(context, null, null, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(2)));

        checkChannel(reply.getData()[0], EnableSwitch.ENABLED, "EM-GM", 1, "channel1", 2);
        checkChannel(reply.getData()[1], EnableSwitch.DISABLED, "EM-MVM", 2, "channel2", 0);
    }

    @Test
    public void getChannelList_limited() throws Exception {

        final EMReply reply = helper.getEMList(context, null, null, 1);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(1)));

        checkChannel(reply.getData()[0], EnableSwitch.ENABLED, "EM-GM", 1, "channel1", 2);
    }

    @Test
    public void getChannelList_startFrom() throws Exception {

        final EMReply reply = helper.getEMList(context, new EMIdItem(2), null, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(1)));

        checkChannel(reply.getData()[0], EnableSwitch.DISABLED, "EM-MVM", 2, "channel2", 0);
    }

    @Test
    public void getChannelList_filtered() throws Exception {

        IEMMarkable filter;
        EMReply reply;

        // Get by ID

        filter = EMItem.markableEM(null);
        filter.setId(2);
        reply = helper.getEMList(context, null, new IEMMarkable[] { filter }, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        checkChannel(reply.getData()[0], EnableSwitch.DISABLED, "EM-MVM", 2, "channel2", 0);

        // Get by Type

        filter = EMItem.markableEM(null);
        filter.setEmType("EM-GM");
        reply = helper.getEMList(context, null, new IEMMarkable[] { filter }, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        checkChannel(reply.getData()[0], EnableSwitch.ENABLED, "EM-GM", 1, "channel1", 2);

        // Get by Mediator ID

        filter = EMItem.markableEM(null);
        filter.setAssociatedMediatorId(10);
        reply = helper.getEMList(context, null, new IEMMarkable[] { filter }, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(2)));
        checkChannel(reply.getData()[0], EnableSwitch.ENABLED, "EM-GM", 1, "channel1", 2);
        checkChannel(reply.getData()[1], EnableSwitch.DISABLED, "EM-MVM", 2, "channel2", 0);

        // Get by ID Name

        filter = EMItem.markableEM(null);
        filter.setIdName("channel1");
        reply = helper.getEMList(context, null, new IEMMarkable[] { filter }, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        checkChannel(reply.getData()[0], EnableSwitch.ENABLED, "EM-GM", 1, "channel1", 2);

        // Get by Activation

        filter = EMItem.markableEM(null);
        filter.setActivation(EnableSwitch.DISABLED);
        reply = helper.getEMList(context, null, new IEMMarkable[] { filter }, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        checkChannel(reply.getData()[0], EnableSwitch.DISABLED, "EM-MVM", 2, "channel2", 0);

    }

    @Test(expected=BcbException.class)
    public void getChannelList_unsupportedFilter() throws Exception {

        final IEMMarkable filter = EMItem.markableEM(null);
        filter.setDisplayAddress("blah");
        helper.getEMList(context, null, new IEMMarkable[] { filter }, ALL);
    }

    @Test
    public void getChannelIdList() throws Exception {

        final EMIdReply reply = helper.getEMIdList(context, null, null, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(Matchers.<IEMId>arrayContaining(new EMIdItem(1), new EMIdItem(2))));

    }

    @Test
    public void getChannelIdList_limited() throws Exception {

        final EMIdReply reply = helper.getEMIdList(context, null, null, 1);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(Matchers.<IEMId>arrayContaining(new EMIdItem(1))));
    }

    @Test
    public void getChannelIdList_startFrom() throws Exception {

        final EMIdReply reply = helper.getEMIdList(context, new EMIdItem(2), null, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(Matchers.<IEMId>arrayContaining(new EMIdItem(2))));
    }

    @Test
    public void getChannelIdList_filtered() throws Exception {

        IEMMarkable filter;
        EMIdReply reply;

        // Get by ID

        filter = EMItem.markableEM(null);
        filter.setId(2);
        reply = helper.getEMIdList(context, null, new IEMMarkable[] { filter }, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(Matchers.<IEMId>arrayContaining(new EMIdItem(2))));

        // Get by Type

        filter = EMItem.markableEM(null);
        filter.setEmType("EM-GM");
        reply = helper.getEMIdList(context, null, new IEMMarkable[] { filter }, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(Matchers.<IEMId>arrayContaining(new EMIdItem(1))));

        // Get by Mediator ID

        filter = EMItem.markableEM(null);
        filter.setAssociatedMediatorId(10);
        reply = helper.getEMIdList(context, null, new IEMMarkable[] { filter }, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(Matchers.<IEMId>arrayContaining(new EMIdItem(1), new EMIdItem(2))));

        // Get by ID Name

        filter = EMItem.markableEM(null);
        filter.setIdName("channel1");
        reply = helper.getEMIdList(context, null, new IEMMarkable[] { filter }, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.getData(), is(Matchers.<IEMId>arrayContaining(new EMIdItem(1))));

        // Get by Activation

        filter = EMItem.markableEM(null);
        filter.setActivation(EnableSwitch.DISABLED);
        reply = helper.getEMIdList(context, null, new IEMMarkable[] { filter }, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(1)));
        assertThat(reply.getData(), is(Matchers.<IEMId>arrayContaining(new EMIdItem(2))));

    }

    @Test(expected=BcbException.class)
    public void getEmIdList_unsupportedFilter() throws Exception {

        final IEMMarkable filter = EMItem.markableEM(null);
        filter.setDisplayAddress("blah");
        helper.getEMIdList(context, null, new IEMMarkable[] { filter }, ALL);
    }

    @Test
    @DataSet("ChannelHelperImplIT.empty.xml")
    public void getChannelList_empty() throws Exception {

        final EMReply reply = helper.getEMList(context, null, null, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(0)));
    }

    @Test
    @DataSet("ChannelHelperImplIT.empty.xml")
    public void getChannelIdList_empty() throws Exception {

        final EMIdReply reply = helper.getEMIdList(context, null, null, ALL);

        assertThat(reply, not(is(nullValue())));
        assertThat(reply.getData(), is(arrayWithSize(0)));
    }

    @Test
    @DataSet("ChannelHelperImplIT.empty.xml")
    public void getSingleChannel_empty() throws Exception {

        final IEM reply = helper.getSingleEM(context, new EMIdItem(1));

        assertThat(reply, is(nullValue()));
    }
}
