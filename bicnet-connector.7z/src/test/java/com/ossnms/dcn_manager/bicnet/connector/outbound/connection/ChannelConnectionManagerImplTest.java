package com.ossnms.dcn_manager.bicnet.connector.outbound.connection;

import com.ossnms.bicnet.bcb.facade.elementMgmt.ElementManagerIdItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.IElementManagerFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.IElementManagerFactory;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMMarkableItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.platform.IConnectionManager;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.platform.PlatformException;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.messaging.ChannelEventSource;
import com.ossnms.dcn_manager.bicnet.connector.storage.ChannelInstanceConnectionRepository;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownChannelPropertyNames;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownSettingsPropertyNames;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelCreatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelCreatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelConnectionRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelUserPreferencesRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertChannelToBcb.convert;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertIntegerToBcbEm.convert;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ChannelConnectionManagerImplTest {

    private static final int CHANNEL_ID = 1;
    private static final int INSTANCE_ID = 2;

    private ChannelEntity channel;
    private ChannelType channelType;
    private Types<ChannelType> channelTypes;
    private BicnetCallContext context;

    private IConnectionManager connectionManager;
    private ISessionContext sessionContext;
    private IElementManagerFactory elementManagerFactory;
    private IElementManagerFacade elementManager;
    private StaticConfigurationSingleton configuration;
    private ChannelConnectionManagerImpl channelConnectionManager;
    private ChannelEntityRepository channelRepository;
    private ChannelConnectionRepository channelConnectionRepository;
    private ChannelUserPreferencesRepository channelUserPreferencesRepository;
    private ChannelInstanceConnectionRepository channelInstanceRepository;
    private LoggerManager<BicnetCallContext> loggerManager;
    private JpaSettingsRepositoryBean settingsRepository;
    private ChannelEventSource channelEvents;

    private GlobalSettings globalSettings;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws RepositoryException {
        channelType = MockFactory.mockEmType();
        channelTypes = mock(Types.class);
        context = mock(BicnetCallContext.class);

        connectionManager = mock(IConnectionManager.class);
        sessionContext = mock(ISessionContext.class);
        configuration = mock(StaticConfigurationSingleton.class);
        elementManagerFactory = mock(IElementManagerFactory.class);
        elementManager = mock(IElementManagerFacade.class);
        channelInstanceRepository = mock(ChannelInstanceConnectionRepository.class);
        channelRepository = mock(ChannelEntityRepository.class);
        channelConnectionRepository = mock(ChannelConnectionRepository.class);
        channelUserPreferencesRepository = mock(ChannelUserPreferencesRepository.class);
        when(channelRepository.getChannelConnectionRepository()).thenReturn(channelConnectionRepository);
        when(channelRepository.getChannelUserPreferencesRepository()).thenReturn(channelUserPreferencesRepository);
        loggerManager = mock(LoggerManager.class);
        settingsRepository = mock(JpaSettingsRepositoryBean.class);
        channelEvents = mock(ChannelEventSource.class);

        final int RECONNECT_INTERVAL = 60;
        final int VERSION = 1;
        final int MEDIATOR_ID = 1;
        channelConnectionManager = new ChannelConnectionManagerImpl(context, connectionManager, configuration,
                new ChannelManagers(channelRepository, channelInstanceRepository, null, null, channelEvents),
                settingsRepository, loggerManager);
        channel = new ChannelEntity(
        		new ChannelInfoBuilder()
        		    .setType(channelType.getName())
        		    .setCoreId("")
        		    .setActivationRequired(false)
        		    .build(CHANNEL_ID, VERSION, MEDIATOR_ID),
        		new ChannelConnectionBuilder().build(CHANNEL_ID, VERSION),
        		new ChannelUserPreferencesBuilder()
        		    .setReconnectInterval(RECONNECT_INTERVAL)
        		    .setName("The channel name")
        		    .build(CHANNEL_ID, VERSION)
        );

        globalSettings = GlobalSettings.build()
                .setDiscoveryPolicy(DiscoveryPolicy.DISCOVER_ALL_NETWORK)
                .setMediatorRetries(1)
                .setNeRetries(2)
                .setEnableScheduledStartup(true)
                .setRetryInterval(RECONNECT_INTERVAL)
                .setScaledStartupLimit(50)
                .toGlobalSettings(1,1);

        when(context.getSessionContext()).thenReturn(sessionContext);
        when(channelType.getName()).thenReturn("typeName");
        when(channelType.getDefaultIcon()).thenReturn("icons");
        when(configuration.getChannelTypes()).thenReturn(channelTypes);
        when(channelTypes.get("typeName")).thenReturn(channelType);

        when(channelRepository.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(channel));
        when(channelInstanceRepository.query(INSTANCE_ID)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder().build(INSTANCE_ID, 0, CHANNEL_ID, 0)));

        when(configuration.getChannelTypes().get(anyString())).thenReturn(channelType);

        when(settingsRepository.getSettings()).thenReturn(globalSettings);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testConnect() throws Exception {
        final ArgumentCaptor<Properties> propertiesCaptor = ArgumentCaptor.forClass(Properties.class);
        final String[] facets = { "provider" };
        final IEM iem = convert(channelType, channel);

        when(connectionManager.createElementManager(eq(sessionContext), any(MediatorIdItem.class), eq(iem), any(Properties.class))).thenReturn(facets);

        channelConnectionManager.connect(INSTANCE_ID);

        verify(connectionManager, times(1)).createElementManager(eq(sessionContext), any(MediatorIdItem.class), eq(iem), propertiesCaptor.capture());
        verify(channelEvents).push(new PhysicalChannelCreatingEvent(INSTANCE_ID, CHANNEL_ID, false));
        verify(channelEvents).push(new PhysicalChannelCreatedEvent(INSTANCE_ID, CHANNEL_ID, false));

        // properties must include channel and EM/NE details
        final Map<String, String> properties = (Map) propertiesCaptor.getValue();
        assertThat(properties, allOf(
                hasEntry(WellKnownSettingsPropertyNames.RETRY_NE, "2"),
                hasEntry(WellKnownSettingsPropertyNames.DISCOVERY_POLICY, DiscoveryPolicy.DISCOVER_ALL_NETWORK.toString()),
                hasEntry(WellKnownSettingsPropertyNames.ENABLE_SCHEDULED_STARTUP, "true"),
                hasEntry(WellKnownSettingsPropertyNames.RETRY_MEDIATOR, "1"),
                hasEntry(WellKnownSettingsPropertyNames.RETRY_INTERVAL, "60"),
                hasEntry(WellKnownSettingsPropertyNames.SCALED_STARTUP_LIMIT, "50"),
                hasEntry(WellKnownChannelPropertyNames.ID_NAME, channel.getUserPreferences().getName())));
    }

    @Test
    public void testConnectUnknownChannelInstance() throws Exception {
        when(channelInstanceRepository.query(INSTANCE_ID)).thenReturn(Optional.empty());

        channelConnectionManager.connect(INSTANCE_ID);

        verify(loggerManager).createSystemEventLog(eq(context), any(LoggerItem[].class));
        verify(channelEvents).push(new PhysicalChannelActivationFailedEvent(INSTANCE_ID, 0, true, "Unknown Channel Instance ID 2"));
    }

    @Test
    public void testConnectUnknownChannel() throws RepositoryException {
        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.empty());

        when(channelUserPreferencesRepository.query(CHANNEL_ID)).thenReturn(Optional.of(
                new ChannelUserPreferencesBuilder().setName("name").build(CHANNEL_ID, 1)
            ));

        channelConnectionManager.connect(INSTANCE_ID);

        verifyErrorWasReported("Unknown Channel ID 1");
    }

    @Test
    public void testConnectChannelRepositoryError() throws RepositoryException {
        when(channelRepository.queryChannel(anyInt())).thenThrow(new RepositoryException());

        when(channelUserPreferencesRepository.query(CHANNEL_ID)).thenReturn(Optional.of(
                new ChannelUserPreferencesBuilder().setName("name").build(CHANNEL_ID, 1)
            ));

        channelConnectionManager.connect(INSTANCE_ID);

        verifyErrorWasReported("Unknown Channel ID 1");
    }

    @Test
    public void testConnectHasNoSupportedFacades() throws Exception {
        final String[] facets = {};

        when(connectionManager.createElementManager(eq(sessionContext), any(MediatorIdItem.class), any(IEM.class), any(Properties.class))).thenReturn(facets);

        channelConnectionManager.connect(INSTANCE_ID);

        verify(channelEvents).push(new PhysicalChannelCreatingEvent(INSTANCE_ID, CHANNEL_ID, false));
        verifyErrorWasReported("Channel id=1 has no supported facades.");
    }

    @Test
    public void testConnectError() throws Exception {
        when(connectionManager.createElementManager(eq(sessionContext), any(MediatorIdItem.class), any(IEM.class),  any(Properties.class))).thenThrow(new BcbException());

        channelConnectionManager.connect(INSTANCE_ID);

        verify(channelEvents).push(new PhysicalChannelCreatingEvent(INSTANCE_ID, CHANNEL_ID, false));
        verifyErrorWasReported("");
    }

    private void verifyErrorWasReported(String message) {
        verify(loggerManager).createSystemEventLog(eq(context), any(LoggerItem[].class));
        verify(channelEvents).push(new PhysicalChannelActivationFailedEvent(INSTANCE_ID, CHANNEL_ID, false, message));
    }

    @Test
    public void testUpdatedProperties() throws Exception {
        when(connectionManager.getFacade(any(ISessionContext.class), anyString(), any(IEMId.class))).thenReturn(elementManager);

        final IEM em = convert(CHANNEL_ID);
        channelConnectionManager.updateChannelProperties(em.getId(), new HashMap<>());

        verify(elementManager, times(1)).updateEM(sessionContext, new ElementManagerIdItem(em.getId()), EMMarkableItem.of(em), new Property[0]);
    }

    @Test
    public void testDisconnect() throws Exception {
        when(connectionManager.getFacade(any(ISessionContext.class), anyString(), any(IEMId.class))).thenReturn(elementManagerFactory);

        final IEM em = convert(CHANNEL_ID);

        channelConnectionManager.disconnect(INSTANCE_ID);

        //verify(elementManagerFactory, times(1)).deactivateElementManager(sessionContext, em.getEMId());
        verify(connectionManager, times(1)).deleteElementManager(sessionContext, new MediatorIdItem(em.getAssociatedMediatorId()), em);
//        verify(channelEvents).push(isA(ActualChannelStateEvent.ChannelDeactivatingEvent.class));
//        verify(channelEvents).push(isA(ActualChannelStateEvent.ChannelDeactivatedEvent.class));
    }

    @Test
    public void testDisconnectWithoutDao() throws Exception {
        when(connectionManager.getFacade(any(ISessionContext.class), anyString(), any(IEMId.class))).thenReturn(null);

        final IEM em = convert(CHANNEL_ID);

        channelConnectionManager.disconnect(INSTANCE_ID);

        verify(elementManagerFactory, never()).deactivateElementManager(sessionContext, em.getEMId());
        verify(connectionManager, times(1)).deleteElementManager(sessionContext, new MediatorIdItem(em.getAssociatedMediatorId()), em);
        verify(channelEvents).push(new PhysicalChannelDeactivatingEvent(INSTANCE_ID, CHANNEL_ID, false));
        verify(channelEvents).push(new PhysicalChannelDeactivatedEvent(INSTANCE_ID, CHANNEL_ID, false));
    }


    @Test
    public void testDisconnectWithErrorOnGetDao() throws Exception {
        when(connectionManager.getFacade(any(ISessionContext.class), anyString(), any(IEMId.class))).thenThrow(new PlatformException());

        when(channelUserPreferencesRepository.query(CHANNEL_ID)).thenReturn(Optional.of(
                new ChannelUserPreferencesBuilder().setName("name").build(CHANNEL_ID, 1)
            ));

        final IEM em = convert(CHANNEL_ID);

        channelConnectionManager.disconnect(INSTANCE_ID);

        verify(connectionManager, times(1)).deleteElementManager(sessionContext, new MediatorIdItem(em.getAssociatedMediatorId()), em);
        verify(channelEvents).push(new PhysicalChannelDeactivatingEvent(INSTANCE_ID, CHANNEL_ID, false));
        verify(channelEvents).push(new PhysicalChannelDeactivatedEvent(INSTANCE_ID, CHANNEL_ID, false));
    }

    @Test
    public void testDisconnectWithErrorDeactivating() throws Exception {
        when(connectionManager.getFacade(any(ISessionContext.class), anyString(), any(IEMId.class))).thenReturn(elementManagerFactory);

        doThrow(new PlatformException()).when(connectionManager).deleteElementManager(any(ISessionContext.class), any(IMediatorId.class), any(IEMId.class));

        when(channelUserPreferencesRepository.query(CHANNEL_ID)).thenReturn(Optional.of(
                new ChannelUserPreferencesBuilder().setName("name").build(CHANNEL_ID, 1)
            ));

        final IEM em = convert(1);

        channelConnectionManager.disconnect(INSTANCE_ID);

        verify(connectionManager, times(1)).deleteElementManager(sessionContext, new MediatorIdItem(em.getAssociatedMediatorId()),em);
        verify(channelEvents).push(new PhysicalChannelDeactivatingEvent(INSTANCE_ID, CHANNEL_ID, false));
        verify(channelEvents).push(new PhysicalChannelDeactivatedEvent(INSTANCE_ID, CHANNEL_ID, false));

    }

    @Test
    public void testFindChannelName() throws RepositoryException {

        when(channelUserPreferencesRepository.query(CHANNEL_ID))
            .thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName("name").build(CHANNEL_ID, 1)))
            .thenReturn(Optional.empty())
            .thenThrow(new RepositoryException());

        assertThat(channelConnectionManager.findChannelName(CHANNEL_ID), is("name"));
        assertThat(channelConnectionManager.findChannelName(CHANNEL_ID), is("EM="+CHANNEL_ID));
        assertThat(channelConnectionManager.findChannelName(CHANNEL_ID), is("EM="+CHANNEL_ID));
    }
}
