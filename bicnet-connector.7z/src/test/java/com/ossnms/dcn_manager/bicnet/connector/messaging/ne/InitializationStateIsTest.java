package com.ossnms.dcn_manager.bicnet.connector.messaging.ne;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementProxyItem;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxyMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;
import com.ossnms.dcn_manager.bicnet.connector.messaging.ne.InitializationStateIs;

public class InitializationStateIsTest {

    @Test
    public void equality() {
        assertTrue(new InitializationStateIs(InitState.INITIALIZED).call(buildMarkable(InitState.INITIALIZED)));
        assertTrue(new InitializationStateIs(InitState.INITIALIZING).call(buildMarkable(InitState.INITIALIZING)));
        assertTrue(new InitializationStateIs(InitState.NOT_INITIALIZED).call(buildMarkable(InitState.NOT_INITIALIZED)));
        assertTrue(new InitializationStateIs(InitState.NOT_SYNCHRONIZED).call(buildMarkable(InitState.NOT_SYNCHRONIZED)));
        assertTrue(new InitializationStateIs(InitState.SHUTTING_DOWN).call(buildMarkable(InitState.SHUTTING_DOWN)));
        assertTrue(new InitializationStateIs(InitState.FAILED).call(buildMarkable(InitState.FAILED)));
    }

    @Test
    public void nullState_notEquals() {
        assertFalse(new InitializationStateIs(InitState.INITIALIZED).call(buildMarkable(null)));
        assertFalse(new InitializationStateIs(InitState.INITIALIZING).call(buildMarkable(null)));
        assertFalse(new InitializationStateIs(InitState.NOT_INITIALIZED).call(buildMarkable(null)));
        assertFalse(new InitializationStateIs(InitState.NOT_SYNCHRONIZED).call(buildMarkable(null)));
        assertFalse(new InitializationStateIs(InitState.SHUTTING_DOWN).call(buildMarkable(null)));
        assertFalse(new InitializationStateIs(InitState.FAILED).call(buildMarkable(null)));
    }

    @Test
    public void unmarked_notEquals() {
        assertFalse(new InitializationStateIs(InitState.INITIALIZED).call(buildUnmarked(InitState.INITIALIZED)));
        assertFalse(new InitializationStateIs(InitState.INITIALIZING).call(buildUnmarked(InitState.INITIALIZING)));
        assertFalse(new InitializationStateIs(InitState.NOT_INITIALIZED).call(buildUnmarked(InitState.NOT_INITIALIZED)));
        assertFalse(new InitializationStateIs(InitState.NOT_SYNCHRONIZED).call(buildUnmarked(InitState.NOT_SYNCHRONIZED)));
        assertFalse(new InitializationStateIs(InitState.SHUTTING_DOWN).call(buildUnmarked(InitState.SHUTTING_DOWN)));
        assertFalse(new InitializationStateIs(InitState.FAILED).call(buildUnmarked(InitState.FAILED)));
    }

    private INetworkElementProxyMarkable buildMarkable(InitState state) {
        final INetworkElementProxyMarkable nem = new NetworkElementProxyItem().toMarkableNetworkElementProxy();
        nem.setInitState(state);
        return nem;
    }

    private INetworkElementProxyMarkable buildUnmarked(InitState state) {
        final NetworkElementProxyItem nep = new NetworkElementProxyItem();
        nep.setInitState(state);
        return nep.toMarkableNetworkElementProxy();
    }

}
