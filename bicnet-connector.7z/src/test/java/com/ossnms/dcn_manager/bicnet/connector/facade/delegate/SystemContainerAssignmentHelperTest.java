package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentMarkable;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentUpdatedEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SystemContainerAssignmentHelperTest {
    private static final int SYSTEM_ID = 1;
    private static final int CONTAINER_ID = 2;
    private static final int VERSION = 100;

    @Mock private ISessionContext sessionContext;
    @Mock private JpaSystemRepositoryBean systemRepository;
    @Mock private JpaContainerRepositoryBean containerRepository;
    @Mock private JpaSettingsRepositoryBean settingsRepository;
    @Mock private ContainerNotifications notifications;
    @Mock private LoggerManagerImpl loggerManager;

    private SystemContainerAssignmentHelper helper;

    @Before public void setUp() throws Exception {
        helper = new SystemContainerAssignmentHelper();

        helper.setContainerRepository(containerRepository);
        helper.setLoggerManager(loggerManager);
        helper.setNotifications(notifications);
        helper.setSystemRepository(systemRepository);
        helper.setSettingsRepository(settingsRepository);
    }

    @Test public void getSingleSystemGenericContainerAssignment() throws Exception {
        SystemAssignmentData systemAssignmentData = new SystemAssignmentData(
                new ContainerInfo(CONTAINER_ID, VERSION, "container_name"), SYSTEM_ID, AssignmentType.PRIMARY);

        when(containerRepository.querySystemAssignment(SYSTEM_ID, CONTAINER_ID))
                .thenReturn(Optional.of(systemAssignmentData));

        ISystemGenericContainerAssignmentId assignmentId = new SystemGenericContainerAssignmentIdItem(SYSTEM_ID,
                CONTAINER_ID);

        final ISystemGenericContainerAssignment containerAssignment = helper
                .getSingleSystemGenericContainerAssignment(sessionContext, assignmentId);

        assertThat(containerAssignment.getGenericContainerId(), is(CONTAINER_ID));
        assertThat(containerAssignment.getSystemContainerId(), is(SYSTEM_ID));

        verify(containerRepository, times(1)).querySystemAssignment(SYSTEM_ID, CONTAINER_ID);
    }

    @Test public void createSystemGenericContainerAssignment() throws Exception {
        ISystemGenericContainerAssignment systemAssignment = new SystemGenericContainerAssignmentItem();
        systemAssignment.setSystemContainerId(SYSTEM_ID);
        systemAssignment.setGenericContainerId(CONTAINER_ID);
        systemAssignment.setPrimary(true);

        when(containerRepository.query(CONTAINER_ID))
                .thenReturn(Optional.of(new ContainerInfo(CONTAINER_ID, VERSION, "container_name")));

        when(systemRepository.query(SYSTEM_ID)).
                thenReturn(Optional.of(new SystemInfo(SYSTEM_ID, VERSION, "system_name")));

        helper.createSystemGenericContainerAssignment(sessionContext, systemAssignment);

        verify(containerRepository, times(1)).query(CONTAINER_ID);
        verify(systemRepository, times(1)).query(SYSTEM_ID);
        verify(notifications, times(1)).notifyChanges(Matchers.any(ContainerSystemAssignmentAddedEvent.class));
    }

    @Test public void deleteSystemGenericContainerAssignment() throws Exception {
        SystemAssignmentData systemAssignmentData1 = new SystemAssignmentData(
                new ContainerInfo(CONTAINER_ID, VERSION, "container_name"), SYSTEM_ID, AssignmentType.LOGICAL);

        SystemAssignmentData systemAssignmentData2 = new SystemAssignmentData(
                new ContainerInfo(3, VERSION, "container_name2"), SYSTEM_ID, AssignmentType.PRIMARY);

        when(containerRepository.querySystemAssignment(SYSTEM_ID, CONTAINER_ID))
                .thenReturn(Optional.of(systemAssignmentData1));

        when(systemRepository.query(SYSTEM_ID)).
                thenReturn(Optional.of(new SystemInfo(SYSTEM_ID, VERSION, "system_name")));

        when(containerRepository.queryAllBySystem(SYSTEM_ID)).thenReturn(ImmutableList.of(systemAssignmentData1,
                systemAssignmentData2));

        ISystemGenericContainerAssignmentId assignmentId = new SystemGenericContainerAssignmentIdItem(SYSTEM_ID,
                CONTAINER_ID);

        when(containerRepository.tryRemoveSystemAssignment(systemAssignmentData1)).thenReturn(true);

        helper.deleteSystemGenericContainerAssignment(sessionContext, assignmentId);

        verify(systemRepository, times(1)).query(SYSTEM_ID);
        verify(notifications, times(1)).notifyChanges(Matchers.any(ContainerSystemAssignmentRemovedEvent.class));
    }

    @Test
    public void deleteSystemGenericContainerAssignment_last_assignment() throws Exception {
        SystemAssignmentData systemAssignmentData1 = new SystemAssignmentData(
                new ContainerInfo(CONTAINER_ID, VERSION, "container_name"), SYSTEM_ID, AssignmentType.LOGICAL);
        final GlobalSettings globalSettings = GlobalSettings.build().toGlobalSettings(1, 1);

        when(containerRepository.querySystemAssignment(SYSTEM_ID, CONTAINER_ID))
                .thenReturn(Optional.of(systemAssignmentData1));
        when(containerRepository.queryAllBySystem(SYSTEM_ID)).thenReturn(ImmutableList.of(systemAssignmentData1));
        when(settingsRepository.getSettings()).thenReturn(globalSettings);
        when(systemRepository.query(SYSTEM_ID)).
                thenReturn(Optional.of(new SystemInfo(SYSTEM_ID, VERSION, "system_name")));
        when(containerRepository.queryByName(globalSettings.getDefaultContainerName()))
                .thenReturn(Optional.of(new ContainerInfo(CONTAINER_ID, VERSION, globalSettings.getDefaultContainerName())));
        when(containerRepository.queryAllBySystem(SYSTEM_ID)).thenReturn(ImmutableList.of(systemAssignmentData1));

        ISystemGenericContainerAssignmentId assignmentId = new SystemGenericContainerAssignmentIdItem(SYSTEM_ID,
                CONTAINER_ID);

        when(containerRepository.tryRemoveSystemAssignment(systemAssignmentData1)).thenReturn(true);

        helper.deleteSystemGenericContainerAssignment(sessionContext, assignmentId);
    }

    @Test public void modifySystemGenericContainerAssignment() throws Exception {
        final ISystemGenericContainerAssignmentMarkable markableInput = SystemGenericContainerAssignmentItem
                .markableSystemGenericContainerAssignment(null);

        markableInput.setGenericContainerId(CONTAINER_ID);
        markableInput.setSystemContainerId(SYSTEM_ID);
        markableInput.setPrimary(true);

        when(containerRepository.query(CONTAINER_ID))
                .thenReturn(Optional.of(new ContainerInfo(CONTAINER_ID, VERSION, "container_name")));

        when(systemRepository.query(SYSTEM_ID)).
                thenReturn(Optional.of(new SystemInfo(SYSTEM_ID, VERSION, "system_name")));

        when(containerRepository.tryUpdateSystemAssignment(Matchers.any(SystemAssignmentData.class))).thenReturn(true);

        final ISystemGenericContainerAssignmentMarkable markableResult = helper
                .modifySystemGenericContainerAssignment(sessionContext, markableInput);

        assertThat(markableInput, is(markableResult));

        verify(containerRepository, times(1)).query(CONTAINER_ID);
        verify(systemRepository, times(1)).query(SYSTEM_ID);
        verify(notifications, times(1)).notifyChanges(Matchers.any(ContainerSystemAssignmentUpdatedEvent.class));
    }
}