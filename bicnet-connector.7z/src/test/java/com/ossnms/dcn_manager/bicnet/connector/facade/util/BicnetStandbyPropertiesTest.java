package com.ossnms.dcn_manager.bicnet.connector.facade.util;

import com.ossnms.bicnet.bcb.facade.scs.IScsFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.scs.ScsSiteConfiguration;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BicnetStandbyPropertiesTest {

    private IScsFacade scs;
    private ISessionContext context;

    @Before
    public void setUp() throws Exception {
        scs = mock(IScsFacade.class);
        context = mock(ISessionContext.class);
    }

    @Test
    public void testGetProperties() throws Exception {
        when(scs.getSiteConfiguration(context)).thenReturn(ScsSiteConfiguration.PRIMARY);
        when(scs.isStandbyConfigured(context)).thenReturn(true);

        final Map<String, String> properties = BicnetStandbyProperties.getProperties(context, scs);
        assertThat(properties, allOf(
                hasEntry("SITE_ROLE", "primary"),
                hasEntry("STANDBY_CONFIGURED", "true")
        ));
    }

    @Test
    public void testGetProperties_siteConfig_exception() throws Exception {
        when(scs.getSiteConfiguration(context)).thenThrow(new BcbException());
        when(scs.isStandbyConfigured(context)).thenReturn(true);

        final Map<String, String> properties = BicnetStandbyProperties.getProperties(context, scs);
        assertThat(properties.isEmpty(), is(true));
    }

    @Test
    public void testGetProperties_standbyConfig_exception() throws Exception {
        when(scs.getSiteConfiguration(context)).thenReturn(ScsSiteConfiguration.PRIMARY);
        when(scs.isStandbyConfigured(context)).thenThrow(new BcbException());

        final Map<String, String> properties = BicnetStandbyProperties.getProperties(context, scs);
        assertThat(properties.isEmpty(), is(true));
    }
}