package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerMarkable;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.container.entities.QContainerInfoDb;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import javax.persistence.PersistenceException;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ContainerHelperTest {

    protected static final int CONTAINER_ID = 76;

    @Mock private ContainerNotifications notifications;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private JpaContainerRepositoryBean repository;
    @Mock private JpaSystemRepositoryBean systemRepository;

    @InjectMocks private ContainerHelper helper;

    @Test
    public void deleteGenericContainer() throws Exception {
        when(repository.query(anyInt())).thenReturn(Optional.of(new ContainerInfo(CONTAINER_ID, 1, "name")));

        helper.deleteGenericContainer(null, new GenericContainerIdItem(CONTAINER_ID));

        verify(repository).delete(isA(ContainerDeletionDescriptor.class));
    }

    @Test(expected=BcbException.class)
    public void deleteGenericContainer_repositoryError_throws() throws Exception {

        when(repository.query(anyInt())).thenThrow(new RepositoryException());

        helper.deleteGenericContainer(null, new GenericContainerIdItem(CONTAINER_ID));
    }

    @Test
    public void deleteGenericContainer_unknownId() throws Exception {

        when(repository.query(anyInt())).thenReturn(Optional.empty());

        helper.deleteGenericContainer(null, new GenericContainerIdItem(CONTAINER_ID));

        verify(repository, never()).delete(isA(ContainerDeletionDescriptor.class));
    }

    @Test
    public void createGenericContainer() throws Exception {
        when(systemRepository.queryByName(anyString())).thenReturn(Optional.empty());
        when(repository.queryByName(anyString())).thenReturn(Optional.empty());
        when(repository.create(any(ContainerCreationDescriptor.class))).then(new Answer<ContainerInfo>() {
            @Override
            public ContainerInfo answer(InvocationOnMock invocation) {
                final ContainerCreationDescriptor desc = (ContainerCreationDescriptor) invocation.getArguments()[0];
                return new ContainerInfo(CONTAINER_ID, 1, desc.getName());
            }
        });

        final GenericContainerItem item = new GenericContainerItem();
        item.setIdName("name");
        final IGenericContainer container = helper.createGenericContainer(null, item);

        assertThat(container, is(notNullValue()));
        assertThat(container.getIdName(), is(item.getIdName()));
        assertThat(container.getId(), is(CONTAINER_ID));
    }

    @Test(expected=BcbException.class)
    public void createGenericContainer_repositoryError_throws() throws Exception {

        when(repository.queryByName(anyString())).thenThrow(new RepositoryException());
        when(repository.create(any(ContainerCreationDescriptor.class))).thenThrow(new RepositoryException());

        final GenericContainerItem item = new GenericContainerItem();
        item.setIdName("name");
        helper.createGenericContainer(null, item);
    }

    @Test(expected=BcbException.class)
    public void createGenericContainer_noName_throws() throws Exception {

        when(repository.create(any(ContainerCreationDescriptor.class))).then(new Answer<ContainerInfo>() {
            @Override
            public ContainerInfo answer(InvocationOnMock invocation) {
                final ContainerCreationDescriptor desc = (ContainerCreationDescriptor) invocation.getArguments()[0];
                return new ContainerInfo(CONTAINER_ID, 1, desc.getName());
            }
        });

        final GenericContainerItem item = new GenericContainerItem();
        item.setIdName("");
        final IGenericContainer container = helper.createGenericContainer(null, item);

        assertThat(container, is(notNullValue()));
        assertThat(container.getIdName(), is(item.getIdName()));
        assertThat(container.getId(), is(CONTAINER_ID));
    }

    @Test(expected=BcbException.class)
    public void getSingleGenericContainer_repositoryError_throws() throws Exception {
        when(repository.query(anyInt())).thenThrow(new RepositoryException());

        helper.getSingleGenericContainer(null, new GenericContainerIdItem(12));
    }

    @Test(expected=BcbException.class)
    public void getGenericContainerList_repositoryError_throws() throws Exception {
        final JpaCloseableQuery query = mock(JpaCloseableQuery.class);

        when(repository.query(any(QContainerInfoDb.class))).thenReturn(query);
        when(query.list(any(QContainerInfoDb.class))).thenThrow(new PersistenceException());

        helper.getGenericContainerList(null, null, null, -1);
    }

    @Test(expected=BcbException.class)
    public void getGenericContainerIdList_repositoryError_throws() throws Exception {
        final JpaCloseableQuery query = mock(JpaCloseableQuery.class);

        when(repository.query(any(QContainerInfoDb.class))).thenReturn(query);
        when(query.list(any(QContainerInfoDb.class))).thenThrow(new PersistenceException());

        helper.getGenericContainerIdList(null, null, null, -1);
    }

    @Test
    public void modifyGenericContainer_unknownContainer_doesNothing() throws Exception {
        when(repository.query(anyInt())).thenReturn(Optional.empty());

        helper.modifyGenericContainer(null, GenericContainerItem.markableGenericContainer(null));

        verifyZeroInteractions(notifications);
        verify(repository, never()).tryUpdate(isA(ContainerInfoMutationDescriptor.class));
    }

    @Test
    public void modifyGenericContainer_repoErrorOnConversion_doesNothing() throws Exception {
        when(repository.query(anyInt())).thenThrow(new RepositoryException());

        helper.modifyGenericContainer(null, GenericContainerItem.markableGenericContainer(null));

        verifyZeroInteractions(notifications);
        verify(repository, never()).tryUpdate(isA(ContainerInfoMutationDescriptor.class));
    }

    @Test(expected=BcbException.class)
    public void modifyGenericContainer_repoErrorOnUpdate_throws() throws Exception {
        when(repository.query(CONTAINER_ID)).thenReturn(Optional.of(new ContainerInfo(CONTAINER_ID, 0, "c1")));
        when(repository.tryUpdate(isA(ContainerInfoMutationDescriptor.class))).thenThrow(new RepositoryException());

        final IGenericContainerMarkable markable = GenericContainerItem.markableGenericContainer(null);
        markable.setId(CONTAINER_ID);
        helper.modifyGenericContainer(null, markable);
    }

    @Test
    public void modifyGenericContainer() throws Exception {
        final ArgumentCaptor<ContainerInfoMutationDescriptor> mutationCaptor = ArgumentCaptor.forClass(ContainerInfoMutationDescriptor.class);

        when(repository.query(CONTAINER_ID)).thenReturn(Optional.of(new ContainerInfo(CONTAINER_ID, 0, "c1")));
        when(repository.tryUpdate(isA(ContainerInfoMutationDescriptor.class))).then(new MutationAnswer<>());
        when(repository.queryByName(anyString())).thenReturn(Optional.empty());
        when(systemRepository.queryByName(anyString())).thenReturn(Optional.empty());

        final IGenericContainerMarkable markable = GenericContainerItem.markableGenericContainer(null);
        markable.setId(CONTAINER_ID);
        markable.setDescription("d1");
        markable.setUserLabel("u1");
        markable.setIdName("n1");
        markable.setParentId(42);

        helper.modifyGenericContainer(null, markable);

        verify(repository).tryUpdate(mutationCaptor.capture());
        verify(notifications).notifyChanges(mutationCaptor.getValue());

        final ContainerInfoMutationDescriptor mutation = mutationCaptor.getValue();
        assertThat(mutation.getResult(), is(new ContainerInfo(CONTAINER_ID, 1, Optional.of(42), "n1", Optional.of("d1"), Optional.of("u1"))));
    }
}
