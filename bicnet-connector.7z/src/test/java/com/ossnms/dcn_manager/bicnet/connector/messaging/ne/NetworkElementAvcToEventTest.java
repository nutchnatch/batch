package com.ossnms.dcn_manager.bicnet.connector.messaging.ne;

import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.ossnms.bicnet.bcb.facade.elementMgmt.CommissioningStatusSummaryPkgItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.GatewayConfigurationPkgItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.WriteAccessStatePkgItem;
import com.ossnms.bicnet.bcb.model.IMoFacet;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.GatewayRole;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary;
import com.ossnms.bicnet.bcb.model.elementMgmt.ICommissioningStatusSummaryPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.ICommissioningStatusSummaryPkgMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.IGatewayConfigurationPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.IGatewayConfigurationPkgMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.IWriteAccessStatePkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.IWriteAccessStatePkgMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.NeFamily;
import com.ossnms.bicnet.bcb.model.elementMgmt.NeSubType;
import com.ossnms.bicnet.bcb.model.elementMgmt.NeType;
import com.ossnms.bicnet.bcb.model.elementMgmt.TpGroupMode;
import com.ossnms.bicnet.bcb.model.elementMgmt.WriteAccessState;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.PlatformException;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.CommissioningMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.OperationalMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.types.WriteAccessMode;
import com.ossnms.dcn_manager.core.events.ne.NeOperationInfoChangedEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class NetworkElementAvcToEventTest {

    private static final int NE_ID = 42;
    private static final String NE_TYPE = "neType";
    private static final int CHANNEL_ID = 2;
    private static final int VERSION = 0;

    @Mock private JpaNetworkElementRepositoryBean neRepository;
    @Mock private NeInfoRepository neInfoRepository;
    @Mock private com.ossnms.dcn_manager.core.configuration.model.NeType type;
    @Mock private StaticConfiguration configuration;
    @Mock private Types<com.ossnms.dcn_manager.core.configuration.model.NeType> neTypes;
    private NeInfoData neInfoData;
    private BiMap<String, String> neIdControlMap;

    private NeOperationInfoChanged neOperationInfoChanged;


    @Before
    public void setUp() throws PlatformException, UnsupportedOperationException, RepositoryException {
        neIdControlMap = ImmutableBiMap.of(WellKnownNePropertyNames.NEIGHBOURHOOD_ID, WellKnownNePropertyNames.TL1_ID);
        neInfoData = new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_ID, VERSION);

        when(configuration.getNeTypes()).thenReturn(neTypes);
        when(neTypes.get(anyString())).thenReturn(type);
        when(neRepository.getNeInfoRepository()).thenReturn(neInfoRepository);
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(neInfoData));
        when(type.getIdentificationControlMap()).thenReturn(neIdControlMap);
        //when(neInfoData.getProxyType()).thenReturn(NE_TYPE);

        neOperationInfoChanged = new NeOperationInfoChanged(neRepository, configuration);
    }

    @Test
    public void testMarked() {
        final INetworkElementMarkable item = buildNetworkElement();

        final NeOperationInfoChangedEvent event = neOperationInfoChanged.call(new AttributeValueChange(new Date(), item));

        assertThat(event.getNeId(), is(42));
        assertThat(event.getRealNeName().get(), is("ne_name"));
        assertThat(event.getNeighbourhoodId().get(), is("tid"));
        assertThat(event.getEventForwardingActive().get(), is(true));
        assertThat(event.getTpGroupMask().get(), is(1234L));
        assertThat(event.getTpGroupMode().get(), is(new TpGroupSettings(true, true, true, true)));
        assertThat(event.getFamily().get(), is(item.getNeFamily().name()));
        assertThat(event.getMainRelease().get(), is("main"));
        assertThat(event.getMaintenanceRelease().get(), is("maintenance"));
        assertThat(event.getNeSubType().get(), is(NeSubType.ADU.name()));
        assertThat(event.getNeType().get(), is(NeType._7090_240.name()));
        assertThat(event.getNeSpecificType().get(), is("specific"));
        assertThat(event.getOperationalMode().get(), is(OperationalMode.ENABLED));
        assertThat(event.getWriteAccess().get(), is(WriteAccessMode.NE_PROXY_AND_CLIENT_EM));
        assertThat(event.getCommissioning().get(), is(CommissioningMode.PARTIALLY_COMMISSIONED));
        assertThat(event.getGatewayMode().get(), is(GatewayMode.PRIMARY));
    }

    @Test
    public void testMarkedWithoutFacets() {
        final INetworkElementMarkable item = buildNetworkElement();
        item.removeOptionalFacet(IWriteAccessStatePkg.class);
        item.removeOptionalFacet(ICommissioningStatusSummaryPkg.class);
        item.removeOptionalFacet(IGatewayConfigurationPkg.class);

        final NeOperationInfoChangedEvent event = neOperationInfoChanged.call(new AttributeValueChange(new Date(), item));

        assertThat(event.getNeId(), is(42));
        assertThat(event.getRealNeName().get(), is("ne_name"));
        assertThat(event.getNeighbourhoodId().get(), is("tid"));
        assertThat(event.getEventForwardingActive().get(), is(true));
        assertThat(event.getTpGroupMask().get(), is(1234L));
        assertThat(event.getTpGroupMode().get(), is(new TpGroupSettings(true, true, true, true)));
        assertThat(event.getFamily().get(), is(item.getNeFamily().name()));
        assertThat(event.getMainRelease().get(), is("main"));
        assertThat(event.getMaintenanceRelease().get(), is("maintenance"));
        assertThat(event.getNeSubType().get(), is(NeSubType.ADU.name()));
        assertThat(event.getNeType().get(), is(NeType._7090_240.name()));
        assertThat(event.getNeSpecificType().get(), is("specific"));
        assertThat(event.getOperationalMode().get(), is(OperationalMode.ENABLED));
        assertThat(event.getGatewayMode(), is(absent()));
        assertThat(event.getWriteAccess(), is(absent()));
        assertThat(event.getCommissioning(), is(absent()));
    }

    @Test
    public void testUnmarked() {
        final INetworkElementMarkable item = NetworkElementItem.markableNetworkElement(new IMoFacet[] {
                WriteAccessStatePkgItem.markableWriteAccessStatePkg(),
                CommissioningStatusSummaryPkgItem.markableCommissioningStatusSummaryPkg(),
                GatewayConfigurationPkgItem.markableGatewayConfigurationPkg()
            });
        item.setNeId(42);

        final NeOperationInfoChangedEvent event = neOperationInfoChanged.call(new AttributeValueChange(new Date(), item));

        assertThat(event.getNeId(), is(42));
        assertThat(event.getRealNeName(), is(absent()));
        assertThat(event.getNeighbourhoodId(), is(absent()));
        assertThat(event.getEventForwardingActive(), is(absent()));
        assertThat(event.getTpGroupMask(), is(absent()));
        assertThat(event.getTpGroupMode(), is(absent()));
        assertThat(event.getFamily(), is(absent()));
        assertThat(event.getMainRelease(), is(absent()));
        assertThat(event.getMaintenanceRelease(), is(absent()));
        assertThat(event.getNeSubType(), is(absent()));
        assertThat(event.getNeType(), is(absent()));
        assertThat(event.getNeSpecificType(), is(absent()));
        assertThat(event.getOperationalMode(), is(absent()));
        assertThat(event.getWriteAccess(), is(absent()));
        assertThat(event.getCommissioning(), is(absent()));
        assertThat(event.getGatewayMode(), is(absent()));
    }

    private INetworkElementMarkable buildNetworkElement() {
        final IWriteAccessStatePkgMarkable markableWriteAccessStatePkg = WriteAccessStatePkgItem.markableWriteAccessStatePkg();
        markableWriteAccessStatePkg.setWriteAccessState(WriteAccessState.NE_PROXY_AND_CLIENT_EM);
        
        final ICommissioningStatusSummaryPkgMarkable markableCommissioningStatusSummaryPkg = CommissioningStatusSummaryPkgItem.markableCommissioningStatusSummaryPkg();
        markableCommissioningStatusSummaryPkg.setCommissioningStatusSummary(CommissioningStatusSummary.PARTIALLY_COMMISSIONED);
        
        final IGatewayConfigurationPkgMarkable gatewayConfigurationMarkable = GatewayConfigurationPkgItem.markableGatewayConfigurationPkg();
        gatewayConfigurationMarkable.setGatewayRole(GatewayRole.PRIMARY);
        
        final INetworkElementMarkable item = NetworkElementItem.markableNetworkElement(new IMoFacet[] {
                markableCommissioningStatusSummaryPkg, markableWriteAccessStatePkg, gatewayConfigurationMarkable
        });

        item.setEventForwarding(EnableSwitch.ENABLED);
        item.setTpGroupMask(1234);
        item.setTpGroupMode(new TpGroupMode(true, true, true, true));
        item.setNeFamily(NeFamily._7090_M);
        item.setMainRelease("main");
        item.setMaintenanceRelease("maintenance");
        item.setNeType(NeType._7090_240);
        item.setNeSubType(NeSubType.ADU);
        item.setSpecificType("specific");
        item.setOperationalState(OperationalState.ENABLED);
        item.setName("ne_name");
        item.setTid("tid");
        item.setNeId(42);
        return item;
    }

}
