package com.ossnms.dcn_manager.bicnet.connector.outbound.connection;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.platform.IConnectionManager;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.platform.BcbSessionRole;
import com.ossnms.bicnet.bcb.model.platform.DuplicatedSessionException;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.messaging.MediatorEventSource;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import java.util.Optional;
import java.util.Properties;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertIntegerToBcbEm.convert;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.hamcrest.Matchers.hasEntry;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MediatorConnectionManagerImplTest {

    private static final int MEDIATOR_ID = 1;
    private static final int PRIMARY_INSTANCE_ID = 33;
    private static final int SECONDARY_INSTANCE_ID = 44;

    private ChannelType channelType;
    private Types<ChannelType> channelTypes;
    private MediatorType mediatorType;
    private Types<MediatorType> mediatorTypes;
    private BicnetCallContext context;

    private IConnectionManager connectionManager;
    private ISessionContext sessionContext;
    private StaticConfigurationSingleton configuration;
    private MediatorConnectionManagerImpl mediatorConnectionManager;
    private MediatorEntityRepository mediatorRepository;
    private MediatorInstanceEntityRepository mediatorInstanceRepository;
    private LoggerManager<BicnetCallContext> loggerManager;
    private JpaSettingsRepositoryBean settingsRepository;
    private MediatorEventSource mediatorEvents;

    private GlobalSettings globalSettings;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws RepositoryException {
        mediatorType = MockFactory.mockMediatorType();
        mediatorTypes = mock(Types.class);
        channelType = MockFactory.mockEmType();
        channelTypes = mock(Types.class);
        context = mock(BicnetCallContext.class);

        connectionManager = mock(IConnectionManager.class);
        sessionContext = mock(ISessionContext.class);
        configuration = mock(StaticConfigurationSingleton.class);
        mediatorRepository = mock(MediatorEntityRepository.class);
        mediatorInstanceRepository = mock(MediatorInstanceEntityRepository.class);
        loggerManager = mock(LoggerManager.class);
        settingsRepository = mock(JpaSettingsRepositoryBean.class);
        mediatorEvents = mock(MediatorEventSource.class);

        final int RECONNECT_INTERVAL = 60;
        final int VERSION = 1;
        mediatorConnectionManager = new MediatorConnectionManagerImpl(context, connectionManager,
                configuration, settingsRepository, mediatorRepository, mediatorInstanceRepository, loggerManager,
                mediatorEvents);

        globalSettings = GlobalSettings.build()
                .setDiscoveryPolicy(DiscoveryPolicy.DISCOVER_ALL_NETWORK)
                .setMediatorRetries(1)
                .setNeRetries(2)
                .setEnableScheduledStartup(true)
                .setRetryInterval(RECONNECT_INTERVAL)
                .setScaledStartupLimit(50)
                .toGlobalSettings(1,1);

        when(context.getSessionContext()).thenReturn(sessionContext);
        when(channelType.getName()).thenReturn("typeName");
        when(mediatorType.getConnectionManagerProviderClass()).thenReturn("providerClass");
        when(channelType.getDefaultIcon()).thenReturn("icons");
        when(configuration.getChannelTypes()).thenReturn(channelTypes);
        when(configuration.getMediatorTypes()).thenReturn(mediatorTypes);
        when(channelTypes.get("typeName")).thenReturn(channelType);
        when(mediatorTypes.get(anyString())).thenReturn(mediatorType);

        when(mediatorRepository.query(anyInt())).thenReturn(Optional.of(
                new MediatorEntity(
                    new MediatorInfoBuilder().setName("name").setTypeName("type").build(MEDIATOR_ID, 1),
                    new MediatorConnectionBuilder().build(MEDIATOR_ID, 1))
            ));

        when(mediatorInstanceRepository.query(PRIMARY_INSTANCE_ID)).thenReturn(Optional.of(
                new MediatorInstance(
                        new MediatorPhysicalDataBuilder().setHost("localhost").setPriority(MediatorInstance.PRIMARY_PRIORITY_LEVEL).build(PRIMARY_INSTANCE_ID, MEDIATOR_ID, VERSION),
                        new MediatorPhysicalConnectionBuilder().setActive(true).build(PRIMARY_INSTANCE_ID, MEDIATOR_ID, VERSION))
            ));
        when(mediatorInstanceRepository.query(SECONDARY_INSTANCE_ID)).thenReturn(Optional.of(
                new MediatorInstance(
                        new MediatorPhysicalDataBuilder().setHost("localhost").setPriority(MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1).build(SECONDARY_INSTANCE_ID, MEDIATOR_ID, VERSION),
                        new MediatorPhysicalConnectionBuilder().setActive(false).build(SECONDARY_INSTANCE_ID, MEDIATOR_ID, VERSION))
            ));

        when(configuration.getChannelTypes().get(Mockito.anyString())).thenReturn(channelType);

        when(settingsRepository.getSettings()).thenReturn(globalSettings);
    }

    @Test
    public void testConnect_withComposedTypeProperties() throws ConnectException, BcbException {
        final ArgumentCaptor<Properties> propertiesCaptor = ArgumentCaptor.forClass(Properties.class);
        final IMediatorId medId = new MediatorIdItem(PRIMARY_INSTANCE_ID);

        when(mediatorType.getTypeProperties()).thenReturn(ImmutableMap.of("a", "A", "h", "- ${Property.BCB-Attribute/Mediator/host} -"));

        mediatorConnectionManager.connect(PRIMARY_INSTANCE_ID);

        verify(connectionManager).connect(eq(sessionContext), eq(medId), propertiesCaptor.capture(), eq(BcbSessionRole.ACTIVE));
        verify(mediatorEvents).push(isA(PhysicalMediatorActivatingEvent.class));
        verify(mediatorEvents).push(isA(PhysicalMediatorActivatedEvent.class));

        assertThat(propertiesCaptor.getValue(), hasEntry("h", "- localhost -"));
        assertThat(propertiesCaptor.getValue(), hasEntry("a", "A"));
    }

    @Test
    public void testConnect_activeInstance() throws ConnectException, BcbException {
        final IMediatorId medId = new MediatorIdItem(PRIMARY_INSTANCE_ID);

        mediatorConnectionManager.connect(PRIMARY_INSTANCE_ID);

        verify(connectionManager).connect(eq(sessionContext), eq(medId), any(Properties.class), eq(BcbSessionRole.ACTIVE));
        verify(mediatorEvents).push(new PhysicalMediatorActivatingEvent(PRIMARY_INSTANCE_ID, MEDIATOR_ID, true));
        verify(mediatorEvents).push(new PhysicalMediatorActivatedEvent(PRIMARY_INSTANCE_ID, MEDIATOR_ID, true));
    }

    @Test
    public void testConnect_inactiveInstance() throws ConnectException, BcbException {
        final IMediatorId medId = new MediatorIdItem(SECONDARY_INSTANCE_ID);

        mediatorConnectionManager.connect(SECONDARY_INSTANCE_ID);

        verify(connectionManager).connect(eq(sessionContext), eq(medId), any(Properties.class), eq(BcbSessionRole.STANDBY));
        verify(mediatorEvents).push(new PhysicalMediatorActivatingEvent(SECONDARY_INSTANCE_ID, MEDIATOR_ID, false));
        verify(mediatorEvents).push(new PhysicalMediatorActivatedEvent(SECONDARY_INSTANCE_ID, MEDIATOR_ID, false));
    }

    @Test
    public void testConnectMediatorRepositoryError() throws RepositoryException {
        when(mediatorRepository.query(anyInt())).thenThrow(new RepositoryException());
        when(mediatorInstanceRepository.query(anyInt())).thenThrow(new RepositoryException());

        mediatorConnectionManager.connect(PRIMARY_INSTANCE_ID);

        verifyErrorWasReported();
    }

    @Test
    public void testConnectError() throws ConnectException, BcbException, RepositoryException {
        doThrow(new BcbException()).when(connectionManager).connect(eq(sessionContext), any(MediatorIdItem.class), any(Properties.class), any(BcbSessionRole.class));

        mediatorConnectionManager.connect(PRIMARY_INSTANCE_ID);

        verify(mediatorEvents).push(isA(PhysicalMediatorActivatingEvent.class));
        verifyErrorWasReported();
    }

    @Test
    public void testConnectError_duplicateMediatorSession_reportsError() throws ConnectException, BcbException, RepositoryException {
        doThrow(new DuplicatedSessionException(new MediatorIdItem(SECONDARY_INSTANCE_ID)))
            .when(connectionManager)
                .connect(eq(sessionContext), any(MediatorIdItem.class), any(Properties.class), any(BcbSessionRole.class));

        when(mediatorRepository.queryMediatorName(MEDIATOR_ID)).thenReturn(Optional.of("name"));

        mediatorConnectionManager.connect(PRIMARY_INSTANCE_ID);

        verify(mediatorEvents).push(isA(PhysicalMediatorActivatingEvent.class));
        verify(mediatorEvents).push(new PhysicalMediatorActivationFailedEvent(PRIMARY_INSTANCE_ID, MEDIATOR_ID, true, tr(Message.MEDIATOR_CONNECTION_ALREADY_ACTIVE, "name")));
        verify(mediatorEvents, never()).push(isA(PhysicalMediatorActivatedEvent.class));

        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem[].class));
    }

    @Test
    public void testConnectError_duplicateMediatorSession_instanceRepoFails_ignoresAndReportsErrorWithoutName() throws ConnectException, BcbException, RepositoryException {
        doThrow(new DuplicatedSessionException(new MediatorIdItem(SECONDARY_INSTANCE_ID)))
                .when(connectionManager)
                .connect(eq(sessionContext), any(MediatorIdItem.class), any(Properties.class), any(BcbSessionRole.class));

        when(mediatorInstanceRepository.query(SECONDARY_INSTANCE_ID)).thenThrow(new RepositoryException());

        mediatorConnectionManager.connect(PRIMARY_INSTANCE_ID);

        verify(mediatorEvents).push(isA(PhysicalMediatorActivatingEvent.class));
        verify(mediatorEvents).push(new PhysicalMediatorActivationFailedEvent(PRIMARY_INSTANCE_ID, MEDIATOR_ID, true, tr(Message.MEDIATOR_CONNECTION_ALREADY_ACTIVE, "")));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem[].class));
    }

    @Test
    public void testConnectError_duplicateMediatorSession_unknownInstance_ignoresAndReportsErrorWithoutName() throws ConnectException, BcbException, RepositoryException {
        doThrow(new DuplicatedSessionException(new MediatorIdItem(SECONDARY_INSTANCE_ID)))
                .when(connectionManager)
                .connect(eq(sessionContext), any(MediatorIdItem.class), any(Properties.class), any(BcbSessionRole.class));

        when(mediatorInstanceRepository.query(SECONDARY_INSTANCE_ID)).thenReturn(Optional.empty());

        mediatorConnectionManager.connect(PRIMARY_INSTANCE_ID);

        verify(mediatorEvents).push(isA(PhysicalMediatorActivatingEvent.class));
        verify(mediatorEvents).push(new PhysicalMediatorActivationFailedEvent(PRIMARY_INSTANCE_ID, MEDIATOR_ID, true, tr(Message.MEDIATOR_CONNECTION_ALREADY_ACTIVE, "")));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem[].class));
    }

    @Test
    public void testConnectError_duplicateMediatorSession_nameQueryFails_ignoresAndReportsError() throws ConnectException, BcbException, RepositoryException {
        doThrow(new DuplicatedSessionException(new MediatorIdItem(SECONDARY_INSTANCE_ID)))
                .when(connectionManager)
                .connect(eq(sessionContext), any(MediatorIdItem.class), any(Properties.class), any(BcbSessionRole.class));

        when(mediatorRepository.queryMediatorName(MEDIATOR_ID)).thenThrow(new RepositoryException());

        mediatorConnectionManager.connect(PRIMARY_INSTANCE_ID);

        verify(mediatorEvents).push(isA(PhysicalMediatorActivatingEvent.class));
        verify(mediatorEvents).push(new PhysicalMediatorActivationFailedEvent(PRIMARY_INSTANCE_ID, MEDIATOR_ID, true, tr(Message.MEDIATOR_CONNECTION_ALREADY_ACTIVE, "")));
        verify(mediatorEvents, never()).push(isA(PhysicalMediatorActivatedEvent.class));

        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem[].class));
    }

    @Test
    public void testConnectError_duplicateMediatorSession_unknownName_ignoresAndReportsError() throws ConnectException, BcbException, RepositoryException {
        doThrow(new DuplicatedSessionException(new MediatorIdItem(SECONDARY_INSTANCE_ID)))
                .when(connectionManager)
                .connect(eq(sessionContext), any(MediatorIdItem.class), any(Properties.class), any(BcbSessionRole.class));

        when(mediatorRepository.queryMediatorName(MEDIATOR_ID)).thenReturn(Optional.empty());

        mediatorConnectionManager.connect(PRIMARY_INSTANCE_ID);

        verify(mediatorEvents).push(isA(PhysicalMediatorActivatingEvent.class));
        verify(mediatorEvents).push(new PhysicalMediatorActivationFailedEvent(PRIMARY_INSTANCE_ID, MEDIATOR_ID, true, tr(Message.MEDIATOR_CONNECTION_ALREADY_ACTIVE, "")));
        verify(mediatorEvents, never()).push(isA(PhysicalMediatorActivatedEvent.class));

        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem[].class));
    }

    private void verifyErrorWasReported() throws RepositoryException {
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem[].class));
        verify(mediatorEvents).push(isA(PhysicalMediatorActivationFailedEvent.class));
    }

    @Test
    public void testDisconnect() throws ConnectException, BcbException {

        final IEM em = convert(PRIMARY_INSTANCE_ID);
        final IMediatorId medId = new MediatorIdItem(PRIMARY_INSTANCE_ID);

        mediatorConnectionManager.disconnect(em.getId());

        verify(connectionManager, times(1)).disconnect(eq(sessionContext), eq(medId));

        verify(mediatorEvents).push(isA(PhysicalMediatorDeactivatingEvent.class));
        verify(mediatorEvents).push(isA(PhysicalMediatorDeactivatedEvent.class));
    }

    @Test
    public void testDisconnectError_onlyLogsErrorAndDisconnectsAnyway() throws ConnectException, BcbException, RepositoryException {

        final IEM em = convert(PRIMARY_INSTANCE_ID);
        final IMediatorId medId = new MediatorIdItem(PRIMARY_INSTANCE_ID);

        doThrow(new BcbException()).when(connectionManager).disconnect(sessionContext, medId);

        mediatorConnectionManager.disconnect(em.getId());

        verify(mediatorEvents).push(isA(PhysicalMediatorDeactivatingEvent.class));
        verify(mediatorEvents).push(isA(PhysicalMediatorDeactivatedEvent.class));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem[].class));
        verify(mediatorEvents, never()).push(isA(PhysicalMediatorActivationFailedEvent.class));
    }

}
