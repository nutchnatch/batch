package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.arrayContaining;
import static org.hamcrest.Matchers.arrayContainingInAnyOrder;
import static org.hamcrest.Matchers.arrayWithSize;
import static org.hamcrest.Matchers.emptyIterableOf;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Iterator;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.unitils.dbunit.annotation.DataSet;
import org.unitils.inject.util.InjectionUtils;
import org.unitils.inject.util.PropertyAccess;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainParticipationIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainParticipationItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainParticipationReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomain;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainParticipationMarkable;
import com.ossnms.dcn_manager.bicnet.connector.storage.HelperItTestBase;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaDomainRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.NeInstanceConnectionRepository;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;

@DataSet
public class DomainHelperIT extends HelperItTestBase {

    @Mock private StaticConfiguration configuration;
    @Mock private ISessionContext context;

    @InjectMocks private JpaNetworkElementRepositoryBean neRepository;
    @InjectMocks private JpaDomainRepositoryBean domainRepository;
    
    private NeInstanceConnectionRepository neInstanceRepository;
    @Mock private NetworkElementInteractionManager neInteractionManager;
    @Mock private NetworkElementNotifications neNotifs;
    @Mock private MessageSource<NeEvent> neEvents;
    @Mock private ChannelEntityRepository channelEntityRepository;
    @Mock private ChannelPhysicalConnectionRepository physicalChannelRepository;
    @Mock private ChannelNotifications channelNotifications;
    @Mock private ChannelInteractionManager channelInteractionManager;
    @Mock private MessageSource<ChannelEvent> channelEvents;

    @InjectMocks private DomainHelper domainHelper;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        neInstanceRepository = new NeInstanceConnectionRepository();

        neRepository.initialize();
        neRepository.start();

        final NeType type = MockFactory.mockNeType();
        final Types<NeType> types = mock(Types.class);
        when(type.getDefaultIcon()).thenReturn("icon");
        when(types.get(anyString())).thenReturn(type);
        when(configuration.getNeTypes()).thenReturn(types);

        
        InjectionUtils.injectIntoByType(domainRepository, JpaDomainRepositoryBean.class, domainHelper, PropertyAccess.FIELD);

        domainHelper.setNeManagers(new NetworkElementManagers(neRepository, neInstanceRepository, neInteractionManager, neNotifs, neEvents));
        domainHelper.setChannelManagers(new ChannelManagers(channelEntityRepository, physicalChannelRepository, channelNotifications, channelInteractionManager, channelEvents));
    }

    @Test
    public void getAllDomains() throws Exception {
        final Iterable<IAS> domains = domainHelper.getDomains(context);

        assertThat(domains, not(is(emptyIterableOf(IAS.class))));

        final Iterator<IAS> iterator = domains.iterator();

        IAS as = iterator.next();
        assertThat(as.getId(), is(1));
        assertThat(as.getIdName(), is("domain1"));
        assertThat(as.getDiscoveryPermited(), is(true));

        as = iterator.next();
        assertThat(as.getId(), is(2));
        assertThat(as.getIdName(), is("domain2"));
        assertThat(as.getDiscoveryPermited(), is(false));
    }

    @Test
    public void getSingleNetworkDomain() throws Exception {
        final INetworkDomain domain = domainHelper.getSingleNetworkDomain(context, new NetworkDomainIdItem(1));

        assertThat(domain.getId(), is(1));
        assertThat(domain.getIdName(), is("domain1"));
        assertThat(domain.getDiscoveryPermited(), is(true));
    }

    @Test
    public void getNetworkDomainList() throws Exception {
        final NetworkDomainReply domains = domainHelper.getNetworkDomainList(context, null, null, ALL);

        assertThat(domains.getData(), is(arrayWithSize(2)));

        INetworkDomain domain = domains.getData()[0];
        assertThat(domain.getId(), is(1));
        assertThat(domain.getIdName(), is("domain1"));
        assertThat(domain.getDiscoveryPermited(), is(true));

        domain = domains.getData()[1];
        assertThat(domain.getId(), is(2));
        assertThat(domain.getIdName(), is("domain2"));
        assertThat(domain.getDiscoveryPermited(), is(false));
    }

    @Test
    public void getNetworkDomainList_limited() throws Exception {
        final NetworkDomainReply domains = domainHelper.getNetworkDomainList(context, null, null, 1);

        assertThat(domains.getData(), is(arrayWithSize(1)));

        final INetworkDomain domain = domains.getData()[0];
        assertThat(domain.getId(), is(1));
        assertThat(domain.getIdName(), is("domain1"));
        assertThat(domain.getDiscoveryPermited(), is(true));
    }

    @Test
    public void getNetworkDomainList_filtered() throws Exception {
        final INetworkDomainMarkable filter = NetworkDomainItem.markableNetworkDomain(null);
        filter.setIdName("domain2");
        final NetworkDomainReply domains = domainHelper.getNetworkDomainList(context, null,
                new INetworkDomainMarkable[] { filter }, ALL);

        assertThat(domains.getData(), is(arrayWithSize(1)));

        final INetworkDomain domain = domains.getData()[0];
        assertThat(domain.getId(), is(2));
        assertThat(domain.getIdName(), is("domain2"));
        assertThat(domain.getDiscoveryPermited(), is(false));
    }

    @Test
    public void getNetworkDomainIdsForNE() throws Exception {

        final INetworkDomainId[] domainIds = domainHelper.getNetworkDomainIdsForNE(context, new NEIdItem(1));

        assertThat(domainIds, is(arrayContainingInAnyOrder(
            new NetworkDomainIdItem(1), new NetworkDomainIdItem(2))));

    }

    @Test
    public void getNetworkDomainsForNE() throws Exception {

        final INetworkDomain[] domains = domainHelper.getNetworkDomainsForNE(context, new NEIdItem(1));

        assertThat(domains, is(arrayWithSize(2)));

        INetworkDomain domain = domains[0];
        assertThat(domain.getId(), is(1));
        assertThat(domain.getIdName(), is("domain1"));
        assertThat(domain.getDiscoveryPermited(), is(true));

        domain = domains[1];
        assertThat(domain.getId(), is(2));
        assertThat(domain.getIdName(), is("domain2"));
        assertThat(domain.getDiscoveryPermited(), is(false));
    }

    @Test
    public void getNEIdsInNetworkDomain() throws Exception {
        final INEId[] ids = domainHelper.getNEIdsInNetworkDomain(context, new NetworkDomainIdItem(1));

        assertThat(ids, is(arrayContaining(new NEIdItem(1))));
    }

    @Test
    public void getNEsInNetworkDomain() throws Exception {
        final INE[] nes = domainHelper.getNEsInNetworkDomain(context, new NetworkDomainIdItem(1));

        assertThat(nes, is(arrayWithSize(1)));

        assertThat(nes[0], is(new NEIdItem(1))); // BCB compares IDs for equality....
        assertThat(nes[0].getIdName(), is("testNeName")); // we'll check just one attribute, check others only if a problem is found
    }

    @Test
    public void getNetworkDomainParticipationList() throws Exception {
        final NetworkDomainParticipationReply reply = domainHelper.getNetworkDomainParticipationList(context, null, null, ALL);

        assertThat(reply.getData(), is(arrayContaining(
                new NetworkDomainParticipationIdItem(1, 1),
                new NetworkDomainParticipationIdItem(2, 1)
            )));
    }

    @Test
    public void getNetworkDomainParticipationList_limited() throws Exception {
        final NetworkDomainParticipationReply reply = domainHelper.getNetworkDomainParticipationList(context, null, null, 1);

        assertThat(reply.getData(), is(arrayContaining(
                new NetworkDomainParticipationIdItem(1, 1)
            )));
    }

    @Test
    public void getNetworkDomainParticipationList_filteredByDomain() throws Exception {
        final INetworkDomainParticipationMarkable filter = NetworkDomainParticipationItem.markableNetworkDomainParticipation(null);
        filter.setNetworkDomainIdId(1);
        final NetworkDomainParticipationReply reply = domainHelper.getNetworkDomainParticipationList(context, null,
                new INetworkDomainParticipationMarkable[] { filter }, ALL);

        assertThat(reply.getData(), is(arrayContaining(
                new NetworkDomainParticipationIdItem(1, 1)
            )));
    }

    @Test
    public void getNetworkDomainParticipationList_filteredByNE() throws Exception {
        final INetworkDomainParticipationMarkable filter = NetworkDomainParticipationItem.markableNetworkDomainParticipation(null);
        filter.setNeIdId(1);
        final NetworkDomainParticipationReply reply = domainHelper.getNetworkDomainParticipationList(context, null,
                new INetworkDomainParticipationMarkable[] { filter }, ALL);

        assertThat(reply.getData(), is(arrayContaining(
                new NetworkDomainParticipationIdItem(1, 1),
                new NetworkDomainParticipationIdItem(2, 1)
            )));
    }

    @Test
    @DataSet("DomainHelperIT.empty.xml")
    public void getAllDomains_empty() throws Exception {
        final Iterable<IAS> domains = domainHelper.getDomains(context);
        assertThat(domains, is(emptyIterableOf(IAS.class)));
    }
}
