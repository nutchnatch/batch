package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorActivationState;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.i18n.Message;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertMediatorToBcb.convert;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ConvertMediatorToBcbTest {

    private static final int MEDIATOR_ID = 1;
    private MediatorType type;

    @Before
    public void setUp() {
        type = MockFactory.mockMediatorType();
    }

    @Test
    public void testBasicInfo() {
        final IMediator mediator = convert(type,
            new MediatorEntity(
                    new MediatorInfoBuilder().setName("name").setActivationRequired(true).setTypeName("BCB").build(MEDIATOR_ID, 1),
                    new MediatorConnectionBuilder().setActualActivationState(ActualActivationState.ACTIVE).build(MEDIATOR_ID, 1)),
            Collections.singletonList(
                    new MediatorInstance(
                        new MediatorPhysicalDataBuilder().setHost("host").setPriority(0).build(999, MEDIATOR_ID, 0),
                        new MediatorPhysicalConnectionBuilder().setActive(true).build(999, MEDIATOR_ID, 0))
                ));

        assertThat(mediator.getActualActivationState(), is(MediatorActivationState.ACTIVE));
        assertThat(mediator.getActivation(), is(EnableSwitch.ENABLED));
        assertThat(mediator.getDisplayState(), is(Message.ACTIVE.toString()));
        assertThat(mediator.getId(), is(MEDIATOR_ID));
        assertThat(mediator.getIdName(), is("name"));
        assertThat(mediator.getMediatorHost(), is("host"));
        assertThat(mediator.getMediatorType(), is(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.BCB));
    }

    @Test
    public void testBasicInfo_withoutInstances() {
        final IMediator mediator = convert(type, buildMediator(ActualActivationState.INACTIVE), Collections.<MediatorInstance>emptyList());

        assertThat(mediator.getActivation(), is(EnableSwitch.DISABLED));
        assertThat(mediator.getId(), is(MEDIATOR_ID));
        assertThat(mediator.getIdName(), is("name"));
        assertThat(mediator.getDisplayState(), is(Message.INACTIVE.toString()));
        assertThat(mediator.getMediatorHost(), is(nullValue()));
        assertThat(mediator.getMediatorType(), is(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.BCB));
    }

    private MediatorEntity buildMediator(ActualActivationState state) {
        return new MediatorEntity(
                    new MediatorInfoBuilder().setName("name").setActivationRequired(false).setTypeName("BCB").build(MEDIATOR_ID, 1),
                    new MediatorConnectionBuilder().setActualActivationState(state).build(MEDIATOR_ID, 1));
    }

    @Test
    public void testActualActivationState() throws Exception {
        assertThat(convert(type, buildMediator(ActualActivationState.ACTIVE), Collections.<MediatorInstance>emptyList()).getActualActivationState(),
                is(MediatorActivationState.ACTIVE));
        assertThat(convert(type, buildMediator(ActualActivationState.FAILED), Collections.<MediatorInstance>emptyList()).getActualActivationState(),
                is(MediatorActivationState.FAILED));

        assertThat(convert(type, buildMediator(ActualActivationState.ACTIVATING), Collections.<MediatorInstance>emptyList()).getActualActivationState(),
                is(MediatorActivationState.INACTIVE));
        assertThat(convert(type, buildMediator(ActualActivationState.DEACTIVATING), Collections.<MediatorInstance>emptyList()).getActualActivationState(),
                is(MediatorActivationState.INACTIVE));
        assertThat(convert(type, buildMediator(ActualActivationState.INACTIVE), Collections.<MediatorInstance>emptyList()).getActualActivationState(),
                is(MediatorActivationState.INACTIVE));
    }

    @Test
    public void testStateMessageDescription() throws Exception {
        assertThat(convert(type, buildMediator(ActualActivationState.ACTIVE), Collections.<MediatorInstance>emptyList()).getDisplayState(), is(tr(Message.ACTIVE)));
        assertThat(convert(type, buildMediator(ActualActivationState.FAILED), Collections.<MediatorInstance>emptyList()).getDisplayState(), is(tr(Message.FAILED)));
        assertThat(convert(type, buildMediator(ActualActivationState.ACTIVATING), Collections.<MediatorInstance>emptyList()).getDisplayState(), is(tr(Message.ACTIVATING)));
        assertThat(convert(type, buildMediator(ActualActivationState.DEACTIVATING), Collections.<MediatorInstance>emptyList()).getDisplayState(), is(tr(Message.DEACTIVATING)));
        assertThat(convert(type, buildMediator(ActualActivationState.INACTIVE), Collections.<MediatorInstance>emptyList()).getDisplayState(), is(tr(Message.INACTIVE)));
    }

}
