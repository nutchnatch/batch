package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentMarkable;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.HelperItTestBase;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.composables.configuration.HardwareConfigurationType;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.container.RootContainerId;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.unitils.dbunit.annotation.DataSet;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.apache.commons.lang3.ArrayUtils.contains;
import static org.apache.commons.lang3.ArrayUtils.isEmpty;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@DataSet
public class NeContainerAssignmentHelperIT extends HelperItTestBase {
    /**
     * IDS for existing objects in resource: NeContainerAssignmentHelperIT.xml
     * <p>
     * Assignments NE_1 x (CONTAINER_ROOT and CONTAINER_1)
     * Assignments NE_2 x CONTAINER_1
     */
    private static final int NE_1 = 61;
    private static final int NE_2 = 62;
    private static final int CONTAINER_ROOT = RootContainerId.ID.get();
    private static final int CONTAINER_1 = 1;
    private static final int DEFAULT_CONTAINER = 3;
    private static final int ALL = -1;

    @Mock private ISessionContext sessionContext;
    @Mock private ContainerNotifications notifications;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private NeHelper neHelper;
    @Mock private StaticConfigurationSingleton configuration;

    @InjectMocks private JpaNetworkElementRepositoryBean neRepository;
    @InjectMocks private JpaContainerRepositoryBean containerRepository;
    @InjectMocks private JpaSettingsRepositoryBean settingsRepository;
    @InjectMocks private JpaSystemRepositoryBean systemRepository;

    private NeContainerAssignmentHelper helper;

    @Override @Before public void setUp() throws Exception {
        super.setUp();

        helper = new NeContainerAssignmentHelper();
        helper.setLoggerManager(loggerManager);
        helper.setNotifications(notifications);
        helper.setContainerRepository(containerRepository);
        helper.setNeRepository(neRepository);
        helper.setSettingsRepository(settingsRepository);
        helper.setSystemRepository(systemRepository);
        helper.setNeHelper(neHelper);

        when(configuration.getHWConfiguration()).thenReturn(HardwareConfigurationType.MED);
        
        settingsRepository.initialize();
        settingsRepository.start();

        neRepository.initialize();
        neRepository.start();
    }

    @Test public void getSingleNeGenericContainerAssignment() throws Exception {
        INeGenericContainerAssignmentId assignmentId = new NeGenericContainerAssignmentIdItem(NE_1,
                CONTAINER_ROOT);

        final INeGenericContainerAssignment neAssignment = helper
                .getSingleNeGenericContainerAssignment(sessionContext, assignmentId);

        assertThat(neAssignment.getNetworkElementId(), is(NE_1));
        assertThat(neAssignment.getGenericContainerId(), is(CONTAINER_ROOT));
        assertThat(neAssignment.getPrimary(), is(true));
    }

    @Test public void getSingleNeGenericContainerAssignment_not_exists_container() throws Exception {
        INeGenericContainerAssignmentId assignmentId = new NeGenericContainerAssignmentIdItem(NE_1, 60000);

        final INeGenericContainerAssignment neAssignment = helper
                .getSingleNeGenericContainerAssignment(sessionContext, assignmentId);

        assertThat(neAssignment, is(nullValue()));
    }

    @Test public void getSingleNeGenericContainerAssignment_not_exists_ne() throws Exception {
        INeGenericContainerAssignmentId assignmentId = new NeGenericContainerAssignmentIdItem(600000,
                CONTAINER_ROOT);

        final INeGenericContainerAssignment neAssignment = helper
                .getSingleNeGenericContainerAssignment(sessionContext, assignmentId);

        assertThat(neAssignment, is(nullValue()));
    }

    @Test public void createNeGenericContainerAssignment() throws Exception {
        INeGenericContainerAssignment newAssignment = new NeGenericContainerAssignmentItem();
        newAssignment.setPrimary(false);
        newAssignment.setGenericContainerId(CONTAINER_1);
        newAssignment.setNetworkElementId(NE_2);

        helper.createNeGenericContainerAssignment(sessionContext, newAssignment);

        verify(notifications, atLeastOnce()).notifyChanges(isA(ContainerNeAssignmentAddedEvent.class));
        verify(loggerManager, atLeastOnce()).createCommandLog(isA(BicnetCallContext.class), isA(LoggerItem.class));
    }

    @Test(expected = BcbException.class) public void createNeGenericContainerAssignment_existing_assignment()
            throws Exception {
        INeGenericContainerAssignment newAssignment = new NeGenericContainerAssignmentItem();
        newAssignment.setPrimary(false);
        newAssignment.setGenericContainerId(CONTAINER_ROOT);
        newAssignment.setNetworkElementId(NE_2);

        helper.createNeGenericContainerAssignment(sessionContext, newAssignment);
    }

    @Test public void deleteNeGenericContainerAssignment_primary() throws Exception {
        INeGenericContainerAssignmentId newAssignment = new NeGenericContainerAssignmentIdItem();
        newAssignment.setGenericContainerId(CONTAINER_ROOT);
        newAssignment.setNetworkElementId(NE_1);

        helper.deleteNeGenericContainerAssignment(sessionContext, newAssignment);

        verify(notifications, atLeastOnce()).notifyChanges(isA(ContainerNeAssignmentRemovedEvent.class));
        verify(loggerManager, atLeastOnce()).createCommandLog(isA(BicnetCallContext.class), isA(LoggerItem.class));

        final INeGenericContainerAssignment neAssignment = helper
                .getSingleNeGenericContainerAssignment(sessionContext, newAssignment);

        assertThat(neAssignment, is(nullValue()));

        INeGenericContainerAssignmentId newAssignmentPrimary = new NeGenericContainerAssignmentIdItem();
        newAssignmentPrimary.setGenericContainerId(CONTAINER_1);
        newAssignmentPrimary.setNetworkElementId(NE_1);

        final INeGenericContainerAssignment neAssignmentPrimary = helper
                .getSingleNeGenericContainerAssignment(sessionContext, newAssignmentPrimary);

        assertThat(neAssignmentPrimary.getPrimary(), is(true));
    }

    @Test public void deleteNeGenericContainerAssignment_last_assignment() throws Exception {
        INeGenericContainerAssignmentId newAssignment = new NeGenericContainerAssignmentIdItem();
        newAssignment.setGenericContainerId(CONTAINER_ROOT);
        newAssignment.setNetworkElementId(NE_2);

        helper.deleteNeGenericContainerAssignment(sessionContext, newAssignment);

        verify(notifications, atLeastOnce()).notifyChanges(isA(ContainerNeAssignmentRemovedEvent.class));
        verify(loggerManager, atLeastOnce()).createCommandLog(isA(BicnetCallContext.class), isA(LoggerItem.class));

        INeGenericContainerAssignmentId defaultAssignment = new NeGenericContainerAssignmentIdItem();
        defaultAssignment.setGenericContainerId(DEFAULT_CONTAINER);
        defaultAssignment.setNetworkElementId(NE_2);
    }

    @Test public void modifyNeGenericContainerAssignment() throws Exception {
        INeGenericContainerAssignmentMarkable updateAssignment = NeGenericContainerAssignmentItem
                .markableNeGenericContainerAssignment(null);
        updateAssignment.setPrimary(false);
        updateAssignment.setGenericContainerId(CONTAINER_ROOT);
        updateAssignment.setNetworkElementId(NE_1);

        helper.modifyNeGenericContainerAssignment(sessionContext, updateAssignment);

        final INeGenericContainerAssignment neAssignment = helper
                .getSingleNeGenericContainerAssignment(sessionContext, updateAssignment);

        assertThat(neAssignment.getNetworkElementId(), is(NE_1));
        assertThat(neAssignment.getGenericContainerId(), is(CONTAINER_ROOT));
        assertThat(neAssignment.getPrimary(), is(false));
    }

    @Test public void getNeGenericContainerAssignmentList_all_items() throws Exception {
        final NeGenericContainerAssignmentReply neAssignmentReply = helper
                .getNeGenericContainerAssignmentList(null, null, null, ALL);

        final INeGenericContainerAssignment[] assignments = neAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<INeGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(INeGenericContainerAssignment::getNeGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(3));
        assertTrue(assignmentIds.contains(new NeGenericContainerAssignmentIdItem(NE_1, CONTAINER_ROOT)));
        assertTrue(assignmentIds.contains(new NeGenericContainerAssignmentIdItem(NE_1, CONTAINER_1)));
        assertTrue(assignmentIds.contains(new NeGenericContainerAssignmentIdItem(NE_2, CONTAINER_ROOT)));
    }

    @Test public void getNeGenericContainerAssignmentList_limit() throws Exception {
        final NeGenericContainerAssignmentReply neAssignmentReply = helper
                .getNeGenericContainerAssignmentList(null, null, null, 1);

        final INeGenericContainerAssignment[] assignments = neAssignmentReply.getData();

        assertThat(assignments.length, is(1));
    }

    @Test public void getNeGenericContainerAssignmentList_all_primary() throws Exception {

        INeGenericContainerAssignmentMarkable filter = NeGenericContainerAssignmentItem
                .markableNeGenericContainerAssignment(null);

        filter.setPrimary(true);

        final NeGenericContainerAssignmentReply neAssignmentReply = helper
                .getNeGenericContainerAssignmentList(sessionContext, null,
                        new INeGenericContainerAssignmentMarkable[] { filter }, ALL);

        final INeGenericContainerAssignment[] assignments = neAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<INeGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(INeGenericContainerAssignment::getNeGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(2));
        assertTrue(assignmentIds.contains(new NeGenericContainerAssignmentIdItem(NE_1, CONTAINER_ROOT)));
        assertTrue(assignmentIds.contains(new NeGenericContainerAssignmentIdItem(NE_2, CONTAINER_ROOT)));
    }

    @Test public void getNeGenericContainerAssignmentList_all_by_system() throws Exception {

        INeGenericContainerAssignmentMarkable filter = NeGenericContainerAssignmentItem
                .markableNeGenericContainerAssignment(null);

        filter.setNetworkElementId(NE_1);

        final NeGenericContainerAssignmentReply neAssignmentReply = helper
                .getNeGenericContainerAssignmentList(sessionContext, null,
                        new INeGenericContainerAssignmentMarkable[] { filter }, ALL);

        final INeGenericContainerAssignment[] assignments = neAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<INeGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(INeGenericContainerAssignment::getNeGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(2));
        assertTrue(assignmentIds.contains(new NeGenericContainerAssignmentIdItem(NE_1, CONTAINER_ROOT)));
        assertTrue(assignmentIds.contains(new NeGenericContainerAssignmentIdItem(NE_1, CONTAINER_1)));
    }

    @Test public void getNeGenericContainerAssignmentList_all_by_container() throws Exception {

        INeGenericContainerAssignmentMarkable filter = NeGenericContainerAssignmentItem
                .markableNeGenericContainerAssignment(null);

        filter.setGenericContainerId(CONTAINER_ROOT);

        final NeGenericContainerAssignmentReply neAssignmentReply = helper
                .getNeGenericContainerAssignmentList(sessionContext, null,
                        new INeGenericContainerAssignmentMarkable[] { filter }, ALL);

        final INeGenericContainerAssignment[] assignments = neAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<INeGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(INeGenericContainerAssignment::getNeGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(2));
        assertTrue(assignmentIds.contains(new NeGenericContainerAssignmentIdItem(NE_1, CONTAINER_ROOT)));
        assertTrue(assignmentIds.contains(new NeGenericContainerAssignmentIdItem(NE_2, CONTAINER_ROOT)));
    }

    @Test public void getNeGenericContainerAssignmentList_by_container_and_system() throws Exception {

        INeGenericContainerAssignmentMarkable filter = NeGenericContainerAssignmentItem
                .markableNeGenericContainerAssignment(null);

        filter.setGenericContainerId(CONTAINER_ROOT);
        filter.setNetworkElementId(NE_1);

        final NeGenericContainerAssignmentReply neAssignmentReply = helper
                .getNeGenericContainerAssignmentList(sessionContext, null,
                        new INeGenericContainerAssignmentMarkable[] { filter }, ALL);

        final INeGenericContainerAssignment[] assignments = neAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<INeGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(INeGenericContainerAssignment::getNeGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(1));
        assertTrue(assignmentIds.contains(new NeGenericContainerAssignmentIdItem(NE_1, CONTAINER_ROOT)));
    }

    @Test public void getNeGenericContainerAssignmentList_by_container_and_system_type() throws Exception {

        INeGenericContainerAssignmentMarkable filter = NeGenericContainerAssignmentItem
                .markableNeGenericContainerAssignment(null);

        filter.setGenericContainerId(CONTAINER_ROOT);
        filter.setNetworkElementId(NE_1);
        filter.setPrimary(true);

        final NeGenericContainerAssignmentReply neAssignmentReply = helper
                .getNeGenericContainerAssignmentList(sessionContext, null,
                        new INeGenericContainerAssignmentMarkable[] { filter }, ALL);

        final INeGenericContainerAssignment[] assignments = neAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<INeGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(INeGenericContainerAssignment::getNeGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(1));
        assertTrue(assignmentIds.contains(new NeGenericContainerAssignmentIdItem(NE_1, CONTAINER_ROOT)));
    }

    @DataSet("NeContainerAssignmentHelperIT.empty.xml")
    @Test public void getNeGenericContainerAssignmentList_empty()
            throws Exception {
        final NeGenericContainerAssignmentReply neAssignmentReply = helper
                .getNeGenericContainerAssignmentList(sessionContext, null, null, ALL);

        final INeGenericContainerAssignment[] assignments = neAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(true));
    }

    @Test public void getNeGenericContainerAssignmentIdList_all_items() throws Exception {
        final NeGenericContainerAssignmentIdReply neAssignmentReply = helper
                .getNeGenericContainerAssignmentIdList(null, null, null, ALL);

        final INeGenericContainerAssignmentId[] assignments = neAssignmentReply.getData();

        assertThat(assignments.length, is(3));
        assertTrue(contains(assignments, new NeGenericContainerAssignmentIdItem(NE_1, CONTAINER_ROOT)));
        assertTrue(contains(assignments, new NeGenericContainerAssignmentIdItem(NE_1, CONTAINER_1)));
        assertTrue(contains(assignments, new NeGenericContainerAssignmentIdItem(NE_2, CONTAINER_ROOT)));
    }
}