package com.ossnms.dcn_manager.bicnet.connector.converter;


import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertIntegerToBcbNe.convert;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;

public class ConvertIntegerToBcbNeTest {

    @Test
    public void testConverterToBcbNeItem() {
        
        INE bcbNe = convert(1);
        
        assertThat(bcbNe.getId(), is(1));
        assertThat(bcbNe.getNEId(), is((INEId)new NEIdItem(1)));
    }
    
    @Test
    public void testConverterToBcbNeIdItem() {
        INEId bcbNe = convert(1);
        
        assertThat(bcbNe.getId(), is(1));
    }
}
