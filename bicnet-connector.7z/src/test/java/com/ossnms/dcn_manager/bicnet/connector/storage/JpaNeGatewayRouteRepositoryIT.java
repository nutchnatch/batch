package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.google.common.base.Supplier;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaUnitOfWorkContext;
import com.ossnms.dcn_manager.connector.storage.ne.JpaNeGatewayRouteRepository;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.unitils.dbunit.annotation.DataSet;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import static com.google.common.collect.FluentIterable.from;
import static com.google.common.collect.Iterables.getOnlyElement;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.emptyIterableOf;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

@DataSet
public class JpaNeGatewayRouteRepositoryIT extends HelperItTestBase {

    private static final int NE_ID = 1;
    private static final int NE_ID2 = 2;

    private JpaNeGatewayRouteRepository routeRepo;
    private Supplier<CloseableEntityTransaction> transactionSupplier;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        transactionSupplier = repositoryBean.getTransactionSupplier();
        routeRepo = new JpaNeGatewayRouteRepository(transactionSupplier);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void findGatewayRouteKeys() throws Exception {

        final Set<Pair<String,Integer>> routeKeys = routeRepo.tryFindRouteKeys(Collections.singleton("route1"));

        assertThat(routeKeys, is(notNullValue()));
        assertThat(routeKeys, is(Matchers.iterableWithSize(1)));
        assertThat(routeKeys, contains(new ImmutablePair<>("route1", 1)));

    }

    @Test
    @SuppressWarnings("unchecked")
    public void findAllRouteKeys() throws Exception {

        final Set<Pair<String,Integer>> routeKeys = routeRepo.tryFindRouteKeys(ImmutableSet.of("route1", "route2"));

        assertThat(routeKeys, is(notNullValue()));
        assertThat(routeKeys, is(Matchers.iterableWithSize(2)));
        assertThat(routeKeys, Matchers.containsInAnyOrder(
                new ImmutablePair<>("route2", 1), new ImmutablePair<>("route1", NE_ID)));

    }

    @Test
    public void findUnknownRouteKeys() throws Exception {

        final Set<Pair<String,Integer>> routeKeys = routeRepo.tryFindRouteKeys(Collections.singleton("blah"));

        assertThat(routeKeys, is(notNullValue()));
        assertThat(routeKeys, is(Matchers.empty()));

    }

    @Test
    public void findRoutesForNe() throws Exception {

        final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.queryRoutes(NE_ID);

        assertThat(gatewayRoutes, is(notNullValue()));
        assertThat(gatewayRoutes, is(Matchers.iterableWithSize(1)));
        final NeGatewayRouteData routeData = gatewayRoutes.iterator().next();
        assertThat(routeData.getKey(), is("route1"));
        assertThat(routeData.getOpaqueProperty("prop1"), hasValue("value1"));

    }

    @Test
    public void findRoutesForNes() throws Exception {

        final ImmutableMap<Integer, Iterable<NeGatewayRouteData>> gatewayRoutes
                = routeRepo.queryRoutes(ImmutableSet.of(NE_ID, NE_ID2));

        assertThat(gatewayRoutes, is(notNullValue()));
        assertThat(gatewayRoutes.size(), is(2));

        assertThat(gatewayRoutes.get(NE_ID), is(Matchers.iterableWithSize(1)));
        assertThat(gatewayRoutes.get(NE_ID2), is(Matchers.iterableWithSize(1)));


        final NeGatewayRouteData routeData = gatewayRoutes.get(NE_ID).iterator().next();
        assertThat(routeData.getKey(), is("route1"));
        assertThat(routeData.getOpaqueProperty("prop1"), hasValue("value1"));

        final NeGatewayRouteData routeData2 = gatewayRoutes.get(NE_ID2).iterator().next();
        assertThat(routeData2.getKey(), is("route3"));
        assertThat(routeData2.getOpaqueProperty("prop3"), hasValue("value3"));

    }


    @Test
    public void findRoutesForNe_withExplicitTransaction() throws Exception {

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {
            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);

            assertThat(gatewayRoutes, is(notNullValue()));
            assertThat(gatewayRoutes, is(Matchers.iterableWithSize(1)));
            final NeGatewayRouteData routeData = gatewayRoutes.iterator().next();
            assertThat(routeData.getKey(), is("route1"));
            assertThat(routeData.getOpaqueProperty("prop1"), hasValue("value1"));

        }

    }

    @Test
    public void findRoutesForUnknownNe() throws Exception {

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {
            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, 12345);

            assertThat(gatewayRoutes, is(notNullValue()));
            assertThat(gatewayRoutes, is(Matchers.iterableWithSize(0)));

        }

    }

    @Test
    public void insertRoute() throws Exception {

        final NeGatewayRouteBuilder routeBuilder = new NeGatewayRouteBuilder()
            .setCost(12)
            .setDomain(Optional.of("newDomain"))
            .setKey("newKey")
            .setPriority(3)
            .setProperty("newProp", "newValue")
            .setUsed(true);

        final NeGatewayRouteData routeData = routeBuilder.build(NE_ID, 0);

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final ImmutableSet<NeGatewayRouteData> inserted =
                    routeRepo.insert(tx, NE_ID, Collections.singleton(routeBuilder));

            assertThat(inserted, contains(routeData));

        }

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);

            assertThat(gatewayRoutes, hasItem(routeData));
            assertThat(gatewayRoutes, is(Matchers.iterableWithSize(2)));
        }

    }

    @Test
    public void createRoutes() throws Exception {

        final NeGatewayRouteMutationDescriptor routeBuilder =
            new NeGatewayRouteMutationDescriptor(
                    new NeGatewayRouteBuilder().setKey("newKey").build(NE_ID, 0))
                .setCost(12)
                .setDomain(Optional.of("newDomain"))
                .setGneName("newGneName")
                .setPriority(3)
                .setProperty("newProp", "newValue")
                .setUsed(true);

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> inserted =
                    routeRepo.createRoutes(NE_ID, Collections.singleton(routeBuilder));

            assertThat(inserted, contains(routeBuilder.getResult()));

        }

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);

            assertThat(gatewayRoutes, hasItem(routeBuilder.getResult()));
            assertThat(gatewayRoutes, is(Matchers.iterableWithSize(2)));
        }

    }

    @Test
    public void createRoute_unitOfWork() throws Exception {

        final NeGatewayRouteMutationDescriptor routeBuilder =
                new NeGatewayRouteMutationDescriptor(
                        new NeGatewayRouteBuilder().setKey("newKey").build(NE_ID, 0))
                        .setCost(12)
                        .setDomain(Optional.of("newDomain"))
                        .setGneName("newGneName")
                        .setPriority(3)
                        .setProperty("newProp", "newValue")
                        .setUsed(true);

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final NeGatewayRouteData inserted =
                    routeRepo.createRoute(new JpaUnitOfWorkContext(tx), NE_ID, routeBuilder);

            assertThat(inserted, is(routeBuilder.getResult()));

        }

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);

            assertThat(gatewayRoutes, hasItem(routeBuilder.getResult()));
            assertThat(gatewayRoutes, is(Matchers.iterableWithSize(2)));
        }

    }

    @Test
    public void updateRoute() throws Exception {

        NeGatewayRouteData newRoute;

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);

            final NeGatewayRouteMutationDescriptor descriptor =
                    new NeGatewayRouteMutationDescriptor(getOnlyElement(gatewayRoutes));
            descriptor.setDomain("This is a new Domain Name");

            final Iterable<NeGatewayRouteData> updatedRoutes =
                    routeRepo.updateRoutes(NE_ID, Collections.singleton(descriptor));
            newRoute = getOnlyElement(updatedRoutes);

            assertThat(newRoute.getDomain(), hasValue("This is a new Domain Name"));

        }

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);

            assertThat(gatewayRoutes, contains(newRoute));
        }

    }

    @Test
    public void updateRoute_unitOfWork() throws Exception {

        NeGatewayRouteData newRoute;

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);

            final NeGatewayRouteMutationDescriptor descriptor =
                    new NeGatewayRouteMutationDescriptor(getOnlyElement(gatewayRoutes));
            descriptor.setDomain("This is a new Domain Name");

            newRoute = routeRepo.updateRoute(new JpaUnitOfWorkContext(tx), NE_ID, descriptor);

            assertThat(newRoute.getDomain(), hasValue("This is a new Domain Name"));

        }

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);

            assertThat(gatewayRoutes, contains(newRoute));
        }

    }

    @Test
    public void updateRouteKey() throws Exception {

        NeGatewayRouteData newRoute;

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);

            final NeGatewayRouteMutationDescriptor descriptor =
                    new NeGatewayRouteMutationDescriptor(getOnlyElement(gatewayRoutes));
            descriptor.setKey("This is the new Route Key.");

            final Iterable<NeGatewayRouteData> updatedRoutes =
                    routeRepo.updateRoutes(NE_ID, Collections.singleton(descriptor));
            newRoute = getOnlyElement(updatedRoutes);

            assertThat(newRoute.getKey(), is("This is the new Route Key."));

        }

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);

            assertThat(getOnlyElement(gatewayRoutes).getKey(), is("This is the new Route Key."));
        }

    }

    @Test
    public void deleteRoute() throws Exception {


        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            routeRepo.deleteRoutes(Collections.singleton("route1"));

        }

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);
            assertThat(gatewayRoutes, is(emptyIterableOf(NeGatewayRouteData.class)));

        }

    }

    @Test
    public void deleteRoute_unitOfWork() throws Exception {


        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            routeRepo.deleteRoute(new JpaUnitOfWorkContext(tx), "route1");

        }

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final Iterable<NeGatewayRouteData> gatewayRoutes = routeRepo.query(tx, NE_ID);
            assertThat(gatewayRoutes, is(emptyIterableOf(NeGatewayRouteData.class)));

        }

    }

    @Test
    public void renameRouteDomains() throws Exception {

        Iterable<NeGatewayRouteData> routes;

        routes = routeRepo.queryRoutes(NE_ID);
        assertThat(from(routes).transform(NeGatewayRouteData::getDomain).transform(Optional::get), hasItems("domain1"));

        routeRepo.renameRouteDomains("domain1", "changed domain name");

        routes = routeRepo.queryRoutes(NE_ID);
        assertThat(from(routes).transform(NeGatewayRouteData::getDomain).transform(Optional::get), hasItems("changed domain name"));
    }
}
