package com.ossnms.dcn_manager.bicnet.connector.converter;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;

public class ConvertBcbNeIdToIntegerTest {

    /**
     * Test method for {@link com.ossnms.dcn_manager.connector.jboss.converter.ConvertBcbNeIdToInteger#apply(com.ossnms.bicnet.bcb.model.emObjMgmt.INEId)}.
     */
    @Test
    public void testApply() {
        final ConvertBcbNeIdToInteger convert = new ConvertBcbNeIdToInteger();

        assertThat(convert.apply(new NEIdItem(13)), is(13));
        assertThat(convert.apply(null), is(0));
    }

}
