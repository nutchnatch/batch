package com.ossnms.dcn_manager.bicnet.connector.facade.util;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.arrayContaining;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.GneCost;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeGneCost;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public class NeGneCostCalculatorTest {

    private NeEntityRepository repo;
    private NeEntityRepository.NeOperationRepository operationRepo;
    private NeEntityRepository.NeGatewayRoutesRepository routesRepo;

    @Before
    public void setUp() throws Exception {
        repo = mock(NeEntityRepository.class);
        operationRepo = mock(NeEntityRepository.NeOperationRepository.class);
        routesRepo = mock(NeEntityRepository.NeGatewayRoutesRepository.class);

        when(repo.getNeOperationRepository()).thenReturn(operationRepo);
        when(repo.getNeGatewayRoutesRepository()).thenReturn(routesRepo);
    }

    @Test
    public void calculateCosts_noNEs() throws Exception {

        when(operationRepo.queryAll()).thenReturn(Collections.emptyList());

        final NeGneCost[] neGneCosts = new NeGneCostCalculator(repo).calculateCostToGneMap();
        assertThat(neGneCosts, not(is(nullValue())));
        assertThat(neGneCosts.length, is(0));
    }

    @Test
    public void calculateCosts() throws Exception {

        when(operationRepo.queryAll()).thenReturn(ImmutableList.of(
                buildNeOperationData(12, "ne-12", GatewayMode.PRIMARY), // gne w/ loopback
                buildNeOperationData(13, "ne-13", GatewayMode.NONE), // rne w/ loopback
                buildNeOperationData(14, null, GatewayMode.NONE), // rne w/o loopback
                buildNeOperationData(15, null, GatewayMode.NONE) // rne w/o any routes with GNE name
        ));

        when(routesRepo.queryRoutes(12)).thenReturn(ImmutableList.of(
                buildGatewayRoute(12, 3, 2, false, "gne12a", null), // usage disambiaguates sort against the next route
                buildGatewayRoute(12, 1, 2, true, null, null), // emulate GM's loopback route
                buildGatewayRoute(12, 2, 1, false, "gne12", "domain-12")
        ));
        when(routesRepo.queryRoutes(13)).thenReturn(ImmutableList.of(
                buildGatewayRoute(13, 1, 2, true, null, null), // emulate GM's loopback route, wrongly placed on a RNE
                buildGatewayRoute(13, 2, 1, false, "gne13", "domain-13")
        ));
        when(routesRepo.queryRoutes(14)).thenReturn(ImmutableList.of(
                buildGatewayRoute(14, 1, 1, true, "gne14", "domain-14")
        ));
        when(routesRepo.queryRoutes(15)).thenReturn(ImmutableList.of(
                buildGatewayRoute(15, 1, 1, true, "", null)
        ));

        when(repo.queryNeName(12)).thenReturn(Optional.of("ne-twelve"));
        when(repo.queryNeName(13)).thenReturn(Optional.empty()); // should result on the real ne name
        when(repo.queryNeName(14)).thenThrow(new RepositoryException()); // should result on the ne id (no ne name)
        when(repo.queryNeName(15)).thenReturn(Optional.of("ne-fifteen"));

        final NeGneCost[] neGneCosts = new NeGneCostCalculator(repo).calculateCostToGneMap();
        assertThat(neGneCosts, not(is(nullValue())));
        assertThat(neGneCosts.length, is(4));

        assertThat(neGneCosts[0].getName(), is("ne-twelve"));
        assertThat(neGneCosts[1].getName(), is("ne-13"));
        assertThat(neGneCosts[2].getName(), is("14"));

        assertThat(neGneCosts[0].getGne_costs(), is(arrayContaining(
                new GneCost("gne12", 1, "domain-12", false),
                new GneCost("ne-12", 2, null, true),
                new GneCost("gne12a", 2, null, false)
        )));
        assertThat(neGneCosts[1].getGne_costs(), is(arrayContaining(
                new GneCost("gne13", 1, "domain-13", false)
        )));
        assertThat(neGneCosts[2].getGne_costs(), is(arrayContaining(
                new GneCost("gne14", 1, "domain-14", true)
        )));
    }

    @Test
    public void calculateCosts_routeRepoError_noCostsForNe() throws Exception {

        when(operationRepo.queryAll()).thenReturn(ImmutableList.of(
                buildNeOperationData(12, "ne-12", GatewayMode.PRIMARY)
        ));
        when(routesRepo.queryRoutes(12)).thenThrow(new RepositoryException());
        when(repo.queryNeName(12)).thenReturn(Optional.of("ne-twelve"));

        final NeGneCost[] neGneCosts = new NeGneCostCalculator(repo).calculateCostToGneMap();
        assertThat(neGneCosts, not(is(nullValue())));
        assertThat(neGneCosts.length, is(1));
    }

    @Test
    public void calculateCosts_noRoutes_noCostsForNe() throws Exception {

        when(operationRepo.queryAll()).thenReturn(ImmutableList.of(
                buildNeOperationData(12, "ne-12", GatewayMode.PRIMARY)
        ));
        when(routesRepo.queryRoutes(12)).thenReturn(Collections.emptyList());
        when(repo.queryNeName(12)).thenReturn(Optional.of("ne-twelve"));

        final NeGneCost[] neGneCosts = new NeGneCostCalculator(repo).calculateCostToGneMap();
        assertThat(neGneCosts, not(is(nullValue())));
        assertThat(neGneCosts.length, is(1));
    }
    
    @Test
    public void calculateCosts_for_neId() throws Exception {

        when(operationRepo.query(12)).thenReturn(Optional.of(buildNeOperationData(12, "ne-12", GatewayMode.PRIMARY))); // gne w/ loopback
        when(routesRepo.queryRoutes(12)).thenReturn(ImmutableList.of(
                buildGatewayRoute(12, 3, 2, false, "gne12a", null), // usage disambiaguates sort against the next route
                buildGatewayRoute(12, 1, 2, true, null, null), // emulate GM's loopback route
                buildGatewayRoute(12, 2, 1, false, "gne12", "domain-12")
        ));

        when(repo.queryNeName(12)).thenReturn(Optional.of("ne-twelve"));

        final NeGneCost neGneCosts = new NeGneCostCalculator(repo).calculateCostToGne(new NEIdItem(12));
        assertThat(neGneCosts, not(is(nullValue())));
        assertThat(neGneCosts.getName(), is("ne-twelve"));
        assertThat(neGneCosts.getGne_costs(), is(arrayContaining(
                new GneCost("gne12", 1, "domain-12", false),
                new GneCost("ne-12", 2, null, true),
                new GneCost("gne12a", 2, null, false)
        )));
    }
    
    @Test
    public void calculateCosts_for_neId_return_empty() throws Exception {
        when(repo.queryNeName(12)).thenReturn(Optional.of("ne-12"));
        when(operationRepo.query(12)).thenReturn(Optional.of(buildNeOperationData(12, "ne-12", GatewayMode.PRIMARY)));
        when(routesRepo.queryRoutes(12)).thenReturn(Collections.emptyList());
        
        final NeGneCost neGneCosts = new NeGneCostCalculator(repo).calculateCostToGne(new NEIdItem(12));
       
        assertThat(neGneCosts, not(is(nullValue())));
        assertThat(neGneCosts.getName(), (is("ne-12")));
        assertThat(neGneCosts.getGne_costs().length, is(0));
        assertThat(neGneCosts.getGne_costs(), not(is(nullValue())));
    }

    private NeOperationData buildNeOperationData(int neId, String neName, GatewayMode gatewayMode) {
        return new NeOperationData.NeOperationBuilder()
                .setRealNeName(Optional.ofNullable(neName))
                .setGatewayMode(Optional.of(gatewayMode))
                .build(neId, 0);
    }

    private NeGatewayRouteData buildGatewayRoute(int neId, int index, int cost, boolean used, String name, String domain) {
        return new NeGatewayRouteData.NeGatewayRouteBuilder()
                .setGneName(name)
                .setCost(cost)
                .setPriority(index)
                .setUsed(used)
                .setDomain(Optional.ofNullable(domain))
                .setKey(String.valueOf(index)) // just to make the builder happy, it's not relevant for this use case.
                .build(neId, 0);
    }
}