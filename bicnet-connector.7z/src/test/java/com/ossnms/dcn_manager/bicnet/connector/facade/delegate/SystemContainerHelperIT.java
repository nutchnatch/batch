package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerMarkable;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.HelperItTestBase;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.composables.configuration.HardwareConfigurationType;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.outbound.SystemNotifications;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.unitils.dbunit.annotation.DataSet;

import static org.hamcrest.Matchers.arrayWithSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@DataSet
public class SystemContainerHelperIT extends HelperItTestBase {

    @Mock private ISessionContext sessionContext;
    @Mock private SystemNotifications notifications;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private ContainerNotifications containerNotifications;
    @Mock private StaticConfigurationSingleton hwConfiguration;

    @InjectMocks private JpaSystemRepositoryBean systemRepository;
    @InjectMocks private JpaContainerRepositoryBean repository;
    @InjectMocks private JpaNetworkElementRepositoryBean neRepository;
    @InjectMocks private JpaSettingsRepositoryBean settingsRepository;
    
    private SystemContainerHelper helper;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        helper = new SystemContainerHelper();
        helper.setLoggerManager(loggerManager);
        helper.setNotifications(notifications);
        helper.setContainerRepository(repository);
        helper.setRepository(systemRepository);
        helper.setJpaNetworkElementRepositoryBean(neRepository);
        helper.setSettingsRepository(settingsRepository);

        when(hwConfiguration.getHWConfiguration()).thenReturn(HardwareConfigurationType.MED);
        
        neRepository.initialize();
        settingsRepository.initialize();
        settingsRepository.start();
    }

    @Test
    public void getSystemContainerList() throws RepositoryException, BcbException {

        ISystemContainerMarkable filter;
        SystemContainerReply list;
        ISystemContainer[] data;

        // Get all

        list = helper.getSystemContainerList(null, null, null, -1);

        assertThat(list, is(notNullValue()));
        data = list.getData();
        assertThat(data, is(arrayWithSize(3)));
        assertThat(data[0].getId(), is(1));
        assertThat(data[0].getIdName(), is("system_1"));
        assertThat(data[1].getId(), is(2));
        assertThat(data[1].getIdName(), is("system_2"));
        assertThat(data[2].getId(), is(3));
        assertThat(data[2].getIdName(), is("system_3"));

        // Get by name

        filter = SystemContainerItem.markableSystemContainer(null);
        filter.setIdName("system_2");
        list = helper.getSystemContainerList(null, null, new ISystemContainerMarkable[] { filter }, -1);

        assertThat(list, is(notNullValue()));
        data = list.getData();
        assertThat(data, is(arrayWithSize(1)));
        assertThat(data[0].getId(), is(2));
        assertThat(data[0].getIdName(), is("system_2"));

        // Get by ID

        filter = SystemContainerItem.markableSystemContainer(null);
        filter.setId(1);
        list = helper.getSystemContainerList(null, null, new ISystemContainerMarkable[] { filter }, -1);

        assertThat(list, is(notNullValue()));
        data = list.getData();
        assertThat(data, is(arrayWithSize(1)));
        assertThat(data[0].getId(), is(1));
        assertThat(data[0].getIdName(), is("system_1"));

        // Get all after first

        list = helper.getSystemContainerList(null, new SystemContainerIdItem(1), null, -1);

        assertThat(list, is(notNullValue()));
        data = list.getData();
        assertThat(data, is(arrayWithSize(2)));
        assertThat(data[0].getId(), is(2));
        assertThat(data[0].getIdName(), is("system_2"));
        assertThat(data[1].getId(), is(3));
        assertThat(data[1].getIdName(), is("system_3"));

        // Get by name or ID

        final ISystemContainerMarkable[] filters = new ISystemContainerMarkable[] {
            SystemContainerItem.markableSystemContainer(null), SystemContainerItem.markableSystemContainer(null)
        };
        filters[0].setId(3);
        filters[1].setIdName("system_2");
        list = helper.getSystemContainerList(null, null, filters, -1);

        assertThat(list, is(notNullValue()));
        data = list.getData();
        assertThat(data, is(arrayWithSize(2)));
        assertThat(data[0].getId(), is(2));
        assertThat(data[0].getIdName(), is("system_2"));
        assertThat(data[1].getId(), is(3));
        assertThat(data[1].getIdName(), is("system_3"));
    }

    @Test
    public void getSingleSystemContainer() throws RepositoryException, BcbException {

        final ISystemContainer container = helper.getSingleSystemContainer(null, new SystemContainerIdItem(2));
        assertThat(container, is(notNullValue()));
        assertThat(container.getId(), is(2));
        assertThat(container.getIdName(), is("system_2"));
    }

    @Test
    public void getSingleSystemContainer_unknownSystem_emptyResponse() throws RepositoryException, BcbException {

        final ISystemContainer container = helper.getSingleSystemContainer(null, new SystemContainerIdItem(12));
        assertThat(container, is(nullValue()));
    }

    @Test
    public void getSystemContainerList_limited() throws RepositoryException, BcbException {

        final SystemContainerReply list = helper.getSystemContainerList(null, null, null, 1);
        assertThat(list, is(notNullValue()));
        final ISystemContainer[] data = list.getData();
        assertThat(data, is(arrayWithSize(1)));
        assertThat(data[0].getId(), is(1));
        assertThat(data[0].getIdName(), is("system_1"));
    }

    @Test
    @DataSet("SystemContainerHelperIT.empty.xml")
    public void getSystemContainerList_empty() throws RepositoryException, BcbException {

        final SystemContainerReply list = helper.getSystemContainerList(null, null, null, -1);
        assertThat(list, is(notNullValue()));
        final ISystemContainer[] data = list.getData();
        assertThat(data, is(arrayWithSize(0)));
    }

    @Test
    public void getSystemContainerIdList() throws RepositoryException, BcbException {

        final SystemContainerIdReply list = helper.getSystemContainerIdList(null, null, null, -1);
        assertThat(list, is(notNullValue()));
        final ISystemContainerId[] data = list.getData();
        assertThat(data, is(arrayWithSize(3)));
        assertThat(data[0].getId(), is(1));
        assertThat(data[1].getId(), is(2));
        assertThat(data[2].getId(), is(3));
    }

    @Test
    public void getSystemContainerIdList_limited() throws RepositoryException, BcbException {

        final SystemContainerIdReply list = helper.getSystemContainerIdList(null, null, null, 1);
        assertThat(list, is(notNullValue()));
        final ISystemContainerId[] data = list.getData();
        assertThat(data, is(arrayWithSize(1)));
        assertThat(data[0].getId(), is(1));
    }

    @Test
    @DataSet("SystemContainerHelperIT.empty.xml")
    public void getSystemContainerIdList_empty() throws RepositoryException, BcbException {

        final SystemContainerIdReply list = helper.getSystemContainerIdList(null, null, null, -1);
        assertThat(list, is(notNullValue()));
        final ISystemContainerId[] data = list.getData();
        assertThat(data, is(arrayWithSize(0)));
    }

    @Test public void modifySystemContainer() throws Exception {
        ISystemContainerMarkable markable = SystemContainerItem.markableSystemContainer(null);
        markable.setId(1);
        markable.setDescription("newDescription");
        markable.setIdName("newName");
        markable.setUserLabel("newLabel");

        final ISystemContainerMarkable markableReturned = helper.modifySystemContainer(sessionContext, markable);

        final ISystemContainer updated = helper
                .getSingleSystemContainer(sessionContext, new SystemContainerIdItem(1));

        assertThat(markableReturned, is(markable));

        assertThat(updated.getIdName(), is("newName"));
        assertThat(updated.getDescription(), is("newDescription"));
        assertThat(updated.getUserLabel(), is("newLabel"));
    }
}
