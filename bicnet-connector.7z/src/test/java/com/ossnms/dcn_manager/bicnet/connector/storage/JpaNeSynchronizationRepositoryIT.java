package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.storage.ne.JpaNeSynchronizationRepository;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationMutationDescriptor;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.unitils.dbunit.annotation.DataSet;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

@DataSet
public class JpaNeSynchronizationRepositoryIT extends HelperItTestBase {

    private JpaNeSynchronizationRepository synchronizationRepo;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        final Supplier<CloseableEntityTransaction> transactionSupplier = repositoryBean.getTransactionSupplier();
        synchronizationRepo = new JpaNeSynchronizationRepository(transactionSupplier);
    }

    @Test
    public void queryWithCounters() throws Exception {
        final Optional<NeSynchronizationData> result = synchronizationRepo.query(2);

        assertThat(result, is(present()));

        final NeSynchronizationData synchronizationData = result.get();
        assertThat(synchronizationData.getAll(), hasValue(123L));
        assertThat(synchronizationData.getAlarms(), hasValue(456L));
        assertThat(synchronizationData.getPacket(), hasValue(789L));
    }

    @Test
    public void queryWithoutCounters() throws Exception {
        final Optional<NeSynchronizationData> result = synchronizationRepo.query(1);

        assertThat(result, is(present()));

        final NeSynchronizationData synchronizationData = result.get();
        assertThat(synchronizationData.getAll(), is(absent()));
        assertThat(synchronizationData.getAlarms(), is(absent()));
        assertThat(synchronizationData.getPacket(), is(absent()));
    }

    @Test
    public void queryAll() throws Exception {
        final Iterable<NeSynchronizationData> result = synchronizationRepo.queryAll();

        assertThat(result, is(Matchers.<NeSynchronizationData>iterableWithSize(2)));
    }

    @Test
    public void modify() throws Exception {
        final Optional<NeSynchronizationData> existing = synchronizationRepo.query(1);

        final NeSynchronizationMutationDescriptor mutation =
            new NeSynchronizationMutationDescriptor(existing.get())
                .setAlarms(9)
                .setAll(8)
                .setPacket(7);

        final Optional<NeSynchronizationData> result = synchronizationRepo.tryUpdate(mutation);

        assertThat(result, is(present()));

        final NeSynchronizationData synchronizationData = result.get();
        assertThat(synchronizationData.getAll(), hasValue(8L));
        assertThat(synchronizationData.getAlarms(), hasValue(9L));
        assertThat(synchronizationData.getPacket(), hasValue(7L));
    }

    @Test
    public void clearCounters() throws Exception {

        synchronizationRepo.clearAllSynchronizationData();

        final Optional<NeSynchronizationData> result1 = synchronizationRepo.query(1);
        final Optional<NeSynchronizationData> result2 = synchronizationRepo.query(2);

        assertThat(result2, is(present()));
        assertThat(result1, is(present()));

        NeSynchronizationData synchronizationData;

        synchronizationData = result1.get();
        assertThat(synchronizationData.getAll(), is(absent()));
        assertThat(synchronizationData.getAlarms(), is(absent()));
        assertThat(synchronizationData.getPacket(), is(absent()));

        synchronizationData = result2.get();
        assertThat(synchronizationData.getAll(), is(absent()));
        assertThat(synchronizationData.getAlarms(), is(absent()));
        assertThat(synchronizationData.getPacket(), is(absent()));
    }
}
