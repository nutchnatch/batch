package com.ossnms.dcn_manager.bicnet.connector.facade;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.ChannelHelper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Map;

import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class ChannelServiceBeanTest {

    @Mock private ChannelHelper helper;
    @Mock private ISessionContext context;

    @InjectMocks private ChannelServiceBean bean;

    @Test
    public void testGetFullChannelList() throws Exception {

        bean.getFullChannelList(context);

        verify(helper).getFullChannelList(context);

    }

    @Test
    public void testGetProperties() throws BcbException {
        final IEMId channelId = new EMIdItem(2);

        bean.getProperties(context, channelId);

        verify(helper).getProperties(context, channelId);
    }

    @Test
    public void testCreateEM() throws BcbException {

        final Property[] emProperties = new Property[0];
        final IMediatorId mediatorId = new MediatorIdItem(4);
        final String emIdName = "name";
        final String emType = "type";

        bean.createEM(context, emType, emIdName, mediatorId, emProperties);

        verify(helper).createEM(context, emType, emIdName, mediatorId, emProperties);
    }

    @Test
    public void testGetRegisteredEmTypes() throws BcbException {

        final String mediatorType = "type";

        bean.getRegisteredEmTypes(context, mediatorType);

        verify(helper).getRegisteredEmTypes(context, mediatorType);
    }

    @Test
    public void testGetAllRegisteredEmTypes() throws BcbException {

        bean.getRegisteredEmTypes(context);

        verify(helper).getRegisteredEmTypes(context);
    }

    @Test
    public void testUpdateProperties() throws BcbException {

        final IEMId channelId = new EMIdItem(5);
        final Map<String, String> properties = Collections.emptyMap();

        bean.updateProperties(context, channelId, properties);

        verify(helper).updateProperties(context, channelId, properties);
    }

}
