package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import org.junit.Test;

import java.util.Optional;

import static java.util.Collections.emptyList;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class ConvertMediatorToMediatorGuiInfoTest {

    private static final int MEDIATOR_ID = 1;
    private static final int ACTIVE_INSTANCE_ID = 10;

    @Test
    public void testBuild_withoutInstances() throws Exception {

        final MediatorEntity entity = new MediatorEntity(
                new MediatorInfoBuilder()
                        .setName("name")
                        .setTypeName("type")
                        .setUserText(Optional.of("user_txt"))
                        .build(MEDIATOR_ID, 0),
                new MediatorConnectionBuilder()
                        .setActualActivationState(ActualActivationState.ACTIVE)
                        .build(MEDIATOR_ID, 0)
        );

        final MediatorInfo info = ConvertMediatorToMediatorGuiInfo.build(entity, emptyList());

        assertThat(info.getMediatorId(), is(MEDIATOR_ID));
        assertThat(info.getGuiActiveActualActivationState(), is(Optional.of(GuiActualActivationState.ACTIVE)));
        assertThat(info.getGuiStandbyActualActivationState(), is(Optional.empty()));
        assertThat(info.getStandbyDisplayState(), is(Optional.of("")));
        assertThat(info.getUserText(), is(Optional.of("user_txt")));
        assertThat(info.isStandbyMediatorConfigured(), is(Optional.of(Boolean.FALSE)));
    }

    @Test
    public void testBuild_withInstances() throws Exception {

        final MediatorEntity entity = new MediatorEntity(
                new MediatorInfoBuilder()
                        .setName("name")
                        .setTypeName("type")
                        .build(MEDIATOR_ID, 0),
                new MediatorConnectionBuilder()
                        .setActualActivationState(ActualActivationState.ACTIVE)
                        .build(MEDIATOR_ID, 0)
        );

        final Iterable<MediatorInstance> instances = ImmutableList.of(
                new MediatorInstance(
                        new MediatorPhysicalDataBuilder()
                                .setPriority(MediatorInstance.PRIMARY_PRIORITY_LEVEL)
                                .build(ACTIVE_INSTANCE_ID, MEDIATOR_ID, 0),
                        new MediatorPhysicalConnectionBuilder()
                                .setActive(true)
                                .setActualActivationState(ActualActivationState.ACTIVE)
                                .build(ACTIVE_INSTANCE_ID, MEDIATOR_ID, 0)
                ),
                new MediatorInstance(
                        new MediatorPhysicalDataBuilder()
                                .setPriority(MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1)
                                .build(ACTIVE_INSTANCE_ID, MEDIATOR_ID, 0),
                        new MediatorPhysicalConnectionBuilder()
                                .setActive(false)
                                .setActualActivationState(ActualActivationState.INACTIVE)
                                .build(ACTIVE_INSTANCE_ID, MEDIATOR_ID, 0)
                )
        );

        final MediatorInfo info = ConvertMediatorToMediatorGuiInfo.build(entity, instances);

        assertThat(info.getMediatorId(), is(MEDIATOR_ID));
        assertThat(info.getGuiActiveActualActivationState(), is(Optional.of(GuiActualActivationState.ACTIVE)));
        assertThat(info.getGuiStandbyActualActivationState(), is(Optional.of(GuiActualActivationState.INACTIVE)));
        assertThat(info.getStandbyDisplayState(), is(Optional.of(ConvertMediatorToBcb.describe(ActualActivationState.INACTIVE))));
        assertThat(info.getUserText(), is(Optional.empty()));
        assertThat(info.isStandbyMediatorConfigured(), is(Optional.of(Boolean.TRUE)));
    }

    @Test
    public void testActualActivationStateConversion() throws Exception {

        assertThat(ConvertMediatorToMediatorGuiInfo.convert(ActualActivationState.ACTIVE), is(GuiActualActivationState.ACTIVE));
        assertThat(ConvertMediatorToMediatorGuiInfo.convert(ActualActivationState.ACTIVATING), is(GuiActualActivationState.ACTIVATING));
        assertThat(ConvertMediatorToMediatorGuiInfo.convert(ActualActivationState.DEACTIVATING), is(GuiActualActivationState.DEACTIVATING));
        assertThat(ConvertMediatorToMediatorGuiInfo.convert(ActualActivationState.INACTIVE), is(GuiActualActivationState.INACTIVE));
        assertThat(ConvertMediatorToMediatorGuiInfo.convert(ActualActivationState.FAILED), is(GuiActualActivationState.FAILED));

    }
}
