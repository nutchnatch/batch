package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ConvertChannelToChannelInfoTest {

    private static final int MEDIATOR_ID = 2;
    private static final int CHANNEL_ID = 1;
    private static final int CHANNEL_INSTANCE_ID = 10;
    private static final int MEDIATOR_INSTANCE_ID = 20;

    @Test
    public void testBasicInfo() {
        final ChannelEntity channelEntity = new ChannelEntity(
                new ChannelInfoBuilder().setType("type").build(CHANNEL_ID, 1, MEDIATOR_ID),
                new ChannelConnectionBuilder().setActivation(ActualActivationState.ACTIVE).build(CHANNEL_ID, 1),
                new ChannelUserPreferencesBuilder().setUserText(Optional.of("text")).build(CHANNEL_ID, 1));

        final ChannelInfo info = ConvertChannelToChannelGuiInfo.build(channelEntity, Collections.emptyList());

        assertThat(info.getChannelId(), is(CHANNEL_ID));
        assertThat(info.getGuiActiveActualActivationState(), is(Optional.of(GuiActualActivationState.ACTIVE)));
        assertThat(info.getGuiStandbyActualActivationState(), is(Optional.empty()));
        assertThat(info.getStandbyDisplayState(), is(Optional.of("")));
        assertThat(info.getUserText(), is(Optional.of("text")));
    }

    @Test
    public void testWithStandby() {
        final ChannelEntity channelEntity = new ChannelEntity(
                new ChannelInfoBuilder().setType("type").build(CHANNEL_ID, 1, MEDIATOR_ID),
                new ChannelConnectionBuilder().setActivation(ActualActivationState.ACTIVE).build(CHANNEL_ID, 1),
                new ChannelUserPreferencesBuilder().setUserText(Optional.of("text")).build(CHANNEL_ID, 1));

        final ChannelPhysicalConnectionData standbyData = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.INACTIVE)
                .setActive(false)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 1);

        final ChannelInfo info = ConvertChannelToChannelGuiInfo.build(channelEntity, Collections.singleton(standbyData));

        assertThat(info.getChannelId(), is(CHANNEL_ID));
        assertThat(info.getGuiActiveActualActivationState(), is(Optional.of(GuiActualActivationState.ACTIVE)));
        assertThat(info.getGuiStandbyActualActivationState(), is(Optional.of(GuiActualActivationState.INACTIVE)));
        assertThat(info.getStandbyDisplayState(), is(Optional.of("Inactive")));
        assertThat(info.getUserText(), is(Optional.of("text")));
    }

}
