package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentMarkable;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.connector.storage.ne.JpaNeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentUpdatedEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class NeContainerAssignmentHelperTest {
    private static final int NE_ID = 1;
    private static final int CONTAINER_ID = 2;
    private static final int VERSION = 100;

    @Mock private ISessionContext sessionContext;
    @Mock private JpaNeUserPreferencesRepository neUserPreferencesRepository;
    @Mock private JpaNetworkElementRepositoryBean neRepository;
    @Mock private JpaContainerRepositoryBean containerRepository;
    @Mock private JpaSettingsRepositoryBean settingsRepository;
    @Mock private ContainerNotifications notifications;
    @Mock private LoggerManagerImpl loggerManager;

    private NeContainerAssignmentHelper helper;

    @Before public void setUp() throws Exception {
        helper = new NeContainerAssignmentHelper();

        helper.setSettingsRepository(settingsRepository);
        helper.setContainerRepository(containerRepository);
        helper.setLoggerManager(loggerManager);
        helper.setNotifications(notifications);
        helper.setNeRepository(neRepository);

        when(neRepository.getNeUserPreferencesRepository()).thenReturn(neUserPreferencesRepository);

        when(neUserPreferencesRepository.query(NE_ID)).
                thenReturn(Optional.of(new NeUserPreferencesData.NeUserPreferencesBuilder().setName("name")
                        .setUserText(Optional.of("text")).build(NE_ID, 1)));
    }

    @Test public void getSingleNeGenericContainerAssignment() throws Exception {
        INeGenericContainerAssignmentId assignmentId = new NeGenericContainerAssignmentIdItem(NE_ID, CONTAINER_ID);

        NeAssignmentData neAssignmentData = new NeAssignmentData(
                new ContainerInfo(CONTAINER_ID, VERSION, "container_name"), NE_ID, AssignmentType.PRIMARY);

        when(containerRepository.queryNeAssignment(NE_ID, CONTAINER_ID)).thenReturn(Optional.of(neAssignmentData));

        final INeGenericContainerAssignment newAssignment = helper
                .getSingleNeGenericContainerAssignment(sessionContext, assignmentId);

        assertThat(newAssignment.getGenericContainerId(), is(CONTAINER_ID));
        assertThat(newAssignment.getNetworkElementId(), is(NE_ID));

        verify(containerRepository, times(1)).queryNeAssignment(NE_ID, CONTAINER_ID);
    }

    @Test public void createNeGenericContainerAssignment() throws Exception {
        INeGenericContainerAssignment neAssignment = new NeGenericContainerAssignmentItem();
        neAssignment.setNetworkElementId(NE_ID);
        neAssignment.setGenericContainerId(CONTAINER_ID);
        neAssignment.setPrimary(true);

        when(containerRepository.query(CONTAINER_ID))
                .thenReturn(Optional.of(new ContainerInfo(CONTAINER_ID, VERSION, "container_name")));

        helper.createNeGenericContainerAssignment(sessionContext, neAssignment);

        verify(containerRepository, times(1)).query(CONTAINER_ID);
        verify(neUserPreferencesRepository, times(1)).query(NE_ID);
        verify(notifications, times(1)).notifyChanges(Matchers.any(ContainerNeAssignmentAddedEvent.class));
    }

    @Test
    public void deleteNeGenericContainerAssignment_last_assignment() throws Exception {
        INeGenericContainerAssignmentId assignmentId = new NeGenericContainerAssignmentIdItem(NE_ID, CONTAINER_ID);
        final GlobalSettings globalSettings = GlobalSettings.build().toGlobalSettings(1, 1);
        NeAssignmentData neAssignmentData = new NeAssignmentData(
                new ContainerInfo(CONTAINER_ID, VERSION, "container_name"), NE_ID, AssignmentType.PRIMARY);

        when(containerRepository.queryNeAssignment(NE_ID, CONTAINER_ID)).thenReturn(Optional.of(neAssignmentData));
        when(containerRepository.tryRemoveNeAssignment(neAssignmentData)).thenReturn(true);
        when(containerRepository.queryAllByNE(NE_ID)).thenReturn(ImmutableList.of(neAssignmentData));
        when(settingsRepository.getSettings()).thenReturn(globalSettings);
        when(containerRepository.queryByName(globalSettings.getDefaultContainerName()))
                .thenReturn(Optional.of(new ContainerInfo(CONTAINER_ID, VERSION, globalSettings.getDefaultContainerName())));

        helper.deleteNeGenericContainerAssignment(sessionContext, assignmentId);

        verify(neUserPreferencesRepository, times(1)).query(NE_ID);
        verify(notifications, times(1)).notifyChanges(Matchers.any(ContainerNeAssignmentRemovedEvent.class));
    }

    public void deleteNeGenericContainerAssignment() throws Exception {
        INeGenericContainerAssignmentId assignmentId = new NeGenericContainerAssignmentIdItem(NE_ID, CONTAINER_ID);

        NeAssignmentData neAssignmentData1 = new NeAssignmentData(
                new ContainerInfo(CONTAINER_ID, VERSION, "container_name1"), NE_ID, AssignmentType.PRIMARY);

        NeAssignmentData neAssignmentData2 = new NeAssignmentData(
                new ContainerInfo(CONTAINER_ID + 1, VERSION, "container_name2"), NE_ID, AssignmentType.PRIMARY);

        when(containerRepository.queryNeAssignment(NE_ID, CONTAINER_ID)).thenReturn(Optional.of(neAssignmentData1));

        when(containerRepository.tryRemoveNeAssignment(neAssignmentData1)).thenReturn(true);

        when(containerRepository.queryAllByNE(NE_ID)).thenReturn(ImmutableList.of(neAssignmentData1, neAssignmentData2));

        helper.deleteNeGenericContainerAssignment(sessionContext, assignmentId);

        verify(neUserPreferencesRepository, times(1)).query(NE_ID);
        verify(notifications, times(1)).notifyChanges(Matchers.any(ContainerNeAssignmentRemovedEvent.class));
    }

    @Test public void modifyNeGenericContainerAssignment() throws Exception {
        final INeGenericContainerAssignmentMarkable markableInput = NeGenericContainerAssignmentItem
                .markableNeGenericContainerAssignment(null);

        markableInput.setGenericContainerId(CONTAINER_ID);
        markableInput.setNetworkElementId(NE_ID);
        markableInput.setPrimary(true);

        when(containerRepository.query(CONTAINER_ID))
                .thenReturn(Optional.of(new ContainerInfo(CONTAINER_ID, VERSION, "container_name")));

        when(containerRepository.tryUpdateNeAssignment(Matchers.any(NeAssignmentData.class))).thenReturn(true);

        final INeGenericContainerAssignmentMarkable markableResult = helper
                .modifyNeGenericContainerAssignment(sessionContext, markableInput);

        assertThat(markableInput, is(markableResult));

        verify(containerRepository, times(1)).query(CONTAINER_ID);
        verify(neUserPreferencesRepository, times(1)).query(NE_ID);
        verify(notifications, times(1)).notifyChanges(Matchers.any(ContainerNeAssignmentUpdatedEvent.class));
    }
}