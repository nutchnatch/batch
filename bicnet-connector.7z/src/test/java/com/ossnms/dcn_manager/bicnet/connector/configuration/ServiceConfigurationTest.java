package com.ossnms.dcn_manager.bicnet.connector.configuration;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.elementMgmt.IGctMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.Log4jLevel;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeDataTransferSettings;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkSettings;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.DataTransferSettingsAdapter;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ServiceConfigurationTest {

    @Mock private ChannelInfoRepository channelInfoRepository;
    @Mock private SettingsRepository settingsRepository;
    @Mock private ChannelEntityRepository channelRepository;
    @Mock private JpaNetworkElementRepositoryBean neRepository;
    @Mock private StaticConfigurationSingleton configuration;
    @Mock private MediatorInstanceEntityRepository mediatorInstanceRepository;
    @Mock private IGctMgrFacade gctManager;
    @Mock private Types<NeType> neTypes;
    @Mock private Types<ChannelType> channelTypes;
    @Mock private NeType neType;
    @Mock private ChannelType channelType;

    @InjectMocks private ServiceConfiguration serviceConfiguration;

    private static final int MEDIATOR_ID = 1;
    private static final String TYPE = "A type";
    private static final String CORE_ID = "A core id";
    private static final boolean ACTIVATION_REQUIRED = true;
    private static final int ONE_VERSION = 1;
    private static final int ONE_ID = 1;

    private static final String GLOBAL_USERNAME = "global_username";
    private static final String GLOBAL_PASSWORD = "global_password";
    private static final String GLOBAL_UPLOADPATH = "global_root/path";
    private static final String GLOBAL_HOST = "1.1.1.1";
    private static final String NE_USERNAME = "ne_username";
    private static final String NE_PASSWORD = "ne_password";
    private static final String NE_UPLOADPATH = "ne_root/path";
    private static final String MEDIATION_HOST = "mediationHost";
    private static final String LOOPBACK = "localhost";

    private static final Map<String, String> map =  ImmutableMap.of( "SFTP_IP",      GLOBAL_HOST,
                                                        "SFTP_USER",    GLOBAL_USERNAME,
                                                        "SFTP_PASSWORD",GLOBAL_PASSWORD,
                                                        "SFTP_ROOTPATH",GLOBAL_UPLOADPATH);

    private static final ChannelInfoData channel = new ChannelInfoBuilder()
                                                .setType(TYPE)
                                                .setCoreId(CORE_ID)
                                                .setActivationRequired(ACTIVATION_REQUIRED)
                                                .build(ONE_ID, ONE_VERSION, MEDIATOR_ID);

    private static final MediatorInstance mediatorInstance = new MediatorInstance(
            new MediatorPhysicalDataBuilder().setHost(MEDIATION_HOST).setPriority(MediatorInstance.PRIMARY_PRIORITY_LEVEL).build(ONE_ID, MEDIATOR_ID, ONE_VERSION),
            new MediatorPhysicalConnectionBuilder().setActive(true).build(ONE_ID, MEDIATOR_ID, ONE_VERSION)
        );

    private NeEntity ne;

    @Before public void setUp() throws Exception {
        ne = new NeEntity(
                new NeConnectionBuilder().build(1, 1),
                new NeOperationBuilder().build(1, 1),
                new NeInfoBuilder().setProxyType("neType").build(1, 10, 1),
                new NeSynchronizationBuilder().build(1, 1),
                new NeUserPreferencesBuilder().setName("n").
                        setPassword(Optional.of("00010203")).
                        setDataTransferSettings(new DataTransferSettingsAdapter().
                                setUsername(Optional.of(NE_USERNAME)).
                                setPassword(Optional.of(NE_PASSWORD)).
                                setUploadpath(Optional.of(NE_UPLOADPATH))).
                        build(1, 1));

        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
        when(channelInfoRepository.query(anyInt())).thenReturn(Optional.of(channel));
        when(configuration.getChannelTypes()).thenReturn(channelTypes);
        when(channelTypes.get(anyString())).thenReturn(channelType);
        when(channelType.supportsGlobalSFTP()).thenReturn(true);
    }

    @Test
    public void testGetNativeNamingEnabled() {
        final GlobalSettings settings = GlobalSettings.build().setShowNativeNeNaming(true).toGlobalSettings(1,1);
        when(settingsRepository.getSettings()).thenReturn(settings);

        final INetworkSettings theNetworkSettings = serviceConfiguration.getTheNetworkSettings(null);
        assertThat(theNetworkSettings.getNetworkSettingsId().getId(), not(is(0)));
        assertThat(theNetworkSettings.getShowNativeNeNaming(), is(true));
    }

    @Test
    public void testGetNativeNamingDisabled() {
        final GlobalSettings settings = GlobalSettings.build().setShowNativeNeNaming(false).toGlobalSettings(1,1);
        when(settingsRepository.getSettings()).thenReturn(settings);

        final INetworkSettings theNetworkSettings = serviceConfiguration.getTheNetworkSettings(null);
        assertThat(theNetworkSettings.getNetworkSettingsId().getId(), not(is(0)));
        assertThat(theNetworkSettings.getShowNativeNeNaming(), is(false));
    }

    @Test
    public void testGetNeDataTransferSettings_ExceptionNeNotFound() {
        try {
            when(neRepository.queryNe(1)).thenReturn(Optional.empty());
            serviceConfiguration.getNeDataTransferSettings(null, new NEIdItem(1));
        } catch (RepositoryException | BcbException e) {
            assertThat(e.getMessage(), is("NeId 1 not found"));
        }
    }

    @Test
    public void testGetNeDataTransferSettings_ExceptionGlobalSettingsEmpty() throws Exception {
        ne = new NeEntity(
                new NeConnectionBuilder().build(1, 1),
                new NeOperationBuilder().build(1, 1),
                new NeInfoBuilder().setProxyType("neType").build(1, 10, 1),
                new NeSynchronizationBuilder().build(1, 1),
                new NeUserPreferencesBuilder().setName("n").setPassword(Optional.of("00010203")).build(1, 1));

        when(neRepository.queryNe(1)).thenReturn(Optional.of(ne));

        when(configuration.getNeTypes()).thenReturn(neTypes);
        when(neTypes.get("neType")).thenReturn(neType);
        when(neType.getName()).thenReturn("neTypeName");
        when(gctManager.getSFTPConfigDetails(null)).thenReturn(null);

        assertNull(serviceConfiguration.getNeDataTransferSettings(null, new NEIdItem(1)));
    }

    @Test
    public void testGetNeDataTransferSettings_ExceptionChannelNotFound() {
        try {
            mockNeTypeAndSFTPSettings();

            when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
            when(channelInfoRepository.query(ne.getInfo().getChannelId())).thenReturn(Optional.empty());


            serviceConfiguration.getNeDataTransferSettings(null, new NEIdItem(1));
        } catch (RepositoryException | BcbException e) {
            assertThat(e.getMessage(), is("ChannelId 10 not found"));
        }
    }

    @Test
    public void testGetNeDataTransferSettings_ExceptionMediatorNotFound() {
        try {
            mockNeTypeAndSFTPSettings();

            when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
            when(channelInfoRepository.query(ne.getInfo().getChannelId())).thenReturn(Optional.of(channel));

            when(mediatorInstanceRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.emptyList());

            serviceConfiguration.getNeDataTransferSettings(null, new NEIdItem(1));

        } catch (RepositoryException | BcbException e) {
            assertThat(e.getMessage(), is("Active instance for MediatorId 1 not found"));
        }
    }

    @Test
    public void testGetNeDataTransferSettings_ChannelNotSupported() throws Exception {
        ne = new NeEntity(
                new NeConnectionBuilder().build(1, 1),
                new NeOperationBuilder().build(1, 1),
                new NeInfoBuilder().setProxyType("neType").build(1, 10, 1),
                new NeSynchronizationBuilder().build(1, 1),
                new NeUserPreferencesBuilder().setName("n").setPassword(Optional.of("00010203")).build(1, 1));

        when(neRepository.queryNe(1)).thenReturn(Optional.of(ne));
        when(configuration.getNeTypes()).thenReturn(neTypes);
        when(neTypes.get("neType")).thenReturn(neType);
        when(neType.getName()).thenReturn("neTypeName");
        when(gctManager.getSFTPConfigDetails(null)).thenReturn(null);

        final INeDataTransferSettings data = serviceConfiguration.getNeDataTransferSettings(null, new NEIdItem(1));

        assertThat(data, nullValue());
    }

    @Test(expected = BcbException.class)
    public void testGetNeDataTransferSettings_ChannelTypeNotSupported() throws Exception {
        when(channelTypes.get(anyString())).thenReturn(null);
        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
        when(channelInfoRepository.query(ne.getInfo().getChannelId())).thenReturn(Optional.of(channel));

        when(mediatorInstanceRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(mediatorInstance));

        serviceConfiguration.getNeDataTransferSettings(null, new NEIdItem(1));
    }

    @Test
    public void testGetNeDataTransferSettings_FromSystemProperties() throws Exception {

        ne = new NeEntity(
                new NeConnectionBuilder().build(1, 1),
                new NeOperationBuilder().build(1, 1),
                new NeInfoBuilder().setProxyType("neType").build(1, 10, 1),
                new NeSynchronizationBuilder().build(1, 1),
                new NeUserPreferencesBuilder().setName("n").setPassword(Optional.of("00010203")).build(1, 1));

        mockNeTypeAndSFTPSettings();

        final INeDataTransferSettings data = serviceConfiguration.getNeDataTransferSettings(null, new NEIdItem(1));
        assertNotNull(data);
        assertThat(data.getUserName(), is(GLOBAL_USERNAME));
        assertThat(data.getPassword(), is(GLOBAL_PASSWORD));
        assertThat(data.getUploadPath(), is(GLOBAL_UPLOADPATH));
        assertThat(data.getIpAddress(), is(GLOBAL_HOST));
        assertThat(data.getScpMode(), is(false));
    }

    @Test
    public void testGetNeDataTransferSettings_HostFromMediator() throws Exception {
        mockNeTypeAndSFTPSettings();

        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
        when(channelInfoRepository.query(ne.getInfo().getChannelId())).thenReturn(Optional.of(channel));

        when(mediatorInstanceRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(mediatorInstance));

        final INeDataTransferSettings data = serviceConfiguration.getNeDataTransferSettings(null, new NEIdItem(1));
        assertNotNull(data);
        assertThat(data.getUserName(), is(NE_USERNAME));
        assertThat(data.getPassword(), is(NE_PASSWORD));
        assertThat(data.getUploadPath(), is(NE_UPLOADPATH));
        assertThat(data.getIpAddress(), is(MEDIATION_HOST));
        assertThat(data.getScpMode(), is(false));
    }

    @Test
    public void testGetNeDataTransferSettings_LoopbackHostName() throws Exception {
        ne = new NeEntity(
                new NeConnectionBuilder().build(1, 1),
                new NeOperationBuilder().build(1, 1),
                new NeInfoBuilder().setProxyType("neType").build(1, 10, 1),
                new NeSynchronizationBuilder().build(1, 1),
                new NeUserPreferencesBuilder().setName("n").
                                            setPassword(Optional.of("00010203")).
                                            setDataTransferSettings(new DataTransferSettingsAdapter().
                                                                        setIpAddress(Optional.of(LOOPBACK)).
                                                                        setUsername(Optional.of(NE_USERNAME)).
                                                                        setPassword(Optional.of(NE_PASSWORD)).
                                                                        setUploadpath(Optional.of(NE_UPLOADPATH))).
                                            build(1, 1));
        mockNeTypeAndSFTPSettings();

        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
        when(channelInfoRepository.query(ne.getInfo().getChannelId())).thenReturn(Optional.of(channel));

        when(mediatorInstanceRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(mediatorInstance));

        final INeDataTransferSettings data = serviceConfiguration.getNeDataTransferSettings(null, new NEIdItem(1));
        assertNotNull(data);
        assertThat(data.getUserName(), is(NE_USERNAME));
        assertThat(data.getPassword(), is(NE_PASSWORD));
        assertThat(data.getUploadPath(), is(NE_UPLOADPATH));
        assertThat(data.getIpAddress(), is(MEDIATION_HOST));
        assertThat(data.getScpMode(), is(false));
    }

    @Test
    public void testGetName() throws BcbException {
        assertThat(serviceConfiguration.getName(null), is(BiCNetComponentType.DCN_MANAGER.toString()));
    }

    @Test
    public void testGetDescription() throws BcbException {
        assertThat(serviceConfiguration.getDescription(null), is(BiCNetComponentType.DCN_MANAGER.toString()));
    }

    @Test
    public void testGetComponentType() throws BcbException {
        assertThat(serviceConfiguration.getComponentType(null), is(BiCNetComponentType.DCN_MANAGER));
    }

    @Test
    public void testGetLog4JDefaultLevel() throws BcbException {
        assertThat(serviceConfiguration.getLog4JDefaultLevel(null), is(Log4jLevel.INFO));
    }

    private void mockNeTypeAndSFTPSettings() throws BcbException, RepositoryException {
        when(neRepository.queryNe(1)).thenReturn(Optional.of(ne));
        when(gctManager.getSFTPConfigDetails(null)).thenReturn(map);
        when(configuration.getServerHost()).thenReturn(MEDIATION_HOST);
    }
}
