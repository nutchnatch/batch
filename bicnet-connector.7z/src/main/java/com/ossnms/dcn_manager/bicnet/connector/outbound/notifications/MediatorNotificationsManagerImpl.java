package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfoNotification;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertMediatorToFullMediator;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.factory.SystemContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorStartingUpEvent;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Collections;
import java.util.Optional;
import java.util.function.Consumer;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertMediatorToBcb.convert;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertMediatorToBcb.fillExistingMarkable;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static java.lang.Boolean.valueOf;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Implements the bridge between our core and the BiCNet notifications service.
 * Handles only notifications about changes to the state of Mediators.
 */
@ApplicationScoped
public class MediatorNotificationsManagerImpl
        extends NotificationsManagerBase<MediatorEvent>
        implements MediatorNotifications {

    private static final Logger LOGGER = getLogger(MediatorNotificationsManagerImpl.class);

    @Inject
    private StaticConfiguration configuration;

    @Inject
    private SecurityManager securityManager;

    @Inject @DcnManager
    private MediatorEntityRepository mediatorRepository;

    @Inject @DcnManager
    private MediatorInstanceEntityRepository mediatorInstancesRepository;

    @Inject
    private LoggerManagerImpl loggerManager;

    @Inject @DcnManager @SystemContext
    private BicnetCallContext systemContext;

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyCreate(@Nonnull MediatorEntity mediator) {

    	MediatorType type = getType(mediator.getInfo());
    	
        Iterable<MediatorInstance> instances = getInstances(mediator.getInfo().getId());
		sendObjectCreatedNotification(
            convert(getType(mediator.getInfo()), mediator, instances));
        sendCustomNotificationToClient(
                new FullMediatorDataCreateNotification(ConvertMediatorToFullMediator.convert(type, mediator, instances)));

    }

    private Iterable<MediatorInstance> getInstances(int mediatorId) {
        try {
            return mediatorInstancesRepository.queryAll(mediatorId);
        } catch (final RepositoryException e) {
            LOGGER.warn("Could not retrieve the list of mediator instances for {}. Using empty list. {}",
                mediatorId, Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyDelete(@Nonnull MediatorEntity mediator) {

        sendObjectDeletedNotification(new MediatorIdItem(mediator.getInfo().getId()));

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyUpdate(@Nonnull MediatorInfoMutationDescriptor mutation) {
        final IMediatorMarkable markable = MediatorItem.markableMediator(null);
        fillExistingMarkable(mutation, markable);
        sendAttributeValueChangeNotification(markable);
        sendMediatorGuiInfoChanges(mutation);

        securityManager.updateMediator(mutation.getTarget());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(@Nonnull MediatorActivatedEvent mediatorActivatedEvent) {
        notify(mediatorActivatedEvent, MediatorActivationState.ACTIVE, Message.ACTIVE, GuiActualActivationState.ACTIVE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(@Nonnull MediatorDeactivatedEvent mediatorDeactivatedEvent) {
        notify(mediatorDeactivatedEvent, MediatorActivationState.INACTIVE, Message.INACTIVE, GuiActualActivationState.INACTIVE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(@Nonnull MediatorActivationFailedEvent mediatorActivationFailedEvent) {
        notify(mediatorActivationFailedEvent, MediatorActivationState.FAILED, Message.FAILED, GuiActualActivationState.FAILED);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(@Nonnull DeactivateMediatorEvent event) {
        final IMediatorMarkable markable = MediatorItem.markableMediator(null);
        markable.setId(event.getMediatorId());
        markable.setActivation(EnableSwitch.DISABLED);
        markable.setPropertiesValid(true);
        sendAttributeValueChangeNotification(markable);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(@Nonnull MediatorActivatingEvent mediatorActivatingEvent) {
        notify(mediatorActivatingEvent, MediatorActivationState.INACTIVE, Message.ACTIVATING, GuiActualActivationState.ACTIVATING);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(@Nonnull MediatorDeactivatingEvent mediatorDeactivatingEvent) {
        notify(mediatorDeactivatingEvent, MediatorActivationState.INACTIVE, Message.DEACTIVATING, GuiActualActivationState.DEACTIVATING);
    }

	@Override
	public void notifyChanges(@Nonnull MediatorStartingUpEvent mediatorStartingUpEvent) {
        notifyPhysicalEvent(mediatorStartingUpEvent,
                e -> sendSystemNotification(e, MediatorActivationState.INACTIVE, Message.STARTING_UP, GuiActualActivationState.ACTIVATING),
                e -> sendClientNotification(e, Message.STARTING_UP, GuiActualActivationState.ACTIVATING));
	}

	@Override
	public void notifyChanges(@Nonnull MediatorShuttingDownEvent mediatorShuttingDownEvent) {
	    notifyPhysicalEvent(mediatorShuttingDownEvent,
                e -> sendSystemNotification(e, MediatorActivationState.INACTIVE, Message.SHUTTING_DOWN, GuiActualActivationState.DEACTIVATING),
                e -> sendClientNotification(e, Message.SHUTTING_DOWN, GuiActualActivationState.DEACTIVATING));
	}

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(@Nonnull ActivateMediatorEvent event) {
        final IMediatorMarkable markable = MediatorItem.markableMediator(null);
        markable.setId(event.getMediatorId());
        markable.setActivation(EnableSwitch.ENABLED);
        markable.setPropertiesValid(true);
        sendAttributeValueChangeNotification(markable);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyUpdateInstance(MediatorInstance physicalInstanceUpdated) {
        if (physicalInstanceUpdated.getConnection().isActive()) {
            final IMediatorMarkable markable = MediatorItem.markableMediator(null);
            markable.setId(physicalInstanceUpdated.getPhysicalInfo().getLogicalMediatorId());
            markable.setMediatorHost(physicalInstanceUpdated.getPhysicalInfo().getHost());
            markable.setDisplayAddress(physicalInstanceUpdated.getPhysicalInfo().getHost());
            markable.setPropertiesValid(true);
            sendAttributeValueChangeNotification(markable);
        }
    }

    @Override
    public void notifyDeleteInstance(int mediatorId, int physicalInstanceId) {

        /*
        Note that it should only be possible to delete secondary (standby) instances.
        In a BiCNet environment there is only one secondary instance, so if that one is deleted
        then we assume that there is no standby instance configured for this mediator.
         */

        sendCustomNotificationToClient(new MediatorInfoNotification(
                new MediatorInfo(mediatorId)
                        .setGuiStandbyActualActivationState(null)
                        .setStandbyDisplayState("")
                        .setStandbyMediatorConfigured(FALSE)
        ));

    }

    @Override
    public void notifyCreateInstance(MediatorInstance created) {

        if (created.getConnection().isActive()) {
            return;
        }

        sendCustomNotificationToClient(new MediatorInfoNotification(
                new MediatorInfo(created.getPhysicalInfo().getLogicalMediatorId())
                        .setGuiStandbyActualActivationState(GuiActualActivationState.INACTIVE)
                        .setStandbyDisplayState(tr(Message.INACTIVE))
                        .setStandbyMediatorConfigured(TRUE)
        ));

    }

    private MediatorType getType(MediatorInfoData infoData) {
        return configuration.getMediatorTypes().get(infoData.getTypeName());
    }

    private void notifyPhysicalEvent(ActualMediatorStateEvent mediatorEvent, Consumer<ActualMediatorStateEvent> systemNotifier, Consumer<ActualMediatorStateEvent> clientNotifier) {

        mediatorEvent.getOriginatingPhysicalEvent()
            .map(event -> event.isInstanceActive() ? systemNotifier : clientNotifier)
            .ifPresent(f -> f.accept(mediatorEvent));

    }

    private void notify(ActualMediatorStateEvent mediatorEvent, MediatorActivationState activationState, Message message, GuiActualActivationState guiActualActivationState) {

        if (mediatorEvent.getOriginatingPhysicalEvent().isPresent()) {
            final PhysicalMediatorStateEvent physicalMediatorStateEvent =
                    mediatorEvent.getOriginatingPhysicalEvent().get();
            if (!physicalMediatorStateEvent.isInstanceActive()) {
                sendClientNotification(mediatorEvent, message, guiActualActivationState);
                logStateChange(mediatorEvent, message);
            }
        } else {
            sendSystemNotification(mediatorEvent, activationState, message, guiActualActivationState);
            logStateChange(mediatorEvent, message);
        }

    }

    private void sendSystemNotification(ActualMediatorStateEvent mediatorEvent, MediatorActivationState activationState,
            Message message, GuiActualActivationState guiActualActivationState) {
        final IMediatorMarkable markable = MediatorItem.markableMediator(null);
        markable.setId(mediatorEvent.getMediatorId());
        markable.setActualActivationState(activationState);
        markable.setAdditionalInfo(mediatorEvent.getDetailedDescription());
        markable.setDisplayState(tr(message));
        markable.setPropertiesValid(true);

        sendAttributeValueChangeNotification(markable);

        sendCustomNotificationToClient(new MediatorInfoNotification(
                new MediatorInfo(mediatorEvent.getMediatorId())
                        .setGuiActualActivationState(guiActualActivationState)
        ));

    }

    private void sendClientNotification(ActualMediatorStateEvent mediatorEvent, Message message,
            GuiActualActivationState guiActualActivationState) {

        sendCustomNotificationToClient(new MediatorInfoNotification(
                new MediatorInfo(mediatorEvent.getMediatorId())
                        .setGuiStandbyActualActivationState(guiActualActivationState)
                        .setStandbyDisplayState(tr(message))
                        .setStandbyMediatorConfigured(valueOf(guiActualActivationState != null))
        ));

    }

    private void logStateChange(ActualMediatorStateEvent event, Message stateDescription) {
        final int mediatorId = event.getMediatorId();
        try {
            final Optional<String> mediatorName = mediatorRepository.queryMediatorName(mediatorId);
            if (mediatorName.isPresent()) {
                loggerManager.createSystemEventLog(systemContext,
                    new LoggerItemMediator(
                        mediatorName.get(),
                        StringUtils.join(new String[] {
                            tr(Message.MEDIATOR_STATE_CHANGED, stateDescription.toString()),
                            event.getDetailedDescription(),
                            event.getOriginatingPhysicalEvent()
                                .filter(physical -> !physical.isInstanceActive())
                                .map(physical -> "(standby)")
                                .orElse(null)
                        }, ' '),
                        MessageSeverity.INFO));
            } else {
                LOGGER.warn("Failed to obtain mediator {} name, no log entry will be emitted.", mediatorId);
            }
        } catch (final RepositoryException e) {
            LOGGER.warn("Failed to obtain mediator {} name, no log entry will be emitted. {}", mediatorId,
                    Throwables.getStackTraceAsString(e));
        }
    }

    private void sendMediatorGuiInfoChanges(MediatorInfoMutationDescriptor preferences) {
        if (preferences.getUserText().isPresent()) {
            sendCustomNotificationToClient(new MediatorInfoNotification(
                    new MediatorInfo(preferences.getTarget().getId())
                            .setUserText(preferences.getUserText().get())));
        }
    }

}
