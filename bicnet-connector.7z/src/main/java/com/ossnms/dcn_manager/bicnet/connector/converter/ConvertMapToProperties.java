package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.base.Function;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Properties;

public class ConvertMapToProperties implements Function<Map<String, String>, Properties>{

    public static Properties convertToProps(@Nonnull Map<String, String> input) {
        final Properties properties = new Properties();
        properties.putAll(input);
        
        return properties;
    }

    @Override
    public Properties apply(Map<String, String> input) {
        return input == null ? null : convertToProps(input);
    }
}
