package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.mysema.query.BooleanBuilder;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.ISystemGenericContainerAssignmentFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentMarkable;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertSystemAssignmentDataToBcb;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.commands.container.MoveSystemsToContainer;
import com.ossnms.dcn_manager.commands.container.assignment.AddSystemAssignment;
import com.ossnms.dcn_manager.commands.container.assignment.DeleteSystemAssignment;
import com.ossnms.dcn_manager.commands.container.assignment.UpdateSystemAssignment;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.container.entities.QContainerSystemAssignmentDb;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.utils.Optionals;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.persistence.PersistenceException;
import java.util.Optional;
import java.util.stream.Stream;

import static com.google.common.base.Functions.compose;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.Arrays.asList;

/**
 * System Container assignments Public services.
 */
public class SystemContainerAssignmentHelper implements ISystemGenericContainerAssignmentFacade {
    private static final Logger LOGGER = LoggerFactory.getLogger(SystemContainerAssignmentHelper.class);

    private JpaSystemRepositoryBean systemRepository;
    private JpaSettingsRepositoryBean settingsRepository;
    private JpaContainerRepositoryBean containerRepository;
    private ContainerNotifications notifications;
    private LoggerManagerImpl loggerManager;

    /** Settings Repository injection point. */
    @Inject
    public void setSettingsRepository(@DcnManager JpaSettingsRepositoryBean settingsRepository) {
        this.settingsRepository = settingsRepository;
    }

    /** System Repository injection point. */
    @Inject public void setSystemRepository(@DcnManager JpaSystemRepositoryBean systemRepository) {
        this.systemRepository = systemRepository;
    }

    /** Container Repository injection point. */
    @Inject public void setContainerRepository(@DcnManager JpaContainerRepositoryBean containerRepository) {
        this.containerRepository = containerRepository;
    }

    /** Container Notifications Manager injection point. */
    @Inject public void setNotifications(ContainerNotifications notifications) {
        this.notifications = notifications;
    }

    /** Logger Manager injection point. */
    @Inject public void setLoggerManager(LoggerManagerImpl loggerManager) {
        this.loggerManager = loggerManager;
    }

    @Override public ISystemGenericContainerAssignment getSingleSystemGenericContainerAssignment(
            ISessionContext sessionContext, ISystemGenericContainerAssignmentId systemGenericAssignId)
            throws BcbException {
        try {
            final Optional<SystemAssignmentData> systemAssignment = containerRepository
                    .querySystemAssignment(systemGenericAssignId.getSystemContainerId(), systemGenericAssignId.getGenericContainerId());

            return systemAssignment.map(new ConvertSystemAssignmentDataToBcb()::apply).orElse(null);
        } catch (RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override public SystemGenericContainerAssignmentReply getSystemGenericContainerAssignmentList(
            ISessionContext sessionContext, ISystemGenericContainerAssignmentId startAfter,
            ISystemGenericContainerAssignmentMarkable[] filter, int howMany) throws BcbException {
        final QContainerSystemAssignmentDb systemAssignmentDb = QContainerSystemAssignmentDb.containerSystemAssignmentDb;

        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, systemAssignmentDb)) {

            final ISystemGenericContainerAssignment[] systemAssignments = query.list(systemAssignmentDb).stream()
                    .map(containerRepository.getSystemAssignmentTransformer()::apply)
                    .filter(Optionals.isPresent()::apply)
                    .map(compose(new ConvertSystemAssignmentDataToBcb(), Optionals.dereference())::apply)
                    .toArray(ISystemGenericContainerAssignment[]::new);

            return new SystemGenericContainerAssignmentReply(systemAssignments, true, null);
        } catch (final PersistenceException | RepositoryException e) {
            throw new BcbException("Error listing System container Assignments.", e);
        }
    }

    @Override public SystemGenericContainerAssignmentIdReply getSystemGenericContainerAssignmentIdList(
            ISessionContext sessionContext, ISystemGenericContainerAssignmentId startAfter,
            ISystemGenericContainerAssignmentMarkable[] filter, int howMany) throws BcbException {
        final QContainerSystemAssignmentDb systemAssignmentDb = QContainerSystemAssignmentDb.containerSystemAssignmentDb;

        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, systemAssignmentDb)) {

            final ISystemGenericContainerAssignmentId[] systemAssignments = query.list(systemAssignmentDb).stream()
                    .map(containerRepository.getSystemAssignmentTransformer()::apply)
                    .filter(Optionals.isPresent()::apply)
                    .map(compose(new ConvertSystemAssignmentDataToBcb(), Optionals.dereference())::apply)
                    .map(ISystemGenericContainerAssignment::getSystemGenericContainerAssignmentId)
                    .toArray(ISystemGenericContainerAssignmentId[]::new);

            return new SystemGenericContainerAssignmentIdReply(systemAssignments, true, null);
        } catch (final PersistenceException | RepositoryException e) {
            throw new BcbException("Error listing System container Assignments.", e);
        }
    }

    @Override public ISystemGenericContainerAssignment createSystemGenericContainerAssignment(
            ISessionContext sessionContext, ISystemGenericContainerAssignment assignment) throws BcbException {
        try {
            final SystemInfo systemInfo = getSystemInfo(assignment.getSystemContainer());
            final ContainerInfo containerInfo = getContainerInfo(assignment.getGenericContainer());

            final SystemAssignmentData systemAssignmentData = new SystemAssignmentData(containerInfo,
                    assignment.getSystemContainerId(), AssignmentType.fromFlag(assignment.getPrimary()));

            new AddSystemAssignment<>(new BicnetCallContext(sessionContext), containerRepository, notifications, loggerManager,
                    systemInfo, systemAssignmentData).call();
        } catch (final CommandException | RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }

        return assignment;
    }

    @Override public void deleteSystemGenericContainerAssignment(ISessionContext sessionContext,
            ISystemGenericContainerAssignmentId assignment) throws BcbException {
        try {
            final SystemAssignmentData systemAssignment = getSystemAssignment(assignment);
            final SystemInfo systemInfo = getSystemInfo(assignment.getSystemContainer());

            new DeleteSystemAssignment<>(new BicnetCallContext(sessionContext), containerRepository, systemRepository, notifications,
                    loggerManager, systemInfo, systemAssignment, settingsRepository).call();
        } catch (final CommandException | RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override public ISystemGenericContainerAssignmentMarkable modifySystemGenericContainerAssignment(
            ISessionContext sessionContext, ISystemGenericContainerAssignmentMarkable assignment)
            throws BcbException {
        final ISystemGenericContainerAssignmentMarkable[] markables = modifySystemGenericContainerAssignments(
                sessionContext, new ISystemGenericContainerAssignmentMarkable[] { assignment });

        return Stream.of(markables).findFirst().orElse(null);
    }

    @Override public ISystemGenericContainerAssignmentMarkable[] modifySystemGenericContainerAssignments(
            ISessionContext sessionContext, ISystemGenericContainerAssignmentMarkable[] systemGenericAssigns)
            throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);

        return Stream.of(systemGenericAssigns)
                .map(assignment -> {
                    try {
                        final SystemInfo systemInfo = getSystemInfo(assignment.getSystemContainer());
                        final ContainerInfo containerInfo = getContainerInfo(assignment.getGenericContainer());

                        final SystemAssignmentData systemAssignmentData = new SystemAssignmentData(containerInfo,
                                assignment.getSystemContainerId(), AssignmentType.fromFlag(assignment.getPrimary()));

                        new UpdateSystemAssignment<>(context, containerRepository, notifications, loggerManager,
                                        systemInfo, systemAssignmentData).call();

                        return Optional.of(systemAssignmentData);
                    } catch (final CommandException | RepositoryException e) {
                        LOGGER.error("Error to update system assignment=" + assignment, e);
                        return Optional.<SystemAssignmentData>empty();
                    }})
                .filter(Optional::isPresent).map(Optional::get)
                .map(ConvertSystemAssignmentDataToBcb::convert)
                .map(input -> input.toMarkableSystemGenericContainerAssignment(false))
                .toArray(ISystemGenericContainerAssignmentMarkable[]::new);
    }

    /**
     * rewrites existing System assignments to Generic Containers with provided ones 
     */
    @Override public void assignSystem(ISessionContext sessionContext, ISystemContainerId system, IGenericContainerId primaryContainer, IGenericContainerId[] secondaryContainers)
            throws BcbException {
        try {
            new MoveSystemsToContainer<>(new BicnetCallContext(sessionContext), containerRepository, asList(system), primaryContainer, asList(secondaryContainers), notifications, loggerManager, systemRepository, settingsRepository).call();
        } catch (CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private JpaCloseableQuery buildQueryExpression(ISystemGenericContainerAssignmentId startAfter, ISystemGenericContainerAssignmentMarkable[] filter,
            int howMany, final QContainerSystemAssignmentDb systemAssignmentDb) throws RepositoryException {
        final JpaCloseableQuery query = containerRepository.query(systemAssignmentDb);
        final BooleanBuilder predicateBuilder = new BooleanBuilder();
        if (filter != null) {
            final BooleanBuilder filterBuilder = new BooleanBuilder();
            for (final ISystemGenericContainerAssignmentMarkable markable : filter) {
                LOGGER.debug("Filtering System Container Assignment listing with: {}", markable.toStringOnlyMarkedAttributes());
                final BooleanBuilder markablePredicateBuilder = new BooleanBuilder();

                if (markable.isMarkedGenericContainerId()) {
                    markablePredicateBuilder.and(systemAssignmentDb.containerSystemKey.containerInfo.containerId.eq(markable.getGenericContainerId()));
                    markable.markGenericContainerId(false);
                }
                if (markable.isMarkedSystemContainerId()) {
                    markablePredicateBuilder.and(systemAssignmentDb.containerSystemKey.systemContainerId.eq(markable.getSystemContainerId()));
                    markable.markSystemContainerId(false);
                }
                if (markable.isMarkedPrimary()) {
                    markablePredicateBuilder.and(systemAssignmentDb.assignmentType.eq(AssignmentType.fromFlag(markable.getPrimary())));
                    markable.markPrimary(false);
                }
                if (markable.countMarks() > 0) {
                    throw new RepositoryException("Unsupported query parameters: {}", markable.toStringOnlyMarkedAttributes());
                }
                filterBuilder.or(markablePredicateBuilder);
            }
            if (filterBuilder.hasValue()) {
                predicateBuilder.and(filterBuilder);
            }
        }
        if (startAfter != null) {
            predicateBuilder.and(systemAssignmentDb.containerSystemKey.systemContainerId.gt(startAfter.getSystemContainerId()));
            predicateBuilder.and(systemAssignmentDb.containerSystemKey.containerInfo.containerId.gt(startAfter.getGenericContainerId()));
        }
        if (predicateBuilder.hasValue()) {
            query.where(predicateBuilder);
        }
        if (howMany > -1) {
            query.limit(howMany);
        }
        query.orderBy(systemAssignmentDb.containerSystemKey.containerInfo.containerId.asc());
        return query;
    }

    private SystemInfo getSystemInfo(ISystemContainerId systemContainerId)
            throws RepositoryException {
        final Optional<SystemInfo> systemInfo = systemRepository.query(systemContainerId.getId());
        if (!systemInfo.isPresent()) {
            throw new RepositoryException("System Container not found id=" + systemContainerId);
        }
        return systemInfo.get();
    }

    private ContainerInfo getContainerInfo(IGenericContainerId containerId)
            throws RepositoryException {
        final Optional<ContainerInfo> containerInfo = containerRepository.query(containerId.getId());
        if (!containerInfo.isPresent()) {
            throw new RepositoryException("Container not found id=" + containerId);
        }
        return containerInfo.get();
    }

    private SystemAssignmentData getSystemAssignment(ISystemGenericContainerAssignmentId assignmentId)
            throws RepositoryException {
        final Optional<SystemAssignmentData> assignmentData = containerRepository
                .querySystemAssignment(assignmentId.getSystemContainerId(), assignmentId.getGenericContainerId());

        if (!assignmentData.isPresent()) {
            throw new RepositoryException("System Assignment not found id=" + assignmentId);
        }
        return assignmentData.get();
    }
}
