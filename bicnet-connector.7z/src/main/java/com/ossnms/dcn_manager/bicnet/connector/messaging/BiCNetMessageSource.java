package com.ossnms.dcn_manager.bicnet.connector.messaging;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.codahale.metrics.Timer.Context;
import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageDispatcherFactory;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageListener;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.elementMgmt.IElementManagerId;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementId;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxyId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.QChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.QNePhysicalConnectionData;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.PostConstruct;
import javax.ejb.Local;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.io.Serializable;
import java.util.Optional;
import java.util.function.Supplier;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Transforms BiCNet messages produced by Message Dispatcher BiCNet Component into
 * an {@link rx.Observable} of {@link Notification}s.</p>
 *
 * <p>Also automatically registers itself as a listener for direct message delivery from
 * Message Dispatcher using {@link BiCNetComponentType#DCN_MANAGER} as their target.</p>
 *
 * <p>Traditional message delivery is accomplished by an object instantiated by Message
 * Dispatcher. See {@link BiCNetMessageListenerImpl} for details.</p>
 */
@Singleton
@Local(BiCNetMessageSink.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
@Lock(LockType.READ)
public class BiCNetMessageSource extends MessageSourceImpl<DecoratedNotification>
        implements BiCNetMessageSink, IBiCNetDirectMessageListener {

    private static final Logger LOGGER = getLogger(BiCNetMessageSource.class);

    @Inject
    private MetricRegistry metrics;

    @Inject @DcnManager
    private IBiCNetDirectMessageDispatcherFactory bicNetDirectMessageDispatcherFactory;

    @Inject @DcnManager
    private MediatorInstanceEntityRepository mediatorInstances;
    @Inject @DcnManager
    private NePhysicalConnectionRepository neInstances;
    @Inject @DcnManager
    private ChannelPhysicalConnectionRepository channelInstances;

    private Timer notificationsTimerMetric;

    @PostConstruct
    public void initialize() {
        notificationsTimerMetric = metrics.timer(MetricRegistry.name("bicnet-messages", "notifications"));

        bicNetDirectMessageDispatcherFactory.getDispatcher(BiCNetComponentType.DCN_MANAGER.toString())
            .register(this);
    }

    /**
     * {@inheritDoc}
     *
     * (Layered delivery)
     */
    @Override
    public void pushMessage(@Nonnull IBiCNetMessage message) {

        pushMessage(true, message);

    }

    /**
     * {@inheritDoc}
     *
     * (Direct delivery)
     */
    @Override
    public void onMessage(ISessionContext sessionContext, IBiCNetMessage message)
            throws BcbException {

        pushMessage(false, message);

    }

    /*
     * FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME
     *
     * don't rely on the message delivery point to determine whether it's about the standby or active object!
     *
     * FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME FIXME
     */

    private void pushMessage(boolean active, IBiCNetMessage message) {
        final Serializable obj = message.getObject();
        if (obj instanceof Notification[]) {
            for (final Notification notification : (Notification[]) obj) {
                final Context metric = notificationsTimerMetric.time();
                try {
                    push(buildDecoratedNotification(active, notification));
                } finally {
                    metric.stop();
                }
            }
        }
    }

    private DecoratedNotification buildDecoratedNotification(boolean active, Notification notification) {
        final IManagedObjectId affectedMO = notification.affectedMO();
        try {
            if (affectedMO instanceof IMediatorId) {
                return buildDecoratedNotificationForMediator(notification);
            }
            if (affectedMO instanceof IElementManagerId) {
                return buildDecoratedNotificationForChannel(active, notification, () -> ((IElementManagerId) affectedMO).getEmId());
            }
            if (affectedMO instanceof IBiCNetComponentId) {
                return buildDecoratedNotificationForChannel(active, notification, () -> ((IBiCNetComponentId) affectedMO).getEmId());
            }
            if (affectedMO instanceof INetworkElementId || affectedMO instanceof INetworkElementProxyId) {
                return buildDecoratedNotificationForNe(active, notification);
            }
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to obtain physical object information for notification {}: {}", notification, Throwables.getStackTraceAsString(e));
        }
        return new DecoratedNotification(notification);
    }

    private DecoratedNotification buildDecoratedNotificationForNe(boolean active, Notification notification) throws RepositoryException {
        final DecoratedNotification decoratedNotification = new DecoratedNotification(notification);
        final QNePhysicalConnectionData qconn = QNePhysicalConnectionData.nePhysicalConnectionData;
        final NePhysicalConnectionData neInstance = neInstances.query(qconn)
            .where(qconn.logicalNeId.eq(decoratedNotification.getAffectedObject(IManagedObjectId.class).get().neId().getNeId())
                    .and(qconn.active.eq(active)))
            .singleResult(qconn);
        if (null != neInstance) {
            decoratedNotification.setOriginatingPhysicalNe(neInstance);
            final Optional<ChannelPhysicalConnectionData> channelInstance =
                    channelInstances.query(neInstance.getChannelInstanceId());
            if (channelInstance.isPresent()) {
                decoratedNotification.setOriginatingPhysicalChannel(channelInstance.get());
                decoratedNotification.setOriginatingPhysicalMediator(
                    mediatorInstances.getMediatorPhysicalConnectionRepository()
                        .query(channelInstance.get().getMediatorInstanceId())
                        .orElse(null));
            }
        }
        return decoratedNotification;
    }

    private DecoratedNotification buildDecoratedNotificationForChannel(
            boolean active, Notification notification, Supplier<Integer> channelIdSupplier)
            throws RepositoryException {
        final DecoratedNotification decoratedNotification = new DecoratedNotification(notification);
        final QChannelPhysicalConnectionData qconn = QChannelPhysicalConnectionData.channelPhysicalConnectionData;
        final ChannelPhysicalConnectionData channelInstance = channelInstances.query(qconn)
            .where(qconn.logicalChannelId.eq(channelIdSupplier.get())
                    .and(qconn.active.eq(active)))
            .singleResult(qconn);
        if (null != channelInstance) {
            decoratedNotification.setOriginatingPhysicalChannel(channelInstance);
            decoratedNotification.setOriginatingPhysicalMediator(
                mediatorInstances.getMediatorPhysicalConnectionRepository()
                    .query(channelInstance.getMediatorInstanceId())
                    .orElse(null));
        }
        return decoratedNotification;
    }

    private DecoratedNotification buildDecoratedNotificationForMediator(Notification notification) throws RepositoryException {
        final DecoratedNotification decoratedNotification = new DecoratedNotification(notification);
        final int mediatorInstanceId = decoratedNotification.getAffectedObject(IMediatorId.class).get().getId();
        final Optional<MediatorPhysicalConnectionData> physicalMediator = mediatorInstances.getMediatorPhysicalConnectionRepository().query(mediatorInstanceId);
        decoratedNotification.setOriginatingPhysicalMediator(physicalMediator.orElse(null));
        return decoratedNotification;
    }

}
