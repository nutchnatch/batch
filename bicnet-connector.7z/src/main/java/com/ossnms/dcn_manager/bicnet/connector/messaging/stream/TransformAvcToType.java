package com.ossnms.dcn_manager.bicnet.connector.messaging.stream;

import rx.functions.Func1;

import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;

public final class TransformAvcToType<T>
        implements Func1<AttributeValueChange, T> {

    @Override
    @SuppressWarnings("unchecked")
    public T call(AttributeValueChange avc) {
        return (T) avc.getChangedObject();
    }


}