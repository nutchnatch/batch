package com.ossnms.dcn_manager.bicnet.connector.aspects;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.MessageSource;

@Aspect("pertypewithin( com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.* )")
public class PushNotificationsToMessageSource {

    @Pointcut("execution( public * com.ossnms.dcn_manager.bicnet.connector.messaging.MessageSourceImpl+.*(com.ossnms.dcn_manager.core.events.Event+) )")
    public void eventReceivingMethod() { }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @After("eventReceivingMethod() && target(source) && args(event)")
    public void pushEvent(Event event, MessageSource source) {
        source.push(event);
    }

}
