package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.common.IconPairIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.IIconPairId;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.properties.channel.ChannelProperties;
import com.ossnms.dcn_manager.core.properties.channel.ChannelProperty;
import com.ossnms.dcn_manager.i18n.Message;
import org.apache.commons.lang3.tuple.Pair;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Handles conversion of internal domain entities representing a Channel to its
 * corresponding type in the BCB object model.
 */
public final class ConvertChannelToBcb implements Function<Pair<ChannelType, ChannelEntity>, IEM> {

    /**
     * Fills an existing {@link IEM} BCB object with information from our domain entity.
     *
     * @param type Channel type metadata.
     * @param channel Channel instance that will be the source of data.
     * @param existingObject BCB IEM instance to fill with data.
     */
    public static void fillExisting(ChannelType type, ChannelEntity channel, IEM existingObject) {
        final ChannelProperties channelProperties = new ChannelProperties();

        existingObject.setActivation(channel.getInfo().isActivationRequired() ? EnableSwitch.ENABLED : EnableSwitch.DISABLED);
        existingObject.setAdditionalInfo(channel.getConnectionState().getAdditionalInfo());
        existingObject.setCommunicationState(convertActivationState(channel.getConnectionState().getActualActivationState()));
        existingObject.setCoreId(channel.getInfo().getCoreId());
        existingObject.setDisplayAddress(channelProperties.getProperty(type, channel.getUserPreferences(), ChannelProperty.DISPLAY_ADDRESS).orElse(""));
        //        emItem.setDisplayDeviceData(em.getDisplayDeviceData()); <-- Unused ?

        existingObject.setDisplayState(getActivationStateMessage(channel.getConnectionState().getActualActivationState()));

        existingObject.setId(channel.getInfo().getId());
        existingObject.setEmType(channel.getInfo().getType());
        existingObject.setAssociatedMediatorId(channel.getInfo().getMediatorId());

        final IIconPairId defaultIconPair = new IconPairIdItem(BiCNetComponentType.DCN_MANAGER, type.getDefaultIcon());
        existingObject.setIconId(defaultIconPair);
        existingObject.setIconIdContext(defaultIconPair.getContext());
        existingObject.setIconIdId(defaultIconPair.getId());

        existingObject.setIdName(channel.getUserPreferences().getName());
        existingObject.setPropertiesValid(true);
        existingObject.setReconnectInterval(channel.getUserPreferences().getReconnectInterval());
        //        emItem.setScheduledStartup(em.getScheduledStartup());
        //        emItem.setUserLabel(em.getUserLabel()); <-- Unused ?

    }

    /**
     * <p>Given the channel Actual Activation state, find the appropriate BCB {@link CommunicationState}.</p>
     *
     * <p>We will lie about the "starting up" and "shutting down" states because there is no appropriate
     * representation in BCB. Hence we'll be optimistic and provide the most frequent conversion.
     * This will be fixed once we simplify channel states in BCB.</p>
     *
     * @param state Channel Actual Activation state.
     * @return A BCB {@link CommunicationState} instance.
     */
    public static CommunicationState convertActivationState(ActualActivationState state) {
        switch (state) {
        case ACTIVE:
            return CommunicationState.CONNECTED;
        case STARTINGUP:
        case ACTIVATING:
        case CREATING:
            return CommunicationState.CONNECTING;
        case INACTIVE:
            return CommunicationState.DISCONNECTED;
        case SHUTTINGDOWN:
        case DEACTIVATING:
            return CommunicationState.DISCONNECTING;
        case FAILED:
            return CommunicationState.FAILED;
        default:
            return null;
        }
    }

    /**
     * Given the channel Actual Activation state, find the appropriate human readable description.
     * @param state Channel Actual Activation state.
     * @return A human readable state description.
     */
    public static String getActivationStateMessage(ActualActivationState state) {
        switch (state) {
        case ACTIVE:
            return tr(Message.ACTIVE);
        case ACTIVATING:
        case CREATING:
            return tr(Message.ACTIVATING);
        case INACTIVE:
            return tr(Message.INACTIVE);
        case DEACTIVATING:
            return tr(Message.DEACTIVATING);
        case FAILED:
            return tr(Message.FAILED);
        case STARTINGUP:
            return tr(Message.ACTIVATING);
        case SHUTTINGDOWN:
            return tr(Message.DEACTIVATING);
        default:
            return "";
        }
    }

    /**
     * Converts a Channel domain entity into a new {@link IEM} BCB object.
     *
     * @param type Channel type metadata.
     * @param channel Channel instance that will be the source of data.
     * @return A new BCB IEM instance filled with data.
     */
    public static IEM convert(ChannelType type, ChannelEntity channel) {
        final IEM newEm = new EMItem();
        fillExisting(type, channel, newEm);
        return newEm;
    }

    @Override
    public IEM apply(Pair<ChannelType, ChannelEntity> channelInformation) {
        return channelInformation != null ? convert(channelInformation.getLeft(), channelInformation.getRight()) : null;
    }

}