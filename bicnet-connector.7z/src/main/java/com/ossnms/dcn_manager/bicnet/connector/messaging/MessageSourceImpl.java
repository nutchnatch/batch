package com.ossnms.dcn_manager.bicnet.connector.messaging;

import javax.annotation.Nonnull;

import org.slf4j.LoggerFactory;

import com.ossnms.dcn_manager.core.events.MessageSource;

import rx.Observable;
import rx.subjects.PublishSubject;
import rx.subjects.Subject;

/**
 * <p>Provides an infinite {@link Observable} that emits objects of type {@code T}.
 * Emission is triggered from the outside by calling {@link MessageSourceImpl#push(T)}.</p>
 */
public class MessageSourceImpl<T> implements MessageSource<T> {

    private final Subject<T, T> publisherSubject;
    private final Observable<T> outputObservable;

    protected MessageSourceImpl() {
        publisherSubject = PublishSubject.<T>create().toSerialized();
        outputObservable = publisherSubject
                .asObservable()
                .onBackpressureBuffer();
    }

    /**
     * Subscribes to an upstream observable. Items emitted upstream will be forwarded
     * through to any subscribers of this instance of {@code MessageSource}.
     * @param upstream An instance of {@link Observable}.
     */
    protected void chain(Observable<? extends T> upstream) {
        upstream.subscribe(publisherSubject);
    }

    /**
     * Provides an infinite {@link Observable} that emits objects of type {@code T}.
     * @return An instance of {@link Observable}.
     */
    public Observable<T> observe() {
        return outputObservable;
    }

    /**
     * Triggers emission of an object.
     * @param message The instance that is to be emitted to subscribers.
     */
    @Override
    public void push(@Nonnull T message) {
        LoggerFactory.getLogger(getClass()).debug("Pushing -> {}", message);
        publisherSubject.onNext(message);
    }
}
