package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentMarkable;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertContainerToBcb;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeAssignmentDataToBcb;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertSystemAssignmentDataToBcb;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.container.ContainerEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentUpdatedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentUpdatedEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

/**
 * Implements the bridge between our core and the BiCNet notifications service.
 * Handles only notifications about changes to the state of containers.
 */
@ApplicationScoped
public class ContainerNotificationsManagerImpl extends NotificationsManagerBase<ContainerEvent>
        implements ContainerNotifications {

    @Inject
    private SecurityManager securityManager;

    @Override public void notifyDelete(ContainerInfo container) {
        sendObjectDeletedNotification(new GenericContainerIdItem(container.getId()));
    }

    @Override public void notifyCreate(ContainerInfo container) {
        sendObjectCreatedNotification(ConvertContainerToBcb.convert(container));
    }

    @Override public void notifyChanges(ContainerInfoMutationDescriptor changes) {
        final IGenericContainerMarkable markable = GenericContainerItem.markableGenericContainer(null);

        markable.setId(changes.getResult().getId());
        if (changes.getName().isPresent()) {
            markable.setIdName(changes.getName().get());
        }
        if (changes.getDescription().isPresent()) {
            markable.setDescription(changes.getDescription().get());
        }
        if (changes.getParentId().isPresent()) {
            markable.setParentId(changes.getParentId().get());
        }
        if (changes.getUserText().isPresent()) {
            markable.setUserLabel(changes.getUserText().get());
        }

        sendAttributeValueChangeNotification(markable);

        securityManager.updateContainer(changes.apply());
    }

    /**
     * Notifies other components that a container has a new assignment with a NE.
     *
     * @param added The new container assignment
     */
    @Override public void notifyChanges(ContainerNeAssignmentAddedEvent added) {
        sendObjectCreatedNotification(ConvertNeAssignmentDataToBcb
                .convert(added.getNeId(), added.getContainerId(), added.getAssignmentType()));

        securityManager.updateNe(added.getNeId());
    }

    /**
     * Notifies other components that a container was removed assignment with a NE.
     *
     * @param removed The deleted assignment
     */
    @Override public void notifyChanges(ContainerNeAssignmentRemovedEvent removed) {
        INeGenericContainerAssignmentId assignment = new NeGenericContainerAssignmentIdItem();
        assignment.setGenericContainerId(removed.getContainerId());
        assignment.setNetworkElementId(removed.getNeId());

        sendObjectDeletedNotification(assignment);

        securityManager.updateNe(removed.getNeId());
    }

    /**
     * Notifies other components that a container was updated assignment with a NE.
     *
     * @param updated Changes applied to the Assignment
     */
    @Override public void notifyChanges(ContainerNeAssignmentUpdatedEvent updated) {
        INeGenericContainerAssignmentMarkable markable = NeGenericContainerAssignmentItem
                .markableNeGenericContainerAssignment(null);

        markable.setGenericContainerId(updated.getContainerId());
        markable.setNetworkElementId(updated.getNeId());
        markable.setPrimary(updated.getAssignmentType().toFlag());

        sendAttributeValueChangeNotification(markable);

        securityManager.updateNe(updated.getNeId());
    }

    /**
     * Notifies other components that a container has a new assignment with a System Container.
     *
     * @param added The new container assignment
     */
    @Override public void notifyChanges(ContainerSystemAssignmentAddedEvent added) {
        sendObjectCreatedNotification(ConvertSystemAssignmentDataToBcb
                .convert(added.getSystemId(), added.getContainerId(), added.getAssignmentType()));

        securityManager.updateSystem(added.getSystemId());
    }

    /**
     * Notifies other components that a container was removed assignment with a System Container.
     *
     * @param removed The deleted assignment
     */
    @Override public void notifyChanges(ContainerSystemAssignmentRemovedEvent removed) {
        ISystemGenericContainerAssignmentId assignment = new SystemGenericContainerAssignmentIdItem();
        assignment.setGenericContainerId(removed.getContainerId());
        assignment.setSystemContainerId(removed.getSystemID());

        sendObjectDeletedNotification(assignment);

        securityManager.updateSystem(removed.getSystemID());
    }

    /**
     * Notifies other components that a container was updated assignment with a System Container.
     *
     * @param updated Changes applied to the Assignment
     */
    @Override public void notifyChanges(ContainerSystemAssignmentUpdatedEvent updated) {
        ISystemGenericContainerAssignmentMarkable markable = SystemGenericContainerAssignmentItem
                .markableSystemGenericContainerAssignment(null);

        markable.setGenericContainerId(updated.getContainerId());
        markable.setSystemContainerId(updated.getSystemId());
        markable.setPrimary(updated.getAssignmentType().toFlag());
        
        sendAttributeValueChangeNotification(markable);

        securityManager.updateSystem(updated.getSystemId());
    }
}
