package com.ossnms.dcn_manager.bicnet.connector.factory;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;

/**
 * Factory used to supply Bicnet connectors with the system session context.
 * Most Bicnet API calls require a session context. Most of them are not
 * made as a direct result of human interaction. Hence the system session
 * context must be provided in these cases. We use a CDI factory to provide
 * it and reduce the amount of references that need to go around all the time.
 */
@ApplicationScoped
public class BicnetSessionContexts {

    @Inject
    private BicnetServiceManager serviceManager;

    public BicnetSessionContexts() {

    }

    @Produces
    @DcnManager
    @SystemContext
    public ISessionContext getSystemSessionContext() {
        return serviceManager.getSecurityManagerFacade().getSystemAccountContext();
    }

    @Produces
    @DcnManager
    @SystemContext
    public BicnetCallContext getSystemCallContext() {
        return new BicnetCallContext(getSystemSessionContext());
    }
}
