package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.base.Function;
import com.google.common.base.Throwables;
import com.google.common.collect.FluentIterable;
import com.mysema.query.BooleanBuilder;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IGenericContainerFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertContainerToBcb;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeAssignmentDataToBcb;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertSystemAssignmentDataToBcb;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.commands.container.CreateContainer;
import com.ossnms.dcn_manager.commands.container.DeleteContainer;
import com.ossnms.dcn_manager.commands.container.GetContainer;
import com.ossnms.dcn_manager.commands.container.ModifyContainers;
import com.ossnms.dcn_manager.commands.container.MoveContainersToContainer;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.container.entities.ContainerNeAssignmentDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.ContainerSystemAssignmentDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.QContainerInfoDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.QContainerNeAssignmentDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.QContainerSystemAssignmentDb;
import com.ossnms.dcn_manager.core.entities.container.RootContainerId;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.utils.Optionals;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownContainerIdException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import javax.persistence.PersistenceException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;

import static com.google.common.base.Functions.compose;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.stream.Collectors.toList;

/**
 * Delegate class for matters related to DCN Containers.
 */
public class ContainerHelper implements IGenericContainerFacade {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContainerHelper.class);

    private JpaContainerRepositoryBean containerRepository;
    private JpaSystemRepositoryBean systemRepository;
    private ContainerNotifications notifications;
    private LoggerManagerImpl loggerManager;

    /** System Repository injection point. */
    @Inject public void setSystemRepository(@DcnManager JpaSystemRepositoryBean systemRepository) {
        this.systemRepository = systemRepository;
    }

    /** Container Repository injection point. */
    @Inject public void setContainerRepository(@DcnManager JpaContainerRepositoryBean containerRepository) {
        this.containerRepository = containerRepository;
    }

    /** Container Notifications Manager injection point. */
    @Inject public void setNotifications(ContainerNotifications notifications) {
        this.notifications = notifications;
    }

    /** Logger Manager injection point. */
    @Inject public void setLoggerManager(LoggerManagerImpl loggerManager) {
        this.loggerManager = loggerManager;
    }

    @Override
    public IGenericContainer getSingleGenericContainer(ISessionContext sessionContext,
            IGenericContainerId containerContainerId) throws BcbException {
        try {
            final ContainerInfo info =
                new GetContainer<>(new BicnetCallContext(sessionContext), containerRepository, containerContainerId.getId())
                    .call();
            return ConvertContainerToBcb.convert(info);
        } catch (final RepositoryException e) {
            throw new BcbException("Error searching for DCN Container " + containerContainerId, e);
        } catch (final UnknownContainerIdException e) {
            LOGGER.info("Unknown DCN container {}", containerContainerId);
            return null;
        }
    }

    private JpaCloseableQuery buildQueryExpression(IGenericContainerId startAfter, IGenericContainerMarkable[] filter,
            int howMany, final QContainerInfoDb genericContainer) throws RepositoryException {
        final JpaCloseableQuery query = containerRepository.query(genericContainer);
        final BooleanBuilder predicateBuilder = new BooleanBuilder();
        if (filter != null) {
            final BooleanBuilder filterBuilder = new BooleanBuilder();
            for (final IGenericContainerMarkable markable : filter) {
                LOGGER.debug("Filtering DCN Container listing with: {}", markable.toStringOnlyMarkedAttributes());
                final BooleanBuilder markablePredicateBuilder = new BooleanBuilder();
                if (markable.isMarkedId()) {
                    markablePredicateBuilder.and(genericContainer.containerId.eq(markable.getId()));
                    markable.markId(false);
                }
                if (markable.isMarkedIdName()) {
                    markablePredicateBuilder.and(genericContainer.containerName.eq(markable.getIdName()));
                    markable.markIdName(false);
                }
                if (markable.isMarkedParentId()) {
                    markablePredicateBuilder.and(genericContainer.parentId.eq(Optional.ofNullable(markable.getParentId())));
                    markable.markParentId(false);
                }
                if (markable.countMarks() > 0) {
                    throw new RepositoryException("Unsupported query parameters: {}", markable.toStringOnlyMarkedAttributes());
                }
                filterBuilder.or(markablePredicateBuilder);
            }
            if (filterBuilder.hasValue()) {
                predicateBuilder.and(filterBuilder);
            }
        }
        if (startAfter != null) {
            predicateBuilder.and(genericContainer.containerId.gt(startAfter.getId()));
        }
        if (predicateBuilder.hasValue()) {
            query.where(predicateBuilder);
        }
        if (howMany > -1) {
            query.limit(howMany);
        }
        query.orderBy(genericContainer.containerId.asc());
        return query;
    }

    @Override
    public GenericContainerReply getGenericContainerList(ISessionContext sessionContext,
            IGenericContainerId startAfter, IGenericContainerMarkable[] filter, int howMany)
            throws BcbException {
        final QContainerInfoDb container = QContainerInfoDb.containerInfoDb;
        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, container)) {
            final IGenericContainer[] containers = query.list(container).stream()
                    .map(containerRepository.getEntityTransformer()::apply)
                    .filter(Optionals.isPresent()::apply)
                    .map(compose(new ConvertContainerToBcb(), Optionals.dereference())::apply)
                    .toArray(IGenericContainer[]::new);
            return new GenericContainerReply(containers, true, null);
        } catch (final PersistenceException | RepositoryException e) {
            throw new BcbException("Error listing DCN Containers.", e);
        }
    }

    @Override
    public GenericContainerIdReply getGenericContainerIdList(ISessionContext sessionContext,
            IGenericContainerId startAfter, IGenericContainerMarkable[] filter, int howMany)
            throws BcbException {
        final QContainerInfoDb container = QContainerInfoDb.containerInfoDb;
        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, container)) {
            final IGenericContainerId[] containers = query.list(container.containerId).stream()
                    .map(GenericContainerIdItem::new)
                    .toArray(IGenericContainerId[]::new);
            return new GenericContainerIdReply(containers, true, null);
        } catch (final PersistenceException | RepositoryException e) {
            throw new BcbException("Error listing DCN Container IDs.", e);
        }
    }

    @Override
    public IGenericContainer createGenericContainer(ISessionContext sessionContext,
            IGenericContainer container) throws BcbException {
        try {
            final ContainerCreationDescriptor creation = container.getParentId() >= RootContainerId.ID.get()
                    ? new ContainerCreationDescriptor(container.getParentId(), container.getIdName())
                    : new ContainerCreationDescriptor(RootContainerId.ID.get(), container.getIdName());
            creation.setDescription(Optional.ofNullable(container.getDescription()));
            creation.setUserText(Optional.ofNullable(container.getUserLabel()));

            final ContainerInfo containerInfo =
                new CreateContainer<>(new BicnetCallContext(sessionContext), containerRepository, systemRepository, notifications, loggerManager,
                    creation).call();

            return ConvertContainerToBcb.convert(containerInfo);
        } catch (final IllegalArgumentException | DuplicatedObjectNameException | RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void deleteGenericContainer(ISessionContext sessionContext,
            IGenericContainerId containercontainerId) throws BcbException {

        try {
            new DeleteContainer<>(new BicnetCallContext(sessionContext), containerRepository, notifications, loggerManager,
                    containercontainerId.getId())
                .call();
        } catch (UnknownContainerIdException | CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }

    }

    @Override
    public IGenericContainerMarkable modifyGenericContainer(ISessionContext sessionContext,
            IGenericContainerMarkable container) throws BcbException {

        return modifyGenericContainers(sessionContext, new IGenericContainerMarkable[] { container })[0];
    }

    @Override
    public IGenericContainerMarkable[] modifyGenericContainers(ISessionContext sessionContext,
            IGenericContainerMarkable[] containerMarkables) throws BcbException {

        final FluentIterable<ContainerInfoMutationDescriptor> containerMutations =
            FluentIterable.from(Arrays.asList(containerMarkables))
                .transform((Function<IGenericContainerMarkable, Optional<ContainerInfoMutationDescriptor>>) input -> {
                    try {
                        final Optional<ContainerInfo> container = containerRepository.query(input.getId());
                        if (container.isPresent()) {
                            final GenericContainerModification modification = new GenericContainerModification(container.get());
                            GenericContainerItem.update(modification, input);
                            return Optional.of(modification.toMutation());
                        } else {
                            LOGGER.warn("Could not find DCN Container for id: {}.", input.getId());
                        }
                    } catch (final RepositoryException e) {
                        LOGGER.error("Failed to obtain DCN Container for {}: {} {}", input,
                                e.getMessage(), Throwables.getStackTraceAsString(e));
                    }
                    return Optional.empty();
                })
                .filter(Optionals.isPresent())
                .transform(Optionals.dereference());

        try {
            new ModifyContainers<>(new BicnetCallContext(sessionContext), containerRepository, systemRepository, notifications, loggerManager, containerMutations)
                .call();
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }

        return containerMarkables;
    }

    public Collection<INeGenericContainerAssignment> getNeContainerAssignments(ISessionContext sessionContext) throws BcbException  {
        QContainerNeAssignmentDb assignment = QContainerNeAssignmentDb.containerNeAssignmentDb;

        try (final JpaCloseableQuery query = containerRepository.query(assignment)) {
            return query.stream(assignment)
                    .map(ContainerNeAssignmentDb.BUILDER::apply)
                    .map(ConvertNeAssignmentDataToBcb::convert)
                    .collect(toList());
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    public Collection<ISystemGenericContainerAssignment> getSystemContainerAssignments(ISessionContext sessionContext) throws BcbException {
        QContainerSystemAssignmentDb assignment = QContainerSystemAssignmentDb.containerSystemAssignmentDb;

        try (final JpaCloseableQuery query = containerRepository.query(assignment)) {
            return query.stream(assignment)
                    .map(ContainerSystemAssignmentDb.BUILDER::apply)
                    .map(ConvertSystemAssignmentDataToBcb::convert)
                    .collect(toList());
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }
    
    private static final class GenericContainerModification extends GenericContainerItem {

        private static final long serialVersionUID = 1L;

        private final transient ContainerInfoMutationDescriptor mutation;

        private GenericContainerModification(@Nonnull ContainerInfo original) {
            mutation = new ContainerInfoMutationDescriptor(original);
        }

        public ContainerInfoMutationDescriptor toMutation() {
            return mutation;
        }

        @Override
        public void setIdName(String idName) {
            mutation.setName(idName);
        }

        @Override
        public void setDescription(String description) {
            mutation.setDescription(Optional.ofNullable(description));
        }

        @Override
        public void setUserLabel(String userLabel) {
            mutation.setUserText(Optional.ofNullable(userLabel));
        }

        @Override
        public void setParentId(int parentId) {
            mutation.setParentId(parentId);
        }

    }

    public void moveToContainer(ISessionContext sessionContext, Collection<IGenericContainerId> containers, IGenericContainerId containerId) throws BcbException {
        try {
            new MoveContainersToContainer<>(new BicnetCallContext(sessionContext), containerRepository, containers, containerId, notifications, loggerManager).call();
        } catch (CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }

    }

}
