package com.ossnms.dcn_manager.bicnet.connector.facade.util;

import java.util.List;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.mysema.query.types.expr.BooleanExpression;
import com.mysema.query.types.template.BooleanTemplate;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;

/**
 * Provides utility methods for creating QueryDSL predicates from arrays of
 * {@link IManagedObjectMarkable} that represent query filters.
 *
 *
 */
public final class MarkableFilters {

    private MarkableFilters() {
        // utility class
    }

    /**
     * Builds a QueryDSL boolean expression representing the disjunction of
     * the individual filters.
     *
     * @param <Q> QueryDSL path type.
     * @param <M> Concrete markable type derived from {@link IManagedObjectMarkable}.
     * @param path Q path root.
     * @param filter Array of instances of M that represent individual filters.
     * @param predicateExpressionBuilder A function returning an instance of {@link BooleanExpression}
     *  when given a QueryDSL path root and an instance of M.
     * @return An instance of {@link BooleanExpression} or {@code null} if the filters are empty, null or
     *  do not specify any constraints.
     */
    @Nullable
    public static <Q, M extends IManagedObjectMarkable> BooleanExpression buildPredicateExpression(
            @Nonnull Q path, @Nullable M[] filter, @Nonnull BiFunction<Q, M, BooleanExpression> predicateExpressionBuilder) {
        return filter == null
            ? null
            : Stream.of(filter)
                .filter(markable -> markable != null && markable.countMarks() > 0)
                .map(markable -> predicateExpressionBuilder.apply(path, markable))
                .collect(Collectors.collectingAndThen(Collectors.toList(), MarkableFilters::joinPredicateExpressions));
    }

    /*
     * Implemented with template expressions to work around a stack overflow in QueryDSL when using
     * builders instead.
     *
     * See https://github.com/querydsl/querydsl/issues/721
     */
    private static BooleanExpression joinPredicateExpressions(List<BooleanExpression> expressions) {
        if (expressions.isEmpty()) {
            return null;
        }
        final StringBuilder template = new StringBuilder("(({0})");
        for (int t = 1; t < expressions.size(); t++) {
            template.append(" or ({").append(t).append("})");
        }
        template.append(')');
        return BooleanTemplate.create(template.toString(), expressions.toArray());
    }

}
