package com.ossnms.dcn_manager.bicnet.connector.facade;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ChannelService;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.ChannelHelper;

import javax.annotation.Nonnull;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.Collection;
import java.util.Map;

@Stateless(name = "ChannelServiceBean")
@Local(ChannelService.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ChannelServiceBean implements ChannelService {

    @Inject
    private ChannelHelper helper;

    @Override
    public Collection<FullChannelData> getFullChannelList(ISessionContext sessionContext)
            throws BcbException {
        return helper.getFullChannelList(sessionContext);
    }

    @Override public FullChannelData getFullChannel(ISessionContext sessionContext, Integer id) throws BcbException {
        return helper.getFullChannel(sessionContext, id);
    }

    @Override
    public Map<String, String> getProperties(@Nonnull final ISessionContext context, @Nonnull final IEMId channelId)
                throws BcbException {
        return helper.getProperties(context, channelId);
    }

    @Override
    public IEM createEM(@Nonnull final ISessionContext sessionContext, @Nonnull final String emType, @Nonnull final String emIdName,
            @Nonnull final IMediatorId mediatorId, @Nonnull final Property[] emProperties)
                throws BcbException {
        return helper.createEM(sessionContext, emType, emIdName, mediatorId, emProperties);
    }

    @Override
    public String[] getRegisteredEmTypes(final ISessionContext sessionContext, final String mediatorType)
                throws BcbException {
        return helper.getRegisteredEmTypes(sessionContext, mediatorType);
    }

    @Override
    public String[] getRegisteredEmTypes(final ISessionContext sessionContext)
                throws BcbException {
        return helper.getRegisteredEmTypes(sessionContext);
    }

    @Override
    public void updateProperties(final ISessionContext sessionContext, final IEMId channelId,
            final Map<String, String> properties) throws BcbException {
        helper.updateProperties(sessionContext, channelId, properties);
    }

    @Override
    public void deleteChannels(final ISessionContext sessionContext, final Collection<IEMId> channelIds) throws BcbException {
        helper.deleteChannels(sessionContext, channelIds);
    }
    
    
    @Override
    public void activateChannelsOnStandbyMediation(ISessionContext sessionContext, Collection<IEMId> channelIds) throws BcbException {
    	helper.activateChannelsOnStandbyMediation(sessionContext, channelIds);
    }

    @Override
    public void deactivateChannelsOnStandbyMediation(ISessionContext sessionContext, Collection<IEMId> channelIds) throws BcbException {
    	helper.deactivateChannelsOnStandbyMediation(sessionContext, channelIds);
    }

    @Override
    public void moveChannelsToAnotherMediators(ISessionContext sessionContext, Collection<IEMId> emIds, IMediatorId targetMediatorId) throws BcbException {
        helper.moveChannelsToAnotherMediators(sessionContext, emIds, targetMediatorId);
    }

}
