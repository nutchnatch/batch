package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.codahale.metrics.JmxReporter;
import com.ossnms.bicnet.bcb.facade.scs.BooleanSettingItem;
import com.ossnms.bicnet.bcb.facade.scs.IScsControllable;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherConfig;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherFactory;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.AdministrativeState;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.common.SyncCategory;
import com.ossnms.bicnet.bcb.model.scs.*;
import com.ossnms.bicnet.util.monitor.jmx.JmxAddressBuilder;
import com.ossnms.bicnet.util.monitor.jmx.MonitoredExecutors;
import com.ossnms.dcn_manager.bicnet.connector.configuration.ServiceConfiguration;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.factory.SystemContext;
import com.ossnms.dcn_manager.bicnet.connector.messaging.*;
import com.ossnms.dcn_manager.bicnet.connector.messaging.discovery.DiscoveryEventSource;
import com.ossnms.dcn_manager.bicnet.connector.messaging.ne.NeEventSource;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.SharedResourcesImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.connection.NeConnectionManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.NeNotificationsManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.policies.MediatorConnectionSchedulerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.ChannelInstanceConnectionRepository;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaChannelRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.bicnet.events.BiCNetIncomingEventDispatcher;
import com.ossnms.dcn_manager.bicnet.events.BiCNetOutgoingEventDispatcher;
import com.ossnms.dcn_manager.composables.mediator.MediatorPhysicalConnectionOperations;
import com.ossnms.dcn_manager.composables.metrics.NeInitializationMetrics;
import com.ossnms.dcn_manager.composables.outbound.NeInformationRetrieval;
import com.ossnms.dcn_manager.connector.storage.StartableRepository;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.outbound.*;
import com.ossnms.dcn_manager.core.policies.*;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.PeriodicEventsDispatcher;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.events.channel.ChannelDispatcher;
import com.ossnms.dcn_manager.events.discovery.DiscoveryDispatcher;
import com.ossnms.dcn_manager.events.domain.DomainDispatcher;
import com.ossnms.dcn_manager.events.mediator.MediatorDispatcher;
import com.ossnms.dcn_manager.events.ne.NeDispatcher;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;
import rx.Scheduler;
import rx.schedulers.Schedulers;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import java.util.Collections;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.stream.StreamSupport;

import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.DCN_MANAGER;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;

/**
 * Manages the component life cycle.
 */
public class ServiceControlHelper implements IScsControllable {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceControlHelper.class);

    @Inject private StaticConfigurationSingleton configuration;

    @Inject @DcnManager private SystemSchedulingConfiguration systemScheduling;

    @Inject @DcnManager private MediatorEntityRepository mediatorRepository;
    @Inject @DcnManager private MediatorInstanceEntityRepository mediatorInstanceRepository;
    @Inject @DcnManager private MediatorConnectionSchedulerImpl mediatorActivationManager;
    @Inject private MediatorConnectionManager mediatorConnectionManager;
    @Inject private MediatorNotifications mediatorNotifications;
    @Inject @DcnManager private MediatorSchedulingConfiguration mediatorScheduling;

    @Inject @DcnManager private JpaChannelRepositoryBean channelRepository;
    @Inject @DcnManager private ChannelInstanceConnectionRepository channelInstanceRepository;
    @Inject @DcnManager private ChannelInteractionManager channelActivationManager;
    @Inject private ChannelNotifications channelNotifications;
    @Inject @DcnManager private ChannelSchedulingConfiguration channelScheduling;

    @Inject @DcnManager private JpaNetworkElementRepositoryBean neRepository;
    @Inject @DcnManager private NePhysicalConnectionRepository neInstanceRepository;
    @Inject @DcnManager private NetworkElementInteractionManager neActivationManager;
    @Inject private NeNotificationsManagerImpl neNotifications;
    @Inject private NeInformationRetrieval neInformationRetrieval;

    @Inject @DcnManager private DomainRepository domainRepository;
    @Inject private DomainNotifications domainNotifications;

    @Inject @DcnManager private Instance<StartableRepository> startableRepositories;

    @Inject @DcnManager private JpaSettingsRepositoryBean settingsRepository;

    @Inject @DcnManager private ISystemControlEjbFacade scs;
    @Inject @DcnManager private IBiCNetMessageDispatcher messageDispatcher;

    @Inject private LoggerManagerImpl loggerManager;
    @Inject private SharedResourcesImpl sharedResources;
    @Inject private NeConnectionManagerImpl connectionManager;

    @Inject private MediatorEventSource mediatorEventSource;
    @Inject private DiscoveryEventSource discoveryEventSource;
    @Inject private ChannelEventSource channelEventSource;
    @Inject private NeEventSource neEventSource;
    @Inject private DomainEventSource domainEventSource;
    @Inject private PeriodicEventsSource periodicEventsSource;

    @Inject @DcnManager private ContainerRepository containerRepository;
    @Inject @DcnManager private SystemRepository systemRepository;
    @Inject private ContainerNotifications containerNotifications;

    @Inject @SystemContext private ISessionContext systemContext;

    @Inject private BiCNetMessageSink bicnetSource;

    @Inject private BiCNetMessageListener biCNetMessageListener;

    @Inject @DcnManager private IBiCNetMessageDispatcherFactory bicNetMessageDispatcherFactory;

    @Inject private Alarms alarms;

    @Inject private ServiceControlHelperData lifeCycle;

    @Inject private JmxReporter jmxReporter;

    @Inject private ServiceConfiguration serviceConfiguration;

    @Inject private NeInitializationMetrics initializationMetrics;

    /** @return Whether start() has been called already. */
    public boolean isComponentStarted() {
        return lifeCycle.isComponentStarted();
    }

    /**
     * <p>{@inheritDoc}</p>
     *
     * <p>DCN Manager performs the following actions when started:</p><ul>
     * <li>Starts repositories, allowing them to finish setting up and connecting resources.</li>
     * <li>Establishes the event processing chain.</li>
     * <li>Automatically activates Mediators that are marked as "activation required".</li>
     * </ul>
     */
    @Override
    public void start(@Nonnull final ISessionContext sessionContext) throws BcbException {

        //allow connection manager to start mediation schedule using DCN manager global properties
        connectionManager.setGlobalProperties(sessionContext, serviceConfiguration.getGlobalSettings());

        LOGGER.info("Connecting event sources.");
        lifeCycle.subscribeToEvents();

        activateMediators();

        LOGGER.info("DCN Manager Started.");

        jmxReporter.start();
    }

    private void activateMediators() throws BcbException {
        try {
            LOGGER.info("Activating 'required' mediators...");
            final MediatorPhysicalConnectionOperations operations =
                new MediatorPhysicalConnectionOperations(mediatorRepository, mediatorActivationManager,
                        mediatorNotifications, mediatorInstanceRepository);

            for (final MediatorInfoData mediatorInfoData : mediatorRepository.getMediatorInfoRepository().queryAll()) {
                if (mediatorInfoData.isActivationRequired()) {
                    LOGGER.info("Scheduling automatic activation of Mediator {}: '{}'",
                            mediatorInfoData.getId(), mediatorInfoData.getName());
                    final Optional<MediatorPhysicalConnectionData> activeMediatorConnection =
                            StreamSupport.stream(mediatorInstanceRepository.getMediatorPhysicalConnectionRepository().queryAll(mediatorInfoData.getId()).spliterator(), false)
                                    .filter(MediatorPhysicalConnectionData::isActive).findFirst();
                    if (activeMediatorConnection.isPresent()) {
                        operations.triggerMediatorPhysicalConnectionStartingUp(activeMediatorConnection.get());
                    } else {
                        LOGGER.warn("Mediator id {} has no active physical connection.", mediatorInfoData.getId());
                    }
                }
            }
            LOGGER.info("'Required' mediators activated.");
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to schedule all automatic mediator activations!", e);
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private void startRepositories(boolean clearData) throws BcbException {
        try {
            LOGGER.info("Starting data repositories.");
            for (final StartableRepository repository : startableRepositories) {
                repository.start();
            }
            LOGGER.info("Data repositories started.");
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to start all data repositories!", e);
            throw logAndRethrowAsBcb(e, LOGGER);
        }
        if (clearData) {
            try {
                LOGGER.info("Clearing synchronization data.");
                neRepository.getNeSynchronizationRepository().clearAllSynchronizationData();
            } catch (RepositoryException e) {
                LOGGER.warn("Could not clear data upon startup.", e.getMessage());
            }
        }
    }

    private void configureChannelSchedulers() {
        try {
            LOGGER.info("Configuring Channel schedulers.");
            final Iterable<ChannelUserPreferencesData> channelPreferences =
                    channelRepository.getChannelUserPreferencesRepository().queryAll();
            StreamSupport.stream(channelPreferences.spliterator(), false)
                .flatMap(preferences ->
                    StreamSupport.stream(channelInstanceRepository.queryAll(preferences.getId()).spliterator(), false)
                        .map(instance -> ImmutablePair.of(instance, preferences)))
                .forEach(pair ->
                    channelScheduling.setMaxOngoingChannelJobCount(pair.getLeft().getId(),
                        pair.getRight().isConcurrentActivationsLimited() ? pair.getRight().getConcurrentActivationsLimit() : Integer.MAX_VALUE));
            LOGGER.info("Channel schedulers configured.");
        } catch (final RepositoryException e) {
            LOGGER.warn("Failed to configure all channel schedulers!", e.getMessage());
        }
    }

    private void configureMediatorSchedulers() {
        try {
            LOGGER.info("Configuring Mediator schedulers.");
            final Iterable<MediatorInfoData> mediatorInfos = mediatorRepository.getMediatorInfoRepository().queryAll();
            StreamSupport.stream(mediatorInfos.spliterator(), false)
                .flatMap(info ->
                    StreamSupport.stream(mediatorInstanceRepository.getMediatorPhysicalConnectionRepository().queryAll(info.getId()).spliterator(), false)
                        .map(instance -> ImmutablePair.of(instance, info)))
                .forEach(pair ->
                    mediatorScheduling.setMaxOngoingMediatorJobCount(pair.getLeft().getId(),
                        pair.getRight().isConcurrentActivationsLimited() ? pair.getRight().getConcurrentActivationsLimit() : Integer.MAX_VALUE));
            LOGGER.info("Mediator schedulers configured.");
        } catch (final RepositoryException e) {
            LOGGER.warn("Failed to configure all mediator schedulers!", e.getMessage());
        }
    }

    /** The executor instance to be used to schedule event servicing execution. */
    @Resource(lookup = "java:jboss/ee/concurrency/executor/dcnManager/events")
    private ManagedExecutorService managedEventsExecutorService;

    /**
     * <p>{@inheritDoc}</p>
     *
     * <p>In DCN Manager all event sources are connected at initialization time.</p>
     */
    @Override
    public void init(@Nonnull final ISessionContext sessionContext) throws BcbException {

        final JmxAddressBuilder addressBuilder = new JmxAddressBuilder().onPool().withName("dcnManager-events");
        final ExecutorService monitoredExecutor = MonitoredExecutors.monitored(managedEventsExecutorService, addressBuilder.build());

        IBiCNetMessageDispatcherConfig dispatcherConfig = bicNetMessageDispatcherFactory.getDispatcherConfig(DCN_MANAGER);
        BiCNetMessageListenerConfiguration.build().forEach((layer, notifications) ->
                dispatcherConfig.addListener(layer, biCNetMessageListener, notifications)
        );

        final Observable<DecoratedNotification> notificationSource = bicnetSource.observe();
        final Scheduler dispatcherScheduler = Schedulers.from(monitoredExecutor);

        initCoreEventSources(notificationSource);

        /* Initialize Core event dispatcher chains against inbound events.
         */
        initCoreEventDispatchers(sessionContext, dispatcherScheduler);

        /* Initialize BiCNet incoming event dispatcher chain.
         */
        new BiCNetIncomingEventDispatcher(neRepository.getNeSyncStateRepository(), messageDispatcher, scs, systemContext)
            .initialize(notificationSource.observeOn(dispatcherScheduler));

        /* Initialize BiCNet outgoing event dispatcher chain.
         * Note that it must be initialized against outbound events so domain object states are coherent.
         * Otherwise the BiCNet chain will make decisions based on unprocessed events.
         */
        new BiCNetOutgoingEventDispatcher(neRepository, scs, sharedResources, systemContext)
            .initialize(Collections.<Observable<? extends Event>>singleton(neNotifications.observe().observeOn(dispatcherScheduler)));

        startRepositories(!scs.isStandbyActivated(systemContext));

        new StandbyHelper(mediatorRepository, mediatorInstanceRepository, channelRepository, channelInstanceRepository,
                neRepository, neInstanceRepository)
            .configureStandbyMediatorInstances(
                scs.getSiteConfiguration(systemContext) == ScsSiteConfiguration.SECONDARY
                        ? MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1
                        : MediatorInstance.PRIMARY_PRIORITY_LEVEL);

        configureChannelSchedulers();
        configureMediatorSchedulers();
        systemScheduling.setMaxOngoingSystemJobCount(settingsRepository.getSettings().getScaledStartupLimit());

        lifeCycle.setComponentStarted(true);

        final BooleanSettingItem setting = new BooleanSettingItem();
        setting.setValue(false);
        setting.setCategory(SettingCategory.FAULT);
        setting.setName("nativeLocation");
        scs.setDefaults(sessionContext, new ISetting[]{setting});

        LOGGER.info("DCN Manager Initialized.");
    }

    private static final int NE_ID_GROUPING_FACTOR = 10;

    private void initCoreEventDispatchers(final ISessionContext sessionContext, Scheduler dispatcherScheduler) {

        // Parameter objects.
        final ChannelManagers channelManagers =
                new ChannelManagers(channelRepository, channelInstanceRepository, channelNotifications, channelActivationManager, channelEventSource);
        final MediatorManagers mediatorManagers =
                new MediatorManagers(mediatorRepository, mediatorInstanceRepository, mediatorNotifications, mediatorActivationManager, mediatorEventSource);
        final NetworkElementManagers networkElementManagers =
                new NetworkElementManagers(neRepository, neInstanceRepository, neActivationManager, neNotifications, neEventSource);
        final DomainManagers domainManagers =
                new DomainManagers(domainRepository, domainNotifications);
        final BicnetCallContext context =
                new BicnetCallContext(sessionContext);

        // Dispatchers.
        new MediatorDispatcher<>(context, configuration, loggerManager, mediatorManagers, channelManagers, settingsRepository)
            .initialize(lifeCycle.getMediatorEventSource());
        new ChannelDispatcher<>(context, configuration, loggerManager, settingsRepository, channelManagers,
                networkElementManagers, mediatorManagers)
            .initialize(lifeCycle.getChannelEventSource());
        new DiscoveryDispatcher<>(context, configuration, configuration, loggerManager, settingsRepository,
                channelManagers, networkElementManagers, domainManagers, containerRepository, systemRepository, containerNotifications)
            .initialize(lifeCycle.getDiscoveryEventSource().observeOn(dispatcherScheduler));

        final NeDispatcher<BicnetCallContext> dispatcher =
            new NeDispatcher<>(context, configuration, loggerManager, networkElementManagers, channelManagers, neInformationRetrieval,
                domainManagers, settingsRepository, systemRepository, alarms, configuration, connectionManager,
                initializationMetrics);
        lifeCycle.getNeEventSource()
            .ofType(NeEvent.class)
            .groupBy(event -> event.getNeId() % NE_ID_GROUPING_FACTOR)
            .subscribe(groupedObservable -> dispatcher.initialize(groupedObservable.observeOn(dispatcherScheduler)));

        new DomainDispatcher<>(context, domainManagers, networkElementManagers, configuration, settingsRepository, loggerManager)
            .initialize(lifeCycle.getDomainEventsSource().observeOn(dispatcherScheduler));

        new PeriodicEventsDispatcher<>(context, mediatorManagers, networkElementManagers, channelManagers, settingsRepository, configuration, loggerManager)
            .initialize(lifeCycle.getPeriodicEventsSource());
    }

    private void initCoreEventSources(final Observable<DecoratedNotification> notificationSource) {

        mediatorEventSource.subscribe(notificationSource);
        channelEventSource.subscribe(notificationSource);
        neEventSource.subscribe(notificationSource);
        discoveryEventSource.subscribe(notificationSource);
        periodicEventsSource.subscribe(notificationSource);
        domainEventSource.subscribe(notificationSource);

        lifeCycle.setCoreEventSources(
                discoveryEventSource.observe().publish(),
                mediatorEventSource.observe().publish(),
                channelEventSource.observe().publish(),
                neEventSource.observe().publish(),
                periodicEventsSource.observe().publish(),
                domainEventSource.observe().publish());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void doSync(@Nonnull final ISessionContext sessionContext, @Nonnull final IBiCNetComponentId[] bicnetComponentIds,
            @Nonnull final ScsSyncMode syncMode, @Nonnull final SyncCategory syncCategory) throws BcbException {

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void doForcedSync(@Nonnull final ISessionContext sessionContext, @Nonnull final IBiCNetComponentId[] bicnetComponentIds,
            @Nonnull final ScsSyncMode syncMode, @Nonnull final SyncCategory syncCategory) throws BcbException {

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void doFullSync(@Nonnull final ISessionContext sessionContext) throws BcbException {

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void shutDown(@Nonnull final ISessionContext sessionContext) throws BcbException {

        if (lifeCycle.isComponentStarted()) {
            stop(sessionContext);
        }

        try {
            LOGGER.info("Disconnecting active mediator sessions.");
            StreamSupport.stream(mediatorInstanceRepository.getMediatorPhysicalConnectionRepository().queryAll().spliterator(), false)
                    .filter(data -> data.getActualActivationState() == ActualActivationState.ACTIVE)
                    .forEach(data -> mediatorConnectionManager.disconnect(data.getId()));
        } catch (RepositoryException e) {
            LOGGER.warn("Failed to query active mediators, connections will not be shut down.", e.getMessage());
        }

        IBiCNetMessageDispatcherConfig dispatcherConfig = bicNetMessageDispatcherFactory.getDispatcherConfig(DCN_MANAGER);
        BiCNetMessageListenerConfiguration.build().forEach(dispatcherConfig::removeListener);

        LOGGER.info("DCN Manager Shut Down.");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stop(@Nonnull final ISessionContext sessionContext) throws BcbException {

        lifeCycle.unsubscribeFromEvents();

        jmxReporter.stop();

        lifeCycle.setComponentStarted(false);

        LOGGER.info("DCN Manager Stopped.");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Nullable
    public ScsComponentState getState(@Nonnull final ISessionContext sessionContext) throws BcbException {
        return new ScsComponentState(AdministrativeState.UNLOCKED, new ScsCategorySyncState[0],
                OperationalState.ENABLED, ScsSyncState.SYNCHRONIZED);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isStartSupported(@Nullable final ISessionContext sessionContext) throws BcbException {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isStopSupported(@Nullable final ISessionContext sessionContext) throws BcbException {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isSyncSupported(@Nullable final ISessionContext sessionContext) throws BcbException {
        return false;
    }

}
