package com.ossnms.dcn_manager.bicnet.connector.outbound;

import static com.google.common.base.Strings.isNullOrEmpty;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import com.ossnms.bicnet.bcb.facade.licensing.ILicenseMgrFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.composables.outbound.LicensingManager;
import com.ossnms.dcn_manager.composables.outbound.exception.LicenseException;

/**
 * @see LicensingManager
 */
public class LicensingManagerImpl implements LicensingManager<BicnetCallContext> {
    
    private final ILicenseMgrFacade licenseFacade;
   
    @Inject
    public LicensingManagerImpl(@DcnManager ILicenseMgrFacade licenseFacade) {
        super();
        this.licenseFacade = licenseFacade;
    }

    /**
     * @see LicensingManager#releaseLicense(com.ossnms.dcn_manager.composables.context.CallContext, String)
     */
    @Override
    public void releaseLicense(@Nonnull final BicnetCallContext context, @Nonnull final String moKey) throws LicenseException {
        
        if (isNullOrEmpty(moKey)) {
            throw new LicenseException("The MO object key cannot be null");
        }
        
        try {
            licenseFacade.releaseLicense(context.getSessionContext(), moKey);
        } catch(final BcbException e) {
            throw new LicenseException(e);
        }
    }
}
