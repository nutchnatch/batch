package com.ossnms.dcn_manager.bicnet.connector.facade.util;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.scs.IScsFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;

import javax.annotation.Nonnull;
import java.util.Map;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * Contains definitions and methods for producing sets of properties
 * describing the current "standby" configuration in SCS.
 */
public final class BicnetStandbyProperties {

    public static final String SITE_ROLE = "SITE_ROLE";
    public static final String STANDBY_CONFIGURED = "STANDBY_CONFIGURED";

    private BicnetStandbyProperties() {

    }

    /**
     * Produces properties about "standby" for usage in the DCN Manager GUI.
     * @param context BiCNet context, for cross-component calls.
     * @param scs SCS API.
     * @return Properties describing the current "standby" configuration in SCS.
     */
    public static Map<String, String> getProperties(@Nonnull ISessionContext context, @Nonnull IScsFacade scs) {
        try {
            return ImmutableMap.of(
                    SITE_ROLE, scs.getSiteConfiguration(context).name(),
                    STANDBY_CONFIGURED, String.valueOf(scs.isStandbyConfigured(context))
            );
        } catch (BcbException e) {
            getLogger(BicnetStandbyProperties.class)
                    .warn("Could not determine SCS standby configuration.", e);
            return ImmutableMap.of();
        }
    }
}
