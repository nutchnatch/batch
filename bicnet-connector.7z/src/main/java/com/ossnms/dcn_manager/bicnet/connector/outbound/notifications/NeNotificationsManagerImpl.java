package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfoNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeRouteInfo;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToFullNe;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToNeGuiInfo;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.factory.SystemContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeStartingUpEvent;
import com.ossnms.dcn_manager.core.events.ne.NeConnectionDescriptionChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.NeGatewayRoutesChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.convertToCommunicationState;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.convertToInitState;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.convertToNeActivationState;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.describe;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.describeEachStates;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.updateMarkable;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Implements the bridge between our core and the BiCNet notifications service.
 * Handles only notifications about changes to the state of NEs.
 */
@ApplicationScoped
public class NeNotificationsManagerImpl
        extends NotificationsManagerBase<NeEvent>
        implements NetworkElementNotifications {

    private static final Logger LOGGER = getLogger(NeNotificationsManagerImpl.class);

    @Inject
    private StaticConfiguration configuration;

    @Inject
    private SecurityManager securityManager;

    @Inject @DcnManager
    private NeEntityRepository neRepository;

    @Inject @DcnManager
    private NePhysicalConnectionRepository nePhysicalConnectionRepository;

    @Inject
    private LoggerManagerImpl loggerManager;

    @Inject @DcnManager @SystemContext
    private BicnetCallContext systemContext;

    /**
     * {@inheritDoc}
     *
     * <p>Also sends a notification to User Security Manager.</p>
     */
    @Override
    public void notifyDelete(NeEntity ne) {

        sendObjectDeletedNotification(new NEIdItem(ne.getInfo().getNeId()));

        securityManager.deleteNe(ne);

    }

    /**
     * {@inheritDoc}
     *
     * <p>Also sends a notification to User Security Manager.</p>
     */
    @Override
    public void notifyCreate(NeEntity ne) {
        final NeType neType = configuration.getNeTypes().get(ne.getInfo().getProxyType());

        final FullNeData fullNeData = ConvertNeToFullNe.convert(
                neType, Optional.empty(), ne,
                loadNeGatewayRouteData(ne),
                nePhysicalConnectionRepository.queryAll(ne.getInfo().getId()));

        sendObjectCreatedNotification(fullNeData.getNe());

        sendCustomNotificationToClient(new FullNeDataCreateNotification(fullNeData));
        
        securityManager.createNe(ne);
    }

    /*
     * we must search for routes because the "sort by connectivity" sorter
     */
    private Iterable<NeGatewayRouteData> loadNeGatewayRouteData(NeEntity ne) {
        try {
            return neRepository.getNeGatewayRoutesRepository().queryRoutes(ne.getInfo().getId());
        } catch (RepositoryException e) {
            LOGGER.error("Error to load NeGatewayRouteData.", e);
        }
        return Collections.emptyList();
    }

    @Override
    public void notifyChanges(NeConnectionDescriptionChangedEvent event) {
        final INEMarkable markable = createNeMarkable(event.getNeId());
        if (event.getRouteDescription().isPresent()) {
            markable.setConnectedVia(event.getRouteDescription().get());
        }
        if (event.getTargetDescription().isPresent()) {
            markable.setDisplayAddress(event.getTargetDescription().get());
        }
        sendAttributeValueChangeNotification(markable);
    }

    @Override
    public void notifyChanges(NeConnectionMutationDescriptor connection) {
        final INEMarkable markable = createNeMarkable(connection.getTarget().getId());
        updateMarkable(markable, connection);
        sendAttributeValueChangeNotification(markable);
    }

    @Override public void notifyChanges(NeGatewayRoutesChangedEvent routes) {
        sendNeGuiInfoChanges(routes);
    }

    @Override
    public void notifyChanges(NeOperationMutationDescriptor operation) {
        final INEMarkable markable = createNeMarkable(operation.getTarget().getId());
        updateMarkable(markable, operation);
        sendAttributeValueChangeNotification(markable);
    }

    @Override
    public void notifyChanges(NeInfoMutationDescriptor info) {
        final INEMarkable markable = createNeMarkable(info.getTarget().getId());
        updateMarkable(markable, info);
        sendAttributeValueChangeNotification(markable);
    }

    /**
     * {@inheritDoc}
     *
     * @throws IllegalStateException If the mutation has not been applied yet.
     *  This is a consequence of having to send an update notification to User
     *  Security Manager with the mutation result.
     */
    @Override
    public void notifyChanges(NeUserPreferencesMutationDescriptor preferences) {
        final INEMarkable markable = createNeMarkable(preferences.getTarget().getId());
        updateMarkable(markable, preferences);

        sendAttributeValueChangeNotification(markable);
        sendNeGuiInfoChanges(preferences);

        securityManager.updateNe(preferences.getResult());
    }

    @Override
    public void notifyChanges(Deactivate event) {
        final INEMarkable markable = createNeMarkable(event.getNeId());
        markable.setActivation(EnableSwitch.DISABLED);
        final String info = event.getDetailedDescription();
        if(null != info && ! info.isEmpty()) {
            markable.setAdditionalInfo(info);
        }
        sendAttributeValueChangeNotification(markable);
    }

    @Override
    public void notifyChanges(Activate event) {
        final INEMarkable markable = createNeMarkable(event.getNeId());
        markable.setActivation(EnableSwitch.ENABLED);
        final String info = event.getDetailedDescription();
        if(null != info && ! info.isEmpty()) {
            markable.setAdditionalInfo(info);
        }
        sendAttributeValueChangeNotification(markable);
    }

    @Override
    public void notifyChanges(NeActivationFailedEvent event) {
        checkRequiredStateIsActive(event);
        notifyStateChange(event, ActualActivationState.FAILED, GuiActualActivationState.FAILED);
    }

    @Override
    public void notifyChanges(NeDisconnectedEvent event) {
        notifyStateChange(event, ActualActivationState.DISCONNECTED, GuiActualActivationState.INACTIVE);
    }

    @Override
    public void notifyChanges(NeDisconnectingEvent event) {
        notifyStateChange(event, ActualActivationState.DISCONNECTING, GuiActualActivationState.DEACTIVATING);
    }

    @Override
    public void notifyChanges(NeInitializedEvent event) {
        checkRequiredStateIsActive(event);
        notifyStateChange(event, ActualActivationState.INITIALIZED, GuiActualActivationState.ACTIVE);
    }

    @Override
    public void notifyChanges(NeInitializingEvent event) {
        checkRequiredStateIsActive(event);
        notifyStateChange(event, ActualActivationState.INITIALIZING, GuiActualActivationState.ACTIVATING);
    }

    @Override
    public void notifyChanges(NeConnectedEvent event) {
        checkRequiredStateIsActive(event);
        notifyStateChange(event, ActualActivationState.CONNECTED, GuiActualActivationState.ACTIVATING);
    }

    @Override
    public void notifyChanges(NeConnectingEvent event) {
        checkRequiredStateIsActive(event);
        notifyStateChange(event, ActualActivationState.CONNECTING, GuiActualActivationState.ACTIVATING);
    }


    @Override
    public void notifyChanges(NeStartingUpEvent event) {
        final GuiActualActivationState guiState = GuiActualActivationState.STARTINGUP;
        notifyPhysicalEvent(event,
                e -> notifySystemStateChange(event, ActualActivationState.STARTUP, guiState),
                e -> notifyClientDisplayStateChange(event, ActualActivationState.STARTUP, guiState));
    }

    @Override
    public void notifyChanges(NeShuttingDownEvent event) {
        final GuiActualActivationState guiState = GuiActualActivationState.SHUTTINGDOWN;
        notifyPhysicalEvent(event,
                e -> notifySystemStateChange(event, ActualActivationState.SHUTDOWN, guiState),
                e -> notifyClientDisplayStateChange(event, ActualActivationState.SHUTDOWN, guiState));
    }

    @Override
    public void notifyCreateInstance(NePhysicalConnectionData physicalConnectionData) {

        sendCustomNotificationToClient(new NeInfoNotification(
                new NeInfo(physicalConnectionData.getLogicalNeId())
                        .setGuiStandbyActualActivationState(GuiActualActivationState.INACTIVE)
                        .setStandbyDisplayState(describe(ActualActivationState.DISCONNECTED))
        ));

    }

    @Override
    public void notifyDeleteInstance(int logicalNeId, int physicalNeId) {

        sendCustomNotificationToClient(new NeInfoNotification(
                new NeInfo(logicalNeId)
                        .setGuiStandbyActualActivationState(null)
                        .setStandbyDisplayState("")
        ));

    }

    private INEMarkable createNeMarkable(int neId) {
        final INEMarkable ne = NEItem.markableNE(null);
        ne.setId(neId);
        ne.setPropertiesValid(true);
        return ne;
    }

    private void notifyStateChange(ActualNeStateEvent event, ActualActivationState state, GuiActualActivationState guiActualActivationState) {
        notify(event, e -> notifySystemStateChange(e, state, guiActualActivationState), e -> notifyClientStateChange(e, state, guiActualActivationState));
    }

    @FunctionalInterface
    private interface NotifyChange {
        void notify(ActualNeStateEvent event);
    }

    private void notify(ActualNeStateEvent event, NotifyChange notifySystem, NotifyChange notifyClient) {
        if (event.getOriginatingPhysicalEvent().isPresent()) {
            final PhysicalNeStateEvent physicalEvent = event.getOriginatingPhysicalEvent().get();
            if (!physicalEvent.isInstanceActive()) {
                notifyClient.notify(event);
            }
        } else {
            notifySystem.notify(event);
        }
    }

    private void notifyPhysicalEvent(ActualNeStateEvent neEvent, NotifyChange notifySystem, NotifyChange notifyClient) {
        neEvent.getOriginatingPhysicalEvent()
                .map(event -> event.isInstanceActive() ? notifySystem : notifyClient)
                .ifPresent(f -> f.notify(neEvent));
    }

    private void notifySystemStateChange(ActualNeStateEvent event, ActualActivationState state, GuiActualActivationState guiActualActivationState) {

        final INEMarkable markable = createNeMarkable(event.getNeId());
        markable.setActualActivationState(convertToNeActivationState(state));
        markable.setInitState(convertToInitState(state));
        markable.setCommunicationState(convertToCommunicationState(state));
        markable.setAdditionalInfo(event.getDetailedDescription());
        markable.setDisplayState(describe(state));
        if (guiActualActivationState == GuiActualActivationState.FAILED ||
            guiActualActivationState == GuiActualActivationState.INACTIVE) {
            // ensure that the "connected via" column is cleared on clients: this information is provided only for active/activatings NEs.
            markable.setConnectedVia("");
        }
        
        sendAttributeValueChangeNotification(markable);

        sendCustomNotificationToClient(new NeInfoNotification(
                new NeInfo(event.getNeId())
                        .setGuiActualActivationState(guiActualActivationState)
        ));

        logStateChange(event, state);
    }

    private void notifyClientStateChange(ActualNeStateEvent event, ActualActivationState state, GuiActualActivationState guiActualActivationState) {

        sendCustomNotificationToClient(new NeInfoNotification(
                new NeInfo(event.getNeId())
                        .setGuiStandbyActualActivationState(guiActualActivationState)
                        .setStandbyDisplayState(describe(state))
        ));

        logStateChange(event, state);
    }

    private void notifyClientDisplayStateChange(ActualNeStateEvent event, ActualActivationState state, GuiActualActivationState guiActualActivationState) {

        sendCustomNotificationToClient(new NeInfoNotification(
                new NeInfo(event.getNeId())
                    .setStandbyDisplayState(describe(state))
                    .setGuiStandbyActualActivationState(guiActualActivationState)
        ));

    }

    private void logStateChange(ActualNeStateEvent event, ActualActivationState state) {
        final int neId = event.getNeId();
        try {
            final Optional<String> neName = neRepository.queryNeName(neId);
            LOGGER.debug("NE {} '{}' state changed to {} on {} connection.",
                    event.getNeId(), neName.orElse(null), state,
                    event.getOriginatingPhysicalEvent()
                            .filter(physical -> !physical.isInstanceActive())
                            .map(physical -> "standby")
                            .orElse("active"));
            if (neName.isPresent()) {
                loggerManager.createSystemEventLog(systemContext,
                    new LoggerItemNe(
                        neName.get(),
                        StringUtils.join(new String[] {
                            tr(Message.NE_STATE_CHANGED, describeEachStates(state)),
                            Optional.ofNullable(event.getDetailedDescription())
                            .filter(description -> ! description.equals(describeEachStates(state)) )
                            .orElse(null),
                            event.getOriginatingPhysicalEvent()
                                .filter(physical -> !physical.isInstanceActive())
                                .map(physical -> "(standby)")
                                .orElse(null)
                        }, ' '),
                        neId,
                        MessageSeverity.INFO));
            } else {
                LOGGER.warn("Failed to obtain NE {} name, no log entry will be emitted.", neId);
            }
        } catch (final RepositoryException e) {
            LOGGER.warn("Failed to obtain NE {} name, no log entry will be emitted. {}", neId,
                    getStackTraceAsString(e));
        }
    }

    private void sendNeGuiInfoChanges(NeUserPreferencesMutationDescriptor preferences) {
        if (preferences.getUserText().isPresent()) {
            sendCustomNotificationToClient(new NeInfoNotification(
                    new NeInfo(preferences.getTarget().getId())
                        .setUserText(preferences.getUserText().get())));
        }
    }

    private void sendNeGuiInfoChanges(NeGatewayRoutesChangedEvent routesChangedEvent) {
        if (routesChangedEvent.getGatewayRoutes().isPresent()) {
            final Set<NeRouteInfo> neRoutes = ConvertNeToNeGuiInfo
                    .convertRoutes(routesChangedEvent.getGatewayRoutes().get());

            sendCustomNotificationToClient(new NeInfoNotification(
                    new NeInfo(routesChangedEvent.getNeId()).setNeRouteInfo(neRoutes)));
        }
    }

    private boolean checkRequiredStateIsActive(NeEvent event) {

        boolean activationRequired = false;
        try {
            final Optional<NeInfoData> neInfo = neRepository.getNeInfoRepository().query(event.getNeId());

            if (neInfo.isPresent()) { 
                activationRequired = neInfo.get().isActive();
                if(! activationRequired) {
                    LOGGER.warn("checkRequiredStateIsActive for neId: {}, required activation state is {}, before producing notification from event {}.",
                            neInfo.get().getId(), activationRequired ? "ENABLED": "DISABLED", event.getClass());
                }
                else {
                    LOGGER.debug("checkRequiredStateIsActive for neId: {}, required activation state is {}, before producing notification from event {}.",
                            neInfo.get().getId(), activationRequired ? "ENABLED": "DISABLED", event.getClass());
                }
            }
            else {
                LOGGER.warn("checkRequiredStateIsActive: Failed to obtain ne info for neid: {}  while producing notification from event {}, returning {}",
                        event.getNeId(), event.getClass(), activationRequired);
            }
            
        } catch (RepositoryException e) {
            LOGGER.warn("Failed to obtain NE {} name, no log entry will be emitted. {}",
                    event.getNeId(), getStackTraceAsString(e));
        }
        
        return activationRequired;

    }
    
    /*
    private void checkRequiredStateIsActive(NeEvent event) {
        try {
            final Optional<NeInfoData> neInfo = neRepository.getNeInfoRepository().query(event.getNeId());

            if (neInfo.isPresent() && !neInfo.get().isActive()) {
                LOGGER.debug("Force set require state to active for neId:{}", neInfo.get().getId());

                final Optional<NeInfoMutationDescriptor> mutation = new NeInfoBehavior(neInfo.get(), this)
                        .activationRequired();
                if (mutation.isPresent()) {
                    neRepository.getNeInfoRepository().tryUpdate(mutation.get());
                }
            }
        } catch (RepositoryException e) {
            LOGGER.warn("Failed to obtain NE {} name, no log entry will be emitted. {}", event.getNeId(),
                    getStackTraceAsString(e));
        }
    }
    */
}
