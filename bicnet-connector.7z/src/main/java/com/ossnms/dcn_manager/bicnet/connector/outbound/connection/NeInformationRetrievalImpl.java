package com.ossnms.dcn_manager.bicnet.connector.outbound.connection;

import static com.google.common.base.Strings.nullToEmpty;
import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.google.common.collect.ImmutableList.copyOf;
import static com.google.common.collect.Lists.transform;
import static com.google.common.collect.Sets.newHashSet;
import static java.util.Collections.emptyMap;
import static org.slf4j.LoggerFactory.getLogger;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.slf4j.Logger;

import com.google.common.collect.BiMap;
import com.ossnms.bicnet.bcb.facade.elementMgmt.INetworkElementDomainAssignmentFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.INetworkElementFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementDomainAssignmentItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementDomainAssignmentReply;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.platform.IMediationFacadeManager;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.GatewayRole;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary;
import com.ossnms.bicnet.bcb.model.elementMgmt.ICommissioningStatusSummaryPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.IGatewayConfigurationPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElement;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementDomainAssignment;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementDomainAssignmentMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.IWriteAccessStatePkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.TpGroupMode;
import com.ossnms.bicnet.bcb.model.elementMgmt.WriteAccessState;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.factory.SystemContext;
import com.ossnms.dcn_manager.composables.configuration.AppProperties;
import com.ossnms.dcn_manager.composables.ne.NeDomainsUpdater;
import com.ossnms.dcn_manager.composables.outbound.NeInformationRetrieval;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.OperationalMode;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.outbound.exception.OutboundException;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;

/**
 * @see NeInformationRetrieval
 */
public class NeInformationRetrievalImpl implements NeInformationRetrieval {

    private static final Logger LOGGER = getLogger(NeInformationRetrievalImpl.class);

    private static final String NE_FACADE = "elementMgmt.NetworkElement";
    private static final String DOMAINS_FACADE = "elementMgmt.NetworkElementDomainAssignment";

    private final IMediationFacadeManager connectionManager;
    private final DomainManagers domainManagers;
    private final SettingsRepository settings;
    private final AppProperties appProperties;
    private final NeEntityRepository neRepository;
    private final ISessionContext context;
    private final NetworkElementNotifications notifications;
    private final StaticConfiguration configuration;
    private final NePhysicalConnectionRepository neInstancesRepository;
    private final ChannelPhysicalConnectionRepository channelInstancesRepository;
    private final NeConnectionManager neConnectionManager;

    @Inject
    public NeInformationRetrievalImpl(
            @DcnManager IMediationFacadeManager connectionManager,
            NetworkElementManagers neManagers,
            @DcnManager ChannelPhysicalConnectionRepository channelInstancesRepository,
            DomainManagers domainManagers,
            @SystemContext ISessionContext context,
            @DcnManager SettingsRepository settings,
            StaticConfiguration configuration,
            AppProperties appProperties,
            NeConnectionManager neConnectionManager) {
        this.connectionManager = connectionManager;
        this.domainManagers = domainManagers;
        this.settings = settings;
        this.appProperties = appProperties;
        this.neRepository = neManagers.getNeRepository();
        this.notifications = neManagers.getNeNotifications();
        this.neInstancesRepository = neManagers.getNeInstanceRepository();
        this.channelInstancesRepository = channelInstancesRepository;
        this.context = context;
        this.configuration = configuration;
        this.neConnectionManager = neConnectionManager;
    }

    @Override
    public NeEntity updateNeDataFromMediator(int physicalNeId)
            throws DataUpdateException, OutboundException, UnknownNetworkElementIdException, UnknownChannelIdException {

        try {
            final Optional<NePhysicalConnectionData> neInstance =
                    neInstancesRepository.query(physicalNeId);
            if (!neInstance.isPresent()) {
                throw new UnknownNetworkElementIdException("NE Instance {} not found.", physicalNeId);
            }

            final Optional<ChannelPhysicalConnectionData> channelInstance =
                    channelInstancesRepository.query(neInstance.get().getChannelInstanceId());
            if (!channelInstance.isPresent()) {
                throw new UnknownChannelIdException("Channel Instance {} not found.", neInstance.get().getChannelInstanceId());
            }

            final Optional<NeEntity> ne = neRepository.queryNe(neInstance.get().getLogicalNeId());
            if (!ne.isPresent()) {
                throw new UnknownNetworkElementIdException("NE {} not found.", neInstance.get().getLogicalNeId());
            }

            final NeEntity neEntity = ne.get();
            final INetworkElement networkElement =
                    getNetworkElement(neEntity.getInfo(), channelInstance.get().getMediatorInstanceId());

            final NeOperationData updatedOperationData =
                    tryUpdateNeOperation(neEntity, networkElement);

            final NeUserPreferencesData updatedUserPreferencesData =
                    tryUpdateNeNameFromNetwork(neEntity.getPreferences(), networkElement, neInstance.get(), neEntity);

            tryUpdateNeDomains(neEntity.getInfo().getNeId(),
                    getNetworkElementDomains(neEntity.getInfo().getNeId(), neEntity.getInfo().getChannelId(), channelInstance.get().getMediatorInstanceId()));

            return new NeEntity(neEntity.getConnection(),
                    updatedOperationData, neEntity.getInfo(), neEntity.getSync(),
                    updatedUserPreferencesData);

        } catch (final RepositoryException exception) {
            throw new DataUpdateException(exception);
        }
    }

    private void tryUpdateNeDomains(int neId, Set<String> configuredNetworkDomains) {

        try {
            LOGGER.info("Updating natural domains for NE {} to {}.", neId, configuredNetworkDomains);
            new NeDomainsUpdater(domainManagers.getDomainRepository(), domainManagers.getDomainNotifications(),
                    settings)
                    .storeNaturalDomains(neId, configuredNetworkDomains);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to update NE {} natural domains to {}: {}", neId, configuredNetworkDomains,
                    getStackTraceAsString(e));
        }

    }

    private Set<String> getNetworkElementDomains(int neId, int channelId, int mediatorInstanceId) throws OutboundException {
        try {
            final INetworkElementDomainAssignmentFacade domainFacade =
                    (INetworkElementDomainAssignmentFacade) connectionManager.getFacade(context, DOMAINS_FACADE,
                            new MediatorIdItem(mediatorInstanceId),
                            new EMIdItem(channelId));
            if (null != domainFacade) {
                final INetworkElementDomainAssignmentMarkable filter =
                        NetworkElementDomainAssignmentItem.markableNetworkElementDomainAssignment(null);
                filter.setNeId(neId);
                final NetworkElementDomainAssignmentReply domainAssignmentReply =
                        domainFacade.getNetworkElementDomainAssignmentList(context, null,
                                new INetworkElementDomainAssignmentMarkable[]{filter}, -1);
                final INetworkElementDomainAssignment[] domainAssignmentReplyData =
                        domainAssignmentReply.getData();
                return domainAssignmentReplyData == null
                        ? Collections.emptySet()
                        : newHashSet(transform(copyOf(domainAssignmentReplyData), INetworkElementDomainAssignment::getDomainName));
            }
        } catch (UnsupportedOperationException e) {
            LOGGER.info("NE {} does not support natural domains.", neId);
        } catch (BcbException e) {
            throw new OutboundException("Failed to work with NE domains facade.", e);
        }
        return Collections.emptySet();
    }

    private INetworkElement getNetworkElement(NeInfoData neInfoData, int mediatorInstance) throws OutboundException {
        try {

            final INetworkElementFacade neFacade =
                    (INetworkElementFacade) connectionManager.getFacade(context, NE_FACADE,
                            new MediatorIdItem(mediatorInstance),
                            new EMIdItem(neInfoData.getChannelId()));

            final INetworkElement networkElement =
                    neFacade.getSingleNetworkElement(context, new NetworkElementIdItem(neInfoData.getNeId()));
            if (null == networkElement) {
                throw new OutboundException("No network element on mediation for {}.", neInfoData);
            }

            return networkElement;
        } catch (UnsupportedOperationException | BcbException e) {
            throw new OutboundException("Failed to retrieve NE facade from CM.", e);
        }
    }

    private NeUserPreferencesData tryUpdateNeNameFromNetwork(NeUserPreferencesData preferences, INetworkElement networkElement, NePhysicalConnectionData connectionData, NeEntity neEntity) {
        final String realNeName = nullToEmpty(networkElement.getName());

        if (appProperties.isAutoCopyNeNameEnabled() && !realNeName.isEmpty()) {

            final NeUserPreferencesMutationDescriptor preferencesMutation =
                    new NeUserPreferencesMutationDescriptor(preferences)
                            .setName(realNeName)
                            .whenApplied(descriptor -> {
                                notifications.notifyChanges(descriptor);
                                notifyMediator(descriptor, connectionData, neEntity);
                            });
            try {
                final Optional<NeUserPreferencesData> updatedPreferences =
                        neRepository.getNeUserPreferencesRepository().tryUpdate(preferencesMutation);
                if (updatedPreferences.isPresent()) {
                    return updatedPreferences.get();
                }
                LOGGER.warn("Failed to update the NE name from network to {} for NE {} : concurrent update.",
                        realNeName, preferences);
            } catch (RepositoryException e) {
                LOGGER.error("Failed to update the NE name from network to {} for NE {} : {}",
                        realNeName, preferences, getStackTraceAsString(e));
            }
        }

        return preferences;
    }

    private void notifyMediator(NeUserPreferencesMutationDescriptor mutation, NePhysicalConnectionData connectionData, NeEntity neEntity) {
        try {
            neConnectionManager.updateNeProperties(neEntity, connectionData, mutation, emptyMap());
        } catch (ConnectException e) {
            LOGGER.error("Failed to update NE properties on mediation", e);
        }
    }

    private NeOperationData tryUpdateNeOperation(@Nonnull NeEntity neEntity, INetworkElement networkElement)
            throws DataUpdateException {
        final NeOperationMutationDescriptor operation = createMutation(neEntity.getOperation())                
                .setRealNeName(nullToEmpty(networkElement.getName()))
                .setTpGroupMask(networkElement.getTpGroupMask())
                .setMainRelease(nullToEmpty(networkElement.getMainRelease()))
                .setMaintenanceRelease(nullToEmpty(networkElement.getMaintenanceRelease()))
                .setLocation(nullToEmpty(networkElement.getLocation()));

        updateGatewayMode(networkElement, operation);
        
        updateOperationalInfo(networkElement, operation);

        updateTypesInfo(networkElement, operation);

        updateAccessInfo(networkElement, operation);

        updateNeSubTypeDescription(operation, networkElement);

        // if NeIdentificationControl is set then choose which INetworkElement attribute should be used to populate NeighbourhoodId

        final NeInfoData info = neEntity.getInfo();
        final NeType neType = configuration.getNeTypes().get(info.getProxyType());

        final BiMap<String, String> idControlMap = neType.getIdentificationControlMap();
        if (null != idControlMap) {
            final String sourcePropNameForNeighbourhoodId = idControlMap.get(WellKnownNePropertyNames.NEIGHBOURHOOD_ID);

            if (WellKnownNePropertyNames.SYSNAME.equals(sourcePropNameForNeighbourhoodId)) {
                operation.setNeighbourhoodId(networkElement.getName());
            } else if (WellKnownNePropertyNames.TL1_ID.equals(sourcePropNameForNeighbourhoodId)) {
                operation.setNeighbourhoodId(networkElement.getTid());
            }
        }

        return tryUpdateNeOperation(operation);
    }

    private void updateGatewayMode(INetworkElement networkElement, NeOperationMutationDescriptor operation) {
        final IGatewayConfigurationPkg gatewayConfig = (IGatewayConfigurationPkg) networkElement.getFacette(IGatewayConfigurationPkg.class);
        if(null != gatewayConfig) {
            final GatewayRole gatewayRole = gatewayConfig.getGatewayRole();
            operation.setGatewayMode(ConvertNeToBcb.convertGatewayRole(gatewayRole));
        }
        else {
            operation.setGatewayMode(GatewayMode.NONE);
        }
    }

    private void updateOperationalInfo(INetworkElement networkElement, NeOperationMutationDescriptor operation) {
        final TpGroupMode tpGroupMode = networkElement.getTpGroupMode();
        if (null != tpGroupMode) {
            operation.setTpGroupMode(
                    tpGroupMode.getAlwaysCompatible(),
                    tpGroupMode.getMultipleGroupMembership(),
                    tpGroupMode.getSubgroupsMustBeEqual(),
                    tpGroupMode.getMultipleSubgroupMembership());
        }

        if (null != networkElement.getOperationalState()) {
            operation.setOperationalMode(networkElement.getOperationalState() == OperationalState.DISABLED
                    ? OperationalMode.DISABLED : OperationalMode.ENABLED);
        }
        if (null != networkElement.getEventForwarding()) {
            operation.setEventForwardingActive(networkElement.getEventForwarding() == EnableSwitch.ENABLED);
        }
    }

    private void updateAccessInfo(INetworkElement networkElement, NeOperationMutationDescriptor operation) {
        final IWriteAccessStatePkg writeAccess = (IWriteAccessStatePkg)
                networkElement.getFacette(IWriteAccessStatePkg.class);
        if (null != writeAccess) {
            final WriteAccessState writeAccessState = writeAccess.getWriteAccessState();
            operation.setWriteAccess(ConvertNeToBcb.convertWriteAccessState(writeAccessState));
        }

        final ICommissioningStatusSummaryPkg commissioningStatus = (ICommissioningStatusSummaryPkg)
                networkElement.getFacette(ICommissioningStatusSummaryPkg.class);
        if (null != commissioningStatus) {
            final CommissioningStatusSummary status = commissioningStatus.getCommissioningStatusSummary();
            operation.setCommissioning(ConvertNeToBcb.convertCommissioningStatusSummary(status));
        }
    }

    private void updateTypesInfo(INetworkElement networkElement, NeOperationMutationDescriptor operation) {
        if (null != networkElement.getSpecificType()) {
            operation.setNeSpecificType(networkElement.getSpecificType());
        }
        if (null != networkElement.getNeFamily()) {
            operation.setFamily(networkElement.getNeFamily().name());
        }
        if (null != networkElement.getNeSubType()) {
            operation.setNeSubType(networkElement.getNeSubType().name());
        }
        if (null != networkElement.getNeType()) {
            operation.setNeType(networkElement.getNeType().name());
        }
    }

    private NeOperationData tryUpdateNeOperation(NeOperationMutationDescriptor operation)
            throws DataUpdateException {
        try {
            final Optional<NeOperationData> updatedOperationData =
                    neRepository.getNeOperationRepository().tryUpdate(operation);
            if (!updatedOperationData.isPresent()) {
                throw new DataUpdateException("Could not update NE Operational Data to {}", operation);
            }
            return updatedOperationData.get();
        } catch (final RepositoryException exception) {
            throw new DataUpdateException(exception);
        }
    }

    private NeOperationMutationDescriptor createMutation(final NeOperationData neOperation) {
        return new NeOperationMutationDescriptor(neOperation)
                .whenApplied(notifications::notifyChanges);
    }

    private void updateNeSubTypeDescription(NeOperationMutationDescriptor operation, INetworkElement networkElement) {
        if (null != networkElement.getSpecificType()) {
            operation.setNeSubTypeDescription(networkElement.getSpecificType());

        } else if (null != networkElement.getType()) {
            operation.setNeSubTypeDescription(networkElement.getType());
        }
    }
}
