package com.ossnms.dcn_manager.bicnet.connector.messaging;

import com.ossnms.dcn_manager.core.events.periodic.PeriodicEvent;
import rx.Observable;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.context.ApplicationScoped;

/**
 * Provides periodic timer events.
 * @see PeriodicEventsTimerBean
 */
@ApplicationScoped
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class PeriodicEventsSource
    extends MessageSourceImpl<PeriodicEvent>
    implements EventSource<PeriodicEvent> {

    @Override
    public void subscribe(Observable<DecoratedNotification> notificationSource) {

        /*
         * At the moment we don't trigger periodic events upon receiving external events.
         * All periodic events are pushed from an application server timer associated
         * with an EJB.
         */

    }

}
