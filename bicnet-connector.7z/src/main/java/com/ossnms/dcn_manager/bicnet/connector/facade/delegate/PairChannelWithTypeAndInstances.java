package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import org.apache.commons.lang3.tuple.Triple;

import javax.annotation.Nullable;
import java.util.function.Function;

public final class PairChannelWithTypeAndInstances implements Function<ChannelEntity, Triple<ChannelType, ChannelEntity, Iterable<ChannelPhysicalConnectionData>>> {

    private final StaticConfiguration configuration;
    private final ChannelPhysicalConnectionRepository physicalConnectionRepository;

    public PairChannelWithTypeAndInstances(StaticConfiguration configuration, ChannelPhysicalConnectionRepository physicalConnectionRepository) {
        this.configuration = configuration;
        this.physicalConnectionRepository = physicalConnectionRepository;
    }

    private Triple<ChannelType, ChannelEntity, Iterable<ChannelPhysicalConnectionData>> pair(StaticConfiguration configuration,
            @Nullable ChannelEntity channel) {
        return null == channel ?
                null :
                Triple.of(configuration.getChannelTypes().get(channel.getInfo().getType()), channel, findInstances(channel.getInfo().getId()));
    }

    private Iterable<ChannelPhysicalConnectionData> findInstances(int channelId) {
        return physicalConnectionRepository.queryAll(channelId);
    }

    @Override public Triple<ChannelType, ChannelEntity, Iterable<ChannelPhysicalConnectionData>> apply(ChannelEntity channel) {
        return pair(configuration, channel);
    }
}