package com.ossnms.dcn_manager.bicnet.connector.converter;

import java.util.function.Function;

import org.apache.commons.lang3.tuple.Triple;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;

/**
 * Handles conversion of internal domain entities representing a Channel to its
 * corresponding type in the server/client object model.
 */
public class ConvertChannelToFullChannel implements Function<Triple<ChannelType, ChannelEntity, Iterable<ChannelPhysicalConnectionData>>, FullChannelData> {

    @Override public FullChannelData apply(Triple<ChannelType, ChannelEntity, Iterable<ChannelPhysicalConnectionData>> channelInformation) {
        return channelInformation != null ? convert(channelInformation.getLeft(), channelInformation.getMiddle(), channelInformation.getRight()) : null;
    }

    /**
     * Converts a Channel domain entity into a new {@link IEM} BCB object.
     *
     * @param type Channel type metadata.
     * @param channel Channel entity that will be the source of data.
     * @param instances Physical channel connections, which will contribute to the whole information set.
     * @return A new instance of {@link FullChannelData} filled with data.
     */
    public static FullChannelData convert(ChannelType type, ChannelEntity channel, Iterable<ChannelPhysicalConnectionData> instances) {
        final IEM bcbChannel = new EMItem();
        final ChannelInfo info = ConvertChannelToChannelGuiInfo.build(channel, instances);

        ConvertChannelToBcb.fillExisting(type, channel, bcbChannel);

        return new FullChannelData(bcbChannel, info);
    }
}