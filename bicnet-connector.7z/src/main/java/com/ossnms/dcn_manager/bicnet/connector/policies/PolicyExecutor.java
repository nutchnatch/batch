package com.ossnms.dcn_manager.bicnet.connector.policies;

import com.ossnms.bicnet.util.monitor.jmx.JmxAddressBuilder;
import com.ossnms.bicnet.util.monitor.jmx.MonitoredExecutors;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutorImpl;

import javax.annotation.Nonnull;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.enterprise.context.ApplicationScoped;
import java.util.Observer;
import java.util.concurrent.ExecutorService;

/**
 * <p>Class that implements an execution policy.</p>
 *
 * <p>Instances have the default scope (i.e. @Dependent).</p>
 *
 * <p>The current implementation forwards execution to an executor service
 * managed by the application server. Provides, therefore, asynchronous
 * execution of any job submitted.</p>
 *
 * <p>Can also be observed by client code in order to be notified when tasks
 * complete execution. Note that the notification itself is done just before
 * releasing the executing thread.</p>
 */
@DcnManager
@ApplicationScoped // because it's an observable against the system executor, which is always the same, and it must keep a list of observers.
public class PolicyExecutor implements ObservableExecutor {

    /** The executor instance to be used to schedule request servicing execution. */
    @Resource(lookup = "java:jboss/ee/concurrency/executor/dcnManager")
    private ManagedExecutorService managedExecutorService;

    private ObservableExecutorImpl delegate;

    /**
     * <p>Creates the observable delegate. It's an ugly solution but necessary
     * because it is not possible to inject named resources in constructors.</p>
     *
     * <p>The delegate will forward execution to an executor service managed
     * by the application server.</p>
     */
    @PostConstruct
    public void initialize() {

        final JmxAddressBuilder addressBuilder = new JmxAddressBuilder().onPool().withName("dcnManager");
        final ExecutorService monitoredExecutor = MonitoredExecutors.monitored(managedExecutorService, addressBuilder.build());

        delegate = new ObservableExecutorImpl(monitoredExecutor);
    }

    /** Forwards execution to the observable executor. */
    @Override
    public void execute(@Nonnull Runnable command) {
        delegate.execute(command);
    }

    /** Forwards subscriptions to the observable executor. */
    @Override
    public void addObserver(Observer o) {
        delegate.addObserver(o);
    }

    /** Forwards unsubscriptions to the observable executor. */
    @Override
    public void deleteObserver(Observer o) {
        delegate.deleteObserver(o);
    }
}
