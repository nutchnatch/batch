package com.ossnms.dcn_manager.bicnet.connector.storage;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.storage.mediator.MediatorInstanceRepository;

/**
 * EJB that maintains an instance of a Mediator Instance repository.
 * @see MediatorInstanceRepository
 */
@DcnManager
@ApplicationScoped
public class JpaMediatorInstanceRepositoryBean extends MediatorInstanceRepository {

    @Inject
    private JpaRepositoryBean repositoryBean;

    @PostConstruct
    public void initialize() {
        final Supplier<CloseableEntityTransaction> transactionSupplier = repositoryBean.getTransactionSupplier();
        initialize(transactionSupplier);
    }

}
