package com.ossnms.dcn_manager.bicnet.events;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.facade.common.BiCNetComponentIdItem;
import com.ossnms.bicnet.bcb.facade.scs.IScsFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.common.SyncCategory;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncMode;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.composables.outbound.SharedResources;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import rx.functions.Action1;

import javax.annotation.Nonnull;
import java.util.Optional;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * Upon a successful NE initialization, acquires all NE shared resources managed by DCN
 * Manager and notifies SCS that other components may begin their initialization against the
 * newly initialized NE.
 */
class AcquireAndRequestNeSyncOnInitialization implements Action1<NeInitializedEvent> {

    private static final Logger LOGGER = getLogger(AcquireAndRequestNeSyncOnInitialization.class);

    private final NeEntityRepository neRepository;
    private final IScsFacade scs;
    private final ISessionContext systemContext;
    private final SharedResources<BicnetCallContext> sharedResources;

    /**
     * Creates a new instance.
     *
     * @param neRepository Network Element entity repository.
     * @param scs BiCNet SCS facade.
     * @param sharedResources Shared Resource management.
     * @param systemContext BiCNet system authentication context.
     */
    AcquireAndRequestNeSyncOnInitialization(
            @Nonnull NeEntityRepository neRepository,
            @Nonnull IScsFacade scs,
            @Nonnull SharedResources<BicnetCallContext> sharedResources,
            @Nonnull ISessionContext systemContext) {
        this.neRepository = neRepository;
        this.scs = scs;
        this.sharedResources = sharedResources;
        this.systemContext = systemContext;
    }

    @Override
    public void call(@Nonnull NeInitializedEvent event) {
        try {
            final Optional<NeInfoData> neInfoFound = neRepository.getNeInfoRepository().query(event.getNeId());
            if (neInfoFound.isPresent()) {
                final NeInfoData infoData = neInfoFound.get();
                final int neId = infoData.getNeId();
                final int channelId = infoData.getChannelId();

                sharedResources.acquireNeResources(new BicnetCallContext(systemContext), neId, channelId);

                requestNeSynchronization(infoData, event);

            } else {
                LOGGER.warn("NE entity not found on {}.", event);
            }
        } catch (final RepositoryException exception) {
            LOGGER.error("NE entity not found after event {}. {}\n{}", event, exception.getMessage(),
                    Throwables.getStackTraceAsString(exception));
        }
    }

    private void requestNeSynchronization(NeInfoData info, NeInitializedEvent event) {

        final SyncCategory syncCategory =
                event.getSynchronizationDataDifferences()
                    .map(this::calculateSyncCategory)
                    .orElse(SyncCategory.ALL); // default category in case we're unable to calculate the correct one.

        triggerSynchronization(info.getNeId(), info.getChannelId(), syncCategory);
    }

    private void triggerSynchronization(int neId, int channelId, SyncCategory syncCategory) {
        try {
            final BiCNetComponentIdItem componentIdItem =
                    new BiCNetComponentIdItem(BiCNetComponentType.ELEMENT_MANAGER, channelId, neId);
            LOGGER.info("Requesting {} synchronization of NE {} from SCS.", syncCategory, neId);
            scs.triggerForcedSync(systemContext,
                    new IBiCNetComponentId[] { componentIdItem },
                    ScsSyncMode.HARD_SYNC, syncCategory);
        } catch (final BcbException e) {
            LOGGER.error("Failed to request synchronization of NE from SCS.", e);
        }
    }

    private SyncCategory calculateSyncCategory(NeSynchronizationData synchronizationDifferences) {

        SyncCategory category = SyncCategory.NONE;

        if (synchronizationDifferences.getPacket().isPresent()) {
            category = SyncCategory.PACKET;
        }
        if (synchronizationDifferences.getAlarms().isPresent()) {
            category = category != SyncCategory.NONE ? SyncCategory.ALL : SyncCategory.ALARMS;
        }
        if (synchronizationDifferences.getAll().isPresent()) {
            category = SyncCategory.ALL;
        }

        return category;
    }
}