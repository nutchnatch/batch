package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;

import javax.annotation.Nonnull;

public class ConvertSystemAssignmentDataToBcb implements Function<SystemAssignmentData, ISystemGenericContainerAssignment> {

    @Override public ISystemGenericContainerAssignment apply(SystemAssignmentData input) {
        return convert(input);
    }

    public static ISystemGenericContainerAssignment convert(SystemAssignmentData input) {
        ISystemGenericContainerAssignment assignment = new SystemGenericContainerAssignmentItem();
        
        assignment.setGenericContainer(new GenericContainerIdItem(input.getContainerInfo().getId()));
        assignment.setSystemContainer(new SystemContainerIdItem(input.getSystemContainerId()));
        assignment.setPrimary(input.getAssignmentType().toFlag());
        
        return assignment;
    }

    public static ISystemGenericContainerAssignment convert(final int systemId, final int containerId, @Nonnull final AssignmentType assignmentType) {
        ISystemGenericContainerAssignment assignment = new SystemGenericContainerAssignmentItem();

        assignment.setGenericContainer(new GenericContainerIdItem(containerId));
        assignment.setSystemContainer(new SystemContainerIdItem(systemId));
        assignment.setPrimary(assignmentType.toFlag());

        return assignment;
    }
}
