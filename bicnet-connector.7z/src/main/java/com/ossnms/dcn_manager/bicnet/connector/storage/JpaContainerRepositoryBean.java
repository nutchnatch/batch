package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.google.common.base.Function;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.container.GenericContainerRepository;
import com.ossnms.dcn_manager.connector.storage.container.entities.ContainerInfoDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.ContainerNeAssignmentDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.ContainerSystemAssignmentDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.QContainerInfoDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.QContainerNeAssignmentDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.QContainerSystemAssignmentDb;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Optional;

/**
 * EJB that maintains an instance of a DCN Container repository.
 */
@DcnManager
@ApplicationScoped
public class JpaContainerRepositoryBean extends GenericContainerRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(JpaContainerRepositoryBean.class);

    @Inject
    private JpaRepositoryBean repositoryBean;

    @Override
    protected CloseableEntityTransaction getTransaction() {
        return repositoryBean.getTransactionSupplier().get();
    }

    public JpaCloseableQuery query(QContainerInfoDb path) {
        return new JpaCloseableQuery(repositoryBean.getManagerSupplier().get(), path);
    }

    public JpaCloseableQuery query(QContainerNeAssignmentDb assignmentDb) {
        return new JpaCloseableQuery(repositoryBean.getManagerSupplier().get(), assignmentDb);
    }

    public JpaCloseableQuery query(QContainerSystemAssignmentDb assignmentDb) {
        return new JpaCloseableQuery(repositoryBean.getManagerSupplier().get(), assignmentDb);
    }

    public Function<ContainerInfoDb, Optional<ContainerInfo>> getEntityTransformer() {
        return entityTransformer;
    }

    public Function<ContainerNeAssignmentDb, Optional<NeAssignmentData>> getNeAssignmentTransformer() {
        return neAssignmentTransformer;
    }

    public Function<ContainerSystemAssignmentDb, Optional<SystemAssignmentData>> getSystemAssignmentTransformer() {
        return systemAssignmentTransformer;
    }

    private final Function<ContainerInfoDb, Optional<ContainerInfo>> entityTransformer = input -> {
        try {
            return null != input ? fetchEntity(input) : Optional.empty();
        } catch (final RepositoryException e) {
            LOGGER.error("Error listing Container entities.", e);
            return Optional.empty();
        }
    };

    private final Function<ContainerNeAssignmentDb, Optional<NeAssignmentData>> neAssignmentTransformer = input -> {
        try {
            return null != input ? fetchEntity(input) : Optional.empty();
        } catch (final RepositoryException e) {
            LOGGER.error("Error listing NE Container assignment entities.", e);
            return Optional.empty();
        }
    };

    private final Function<ContainerSystemAssignmentDb, Optional<SystemAssignmentData>> systemAssignmentTransformer = input -> {
        try {
            return null != input ? fetchEntity(input) : Optional.empty();
        } catch (final RepositoryException e) {
            LOGGER.error("Error listing System Container assignment entities.", e);
            return Optional.empty();
        }
    };
}
