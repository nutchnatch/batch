package com.ossnms.dcn_manager.bicnet.connector.converter;

import java.util.Date;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.logMgmt.CommandLogRecordItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.LogIdItem;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogId;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecord;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;

/**
 * Converts the {@link LoggerItem} to BCB {@link CommandLogRecordItem}
 */
public class ConvertLoggerToCommandLog implements Function<LoggerItem, ILogRecord> {

    protected static final ILogId LOG_COMMAND_ID = new LogIdItem("Command Log");
    
    private final String userName;

    public ConvertLoggerToCommandLog(@Nullable String userName) {
        super();
        this.userName = userName;
    }
    
    public CommandLogRecordItem convert(@Nonnull final LoggerItem input) {
        final CommandLogRecordItem logRecord = new CommandLogRecordItem();

        logRecord.setBelonging(LOG_COMMAND_ID);
        logRecord.setBelongingName(LOG_COMMAND_ID.getName());
        logRecord.setComponent(BiCNetComponentType.DCN_MANAGER);

        logRecord.setTimeStamp(new Date());

        logRecord.setUserName(userName);
        logRecord.setAffectedObject(input.getAffectedObject());
        logRecord.setDescription(input.getMessage());

        return logRecord;
    }

    /**
     * @see Function#apply(Object)
     */
    @Override
    public ILogRecord apply(@Nullable LoggerItem input) {
        return input == null ? null : convert(input);
    }

}
