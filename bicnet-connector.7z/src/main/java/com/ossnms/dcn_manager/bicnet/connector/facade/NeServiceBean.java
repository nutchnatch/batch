package com.ossnms.dcn_manager.bicnet.connector.facade;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.NeService;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.NeHelper;
import com.ossnms.dcn_manager.bicnet.connector.security.Securable;

import javax.annotation.Nonnull;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.Collection;
import java.util.Map;

@Stateless(name = "NeServiceBean")
@Local(NeService.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class NeServiceBean implements NeService {

    @Inject
    private NeHelper helper;

    private void checkId(int id) throws BcbException {
        if (id <= 0) {
            throw new BcbException("NE IDs must be positive.");
        }
    }

    @Override
    public INE createNE(ISessionContext sessionContext, String neProxyType, IEMId parentEmId, INEId parentNe,
            IGenericContainerId genericContainerId, String neIdName, Property[] neProperties) throws BcbException {
        return helper.createNE(sessionContext, neProxyType, parentEmId, parentNe, genericContainerId, neIdName, neProperties);
    }

    /**
     * Duplicate NE data base on template object.
     *
     * @param sessionContext
     * @param template
     * @param neProperties
     */
    @Override public void duplicate(ISessionContext sessionContext, INE template, Property[] neProperties)
            throws BcbException {
        helper.duplicate(sessionContext, template, neProperties);
    }

    @Override
    public INE createNE(ISessionContext sessionContext, String neProxyType, IEMId parentEmId, INEId parentNe,
            ISystemContainerId systemContainerId, String neIdName, Property[] neProperties) throws BcbException {
        return helper.createNE(sessionContext, neProxyType, parentEmId, parentNe, systemContainerId, neIdName, neProperties);
    }

    @Override
    public Collection<FullNeData> getFullNeList(final ISessionContext sessionContext) throws BcbException {
        return helper.getFullNeList(sessionContext);
    }

    @Override public FullNeData getFullNe(ISessionContext sessionContext, Integer neId) throws BcbException {
        checkId(neId);
        return helper.getFullNe(sessionContext, neId);
    }

    @Override
    public Map<String, String> getProperties(@Nonnull final ISessionContext context, @Nonnull final INEId neId) throws BcbException {
        checkId(neId.getId());
        return helper.getProperties(context, neId);
    }

    @Override
    public Iterable<ScsSynchronizationState> getScsSynchronizationStates() {
        return helper.getScsSynchronizationStates();
    }

    @Override
    public String[] getSupportedNeTypes(@Nonnull final ISessionContext sessionContext, @Nonnull final String emType) throws BcbException {
        return helper.getSupportedNeTypes(sessionContext, emType);
    }

    @Override
    public void updateProperties(final ISessionContext sessionContext, final INEId neId, final Map<String, String> properties) throws BcbException {
        checkId(neId.getId());
        helper.updateProperties(sessionContext, neId, properties);
    }

    @Securable(SecureAction.OP_DELETE_SAN)
    @Override
    public void deleteNEs(final ISessionContext sessionContext, final Collection<INEId> neIds) throws BcbException {
        helper.deleteNEs(sessionContext, neIds);
    }

    @Securable(SecureAction.OP_COPY_NE_NAME_TO_ID_NAME_SAN)
    @Override
    public void copyNetworkNamesToNeNames(final ISessionContext sessionContext, final Collection<INEId> neIds) throws BcbException {
        helper.copyNetworkNamesToNeNames(sessionContext, neIds);
    }

    @Override
    public void moveNesToAnotherChannel(final ISessionContext sessionContext, final Collection<INEId> neIds, final IEMId targetChannelId) throws BcbException {
        helper.moveNesToAnotherChannel(sessionContext, neIds, targetChannelId);
    }

    @Securable(SecureAction.OP_MOGCM_ACTIVE_SAN)
    @Override
    public void setToActiveStateMode(final ISessionContext sessionContext, final INEId neId) throws BcbException {
        helper.setToActiveStateMode(sessionContext, neId);
    }

    @Securable(SecureAction.OP_MOGCM_MAINTENANCE_SAN)
    @Override
    public void setToMaintenanceMode(final ISessionContext sessionContext, final INEId neId) throws BcbException {
        helper.setToMaintenanceMode(sessionContext, neId);
    }

    @Securable(SecureAction.OP_MOGCM_OPERATIONAL_SAN)
    @Override
    public void setToOperationalMode(final ISessionContext sessionContext, final INEId neId) throws BcbException {
        helper.setToOperationalMode(sessionContext, neId);
    }

    @Securable(SecureAction.OP_MOGCM_REL_WRITE_ACC_SAN)
    @Override
    public void writeAccessRelease(final ISessionContext sessionContext, final INEId neId) throws BcbException {
        helper.writeAccessRelease(sessionContext, neId);
    }

    @Securable(SecureAction.OP_MOGCM_REQ_WRITE_ACC_SAN)
    @Override
    public void writeAccessRequest(final ISessionContext sessionContext, final INEId neId) throws BcbException {
        helper.writeAccessRequest(sessionContext, neId);
    }

    @Securable(SecureAction.OP_MOGCM_ENF_WRITE_ACC_SAN)
    @Override
    public void writeAccessEnforce(final ISessionContext sessionContext, final INEId neId) throws BcbException {
        helper.writeAccessEnforce(sessionContext, neId);
    }

    @Override
    public void changeSystemContainerId(final ISessionContext sessionContext, final Map<INEId, ISystemContainerId> associations) throws BcbException {
        helper.changeSystemContainerId(sessionContext, associations);
    }
    
    /**
     * Activates a collection of NEs on hot standby mode
     * 
     * @param sessionContext
     * @param neIds
     * @throws BcbException
     */
    @Override
    public void activateNesOnStandbyMediation(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException {
    	helper.activateNesOnStandbyMediation(sessionContext, neIds);    
    }

    /**
     * Deactivates a collection of NEs on hot standby mode
     * 
     * @param sessionContext
     * @param neIds
     * @throws BcbException
     */
    @Override
    public void deactivateNesOnStandbyMediation(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException {
    	helper.deactivateNesOnStandbyMediation(sessionContext, neIds);    
    }

    /**
     * Performs a resynch operations on a collection of NEs on hot standby mode
     * 
     * @param sessionContext
     * @param neIds
     * @throws BcbException
     */
    @Override
    public void resynchronizeNesOnStandbyMediation(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException {
    	helper.resynchronizeNesOnStandbyMediation(sessionContext, neIds);
    }

    @Override
    public void moveToContainers(ISessionContext sessionContext, Collection<INEId> neIds, Collection<IGenericContainerId> containers, IGenericContainerId primaryContainer) throws BcbException {
        helper.moveToContainers(sessionContext, neIds, containers, primaryContainer);
    }

    @Override
    public void moveToSystem(ISessionContext sessionContext, Collection<INEId> neIds, ISystemContainerId systemId) throws BcbException {
        helper.moveToSystem(sessionContext, neIds, systemId);
    }

    @Override
    public void moveToDefaultContainer(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException {
        helper.moveToDefaultContainer(sessionContext, neIds);
    }
}
