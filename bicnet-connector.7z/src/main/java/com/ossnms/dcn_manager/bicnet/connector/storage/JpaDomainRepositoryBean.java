package com.ossnms.dcn_manager.bicnet.connector.storage;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.domain.NetworkDomainRepository;
import com.ossnms.dcn_manager.connector.storage.domain.entities.QDomainInfoDb;
import com.ossnms.dcn_manager.connector.storage.domain.entities.QDomainNeMembershipDb;

/**
 * EJB that maintains an instance of a Domain repository.
 */
@DcnManager
@ApplicationScoped
public class JpaDomainRepositoryBean extends NetworkDomainRepository {

    @Inject
    private JpaRepositoryBean repositoryBean;

    @Override
    protected CloseableEntityTransaction getTransaction() {
        return repositoryBean.getTransactionSupplier().get();
    }

    public JpaCloseableQuery query(QDomainInfoDb path) {
        return new JpaCloseableQuery(repositoryBean.getManagerSupplier().get(), path);
    }

    public JpaCloseableQuery query(QDomainNeMembershipDb path) {
        return new JpaCloseableQuery(repositoryBean.getManagerSupplier().get(), path);
    }

}
