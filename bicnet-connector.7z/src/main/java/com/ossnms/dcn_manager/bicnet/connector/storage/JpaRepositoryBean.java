package com.ossnms.dcn_manager.bicnet.connector.storage;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityManager;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;

public class JpaRepositoryBean {

    @PersistenceUnit(unitName="DCN-MANAGER")
    private EntityManagerFactory managerFactory;

    private final Supplier<CloseableEntityTransaction> transactionSupplier = new TransactionSupplier();
    private final Supplier<CloseableEntityManager> managerSupplier = new EntityManagerSupplier();

    protected Supplier<CloseableEntityTransaction> getTransactionSupplier() {
        return transactionSupplier;
    }

    public Supplier<CloseableEntityManager> getManagerSupplier() {
        return managerSupplier;
    }

    protected final class TransactionSupplier implements Supplier<CloseableEntityTransaction> {
        @Override
        public CloseableEntityTransaction get() {
            final EntityManager entityManager = managerFactory.createEntityManager();
            final EntityTransaction tx = entityManager.getTransaction();
            tx.begin();
            return new JpaCloseableTransactionWithEntityManager(entityManager, tx);
        }
    }

    protected final class EntityManagerSupplier implements Supplier<CloseableEntityManager> {
        @Override
        public CloseableEntityManager get() {
            final EntityManager entityManager = managerFactory.createEntityManager();
            return new CloseableEntityManager(entityManager);
        }
    }

    private static final class JpaCloseableTransactionWithEntityManager
            extends CloseableEntityTransaction {

        private JpaCloseableTransactionWithEntityManager(EntityManager manager, EntityTransaction transaction) {
            super(manager, transaction);
        }

        /**
         * Closes the transaction and its supporting Entity Manager.
         */
        @Override
        public void close() {
            try {
                super.close();
            } finally {
                getEntityManager().close();
            }
        }
    }

}
