package com.ossnms.dcn_manager.bicnet.connector.factory;

import com.ossnms.bicnet.bcb.facade.elementMgmt.IGctMgrFacade;
import com.ossnms.bicnet.bcb.facade.faultMgmt.IFaultMgrFacade;
import com.ossnms.bicnet.bcb.facade.licensing.ILicenseMgrFacade;
import com.ossnms.bicnet.bcb.facade.logMgmt.ILogMgrFacade;
import com.ossnms.bicnet.bcb.facade.ndm.INetworkDataManagerFacade;
import com.ossnms.bicnet.bcb.facade.platform.IConnectionManager;
import com.ossnms.bicnet.bcb.facade.platform.INotifyBeanFacade;
import com.ossnms.bicnet.bcb.facade.platform.ISchedulerEjbFacade;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherFactory;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageDispatcherFactory;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.messaging.BiCNetMessageDispatcherFactory;
import com.ossnms.bicnet.messaging.direct.BiCNetDirectMessageDispatcherFactory;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import com.ossnms.dcn_manager.bicnet.connector.interfaces.BicnetServiceManagerFactory;
import com.ossnms.dcn_manager.bicnet.connector.security.SecureActionValidation;
import org.aspectj.lang.Aspects;

import javax.annotation.Nonnull;
import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.DCN_MANAGER;

/**
 * Factory that produces other CF BicNet public Facade implementations using the BiCNetServiceLocator.
 */
@ApplicationScoped
public class BicnetServiceManager implements BicnetServiceManagerFactory {

    public BicnetServiceManager() {

    }

    /**
     * Used to inject this bean in all aspects that need it.
     */
    @PostConstruct
    public void configureAspects() {
        Aspects.aspectOf(SecureActionValidation.class).setServiceManager(this);
    }

    /**
     * @return An instance of {@link IBiCNetDirectMessageDispatcherFactory}.
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public IBiCNetDirectMessageDispatcherFactory getBiCNetDirectMessageDispatcherFactory() {
        return BiCNetDirectMessageDispatcherFactory.getInstance();
    }

    /**
     * @return An instance of {@link IBiCNetMessageDispatcherFactory}.
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public IBiCNetMessageDispatcherFactory getBiCNetMessageDispatcherFactory() {
        return BiCNetMessageDispatcherFactory.getInstance();
    }

    /**
     * @return @see IBiCNetMessageDispatcher
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public IBiCNetMessageDispatcher getBiCNetMessageDispatcher() {
        return BiCNetMessageDispatcherFactory.getInstance().getDispatcher(DCN_MANAGER);
    }

    /**
     * @return @see IConnectionManager.
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public IConnectionManager getConnectionManagerAtpFacade() {
        try {
            return BiCNetServiceLocator.getInstance().getConnectionManager(DCN_MANAGER);
        } catch (final UnexpectedException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    /**
     * @return @see ILogMgrFacade
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public ILogMgrFacade getLogManagerFacade() {
        try {
            return BiCNetServiceLocator.getInstance().getLogManager(DCN_MANAGER);
        } catch (final UnexpectedException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    /**
     * @return @see ISchedulerEjbFacade
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public ISchedulerEjbFacade getSchedulerManagerFacade() {
        try {
            return BiCNetServiceLocator.getInstance().getScheduler(DCN_MANAGER);
        } catch (final UnexpectedException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    /**
     * @return @see ISystemControlEjbFacade
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public ISystemControlEjbFacade getSystemControlManagerFacade() {
        try {
            return BiCNetServiceLocator.getInstance().getScsManager(DCN_MANAGER);
        } catch (final UnexpectedException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    /**
     * @return @see IFaultMgrFacade
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public IFaultMgrFacade getFaultManager() {
        try {
            return BiCNetServiceLocator.getInstance().getFaultManager(DCN_MANAGER);
        } catch (final UnexpectedException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    /**
     * @return @see INotifyBeanFacade
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public INotifyBeanFacade getNotifyBeanFacade() {
        try {
            return BiCNetServiceLocator.getInstance().getNotificationManager(DCN_MANAGER);
        } catch (final UnexpectedException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    /**
     * @return @see ILicenseMgrFacade
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public ILicenseMgrFacade getLicenseManagerFacade() {
        try {
            return BiCNetServiceLocator.getInstance().getLicenseManager(DCN_MANAGER);
        } catch (final UnexpectedException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    /**
     * @return @see ISecurityMgrFacade
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public ISecurityMgrFacade getSecurityManagerFacade() {
        try {
            return BiCNetServiceLocator.getInstance().getSecurityManager(DCN_MANAGER);
        } catch (final UnexpectedException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    /**
     * @return @see IGctMgrFacade
     */
    @Override
    @Produces
    @DcnManager
    @Nonnull
    public IGctMgrFacade getGctManagerFacade() {
        try {
            return BiCNetServiceLocator.getInstance().getGctManager(DCN_MANAGER);
        } catch (final UnexpectedException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    @Override
    @Produces
    @DcnManager
    @Nonnull
	public INetworkDataManagerFacade getNetworkDataManager() {
    	try {
			return (INetworkDataManagerFacade) BiCNetServiceLocator.getInstance().getPublicFacade(BiCNetComponentType.NETWORK_DATA_MANAGER, DCN_MANAGER);
		} catch (UnsupportedOperationException | UnexpectedException e) {
			throw new UnsupportedOperationException(e);
		}
	}
}
