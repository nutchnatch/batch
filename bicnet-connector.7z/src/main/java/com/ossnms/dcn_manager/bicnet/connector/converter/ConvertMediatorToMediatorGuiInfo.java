package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.stream.StreamSupport;

/**
 * Handles conversion of internal domain entities representing a Mediator to its
 * corresponding type containing only GUI information.
 */
public final class ConvertMediatorToMediatorGuiInfo {

    private ConvertMediatorToMediatorGuiInfo() {

    }

    /**
     * Builds an instance of {@link MediatorInfo} containing GUI information.
     * @param mediator Mediator entity.
     * @return An instance of {@link MediatorInfo} containing GUI information.
     */
    public static MediatorInfo build(@Nonnull MediatorEntity mediator, Iterable<MediatorInstance> instances) {
        final Optional<ActualActivationState> standbyActualActivationState = findStandbyActualActivationState(instances);
        return new MediatorInfo(mediator.getInfo().getId())
                .setGuiActualActivationState(convert(mediator.getConnection().getActualActivationState()))
                .setGuiStandbyActualActivationState(standbyActualActivationState.map(ConvertMediatorToMediatorGuiInfo::convert).orElse(null))
                .setStandbyDisplayState(standbyActualActivationState.map(ConvertMediatorToBcb::describe).orElse(StringUtils.EMPTY))
                .setStandbyMediatorConfigured(standbyActualActivationState.isPresent())
                .setUserText(mediator.getInfo().getUserText().orElse(null));
    }

    private static Optional<ActualActivationState> findStandbyActualActivationState(Iterable<MediatorInstance> instances) {
        return StreamSupport.stream(instances.spliterator(), false)
            .map(MediatorInstance::getConnection)
            .filter(instance -> !instance.isActive())
            .findFirst()
            .map(MediatorPhysicalConnectionData::getActualActivationState);
    }

    /**
     * Given the current connection state, obtain the corresponding state for displaying in the GUI.
     */
    public static GuiActualActivationState convert(@Nonnull final ActualActivationState activationState) {
        switch (activationState) {
            case ACTIVE:
                return GuiActualActivationState.ACTIVE;
            case ACTIVATING:
                return GuiActualActivationState.ACTIVATING;
            case INACTIVE:
                return GuiActualActivationState.INACTIVE;
            case DEACTIVATING:
                return GuiActualActivationState.DEACTIVATING;
            case FAILED:
                return GuiActualActivationState.FAILED;
            default:
                throw new IllegalStateException("Actual activation state without GUI match: " + activationState);
        }
    }
}
