package com.ossnms.dcn_manager.bicnet.connector.outbound;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.platform.IConnectionManager;
import com.ossnms.bicnet.bcb.facade.platform.INotifyBeanFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.PlatformException;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertIntegerToBcbEm;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.composables.outbound.SharedResources;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

/**
 * @see SharedResources
 */
public class SharedResourcesImpl implements SharedResources<BicnetCallContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SharedResourcesImpl.class);

    private final INotifyBeanFacade notifyFacade;
    private final IConnectionManager connectionManagerFacade;

    @Inject
    public SharedResourcesImpl(
            @DcnManager INotifyBeanFacade notifyFacade,
            @DcnManager IConnectionManager connectionManagerFacade) {
        super();
        this.notifyFacade = notifyFacade;
        this.connectionManagerFacade = connectionManagerFacade;
    }

    /**
     * <p>Weaves EMs and NEs on Connection Manager and unlocks the NE facades, effectively
     * allowing other components to obtain information from NEs.</p>
     *
     * <img src="doc-files/sharedres-acquire-ne-sequence.png">
     */
    /*
     * @startuml doc-files/sharedres-acquire-ne-sequence.png
     * SharedResources --> "@P ConnectionManager": assignDao
     * SharedResources --> "@P ConnectionManager": release
     * box "BicNet" #LightBlue
     *    participant "@P ConnectionManager"
     * end box
     * @enduml
     */
    @Override
    public void acquireNeResources(BicnetCallContext context, int neId, int channelId) {
        final NEIdItem neIdItem = new NEIdItem(neId);

        /*
         * Let Connection Manager learn about the association between the NE and the Channel.
         * Tell Connection Manager to "unlock" the NE facades, effectively
         * allowing other components to obtain information from NEs.
         */
        try {
            connectionManagerFacade.assignNeToEm(context.getSessionContext(), new EMIdItem(channelId), neIdItem);
        } catch (final PlatformException e) {
            LOGGER.error("Connection Manager refused to associate NE {} with Channel {}. {}", neId, channelId, e);
        }
    }

    /**
     * <p>Tells @P Notif that the NE is no longer in use, disconnects EMs and NEs on Connection Manager
     * and locks the NE facades, effectively preventing other components from obtaining information
     * from NEs.</p>
     *
     * <img src="doc-files/sharedres-release-ne-sequence.png">
     */
    /*
     * @startuml doc-files/sharedres-release-ne-sequence.png
     * SharedResources --> "@P ConnectionManager": revoke
     * SharedResources --> "@P ConnectionManager": unassignDao
     * SharedResources --> "@P NotifMBean": releaseNe
     * box "BicNet" #LightBlue
     *    participant "@P NotifMBean"
     *    participant "@P ConnectionManager"
     * end box
     * @enduml
     */
    @Override
    public void releaseNeResources(BicnetCallContext context, int neId) {
        final NEIdItem neIdItem = new NEIdItem(neId);

        /*
         * Remove the association between the NE and the Channel from Connection Manager.
           * Tell Connection Manager to "lock" the NE facades, effectively preventing other
         * components from obtaining information from NEs.
         */
        try {
            connectionManagerFacade.unassignNeFromEm(context.getSessionContext(), neIdItem);
        } catch (final PlatformException pe) {
            LOGGER.error("Connection Manager refused to deassociate NE {} from its Channel. {}", neId, pe);
        }

        try {
            /*
             * Clear the @P NotifMBean Counter and Scheduler caches for NE entity.
             * NOTE: The @P NotifMBean caches are allocated by southbound components on the NE activation Use Case.
             */
            notifyFacade.releaseNe(context.getSessionContext(), neIdItem);
        } catch (final BcbException e) {
            LOGGER.error("Error to release the shared resources for NE=" + neId, e);
        }
    }

    /**
     * <p>Tells @P Notif that the Channel is no longer in use.</p>
     *
     * <img src="doc-files/sharedres-release-em-sequence.png">
     */
    /*
     * @startuml doc-files/sharedres-release-em-sequence.png
     * SharedResources --> "@P NotifMBean": releaseEm
     * box "BicNet" #LightBlue
     *    participant "@P NotifMBean"
     * end box
     * @enduml
     */
    @Override
    public void releaseChannelResources(BicnetCallContext context, int channelId) {
        try {
            /*
             * Clear the @P NotifMBean Counter and Scheduler caches for EM entity.
             * NOTE: The @P NotifMBean caches are allocated by southbound components on the EM activation Use Case.
             */
            notifyFacade.releaseEm(context.getSessionContext(), ConvertIntegerToBcbEm.convert(channelId));
        } catch (final BcbException e) {
            LOGGER.error("Error to release the shared resources for Channel=" + channelId, e);
        }
    }
}
