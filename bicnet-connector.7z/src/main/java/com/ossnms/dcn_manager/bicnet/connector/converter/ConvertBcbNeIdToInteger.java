package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;

/**
 * Function that converts an {@link INEId} into an integer.
 */
public class ConvertBcbNeIdToInteger implements Function<INEId, Integer> {

    /**
     * Extracts an integer NE identifier from an instance of {@link INEId}.
     * @return The value of {@link INEId#getId()} or zero if the instance received is {@code null}.
     */
    @Override
    public Integer apply(INEId input) {
        return input != null ? input.getId() : 0;
    }

}
