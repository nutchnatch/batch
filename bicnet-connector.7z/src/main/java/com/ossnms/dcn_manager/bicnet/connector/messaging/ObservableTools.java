package com.ossnms.dcn_manager.bicnet.connector.messaging;

import java.util.LinkedList;
import java.util.List;

import com.google.common.collect.ImmutableList;

import rx.Observable;
import rx.Subscriber;
import rx.functions.Func1;

/**
 * Provides utility functions and predicates for using with the Rx Observables API.
 */
public final class ObservableTools {

    private ObservableTools() {
        // utility classes are final with private constructors.
    }

    /**
     * Predicate used to determine whether an object is of a specific type.
     * @param klass K type metadata.
     * @param <T> Base object type.
     * @param <K> Type to check the object against.
     * @return A predicate that will return {@code True} when called with an
     * instance of the type as its argument.
     */
    public static <T, K> Func1<T, Boolean> isOfType(Class<K> klass) {
        return new IsOfType<>(klass);
    }

    /**
     * Function used to cast an object instance to a specific type.
     * @param klass K type metadata.
     * @param <T> Base object type.
     * @param <K> Type to cast the instance to.
     * @return A function that will always cast its argument to type K
     * and return it as K.
     */
    public static <T, K> Func1<T, K> cast(Class<K> klass) {
        return new Cast<>(klass);
    }

    /**
     * <p>Builder function for a conditional map operator.</p>
     *
     * <p>This operator needs one or more predicates and a transformation
     * (map) function. When invoked with an item instance, it will apply the map
     * function to the item and return its result IIF all predicates return True.
     * Otherwise, the original item is returned untouched.</p>
     *
     * <p>Example: <code> when(isOfType(SomeType.class)).map(new MapFunction()) </code><p>
     *
     * @param predicate Initial
     * @param <T> Original argument type.
     * @param <R> Map function result type.
     * @return
     */
    public static <R, T extends R> When<R, T> when(Func1<? super T, Boolean> predicate) {
        return new When<R, T>(predicate);
    }

    /**
     * <p>Utility function used to cast the result of a function to {@code Object}.</p>
     *
     * <p>Given a function f with a parameter p of type T, this is equivalent to
     * {@code (Object) f(p)}.</p>
     *
     * @param function Function that is to be used to obtain the object instance.
     * @param <T> Original argument type.
     * @param <R> Original function result type.
     * @return A function that will always cast its argument to {@code Object}
     * and return it as {@code Object}.
     */
    public static <T, R> Func1<T, Object> objectify(final Func1<T, R> function) {
        return new Func1<T, Object>() {
            @Override
            public Object call(T t1) {
                return function.call(t1);
            }
        };
    }

    /**
     * Creates a new "and" evaluation of a number of predicates.
     * Evaluation is short-circuited: predicate evaluation is stopped
     * as soon as one evaluates to false.
     * @param <T> Base argument type.
     * @param predicates Predicates to be evaluated.
     * @throws NullPointerException if any of {@code predicates} is null
     */
    @SafeVarargs
    public static <T extends Object> Func1<T, Boolean> and(Func1<T, Boolean>... predicates) {
        return new And<>(predicates);
    }

    /**
     * Creates a new "and" evaluation of two predicates.
     * Evaluation is short-circuited: predicate evaluation is stopped
     * as soon as one evaluates to false.
     * @param <T> Base argument type.
     * @param predicateA Predicate to be evaluated.
     * @param predicateB Predicate to be evaluated.
     */
    public static Func1<? super Object, Boolean> and(final Func1<? super Object, Boolean> predicateA, final Func1<? super Object, Boolean> predicateB) {
        return new Func1<Object, Boolean>() {
            @Override
            public Boolean call(Object t1) {
                return predicateA.call(t1) && predicateB.call(t1);
            }
        };
    }

    /**
     * Function composition. Given two functions f and g such that {@code f: T -> K} and
     * {@code g: K -> R}, returns a function {@link h: T -> R} where
     * {@code h(x) == g(f(x))}.
     * @param <T> Initial argument type.
     * @param <K> Intermediate argument type.
     * @param <R> Return type.
     * @param g Outer function to apply.
     * @param f Inner function to apply.
     * @return The composition of f and g.
     */
    public static <T, K, R> Func1<T, R> compose(Func1<K, R> g, Func1<T, K> f) {
        return new Compose<>(g, f);
    }

    private static final class Cast<T, K> implements Func1<T, K> {

        private final Class<K> klass;

        private Cast(Class<K> klass) {
            this.klass = klass;
        }

        /* (non-Javadoc)
         * @see rx.functions.Func1#call(java.lang.Object)
         */
        @Override
        public K call(T value) {
            return klass.cast(value);
        }

    }

    private static final class IsOfType<T, K> implements Func1<T, Boolean> {

        private final Class<K> klass;

        private IsOfType(Class<K> klass) {
            this.klass = klass;
        }

        /* (non-Javadoc)
         * @see rx.functions.Func1#call(java.lang.Object)
         */
        @Override
        public Boolean call(T value) {
            return klass.isInstance(value);
        }

    }

    private static final class Compose<T, K, R> implements Func1<T, R> {

        private final Func1<T, K> func1;
        private final Func1<K, R> func2;

        private Compose(Func1<K, R> g, Func1<T, K> f) {
            func1 = f;
            func2 = g;
        }

        /* (non-Javadoc)
         * @see rx.functions.Func1#call(java.lang.Object)
         */
        @Override
        public R call(T value) {
            return func2.call(func1.call(value));
        }

    }

    private static final class And<T> implements Func1<T, Boolean> {

        private final Iterable<Func1<T, Boolean>> predicates;

        @SafeVarargs
        private And(Func1<T, Boolean>... predicates) {
            this.predicates = ImmutableList.copyOf(predicates);
        }

        /* (non-Javadoc)
         * @see rx.functions.Func1#call(java.lang.Object)
         */
        @Override
        public Boolean call(T value) {
            for (final Func1<T, Boolean> predicate : predicates) {
                if (!predicate.call(value)) {
                    return false;
                }
            }
            return true;
        }

    }

    /**
     * Implementation of the operator builder created by {@link ObservableTools#when(Func1)}.
     *
     * @param <T> Original argument type.
     * @param <R> Map function result type.
     */
    public static final class When<R, T extends R> {

        private final List<Func1<? super T, Boolean>> predicates;

        private When(Func1<? super T, Boolean> predicate) {
            predicates = new LinkedList<>();
            predicates.add(predicate);
        }

        /**
         * Adds a predicate to the list of preconditions.
         * @param predicate Predicate to be evaluated.
         */
        public When<R, T> and(Func1<? super T, Boolean> predicate) {
            predicates.add(predicate);
            return this;
        }

        /**
         * Sets the map function that will be called conditionally, depending on the
         * evaluation of the predicates for each item, and builds this {@code When}
         * operator.
         *
         * @param transformation Item map (transformation) function.
         * @return An instance of {@link Observable.Operator}.
         */
        public Observable.Operator<R, T> map(final Func1<? super T, ? extends R> transformation) {
            return new Observable.Operator<R, T>() {
                @Override
                public Subscriber<? super T> call(final Subscriber<? super R> child) {
                    return new ConditionalTransformationSubscriber(child, transformation);
                }
            };
        }

        private final class ConditionalTransformationSubscriber extends Subscriber<T> {

            private final Subscriber<? super R> child;
            private final Func1<? super T, ? extends R> transformation;

            private ConditionalTransformationSubscriber(Subscriber<? super R> child,
                    Func1<? super T, ? extends R> transformation) {
                this.child = child;
                this.transformation = transformation;
            }

            @Override
            public void onCompleted() {
                if (!child.isUnsubscribed()) {
                    child.onCompleted();
                }
            }

            @Override
            public void onError(Throwable e) {
                if (!child.isUnsubscribed()) {
                    child.onError(e);
                }
            }

            /**
             * {@inheritDoc}
             *
             * <p>The item provided will be either the original item if at least one
             * predicate evaluates to False, or the item transformed by a map
             * function.</p>
             */
            @Override
            public void onNext(T t) {
                if (child.isUnsubscribed()) {
                    return;
                }
                for (final Func1<? super T, Boolean> func1 : predicates) {
                    if (!func1.call(t)) {
                        child.onNext(t);
                        return;
                    }
                }
                child.onNext(transformation.call(t));
            }
        }

    }

}
