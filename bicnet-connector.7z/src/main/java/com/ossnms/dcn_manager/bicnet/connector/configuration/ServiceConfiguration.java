package com.ossnms.dcn_manager.bicnet.connector.configuration;

import com.ossnms.bicnet.bcb.facade.common.IBicNetService;
import com.ossnms.bicnet.bcb.facade.elementMgmt.IGctMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.INetworkSettingsFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkSettingsItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.bcb.model.common.File;
import com.ossnms.bicnet.bcb.model.common.Log4jLevel;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeDataTransferSettings;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkSettings;
import com.ossnms.bicnet.util.versions.ServerComponentVersionInfo;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertBcbToDataTransferSettings;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertDataTransferSettingsToBcb;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.connection.NeConnectionManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.NeNotificationsManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.commands.settings.internal.SetNeDataTransferSettings;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.emne.SettingsProperties;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDataTransferSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nullable;
import javax.inject.Inject;
import java.util.Map;
import java.util.Optional;
import java.util.stream.StreamSupport;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertDataTransferSettingsToBcb.loopbackToServerHost;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.Optional.ofNullable;

public class ServiceConfiguration implements IBicNetService, INetworkSettingsFacade {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceConfiguration.class);

    private static final int NETWORK_SETTINGS_ID = 1;

    @Inject @DcnManager
    private SettingsRepository settingsRepository;

    @Inject @DcnManager
    private JpaNetworkElementRepositoryBean neRepository;

    @Inject
    private StaticConfigurationSingleton configuration;

    @Inject @DcnManager
    private ChannelEntityRepository channelRepository;

    @Inject @DcnManager
    private MediatorInstanceEntityRepository mediatorInstanceRepository;

    @Inject
    private NetworkElementManagers networkElementManagers;
    
    @Inject
    private NeNotificationsManagerImpl notifications;
    
    @Inject
    private NeConnectionManagerImpl connectionManager;
    
    @Inject
    private LoggerManagerImpl loggerManager;
    
    @Inject @DcnManager
    private IGctMgrFacade gctManager;

    /**
     * @return The Global Configuration defined by user.
     */
    public Map<String, String> getGlobalSettings() {
        return SettingsProperties.getProperties(settingsRepository.getSettings());
    }

    /**
     * Gets the Data Transfer authentication present at the NE User Prefereces or Global Configuration.
     *
     * @param sessionContext
     * @param neId
     * @return
     * @throws BcbException
     */
    public INeDataTransferSettings getNeDataTransferSettings(ISessionContext sessionContext, INEId neId)
            throws BcbException {
        try {
            final NeEntity ne = neRepository.queryNe(neId.getId())
                    .orElseThrow(() -> new RepositoryException("NeId {} not found", neId.getId()));

            final ChannelInfoData channel = channelRepository.getChannelInfoRepository().query(ne.getInfo().getChannelId())
                    .orElseThrow(() -> new RepositoryException("ChannelId {} not found", ne.getInfo().getChannelId()));

            Optional<INeDataTransferSettings> dataTransferSettingsBcb = loadDataTransferFromNE(ne, channel);

            if (!dataTransferSettingsBcb.isPresent() && supportsGlobalSFTP(channel)) {
                dataTransferSettingsBcb = loadGlobalDataTransfer(sessionContext, ne.getInfo().getProxyType());
            }

            return loopbackToServerHost(dataTransferSettingsBcb, configuration.getServerHost());

        } catch (final Exception e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private boolean supportsGlobalSFTP(final ChannelInfoData channel) throws RepositoryException {
        return ofNullable(configuration.getChannelTypes().get(channel.getType()))
                .orElseThrow(() -> new RepositoryException("Channel Type Unknown."))
                .supportsGlobalSFTP();
    }

    private Optional<INeDataTransferSettings> loadDataTransferFromNE(NeEntity ne, ChannelInfoData channel)
            throws RepositoryException {

        final NeDataTransferSettings dataTransferFromNe = ne.getPreferences().getDataTransferSettings();

        if (dataTransferFromNe.getUsername().isPresent() && dataTransferFromNe.getPassword().isPresent()) {
            INeDataTransferSettings dataTransferSettingsBcb = ConvertDataTransferSettingsToBcb.from(dataTransferFromNe, ne.getInfo().getProxyType());

            if (!dataTransferFromNe.getIpAddress().isPresent() || StringUtils.isBlank(dataTransferFromNe.getIpAddress().orElse(""))) {
                final String mediatorHost = loadActiveMediatorHostName(channel);

                dataTransferSettingsBcb.setIpAddress(mediatorHost);
            }

            return Optional.of(dataTransferSettingsBcb);
        }

        return Optional.empty();
    }

    private Optional<INeDataTransferSettings> loadGlobalDataTransfer(ISessionContext sessionContext, String neType)
            throws BcbException {
        final Map<String, String> globalDataTransferProperties = gctManager.getSFTPConfigDetails(sessionContext);

        if (globalDataTransferProperties == null ) {
            LOGGER.error("Error getting global SFTP settings. SFTP settings are null.");
            return Optional.empty();
        }

        return Optional.of(ConvertDataTransferSettingsToBcb.from(globalDataTransferProperties, neType));
    }

    private String loadActiveMediatorHostName(ChannelInfoData channel) throws RepositoryException {
        final Optional<String> activeMediatorHostName =
                StreamSupport.stream(mediatorInstanceRepository.queryAll(channel.getMediatorId()).spliterator(), false)
                .filter(instance -> instance.getConnection().isActive())
                .findFirst()
                .map(MediatorInstance::getPhysicalInfo)
                .map(MediatorPhysicalData::getHost);
        if (!activeMediatorHostName.isPresent()) {
            throw new RepositoryException("Active instance for MediatorId {} not found", channel.getMediatorId());
        }

        return activeMediatorHostName.get();
    }

    public void setNeDataTransferSettings(ISessionContext sessionContext, INEId neId, INeDataTransferSettings neDataTransferSettings)
            throws BcbException {
        try {
            new SetNeDataTransferSettings<>(new BicnetCallContext(sessionContext), 
                    neId.getId(), 
                    neDataTransferSettings.getNeType(),
                    neRepository, 
                    networkElementManagers,
                    connectionManager,
                    notifications, 
                    loggerManager,
                    ConvertBcbToDataTransferSettings.from(neDataTransferSettings))
            .call();
        } catch (CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }
  
    /**
     * {@inheritDoc}
     */
    @Override
    @Nullable
    public String getName(@Nullable ISessionContext sessionContext) throws BcbException {
        return BiCNetComponentType.DCN_MANAGER.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Nullable
    public String getDescription(@Nullable ISessionContext sessionContext) throws BcbException {
        return BiCNetComponentType.DCN_MANAGER.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Nullable
    public BiCNetComponentType getComponentType(@Nullable ISessionContext sessionContext) throws BcbException {
        return BiCNetComponentType.DCN_MANAGER;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Nullable
    public Log4jLevel getLog4JDefaultLevel(@Nullable ISessionContext sessionContext) throws BcbException {
        return Log4jLevel.INFO;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Nullable
    public ComponentVersionInformation getVersion(@Nullable ISessionContext sessionContext) throws BcbException {
        return ServerComponentVersionInfo.getVersionInfo(getClass());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isTraceDataCollectionSupported(@Nullable ISessionContext sessionContext) throws BcbException {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void collectTraceData(@Nullable ISessionContext sessionContext, @Nullable File destinationFolder) throws BcbException {
        LOGGER.info("Nothing to do...");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public INetworkSettings getTheNetworkSettings(ISessionContext sessionContext) {
        return new NetworkSettingsItem(null, NETWORK_SETTINGS_ID,
                settingsRepository.getSettings().isNativeNeNamingEnabled());
    }
}
