package com.ossnms.dcn_manager.bicnet.connector.outbound;

import static com.google.common.collect.Iterables.toArray;
import static com.google.common.collect.Iterables.transform;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.logMgmt.ILogMgrFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecord;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToCommandLog;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToImportHistory;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToNetworkEventLog;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToNetworkResourceLog;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToSystemEventLog;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemImportHistory;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;

/**
 * @see {@link #LoggerManager}
 * 
 * <img src="doc-files/loggermanagement.png"> 
 */
/*
 * @startuml doc-files/loggermanagement.png
 * "EMNE LoggerManager" --> "EMNE LoggerManager": convertLoggerItemsToLogRecords
 * "EMNE LoggerManager" --> "LogM": createLogRecords
 * box "BicNet" #LightBlue
 *    participant "LogM"
 * end box
 * @enduml
 */
public class LoggerManagerImpl implements LoggerManager<BicnetCallContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoggerManagerImpl.class);

    private final ILogMgrFacade logFacade;

    @Inject
    public LoggerManagerImpl(@DcnManager ILogMgrFacade logFacade) {
        super();
        this.logFacade = logFacade;
    }

    /**
     * @see LoggerManager#createSystemEventLog(com.ossnms.dcn_manager.core.context.CallContext, LoggerItem...)
     */
    @Override
    public void createSystemEventLog(@Nonnull final BicnetCallContext context, @Nonnull final LoggerItem... loggerItems) {
        createLogRecords(context,
                transform(ImmutableList.copyOf(loggerItems),
                        new ConvertLoggerToSystemEventLog(context.getSessionContext().getUserName())));
    }

    /**
     * @see LoggerManager#createCommandLog(com.ossnms.dcn_manager.core.context.CallContext, LoggerItem...)
     */
    @Override
    public void createCommandLog(@Nonnull final BicnetCallContext context, @Nonnull final LoggerItem... loggerItems) {
        createLogRecords(context,
                transform(ImmutableList.copyOf(loggerItems),
                        new ConvertLoggerToCommandLog(context.getSessionContext().getUserName())));
    }

    /**
     * @see LoggerManager#createNetworkResourceLog(com.ossnms.dcn_manager.core.context.CallContext, LoggerItemNe...)
     */
    @Override
    public void createNetworkResourceLog(@Nonnull final BicnetCallContext context, @Nonnull final LoggerItemNe... loggerItems) {
        createLogRecords(context,
                transform(ImmutableList.copyOf(loggerItems),
                        new ConvertLoggerToNetworkResourceLog(context.getSessionContext().getUserName())));
    }

    /**
     * @see LoggerManager#createNetworkEventLog(com.ossnms.dcn_manager.core.context.CallContext, LoggerItemNe...)
     */
    @Override
    public void createNetworkEventLog(@Nonnull final BicnetCallContext context, @Nonnull final LoggerItemNe... loggerItems) {
        createLogRecords(context,
                transform(ImmutableList.copyOf(loggerItems), 
                        new ConvertLoggerToNetworkEventLog(context.getSessionContext().getUserName())));
    }

    /**
     * @see LoggerManager#createImportHistoryLog(com.ossnms.dcn_manager.core.context.CallContext,
     *      LoggerItemImportHistory...)
     */
    @Override
    public void createImportHistoryLog(@Nonnull final BicnetCallContext context, @Nonnull final LoggerItemImportHistory... loggerItems) {
        createLogRecords(context, 
                transform(ImmutableList.copyOf(loggerItems), new ConvertLoggerToImportHistory()));
    }

    /**
     * Sends the data to Bicnet Log manager.
     * 
     * @param context
     * @param logRecords
     * @throws BcbException
     */    
    private void createLogRecords(@Nonnull final BicnetCallContext context, @Nonnull final Iterable<ILogRecord> logRecords) {
        try {
            logFacade.createLogRecords(context.getSessionContext(), toArray(logRecords, ILogRecord.class));
        } catch (final BcbException e) {
            LOGGER.error("Erro to create the log record for loggerItems {}", logRecords);
        }
    }
}
