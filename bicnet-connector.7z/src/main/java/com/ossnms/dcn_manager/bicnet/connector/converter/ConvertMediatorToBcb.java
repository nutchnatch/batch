package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.ossnms.bicnet.bcb.facade.common.IconPairIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.IIconPairId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorActivationState;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.i18n.Message;
import org.apache.commons.lang3.tuple.Triple;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.StreamSupport;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Handles conversion of internal domain entities representing a Mediator to its
 * corresponding type in the BCB object model.
 */
public class ConvertMediatorToBcb implements Function<Triple<MediatorType, MediatorEntity, Iterable<MediatorInstance>>, IMediator> {

    /**
     * Converts internal domain entities representing a Mediator to a
     * {@link IMediator} BCB object.
     *
     * @param type Mediator type metadata.
     * @param entity Mediator entity instance that will be the source of data.
     * @param instances Configured physical Mediator server instances.
     * @return A new instance of {@link IMediator} filled with data.
     */
    public static IMediator convert(MediatorType type, MediatorEntity entity, Iterable<MediatorInstance> instances) {
        final IMediator mediator = new MediatorItem();
        fillExisting(type, entity, instances, mediator);
        return mediator;
    }

    /**
     * Fills an existing {@link IMediator} BCB object with information from our domain entity.
     *
     * @param type Mediator type metadata.
     * @param entity Mediator entity instance that will be the source of data.
     * @param existing BCB {@link IMediator} instance to fill with data.
     */
    public static void fillExisting(MediatorType type, MediatorEntity entity, Iterable<MediatorInstance> instances, IMediator existing) {

        fillExisting(entity, instances, existing);

        final IIconPairId defaultIconPair = new IconPairIdItem(BiCNetComponentType.DCN_MANAGER, type.getDefaultIcon());
        existing.setIconId(defaultIconPair);
        existing.setIconIdContext(defaultIconPair.getContext());
        existing.setIconIdId(defaultIconPair.getId());

    }

    /**
     * Fills an existing {@link IMediator} BCB object with information from our domain entity.
     *
     * @param entity Mediator entity instance that will be the source of data.
     * @param existing BCB {@link IMediator} instance to fill with data.
     */
    public static void fillExisting(MediatorEntity entity, Iterable<MediatorInstance> instances, IMediator existing) {

        fillExisting(entity.getInfo(), existing);
        fillExisting(entity.getConnection(), existing);

        final Optional<MediatorInstance> activeInstance = StreamSupport.stream(instances.spliterator(), false)
                        .filter(MediatorInstance.IS_ACTIVE::apply).findFirst();
        if (activeInstance.isPresent()) {
            existing.setMediatorHost(activeInstance.get().getPhysicalInfo().getHost());
            existing.setDisplayAddress(activeInstance.get().getPhysicalInfo().getHost());
        }

        existing.setAdditionalInfo(entity.getConnection().getAdditionalInfo());
        existing.setPropertiesValid(true);
    }

    private static void fillExisting(MediatorConnectionData connection, IMediator existing) {
        existing.setActualActivationState(convert(connection.getActualActivationState()));
        existing.setDisplayState(describe(connection.getActualActivationState()));
    }

    public static String describe(ActualActivationState actualActivationState) {
        switch (actualActivationState) {
        case ACTIVE:
            return tr(Message.ACTIVE);
        case ACTIVATING:
            return tr(Message.ACTIVATING);
        case INACTIVE:
            return tr(Message.INACTIVE);
        case DEACTIVATING:
            return tr(Message.DEACTIVATING);
        case FAILED:
            return tr(Message.FAILED);
        default:
            return "";
        }
    }

    private static MediatorActivationState convert(ActualActivationState actualActivationState) {
        switch (actualActivationState) {
        case ACTIVE:
            return MediatorActivationState.ACTIVE;
        case FAILED:
            return MediatorActivationState.FAILED;
        default:
            return MediatorActivationState.INACTIVE;
        }
    }

    private static void fillExisting(MediatorInfoData info, IMediator existing) {

        existing.setId(info.getId());
        existing.setIdName(info.getName());
        existing.setActivation(info.isActivationRequired() ? EnableSwitch.ENABLED : EnableSwitch.DISABLED);
        existing.setMediatorType(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.fromName(info.getTypeName()));
        existing.setReconnectInterval(info.getReconnectAttemptInterval());
    }

    /**
     * Fills an existing {@link IMediatorMarkable} BCB object with information from
     * a mutation executed on our domain entity.
     *
     * @param mutation Entity mutation descriptor that will be the source of data.
     * @param existing BCB {@link IMediatorMarkable} instance to fill with data.
     */
    public static void fillExistingMarkable(MediatorInfoMutationDescriptor mutation, IMediatorMarkable existing) {

        fillExisting(mutation.getResult(), existing);
        existing.setId(mutation.getResult().getId());
        existing.setPropertiesValid(true);
        mutation.getActivationRequired().ifPresent(activationRequired -> existing.setActivation(activationRequired ? EnableSwitch.ENABLED : EnableSwitch.DISABLED));
        mutation.getName().ifPresent(name -> existing.setIdName(name));
        mutation.getReconnectAttemptInterval().ifPresent(reconnectInterval -> existing.setReconnectInterval(reconnectInterval) );
    }

    public static IMediator convert(@Nonnull Triple<MediatorType, MediatorEntity, Iterable<MediatorInstance>> input) {
        return convert(input.getLeft(), input.getMiddle(), input.getRight());
    }

    @Override
    public IMediator apply(@Nonnull Triple<MediatorType, MediatorEntity, Iterable<MediatorInstance>> input) {
        return convert(input.getLeft(), input.getMiddle(), input.getRight());
    }

}
