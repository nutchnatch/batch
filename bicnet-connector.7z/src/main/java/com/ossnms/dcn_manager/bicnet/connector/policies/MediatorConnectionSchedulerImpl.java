package com.ossnms.dcn_manager.bicnet.connector.policies;

import com.codahale.metrics.Gauge;
import com.codahale.metrics.MetricRegistry;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorConnectionManager;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.policies.impl.MediatorInteractionManagerImpl;

import javax.annotation.Nonnull;
import javax.annotation.PreDestroy;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import static com.codahale.metrics.MetricRegistry.name;

/**
 * Class that implements the connector responsible for binding the implementation of the mediator interaction policy
 * (i.e. {@link MediatorConnectionSchedulerImpl} to the technological stack whose existence is presumed by this
 * connector (i.e. JBoss EJB container).
 *
 * Design decisions:
 * <ul>
 * <li> The implementation relies on delegation, instead of using inheritance, as depicted in the class diagram.
 * The goal is to segregate technology specific requirements (e.g. life-cycle management services that require
 * the use of proxies, and therefore a no-argument constructor) from the requirements pertaining to the problem
 * domain. </li>
 * <li> Because application scope is used, the class implementation is thread-safe by resorting to immutable state
 * and delegation: the field {@link #delegate} is final and the referenced object is thread-safe.
 * </ul>
 *
 * <p> <figure>
 * <img src="doc-files/mediator_connection_scheduler_connector-class.png">
 * <figcaption>Class diagram of the implementation of the connector for mediator interaction policy</figcaption>
 * </figure> </p>
 */
/*
 * @startuml doc-files/mediator_connection_scheduler_connector-class.png

 * package emne.core.policies {
 *      interface MediatorInteractionManager {
 *          + scheduleActivation(ActivateMediatorEvent)
 *          + scheduleDeactivation(ActivateMediatorEvent)
 *          + onMediatorInteractionEnded(ActualMediatorStateEvent)
 *          + getPendingJobCount() : int
 *          + getOngoingJobCount() : int
 *          + getMaxOngoingJobCount() : int
 *          + setMaxOngoingJobCount(int)
 *      }
 *      package emne.core.policies.impl {
 *          class MediatorInteractionManagerImpl
 *      }
 * }
 * package emne.connector.jboss.policies {
 *      class MediatorConnectionSchedulerImpl << ApplicationScoped >>
 * }
 * MediatorInteractionManager <|.. MediatorInteractionManagerImpl
 * MediatorInteractionManager <|.. MediatorConnectionSchedulerImpl
 * MediatorConnectionSchedulerImpl *- MediatorInteractionManagerImpl : delegate
 * hide MediatorInteractionManagerImpl members
 * hide MediatorConnectionSchedulerImpl members
 * @enduml
 */
@ApplicationScoped
@DcnManager
public class MediatorConnectionSchedulerImpl implements MediatorInteractionManager {

    private static final String MEDIATOR_INTERACTIONS_METRIC_NAME = "mediator-interactions";

    /** Holds the actual policy implementation. */
    private final MediatorInteractionManager delegate;

    /**
     * Initiates an instance with the required dependencies.
     * @param connectionManager The instance used to interact with the solution's Connection Manager
     * (i.e. the out-bound abstraction).
     * @param executionPolicy The executor instance to be used to schedule request servicing execution.
     */
    @Inject
    public MediatorConnectionSchedulerImpl(
            MediatorConnectionManager connectionManager,
            @DcnManager ObservableExecutor executionPolicy,
            MetricRegistry metricRegistry) {
        delegate = new MediatorInteractionManagerImpl(connectionManager, executionPolicy);

        metricRegistry.<Gauge<Integer>>register(
                name(MEDIATOR_INTERACTIONS_METRIC_NAME, "pendingOnSystem"), this::getPendingJobCount);
        metricRegistry.<Gauge<Integer>>register(
                name(MEDIATOR_INTERACTIONS_METRIC_NAME, "ongoingOnSystem"), this::getOngoingJobCount);
    }

    /** Default constructor to make the class proxyable by Jboss. */
    protected MediatorConnectionSchedulerImpl() {
        // Proxyes do not make use of the types' fields.
        delegate = null;
    }

    /** {@inheritDoc} */
    @Override
    public void scheduleActivation(@Nonnull ActivateMediatorEvent event) {
        delegate.scheduleActivation(event);
    }

    /** {@inheritDoc} */
    @Override
    public void scheduleDeactivation(@Nonnull DeactivateMediatorEvent event) {
        delegate.scheduleDeactivation(event);
    }

    /** {@inheritDoc} */
    @Override
    public void onMediatorInteractionEnded(@Nonnull ActualMediatorStateEvent mediatorStateEvent) {
        delegate.onMediatorInteractionEnded(mediatorStateEvent);
    }

    /** {@inheritDoc} */
    @Override
    public int getPendingJobCount() {
        return delegate.getPendingJobCount();
    }

    /** {@inheritDoc} */
    @Override
    public int getOngoingJobCount() {
        return delegate.getOngoingJobCount();
    }

    /** {@inheritDoc} */
    @Override
    public int getMaxOngoingJobCount() {
        return delegate.getMaxOngoingJobCount();
    }

    /** {@inheritDoc} */
    @Override
    public void setMaxOngoingJobCount(int newMaxInteractions) {
        delegate.setMaxOngoingJobCount(newMaxInteractions);
    }

    @PreDestroy
    @Override
    public void close() {
        delegate.close();
    }
}
