package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.elementMgmt.IGctMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeDataTransferSettingsItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeDataTransferSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDataTransferSettings;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

import static com.google.common.base.Preconditions.checkNotNull;
import static org.apache.commons.lang3.StringUtils.stripToEmpty;

/**
 * Convert the Ne Data transfer settings to BCB.
 */
public final class ConvertDataTransferSettingsToBcb {

    private ConvertDataTransferSettingsToBcb() {}
    
    private static final Collection<String> LOOPBACK_OR_EMPTY = ImmutableList.of("localhost", "127.0.0.1", "");

    /**
     * Transform  from the Global (S)FTP Settings.
     *
     * @param input The Data transfer properties map from Global Configuration.
     * @param neType
     * @return The BCB Data Transfer settings
     */
    @Nonnull
    public static INeDataTransferSettings from(@Nonnull final Map<String,String> input, @Nonnull final String neType) {
        return from(input.get(IGctMgrFacade.GCT_SFTP_IP),
                    input.get(IGctMgrFacade.GCT_SFTP_USER),
                    input.get(IGctMgrFacade.GCT_SFTP_PASSWORD),
                    input.get(IGctMgrFacade.GCT_SFTP_ROOTPATH),
                    neType,
                    false);
    }

    /**
     * Transform from the NE user preferences.
     *
     * @param input Ne data transfer settings from Ne user preferences.
     * @param neType
     * @return The BCB Data Transfer settings
     */
    @Nonnull
    public static INeDataTransferSettings from(@Nonnull final NeDataTransferSettings input, @Nonnull final String neType) {
        checkNotNull(input);
        checkNotNull(neType);

        return from(input.getIpAddress().orElse(null),
                input.getUsername().orElse(null),
                input.getPassword().orElse(null),
                input.getUploadPath().orElse(null),
                    neType,
                    input.getIsScp());
    }

    @Nonnull
    public static INeDataTransferSettings loopbackToServerHost(@Nonnull final Optional<INeDataTransferSettings> input, @Nonnull final String serverHost) {
        if (input.isPresent() && LOOPBACK_OR_EMPTY.contains(stripToEmpty(input.get().getIpAddress()))) {
            input.get().setIpAddress(serverHost);
        }

        return input.orElse(null);
    }

    private static INeDataTransferSettings from(String ipAddress, String userName, String password, String uploadPath, String neType, boolean scpModeEnable) {
        INeDataTransferSettings dataTransferSettings = new NeDataTransferSettingsItem();

        dataTransferSettings.setIpAddress(ipAddress);
        dataTransferSettings.setUserName(userName);
        dataTransferSettings.setPassword(password);
        dataTransferSettings.setUploadPath(uploadPath);
        dataTransferSettings.setNeType(neType);
        dataTransferSettings.setScpMode(scpModeEnable);

        return dataTransferSettings;
    }
}
