package com.ossnms.dcn_manager.bicnet.connector.messaging.discovery;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.elementMgmt.NetworkElementDiscovered;
import com.ossnms.dcn_manager.bicnet.connector.messaging.DecoratedNotification;
import com.ossnms.dcn_manager.bicnet.connector.messaging.EventSource;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.events.Event;

import rx.Observable;

/**
 * Filtering, preprocessing and transformation of NE Discovered events.
 */
@ApplicationScoped
public class DiscoveryEventSource implements EventSource<Event> {

    static final Logger LOGGER = LoggerFactory.getLogger(DiscoveryEventSource.class);

    @Inject
    private StaticConfiguration configuration;

    private Observable<Event> events;

    @Override
    public void subscribe(Observable<DecoratedNotification> notificationSource) {

        events = notificationSource
                .filter(n -> n.getNotification(NetworkElementDiscovered.class).isPresent())
                .filter(n -> n.getOriginatingPhysicalMediator().map(MediatorPhysicalConnectionData::isActive).orElse(false))
                .map(new MapToInternalDiscoveryEvent(configuration));

    }

    @Override
    public Observable<Event> observe() {
        return events;
    }

}
