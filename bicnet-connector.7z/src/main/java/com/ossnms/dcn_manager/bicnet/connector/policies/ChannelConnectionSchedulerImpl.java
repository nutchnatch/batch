package com.ossnms.dcn_manager.bicnet.connector.policies;

import com.codahale.metrics.Gauge;
import com.codahale.metrics.MetricRegistry;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelConnectionManager;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.policies.impl.ChannelInteractionManagerImpl;

import javax.annotation.Nonnull;
import javax.annotation.PreDestroy;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import static com.codahale.metrics.MetricRegistry.name;

/**
 * Class that implements the connector responsible for binding the implementation of the Channel interaction policy
 * (i.e. {@link ChannelInteractionManager) to the technological stack whose existence is presumed by this
 * connector (i.e. JBoss EJB container).
 *
 * Design decisions:
 * <ul>
 * <li> The implementation relies on delegation, instead of using inheritance, as depicted in the class diagram.
 * The goal is to segregate technology specific requirements (e.g. life-cycle management services that require
 * the use of proxies, and therefore a no-argument constructor) from the requirements pertaining to the problem
 * domain. </li>
 * <li> Because application scope is used, the class implementation is thread-safe by resorting to immutable state
 * and delegation: the field {@link #delegate} is final and the referenced object is thread-safe.
 * </ul>
 *
 * <p> <figure>
 * <img src="doc-files/ne_connection_scheduler_connector-class.png">
 * <figcaption>Class diagram of the implementation of the connector for NE interaction policy</figcaption>
 * </figure> </p>
 */
/*
 * @startuml doc-files/ne_connection_scheduler_connector-class.png

 * package emne.core.policies {
 *      interface NetworkElementInteractionManager {
 *          + scheduleActivation(ActivateNeEvent)
 *          + scheduleDeactivation(DeactivateNeEvent)
 *          + onMediatorInteractionEnded(ActualNeStateEvent)
 *          + getPendingJobCount() : int
 *          + getOngoingJobCount() : int
 *          + getMaxOngoingJobCount() : int
 *          + getPendingJobCount(channelId : int) : int
 *          + getOngoingJobCount(channelId : int) : int
 *          + getMaxOngoingJobCount(channelId : int) : int
 *          + setMaxOngoingJobCount(channelId : int, newMax : int)
 *      }
 *      package emne.core.policies.impl {
 *          class NetworkElementInteractionManagerImpl
 *      }
 * }
 * package emne.connector.jboss.policies {
 *      class NetworkElementConnectionSchedulerImpl << ApplicationScoped >>
 * }
 * NetworkElementInteractionManager <|.. NetworkElementConnectionSchedulerImpl
 * NetworkElementInteractionManager <|.. NetworkElementInteractionManagerImpl
 * NetworkElementConnectionSchedulerImpl *- NetworkElementInteractionManagerImpl : delegate
 * hide NetworkElementConnectionSchedulerImpl members
 * hide NetworkElementInteractionManagerImpl members
 * @enduml
 */
@ApplicationScoped
@DcnManager
public class ChannelConnectionSchedulerImpl implements ChannelInteractionManager {

    private static final String CHANNEL_INTERACTIONS_METRIC_NAME = "channel-interactions";

    /** Holds the actual policy implementation. */
    private final ChannelInteractionManager delegate;

    /**
     * Initiates an instance with the required dependencies.
     * @param connectionManager The instance used to interact with the solution's Connection Manager
     * (i.e. the out-bound abstraction).
     */
    @Inject
    public ChannelConnectionSchedulerImpl(
            ChannelConnectionManager connectionManager,
            @DcnManager ObservableExecutor executionPolicy,
            MetricRegistry metricRegistry) {
        delegate = new ChannelInteractionManagerImpl(connectionManager, executionPolicy);

        metricRegistry.<Gauge<Integer>>register(
                name(CHANNEL_INTERACTIONS_METRIC_NAME, "pendingOnSystem"), this::getPendingJobCount);
        metricRegistry.<Gauge<Integer>>register(
                name(CHANNEL_INTERACTIONS_METRIC_NAME, "ongoingOnSystem"), this::getOngoingJobCount);
    }

    /** Default constructor to make the class proxyable by Jboss. */
    protected ChannelConnectionSchedulerImpl() {
        // Proxies do not make use of the types' fields.
        delegate = null;
    }

    /** {@inheritDoc} */
    @Override
    public void scheduleActivation(@Nonnull RequiredChannelStateEvent.Activate event) {
        delegate.scheduleActivation(event);
    }

    /** {@inheritDoc} */
    @Override
    public void scheduleDeactivation(@Nonnull RequiredChannelStateEvent.Deactivate event) {
        delegate.scheduleDeactivation(event);
    }

    /** {@inheritDoc} */
    @Override
    public void onChannelInteractionEnded(@Nonnull ActualChannelStateEvent channelStateEvent) {
        delegate.onChannelInteractionEnded(channelStateEvent);
    }

    /** {@inheritDoc} */
    @Override
    public int getPendingJobCount() {
        return delegate.getPendingJobCount();
    }

    /** {@inheritDoc} */
    @Override
    public int getOngoingJobCount() {
        return delegate.getOngoingJobCount();
    }

    /** {@inheritDoc} */
    @Override
    public int getPendingJobCount(int channelId) {
        return delegate.getPendingJobCount(channelId);
    }

    /** {@inheritDoc} */
    @Override
    public int getOngoingJobCount(int channelId) {
        return delegate.getOngoingJobCount(channelId);
    }

    /** {@inheritDoc} */
    @Override
    public int getMaxOngoingJobCount(int channelId) {
        return delegate.getMaxOngoingJobCount(channelId);
    }

    /** {@inheritDoc} */
    @Override
    public void setMaxOngoingJobCount(int channelId, int newMaxInteractions) {
        delegate.setMaxOngoingJobCount(channelId, newMaxInteractions);
    }

    @PreDestroy
    @Override
    public void close() {
        delegate.close();
    }

    /** {@inheritDoc} */
    @Override
    public void cancelDeactivations(@Nonnull RequiredChannelStateEvent event) {
        delegate.cancelDeactivations(event);
    }

    /** {@inheritDoc} */
    @Override
    public void cancelActivations(@Nonnull RequiredChannelStateEvent event) {
        delegate.cancelActivations(event);
    }
}
