package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterators;
import com.google.common.collect.Maps;
import com.mysema.commons.lang.CloseableIterator;
import com.mysema.query.BooleanBuilder;
import com.mysema.query.types.Ops;
import com.mysema.query.types.expr.BooleanExpression;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.INEFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEReply;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapabilities;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapability;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeGneCost;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.NeService;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertBcbNeIdToInteger;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertBcbPropertyToMap;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToFullNe;
import com.ossnms.dcn_manager.bicnet.connector.facade.util.BicnetStandbyProperties;
import com.ossnms.dcn_manager.bicnet.connector.facade.util.MarkableFilters;
import com.ossnms.dcn_manager.bicnet.connector.facade.util.NeGneCostCalculator;
import com.ossnms.dcn_manager.bicnet.connector.facade.util.UnsupportedQueryParametersException;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.connection.NeAccessControlManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.connection.NeConnectionManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.NeNotificationsManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.commands.channel.internal.GetSupportedNeTypeNames;
import com.ossnms.dcn_manager.commands.container.MoveNesToContainer;
import com.ossnms.dcn_manager.commands.container.MoveNesToDefaultContainer;
import com.ossnms.dcn_manager.commands.container.MoveNesToSystem;
import com.ossnms.dcn_manager.commands.container.assignment.CreateDefaultNeAssignment;
import com.ossnms.dcn_manager.commands.container.assignment.CreateSingleNeAssignment;
import com.ossnms.dcn_manager.commands.ne.CreateNetworkElement;
import com.ossnms.dcn_manager.commands.ne.DeleteNetworkElement;
import com.ossnms.dcn_manager.commands.ne.DuplicateNetworkElement;
import com.ossnms.dcn_manager.commands.ne.GetAllNEs;
import com.ossnms.dcn_manager.commands.ne.GetNe;
import com.ossnms.dcn_manager.commands.ne.internal.ActivateNeOnStandby;
import com.ossnms.dcn_manager.commands.ne.internal.ChangeNeSystem;
import com.ossnms.dcn_manager.commands.ne.internal.CopyNetworkNameToNeName;
import com.ossnms.dcn_manager.commands.ne.internal.DeactivateNeOnStandby;
import com.ossnms.dcn_manager.commands.ne.internal.MoveNetworkElementsToAnotherChannel;
import com.ossnms.dcn_manager.commands.ne.internal.NetworkElementActivationRequired;
import com.ossnms.dcn_manager.commands.ne.internal.NetworkElementDeactivationRequired;
import com.ossnms.dcn_manager.commands.ne.internal.ResynchronizeNeOnStandby;
import com.ossnms.dcn_manager.commands.ne.internal.ResynchronizeNetworkElements;
import com.ossnms.dcn_manager.commands.ne.internal.SetToActiveStateMode;
import com.ossnms.dcn_manager.commands.ne.internal.SetToMaintenanceMode;
import com.ossnms.dcn_manager.commands.ne.internal.SetToOperationalMode;
import com.ossnms.dcn_manager.commands.ne.internal.UpdateNeProperties;
import com.ossnms.dcn_manager.commands.ne.internal.WriteAccessEnforce;
import com.ossnms.dcn_manager.commands.ne.internal.WriteAccessRelease;
import com.ossnms.dcn_manager.commands.ne.internal.WriteAccessRequest;
import com.ossnms.dcn_manager.composables.ne.NeDomainsUpdater;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeEntityDb;
import com.ossnms.dcn_manager.connector.storage.ne.entities.QNeEntityDb;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.ne.NePropertiesChangedEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.properties.ne.NeDirectRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeGatewayRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeOperationalProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeProperties;
import com.ossnms.dcn_manager.core.properties.ne.NePropertyUtils;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.utils.GuavaCollectors;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.IllegalNetworkElementStateException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import javax.persistence.PersistenceException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.google.common.base.Functions.compose;
import static com.google.common.base.Predicates.and;
import static com.google.common.base.Predicates.notNull;
import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.google.common.collect.Collections2.filter;
import static com.google.common.collect.Collections2.transform;
import static com.google.common.collect.Iterables.toArray;
import static com.google.common.collect.Iterators.limit;
import static com.mysema.query.support.Expressions.constant;
import static com.mysema.query.support.Expressions.predicate;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.Collections.emptyMap;
import static java.util.stream.StreamSupport.stream;


public class NeHelper implements INEFacade, NeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeHelper.class);

    @Inject @DcnManager
    private JpaNetworkElementRepositoryBean neRepository;

    @Inject @DcnManager
    private JpaContainerRepositoryBean containerRepository;

    @Inject @DcnManager
    private JpaSystemRepositoryBean systemRepository;

    @Inject @DcnManager
    private DomainRepository domainRepository;

    @Inject
    private DomainNotifications domainNotifications;

    @Inject @DcnManager
    private SettingsRepository settingsRepository;

    @Inject @DcnManager
    private ChannelEntityRepository channelRepository;

    @Inject @DcnManager
    private ChannelPhysicalConnectionRepository channelInstanceRepository;

    @Inject
    private StaticConfiguration configuration;

    @Inject
    private NeNotificationsManagerImpl notifications;

    @Inject
    private LoggerManagerImpl loggerManager;

    @Inject
    private NeConnectionManagerImpl connectionManager;

    @Inject
    private NeAccessControlManagerImpl accessControlManager;

    @Inject
    private NetworkElementManagers networkElementManagers;

    @Inject
    private ChannelManagers channelManagers;

    @Inject @DcnManager
    private ISystemControlEjbFacade scs;

    @Inject
    private ContainerNotifications containerNotifications;

    /**
     * Gets the NeType property from a key.
     */
    public Property getNeTypeProperty(ISessionContext sessionContext, int neId, String propertyName) throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }

    @Override
    public INE getSingleNE(ISessionContext sessionContext, INEId neId) throws BcbException {
        try {
            final BicnetCallContext context = new BicnetCallContext(sessionContext);
            final int id = neId.getId();
            final Optional<NeEntity> ne = new GetNe<>(context, neRepository, id).call();
            return optionalEntityToBcb(ne);
        } catch (final DcnManagerException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    // TODO improve performance with a single query.
    public Optional<IMediatorId> getMediatorIdByNeId(INEId neId) throws BcbException {
        try {
            final Optional<NeInfoData> ne = neRepository.getNeInfoRepository().query(neId.getId());
            if (ne.isPresent()) {
                final Optional<ChannelInfoData> channel = channelRepository.getChannelInfoRepository()
                        .query(ne.get().getChannelId());
                if (channel.isPresent()) {
                    return Optional.of(new MediatorIdItem(channel.get().getMediatorId()));
                }
            }
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }

        return Optional.empty();
    }

    private Collection<String> getNeTypeNamesWithCapabilities(final NeCapabilities capabilities) {
        return transform(
                filter(configuration.getNeTypes().values(),
                        type -> NeCapabilities.fromDbString(type.getCapabilities()).containsAll(capabilities)),
                NeType::getName
        );
    }

    private JpaCloseableQuery buildQueryExpression(INEId startAfter, INEMarkable[] filter, QNeEntityDb ne) throws UnsupportedQueryParametersException {
        final JpaCloseableQuery query = neRepository.query(ne);
        final BooleanBuilder predicateBuilder = new BooleanBuilder();

        predicateBuilder.and(MarkableFilters.buildPredicateExpression(ne, filter, this::buildPredicateExpression));

        if (startAfter != null) {
            predicateBuilder.and(ne.info.neId.gt(startAfter.getId()));
        }
        if (predicateBuilder.hasValue()) {
            query.where(predicateBuilder);
        }

        /*
         * We don't limit the number of records returned explicitly so that an iterator created
         * against the entire result set will allow detection of further unread records.
         */
        query.orderBy(ne.info.neId.asc());
        return query;
    }

    private BooleanExpression buildPredicateExpression(QNeEntityDb ne, INEMarkable markable) {
        LOGGER.debug("Filtering NE listing with: {}", markable.toStringOnlyMarkedAttributes());
        final List<BooleanExpression> booleanExpressions = new LinkedList<>();
        if (markable.isMarkedId()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.info.neId, constant(markable.getId())));
            markable.markId(false);
        }
        if (markable.isMarkedNeProxyType()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.info.proxyType, constant(markable.getNeProxyType())));
            markable.markNeProxyType(false);
        }
        if (markable.isMarkedAssociatedEmId()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.info.channelId, constant(markable.getAssociatedEmId())));
            markable.markAssociatedEmId(false);
        }
        if (markable.isMarkedCoreId()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.info.coreId, constant(Optional.of(markable.getCoreId()))));
            markable.markCoreId(false);
        }
        if (markable.isMarkedAssociatedSystemContainerId()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.preferences.containerId, constant(Optional.of(markable.getAssociatedSystemContainerId()))));
            markable.markAssociatedSystemContainerId(false);
        }
        if (markable.isMarkedIdName()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.preferences.name, constant(markable.getIdName())));
            markable.markIdName(false);
        }
        if (markable.isMarkedNeighbourhoodId()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.operation.neighbourhoodId, constant(Optional.ofNullable(markable.getNeighbourhoodId()))));
            markable.markNeighbourhoodId(false);
        }
        if (markable.isMarkedRealNeName()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.operation.realNeName, constant(Optional.ofNullable(markable.getRealNeName()))));
            markable.markRealNeName(false);
        }
        if (markable.isMarkedActivation()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.info.requiredActivationState,
                    constant(markable.getActivation() == EnableSwitch.ENABLED ? RequiredActivationState.ACTIVE : RequiredActivationState.INACTIVE)));
            markable.markActivation(false);
        }
        if (markable.isMarkedCapabilities()) {
            booleanExpressions.add(predicate(Ops.IN, ne.info.proxyType, constant(getNeTypeNamesWithCapabilities(markable.getCapabilities()))));
            markable.markCapabilities(false);
        }
        if (markable.isMarkedNeFamilyEnum()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.operation.family, constant(Optional.ofNullable(markable.getNeFamilyEnum().name()))));
            markable.markNeFamilyEnum(false);
        }
        if (markable.isMarkedNeTypeEnum()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.operation.neType, constant(Optional.ofNullable(markable.getNeTypeEnum().name()))));
            markable.markNeTypeEnum(false);
        }
        if (markable.isMarkedGlobalId()) {
            booleanExpressions.add(predicate(Ops.EQ, ne.preferences.globalId, constant(Optional.ofNullable(markable.getGlobalId()))));
            markable.markGlobalId(false);
        }
        if (markable.countMarks() > 0) {
            throw new UnsupportedQueryParametersException("Unsupported query parameters: " + markable.toStringOnlyMarkedAttributes());
        }
        return BooleanExpression.allOf(booleanExpressions.toArray(new BooleanExpression[booleanExpressions.size()]));
    }

    private List<INEMarkable> consumeActivationStateFilters(INEMarkable[] filterMarkables) {
        if (null != filterMarkables) {
            final ArrayList<INEMarkable> filter = new ArrayList<>(filterMarkables.length);
            for (final INEMarkable markable : filterMarkables) {
                if (markable.isMarkedCommunicationState() || markable.isMarkedInitState() || markable.isMarkedActualActivationState()) {
                    final INEMarkable activationStateMarkable = NEItem.markableNE(null);
                    activationStateMarkable.setCommunicationState(markable.getCommunicationState());
                    activationStateMarkable.setInitState(markable.getInitState());
                    activationStateMarkable.setActualActivationState(markable.getActualActivationState());
                    activationStateMarkable.markCommunicationState(markable.isMarkedCommunicationState());
                    activationStateMarkable.markInitState(markable.isMarkedInitState());
                    activationStateMarkable.markActualActivationState(markable.isMarkedActualActivationState());
                    markable.markCommunicationState(false);
                    markable.markInitState(false);
                    markable.markActualActivationState(false);
                    LOGGER.debug("Filtering NE listing with: {}", activationStateMarkable.toStringOnlyMarkedAttributes());
                    filter.add(activationStateMarkable);
                }
            }
            return filter;
        }
        return Collections.emptyList();
    }

    private INE optionalEntityToBcb(@Nonnull Optional<NeEntity> ne) {
        if (ne.isPresent()) {
            final NeType neType = configuration.getNeTypes().get(ne.get().getInfo().getProxyType());
            if(null != neType) {
                final NeInfoData info = ne.get().getInfo();
                return ConvertNeToBcb.convert(neType, ne.get(), networkElementManagers.getNeInstanceRepository().queryAll(info.getNeId()));
            }
        }
        return null;
    }

    private boolean actualActivationStateMatches(@Nonnull INE input, @Nonnull List<INEMarkable> filter) {
        for (final INEMarkable markable : filter) {
            if (NEItem.matches(input, markable)) {
                return true;
            }
        }
        return filter.isEmpty();
    }

    @Override
    public INE createNE(ISessionContext sessionContext, String neProxyType, IEMId parentEmId, INEId parentNe,
                        IGenericContainerId genericContainerId, String neIdName, Property[] neProperties) throws BcbException {

        NeCreateDescriptor createDescriptor = neCreateDescriptor(neIdName, neProxyType, parentEmId.getId(),
                ConvertBcbPropertyToMap.convert(neProperties));

        BiFunction<BicnetCallContext, NeUserPreferencesData, Command<BicnetCallContext, Void>> assignmentCommand = (context, ne) ->
                new CreateSingleNeAssignment<>(context, containerRepository, systemRepository, ne, genericContainerId.getId(),
                        containerNotifications, loggerManager, settingsRepository);

        return createNE(sessionContext, createDescriptor, Optional.of(assignmentCommand));
    }

    @Override public void duplicate(ISessionContext sessionContext, INE template, Property[] neProperties)
            throws BcbException {
        NeCreateDescriptor createDescriptor = neCreateDescriptor(template.getIdName(), template.getNeProxyType(),
                template.getAssociatedEmId(), ConvertBcbPropertyToMap.convert(neProperties));

        createDescriptor.getPreferences().setContainerId(Optional.of(template.getAssociatedSystemContainerId()));

        try {
            new DuplicateNetworkElement<>(new BicnetCallContext(sessionContext),
                    networkElementManagers, channelRepository, systemRepository, channelInstanceRepository,
                    loggerManager, settingsRepository, containerRepository, containerNotifications, createDescriptor,
                    template.getId()).call();
        } catch (DcnManagerException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override public INE createNE(ISessionContext sessionContext, String neProxyType, IEMId parentEmId, INEId parentNe,
                                  ISystemContainerId systemContainerId, String neIdName, Property[] neProperties) throws BcbException {
        
        NeCreateDescriptor createDescriptor = neCreateDescriptor(neIdName, neProxyType, parentEmId.getId(),
                ConvertBcbPropertyToMap.convert(neProperties));
        createDescriptor.getPreferences()
                .setContainerId(Optional.of(systemContainerId.getId()));

        return createNE(sessionContext, createDescriptor, Optional.empty());
    }

    @Override
    public INE createNE(ISessionContext sessionContext, INE ne) throws BcbException {
        
        NeCreateDescriptor createDescriptor = neCreateDescriptor(ne.getIdName(), ne.getNeProxyType(), 
                ne.getAssociatedEmId(), emptyMap());
        createDescriptor.getPreferences()
                .setReconnectInterval(ne.getReconnectInterval())
                .setContainerId(ne.getAssociatedSystemContainerId() > 0
                        ? Optional.of(ne.getAssociatedSystemContainerId()) : Optional.empty());
        createDescriptor.getOperation()
                .setRealNeName(Optional.ofNullable(ne.getRealNeName()));

        BiFunction<BicnetCallContext, NeUserPreferencesData, Command<BicnetCallContext, Void>> assignmentCommand = (context, prefs) ->
                new CreateDefaultNeAssignment<>(context, containerRepository, systemRepository, prefs, containerNotifications, loggerManager, settingsRepository);

        return createNE(sessionContext, createDescriptor, Optional.of(assignmentCommand));
    }

    public INE createNE(ISessionContext sessionContext, String neProxyType, IEMId parentEmId,
                        String neIdName, Property[] neProperties) throws BcbException {
        
        NeCreateDescriptor createDescriptor = neCreateDescriptor(neIdName, neProxyType, parentEmId.getId(),
                ConvertBcbPropertyToMap.convert(neProperties));
        
        BiFunction<BicnetCallContext, NeUserPreferencesData, Command<BicnetCallContext, Void>> assignmentCommand = (context, ne) ->
                new CreateDefaultNeAssignment<>(context, containerRepository, systemRepository, ne, containerNotifications, loggerManager, settingsRepository);
        
        return createNE(sessionContext, createDescriptor, Optional.of(assignmentCommand));
    }

    private INE createNE(ISessionContext sessionContext, NeCreateDescriptor neCreateDescriptor,
            Optional<BiFunction<BicnetCallContext, NeUserPreferencesData, Command<BicnetCallContext, Void>>> assignmentCommand) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);

        try {
            final NeEntity neEntity = new CreateNetworkElement<>(context, networkElementManagers, channelRepository,
                    systemRepository, channelInstanceRepository, loggerManager, neCreateDescriptor).call();

            if (assignmentCommand.isPresent()) {
                assignmentCommand.get().apply(context, neEntity.getPreferences()).call();
            }

            return ConvertNeToBcb.convert(neCreateDescriptor.getType(), neEntity, Collections.emptyList()); // a new NE has inactive instances
        } catch (DcnManagerException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private NeCreateDescriptor neCreateDescriptor(String idName, String neType, int channelId,
                                                  Map<String, String> neProperties) throws BcbException {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(channelId, findNeType(neType));
        createDescriptor.getPreferences().setName(idName);
        
        final NeProperties properties = new NeProperties();
        final NeDirectRouteProperties routeProperties = new NeDirectRouteProperties();
        final NeOperationalProperties neOperationalProperties = new NeOperationalProperties();
        NePropertyUtils.applyDefaultProperties(createDescriptor, properties, routeProperties);
        applyProperties(neProperties, createDescriptor, properties, routeProperties);
        NePropertyUtils.applyAdditionalControlProperties(createDescriptor, neOperationalProperties, neProperties);
        
        return createDescriptor;
    }

    @Override
    public Collection<FullNeData> getFullNeList(ISessionContext sessionContext) throws BcbException {

        try {
            final GetAllNEs<BicnetCallContext> command = new GetAllNEs<>(new BicnetCallContext(sessionContext), neRepository);

            final Iterable<NeEntity> neEntities = command.call();

            final ImmutableSet<Integer> neIds = stream(neEntities.spliterator(), false)
                    .map(NeEntity::getInfo).map(NeInfoData::getNeId).collect(GuavaCollectors.toImmutableSet());

            final ImmutableMap<Integer, Iterable<NeGatewayRouteData>> neGateways =
                    networkElementManagers.getNeRepository().getNeGatewayRoutesRepository().queryRoutes(neIds);

            return toFullNes(stream(neEntities.spliterator(), false),
                    neId -> Optional.ofNullable(neGateways.get(neId)).orElse(ImmutableList.of()))
                    .collect(Collectors.toList());

        } catch (final CommandException | RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private Stream<FullNeData> toFullNes(Stream<NeEntity> nes,
                                         Function<Integer, Iterable<NeGatewayRouteData>> neGatewayRoutesProvider) {
        return nes
                .map(new AssociateNeWithTypeAndInstances(configuration,
                        neRepository.getNeSyncStateRepository(),
                        networkElementManagers.getNeInstanceRepository(),
                        neGatewayRoutesProvider))
                .map(new ConvertNeToFullNe())
                .filter(Objects::nonNull);
    }

    @Override public FullNeData getFullNe(ISessionContext sessionContext, Integer neId) throws BcbException {
        final GetNe<BicnetCallContext> getNe = new GetNe<>(new BicnetCallContext(sessionContext), neRepository, neId);
        try {
            Optional<NeEntity> neOpt = getNe.call();

            final Function<Integer, Iterable<NeGatewayRouteData>> neGatewayRoutesProvider = neIdTmp -> {
                Iterable<NeGatewayRouteData> result = ImmutableList.of();
                try {
                    result = networkElementManagers.getNeRepository().getNeGatewayRoutesRepository()
                            .queryRoutes(neIdTmp);
                } catch (RepositoryException e) {
                    LOGGER.error("Error loading gateway Routes", e);
                }
                return result;
            };

            return toFullNes(neOpt.isPresent() ? Stream.of(neOpt.get()) : Stream.empty(), neGatewayRoutesProvider)
                    .findAny().orElse(null);
        } catch (CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public NEReply getNEList(ISessionContext sessionContext, INEId startAfter, INEMarkable[] filter, int howMany) throws BcbException {
        final List<INEMarkable> activationStateFilter = consumeActivationStateFilters(filter);
        final QNeEntityDb ne = QNeEntityDb.neEntityDb;
        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, ne);
             final CloseableIterator<NeEntityDb> queryIterator = query.iterate(ne)) {
            Iterator<INE> ineIterator =
                    Iterators.filter(
                    Iterators.transform(queryIterator, compose(this::optionalEntityToBcb, neRepository.getEntityTransformer())),
                    and(notNull(), ine -> actualActivationStateMatches(ine, activationStateFilter)));
            if (howMany > -1) {
                ineIterator = limit(ineIterator, howMany);
            }
            final INE[] ineArray = Iterators.toArray(ineIterator, INE.class);
            final boolean isEof = !queryIterator.hasNext();
            return new NEReply(ineArray, isEof, isEof ? null : ineArray[ineArray.length - 1].getNEId());
        } catch (final PersistenceException | UnsupportedQueryParametersException | RepositoryException exception) {
            throw logAndRethrowAsBcb(exception, LOGGER);
        }
    }

    @Override
    public NEReply getNEList(ISessionContext sessionContext, INEId startAfter, INEMarkable[] filter, int howMany,
                             final NeCapability capability) throws BcbException {
        final INEMarkable[] markables = Stream.of(filter)
                .map(markable -> {
                    markable.setCapabilities(NeCapabilities.of(capability));
                    return markable;
                }).toArray(INEMarkable[]::new);

        return getNEList(sessionContext, startAfter, markables, howMany);
    }

    @Override
    public NEIdReply getNEIdList(ISessionContext sessionContext, INEId startAfter, INEMarkable[] filter, int howMany) throws BcbException {
        final QNeEntityDb ne = QNeEntityDb.neEntityDb;
        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, ne);
             final CloseableIterator<Integer> queryIterator = query.iterate(ne.info.neId)) {
            Iterator<INEId> ineIdIterator = Iterators.transform(queryIterator, NEIdItem::new);
            if (howMany > -1) {
                ineIdIterator = limit(ineIdIterator, howMany);
            }
            final INEId[] ineIdArray = Iterators.toArray(ineIdIterator, INEId.class);
            final boolean isEof = !queryIterator.hasNext();
            return new NEIdReply(ineIdArray, isEof, isEof ? null : ineIdArray[ineIdArray.length - 1]);
        } catch (final PersistenceException | UnsupportedQueryParametersException | RepositoryException exception) {
            throw logAndRethrowAsBcb(exception, LOGGER);
        }
    }

    @Override
    public INEId[] getActivatedNEs(ISessionContext sessionContext, INEId[] neIds) throws BcbException {
        if (null == neIds || neIds.length == 0) {
            return new INEId[0];
        }
        final Set<Integer> neIdSet = Stream.of(neIds)
                .map(INEId::getId)
                .collect(Collectors.toSet());
        try {
            Iterable<NeConnectionData> connectionData = neRepository.getNeConnectionRepository().queryAll();
            return stream(connectionData.spliterator(), false)
                    .filter(data -> null != data && data.isActive() && neIdSet.contains(data.getId()))
                    .map(input -> new NEIdItem(input.getId()))
                    .toArray(INEId[]::new);
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public NeGneCost[] getCostToGneMap(ISessionContext sessionContext) throws BcbException {

        try {
            return new NeGneCostCalculator(neRepository).calculateCostToGneMap();
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }
    
    @Override
    public NeGneCost getCostToGne(ISessionContext sessionContext, INEId neId) throws BcbException {
        try {
            return new NeGneCostCalculator(neRepository).calculateCostToGne(neId);
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public INEMarkable modifyNE(ISessionContext sessionContext, INEMarkable ne) throws BcbException {
        throw new UnsupportedOperationException();
    }

    @Override
    public INEMarkable[] modifyNEs(ISessionContext sessionContext, INEMarkable[] nes) throws BcbException {
        throw new UnsupportedOperationException();
    }

    private void applyProperties(Map<String, String> map, NeCreateDescriptor createDescriptor,
            NeProperties properties, NeDirectRouteProperties routeProperties) throws BcbException {
        final NeType neType = createDescriptor.getType();
        try {
            // Order is important. We allow Route properties to depend on NE properties so the latter must be set first.
            properties.setProperties(neType, createDescriptor.getPreferences(), map);
            routeProperties.set(neType, createDescriptor, createDescriptor.getPreferences(), map);
            createDescriptor.putGatewayRoutes(new NeGatewayRouteProperties(neType).parseProperties(map, createDescriptor));

        } catch (final InvalidMutationException e) {
            throw new BcbException("Failed to apply property to a new NE.", e);
        }
    }

    private NeType findNeType(String typeName) throws BcbException {
        final NeType neType = configuration.getNeTypes().get(typeName);
        if (null == neType) {
            throw new BcbException("Unknown NE Type: " + typeName);
        }
        return neType;
    }

    @Override
    public void deleteNE(ISessionContext sessionContext, INEId neId) throws BcbException {
        deleteNEs(sessionContext, ImmutableList.of(neId));
    }

    @Override
    public void activateNEs(ISessionContext sessionContext, INEId[] nes) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        for (final INEId neId : nes) {
            try {
                new NetworkElementActivationRequired<>(context, neId.getId(),
                        networkElementManagers, channelRepository, channelInstanceRepository, loggerManager)
                    .call();
            } catch (final RepositoryException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            } catch (final DcnManagerException e) {
                LOGGER.error("Failed to activate NE {}: {}", neId, getStackTraceAsString(e));
            }
        }
    }

    @Override
    public void deactivateNEs(ISessionContext sessionContext, INEId[] nes) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        for (final INEId neId : nes) {
            try {
                new NetworkElementDeactivationRequired<>(context, neId.getId(),
                        networkElementManagers, channelInstanceRepository, loggerManager)
                    .call();
            } catch (final RepositoryException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            } catch (final DcnManagerException e) {
                LOGGER.error("Failed to deactivate NE {}: {}", neId, getStackTraceAsString(e));
            }
        }
    }

    @Override
    public void updateProperties(ISessionContext sessionContext, INEId neId, Map<String, String> properties) throws BcbException {
        try {
            new UpdateNeProperties<>(new BicnetCallContext(sessionContext),
                    networkElementManagers, systemRepository, configuration, loggerManager, connectionManager,
                    new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository),
                    new NePropertiesChangedEvent(neId.getId(), ImmutableMap.copyOf(properties)))
                .call();
        } catch (final DcnManagerException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public Map<String, String> getProperties(
            @Nonnull ISessionContext context, @Nonnull INEId neId) throws BcbException {
        try {
            final Optional<NeEntity> ne = neRepository.queryNe(neId.getId());

            if (ne.isPresent()) {
                final NeEntity neEntity = ne.get();
                final NeType type = configuration.getNeTypes().get(neEntity.getInfo().getProxyType());
                if (null != type) {
                    final Iterable<NeGatewayRouteData> routes = neRepository.getNeGatewayRoutesRepository().queryRoutes(neId.getId());
                    final HashMap<String, String> propertyMapping = new HashMap<>();
                    propertyMapping.putAll(new NeProperties().getProperties(type, neEntity));
                    propertyMapping.putAll(new NeGatewayRouteProperties(type).toProperties(neEntity, routes));
                    propertyMapping.putAll(BicnetStandbyProperties.getProperties(context, scs));
                    return propertyMapping;
                }
            }

            return emptyMap();
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public String[] getSupportedNeTypes(
            @Nonnull ISessionContext sessionContext, @Nonnull String emType) throws BcbException {
        try {
            final Iterable<String> names =
                    new GetSupportedNeTypeNames<>(new BicnetCallContext(sessionContext), emType, configuration)
                            .call();
            return toArray(names, String.class);
        } catch (final CommandException e) {
            throw new BcbException("Unknown channel type.", e);
        }
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>Attempts to trigger resynchronization operations on a collection of network elements.</p>
     * <p>
     * <p>Network elements must be active, i.e., initialized, in order to request a new synchronization (initialization).</p>
     * <p>
     * <p>Successes and most errors are audited in the Command Log for each NE.</p>
     */
    @Override
    public void resynchronizeNEs(ISessionContext sessionContext, INEId[] neIds) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        try {
            new ResynchronizeNetworkElements<>(context, networkElementManagers, channelInstanceRepository, loggerManager,
                    transform(ImmutableList.copyOf(neIds), new ConvertBcbNeIdToInteger()))
                    .call();
        } catch (final DcnManagerException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void deleteNEs(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        for (final INEId neId : neIds) {
            try {
                new DeleteNetworkElement<>(context, networkElementManagers, domainRepository, domainNotifications, settingsRepository,
                        loggerManager, neId.getId()).call();
            } catch (final RepositoryException | IllegalNetworkElementStateException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }
        }
    }

    @Override
    public void copyNetworkNamesToNeNames(ISessionContext sessionContext, Collection<INEId> neIds)
            throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        try {
            new CopyNetworkNameToNeName<>(context, networkElementManagers, connectionManager, neRepository, notifications, loggerManager,                    
                    transform(neIds, new ConvertBcbNeIdToInteger()))
                    .call();
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void moveNesToAnotherChannel(ISessionContext sessionContext, Collection<INEId> neIds, IEMId targetChannelId)
            throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        try {
            new MoveNetworkElementsToAnotherChannel<>(context, networkElementManagers,
                    channelRepository, channelInstanceRepository, loggerManager,
                    transform(neIds, new ConvertBcbNeIdToInteger()), targetChannelId.getId())
                    .call();
        } catch (UnknownChannelIdException | RepositoryException | CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void setToActiveStateMode(ISessionContext sessionContext, INEId neId) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        try {
            new SetToActiveStateMode<>(context, accessControlManager, neRepository, loggerManager, neId.getId()).call();
        } catch (final RepositoryException | CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void setToMaintenanceMode(ISessionContext sessionContext, INEId neId) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        try {
            new SetToMaintenanceMode<>(context, accessControlManager, neRepository, loggerManager, neId.getId()).call();
        } catch (final RepositoryException | CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void setToOperationalMode(ISessionContext sessionContext, INEId neId) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        try {
            new SetToOperationalMode<>(context, accessControlManager, neRepository, loggerManager, neId.getId()).call();
        } catch (final RepositoryException | CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void writeAccessRelease(ISessionContext sessionContext, INEId neId) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        try {
            new WriteAccessRelease<>(context, accessControlManager, neRepository, loggerManager, neId.getId()).call();
        } catch (final RepositoryException | CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void writeAccessRequest(ISessionContext sessionContext, INEId neId) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        try {
            new WriteAccessRequest<>(context, accessControlManager, neRepository, loggerManager, neId.getId()).call();
        } catch (final RepositoryException | CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void writeAccessEnforce(ISessionContext sessionContext, INEId neId) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        try {
            new WriteAccessEnforce<>(context, accessControlManager, neRepository, loggerManager, neId.getId()).call();
        } catch (final RepositoryException | CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public Iterable<ScsSynchronizationState> getScsSynchronizationStates() {
        return neRepository.getNeSyncStateRepository().queryAll();
    }

    @Override
    public void changeSystemContainerId(ISessionContext sessionContext, Map<INEId, ISystemContainerId> associations) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        try {
            final Map<Integer, Optional<Integer>> idAssociations = Maps.transformValues(
                    FluentIterable.from(associations.entrySet())
                            .transform(input -> {
                                final ISystemContainerId value = input.getValue();
                                return Maps.immutableEntry(
                                        input.getKey().getId(),
                                        value != null && value.getId() > 0 ? Optional.of(value.getId()) : Optional.<Integer>empty()
                                );
                            })
                            .uniqueIndex(Entry::getKey),
                    Entry::getValue);
            new ChangeNeSystem<>(context, neRepository, notifications, loggerManager, idAssociations).call();
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }
    
    /**
     * Activates a collection of NEs on hot standby mode
     * 
     * @param sessionContext
     * @param neIds
     * @throws BcbException
     */
    @Override public void activateNesOnStandbyMediation(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        for (final INEId neId : neIds) {
            try {
            	
            	new ActivateNeOnStandby<>(context, neId.getId(),
                        networkElementManagers,
                        channelManagers,
            			loggerManager,
            			settingsRepository)
            	.call();
            } catch (final DcnManagerException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }
        }
    }

    /**
     * Deactivates a collection of NEs on hot standby mode
     * 
     * @param sessionContext
     * @param neIds
     * @throws BcbException
     */
    @Override public void deactivateNesOnStandbyMediation(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException {
    	final BicnetCallContext context = new BicnetCallContext(sessionContext);
        for (final INEId neId : neIds) {
            try {
            	
            	new DeactivateNeOnStandby<>(context, neId.getId(),
                        networkElementManagers,
                        channelManagers,
            			loggerManager)
            	.call();
            } catch (final DcnManagerException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }
        }
    }

    /**
     * Performs a resynch operations on a collection of NEs on hot standby mode
     * 
     * @param sessionContext
     * @param neIds
     * @throws BcbException
     */
    @Override public void resynchronizeNesOnStandbyMediation(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException {
    	final BicnetCallContext context = new BicnetCallContext(sessionContext);
        for (final INEId neId : neIds) {
            try {
            	
            	new ResynchronizeNeOnStandby<>(context, neId.getId(),
                        networkElementManagers,
                        channelManagers,
            			loggerManager)
            	.call();
            } catch (final DcnManagerException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }
        }
    }

    @Override
    public void moveToContainers(ISessionContext sessionContext, Collection<INEId> neIds, Collection<IGenericContainerId> containers, IGenericContainerId primaryContainer) throws BcbException {
        try {
            Collection<IGenericContainerId> allContainers = ImmutableSet.<IGenericContainerId>builder()
                    .add(primaryContainer)
                    .addAll(containers).build();
            new MoveNesToContainer<>(new BicnetCallContext(sessionContext), neIds, allContainers, primaryContainer,
                    containerRepository, systemRepository, neRepository, containerNotifications, loggerManager, notifications, settingsRepository).call();
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void moveToSystem(ISessionContext sessionContext, Collection<INEId> neIds, ISystemContainerId systemId) throws BcbException {
        try {
            new MoveNesToSystem<>(new BicnetCallContext(sessionContext), neIds, systemId, 
                    containerRepository, systemRepository, neRepository, containerNotifications, loggerManager, notifications, settingsRepository).call();
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void moveToDefaultContainer(ISessionContext sessionContext, Collection<INEId> neIds) throws BcbException {
        try {
            new MoveNesToDefaultContainer<>(new BicnetCallContext(sessionContext), neIds, containerRepository, systemRepository,
                    neRepository, containerNotifications, loggerManager, notifications, settingsRepository).call();
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }
}
