package com.ossnms.dcn_manager.bicnet.events;

import com.ossnms.bicnet.bcb.facade.scs.IScsFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.composables.outbound.SharedResources;
import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;
import rx.functions.Action1;

import javax.annotation.Nonnull;

/**
 * <p>Dispatches EM/NE events within the BiCNet Connector layer only.</p>
 *
 * <p>Some events have behavior that is tightly coupled with the BiCNet architecture and
 * TNMS components. Therefore it does not make sense to propagate such dependencies to
 * the EM/NE core.</p>
 */
public class BiCNetOutgoingEventDispatcher {

    private static final Logger LOGGER = LoggerFactory.getLogger(BiCNetOutgoingEventDispatcher.class);

    private final NeEntityRepository neRepository;
    private final IScsFacade scs;
    private final ISessionContext systemContext;
    private final SharedResources<BicnetCallContext> sharedResources;

    /**
     * Creates a new instance.
     *
     * @param neRepository Network Element entity repository.
     * @param scs BiCNet SCS facade.
     * @param sharedResources Shared Resource management.
     * @param systemContext BiCNet system authentication context.
     */
    public BiCNetOutgoingEventDispatcher(
            @Nonnull NeEntityRepository neRepository,
            @Nonnull IScsFacade scs,
            @Nonnull SharedResources<BicnetCallContext> sharedResources,
            @Nonnull ISessionContext systemContext) {
        this.neRepository = neRepository;
        this.scs = scs;
        this.sharedResources = sharedResources;
        this.systemContext = systemContext;
    }

    /**
     * Initializes dispatching of events emitted by a number of event sources.
     *
     * @param eventSources Event sources as instances of {@link Observable}.
     */
    public final void initialize(Iterable<Observable<? extends Event>> eventSources) {

        // subscribe to relevant Channel and NE events from all sources
        for (final Observable<? extends Event> source : eventSources) {
            source
                .ofType(NeInitializedEvent.class)
                .filter(this::isInternalEventFromActiveInstance)
                .subscribe(new AcquireAndRequestNeSyncOnInitialization(neRepository, scs, sharedResources, systemContext));

            source
                .ofType(NeDisconnectedEvent.class)
                .filter(this::isInternalEventFromActiveInstance)
                .subscribe(new ReleaseNeOnDisconnection());

            source
                .ofType(ActualChannelStateEvent.ChannelDeactivatedEvent.class)
                .filter(this::isEventFromActiveInstance)
                .subscribe(new ReleaseChannelOnDisconnection());
        }

    }

    private boolean isInternalEventFromActiveInstance(ActualNeStateEvent event) {
        return !event.getOriginatingPhysicalEvent().isPresent();
    }

    private boolean isEventFromActiveInstance(ActualChannelStateEvent event) {
        return !event.getOriginatingPhysicalEvent().isPresent();
    }

    /**
     * Upon a successful Channel disconnection, releases all NE shared resources managed by EM/NE.
     */
    private final class ReleaseChannelOnDisconnection implements Action1<ActualChannelStateEvent.ChannelDeactivatedEvent> {
        @Override
        public void call(@Nonnull ActualChannelStateEvent.ChannelDeactivatedEvent event) {
            LOGGER.info("Locking Channel {} for usage on Connection Manager (release).", event.getChannelId());
            sharedResources.releaseChannelResources(new BicnetCallContext(systemContext), event.getChannelId());
        }
    }

    /**
     * Upon a successful NE disconnection, releases all NE shared resources managed by EM/NE.
     */
    private final class ReleaseNeOnDisconnection implements Action1<NeDisconnectedEvent> {
        @Override
        public void call(@Nonnull NeDisconnectedEvent event) {
            LOGGER.info("Locking NE {} for usage on Connection Manager (release).", event.getNeId());
            sharedResources.releaseNeResources(new BicnetCallContext(systemContext), event.getNeId());
        }
    }
}
