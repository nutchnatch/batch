package com.ossnms.dcn_manager.bicnet.connector.converter;

import javax.annotation.Nonnull;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;

/**
 * Converts {@link MessageSeverity} to BCB {@link LogSeverity} 
 */
public final class ConvertSeverityToBcb implements Function<MessageSeverity, LogSeverity>{

    public static LogSeverity convertSeverity(@Nonnull MessageSeverity input) {
        return LogSeverity.fromName(input.getName());
    }
    
    /**
     * @see Function#apply(Object)
     */
    @Override
    @Nonnull
    public LogSeverity apply(@Nonnull MessageSeverity input) {
        return convertSeverity(input);
    }
}
