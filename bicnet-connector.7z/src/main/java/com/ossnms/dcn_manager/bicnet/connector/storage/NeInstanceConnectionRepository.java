package com.ossnms.dcn_manager.bicnet.connector.storage;

import javax.enterprise.context.ApplicationScoped;

import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.connector.storage.ne.InMemoryNePhysicalConnectionRepository;

/**
 * <p>EJB that maintains an instance of a Physical NE Connections repository.</p>
 */
@DcnManager
@ApplicationScoped
public class NeInstanceConnectionRepository
        extends InMemoryNePhysicalConnectionRepository {

}
