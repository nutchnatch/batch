package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.mysema.query.BooleanBuilder;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.INeGenericContainerAssignmentFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentMarkable;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeAssignmentDataToBcb;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.commands.container.assignment.AddNeAssignment;
import com.ossnms.dcn_manager.commands.container.assignment.DeleteNeAssignment;
import com.ossnms.dcn_manager.commands.container.assignment.UpdateNeAssignment;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.container.entities.QContainerNeAssignmentDb;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.utils.Optionals;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import javax.persistence.PersistenceException;
import java.util.Optional;
import java.util.stream.Stream;

import static com.google.common.base.Functions.compose;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.Arrays.asList;

/**
 * NE assignments Public services.
 */
public class NeContainerAssignmentHelper implements INeGenericContainerAssignmentFacade {
    private static final Logger LOGGER = LoggerFactory.getLogger(NeContainerAssignmentHelper.class);

    private JpaContainerRepositoryBean containerRepository;
    private JpaSystemRepositoryBean systemRepository;
    private JpaSettingsRepositoryBean settingsRepository;
    private JpaNetworkElementRepositoryBean neRepository;
    private ContainerNotifications notifications;
    private LoggerManagerImpl loggerManager;
    private NeHelper neHelper;

    /** Settings Repository injection point. */
    @Inject
    public void setSettingsRepository(@DcnManager JpaSettingsRepositoryBean settingsRepository) {
        this.settingsRepository = settingsRepository;
    }

    /** System Repository injection point. */
    @Inject public void setSystemRepository(@DcnManager JpaSystemRepositoryBean systemRepository) {
        this.systemRepository = systemRepository;
    }

    /** NE Repository injection point. */
    @Inject public void setNeRepository(@DcnManager JpaNetworkElementRepositoryBean neRepository) {
        this.neRepository = neRepository;
    }

    /** Container Notifications Manager injection point. */
    @Inject public void setNotifications(ContainerNotifications notifications) {
        this.notifications = notifications;
    }

    /** Logger Manager injection point. */
    @Inject public void setLoggerManager(LoggerManagerImpl loggerManager) {
        this.loggerManager = loggerManager;
    }

    @Inject public void setContainerRepository(@DcnManager JpaContainerRepositoryBean containerRepository) {
        this.containerRepository = containerRepository;
    }

    @Inject public void setNeHelper(NeHelper neHelper) {
        this.neHelper = neHelper;
    }

    @Override public INeGenericContainerAssignment getSingleNeGenericContainerAssignment(
            @Nonnull final ISessionContext sessionContext,
            @Nonnull final INeGenericContainerAssignmentId neContainerAssignId) throws BcbException {
        try {
            final Optional<NeAssignmentData> neAssignment = containerRepository
                    .queryNeAssignment(neContainerAssignId.getNetworkElementId(), neContainerAssignId.getGenericContainerId());

            return neAssignment.map(new ConvertNeAssignmentDataToBcb()::apply).orElse(null);
        } catch (RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override public NeGenericContainerAssignmentReply getNeGenericContainerAssignmentList(
            ISessionContext sessionContext, INeGenericContainerAssignmentId startAfter,
            INeGenericContainerAssignmentMarkable[] filter, int howMany) throws BcbException {

        final QContainerNeAssignmentDb neAssignmentDb = QContainerNeAssignmentDb.containerNeAssignmentDb;

        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, neAssignmentDb)) {

            final INeGenericContainerAssignment[] neAssignments = query.list(neAssignmentDb).stream()
                    .map(containerRepository.getNeAssignmentTransformer()::apply)
                    .filter(Optionals.isPresent()::apply)
                    .map(compose(new ConvertNeAssignmentDataToBcb(), Optionals.dereference())::apply)
                    .toArray(INeGenericContainerAssignment[]::new);

            return new NeGenericContainerAssignmentReply(neAssignments, true, null);
        } catch (final PersistenceException | RepositoryException e) {
            throw new BcbException("Error listing NE container Assignments.", e);
        }
    }

    @Override public NeGenericContainerAssignmentIdReply getNeGenericContainerAssignmentIdList(
            ISessionContext sessionContext, INeGenericContainerAssignmentId startAfter,
            INeGenericContainerAssignmentMarkable[] filter, int howMany) throws BcbException {

        final QContainerNeAssignmentDb neAssignmentDb = QContainerNeAssignmentDb.containerNeAssignmentDb;

        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, neAssignmentDb)) {
            final INeGenericContainerAssignmentId[] neAssignments = query.list(neAssignmentDb).stream()
                    .map(containerRepository.getNeAssignmentTransformer()::apply)
                    .filter(Optionals.isPresent()::apply)
                    .map(compose(new ConvertNeAssignmentDataToBcb(), Optionals.dereference())::apply)
                    .map(INeGenericContainerAssignment::getNeGenericContainerAssignmentId)
                    .toArray(INeGenericContainerAssignmentId[]::new);

            return new NeGenericContainerAssignmentIdReply(neAssignments, true, null);
        } catch (final PersistenceException | RepositoryException e) {
            throw new BcbException("Error listing NE container Assignments IDs.", e);
        }
    }

    @Override public INeGenericContainerAssignment createNeGenericContainerAssignment(ISessionContext sessionContext,
            INeGenericContainerAssignment assignment) throws BcbException {
        try {
            final NeUserPreferencesData neUserPreferences = getNeUserPreferencesData(assignment.getNetworkElement());
            final ContainerInfo containerInfo = getContainerInfo(assignment.getGenericContainer());

            final NeAssignmentData neAssignmentData = new NeAssignmentData(containerInfo,
                    assignment.getNetworkElementId(), AssignmentType.fromFlag(assignment.getPrimary()));

            new AddNeAssignment<>(new BicnetCallContext(sessionContext), containerRepository, notifications, loggerManager,
                    neUserPreferences, neAssignmentData).call();
        } catch (final CommandException | RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }

        return assignment;
    }

    @Override public void deleteNeGenericContainerAssignment(ISessionContext sessionContext,
            INeGenericContainerAssignmentId assignId) throws BcbException {
        try {
            final NeAssignmentData neAssignment = getNeAssignment(assignId);
            final NeUserPreferencesData neUserPreferencesData = getNeUserPreferencesData(assignId.getNetworkElement());

            new DeleteNeAssignment<>(new BicnetCallContext(sessionContext), containerRepository, systemRepository, notifications,
                    loggerManager, neUserPreferencesData, neAssignment, settingsRepository).call();

        } catch (final CommandException | RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override public INeGenericContainerAssignmentMarkable modifyNeGenericContainerAssignment(
            ISessionContext sessionContext, INeGenericContainerAssignmentMarkable assignment)
            throws BcbException {
         final INeGenericContainerAssignmentMarkable[] markables = modifyNeGenericContainerAssignments(
                sessionContext, new INeGenericContainerAssignmentMarkable[] { assignment });

        return Stream.of(markables).findFirst().orElse(null);
    }

    @Override public INeGenericContainerAssignmentMarkable[] modifyNeGenericContainerAssignments(
            ISessionContext sessionContext, INeGenericContainerAssignmentMarkable[] neContainerAssigns)
            throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);

        return Stream.of(neContainerAssigns)
                .map(assignment -> {
                    try {
                        final NeUserPreferencesData neUserPreferencesData = getNeUserPreferencesData(
                                assignment.getNetworkElement());
                        final ContainerInfo containerInfo = getContainerInfo(assignment.getGenericContainer());

                        final NeAssignmentData systemAssignmentData = new NeAssignmentData(containerInfo,
                                assignment.getNetworkElementId(), AssignmentType.fromFlag(assignment.getPrimary()));

                        new UpdateNeAssignment<>(context, containerRepository, notifications, loggerManager,
                                neUserPreferencesData, systemAssignmentData).call();

                        return Optional.of(systemAssignmentData);
                    } catch (final CommandException | RepositoryException e) {
                        LOGGER.error("Error to update NE assignment=" + assignment, e);
                        return Optional.<NeAssignmentData>empty();
                    }})
                .filter(Optional::isPresent).map(Optional::get)
                .map(ConvertNeAssignmentDataToBcb::convert)
                .map(input -> input.toMarkableNeGenericContainerAssignment(false))
                .toArray(INeGenericContainerAssignmentMarkable[]::new);
    }

    @Override
    public void assignNe(ISessionContext sessionContext, INEId neId, IGenericContainerId primaryContainer, IGenericContainerId[] secondaryContainers) throws BcbException {
        neHelper.moveToContainers(sessionContext, asList(neId), asList(secondaryContainers), primaryContainer);
    }

    private JpaCloseableQuery buildQueryExpression(INeGenericContainerAssignmentId startAfter, INeGenericContainerAssignmentMarkable[] filter,
            int howMany, final QContainerNeAssignmentDb neAssignmentDb) throws RepositoryException {
        final JpaCloseableQuery query = containerRepository.query(neAssignmentDb);
        final BooleanBuilder predicateBuilder = new BooleanBuilder();
        if (filter != null) {
            final BooleanBuilder filterBuilder = new BooleanBuilder();
            for (final INeGenericContainerAssignmentMarkable markable : filter) {
                LOGGER.debug("Filtering Ne Container Assignment listing with: {}", markable.toStringOnlyMarkedAttributes());
                final BooleanBuilder markablePredicateBuilder = new BooleanBuilder();
                if (markable.isMarkedGenericContainerId()) {
                    markablePredicateBuilder.and(neAssignmentDb.containerNeKey.containerInfo.containerId.eq(markable.getGenericContainerId()));
                    markable.markGenericContainerId(false);
                }
                if (markable.isMarkedNetworkElementId()) {
                    markablePredicateBuilder.and(neAssignmentDb.containerNeKey.neId.eq(markable.getNetworkElementId()));
                    markable.markNetworkElementId(false);
                }
                if (markable.isMarkedPrimary()) {
                    markablePredicateBuilder.and(neAssignmentDb.assignmentType.eq(AssignmentType.fromFlag(markable.getPrimary())));
                    markable.markPrimary(false);
                }
                if (markable.countMarks() > 0) {
                    throw new RepositoryException("Unsupported query parameters: {}", markable.toStringOnlyMarkedAttributes());
                }
                filterBuilder.or(markablePredicateBuilder);
            }
            if (filterBuilder.hasValue()) {
                predicateBuilder.and(filterBuilder);
            }
        }
        if (startAfter != null) {
            predicateBuilder.and(neAssignmentDb.containerNeKey.neId.gt(startAfter.getNetworkElementId()));
            predicateBuilder.and(neAssignmentDb.containerNeKey.containerInfo.containerId.gt(startAfter.getGenericContainerId()));
        }
        if (predicateBuilder.hasValue()) {
            query.where(predicateBuilder);
        }
        if (howMany > -1) {
            query.limit(howMany);
        }
        query.orderBy(neAssignmentDb.containerNeKey.containerInfo.containerId.asc());
        return query;
    }

    private NeUserPreferencesData getNeUserPreferencesData(INEId neId)
            throws RepositoryException {
        final Optional<NeUserPreferencesData> neUserPreferences = neRepository.getNeUserPreferencesRepository()
                .query(neId.getId());
        if (!neUserPreferences.isPresent()) {
            throw new RepositoryException("NE not found, id=" + neId);
        }
        return neUserPreferences.get();
    }

    private ContainerInfo getContainerInfo(IGenericContainerId containerId)
            throws RepositoryException {
        final Optional<ContainerInfo> containerInfo = containerRepository.query(containerId.getId());
        if (!containerInfo.isPresent()) {
            throw new RepositoryException("Container not found, id=" + containerId);
        }
        return containerInfo.get();
    }

    private NeAssignmentData getNeAssignment(INeGenericContainerAssignmentId assignmentId)
            throws RepositoryException {
        final Optional<NeAssignmentData> assignmentData = containerRepository
                .queryNeAssignment(assignmentId.getNetworkElementId(), assignmentId.getGenericContainerId());

        if (!assignmentData.isPresent()) {
            throw new RepositoryException("NE Assignment not found, id=" + assignmentId);
        }
        return assignmentData.get();
    }
}
