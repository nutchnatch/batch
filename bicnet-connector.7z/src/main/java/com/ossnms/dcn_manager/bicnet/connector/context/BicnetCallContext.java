package com.ossnms.dcn_manager.bicnet.connector.context;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.dcn_manager.composables.context.CallContext;

public class BicnetCallContext implements CallContext {

    private final ISessionContext sessionContext;

    public BicnetCallContext(ISessionContext sessionContext) {
        this.sessionContext = sessionContext;
    }

    public ISessionContext getSessionContext() {
        return sessionContext;
    }

}
