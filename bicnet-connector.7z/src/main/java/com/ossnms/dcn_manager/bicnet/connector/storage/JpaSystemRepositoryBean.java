package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.google.common.base.Function;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.container.SystemContainerRepository;
import com.ossnms.dcn_manager.connector.storage.container.entities.QSystemInfoDb;
import com.ossnms.dcn_manager.connector.storage.container.entities.SystemInfoDb;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Optional;

/**
 * EJB that maintains an instance of a System Container repository.
 */
@DcnManager
@ApplicationScoped
public class JpaSystemRepositoryBean extends SystemContainerRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(JpaSystemRepositoryBean.class);

    @Inject
    private JpaRepositoryBean repositoryBean;

    @Override
    protected CloseableEntityTransaction getTransaction() {
        return repositoryBean.getTransactionSupplier().get();
    }

    public JpaCloseableQuery query(QSystemInfoDb path) {
        return new JpaCloseableQuery(repositoryBean.getManagerSupplier().get(), path);
    }

    public Function<SystemInfoDb, Optional<SystemInfo>> getEntityTransformer() {
        return entityTransformer;
    }

    private final Function<SystemInfoDb, Optional<SystemInfo>> entityTransformer = input -> {
        try {
            return null != input ? fetchEntity(input) : Optional.empty();
        } catch (final RepositoryException e) {
            LOGGER.error("Error listing System Container entities.", e);
            return Optional.empty();
        }
    };

}
