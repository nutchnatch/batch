package com.ossnms.dcn_manager.bicnet.connector.messaging.ne;

import rx.functions.Func1;

import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxyMarkable;

final class ConnectionStateIs
        implements Func1<INetworkElementProxyMarkable, Boolean> {
    private final CommunicationState communicationState;

    public ConnectionStateIs(CommunicationState state) {
        this.communicationState = state;
    }

    @Override
    public Boolean call(INetworkElementProxyMarkable m) {
        return m.isMarkedCommunicationState() && communicationState == m.getCommunicationState();
    }
}