package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import javax.enterprise.context.ApplicationScoped;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkSettingsItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkSettingsMarkable;
import com.ossnms.dcn_manager.core.events.settings.GlobalSettingsEvent;
import com.ossnms.dcn_manager.core.events.settings.NativeNeNamingSettingChangeEvent;
import com.ossnms.dcn_manager.core.outbound.GlobalSettingsNotifications;

/**
 * Implements the bridge between our core and the BiCNet notifications service.
 * Handles only notifications about changes to EM/NE settings.
 */
@ApplicationScoped
public class GlobalSettingsNotificationsManagerImpl extends
        NotificationsManagerBase<GlobalSettingsEvent> implements GlobalSettingsNotifications {

    @Override
    public void notifyChanges(NativeNeNamingSettingChangeEvent event) {
        final INetworkSettingsMarkable markable = NetworkSettingsItem.markableNetworkSettings(null);
        markable.setShowNativeNeNaming(event.getShowNativeNeNaming());
        sendAttributeValueChangeNotification(markable);
    }

}
