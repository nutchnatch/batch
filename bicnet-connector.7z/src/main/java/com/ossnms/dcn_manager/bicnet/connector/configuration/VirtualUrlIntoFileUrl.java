package com.ossnms.dcn_manager.bicnet.connector.configuration;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Function;

/**
 * JBoss uses a sort of "virtual file system". Hence we need to attempt to decode
 * and convert its "vfs" URLs into "file" URLs that can be scanned in a manner that
 * is container independent.
 */
final class VirtualUrlIntoFileUrl implements Function<URL, URL> {

    private static final Logger LOGGER = LoggerFactory.getLogger(VirtualUrlIntoFileUrl.class);

    private final Pattern vfsPattern = Pattern.compile("(vfszip:|vfsfile:|vfs:)");
    private final Pattern jarSlashPattern = Pattern.compile("\\.jar/");

    @Override
    public URL apply(URL input) {
        URL output = input;
        if (null != input) {
            final String inputURL = input.toString();
            String cleanURL = vfsPattern.matcher(inputURL).replaceFirst("file:");
            cleanURL = jarSlashPattern.matcher(cleanURL).replaceFirst(".jar!/");
            try {
                output = new URL(cleanURL);
            } catch (final MalformedURLException ex) {
                // Shouldn't happen, but we can't do anything else to transform this URL.
                LOGGER.warn("Transformation of {} resulted in invalid URL {} : {}.", inputURL, cleanURL, ex.getMessage());
            }
        }
        return output;
    }
}