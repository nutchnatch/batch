package com.ossnms.dcn_manager.bicnet.connector.messaging.discovery;

import com.ossnms.bicnet.bcb.model.EnumOrdinalBase;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.elementMgmt.NetworkElementDiscovered;
import com.ossnms.bicnet.bcb.model.elementMgmt.TpGroupMode;
import com.ossnms.bicnet.bcb.model.elementMgmt.WriteAccessState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertBcbPropertyToMap;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb;
import com.ossnms.dcn_manager.bicnet.connector.messaging.DecoratedNotification;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.OperationalMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import org.slf4j.Logger;
import rx.functions.Func1;

import javax.annotation.Nullable;
import java.io.UnsupportedEncodingException;
import java.util.Optional;

import static org.slf4j.LoggerFactory.getLogger;

final class MapToInternalDiscoveryEvent implements
        Func1<DecoratedNotification, Event> {

    private static final Logger LOGGER = getLogger(MapToInternalDiscoveryEvent.class);

    private final StaticConfiguration configuration;

    MapToInternalDiscoveryEvent(StaticConfiguration configuration) {
        this.configuration = configuration;
    }

    @Override
    public Event call(DecoratedNotification notification) {
        final NetworkElementDiscovered event = notification.getNotification(NetworkElementDiscovered.class).get();
        final INE ne = event.getDiscoveredNetworkElement();
        /*
         * Rationale: don't make educated guesses about information that is not present.
         * The actual event handler will need to know what was really received from the
         * outside.
         */
        return new NeDiscoveredEvent(
                buildDescriptorFromBcb(ne),
                ConvertBcbPropertyToMap.convert(event.getProperties()),
                Optional.ofNullable(ne.getIdName()),
                ne.getId());
    }

    private NeCreateDescriptor buildDescriptorFromBcb(INE ne) {
        final NeType neType = configuration.getNeTypes().get(ne.getNeProxyType());
        final NeCreateDescriptor create = new NeCreateDescriptor(ne.getAssociatedEmId(), neType);
        final Optional<String> newIconId = Optional.ofNullable(ne.getIconIdId());
        create.getOperation()
            .setGatewayMode(Optional.ofNullable(ConvertNeToBcb.convertGatewayRole(ne.getGatewayRole())))
            .setMainRelease(Optional.ofNullable(ne.getMainRelease()))
            .setMaintenanceRelease(Optional.ofNullable(ne.getMaintenanceRelease()))
            .setFamily(convertEnum(ne.getNeFamilyEnum()))
            .setNeSubType(convertEnum(ne.getNeSubTypeEnum()))
            .setNeSubTypeDescription(Optional.ofNullable(ne.getNeSubType()))
            .setNeType(convertEnum(ne.getNeTypeEnum()))
            .setRealNeName(Optional.ofNullable(ne.getRealNeName()))
            .setNeSpecificType(Optional.ofNullable(ne.getSpecificType()))
            .setNeighbourhoodId(Optional.ofNullable(ne.getNeighbourhoodId()))
            .setTpGroupMask(Optional.of(ne.getTpGroupMask()))
            .setTpGroupMode(convertTpGroupMode(ne.getTpGroupMode()))
            .setEventForwardingMode(convertEventForwarding(ne.getEventForwarding()))
            .setOperational(convertOperationalState(ne.getOperationalState()))
            .setCommissioning(Optional.ofNullable(ConvertNeToBcb.convertCommissioningStatusSummary(ne.getCommissioningStatus())))
            .setWriteAccess(Optional.ofNullable(ConvertNeToBcb.convertWriteAccessState(WriteAccessState.fromOrdinal(ne.getWriteAccessState()))))
            .setIconId(newIconId);
        if (newIconId.isPresent()) {
            create.getInfo().setIconId(newIconId);
        }
        if (ne.getLoginPasswordMd5() != null && ne.getLoginPasswordMd5().length > 0) {
            try {
                create.getPreferences()
                    .setPassword(Optional.of(new String(ne.getLoginPasswordMd5(), "US-ASCII")));
            } catch (final UnsupportedEncodingException e) {
                LOGGER.warn("Failed to convert to string the login password for NE id {}. {}", ne.getId(), e.getMessage());
            }
        }
        create.getPreferences()
            .setUsesGne(ne.getUsesGNE())
            .setUserName(Optional.ofNullable(ne.getLoginUserName()));
        return create;
    }

    private Optional<String> convertEnum(@SuppressWarnings("rawtypes") @Nullable EnumOrdinalBase enumOrdinalBase) {
        return null == enumOrdinalBase
                ? Optional.empty()
                : Optional.of(enumOrdinalBase.name());
    }

    private Optional<OperationalMode> convertOperationalState(OperationalState operationalState) {
        return null == operationalState ?
                Optional.empty() :
                    Optional.of(OperationalState.DISABLED == operationalState ? OperationalMode.DISABLED : OperationalMode.ENABLED);
    }

    private Optional<Boolean> convertEventForwarding(EnableSwitch eventForwarding) {
        return null == eventForwarding ?
                Optional.empty() :
                    Optional.of(EnableSwitch.ENABLED == eventForwarding);
    }

    private Optional<TpGroupSettings> convertTpGroupMode(TpGroupMode tpGroupMode) {
        return null != tpGroupMode
                ? Optional.of(
                    new TpGroupSettings(tpGroupMode.getAlwaysCompatible(), tpGroupMode.getMultipleGroupMembership(),
                        tpGroupMode.getSubgroupsMustBeEqual(), tpGroupMode.getMultipleSubgroupMembership()))
                : Optional.empty();
    }
}