package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INeDataTransferSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDataTransferSettings;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Convert the BCB Data transfer settings to Ne.
 */
public final class ConvertBcbToDataTransferSettings {

    private ConvertBcbToDataTransferSettings() {}
    
    /**
     * Transform to the NE user preferences.
     *
     * @param input Ne data transfer settings from BCB.
     * @return The NE Data Transfer settings
     */
    @Nonnull
    public static NeDataTransferSettings from(@Nonnull final INeDataTransferSettings input) {
        checkNotNull(input);

        return from(input.getIpAddress(),
                    input.getUserName(),
                    input.getPassword(),
                    input.getUploadPath(),
                    input.getScpMode());
    }

    private static NeDataTransferSettings from(String ipAddress, String userName, String password, String uploadPath, boolean scpModeEnable) {
        return new NeDataTransferSettings(Optional.ofNullable(uploadPath),
                                            Optional.ofNullable(userName),
                                            Optional.ofNullable(password),
                                            Optional.ofNullable(ipAddress), 
                                            scpModeEnable);
    }
}
