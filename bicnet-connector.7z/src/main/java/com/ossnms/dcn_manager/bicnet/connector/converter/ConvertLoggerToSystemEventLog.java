package com.ossnms.dcn_manager.bicnet.connector.converter;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertSeverityToBcb.convertSeverity;

import java.util.Date;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.logMgmt.LogIdItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.SystemEventLogRecordItem;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogId;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecord;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;

/**
 * Converts LoggerItem to BCB {@link SystemEventLogRecordItem}
 */
public class ConvertLoggerToSystemEventLog implements Function<LoggerItem, ILogRecord> {

    protected static final ILogId LOG_SEL_ID = new LogIdItem("System Event Log");

    private final String userName;

    public ConvertLoggerToSystemEventLog(@Nullable String userName) {
        super();
        this.userName = userName;
    }

    public SystemEventLogRecordItem convert(@Nonnull LoggerItem input) {
        final SystemEventLogRecordItem logRecord = new SystemEventLogRecordItem();

        logRecord.setBelonging(LOG_SEL_ID);
        logRecord.setBelongingName(LOG_SEL_ID.getName());
        logRecord.setComponent(BiCNetComponentType.DCN_MANAGER);

        logRecord.setTimeStamp(new Date());

        logRecord.setUserName(userName);
        logRecord.setAffectedObject(input.getAffectedObject());
        logRecord.setDescription(input.getMessage());

        logRecord.setSeverity(convertSeverity(input.getSeverity()));

        return logRecord;
    }

    /**
     * @see Function#apply(Object)
     */
    @Override
    public ILogRecord apply(@Nullable LoggerItem input) {
        return input == null ? null : convert(input);
    }
}
