package com.ossnms.dcn_manager.bicnet.connector.converter;

import javax.annotation.Nonnull;

import com.google.common.base.Function;
import com.google.common.collect.FluentIterable;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomain;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;

public class ConvertDomainToBcb implements Function<DomainInfoData, IAS> {

    private final DomainRepository domainRepository;

    public ConvertDomainToBcb(@Nonnull DomainRepository domainRepository) {
        this.domainRepository = domainRepository;
    }

    /**
     * Converts a Domain entity into a new {@link IAS} BCB object.
     *
     * @param domainInfo Domain instance that will be the source of data.
     * @param childrenNeIds Iterable of children NE identifiers.
     * @return A new BCB IAS instance filled with data.
     */
    public static IAS convert(DomainInfoData domainInfo, Iterable<Integer> childrenNeIds) {
        final IAS as = new ASItem();
        as.setId(domainInfo.getId());
        as.setIdName(domainInfo.getName());
        as.setDiscoveryPermited(domainInfo.isAutomaticNeActivationPermitted());
        setNeList(as, childrenNeIds);
        return as;
    }

    /**
     * Converts a Domain entity into a new {@link INetworkDomain} BCB object.
     *
     * @param domainInfo Domain instance that will be the source of data.
     * @return A new BCB INetworkDomain instance filled with data.
     */
    public static INetworkDomain convert(DomainInfoData domainInfo) {
        final INetworkDomain networkDomain = new NetworkDomainItem();
        networkDomain.setId(domainInfo.getId());
        networkDomain.setIdName(domainInfo.getName());
        networkDomain.setDiscoveryPermited(domainInfo.isAutomaticNeActivationPermitted());
        return networkDomain;
    }

    /**
     * Sets the list of children NE identifiers on an existing {@link IAS} BCB object.
     *
     * @param as An instance of {@link IAS}.
     * @param childrenNeIds Domain children NE identifiers.
     */
    public static void setNeList(final IAS as, Iterable<Integer> childrenNeIds) {
        as.setNeList(FluentIterable
                .from(childrenNeIds)
                .transform(new Function<Integer, INEId>() {
                        @Override
                        public INEId apply(@Nonnull Integer id) {
                            return new NEIdItem(id);
                        }
                    })
                .toArray(INEId.class));
    }

    @Override
    public IAS apply(DomainInfoData input) {
        return convert(input, domainRepository.queryChildrenNEs(input.getId()));
    }

}
