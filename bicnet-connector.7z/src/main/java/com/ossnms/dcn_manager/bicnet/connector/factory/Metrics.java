package com.ossnms.dcn_manager.bicnet.connector.factory;

import com.codahale.metrics.JmxReporter;
import com.codahale.metrics.MetricRegistry;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.composables.metrics.NeInitializationMetrics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.management.*;
import java.lang.management.ManagementFactory;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Factory that produces instances of metrics-gathering classes.
 */
@ApplicationScoped
public class Metrics {

    private static final Logger LOGGER = LoggerFactory.getLogger(Metrics.class);

    private static final String JMX_DCN_MANAGER_DOMAIN = "tnms.dcn-manager";

    private final MetricRegistry metrics;
    private final NeInitializationMetrics neInitializationMetrics;

    private JmxReporter jmxReporter;

    private final Set<ObjectName> registeredMbeans;

    /**
     * Constructs a new object.
     */
    public Metrics() {
        metrics = new MetricRegistry();
        neInitializationMetrics = new NeInitializationMetrics(metrics);
        registeredMbeans = ConcurrentHashMap.newKeySet();
    }

    /**
     * JMX initialization.
     */
    @PostConstruct
    public void initialize() {
        // publish metrics over JMX
        jmxReporter = JmxReporter.forRegistry(metrics)
                .inDomain(JMX_DCN_MANAGER_DOMAIN)
                .createsObjectNamesWith(this::jmxObjectNameBuilder)
                .build();

        // publish specific operations related to NE initialization.
        registerMetric(neInitializationMetrics, NeInitializationMetrics.NE_INITIALIZATION);
    }

    private ObjectName jmxObjectNameBuilder(String type, String domain, String name) {
        final String[] nameParts = name.split("\\.");
        final StringBuilder builder = new StringBuilder();
        char qualifier = 'a';
        builder.append(domain).append(':');
        for (int i = 0; i < nameParts.length; i++, qualifier++) {
            if (i > 0) {
                builder.append(',');
            }
            builder.append(qualifier).append('=').append(nameParts[i]);
        }
        try {
            return ObjectName.getInstance(builder.toString());
        } catch (MalformedObjectNameException e) {
            LOGGER.error("Unable to register {} {}", type, name);
            throw new UnsupportedOperationException(e);
        }
    }


    @PreDestroy
    public void shutdown() {
        jmxReporter.close();
        unregisterMbeans();
    }

    /**
     * @return An instance of the registry of all metrics in the component.
     */
    @Produces
    public MetricRegistry getMetricsRegistry() {
        return metrics;
    }

    /**
     * @return The instance of the class responsible for gathering statistics about NE initialization times.
     */
    @Produces
    public NeInitializationMetrics getNeInitializationMetrics() { return neInitializationMetrics; }

    /**
     * @return The instance of the reporter responsible for providing metrics via JMX.
     */
    @Produces
    public JmxReporter getJmxReporter() {
        return jmxReporter;
    }


    public void registerMetric(final Object mbean, final String name){
        registerMetric(mbean, ImmutableMap.of("a",name));
    }

    public void registerMetric(final Object mbean, final Map<String,String> properties){
        final MBeanServer beanServer = ManagementFactory.getPlatformMBeanServer();
        if (null != beanServer) {
            try {
                final ObjectInstance objectInstance = beanServer.registerMBean(mbean,
                        new ObjectName(JMX_DCN_MANAGER_DOMAIN, new Hashtable<>(properties)));
                registeredMbeans.add(objectInstance.getObjectName());
            } catch (InstanceAlreadyExistsException | MBeanRegistrationException |
                    NotCompliantMBeanException | MalformedObjectNameException e) {
                LOGGER.warn("Could not register operations MBean.", e.getMessage());
            }
        }
    }


    private void unregisterMbeans(){
        final MBeanServer beanServer = ManagementFactory.getPlatformMBeanServer();
        if (null != beanServer) {
            registeredMbeans.forEach(objectName -> unregisterMbean(beanServer, objectName));
        }
    }

    private static void unregisterMbean(final MBeanServer beanServer, final ObjectName objectName){
        try {
            beanServer.unregisterMBean(objectName);
        } catch (InstanceNotFoundException | MBeanRegistrationException e) {
            LOGGER.warn("Could not unregister operations MBean.", e.getMessage());
        }
    }




}
