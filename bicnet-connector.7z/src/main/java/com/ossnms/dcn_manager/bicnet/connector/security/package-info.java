
/**
 * <p>Contains an enumeration of all secured component actions, whether connected to menu
 * actions or not. Also contains annotations and aspects used for securing exposed facades.</p>
 *
 * <p>It goes without saying that utility classes are present as well.</p>
 */

package com.ossnms.dcn_manager.bicnet.connector.security;
