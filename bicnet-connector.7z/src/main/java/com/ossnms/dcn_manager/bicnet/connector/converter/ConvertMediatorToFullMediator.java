package com.ossnms.dcn_manager.bicnet.connector.converter;

import java.util.function.Function;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.tuple.Triple;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.MediatorInfo;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;

/**
 * Handles conversion of internal domain entities representing a Mediator to its
 * corresponding type in the BCB object model.
 */
public class ConvertMediatorToFullMediator implements Function<Triple<MediatorType, MediatorEntity, Iterable<MediatorInstance>>, FullMediatorData> {

    @Override
    public FullMediatorData apply(@Nonnull Triple<MediatorType, MediatorEntity, Iterable<MediatorInstance>> input) {
        return convert(input.getLeft(), input.getMiddle(), input.getRight());
    }

    /**
     * Converts internal domain entities representing a Mediator to a
     * {@link IMediator} BCB object.
     *
     * @param type Mediator type metadata.
     * @param entity Mediator entity instance that will be the source of data.
     * @return A new instance of {@link IMediator} filled with data.
     */
    public static FullMediatorData convert(MediatorType type, MediatorEntity entity, Iterable<MediatorInstance> instances) {
        final IMediator mediator = ConvertMediatorToBcb.convert(type, entity, instances);
        final MediatorInfo mediatorInfo = ConvertMediatorToMediatorGuiInfo.build(entity, instances);

        return new FullMediatorData(mediator, mediatorInfo);
    }
}
