package com.bnppa.sesame.services.internal.v2;

import com.bnppa.sesame.services.internal.exception.v2.InvalidParameterException;
import com.bnppa.sesame.services.internal.exception.v2.TechnicalException;
import com.bnppa.sesame.services.internal.exception.v2.UnauthorizedActionException;
import com.bnppa.sesame.services.internal.model.v2.IdentityProviderCertificate;
import java.math.BigInteger;
import java.util.List;

public interface IdentityProviderServices {
    List<IdentityProviderCertificate> getIdentityProviderCertificatesInfo(String var1) throws UnauthorizedActionException, TechnicalException;

    void storeIdentityProviderCertificate(String var1, IdentityProviderCertificate var2) throws UnauthorizedActionException, InvalidParameterException, TechnicalException;

    IdentityProviderCertificate getCurrentIdentityProviderCertificate(String var1) throws UnauthorizedActionException, TechnicalException;

    IdentityProviderCertificate getCurrentIdentityProviderCertificateWithoutToken() throws UnauthorizedActionException, TechnicalException;

    IdentityProviderCertificate getNextIdentityProviderCertificate(String var1) throws UnauthorizedActionException, TechnicalException;

    void setCurrentIdentityProviderCertificate(String var1, BigInteger var2) throws UnauthorizedActionException, InvalidParameterException, TechnicalException;

    void setNextIdentityProviderCertificate(String var1, BigInteger var2) throws UnauthorizedActionException, InvalidParameterException, TechnicalException;
}
