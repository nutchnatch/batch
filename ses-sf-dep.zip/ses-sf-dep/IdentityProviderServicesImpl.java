package com.bnppa.sesame.services.internal.v2;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import com.bnppa.sesame.services.standard.impl.AuthentLevelV1Impl;
import com.bnppa.sesame.services.utils.exception.FunctionalException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.bnppa.sesame.services.business.account.AccountEBO;
import com.bnppa.sesame.services.business.authaccount.AuthAccountEBO;
import com.bnppa.sesame.services.business.constants.UnAuthorizedActionBOExceptionConstants;
import com.bnppa.sesame.services.business.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.services.business.exceptions.TechnicalBOException;
import com.bnppa.sesame.services.business.exceptions.UnAuthorizedActionBOException;
import com.bnppa.sesame.services.business.sci.idprovidercertificate.IdProviderCertificateSBO;
import com.bnppa.sesame.services.business.token.TokenEBO;
import com.bnppa.sesame.services.business.token.TokenSBO;
import com.bnppa.sesame.services.business.uaa.SesameCAPermission;
import com.bnppa.sesame.services.internal.exception.v2.InvalidParameterException;
import com.bnppa.sesame.services.internal.exception.v2.TechnicalException;
import com.bnppa.sesame.services.internal.exception.v2.UnauthorizedActionException;
import com.bnppa.sesame.services.internal.mapper.InternalExceptionMapper;
import com.bnppa.sesame.services.internal.model.v2.IdentityProviderCertificate;
import com.bnppa.sesame.services.model.IdProviderCertificateDO;
import com.bnppa.sesame.services.standard.model.Permission;
import com.bnppa.sesame.services.utils.ManageSecurityHelper;
import com.bnppa.sesame.services.utils.annot.Audit;
import com.bnppa.sesame.services.utils.annot.Profiled;
import com.bnppa.sesame.services.utils.annot.RuntimeCatcher;
import com.bnppa.sesame.services.utils.annot.Token;
import com.bnppa.sesame.services.utils.annot.TokenControl;

@Service
public class IdentityProviderServicesImpl implements IdentityProviderServices {

    private static final Log LOGGER = LogFactory.getLog(IdentityProviderServicesImpl.class);
    private static final String APPLICATION_DOMAIN_LABEL = "SAF";

    @Autowired
    private TokenSBO tokenSBO;

    @Autowired
    private IdProviderCertificateSBO idProviderCertificateSBO;

    @Autowired
    private InternalExceptionMapper exceptionMapper;

    @Autowired
    private AuthentLevelV1Impl authenticationLevelServices;

	@Autowired
	private ManageSecurityHelper manageSecurityHelper;

    /**
     * Check if the owner of token has the permission(s) tin toCheck on the
     * ServiceProviderServicesImpl.APPLICATION_DOMAIN_LABEL domain
     * 
     * @param token
     *            the token identifying the current user session
     * @param toCheck
     *            the permissions to check
     * @throws UnauthorizedActionException
     *             in the user is missing any of the permissions in toCheck
     * @throws TechnicalException
     *             in a technical (non-functional) error occurs
     */
	private void checkPermissions(final String token, final SesameCAPermission... toCheck) throws UnauthorizedActionException,
			TechnicalException {
		try {
			final TokenEBO tokenEBO = this.tokenSBO.find(token);
			final AuthAccountEBO authAccountEBO = this.tokenSBO.getAuthAccount(tokenEBO);
			final AccountEBO accountEBO = authAccountEBO.getAccount();
			Permission[] permissions = this.authenticationLevelServices.getPermissionsWithAuthenticationLevel(token,
					IdentityProviderServicesImpl.APPLICATION_DOMAIN_LABEL);
			if (permissions == null) {
				permissions = new Permission[] {};
			}

			final Set<String> permissionLabels = new HashSet<>(permissions.length);
			for (final Permission item : permissions) {
				final String label = item.getLabel();
				permissionLabels.add(label);
			}

			for (final SesameCAPermission item : toCheck) {
				final String permissionName = item.getName();
				if (!permissionLabels.contains(permissionName)) {
					throw new UnAuthorizedActionBOException(
							UnAuthorizedActionBOExceptionConstants.USER_NO_PERMISSION_ON_DOMAIN,
							new String[] {
									accountEBO.getId(), permissionName,
									IdentityProviderServicesImpl.APPLICATION_DOMAIN_LABEL },
							IdentityProviderServicesImpl.LOGGER);
				}
			}
		} catch (UnAuthorizedActionBOException e) {
			throw this.exceptionMapper.map(e, LOGGER);
		} catch (TechnicalBOException e) {
			throw this.exceptionMapper.map(e, LOGGER);
		} catch (com.bnppa.sesame.services.utils.exception.TechnicalException e) {
			throw new TechnicalException(e.getMessage());
		} catch (FunctionalException e) {
			throw new TechnicalException(e.getMessage());
		}
	}

    /**
     * {@inheritDoc}
     */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = UnauthorizedActionException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-spring-IdentityProviderServices-getIdentityProviderCertificatesInfo")
	@Transactional(readOnly = true)
	@Override
	public List<IdentityProviderCertificate> getIdentityProviderCertificatesInfo(@Token String token)
			throws UnauthorizedActionException, TechnicalException {
		this.checkPermissions(token, SesameCAPermission.SESAME_SAF_getIdentityProviderCertificatesInfo);
		final List<IdProviderCertificateDO> sourceObjects = this.idProviderCertificateSBO.findList();
		return sourceObjects.stream().map(p -> IdentityProviderServicesImpl.mapWithoutMetadata(p)).collect(Collectors.toList());
	}

    /**
     * maps all relevant information in source to a new
     * IdentityProviderCertificate instance, excluding the metadata
     * 
     * @param source
     *            the source instance
     * @return the mapped instance
     */
	private static IdentityProviderCertificate mapWithoutMetadata(final IdProviderCertificateDO source) {
		if (source == null) {
			return null;
		}
		final IdentityProviderCertificate ret = new IdentityProviderCertificate();
		ret.setCreationDate(source.getCreationDate());
		ret.setSerialNumber(BigInteger.valueOf(source.getSerialNumber()));
		return ret;
	}

    /**
     * maps all relevant information in source to a new
     * IdentityProviderCertificate instance
     * 
     * @param source
     *            the source instance
     * @return the mapped instance
     */
	private static IdentityProviderCertificate map(final IdProviderCertificateDO source) {
		if (source == null) {
			return null;
		}
		final IdentityProviderCertificate ret = IdentityProviderServicesImpl.mapWithoutMetadata(source);
		ret.setCertificate(source.getCertificate());
		return ret;
	}

    /**
     * {@inheritDoc}
     */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = UnauthorizedActionException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-spring-IdentityProviderServices-storeIdentityProviderCertificate")
	@Transactional(readOnly = true)
    @Override
	public void storeIdentityProviderCertificate(@Token String token, IdentityProviderCertificate certificate)
			throws UnauthorizedActionException, InvalidParameterException, TechnicalException {
		this.checkPermissions(token, SesameCAPermission.SESAME_SAF_storeIdentityProviderCertificate);
		if (certificate == null) {
			throw new InvalidParameterException("certificate == " + certificate);
		}

		final BigInteger serialNumberBI = certificate.getSerialNumber();
		if (serialNumberBI == null) {
			throw new InvalidParameterException("certificate.serialNumber == " + serialNumberBI);
		}

		final long serialNumber = serialNumberBI.longValue();
		final IdProviderCertificateDO existing = this.idProviderCertificateSBO.findById(serialNumber);
		if (existing != null) {
			throw new InvalidParameterException("an instance with serialNumber " + serialNumber + " already exists");
		}

		final IdProviderCertificateDO toCreate = IdentityProviderServicesImpl.map(certificate);
		this.idProviderCertificateSBO.create(toCreate);
	}

    /**
     * maps all relevant information in source to a new IdProviderCertificateEBO
     * instance
     * 
     * @param source
     *            the source instance
     * @return the mapped instance
     */
	private static IdProviderCertificateDO map(final IdentityProviderCertificate source) {
		final IdProviderCertificateDO ret = new IdProviderCertificateDO();
		ret.setCertificate(source.getCertificate());
		ret.setCreationDate(source.getCreationDate());
		ret.setSerialNumber(source.getSerialNumber().longValue());
		return ret;
	}

    /**
     * {@inheritDoc}
     */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = UnauthorizedActionException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-spring-IdentityProviderServices-getCurrentIdentityProviderCertificate")
	@Transactional(readOnly = true)
    @Override
	public IdentityProviderCertificate getCurrentIdentityProviderCertificate(@Token String token)
			throws UnauthorizedActionException, TechnicalException {
		this.checkPermissions(token, SesameCAPermission.SESAME_SAF_getIdentityProviderCurrentPEMCertificate);
		return this.getCurrentIdentityProviderCertificateWithoutAuthentication();
	}

	private IdentityProviderCertificate getCurrentIdentityProviderCertificateWithoutAuthentication() {
		final IdProviderCertificateDO source = this.idProviderCertificateSBO.findCurrent();
		return IdentityProviderServicesImpl.map(source);
	}

    /**
     * {@inheritDoc}
     */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = UnauthorizedActionException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-spring-IdentityProviderServices-getNextIdentityProviderCertificate")
	@Transactional(readOnly = true)
    @Override
	public IdentityProviderCertificate getNextIdentityProviderCertificate(@Token String token) 
			throws UnauthorizedActionException, TechnicalException {
		this.checkPermissions(token, SesameCAPermission.SESAME_SAF_getIdentityProviderNextPEMCertificate);
		final IdProviderCertificateDO source = this.idProviderCertificateSBO.findNext();
		return IdentityProviderServicesImpl.map(source);

	}

    /**
     * {@inheritDoc}
     */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = UnauthorizedActionException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-spring-IdentityProviderServices-setCurrentIdentityProviderCertificate")
	@Transactional(rollbackFor = { Exception.class })
    @Override
	public void setCurrentIdentityProviderCertificate(@Token String token, BigInteger serialNumber)
			throws UnauthorizedActionException, InvalidParameterException, TechnicalException {
		this.checkPermissions(token, SesameCAPermission.SESAME_SAF_updateIdentityProviderCertificatesInfo);
		try {
			this.idProviderCertificateSBO.setCurrentCertificate(serialNumber);
		} catch (InvalidParameterBOException e) {
			throw this.exceptionMapper.map(e, LOGGER);
		} catch (TechnicalBOException e) {
			throw this.exceptionMapper.map(e, LOGGER);
		}
	}

    /**
     * {@inheritDoc}
     */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = UnauthorizedActionException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-spring-IdentityProviderServices-setNextIdentityProviderCertificate")
	@Transactional(rollbackFor = { Exception.class })
    @Override
	public void setNextIdentityProviderCertificate(@Token String token, BigInteger serialNumber)
			throws UnauthorizedActionException, InvalidParameterException, TechnicalException {
		this.checkPermissions(token, SesameCAPermission.SESAME_SAF_updateIdentityProviderCertificatesInfo);
		try {
			this.idProviderCertificateSBO.setNextCertificate(serialNumber);
		} catch (InvalidParameterBOException e) {
			throw this.exceptionMapper.map(e, LOGGER);
		} catch (TechnicalBOException e) {
			throw this.exceptionMapper.map(e, LOGGER);
		}
	}

    /**
     * {@inheritDoc}
     */
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-spring-IdentityProviderServices-getCurrentIdentityProviderCertificateWithoutToken")
	@Transactional(readOnly = true)
    @Override
	public IdentityProviderCertificate getCurrentIdentityProviderCertificateWithoutToken()
			throws UnauthorizedActionException, TechnicalException {
		final RequestAttributes att = RequestContextHolder.currentRequestAttributes();
		if (att == null) {
			throw new TechnicalException("Impossible to find RequestAttributes object.");
		}
		final HttpServletRequest request = ((ServletRequestAttributes) att).getRequest();
		if (request == null) {
			throw new TechnicalException("Impossible to find HttpServletRequest object.");
		}
		this.manageSecurityHelper.basicAuthentication(request);
		return this.getCurrentIdentityProviderCertificateWithoutAuthentication();
	}

}
